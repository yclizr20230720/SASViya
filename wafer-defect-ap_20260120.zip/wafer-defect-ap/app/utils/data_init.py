"""
Data initialization utility for JSON storage
Creates initial JSON files with proper structure
"""
import os
import json
from datetime import datetime
from app.utils.json_storage import JSONStorage


def generate_lot_id(lot_number: int) -> str:
    """
    Generate LotID in format: M93242.00
    
    Args:
        lot_number: 5-digit lot number
    
    Returns:
        LotID string (e.g., M93242.00)
    """
    return f"M{lot_number:05d}.00"


def generate_wafer_id(lot_number: int, wafer_number: int) -> str:
    """
    Generate WaferID in format: M93242.01 to M93242.25
    
    Args:
        lot_number: 5-digit lot number
        wafer_number: Wafer number (1-25)
    
    Returns:
        WaferID string (e.g., M93242.01)
    """
    if wafer_number < 1 or wafer_number > 25:
        raise ValueError("Wafer number must be between 1 and 25")
    return f"M{lot_number:05d}.{wafer_number:02d}"


def validate_lot_id(lot_id: str) -> bool:
    """
    Validate LotID format: M93242.00 (9 characters)
    
    Args:
        lot_id: LotID to validate
    
    Returns:
        True if valid, False otherwise
    """
    if not lot_id or len(lot_id) != 9:
        return False
    
    if not lot_id.startswith('M'):
        return False
    
    if not lot_id.endswith('.00'):
        return False
    
    try:
        # Check if middle part is 5 digits (positions 1-6)
        int(lot_id[1:6])
        return True
    except ValueError:
        return False


def validate_wafer_id(wafer_id: str) -> bool:
    """
    Validate WaferID format: M93242.01 to M93242.25 (9 characters)
    
    Args:
        wafer_id: WaferID to validate
    
    Returns:
        True if valid, False otherwise
    """
    if not wafer_id or len(wafer_id) != 9:
        return False
    
    if not wafer_id.startswith('M'):
        return False
    
    if wafer_id[6] != '.':
        return False
    
    try:
        # Check if middle part is 5 digits (positions 1-6)
        int(wafer_id[1:6])
        
        # Check if wafer number is between 01 and 25 (positions 7-9)
        wafer_num = int(wafer_id[7:9])
        if wafer_num < 1 or wafer_num > 25:
            return False
        
        return True
    except (ValueError, IndexError):
        return False


def initialize_json_files(metadata_folder: str):
    """
    Initialize all JSON data files with empty arrays
    
    Args:
        metadata_folder: Path to metadata folder
    """
    storage = JSONStorage(metadata_folder)
    
    # Initialize empty JSON files
    files = [
        'wafers.json',
        'defects.json',
        'training_jobs.json',
        'inference_results.json',
        'models.json'
    ]
    
    for filename in files:
        file_path = os.path.join(metadata_folder, filename)
        if not os.path.exists(file_path):
            storage.write(filename, [])
            print(f"✓ Created {filename}")
        else:
            print(f"- {filename} already exists")
    
    print(f"\n✓ JSON storage initialized at: {metadata_folder}")


def create_sample_data(metadata_folder: str):
    """
    Create sample data for testing (optional)
    
    Args:
        metadata_folder: Path to metadata folder
    """
    storage = JSONStorage(metadata_folder)
    
    # Sample lot and wafer data
    sample_wafers = [
        {
            "lot_id": "M93242.00",
            "wafer_id": "M93242.01",
            "tool_id": "LITHO-ASML-04",
            "scan_time": "2024-01-15T10:30:00Z",
            "process_step": "Lithography",
            "defect_count": 45,
            "status": "processed"
        },
        {
            "lot_id": "M93242.00",
            "wafer_id": "M93242.02",
            "tool_id": "LITHO-ASML-04",
            "scan_time": "2024-01-15T10:35:00Z",
            "process_step": "Lithography",
            "defect_count": 38,
            "status": "processed"
        },
        {
            "lot_id": "M93243.00",
            "wafer_id": "M93243.01",
            "tool_id": "CVD-AMAT-02",
            "scan_time": "2024-01-15T11:00:00Z",
            "process_step": "CVD",
            "defect_count": 52,
            "status": "pending"
        }
    ]
    
    # Add sample wafers
    for wafer in sample_wafers:
        storage.append('wafers.json', wafer)
    
    print(f"\n✓ Created {len(sample_wafers)} sample wafer records")


if __name__ == '__main__':
    # Test the functions
    print("Testing ID generation and validation:")
    print(f"LotID: {generate_lot_id(93242)}")
    print(f"WaferID: {generate_wafer_id(93242, 1)}")
    print(f"WaferID: {generate_wafer_id(93242, 25)}")
    
    print(f"\nValidation tests:")
    print(f"Valid LotID 'M93242.00': {validate_lot_id('M93242.00')}")
    print(f"Invalid LotID 'M93242.01': {validate_lot_id('M93242.01')}")
    print(f"Valid WaferID 'M93242.01': {validate_wafer_id('M93242.01')}")
    print(f"Valid WaferID 'M93242.25': {validate_wafer_id('M93242.25')}")
    print(f"Invalid WaferID 'M93242.26': {validate_wafer_id('M93242.26')}")
    print(f"Invalid WaferID 'M93242.00': {validate_wafer_id('M93242.00')}")
