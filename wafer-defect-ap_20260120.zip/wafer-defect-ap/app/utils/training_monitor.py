"""
Training Monitor Utility

Captures training console output and updates job status in real-time
"""
import os
import sys
import re
import json
from datetime import datetime
from typing import Dict, Optional
from pathlib import Path


class TrainingMonitor:
    """
    Monitor training progress and capture console output
    
    Features:
    - Capture console output to log file
    - Parse training metrics from output
    - Update job status in real-time
    - Track epoch progress
    """
    
    def __init__(self, job_id: str, metadata_folder: str, log_folder: str):
        """
        Initialize training monitor
        
        Args:
            job_id: Training job ID
            metadata_folder: Path to metadata folder
            log_folder: Path to logs folder
        """
        self.job_id = job_id
        self.metadata_folder = metadata_folder
        self.log_folder = log_folder
        
        # Create log file
        os.makedirs(log_folder, exist_ok=True)
        self.log_file = os.path.join(log_folder, f'training_{job_id}.log')
        
        # Metrics history
        self.metrics_history = []
        
        # Current metrics
        self.current_metrics = {
            'epoch': 0,
            'train_loss': 0.0,
            'train_pattern_acc': 0.0,
            'train_root_cause_acc': 0.0,
            'val_loss': 0.0,
            'val_pattern_acc': 0.0,
            'val_root_cause_acc': 0.0,
            'learning_rate': 0.0
        }
    
    def log(self, message: str):
        """
        Log message to file and parse metrics
        
        Args:
            message: Log message
        """
        # Write to log file
        with open(self.log_file, 'a', encoding='utf-8') as f:
            timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"[{timestamp}] {message}\n")
        
        # Parse metrics from message
        self._parse_metrics(message)
    
    def _parse_metrics(self, message: str):
        """
        Parse training metrics from console output
        
        Args:
            message: Console output message
        """
        # Parse epoch number
        epoch_match = re.search(r'Epoch (\d+)/(\d+)', message)
        if epoch_match:
            self.current_metrics['epoch'] = int(epoch_match.group(1))
            self.current_metrics['total_epochs'] = int(epoch_match.group(2))
        
        # Parse train metrics
        train_match = re.search(r'Train - Loss: ([\d.]+), Pattern Acc: ([\d.]+), Root Cause Acc: ([\d.]+)', message)
        if train_match:
            self.current_metrics['train_loss'] = float(train_match.group(1))
            self.current_metrics['train_pattern_acc'] = float(train_match.group(2))
            self.current_metrics['train_root_cause_acc'] = float(train_match.group(3))
        
        # Parse validation metrics
        val_match = re.search(r'Val\s+-\s+Loss: ([\d.]+), Pattern Acc: ([\d.]+), Root Cause Acc: ([\d.]+)', message)
        if val_match:
            self.current_metrics['val_loss'] = float(val_match.group(1))
            self.current_metrics['val_pattern_acc'] = float(val_match.group(2))
            self.current_metrics['val_root_cause_acc'] = float(val_match.group(3))
            
            # Save to history when validation metrics are available
            self.metrics_history.append(self.current_metrics.copy())
        
        # Parse learning rate
        lr_match = re.search(r'LR: ([\d.]+)', message)
        if lr_match:
            self.current_metrics['learning_rate'] = float(lr_match.group(1))
        
        # Update job status after parsing
        self._update_job_status()
    
    def _update_job_status(self):
        """Update training job status in JSON storage"""
        try:
            from app.utils.json_storage import JSONStorage
            
            storage = JSONStorage(self.metadata_folder)
            
            # Find job
            job = storage.find_one('training_jobs.json', job_id=self.job_id)
            
            if job:
                # Update metrics
                updates = {
                    'current_epoch': self.current_metrics.get('epoch', 0),
                    'metrics': {
                        'train_loss': self.current_metrics.get('train_loss', 0.0),
                        'train_pattern_acc': self.current_metrics.get('train_pattern_acc', 0.0),
                        'train_root_cause_acc': self.current_metrics.get('train_root_cause_acc', 0.0),
                        'val_loss': self.current_metrics.get('val_loss', 0.0),
                        'val_pattern_acc': self.current_metrics.get('val_pattern_acc', 0.0),
                        'val_root_cause_acc': self.current_metrics.get('val_root_cause_acc', 0.0),
                        'learning_rate': self.current_metrics.get('learning_rate', 0.0)
                    },
                    'last_updated': datetime.utcnow().isoformat(),
                    'metrics_history': self.metrics_history
                }
                
                # Update status to running if not already
                if job.get('status') == 'queued':
                    updates['status'] = 'running'
                    updates['start_time'] = datetime.utcnow().isoformat()
                
                storage.update('training_jobs.json', job['id'], updates)
        
        except Exception as e:
            # Don't fail training if status update fails
            print(f"Warning: Failed to update job status: {str(e)}")
    
    def mark_completed(self, success: bool = True):
        """
        Mark training job as completed
        
        Args:
            success: Whether training completed successfully
        """
        try:
            from app.utils.json_storage import JSONStorage
            
            storage = JSONStorage(self.metadata_folder)
            
            # Find job
            job = storage.find_one('training_jobs.json', job_id=self.job_id)
            
            if job:
                updates = {
                    'status': 'completed' if success else 'failed',
                    'end_time': datetime.utcnow().isoformat(),
                    'last_updated': datetime.utcnow().isoformat()
                }
                
                storage.update('training_jobs.json', job['id'], updates)
                
                # Log completion
                self.log(f"Training {'completed successfully' if success else 'failed'}")
        
        except Exception as e:
            print(f"Warning: Failed to mark job as completed: {str(e)}")
    
    def get_metrics(self) -> Dict:
        """
        Get current training metrics
        
        Returns:
            Dictionary with current metrics
        """
        return self.current_metrics.copy()
    
    def get_metrics_history(self) -> list:
        """
        Get metrics history
        
        Returns:
            List of metrics dictionaries
        """
        return self.metrics_history.copy()


class TeeOutput:
    """
    Tee output to both console and training monitor
    
    Captures stdout/stderr and sends to both console and log file
    """
    
    def __init__(self, monitor: TrainingMonitor, original_stream):
        """
        Initialize tee output
        
        Args:
            monitor: Training monitor instance
            original_stream: Original stdout/stderr stream
        """
        self.monitor = monitor
        self.original_stream = original_stream
    
    def write(self, message: str):
        """Write message to both console and log"""
        # Write to original stream (console)
        self.original_stream.write(message)
        self.original_stream.flush()
        
        # Write to monitor log
        if message.strip():  # Only log non-empty messages
            self.monitor.log(message.strip())
    
    def flush(self):
        """Flush output"""
        self.original_stream.flush()


def setup_training_monitor(job_id: str, metadata_folder: str, log_folder: str) -> TrainingMonitor:
    """
    Setup training monitor and redirect output
    
    Args:
        job_id: Training job ID
        metadata_folder: Path to metadata folder
        log_folder: Path to logs folder
    
    Returns:
        TrainingMonitor instance
    """
    # Create monitor
    monitor = TrainingMonitor(job_id, metadata_folder, log_folder)
    
    # Redirect stdout and stderr
    sys.stdout = TeeOutput(monitor, sys.stdout)
    sys.stderr = TeeOutput(monitor, sys.stderr)
    
    monitor.log(f"Training monitor initialized for job: {job_id}")
    
    return monitor
