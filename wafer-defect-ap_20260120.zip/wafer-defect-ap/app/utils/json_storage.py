"""
JSON-based data storage manager with file locking for concurrent access
"""
import json
import os
from datetime import datetime
from typing import Any, Dict, List, Optional
from filelock import FileLock
import uuid


class JSONStorage:
    """
    Thread-safe JSON file storage manager
    """
    
    def __init__(self, base_path: str):
        """
        Initialize JSON storage manager
        
        Args:
            base_path: Base directory for JSON files
        """
        self.base_path = base_path
        os.makedirs(base_path, exist_ok=True)
    
    def _get_file_path(self, filename: str) -> str:
        """Get full file path"""
        return os.path.join(self.base_path, filename)
    
    def _get_lock_path(self, filename: str) -> str:
        """Get lock file path"""
        return os.path.join(self.base_path, f"{filename}.lock")
    
    def read(self, filename: str, default: Any = None) -> Any:
        """
        Read data from JSON file with file locking
        
        Args:
            filename: JSON filename
            default: Default value if file doesn't exist
        
        Returns:
            Data from JSON file or default value
        """
        file_path = self._get_file_path(filename)
        lock_path = self._get_lock_path(filename)
        
        if not os.path.exists(file_path):
            return default if default is not None else []
        
        with FileLock(lock_path, timeout=10):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return default if default is not None else []
            except Exception as e:
                raise Exception(f"Error reading {filename}: {str(e)}")
    
    def write(self, filename: str, data: Any) -> bool:
        """
        Write data to JSON file with file locking
        
        Args:
            filename: JSON filename
            data: Data to write
        
        Returns:
            True if successful
        """
        file_path = self._get_file_path(filename)
        lock_path = self._get_lock_path(filename)
        
        with FileLock(lock_path, timeout=10):
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False, default=str)
                return True
            except Exception as e:
                raise Exception(f"Error writing {filename}: {str(e)}")
    
    def append(self, filename: str, item: Dict) -> bool:
        """
        Append item to JSON array file
        
        Args:
            filename: JSON filename
            item: Item to append
        
        Returns:
            True if successful
        """
        data = self.read(filename, default=[])
        if not isinstance(data, list):
            raise ValueError(f"{filename} does not contain an array")
        
        # Add timestamp and ID if not present
        if 'id' not in item:
            item['id'] = str(uuid.uuid4())
        if 'created_at' not in item:
            item['created_at'] = datetime.utcnow().isoformat()
        
        data.append(item)
        return self.write(filename, data)
    
    def update(self, filename: str, item_id: str, updates: Dict) -> bool:
        """
        Update item in JSON array file by ID
        
        Args:
            filename: JSON filename
            item_id: Item ID to update
            updates: Fields to update
        
        Returns:
            True if successful, False if item not found
        """
        data = self.read(filename, default=[])
        if not isinstance(data, list):
            raise ValueError(f"{filename} does not contain an array")
        
        for item in data:
            if item.get('id') == item_id:
                item.update(updates)
                item['updated_at'] = datetime.utcnow().isoformat()
                return self.write(filename, data)
        
        return False
    
    def delete(self, filename: str, item_id: str) -> bool:
        """
        Delete item from JSON array file by ID
        
        Args:
            filename: JSON filename
            item_id: Item ID to delete
        
        Returns:
            True if successful, False if item not found
        """
        data = self.read(filename, default=[])
        if not isinstance(data, list):
            raise ValueError(f"{filename} does not contain an array")
        
        original_length = len(data)
        data = [item for item in data if item.get('id') != item_id]
        
        if len(data) < original_length:
            return self.write(filename, data)
        
        return False
    
    def find(self, filename: str, **filters) -> List[Dict]:
        """
        Find items in JSON array file matching filters
        
        Args:
            filename: JSON filename
            **filters: Field filters (e.g., wafer_id='W001')
        
        Returns:
            List of matching items
        """
        data = self.read(filename, default=[])
        if not isinstance(data, list):
            return []
        
        if not filters:
            return data
        
        results = []
        for item in data:
            match = True
            for key, value in filters.items():
                if item.get(key) != value:
                    match = False
                    break
            if match:
                results.append(item)
        
        return results
    
    def find_one(self, filename: str, **filters) -> Optional[Dict]:
        """
        Find first item matching filters
        
        Args:
            filename: JSON filename
            **filters: Field filters
        
        Returns:
            First matching item or None
        """
        results = self.find(filename, **filters)
        return results[0] if results else None
    
    def count(self, filename: str, **filters) -> int:
        """
        Count items matching filters
        
        Args:
            filename: JSON filename
            **filters: Field filters
        
        Returns:
            Count of matching items
        """
        return len(self.find(filename, **filters))
    
    def backup(self, filename: str) -> str:
        """
        Create backup of JSON file
        
        Args:
            filename: JSON filename
        
        Returns:
            Backup filename
        """
        file_path = self._get_file_path(filename)
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"{filename} not found")
        
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        backup_filename = f"{filename}.backup_{timestamp}"
        backup_path = self._get_file_path(backup_filename)
        
        data = self.read(filename)
        with open(backup_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=str)
        
        return backup_filename
