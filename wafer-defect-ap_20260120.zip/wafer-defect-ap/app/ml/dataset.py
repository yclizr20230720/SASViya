"""
PyTorch Dataset classes for wafer defect pattern recognition
"""
import os
import json
import torch
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import numpy as np
from typing import Tuple, Optional, List, Dict
from pathlib import Path

from .preprocessing import WaferPreprocessor, WaferAugmentation
from .model import PATTERN_CLASSES, ROOT_CAUSE_CLASSES


class WaferDefectDataset(Dataset):
    """
    PyTorch Dataset for wafer defect pattern recognition
    
    Loads wafer images and labels for multi-task learning:
    - Pattern classification (10 classes)
    - Root cause classification (8 classes)
    """
    
    def __init__(
        self,
        data_dir: str,
        metadata_file: str,
        transform: Optional[object] = None,
        augmentation: Optional[object] = None,
        target_size: Tuple[int, int] = (224, 224)
    ):
        """
        Initialize dataset
        
        Args:
            data_dir: Directory containing wafer images
            metadata_file: Path to JSON file with labels
            transform: Optional preprocessing transform
            augmentation: Optional data augmentation
            target_size: Target image size (height, width)
        """
        self.data_dir = Path(data_dir)
        self.transform = transform or WaferPreprocessor(target_size)
        self.augmentation = augmentation
        
        # Load metadata
        with open(metadata_file, 'r') as f:
            self.metadata = json.load(f)
        
        # Filter valid samples (must have pattern and root_cause labels)
        self.samples = [
            sample for sample in self.metadata
            if 'pattern_class' in sample and 'root_cause' in sample
        ]
        
        print(f"Loaded {len(self.samples)} samples from {metadata_file}")
    
    def __len__(self) -> int:
        return len(self.samples)
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int, int]:
        """
        Get a sample
        
        Args:
            idx: Sample index
        
        Returns:
            tuple: (image_tensor, pattern_label, root_cause_label)
        """
        sample = self.samples[idx]
        
        # Load image
        image_path = self.data_dir / sample['image_filename']
        
        if not image_path.exists():
            # Fallback to image_path field
            image_path = Path(sample.get('image_path', ''))
        
        if not image_path.exists():
            raise FileNotFoundError(f"Image not found: {image_path}")
        
        # Load and preprocess image
        if self.augmentation:
            # Load as PIL for augmentation
            image = Image.open(image_path).convert('RGB')
            image = self.augmentation(image)
            # Save temporarily and preprocess
            image_tensor = self.transform.preprocess_image(image_path)
        else:
            image_tensor = self.transform.preprocess_image(str(image_path))
        
        # Get labels
        pattern_label = self._get_pattern_label(sample['pattern_class'])
        root_cause_label = self._get_root_cause_label(sample['root_cause'])
        
        return image_tensor, pattern_label, root_cause_label
    
    def _get_pattern_label(self, pattern_class: str) -> int:
        """Convert pattern class name to label index"""
        try:
            return PATTERN_CLASSES.index(pattern_class)
        except ValueError:
            # Default to 'Mixed' if unknown
            return PATTERN_CLASSES.index('Mixed')
    
    def _get_root_cause_label(self, root_cause: str) -> int:
        """Convert root cause name to label index"""
        try:
            return ROOT_CAUSE_CLASSES.index(root_cause)
        except ValueError:
            # Default to 'Unknown' if not found
            return ROOT_CAUSE_CLASSES.index('Unknown')



def create_data_loaders(
    train_dir: str,
    val_dir: str,
    test_dir: str,
    train_metadata: str,
    val_metadata: str,
    test_metadata: str,
    batch_size: int = 32,
    num_workers: int = 4,
    augmentation_level: str = 'medium'
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Create train, validation, and test data loaders
    
    Args:
        train_dir: Training images directory
        val_dir: Validation images directory
        test_dir: Test images directory
        train_metadata: Training metadata JSON file
        val_metadata: Validation metadata JSON file
        test_metadata: Test metadata JSON file
        batch_size: Batch size
        num_workers: Number of data loading workers
        augmentation_level: Augmentation level ('light', 'medium', 'strong')
    
    Returns:
        tuple: (train_loader, val_loader, test_loader)
    """
    # Create datasets
    train_dataset = WaferDefectDataset(
        data_dir=train_dir,
        metadata_file=train_metadata,
        augmentation=WaferAugmentation(augmentation_level)
    )
    
    val_dataset = WaferDefectDataset(
        data_dir=val_dir,
        metadata_file=val_metadata,
        augmentation=None  # No augmentation for validation
    )
    
    test_dataset = WaferDefectDataset(
        data_dir=test_dir,
        metadata_file=test_metadata,
        augmentation=None  # No augmentation for testing
    )
    
    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    return train_loader, val_loader, test_loader


def split_dataset(
    metadata_file: str,
    output_dir: str,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    seed: int = 42
) -> Tuple[str, str, str]:
    """
    Split dataset into train/val/test sets
    
    Args:
        metadata_file: Path to metadata JSON file
        output_dir: Output directory for split files
        train_ratio: Training set ratio
        val_ratio: Validation set ratio
        test_ratio: Test set ratio
        seed: Random seed for reproducibility
    
    Returns:
        tuple: (train_metadata_path, val_metadata_path, test_metadata_path)
    """
    import random
    
    # Set random seed
    random.seed(seed)
    np.random.seed(seed)
    
    # Load metadata
    with open(metadata_file, 'r') as f:
        metadata = json.load(f)
    
    # Shuffle
    random.shuffle(metadata)
    
    # Calculate split indices
    n_samples = len(metadata)
    n_train = int(n_samples * train_ratio)
    n_val = int(n_samples * val_ratio)
    
    # Split
    train_data = metadata[:n_train]
    val_data = metadata[n_train:n_train + n_val]
    test_data = metadata[n_train + n_val:]
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Save splits
    train_path = os.path.join(output_dir, 'train_metadata.json')
    val_path = os.path.join(output_dir, 'val_metadata.json')
    test_path = os.path.join(output_dir, 'test_metadata.json')
    
    with open(train_path, 'w') as f:
        json.dump(train_data, f, indent=2)
    
    with open(val_path, 'w') as f:
        json.dump(val_data, f, indent=2)
    
    with open(test_path, 'w') as f:
        json.dump(test_data, f, indent=2)
    
    print(f"Dataset split:")
    print(f"  Train: {len(train_data)} samples ({train_ratio*100:.1f}%)")
    print(f"  Val:   {len(val_data)} samples ({val_ratio*100:.1f}%)")
    print(f"  Test:  {len(test_data)} samples ({test_ratio*100:.1f}%)")
    
    return train_path, val_path, test_path


def calculate_class_weights(metadata_file: str, num_classes: int) -> torch.Tensor:
    """
    Calculate class weights for handling class imbalance
    
    Args:
        metadata_file: Path to metadata JSON file
        num_classes: Number of classes
    
    Returns:
        Class weights tensor
    """
    # Load metadata
    with open(metadata_file, 'r') as f:
        metadata = json.load(f)
    
    # Count class frequencies
    class_counts = np.zeros(num_classes)
    for sample in metadata:
        if 'pattern_class' in sample:
            label = PATTERN_CLASSES.index(sample['pattern_class'])
            class_counts[label] += 1
    
    # Calculate inverse frequency weights
    total = class_counts.sum()
    class_weights = total / (num_classes * class_counts + 1e-6)
    
    # Normalize
    class_weights = class_weights / class_weights.sum() * num_classes
    
    return torch.FloatTensor(class_weights)
