"""
Data preprocessing pipeline for wafer defect pattern recognition

Implements preprocessing steps from AI_MODEL_ARCHITECTURE.md Section 3
"""
import numpy as np
import cv2
from PIL import Image
import torch
from torchvision import transforms
from typing import Tuple, Optional, List, Dict
from sklearn.cluster import DBSCAN


class WaferPreprocessor:
    """
    Preprocess wafer map images for model input
    
    Steps:
    1. Load image (JPG, PNG, GIF)
    2. Convert to RGB if grayscale
    3. Apply circular wafer mask
    4. Resize to 224x224 (EfficientNet input size)
    5. Normalize pixel values
    6. Apply ImageNet normalization
    """
    
    def __init__(self, target_size: Tuple[int, int] = (224, 224)):
        """
        Initialize preprocessor
        
        Args:
            target_size: Target image size (height, width)
        """
        self.target_size = target_size
        
        # ImageNet normalization (for pretrained EfficientNet)
        self.normalize = transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )
    
    def create_circular_mask(self, size: Tuple[int, int]) -> np.ndarray:
        """
        Create circular mask for wafer (wafers are circular)
        
        Args:
            size: Image size (height, width)
        
        Returns:
            Binary mask (1 inside circle, 0 outside)
        """
        h, w = size
        center = (w // 2, h // 2)
        radius = min(w, h) // 2
        
        Y, X = np.ogrid[:h, :w]
        dist_from_center = np.sqrt((X - center[0])**2 + (Y - center[1])**2)
        
        mask = dist_from_center <= radius
        return mask.astype(np.uint8)
    
    def apply_mask(self, image: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """
        Apply circular mask to image
        
        Args:
            image: Input image [H, W, C]
            mask: Binary mask [H, W]
        
        Returns:
            Masked image
        """
        # Expand mask to 3 channels
        mask_3ch = np.stack([mask] * 3, axis=-1)
        
        # Apply mask (set outside to black)
        masked_image = image * mask_3ch
        
        return masked_image
    
    def preprocess_image(self, image_path: str) -> torch.Tensor:
        """
        Preprocess wafer map image
        
        Args:
            image_path: Path to image file
        
        Returns:
            Preprocessed image tensor [3, 224, 224]
        """
        # Load image
        img = Image.open(image_path).convert('RGB')
        img_np = np.array(img)
        
        # Apply circular wafer mask
        mask = self.create_circular_mask(img_np.shape[:2])
        img_np = self.apply_mask(img_np, mask)
        
        # Convert back to PIL
        img = Image.fromarray(img_np)
        
        # Resize to target size
        img = img.resize(self.target_size, Image.LANCZOS)
        
        # Convert to tensor [C, H, W] and normalize to [0, 1]
        img_tensor = transforms.ToTensor()(img)
        
        # Apply ImageNet normalization
        img_tensor = self.normalize(img_tensor)
        
        return img_tensor



class DefectMapGenerator:
    """
    Generate defect density heatmaps from defect coordinates
    """
    
    def __init__(self, wafer_size: Tuple[int, int] = (300, 300)):
        """
        Initialize generator
        
        Args:
            wafer_size: Wafer map size (height, width)
        """
        self.wafer_size = wafer_size
    
    def generate_heatmap(self, defects: List[Dict], sigma: float = 10.0) -> np.ndarray:
        """
        Generate defect density heatmap using Gaussian kernel
        
        Args:
            defects: List of defect dicts with 'x' and 'y' coordinates
            sigma: Gaussian kernel standard deviation
        
        Returns:
            Heatmap [H, W] normalized to [0, 1]
        """
        # Create empty heatmap
        heatmap = np.zeros(self.wafer_size, dtype=np.float32)
        
        if len(defects) == 0:
            return heatmap
        
        # Add Gaussian blob at each defect location
        for defect in defects:
            x = int(defect['x'])
            y = int(defect['y'])
            
            # Ensure coordinates are within bounds
            if 0 <= x < self.wafer_size[1] and 0 <= y < self.wafer_size[0]:
                # Create Gaussian kernel
                kernel_size = int(6 * sigma)  # 6-sigma rule
                if kernel_size % 2 == 0:
                    kernel_size += 1
                
                # Generate 2D Gaussian
                ax = np.arange(-kernel_size // 2 + 1, kernel_size // 2 + 1)
                xx, yy = np.meshgrid(ax, ax)
                kernel = np.exp(-(xx**2 + yy**2) / (2 * sigma**2))
                
                # Calculate bounds for kernel placement
                y_start = max(0, y - kernel_size // 2)
                y_end = min(self.wafer_size[0], y + kernel_size // 2 + 1)
                x_start = max(0, x - kernel_size // 2)
                x_end = min(self.wafer_size[1], x + kernel_size // 2 + 1)
                
                # Calculate kernel slice
                ky_start = kernel_size // 2 - (y - y_start)
                ky_end = kernel_size // 2 + (y_end - y)
                kx_start = kernel_size // 2 - (x - x_start)
                kx_end = kernel_size // 2 + (x_end - x)
                
                # Add kernel to heatmap
                heatmap[y_start:y_end, x_start:x_end] += kernel[ky_start:ky_end, kx_start:kx_end]
        
        # Normalize to [0, 1]
        if heatmap.max() > 0:
            heatmap = (heatmap - heatmap.min()) / (heatmap.max() - heatmap.min())
        
        return heatmap


class SpatialFeatureExtractor:
    """
    Extract hand-crafted spatial features from defect patterns
    
    Features:
    - Center of mass (x, y)
    - Defect density
    - Spatial spread (std)
    - Radial distribution
    - Cluster count (DBSCAN)
    - Edge proximity score
    """
    
    def __init__(self, wafer_size: Tuple[int, int] = (300, 300)):
        """
        Initialize extractor
        
        Args:
            wafer_size: Wafer map size (height, width)
        """
        self.wafer_size = wafer_size
        self.center = (wafer_size[1] / 2, wafer_size[0] / 2)
        self.radius = min(wafer_size) / 2
    
    def extract_features(self, defects: List[Dict]) -> Dict[str, float]:
        """
        Extract spatial features from defect coordinates
        
        Args:
            defects: List of defect dicts with 'x' and 'y' coordinates
        
        Returns:
            Dictionary of feature values
        """
        features = {}
        
        if len(defects) == 0:
            # Return zero features for no defects
            return {
                'center_x': 0.0,
                'center_y': 0.0,
                'density': 0.0,
                'spread_x': 0.0,
                'spread_y': 0.0,
                'radial_mean': 0.0,
                'radial_std': 0.0,
                'cluster_count': 0,
                'edge_proximity': 0.0
            }
        
        # Extract coordinates
        coords = np.array([[d['x'], d['y']] for d in defects])
        
        # Center of mass
        features['center_x'] = np.mean(coords[:, 0])
        features['center_y'] = np.mean(coords[:, 1])
        
        # Defect density (defects per unit area)
        wafer_area = np.pi * self.radius ** 2
        features['density'] = len(defects) / wafer_area
        
        # Spatial spread
        features['spread_x'] = np.std(coords[:, 0])
        features['spread_y'] = np.std(coords[:, 1])
        
        # Radial distribution (distance from wafer center)
        distances = np.sqrt(
            (coords[:, 0] - self.center[0])**2 + 
            (coords[:, 1] - self.center[1])**2
        )
        features['radial_mean'] = np.mean(distances)
        features['radial_std'] = np.std(distances)
        
        # Cluster analysis using DBSCAN
        if len(defects) >= 3:
            clustering = DBSCAN(eps=20, min_samples=3).fit(coords)
            # Count clusters (excluding noise points labeled as -1)
            labels = clustering.labels_
            features['cluster_count'] = len(set(labels)) - (1 if -1 in labels else 0)
        else:
            features['cluster_count'] = 1 if len(defects) > 0 else 0
        
        # Edge proximity score (fraction of defects near edge)
        edge_threshold = self.radius * 0.8  # Within 80% of radius
        near_edge = np.sum(distances > edge_threshold)
        features['edge_proximity'] = near_edge / len(defects)
        
        return features



class WaferAugmentation:
    """
    Domain-specific augmentation for wafer maps
    Preserves pattern semantics while increasing diversity
    """
    
    def __init__(self, augmentation_level: str = 'medium'):
        """
        Initialize augmentation pipeline
        
        Args:
            augmentation_level: 'light', 'medium', or 'strong'
        """
        self.augmentation_level = augmentation_level
        
        # Base transformations (always applied)
        base_transforms = [
            transforms.RandomRotation(degrees=360),  # Wafers are rotationally symmetric
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomVerticalFlip(p=0.5),
        ]
        
        # Medium augmentation
        if augmentation_level in ['medium', 'strong']:
            base_transforms.extend([
                transforms.ColorJitter(
                    brightness=0.2,
                    contrast=0.2,
                    saturation=0.1,
                    hue=0.05
                ),
            ])
        
        # Strong augmentation
        if augmentation_level == 'strong':
            base_transforms.extend([
                transforms.RandomAffine(
                    degrees=0,
                    translate=(0.1, 0.1),
                    scale=(0.9, 1.1)
                ),
            ])
        
        self.transform = transforms.Compose(base_transforms)
    
    def __call__(self, image: Image.Image) -> Image.Image:
        """
        Apply augmentation to image
        
        Args:
            image: PIL Image
        
        Returns:
            Augmented PIL Image
        """
        return self.transform(image)


class AddGaussianNoise:
    """
    Add Gaussian noise to simulate sensor noise
    """
    
    def __init__(self, mean: float = 0.0, std: float = 0.01):
        """
        Initialize noise generator
        
        Args:
            mean: Mean of Gaussian noise
            std: Standard deviation of Gaussian noise
        """
        self.mean = mean
        self.std = std
    
    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        """
        Add Gaussian noise to tensor
        
        Args:
            tensor: Input tensor [C, H, W]
        
        Returns:
            Noisy tensor
        """
        noise = torch.randn_like(tensor) * self.std + self.mean
        return tensor + noise


class ElasticTransform:
    """
    Elastic deformation to simulate wafer warping
    """
    
    def __init__(self, alpha: float = 50, sigma: float = 5):
        """
        Initialize elastic transform
        
        Args:
            alpha: Deformation intensity
            sigma: Smoothness of deformation
        """
        self.alpha = alpha
        self.sigma = sigma
    
    def __call__(self, image: Image.Image) -> Image.Image:
        """
        Apply elastic deformation
        
        Args:
            image: PIL Image
        
        Returns:
            Deformed PIL Image
        """
        img_np = np.array(image)
        shape = img_np.shape[:2]
        
        # Generate random displacement fields
        dx = cv2.GaussianBlur(
            (np.random.rand(*shape) * 2 - 1),
            (0, 0),
            self.sigma
        ) * self.alpha
        dy = cv2.GaussianBlur(
            (np.random.rand(*shape) * 2 - 1),
            (0, 0),
            self.sigma
        ) * self.alpha
        
        # Create meshgrid
        x, y = np.meshgrid(np.arange(shape[1]), np.arange(shape[0]))
        
        # Apply displacement
        map_x = (x + dx).astype(np.float32)
        map_y = (y + dy).astype(np.float32)
        
        # Remap image
        deformed = cv2.remap(
            img_np,
            map_x,
            map_y,
            interpolation=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_REFLECT
        )
        
        return Image.fromarray(deformed)
