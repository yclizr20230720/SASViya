"""
Explainability Engine for Wafer Defect Pattern Recognition

Implements Task 11 from tasks_backend.md:
- Grad-CAM for visual explanations
- SHAP values for feature importance
- Similar case retrieval using embeddings

This module provides interpretable explanations for model predictions
to build trust and enable root cause analysis.
"""
import torch
import torch.nn.functional as F
import numpy as np
from PIL import Image
import cv2
from typing import Dict, List, Tuple, Optional
from pathlib import Path
import shap

from .model import WaferDefectModel
from .preprocessing import WaferPreprocessor


class GradCAMExplainer:
    """
    Gradient-weighted Class Activation Mapping (Grad-CAM)
    
    Generates visual explanations by highlighting regions of the wafer map
    that are most important for the model's prediction.
    
    Reference: Selvaraju et al., "Grad-CAM: Visual Explanations from Deep Networks
    via Gradient-based Localization", ICCV 2017
    """
    
    def __init__(self, model: WaferDefectModel, target_layer: str = None):
        """
        Initialize Grad-CAM explainer
        
        Args:
            model: Trained WaferDefectModel
            target_layer: Name of target layer (default: last conv layer)
        """
        self.model = model
        self.model.eval()
        
        # Find target layer (last convolutional layer of backbone)
        if target_layer is None:
            # For EfficientNet-B3, use the last conv layer
            self.target_layer = self.model.backbone._conv_head
        else:
            self.target_layer = dict(self.model.named_modules())[target_layer]
        
        self.gradients = None
        self.activations = None
        
        # Register hooks
        self.target_layer.register_forward_hook(self._save_activation)
        self.target_layer.register_backward_hook(self._save_gradient)
    
    def _save_activation(self, module, input, output):
        """Hook to save forward activations"""
        self.activations = output.detach()
    
    def _save_gradient(self, module, grad_input, grad_output):
        """Hook to save backward gradients"""
        self.gradients = grad_output[0].detach()
    
    def generate_heatmap(
        self,
        input_tensor: torch.Tensor,
        class_idx: int,
        task: str = 'pattern'
    ) -> np.ndarray:
        """
        Generate Grad-CAM heatmap for a specific class
        
        Args:
            input_tensor: Input image tensor [1, 3, H, W]
            class_idx: Target class index
            task: 'pattern' or 'root_cause'
        
        Returns:
            Heatmap as numpy array [H, W]
        """
        # Forward pass
        self.model.zero_grad()
        pattern_logits, root_cause_logits = self.model(input_tensor)
        
        # Select target logits
        if task == 'pattern':
            target_logits = pattern_logits
        else:
            target_logits = root_cause_logits
        
        # Backward pass for target class
        target_logits[0, class_idx].backward()
        
        # Get gradients and activations
        gradients = self.gradients  # [1, C, H', W']
        activations = self.activations  # [1, C, H', W']
        
        # Global average pooling of gradients
        weights = torch.mean(gradients, dim=(2, 3), keepdim=True)  # [1, C, 1, 1]
        
        # Weighted combination of activation maps
        cam = torch.sum(weights * activations, dim=1, keepdim=True)  # [1, 1, H', W']
        
        # Apply ReLU (only positive contributions)
        cam = F.relu(cam)
        
        # Upsample to input size
        cam = F.interpolate(
            cam,
            size=input_tensor.shape[2:],
            mode='bilinear',
            align_corners=False
        )
        
        # Normalize to [0, 1]
        cam = cam.squeeze().cpu().numpy()
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        
        return cam
    
    def generate_overlay(
        self,
        image_path: str,
        class_idx: int,
        task: str = 'pattern',
        colormap: int = cv2.COLORMAP_JET,
        alpha: float = 0.5
    ) -> np.ndarray:
        """
        Generate heatmap overlay on original image
        
        Args:
            image_path: Path to wafer map image
            class_idx: Target class index
            task: 'pattern' or 'root_cause'
            colormap: OpenCV colormap (default: COLORMAP_JET)
            alpha: Overlay transparency (default: 0.5)
        
        Returns:
            Overlay image as numpy array [H, W, 3]
        """
        # Load and preprocess image
        preprocessor = WaferPreprocessor(target_size=(224, 224))
        input_tensor = preprocessor.preprocess_image(image_path)
        input_tensor = input_tensor.unsqueeze(0).to(next(self.model.parameters()).device)
        
        # Generate heatmap
        heatmap = self.generate_heatmap(input_tensor, class_idx, task)
        
        # Load original image
        original_image = Image.open(image_path).convert('RGB')
        original_image = original_image.resize((224, 224))
        original_image = np.array(original_image)
        
        # Apply colormap to heatmap
        heatmap_colored = cv2.applyColorMap(
            (heatmap * 255).astype(np.uint8),
            colormap
        )
        heatmap_colored = cv2.cvtColor(heatmap_colored, cv2.COLOR_BGR2RGB)
        
        # Blend with original image
        overlay = (alpha * heatmap_colored + (1 - alpha) * original_image).astype(np.uint8)
        
        return overlay


class SHAPExplainer:
    """
    SHAP (SHapley Additive exPlanations) for feature importance
    
    Provides feature-level explanations showing which spatial regions
    and features contribute most to the prediction.
    
    Reference: Lundberg & Lee, "A Unified Approach to Interpreting Model Predictions",
    NeurIPS 2017
    """
    
    def __init__(
        self,
        model: WaferDefectModel,
        background_data: torch.Tensor,
        device: str = 'cuda'
    ):
        """
        Initialize SHAP explainer
        
        Args:
            model: Trained WaferDefectModel
            background_data: Background dataset for SHAP [N, 3, H, W]
            device: Device to use
        """
        self.model = model
        self.model.eval()
        self.device = device
        
        # Create wrapper for SHAP
        def model_wrapper(x):
            """Wrapper that returns pattern predictions"""
            x_tensor = torch.from_numpy(x).float().to(self.device)
            with torch.no_grad():
                pattern_logits, _ = self.model(x_tensor)
                probs = F.softmax(pattern_logits, dim=1)
            return probs.cpu().numpy()
        
        # Initialize DeepExplainer
        self.explainer = shap.DeepExplainer(
            model_wrapper,
            background_data.to(self.device)
        )
    
    def explain(
        self,
        input_tensor: torch.Tensor,
        num_samples: int = 100
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Compute SHAP values for input
        
        Args:
            input_tensor: Input image tensor [1, 3, H, W]
            num_samples: Number of samples for SHAP estimation
        
        Returns:
            Tuple of (shap_values, expected_values)
        """
        # Compute SHAP values
        shap_values = self.explainer.shap_values(
            input_tensor.cpu().numpy(),
            nsamples=num_samples
        )
        
        return shap_values, self.explainer.expected_value
    
    def get_top_features(
        self,
        shap_values: np.ndarray,
        class_idx: int,
        top_k: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Get top-k most important features
        
        Args:
            shap_values: SHAP values from explain()
            class_idx: Target class index
            top_k: Number of top features to return
        
        Returns:
            List of (feature_name, importance) tuples
        """
        # Get SHAP values for target class
        class_shap = shap_values[class_idx][0]  # [3, H, W]
        
        # Compute spatial importance
        spatial_importance = np.abs(class_shap).sum(axis=0)  # [H, W]
        
        # Find top-k spatial locations
        flat_importance = spatial_importance.flatten()
        top_indices = np.argsort(flat_importance)[-top_k:][::-1]
        
        # Convert to (row, col) coordinates
        h, w = spatial_importance.shape
        top_features = []
        
        for idx in top_indices:
            row = idx // w
            col = idx % w
            importance = flat_importance[idx]
            top_features.append((f"Region ({row}, {col})", importance))
        
        return top_features


class SimilarCaseRetriever:
    """
    Retrieve similar wafer cases using feature embeddings
    
    Uses cosine similarity in the embedding space to find
    wafers with similar defect patterns.
    """
    
    def __init__(
        self,
        model: WaferDefectModel,
        embedding_database: Dict[str, np.ndarray],
        device: str = 'cuda'
    ):
        """
        Initialize similar case retriever
        
        Args:
            model: Trained WaferDefectModel
            embedding_database: Dict mapping wafer_id to embedding vector
            device: Device to use
        """
        self.model = model
        self.model.eval()
        self.device = device
        self.embedding_database = embedding_database
        
        # Convert embeddings to matrix for efficient search
        self.wafer_ids = list(embedding_database.keys())
        self.embeddings_matrix = np.vstack([
            embedding_database[wid] for wid in self.wafer_ids
        ])
        
        # Normalize embeddings for cosine similarity
        self.embeddings_matrix = self._normalize(self.embeddings_matrix)
    
    def _normalize(self, vectors: np.ndarray) -> np.ndarray:
        """L2 normalize vectors"""
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        return vectors / (norms + 1e-8)
    
    def extract_embedding(self, input_tensor: torch.Tensor) -> np.ndarray:
        """
        Extract embedding for input wafer
        
        Args:
            input_tensor: Input image tensor [1, 3, H, W]
        
        Returns:
            Embedding vector [256]
        """
        with torch.no_grad():
            embedding = self.model.get_embeddings(input_tensor)
        
        return embedding.cpu().numpy()[0]
    
    def find_similar(
        self,
        query_embedding: np.ndarray,
        top_k: int = 5,
        exclude_wafer_id: Optional[str] = None
    ) -> List[Dict]:
        """
        Find top-k most similar wafers
        
        Args:
            query_embedding: Query embedding vector
            top_k: Number of similar cases to return
            exclude_wafer_id: Wafer ID to exclude from results
        
        Returns:
            List of similar case dictionaries with wafer_id and similarity
        """
        # Normalize query
        query_normalized = self._normalize(query_embedding.reshape(1, -1))
        
        # Compute cosine similarities
        similarities = np.dot(self.embeddings_matrix, query_normalized.T).flatten()
        
        # Get top-k indices
        top_indices = np.argsort(similarities)[-top_k-1:][::-1]
        
        # Build results
        results = []
        for idx in top_indices:
            wafer_id = self.wafer_ids[idx]
            
            # Skip excluded wafer
            if wafer_id == exclude_wafer_id:
                continue
            
            similarity = float(similarities[idx])
            
            results.append({
                'wafer_id': wafer_id,
                'similarity': similarity,
                'distance': 1.0 - similarity
            })
            
            if len(results) >= top_k:
                break
        
        return results
    
    def find_similar_by_wafer_id(
        self,
        wafer_id: str,
        top_k: int = 5
    ) -> List[Dict]:
        """
        Find similar wafers given a wafer ID
        
        Args:
            wafer_id: Query wafer ID
            top_k: Number of similar cases to return
        
        Returns:
            List of similar case dictionaries
        """
        if wafer_id not in self.embedding_database:
            raise ValueError(f"Wafer {wafer_id} not found in embedding database")
        
        query_embedding = self.embedding_database[wafer_id]
        
        return self.find_similar(
            query_embedding,
            top_k=top_k,
            exclude_wafer_id=wafer_id
        )
    
    def add_to_database(self, wafer_id: str, embedding: np.ndarray):
        """
        Add new wafer embedding to database
        
        Args:
            wafer_id: Wafer ID
            embedding: Embedding vector
        """
        self.embedding_database[wafer_id] = embedding
        self.wafer_ids.append(wafer_id)
        
        # Update embeddings matrix
        normalized_embedding = self._normalize(embedding.reshape(1, -1))
        self.embeddings_matrix = np.vstack([
            self.embeddings_matrix,
            normalized_embedding
        ])


def build_embedding_database(
    model: WaferDefectModel,
    wafer_data: List[Dict],
    device: str = 'cuda'
) -> Dict[str, np.ndarray]:
    """
    Build embedding database for all wafers
    
    Args:
        model: Trained WaferDefectModel
        wafer_data: List of wafer dictionaries with 'wafer_id' and 'image_path'
        device: Device to use
    
    Returns:
        Dictionary mapping wafer_id to embedding vector
    """
    model.eval()
    preprocessor = WaferPreprocessor(target_size=(224, 224))
    
    embedding_db = {}
    
    print(f"Building embedding database for {len(wafer_data)} wafers...")
    
    for i, wafer in enumerate(wafer_data):
        wafer_id = wafer['wafer_id']
        image_path = wafer['image_path']
        
        try:
            # Preprocess image
            input_tensor = preprocessor.preprocess_image(image_path)
            input_tensor = input_tensor.unsqueeze(0).to(device)
            
            # Extract embedding
            with torch.no_grad():
                embedding = model.get_embeddings(input_tensor)
            
            embedding_db[wafer_id] = embedding.cpu().numpy()[0]
            
            if (i + 1) % 100 == 0:
                print(f"  Processed {i + 1}/{len(wafer_data)} wafers")
        
        except Exception as e:
            print(f"  Error processing {wafer_id}: {e}")
            continue
    
    print(f"Embedding database built: {len(embedding_db)} wafers")
    
    return embedding_db
