"""
Multi-task learning model for wafer defect pattern recognition

This module implements the core AI model architecture described in AI_MODEL_ARCHITECTURE.md
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from efficientnet_pytorch import EfficientNet
    EFFICIENTNET_AVAILABLE = True
except ImportError:
    EFFICIENTNET_AVAILABLE = False
    print("Warning: efficientnet_pytorch not installed. Install with: pip install efficientnet-pytorch")


class WaferDefectModel(nn.Module):
    """
    Multi-task learning model for wafer defect pattern recognition
    
    Architecture:
    - Backbone: EfficientNet-B3 (pretrained on ImageNet)
    - Shared Head: 2-layer MLP with dropout
    - Task-specific Heads: Pattern classification (10 classes) + Root cause (8 classes)
    
    Args:
        num_pattern_classes (int): Number of defect pattern classes (default: 10)
        num_root_cause_classes (int): Number of root cause classes (default: 8)
        dropout (float): Dropout rate (default: 0.3)
        pretrained (bool): Use pretrained EfficientNet weights (default: True)
    """
    
    def __init__(self, 
                 num_pattern_classes=10, 
                 num_root_cause_classes=8,
                 dropout=0.3,
                 pretrained=True):
        super(WaferDefectModel, self).__init__()
        
        if not EFFICIENTNET_AVAILABLE:
            raise ImportError(
                "efficientnet_pytorch is required. "
                "Install with: pip install efficientnet-pytorch"
            )
        
        # Backbone: EfficientNet-B3
        if pretrained:
            self.backbone = EfficientNet.from_pretrained('efficientnet-b3')
        else:
            self.backbone = EfficientNet.from_name('efficientnet-b3')
        
        # Remove final classification layer
        self.backbone._fc = nn.Identity()
        
        # Feature dimension from EfficientNet-B3
        feature_dim = 1536
        
        # Shared representation head
        self.shared_head = nn.Sequential(
            nn.Linear(feature_dim, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout * 0.7)
        )
        
        # Pattern classification head
        self.pattern_classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout * 0.5),
            nn.Linear(128, num_pattern_classes)
        )
        
        # Root cause classification head
        self.root_cause_classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout * 0.5),
            nn.Linear(128, num_root_cause_classes)
        )
        
        self.num_pattern_classes = num_pattern_classes
        self.num_root_cause_classes = num_root_cause_classes
    
    def forward(self, x):
        """
        Forward pass
        
        Args:
            x (torch.Tensor): Input images [batch_size, 3, 224, 224]
        
        Returns:
            tuple: (pattern_logits, root_cause_logits)
                - pattern_logits: [batch_size, num_pattern_classes]
                - root_cause_logits: [batch_size, num_root_cause_classes]
        """
        # Extract features from backbone
        features = self.backbone(x)
        
        # Shared representation
        shared = self.shared_head(features)
        
        # Task-specific predictions
        pattern_logits = self.pattern_classifier(shared)
        root_cause_logits = self.root_cause_classifier(shared)
        
        return pattern_logits, root_cause_logits
    
    def get_embeddings(self, x):
        """
        Extract feature embeddings (for similarity search)
        
        Args:
            x (torch.Tensor): Input images [batch_size, 3, 224, 224]
        
        Returns:
            torch.Tensor: Feature embeddings [batch_size, 256]
        """
        features = self.backbone(x)
        embeddings = self.shared_head(features)
        return embeddings


# Pattern class names (10 classes)
PATTERN_CLASSES = [
    'Center',      # Defects concentrated at wafer center
    'Donut',       # Ring-shaped defect pattern
    'Edge-Ring',   # Defects along wafer edge
    'Edge-Loc',    # Localized edge defects
    'Loc',         # Localized cluster anywhere
    'Random',      # Randomly distributed defects
    'Scratch',     # Linear scratch patterns
    'Near-Full',   # Nearly complete wafer coverage
    'None',        # No significant defects
    'Mixed'        # Multiple pattern types
]

# Root cause class names (8 classes)
ROOT_CAUSE_CLASSES = [
    'Lithography Issues',      # Exposure, focus, alignment
    'CVD Process Variation',   # Chemical vapor deposition
    'CMP Non-uniformity',      # Chemical mechanical polishing
    'Etch Process Drift',      # Etching parameter variations
    'Particle Contamination',  # Foreign material
    'Equipment Malfunction',   # Tool-related defects
    'Material Defects',        # Substrate or material issues
    'Unknown'                  # Cannot determine root cause
]
