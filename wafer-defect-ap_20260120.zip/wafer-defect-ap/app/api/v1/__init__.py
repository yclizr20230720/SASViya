"""
API v1 Blueprint
"""
from flask import Blueprint

# Create API v1 blueprint
api_v1_bp = Blueprint('api_v1', __name__)

# Import routes
from app.api.v1 import health, wafer, training, inference, analytics, gan
