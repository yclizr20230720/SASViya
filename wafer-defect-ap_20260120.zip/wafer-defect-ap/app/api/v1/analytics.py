"""
Analytics API endpoints for wafer defect pattern recognition

Implements Task 7 from tasks_backend.md
"""
from flask import request, jsonify, current_app
from app.api.v1 import api_v1_bp
from app.utils.json_storage import JSONStorage
from datetime import datetime, timedelta
from collections import defaultdict, Counter
import os
import psutil
import torch


@api_v1_bp.route('/analytics/dashboard', methods=['GET'])
def get_dashboard_analytics():
    """
    Get dashboard analytics with KPIs and insights
    
    Query Parameters:
        - date_range: Number of days to include (default: 30)
        - lot_id: Filter by lot ID (optional)
    
    Returns:
        JSON response with dashboard analytics
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get query parameters
        date_range = int(request.args.get('date_range', 30))
        lot_id = request.args.get('lot_id')
        
        # Calculate date filter
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=date_range)
        start_date_str = start_date.isoformat()
        
        # Get all data
        wafers = storage.find('wafers.json')
        inferences = storage.find('inference_results.json')
        models = storage.find('models.json')
        
        # Apply filters
        if lot_id:
            wafers = [w for w in wafers if w.get('lot_id') == lot_id]
        
        # Filter by date range
        filtered_inferences = [
            i for i in inferences
            if i.get('timestamp', '') >= start_date_str
        ]
        
        if lot_id:
            wafer_ids = [w.get('wafer_id') for w in wafers]
            filtered_inferences = [
                i for i in filtered_inferences
                if i.get('wafer_id') in wafer_ids
            ]
        
        # Calculate KPIs
        total_wafers = len(wafers)
        total_inferences = len(filtered_inferences)
        
        # Defect rate (wafers with defects / total wafers)
        wafers_with_defects = len([
            w for w in wafers
            if w.get('defect_count', 0) > 0
        ])
        defect_rate = wafers_with_defects / total_wafers if total_wafers > 0 else 0
        
        # Model accuracy (from latest model)
        model_accuracy = 0.0
        if models and len(models) > 0:
            latest_model = sorted(
                models,
                key=lambda x: x.get('created_at', ''),
                reverse=True
            )[0]
            model_accuracy = latest_model.get('performance', {}).get('pattern_accuracy', 0.0)
        
        # Average confidence
        confidences = [i.get('pattern_confidence', 0) for i in filtered_inferences]
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
        
        # Pattern distribution
        pattern_counts = Counter([
            i.get('pattern', 'Unknown')
            for i in filtered_inferences
        ])
        
        pattern_distribution = [
            {
                'pattern': pattern,
                'count': count,
                'percentage': round((count / total_inferences * 100), 2) if total_inferences > 0 else 0
            }
            for pattern, count in pattern_counts.most_common()
        ]
        
        # Recent activity (last 10 inferences)
        recent_inferences = sorted(
            filtered_inferences,
            key=lambda x: x.get('timestamp', ''),
            reverse=True
        )[:10]
        
        recent_activity = [
            {
                'wafer_id': inf.get('wafer_id'),
                'timestamp': inf.get('timestamp'),
                'pattern': inf.get('pattern'),  # Changed from pattern_class to pattern
                'confidence': round(inf.get('pattern_confidence', 0), 4)
            }
            for inf in recent_inferences
        ]
        
        # System health
        system_health = get_system_health()
        
        return jsonify({
            'status': 'success',
            'date_range_days': date_range,
            'kpis': {
                'total_wafers': total_wafers,
                'total_inferences': total_inferences,
                'defect_rate': round(defect_rate, 4),
                'model_accuracy': round(model_accuracy, 4),
                'avg_confidence': round(avg_confidence, 4)
            },
            'pattern_distribution': pattern_distribution,
            'recent_activity': recent_activity,
            'system_health': system_health
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Dashboard analytics error: {str(e)}")
        return jsonify({'error': f'Failed to get dashboard analytics: {str(e)}'}), 500



@api_v1_bp.route('/analytics/patterns', methods=['GET'])
def get_pattern_analytics():
    """
    Get pattern distribution analytics over time
    
    Query Parameters:
        - date_range: Number of days to include (default: 30)
        - equipment_id: Filter by equipment (optional)
        - granularity: Time granularity (day, week, month) (default: day)
    
    Returns:
        JSON response with pattern analytics
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get query parameters
        date_range = int(request.args.get('date_range', 30))
        equipment_id = request.args.get('equipment_id')
        granularity = request.args.get('granularity', 'day')
        
        # Calculate date filter
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=date_range)
        start_date_str = start_date.isoformat()
        
        # Get data
        wafers = storage.find('wafers.json')
        inferences = storage.find('inference_results.json')
        
        # Filter by equipment
        if equipment_id:
            wafer_ids = [
                w.get('wafer_id') for w in wafers
                if w.get('tool_id') == equipment_id
            ]
            inferences = [
                i for i in inferences
                if i.get('wafer_id') in wafer_ids
            ]
        
        # Filter by date
        inferences = [
            i for i in inferences
            if i.get('timestamp', '') >= start_date_str
        ]
        
        # Pattern distribution over time
        time_series = defaultdict(lambda: defaultdict(int))
        
        for inf in inferences:
            timestamp = inf.get('timestamp', '')
            if not timestamp:
                continue
            
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            
            # Determine time bucket based on granularity
            if granularity == 'day':
                time_key = dt.strftime('%Y-%m-%d')
            elif granularity == 'week':
                time_key = dt.strftime('%Y-W%W')
            elif granularity == 'month':
                time_key = dt.strftime('%Y-%m')
            else:
                time_key = dt.strftime('%Y-%m-%d')
            
            pattern = inf.get('pattern', 'Unknown')
            time_series[time_key][pattern] += 1
        
        # Convert to list format
        pattern_over_time = []
        for time_key in sorted(time_series.keys()):
            entry = {'date': time_key}
            entry.update(time_series[time_key])
            pattern_over_time.append(entry)
        
        # Pattern frequency by equipment
        pattern_by_equipment = defaultdict(lambda: defaultdict(int))
        
        for inf in inferences:
            wafer_id = inf.get('wafer_id')
            pattern = inf.get('pattern', 'Unknown')
            
            # Find wafer equipment
            wafer = next((w for w in wafers if w.get('wafer_id') == wafer_id), None)
            if wafer:
                equip = wafer.get('tool_id', 'Unknown')
                pattern_by_equipment[equip][pattern] += 1
        
        equipment_patterns = [
            {
                'equipment_id': equip,
                'patterns': dict(patterns)
            }
            for equip, patterns in pattern_by_equipment.items()
        ]
        
        # Overall pattern distribution
        pattern_counts = Counter([
            i.get('pattern', 'Unknown')
            for i in inferences
        ])
        
        pattern_distribution = [
            {
                'pattern': pattern,
                'count': count,
                'percentage': round((count / len(inferences) * 100), 2) if inferences else 0
            }
            for pattern, count in pattern_counts.most_common()
        ]
        
        return jsonify({
            'status': 'success',
            'date_range_days': date_range,
            'granularity': granularity,
            'total_inferences': len(inferences),
            'pattern_distribution': pattern_distribution,
            'pattern_over_time': pattern_over_time,
            'pattern_by_equipment': equipment_patterns
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Pattern analytics error: {str(e)}")
        return jsonify({'error': f'Failed to get pattern analytics: {str(e)}'}), 500



@api_v1_bp.route('/analytics/yield', methods=['GET'])
def get_yield_analytics():
    """
    Get yield analysis and trends
    
    Query Parameters:
        - date_range: Number of days to include (default: 30)
        - lot_id: Filter by lot ID (optional)
    
    Returns:
        JSON response with yield analytics
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get query parameters
        date_range = int(request.args.get('date_range', 30))
        lot_id = request.args.get('lot_id')
        
        # Calculate date filter
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=date_range)
        start_date_str = start_date.isoformat()
        
        # Get data
        wafers = storage.find('wafers.json')
        inferences = storage.find('inference_results.json')
        
        # Filter by date
        wafers = [
            w for w in wafers
            if w.get('upload_time', '') >= start_date_str
        ]
        
        # Filter by lot_id
        if lot_id:
            wafers = [w for w in wafers if w.get('lot_id') == lot_id]
        
        # Calculate yield by lot
        lot_yields = defaultdict(lambda: {'total': 0, 'good': 0, 'defective': 0})
        
        for wafer in wafers:
            lot = wafer.get('lot_id', 'Unknown')
            lot_yields[lot]['total'] += 1
            
            # Consider wafer good if defect_count is 0 or pattern is 'None'
            defect_count = wafer.get('defect_count', 0)
            
            # Check inference result
            wafer_id = wafer.get('wafer_id')
            inf = next((i for i in inferences if i.get('wafer_id') == wafer_id), None)
            
            if inf:
                pattern = inf.get('pattern', '')
                if pattern == 'None' or defect_count == 0:
                    lot_yields[lot]['good'] += 1
                else:
                    lot_yields[lot]['defective'] += 1
            else:
                # No inference - use defect count
                if defect_count == 0:
                    lot_yields[lot]['good'] += 1
                else:
                    lot_yields[lot]['defective'] += 1
        
        # Calculate yield percentages
        yield_by_lot = []
        for lot, counts in lot_yields.items():
            yield_pct = (counts['good'] / counts['total'] * 100) if counts['total'] > 0 else 0
            yield_by_lot.append({
                'lot_id': lot,
                'total_wafers': counts['total'],
                'good_wafers': counts['good'],
                'defective_wafers': counts['defective'],
                'yield_percentage': round(yield_pct, 2)
            })
        
        # Sort by yield percentage
        yield_by_lot.sort(key=lambda x: x['yield_percentage'], reverse=True)
        
        # Yield trends over time (daily)
        daily_yields = defaultdict(lambda: {'total': 0, 'good': 0})
        
        for wafer in wafers:
            timestamp = wafer.get('upload_time', '')
            if not timestamp:
                continue
            
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            date_key = dt.strftime('%Y-%m-%d')
            
            daily_yields[date_key]['total'] += 1
            
            defect_count = wafer.get('defect_count', 0)
            if defect_count == 0:
                daily_yields[date_key]['good'] += 1
        
        yield_trends = []
        for date_key in sorted(daily_yields.keys()):
            counts = daily_yields[date_key]
            yield_pct = (counts['good'] / counts['total'] * 100) if counts['total'] > 0 else 0
            yield_trends.append({
                'date': date_key,
                'total_wafers': counts['total'],
                'good_wafers': counts['good'],
                'yield_percentage': round(yield_pct, 2)
            })
        
        # Defect impact on yield (pattern distribution for defective wafers)
        defective_wafers = [w for w in wafers if w.get('defect_count', 0) > 0]
        defective_wafer_ids = [w.get('wafer_id') for w in defective_wafers]
        
        defect_patterns = Counter([
            i.get('pattern', 'Unknown')
            for i in inferences
            if i.get('wafer_id') in defective_wafer_ids
        ])
        
        defect_impact = [
            {
                'pattern': pattern,
                'count': count,
                'percentage': round((count / len(defective_wafers) * 100), 2) if defective_wafers else 0
            }
            for pattern, count in defect_patterns.most_common()
        ]
        
        # Overall statistics
        total_wafers = len(wafers)
        good_wafers = len([w for w in wafers if w.get('defect_count', 0) == 0])
        overall_yield = (good_wafers / total_wafers * 100) if total_wafers > 0 else 0
        
        return jsonify({
            'status': 'success',
            'date_range_days': date_range,
            'overall_statistics': {
                'total_wafers': total_wafers,
                'good_wafers': good_wafers,
                'defective_wafers': total_wafers - good_wafers,
                'overall_yield_percentage': round(overall_yield, 2)
            },
            'yield_by_lot': yield_by_lot,
            'yield_trends': yield_trends,
            'defect_impact': defect_impact
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Yield analytics error: {str(e)}")
        return jsonify({'error': f'Failed to get yield analytics: {str(e)}'}), 500



@api_v1_bp.route('/analytics/equipment', methods=['GET'])
def get_equipment_analytics():
    """
    Get equipment correlation analysis
    
    Query Parameters:
        - date_range: Number of days to include (default: 30)
    
    Returns:
        JSON response with equipment analytics
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get query parameters
        date_range = int(request.args.get('date_range', 30))
        
        # Calculate date filter
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=date_range)
        start_date_str = start_date.isoformat()
        
        # Get data
        wafers = storage.find('wafers.json')
        inferences = storage.find('inference_results.json')
        
        # Filter by date
        wafers = [
            w for w in wafers
            if w.get('upload_time', '') >= start_date_str
        ]
        
        # Equipment performance metrics
        equipment_metrics = defaultdict(lambda: {
            'total_wafers': 0,
            'defective_wafers': 0,
            'patterns': defaultdict(int),
            'avg_defect_count': 0,
            'total_defects': 0
        })
        
        for wafer in wafers:
            equip = wafer.get('tool_id', 'Unknown')
            defect_count = wafer.get('defect_count', 0)
            
            equipment_metrics[equip]['total_wafers'] += 1
            equipment_metrics[equip]['total_defects'] += defect_count
            
            if defect_count > 0:
                equipment_metrics[equip]['defective_wafers'] += 1
            
            # Get pattern from inference
            wafer_id = wafer.get('wafer_id')
            inf = next((i for i in inferences if i.get('wafer_id') == wafer_id), None)
            if inf:
                pattern = inf.get('pattern', 'Unknown')
                equipment_metrics[equip]['patterns'][pattern] += 1
        
        # Calculate averages and format response
        equipment_performance = []
        for equip, metrics in equipment_metrics.items():
            total = metrics['total_wafers']
            defective = metrics['defective_wafers']
            
            defect_rate = (defective / total * 100) if total > 0 else 0
            avg_defects = metrics['total_defects'] / total if total > 0 else 0
            
            # Most common pattern
            most_common_pattern = 'None'
            if metrics['patterns']:
                most_common_pattern = max(
                    metrics['patterns'].items(),
                    key=lambda x: x[1]
                )[0]
            
            equipment_performance.append({
                'equipment_id': equip,
                'total_wafers': total,
                'defective_wafers': defective,
                'defect_rate_percentage': round(defect_rate, 2),
                'avg_defect_count': round(avg_defects, 2),
                'most_common_pattern': most_common_pattern,
                'pattern_distribution': dict(metrics['patterns'])
            })
        
        # Sort by defect rate (worst first)
        equipment_performance.sort(key=lambda x: x['defect_rate_percentage'], reverse=True)
        
        # Equipment correlation (which equipment has similar defect patterns)
        equipment_correlation = []
        equipment_list = list(equipment_metrics.keys())
        
        for i, equip1 in enumerate(equipment_list):
            for equip2 in equipment_list[i+1:]:
                # Calculate pattern similarity (Jaccard similarity)
                patterns1 = set(equipment_metrics[equip1]['patterns'].keys())
                patterns2 = set(equipment_metrics[equip2]['patterns'].keys())
                
                if patterns1 and patterns2:
                    intersection = len(patterns1 & patterns2)
                    union = len(patterns1 | patterns2)
                    similarity = intersection / union if union > 0 else 0
                    
                    if similarity > 0.3:  # Only include if similarity > 30%
                        equipment_correlation.append({
                            'equipment_1': equip1,
                            'equipment_2': equip2,
                            'similarity_score': round(similarity, 4),
                            'common_patterns': list(patterns1 & patterns2)
                        })
        
        # Sort by similarity
        equipment_correlation.sort(key=lambda x: x['similarity_score'], reverse=True)
        
        return jsonify({
            'status': 'success',
            'date_range_days': date_range,
            'equipment_performance': equipment_performance,
            'equipment_correlation': equipment_correlation[:10]  # Top 10 correlations
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Equipment analytics error: {str(e)}")
        return jsonify({'error': f'Failed to get equipment analytics: {str(e)}'}), 500



@api_v1_bp.route('/analytics/temporal', methods=['GET'])
def get_temporal_analytics():
    """
    Get time-series defect trends and anomaly detection
    
    Query Parameters:
        - date_range: Number of days to include (default: 90)
        - granularity: Time granularity (day, week, month) (default: day)
    
    Returns:
        JSON response with temporal analytics
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get query parameters
        date_range = int(request.args.get('date_range', 90))
        granularity = request.args.get('granularity', 'day')
        
        # Calculate date filter
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=date_range)
        start_date_str = start_date.isoformat()
        
        # Get data
        wafers = storage.find('wafers.json')
        inferences = storage.find('inference_results.json')
        
        # Filter by date
        wafers = [
            w for w in wafers
            if w.get('upload_time', '') >= start_date_str
        ]
        
        # Time-series defect trends
        time_series = defaultdict(lambda: {
            'total_wafers': 0,
            'defective_wafers': 0,
            'total_defects': 0,
            'patterns': defaultdict(int)
        })
        
        for wafer in wafers:
            timestamp = wafer.get('upload_time', '')
            if not timestamp:
                continue
            
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            
            # Determine time bucket
            if granularity == 'day':
                time_key = dt.strftime('%Y-%m-%d')
            elif granularity == 'week':
                time_key = dt.strftime('%Y-W%W')
            elif granularity == 'month':
                time_key = dt.strftime('%Y-%m')
            else:
                time_key = dt.strftime('%Y-%m-%d')
            
            defect_count = wafer.get('defect_count', 0)
            
            time_series[time_key]['total_wafers'] += 1
            time_series[time_key]['total_defects'] += defect_count
            
            if defect_count > 0:
                time_series[time_key]['defective_wafers'] += 1
            
            # Get pattern
            wafer_id = wafer.get('wafer_id')
            inf = next((i for i in inferences if i.get('wafer_id') == wafer_id), None)
            if inf:
                pattern = inf.get('pattern', 'Unknown')
                time_series[time_key]['patterns'][pattern] += 1
        
        # Convert to list and calculate rates
        defect_trends = []
        for time_key in sorted(time_series.keys()):
            data = time_series[time_key]
            total = data['total_wafers']
            
            defect_rate = (data['defective_wafers'] / total * 100) if total > 0 else 0
            avg_defects = data['total_defects'] / total if total > 0 else 0
            
            defect_trends.append({
                'date': time_key,
                'total_wafers': total,
                'defective_wafers': data['defective_wafers'],
                'defect_rate_percentage': round(defect_rate, 2),
                'avg_defect_count': round(avg_defects, 2),
                'total_defects': data['total_defects']
            })
        
        # Simple anomaly detection (values > 2 std deviations from mean)
        if len(defect_trends) > 3:
            defect_rates = [d['defect_rate_percentage'] for d in defect_trends]
            mean_rate = sum(defect_rates) / len(defect_rates)
            
            # Calculate standard deviation
            variance = sum((x - mean_rate) ** 2 for x in defect_rates) / len(defect_rates)
            std_dev = variance ** 0.5
            
            threshold = mean_rate + (2 * std_dev)
            
            anomalies = [
                {
                    'date': trend['date'],
                    'defect_rate': trend['defect_rate_percentage'],
                    'deviation': round(trend['defect_rate_percentage'] - mean_rate, 2),
                    'severity': 'high' if trend['defect_rate_percentage'] > threshold else 'medium'
                }
                for trend in defect_trends
                if trend['defect_rate_percentage'] > threshold
            ]
        else:
            anomalies = []
            mean_rate = 0
            std_dev = 0
        
        # Seasonal patterns (day of week analysis)
        day_of_week_stats = defaultdict(lambda: {'total': 0, 'defective': 0})
        
        for wafer in wafers:
            timestamp = wafer.get('upload_time', '')
            if not timestamp:
                continue
            
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            day_name = dt.strftime('%A')
            
            day_of_week_stats[day_name]['total'] += 1
            if wafer.get('defect_count', 0) > 0:
                day_of_week_stats[day_name]['defective'] += 1
        
        seasonal_patterns = []
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        
        for day in day_order:
            if day in day_of_week_stats:
                stats = day_of_week_stats[day]
                defect_rate = (stats['defective'] / stats['total'] * 100) if stats['total'] > 0 else 0
                seasonal_patterns.append({
                    'day_of_week': day,
                    'total_wafers': stats['total'],
                    'defect_rate_percentage': round(defect_rate, 2)
                })
        
        return jsonify({
            'status': 'success',
            'date_range_days': date_range,
            'granularity': granularity,
            'defect_trends': defect_trends,
            'statistics': {
                'mean_defect_rate': round(mean_rate, 2),
                'std_deviation': round(std_dev, 2),
                'anomaly_threshold': round(mean_rate + (2 * std_dev), 2) if std_dev > 0 else 0
            },
            'anomalies': anomalies,
            'seasonal_patterns': seasonal_patterns
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Temporal analytics error: {str(e)}")
        return jsonify({'error': f'Failed to get temporal analytics: {str(e)}'}), 500


def get_system_health():
    """
    Get system health metrics
    
    Returns:
        Dictionary with system health information
    """
    try:
        # API status
        api_status = 'healthy'
        
        # Model status
        model_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            'checkpoints',
            'best_model.pth'
        )
        model_status = 'active' if os.path.exists(model_path) else 'not_found'
        
        # GPU utilization
        gpu_utilization = 0.0
        gpu_available = torch.cuda.is_available()
        
        if gpu_available:
            try:
                # Get GPU memory usage as proxy for utilization
                gpu_memory_allocated = torch.cuda.memory_allocated(0)
                gpu_memory_total = torch.cuda.get_device_properties(0).total_memory
                gpu_utilization = gpu_memory_allocated / gpu_memory_total
            except:
                gpu_utilization = 0.0
        
        # CPU and memory
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
        memory_percent = memory.percent / 100
        
        # Disk usage
        disk = psutil.disk_usage('/')
        disk_percent = disk.percent / 100
        
        return {
            'api_status': api_status,
            'model_status': model_status,
            'gpu_available': gpu_available,
            'gpu_utilization': round(gpu_utilization, 4),
            'cpu_utilization': round(cpu_percent / 100, 4),
            'memory_utilization': round(memory_percent, 4),
            'disk_utilization': round(disk_percent, 4)
        }
    except Exception as e:
        return {
            'api_status': 'healthy',
            'model_status': 'unknown',
            'error': str(e)
        }
