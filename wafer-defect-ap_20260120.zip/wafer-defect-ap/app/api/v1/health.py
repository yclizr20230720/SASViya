"""
Health check and system status endpoints
"""
from flask import jsonify, current_app
from app.api.v1 import api_v1_bp
import psutil
import os


@api_v1_bp.route('/health', methods=['GET'])
def health_check():
    """
    Health check endpoint
    
    Returns:
        JSON response with system health status
    """
    # Get system metrics
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    return jsonify({
        'status': 'healthy',
        'version': current_app.config['API_VERSION'],
        'system': {
            'cpu_percent': cpu_percent,
            'memory_percent': memory.percent,
            'disk_percent': disk.percent
        },
        'storage': {
            'upload_folder': os.path.exists(current_app.config['UPLOAD_FOLDER']),
            'model_folder': os.path.exists(current_app.config['MODEL_FOLDER']),
            'temp_folder': os.path.exists(current_app.config['TEMP_FOLDER']),
            'metadata_folder': os.path.exists(current_app.config['METADATA_FOLDER'])
        }
    }), 200


@api_v1_bp.route('/status', methods=['GET'])
def system_status():
    """
    Detailed system status endpoint
    
    Returns:
        JSON response with detailed system information
    """
    return jsonify({
        'api_version': current_app.config['API_VERSION'],
        'environment': os.getenv('FLASK_ENV', 'development'),
        'debug_mode': current_app.debug,
        'upload_folder': current_app.config['UPLOAD_FOLDER'],
        'max_upload_size_mb': current_app.config['MAX_CONTENT_LENGTH'] / (1024 * 1024),
        'default_model_version': current_app.config['DEFAULT_MODEL_VERSION']
    }), 200
