"""
GAN API Endpoints for Synthetic Data Generation

Provides endpoints for:
- Training GAN
- Generating synthetic wafer maps
- Validating synthetic quality
- Managing GAN models
"""
from flask import request, jsonify, current_app, send_file
from app.api.v1 import api_v1_bp
from app.utils.json_storage import JSONStorage
from datetime import datetime
import os
import json
import uuid
from pathlib import Path
import threading


# Global GAN training status
gan_training_status = {
    'is_training': False,
    'job_id': None,
    'progress': 0,
    'current_epoch': 0,
    'total_epochs': 0,
    'metrics': {},
    'error': None
}


@api_v1_bp.route('/gan/train', methods=['POST'])
def start_gan_training():
    """
    Start GAN training
    
    Request Body:
    {
        "epochs": 100,
        "batch_size": 32,
        "n_critic": 5,
        "lambda_gp": 10.0,
        "learning_rate": 0.0001,
        "data_split": "all",
        "checkpoint_dir": "checkpoints/gan"
    }
    
    Returns:
        JSON response with job_id and status
    """
    try:
        global gan_training_status
        
        # Check if already training
        if gan_training_status['is_training']:
            return jsonify({
                'error': 'GAN training already in progress',
                'job_id': gan_training_status['job_id']
            }), 400
        
        # Get request data
        data = request.get_json()
        
        # Validate required fields
        epochs = data.get('epochs', 100)
        batch_size = data.get('batch_size', 32)
        n_critic = data.get('n_critic', 5)
        lambda_gp = data.get('lambda_gp', 10.0)
        learning_rate = data.get('learning_rate', 0.0001)
        data_split = data.get('data_split', 'all')
        checkpoint_dir = data.get('checkpoint_dir', 'checkpoints/gan')
        
        # Generate job ID
        job_id = str(uuid.uuid4())
        
        # Create job record
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        job_record = {
            'id': job_id,
            'type': 'gan_training',
            'status': 'queued',
            'created_at': datetime.now().isoformat(),
            'config': {
                'epochs': epochs,
                'batch_size': batch_size,
                'n_critic': n_critic,
                'lambda_gp': lambda_gp,
                'learning_rate': learning_rate,
                'data_split': data_split,
                'checkpoint_dir': checkpoint_dir
            },
            'progress': 0,
            'metrics': {}
        }
        
        # Save job record
        gan_jobs = storage.read('gan_jobs.json', default=[])
        gan_jobs.append(job_record)
        storage.write('gan_jobs.json', gan_jobs)
        
        # Update global status
        gan_training_status = {
            'is_training': True,
            'job_id': job_id,
            'progress': 0,
            'current_epoch': 0,
            'total_epochs': epochs,
            'metrics': {},
            'error': None
        }
        
        # Start training in background thread
        training_thread = threading.Thread(
            target=_run_gan_training,
            args=(job_id, job_record['config'])
        )
        training_thread.daemon = True
        training_thread.start()
        
        return jsonify({
            'status': 'success',
            'message': 'GAN training started',
            'job_id': job_id,
            'estimated_duration_minutes': epochs * 2  # Rough estimate
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"GAN training start error: {str(e)}")
        return jsonify({'error': f'Failed to start GAN training: {str(e)}'}), 500


@api_v1_bp.route('/gan/status/<job_id>', methods=['GET'])
def get_gan_training_status(job_id):
    """
    Get GAN training status
    
    Returns:
        JSON response with training progress and metrics
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Find job
        gan_jobs = storage.read('gan_jobs.json', default=[])
        job = next((j for j in gan_jobs if j['id'] == job_id), None)
        
        if not job:
            return jsonify({'error': 'Job not found'}), 404
        
        # Get current status from global variable if training
        if gan_training_status['job_id'] == job_id and gan_training_status['is_training']:
            job['status'] = 'training'
            job['progress'] = gan_training_status['progress']
            job['current_epoch'] = gan_training_status['current_epoch']
            job['metrics'] = gan_training_status['metrics']
            if gan_training_status['error']:
                job['error'] = gan_training_status['error']
        
        return jsonify({
            'status': 'success',
            'job': job
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"GAN status error: {str(e)}")
        return jsonify({'error': f'Failed to get GAN status: {str(e)}'}), 500


@api_v1_bp.route('/gan/generate', methods=['POST'])
def generate_synthetic_wafers():
    """
    Generate synthetic wafer maps
    
    Request Body:
    {
        "num_samples": 100,
        "pattern": "Center",  // optional
        "defect_density": 0.5,  // optional
        "checkpoint": "checkpoints/gan/gan_final.pth",
        "output_dir": "data/synthetic"
    }
    
    Returns:
        JSON response with generation status and file paths
    """
    try:
        # Get request data
        data = request.get_json()
        
        num_samples = data.get('num_samples', 100)
        pattern = data.get('pattern')
        defect_density = data.get('defect_density')
        checkpoint = data.get('checkpoint', 'checkpoints/gan/gan_final.pth')
        output_dir = data.get('output_dir', 'data/synthetic')
        
        # Validate checkpoint exists
        if not os.path.exists(checkpoint):
            return jsonify({'error': f'Checkpoint not found: {checkpoint}'}), 404
        
        # Generate job ID
        job_id = str(uuid.uuid4())
        
        # Create job record
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        job_record = {
            'id': job_id,
            'type': 'gan_generation',
            'status': 'queued',
            'created_at': datetime.now().isoformat(),
            'config': {
                'num_samples': num_samples,
                'pattern': pattern,
                'defect_density': defect_density,
                'checkpoint': checkpoint,
                'output_dir': output_dir
            },
            'progress': 0,
            'generated_files': []
        }
        
        # Save job record
        gan_jobs = storage.read('gan_jobs.json', default=[])
        gan_jobs.append(job_record)
        storage.write('gan_jobs.json', gan_jobs)
        
        # Start generation in background thread
        generation_thread = threading.Thread(
            target=_run_gan_generation,
            args=(job_id, job_record['config'])
        )
        generation_thread.daemon = True
        generation_thread.start()
        
        return jsonify({
            'status': 'success',
            'message': 'Synthetic generation started',
            'job_id': job_id
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"GAN generation error: {str(e)}")
        return jsonify({'error': f'Failed to start generation: {str(e)}'}), 500


@api_v1_bp.route('/gan/models', methods=['GET'])
def list_gan_models():
    """
    List available GAN models
    
    Returns:
        JSON response with list of GAN checkpoints
    """
    try:
        checkpoint_dir = Path('checkpoints/gan')
        
        if not checkpoint_dir.exists():
            return jsonify({
                'status': 'success',
                'models': []
            }), 200
        
        # Find all .pth files
        models = []
        for checkpoint_file in checkpoint_dir.glob('*.pth'):
            stat = checkpoint_file.stat()
            models.append({
                'name': checkpoint_file.name,
                'path': str(checkpoint_file),
                'size_mb': round(stat.st_size / (1024 * 1024), 2),
                'created_at': datetime.fromtimestamp(stat.st_ctime).isoformat()
            })
        
        # Sort by creation time (newest first)
        models.sort(key=lambda x: x['created_at'], reverse=True)
        
        return jsonify({
            'status': 'success',
            'models': models
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"List GAN models error: {str(e)}")
        return jsonify({'error': f'Failed to list models: {str(e)}'}), 500


@api_v1_bp.route('/gan/jobs', methods=['GET'])
def list_gan_jobs():
    """
    List all GAN jobs (training and generation)
    
    Query Parameters:
        - type: Filter by job type (training, generation)
        - status: Filter by status (queued, training, completed, failed)
        - limit: Number of jobs to return (default: 50)
    
    Returns:
        JSON response with list of jobs
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get query parameters
        job_type = request.args.get('type')
        status = request.args.get('status')
        limit = int(request.args.get('limit', 50))
        
        # Load jobs
        gan_jobs = storage.read('gan_jobs.json', default=[])
        
        # Apply filters
        if job_type:
            gan_jobs = [j for j in gan_jobs if j.get('type') == job_type]
        
        if status:
            gan_jobs = [j for j in gan_jobs if j.get('status') == status]
        
        # Sort by creation time (newest first)
        gan_jobs.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        # Limit results
        gan_jobs = gan_jobs[:limit]
        
        return jsonify({
            'status': 'success',
            'jobs': gan_jobs,
            'total': len(gan_jobs)
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"List GAN jobs error: {str(e)}")
        return jsonify({"error": f"Failed to list jobs: {str(e)}"}), 500


@api_v1_bp.route('/gan/validate', methods=['POST'])
def validate_synthetic_quality():
    """
    Validate quality of synthetic wafer maps
    
    Request Body:
    {
        "real_dir": "data/wafer_images",
        "synthetic_dir": "data/synthetic",
        "model_checkpoint": "checkpoints/best_model.pth"
    }
    
    Returns:
        JSON response with quality metrics
    """
    try:
        # Get request data
        data = request.get_json()
        
        real_dir = data.get('real_dir', 'data/wafer_images')
        synthetic_dir = data.get('synthetic_dir', 'data/synthetic')
        model_checkpoint = data.get('model_checkpoint', 'checkpoints/best_model.pth')
        
        # Validate directories exist
        if not os.path.exists(real_dir):
            return jsonify({'error': f'Real directory not found: {real_dir}'}), 404
        
        if not os.path.exists(synthetic_dir):
            return jsonify({'error': f'Synthetic directory not found: {synthetic_dir}'}), 404
        
        if not os.path.exists(model_checkpoint):
            return jsonify({'error': f'Model checkpoint not found: {model_checkpoint}'}), 404
        
        # Generate job ID
        job_id = str(uuid.uuid4())
        
        # Create job record
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        job_record = {
            'id': job_id,
            'type': 'gan_validation',
            'status': 'queued',
            'created_at': datetime.now().isoformat(),
            'config': {
                'real_dir': real_dir,
                'synthetic_dir': synthetic_dir,
                'model_checkpoint': model_checkpoint
            },
            'metrics': {}
        }
        
        # Save job record
        gan_jobs = storage.read('gan_jobs.json', default=[])
        gan_jobs.append(job_record)
        storage.write('gan_jobs.json', gan_jobs)
        
        # Start validation in background thread
        validation_thread = threading.Thread(
            target=_run_gan_validation,
            args=(job_id, job_record['config'])
        )
        validation_thread.daemon = True
        validation_thread.start()
        
        return jsonify({
            'status': 'success',
            'message': 'Quality validation started',
            'job_id': job_id
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"GAN validation error: {str(e)}")
        return jsonify({'error': f'Failed to start validation: {str(e)}'}), 500


# Background task functions

def _run_gan_training(job_id: str, config: dict):
    """Run GAN training in background"""
    import subprocess
    import sys
    
    global gan_training_status
    
    try:
        # Update status
        gan_training_status['status'] = 'training'
        
        # Build command
        cmd = [
            sys.executable,
            'scripts/train_gan.py',
            '--epochs', str(config['epochs']),
            '--batch-size', str(config['batch_size']),
            '--n-critic', str(config['n_critic']),
            '--lambda-gp', str(config['lambda_gp']),
            '--lr', str(config['learning_rate']),
            '--split', config['data_split'],
            '--checkpoint-dir', config['checkpoint_dir']
        ]
        
        # Run training
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        
        # Monitor progress
        for line in process.stdout:
            # Parse progress from output
            if 'Epoch [' in line:
                # Extract epoch number
                try:
                    epoch_str = line.split('Epoch [')[1].split('/')[0]
                    current_epoch = int(epoch_str)
                    gan_training_status['current_epoch'] = current_epoch
                    gan_training_status['progress'] = int((current_epoch / config['epochs']) * 100)
                except:
                    pass
            
            # Extract metrics
            if 'D Loss:' in line:
                try:
                    parts = line.split('-')[1].strip().split(',')
                    metrics = {}
                    for part in parts:
                        key, value = part.split(':')
                        metrics[key.strip()] = float(value.strip())
                    gan_training_status['metrics'] = metrics
                except:
                    pass
        
        process.wait()
        
        # Update job record
        storage = JSONStorage('data/metadata')
        gan_jobs = storage.read('gan_jobs.json', default=[])
        
        for job in gan_jobs:
            if job['id'] == job_id:
                if process.returncode == 0:
                    job['status'] = 'completed'
                    job['completed_at'] = datetime.now().isoformat()
                    job['progress'] = 100
                else:
                    job['status'] = 'failed'
                    job['error'] = f'Training failed with exit code {process.returncode}'
                break
        
        storage.write('gan_jobs.json', gan_jobs)
        
        # Reset global status
        gan_training_status['is_training'] = False
        
    except Exception as e:
        # Update job record with error
        storage = JSONStorage('data/metadata')
        gan_jobs = storage.read('gan_jobs.json', default=[])
        
        for job in gan_jobs:
            if job['id'] == job_id:
                job['status'] = 'failed'
                job['error'] = str(e)
                break
        
        storage.write('gan_jobs.json', gan_jobs)
        
        gan_training_status['is_training'] = False
        gan_training_status['error'] = str(e)


def _run_gan_generation(job_id: str, config: dict):
    """Run GAN generation in background"""
    import subprocess
    import sys
    
    try:
        # Build command
        cmd = [
            sys.executable,
            'scripts/generate_synthetic_wafers.py',
            '--checkpoint', config['checkpoint'],
            '--num-samples', str(config['num_samples']),
            '--output-dir', config['output_dir'],
            '--save-metadata'
        ]
        
        if config.get('pattern'):
            cmd.extend(['--pattern', config['pattern']])
        
        if config.get('defect_density') is not None:
            cmd.extend(['--defect-density', str(config['defect_density'])])
        
        # Run generation
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        # Update job record
        storage = JSONStorage('data/metadata')
        gan_jobs = storage.read('gan_jobs.json', default=[])
        
        for job in gan_jobs:
            if job['id'] == job_id:
                if result.returncode == 0:
                    job['status'] = 'completed'
                    job['completed_at'] = datetime.now().isoformat()
                    job['progress'] = 100
                    
                    # List generated files
                    output_dir = Path(config['output_dir'])
                    if output_dir.exists():
                        job['generated_files'] = [str(f) for f in output_dir.glob('*.png')]
                else:
                    job['status'] = 'failed'
                    job['error'] = result.stderr
                break
        
        storage.write('gan_jobs.json', gan_jobs)
        
    except Exception as e:
        # Update job record with error
        storage = JSONStorage('data/metadata')
        gan_jobs = storage.read('gan_jobs.json', default=[])
        
        for job in gan_jobs:
            if job['id'] == job_id:
                job['status'] = 'failed'
                job['error'] = str(e)
                break
        
        storage.write('gan_jobs.json', gan_jobs)


def _run_gan_validation(job_id: str, config: dict):
    """Run GAN validation in background"""
    import subprocess
    import sys
    
    try:
        # Build command
        cmd = [
            sys.executable,
            'scripts/validate_synthetic_quality.py',
            '--real-dir', config['real_dir'],
            '--synthetic-dir', config['synthetic_dir'],
            '--model-checkpoint', config['model_checkpoint']
        ]
        
        # Run validation
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        # Parse metrics from output
        metrics = {}
        if result.returncode == 0:
            # Extract FID score
            for line in result.stdout.split('\n'):
                if 'FID Score:' in line:
                    try:
                        metrics['fid_score'] = float(line.split(':')[1].strip())
                    except:
                        pass
                elif 'Average Classifier Confidence:' in line:
                    try:
                        metrics['avg_confidence'] = float(line.split(':')[1].strip())
                    except:
                        pass
        
        # Update job record
        storage = JSONStorage('data/metadata')
        gan_jobs = storage.read('gan_jobs.json', default=[])
        
        for job in gan_jobs:
            if job['id'] == job_id:
                if result.returncode == 0:
                    job['status'] = 'completed'
                    job['completed_at'] = datetime.now().isoformat()
                    job['metrics'] = metrics
                else:
                    job['status'] = 'failed'
                    job['error'] = result.stderr
                break
        
        storage.write('gan_jobs.json', gan_jobs)
        
    except Exception as e:
        # Update job record with error
        storage = JSONStorage('data/metadata')
        gan_jobs = storage.read('gan_jobs.json', default=[])
        
        for job in gan_jobs:
            if job['id'] == job_id:
                job['status'] = 'failed'
                job['error'] = str(e)
                break
        
        storage.write('gan_jobs.json', gan_jobs)
