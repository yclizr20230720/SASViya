# Windows Server 2022 Deployment Guide
# Wafer Defect Pattern Recognition System - Backend API

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Service Installation](#service-installation)
5. [Verification](#verification)
6. [Maintenance](#maintenance)
7. [Troubleshooting](#troubleshooting)
8. [Backup and Restore](#backup-and-restore)

---

## Prerequisites

### System Requirements

**Hardware:**
- CPU: Intel Xeon or AMD EPYC (8+ cores recommended)
- RAM: 16 GB minimum, 32 GB recommended
- Storage: 500 GB SSD (for data and models)
- GPU: NVIDIA GPU with 8GB+ VRAM (optional, for faster inference)

**Software:**
- Windows Server 2022 (Standard or Datacenter)
- Python 3.11 or higher
- NVIDIA CUDA Toolkit 11.8 (if using GPU)
- Administrator access

### Network Requirements
- Port 5000 must be available for API server
- Outbound internet access for package installation
- Inbound access from frontend server (port 5000)

---

## Installation

### Step 1: Install Python 3.11

1. Download Python 3.11 from: https://www.python.org/downloads/
2. Run the installer
3. **IMPORTANT**: Check "Add Python to PATH"
4. Choose "Customize installation"
5. Enable "pip" and "py launcher"
6. Install for all users
7. Verify installation:
   ```cmd
   python --version
   ```
   Should output: `Python 3.11.x`

### Step 2: Install NVIDIA CUDA (Optional, for GPU)

If you have an NVIDIA GPU:

1. Download CUDA Toolkit 11.8 from: https://developer.nvidia.com/cuda-downloads
2. Run the installer
3. Follow the installation wizard
4. Verify installation:
   ```cmd
   nvcc --version
   ```

### Step 3: Download and Extract Application

1. Copy the `wafer-defect-ap` folder to your server
2. Recommended location: `C:\Apps\wafer-defect-ap`
3. Open Command Prompt as Administrator
4. Navigate to the application directory:
   ```cmd
   cd C:\Apps\wafer-defect-ap
   ```

### Step 4: Run Installation Script

Run the automated installer:

```cmd
deploy\install.bat
```

The installer will:
- ✓ Check Python installation
- ✓ Create virtual environment
- ✓ Install all dependencies
- ✓ Install PyTorch (with CUDA if available)
- ✓ Initialize data storage
- ✓ Create configuration file
- ✓ Configure Windows Firewall
- ✓ Run health check

**Installation time:** 5-10 minutes (depending on internet speed)

---

## Configuration

### Environment Configuration

Edit the `.env` file to configure the application:

```bash
# Flask Configuration
FLASK_ENV=production
FLASK_DEBUG=False
SECRET_KEY=your-secret-key-here-change-this

# Server Configuration
HOST=0.0.0.0
PORT=5000

# Data Storage Paths
DATA_FOLDER=data
METADATA_FOLDER=data/metadata
WAFER_IMAGES_FOLDER=data/wafer_images
MODELS_FOLDER=data/models
TEMP_FOLDER=data/temp
LOGS_FOLDER=logs
CHECKPOINTS_FOLDER=checkpoints

# Model Configuration
DEFAULT_MODEL_PATH=checkpoints/best_model.pth
INFERENCE_DEVICE=cuda  # or 'cpu'
INFERENCE_BATCH_SIZE=32

# Training Configuration
TRAINING_EPOCHS=100
TRAINING_BATCH_SIZE=32
TRAINING_LEARNING_RATE=0.0001

# API Configuration
MAX_UPLOAD_SIZE=100  # MB
ALLOWED_EXTENSIONS=jpg,jpeg,png,gif,json,csv,xlsx
CORS_ORIGINS=http://localhost:5173,http://your-frontend-server

# Logging
LOG_LEVEL=INFO
LOG_MAX_BYTES=10485760  # 10 MB
LOG_BACKUP_COUNT=5
```

### Important Configuration Notes

1. **SECRET_KEY**: Generate a secure random key:
   ```python
   python -c "import secrets; print(secrets.token_hex(32))"
   ```

2. **CORS_ORIGINS**: Add your frontend server URL

3. **INFERENCE_DEVICE**: 
   - Use `cuda` if you have NVIDIA GPU
   - Use `cpu` for CPU-only inference

4. **Paths**: Use absolute paths if deploying to non-standard location

---

## Service Installation

### Option 1: Manual Start (Testing)

For testing and development:

```cmd
deploy\start_service.bat
```

This starts the API server in the current terminal. Press Ctrl+C to stop.

### Option 2: Windows Service (Production)

For production deployment with automatic startup:

#### Step 1: Download NSSM

1. Download NSSM from: https://nssm.cc/download
2. Extract `nssm.exe` (64-bit version)
3. Copy `nssm.exe` to `deploy\` folder

#### Step 2: Install Service

Run as Administrator:

```cmd
deploy\install_service.bat
```

The service will be:
- **Name**: WaferDefectAPI
- **Display Name**: Wafer Defect Pattern Recognition API
- **Startup Type**: Automatic
- **Logs**: `logs\service_stdout.log` and `logs\service_stderr.log`

#### Step 3: Manage Service

**Start service:**
```cmd
net start WaferDefectAPI
```

**Stop service:**
```cmd
net stop WaferDefectAPI
```

**Check status:**
```cmd
sc query WaferDefectAPI
```

**View service in Services Manager:**
```cmd
services.msc
```

#### Step 4: Uninstall Service (if needed)

```cmd
deploy\uninstall_service.bat
```

---

## Verification

### Health Check

Run the health check script:

```cmd
python deploy\health_check.py
```

Expected output:
```
Checking Python version... ✓ Python 3.11.x
Checking dependencies... ✓ All 6 packages installed
Checking PyTorch CUDA... ✓ CUDA available (GPU: NVIDIA ...)
Checking directory structure... ✓ All 13 directories exist
Checking JSON storage files... ✓ All 5 JSON files exist
Checking configuration file... ✓ .env file exists
Checking trained model... ⚠ No trained model found
Checking Flask application... ✓ Flask app initialized successfully
Checking port 5000 availability... ✓ Port 5000 is available

Total: 9/9 checks passed
✓ System is ready for deployment!
```

### API Endpoint Testing

Test the API is responding:

```cmd
curl http://localhost:5000/api/v1/health
```

Expected response:
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2026-01-20T10:30:00Z"
}
```

### Frontend Integration Test

From the frontend server, test connectivity:

```cmd
curl http://your-server-ip:5000/api/v1/health
```

---

## Maintenance

### Log Management

**View logs:**
```cmd
type logs\app.log
type logs\service_stdout.log
type logs\service_stderr.log
```

**Log rotation:**
Logs are automatically rotated when they reach 10 MB. Up to 5 backup files are kept.

**Clear old logs:**
```cmd
del /Q logs\*.log.1
del /Q logs\*.log.2
del /Q logs\*.log.3
```

### Data Management

**Check disk usage:**
```cmd
dir /s data
```

**Clean temporary files:**
```cmd
del /Q data\temp\*.*
```

**Archive old wafer images:**
```cmd
REM Move images older than 90 days to archive
forfiles /P data\wafer_images /D -90 /M *.* /C "cmd /c move @path data\archive\"
```

### Model Updates

**Deploy new model:**

1. Stop the service:
   ```cmd
   net stop WaferDefectAPI
   ```

2. Backup current model:
   ```cmd
   copy checkpoints\best_model.pth checkpoints\best_model_backup.pth
   ```

3. Copy new model:
   ```cmd
   copy new_model.pth checkpoints\best_model.pth
   ```

4. Start the service:
   ```cmd
   net start WaferDefectAPI
   ```

### Dependency Updates

**Update Python packages:**

```cmd
venv\Scripts\activate
pip install --upgrade -r requirements.txt
```

**Update PyTorch:**

```cmd
venv\Scripts\activate
pip install --upgrade torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

---

## Backup and Restore

### Backup

**Create backup:**

```cmd
deploy\backup.bat
```

This creates a timestamped backup in `backups\backup_YYYYMMDD_HHMM\` containing:
- Data files (JSON, images)
- Configuration (.env, config.py)
- Logs
- Model checkpoints

**Manual backup:**

```cmd
xcopy /E /I data backups\manual_backup\data
copy .env backups\manual_backup\.env
xcopy /E /I checkpoints backups\manual_backup\checkpoints
```

### Restore

**Restore from backup:**

```cmd
deploy\restore.bat
```

Follow the prompts to select a backup to restore.

**Manual restore:**

```cmd
xcopy /E /I /Y backups\backup_YYYYMMDD_HHMM\data data
copy /Y backups\backup_YYYYMMDD_HHMM\.env .env
xcopy /E /I /Y backups\backup_YYYYMMDD_HHMM\checkpoints checkpoints
```

### Automated Backup Schedule

**Create scheduled task for daily backups:**

1. Open Task Scheduler: `taskschd.msc`
2. Create Basic Task
3. Name: "Wafer Defect API Backup"
4. Trigger: Daily at 2:00 AM
5. Action: Start a program
6. Program: `C:\Apps\wafer-defect-ap\deploy\backup.bat`
7. Finish

---

## Troubleshooting

### Service Won't Start

**Check logs:**
```cmd
type logs\service_stderr.log
```

**Common issues:**

1. **Port 5000 in use:**
   ```cmd
   netstat -ano | findstr :5000
   taskkill /PID <process_id> /F
   ```

2. **Python not found:**
   - Verify Python is in PATH
   - Check service configuration in `services.msc`

3. **Missing dependencies:**
   ```cmd
   venv\Scripts\activate
   pip install -r requirements.txt
   ```

### Inference Errors

**Model not found:**
```
ERROR: Trained model not found at checkpoints/best_model.pth
```

**Solution:**
- Train a model using `scripts\train_model.py`
- Or copy a pre-trained model to `checkpoints\best_model.pth`

**CUDA out of memory:**
```
RuntimeError: CUDA out of memory
```

**Solution:**
- Reduce batch size in `.env`: `INFERENCE_BATCH_SIZE=16`
- Or switch to CPU: `INFERENCE_DEVICE=cpu`

### High Memory Usage

**Check memory usage:**
```cmd
tasklist /FI "IMAGENAME eq python.exe" /FO TABLE
```

**Solutions:**
- Restart service: `net stop WaferDefectAPI && net start WaferDefectAPI`
- Reduce batch size
- Clear temporary files: `del /Q data\temp\*.*`

### Slow Inference

**Check GPU usage:**
```cmd
nvidia-smi
```

**Solutions:**
- Ensure CUDA is properly installed
- Verify `INFERENCE_DEVICE=cuda` in `.env`
- Check GPU memory is not full
- Use batch inference for multiple wafers

### Network Connectivity Issues

**Test from frontend:**
```cmd
curl http://backend-server-ip:5000/api/v1/health
```

**Check firewall:**
```cmd
netsh advfirewall firewall show rule name="Wafer Defect API"
```

**Add firewall rule manually:**
```cmd
netsh advfirewall firewall add rule name="Wafer Defect API" dir=in action=allow protocol=TCP localport=5000
```

### Database Corruption

**Symptoms:**
- JSON parsing errors
- Missing data
- Inconsistent state

**Solution:**

1. Stop service:
   ```cmd
   net stop WaferDefectAPI
   ```

2. Restore from backup:
   ```cmd
   deploy\restore.bat
   ```

3. Or reinitialize storage:
   ```cmd
   python -c "from app.utils.init_storage import initialize_storage; initialize_storage()"
   ```

4. Start service:
   ```cmd
   net start WaferDefectAPI
   ```

---

## Performance Tuning

### For High-Volume Inference

**Optimize configuration:**

```bash
# .env
INFERENCE_BATCH_SIZE=64  # Increase for GPU
INFERENCE_DEVICE=cuda
```

**Use batch inference API:**
```python
POST /api/v1/inference/batch-predict
{
  "wafer_ids": ["W001", "W002", ...],
  "batch_size": 64
}
```

### For Limited Resources

**Reduce memory usage:**

```bash
# .env
INFERENCE_BATCH_SIZE=8
TRAINING_BATCH_SIZE=16
```

**Use CPU inference:**

```bash
# .env
INFERENCE_DEVICE=cpu
```

### For Production Scale

**Recommendations:**
- Use NVIDIA GPU with 16GB+ VRAM
- 32 GB RAM minimum
- SSD storage for data
- Dedicated server (not shared)
- Regular backups (daily)
- Monitoring and alerting

---

## Security Considerations

### Network Security

1. **Firewall Configuration:**
   - Only allow port 5000 from frontend server
   - Block external access if not needed

2. **HTTPS (Recommended):**
   - Use reverse proxy (IIS, Nginx) for HTTPS
   - Configure SSL certificates
   - Redirect HTTP to HTTPS

### Application Security

1. **Secret Key:**
   - Use strong random secret key
   - Never commit to version control

2. **File Upload Validation:**
   - File type validation enabled
   - Size limits enforced (100 MB default)
   - Malware scanning recommended

3. **Access Control:**
   - Implement authentication (if needed)
   - Use API keys for frontend
   - Rate limiting for public endpoints

### Data Security

1. **Backup Encryption:**
   - Encrypt backup files
   - Store backups securely
   - Test restore procedures

2. **Data Privacy:**
   - Implement data retention policies
   - Secure deletion of old data
   - Compliance with regulations

---

## Monitoring and Alerts

### System Monitoring

**CPU and Memory:**
```cmd
perfmon
```

**Disk Space:**
```cmd
wmic logicaldisk get size,freespace,caption
```

**GPU Monitoring:**
```cmd
nvidia-smi -l 5
```

### Application Monitoring

**API Health:**
```cmd
curl http://localhost:5000/api/v1/health
```

**Service Status:**
```cmd
sc query WaferDefectAPI
```

**Log Monitoring:**
```cmd
powershell Get-Content logs\app.log -Wait -Tail 50
```

### Recommended Monitoring Tools

- **Windows Performance Monitor** - System metrics
- **Event Viewer** - Windows events and errors
- **NVIDIA SMI** - GPU monitoring
- **Custom scripts** - API health checks

---

## Support and Contact

For technical support:
- Check logs in `logs\` directory
- Review this deployment guide
- Run health check: `python deploy\health_check.py`
- Contact system administrator

---

## Appendix

### Directory Structure

```
wafer-defect-ap/
├── app/                    # Application code
│   ├── api/               # API endpoints
│   ├── ml/                # ML models
│   └── utils/             # Utilities
├── data/                  # Data storage
│   ├── metadata/          # JSON files
│   ├── wafer_images/      # Wafer images
│   ├── models/            # Model registry
│   └── temp/              # Temporary files
├── logs/                  # Application logs
├── checkpoints/           # Model checkpoints
├── scripts/               # Training scripts
├── deploy/                # Deployment scripts
│   ├── install.bat
│   ├── install_service.bat
│   ├── start_service.bat
│   ├── stop_service.bat
│   ├── backup.bat
│   └── restore.bat
├── venv/                  # Virtual environment
├── .env                   # Configuration
├── requirements.txt       # Dependencies
└── run.py                 # Application entry point
```

### Port Usage

- **5000**: Flask API server (HTTP)
- **5173**: Frontend dev server (if running locally)

### File Locations

- **Configuration**: `.env`
- **Logs**: `logs\app.log`, `logs\service_*.log`
- **Data**: `data\metadata\*.json`
- **Models**: `checkpoints\best_model.pth`
- **Backups**: `backups\backup_*\`

---

**Document Version**: 1.0  
**Last Updated**: January 20, 2026  
**Target Platform**: Windows Server 2022
