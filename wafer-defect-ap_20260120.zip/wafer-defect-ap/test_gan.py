"""
Test GAN Implementation

Verifies that the GAN architecture and training loop work correctly
"""
import torch
import numpy as np
from pathlib import Path

from app.ml.gan import Generator, Discriminator, WaferGAN


def test_generator():
    """Test Generator network"""
    print("="*60)
    print("TEST 1: Generator Network")
    print("="*60)
    
    # Initialize generator
    generator = Generator(noise_dim=100, num_patterns=10, img_size=224)
    
    # Test forward pass
    batch_size = 4
    noise = torch.randn(batch_size, 100)
    pattern_labels = torch.randint(0, 10, (batch_size,))
    defect_density = torch.rand(batch_size, 1)
    
    output = generator(noise, pattern_labels, defect_density)
    
    # Verify output shape
    assert output.shape == (batch_size, 3, 224, 224), f"Expected (4, 3, 224, 224), got {output.shape}"
    
    # Verify output range [0, 1]
    assert output.min() >= 0 and output.max() <= 1, f"Output not in [0, 1]: min={output.min()}, max={output.max()}"
    
    # Count parameters
    num_params = sum(p.numel() for p in generator.parameters())
    
    print(f"✓ Generator initialized successfully")
    print(f"✓ Output shape: {output.shape}")
    print(f"✓ Output range: [{output.min():.4f}, {output.max():.4f}]")
    print(f"✓ Parameters: {num_params:,}")
    print()


def test_discriminator():
    """Test Discriminator network"""
    print("="*60)
    print("TEST 2: Discriminator Network")
    print("="*60)
    
    # Initialize discriminator
    discriminator = Discriminator(num_patterns=10, img_size=224)
    
    # Test forward pass
    batch_size = 4
    images = torch.rand(batch_size, 3, 224, 224)
    pattern_labels = torch.randint(0, 10, (batch_size,))
    defect_density = torch.rand(batch_size, 1)
    
    output = discriminator(images, pattern_labels, defect_density)
    
    # Verify output shape
    assert output.shape == (batch_size, 1), f"Expected (4, 1), got {output.shape}"
    
    # Count parameters
    num_params = sum(p.numel() for p in discriminator.parameters())
    
    print(f"✓ Discriminator initialized successfully")
    print(f"✓ Output shape: {output.shape}")
    print(f"✓ Output range: [{output.min():.4f}, {output.max():.4f}]")
    print(f"✓ Parameters: {num_params:,}")
    print()


def test_wafer_gan():
    """Test WaferGAN class"""
    print("="*60)
    print("TEST 3: WaferGAN Class")
    print("="*60)
    
    # Initialize GAN
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    gan = WaferGAN(noise_dim=100, num_patterns=10, img_size=224, device=device)
    
    print(f"✓ WaferGAN initialized on {device}")
    
    # Test generation
    batch_size = 4
    pattern_labels = torch.randint(0, 10, (batch_size,), device=device)
    defect_density = torch.rand(batch_size, 1, device=device)
    
    fake_images = gan.generate(pattern_labels, defect_density, num_samples=batch_size)
    
    assert fake_images.shape == (batch_size, 3, 224, 224), f"Expected (4, 3, 224, 224), got {fake_images.shape}"
    
    print(f"✓ Generation successful")
    print(f"✓ Generated images shape: {fake_images.shape}")
    print()


def test_gradient_penalty():
    """Test gradient penalty computation"""
    print("="*60)
    print("TEST 4: Gradient Penalty")
    print("="*60)
    
    # Initialize GAN
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    gan = WaferGAN(noise_dim=100, num_patterns=10, img_size=224, device=device)
    
    # Create fake data
    batch_size = 4
    real_images = torch.rand(batch_size, 3, 224, 224, device=device)
    fake_images = torch.rand(batch_size, 3, 224, 224, device=device)
    pattern_labels = torch.randint(0, 10, (batch_size,), device=device)
    defect_density = torch.rand(batch_size, 1, device=device)
    
    # Compute gradient penalty
    gp = gan.compute_gradient_penalty(real_images, fake_images, pattern_labels, defect_density)
    
    assert gp.item() >= 0, f"Gradient penalty should be non-negative, got {gp.item()}"
    
    print(f"✓ Gradient penalty computed successfully")
    print(f"✓ GP value: {gp.item():.4f}")
    print()


def test_training_step():
    """Test single training step"""
    print("="*60)
    print("TEST 5: Training Step")
    print("="*60)
    
    # Initialize GAN
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    gan = WaferGAN(noise_dim=100, num_patterns=10, img_size=224, device=device)
    
    # Create fake data
    batch_size = 4
    real_images = torch.rand(batch_size, 3, 224, 224, device=device)
    pattern_labels = torch.randint(0, 10, (batch_size,), device=device)
    defect_density = torch.rand(batch_size, 1, device=device)
    
    # Training step
    metrics = gan.train_step(real_images, pattern_labels, defect_density, n_critic=2)
    
    # Verify metrics
    assert 'd_loss' in metrics, "Missing d_loss in metrics"
    assert 'g_loss' in metrics, "Missing g_loss in metrics"
    assert 'gp' in metrics, "Missing gp in metrics"
    assert 'w_dist' in metrics, "Missing w_dist in metrics"
    
    print(f"✓ Training step successful")
    print(f"✓ Discriminator loss: {metrics['d_loss']:.4f}")
    print(f"✓ Generator loss: {metrics['g_loss']:.4f}")
    print(f"✓ Gradient penalty: {metrics['gp']:.4f}")
    print(f"✓ Wasserstein distance: {metrics['w_dist']:.4f}")
    print()


def test_checkpoint():
    """Test checkpoint save/load"""
    print("="*60)
    print("TEST 6: Checkpoint Save/Load")
    print("="*60)
    
    # Initialize GAN
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    gan = WaferGAN(noise_dim=100, num_patterns=10, img_size=224, device=device)
    
    # Save checkpoint
    checkpoint_path = 'test_gan_checkpoint.pth'
    gan.save(checkpoint_path)
    
    assert Path(checkpoint_path).exists(), "Checkpoint file not created"
    
    print(f"✓ Checkpoint saved to {checkpoint_path}")
    
    # Load checkpoint
    gan2 = WaferGAN(noise_dim=100, num_patterns=10, img_size=224, device=device)
    gan2.load(checkpoint_path)
    
    print(f"✓ Checkpoint loaded successfully")
    
    # Clean up
    Path(checkpoint_path).unlink()
    print(f"✓ Checkpoint file removed")
    print()


def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("GAN IMPLEMENTATION TESTS")
    print("="*60)
    print()
    
    try:
        test_generator()
        test_discriminator()
        test_wafer_gan()
        test_gradient_penalty()
        test_training_step()
        test_checkpoint()
        
        print("="*60)
        print("ALL TESTS PASSED ✓")
        print("="*60)
        print()
        print("GAN implementation is working correctly!")
        print()
        print("Next steps:")
        print("1. Prepare training dataset with labeled wafer maps")
        print("2. Train GAN using: python scripts/train_gan.py")
        print("3. Generate synthetic samples using: python scripts/generate_synthetic_wafers.py")
        print("4. Validate quality using: python scripts/validate_synthetic_quality.py")
        print()
        
    except Exception as e:
        print(f"\n✗ TEST FAILED: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == '__main__':
    exit(main())
