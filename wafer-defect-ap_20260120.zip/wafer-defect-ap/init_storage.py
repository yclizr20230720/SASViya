"""
Initialize JSON storage structure
Run this script to set up the data directories and JSON files
"""
import os
import sys
from app.utils.data_init import initialize_json_files, create_sample_data

# Add app to path
sys.path.insert(0, os.path.dirname(__file__))

def main():
    """Initialize storage structure"""
    print("=" * 60)
    print("Wafer Defect Analysis System - Storage Initialization")
    print("=" * 60)
    
    # Get base directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Create directory structure
    directories = [
        os.path.join(base_dir, 'data', 'metadata'),
        os.path.join(base_dir, 'data', 'wafer_images'),
        os.path.join(base_dir, 'data', 'models'),
        os.path.join(base_dir, 'data', 'temp'),
        os.path.join(base_dir, 'logs')
    ]
    
    print("\n1. Creating directory structure...")
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"   ✓ {directory}")
    
    # Initialize JSON files
    print("\n2. Initializing JSON files...")
    metadata_folder = os.path.join(base_dir, 'data', 'metadata')
    initialize_json_files(metadata_folder)
    
    # Ask if user wants sample data
    print("\n3. Sample data creation (optional)")
    response = input("   Do you want to create sample data for testing? (y/n): ").strip().lower()
    
    if response == 'y':
        create_sample_data(metadata_folder)
    else:
        print("   - Skipped sample data creation")
    
    print("\n" + "=" * 60)
    print("✓ Storage initialization completed successfully!")
    print("=" * 60)
    print("\nNext steps:")
    print("1. Install dependencies: pip install -r requirements.txt")
    print("2. Run the Flask app: python run.py")
    print("3. Test health endpoint: http://localhost:5000/health")
    print()

if __name__ == '__main__':
    main()
