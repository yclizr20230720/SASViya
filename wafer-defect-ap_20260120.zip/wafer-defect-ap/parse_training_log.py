"""
Parse actual training log and create structured data for web monitoring

This script reads the training console output and creates:
1. logs/training_metrics.json - Structured metrics for each epoch
2. logs/training_current.log - Formatted log file
3. logs/training_status.json - Current training status
"""
import re
import json
from datetime import datetime
from pathlib import Path

# Create logs directory
Path('logs').mkdir(exist_ok=True)

# Your actual training log (paste the console output here)
TRAINING_LOG = """
Epoch 1/30
Train - Loss: 0.8287, Pattern Acc: 0.204, Root Cause Acc: 0.225
Val   - Loss: 0.8282, Pattern Acc: 0.300, Root Cause Acc: 0.225
LR: 0.000098
Saved checkpoint: checkpoints\\checkpoint_epoch_1.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 2/30
Train - Loss: 0.7381, Pattern Acc: 0.382, Root Cause Acc: 0.366
Val   - Loss: 0.7581, Pattern Acc: 0.350, Root Cause Acc: 0.225
LR: 0.000091
Saved checkpoint: checkpoints\\checkpoint_epoch_2.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 3/30
Train - Loss: 0.6703, Pattern Acc: 0.424, Root Cause Acc: 0.429
Val   - Loss: 0.6852, Pattern Acc: 0.375, Root Cause Acc: 0.225
LR: 0.000080
Saved checkpoint: checkpoints\\checkpoint_epoch_3.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 4/30
Train - Loss: 0.6015, Pattern Acc: 0.529, Root Cause Acc: 0.534
Val   - Loss: 0.6398, Pattern Acc: 0.475, Root Cause Acc: 0.300
LR: 0.000066
Saved checkpoint: checkpoints\\checkpoint_epoch_4.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 5/30
Train - Loss: 0.5595, Pattern Acc: 0.539, Root Cause Acc: 0.503
Val   - Loss: 0.5917, Pattern Acc: 0.550, Root Cause Acc: 0.350
LR: 0.000051
Saved checkpoint: checkpoints\\checkpoint_epoch_5.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 6/30
Train - Loss: 0.5098, Pattern Acc: 0.613, Root Cause Acc: 0.586
Val   - Loss: 0.5367, Pattern Acc: 0.675, Root Cause Acc: 0.575
LR: 0.000035
Saved checkpoint: checkpoints\\checkpoint_epoch_6.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 7/30
Train - Loss: 0.4898, Pattern Acc: 0.670, Root Cause Acc: 0.660
Val   - Loss: 0.4996, Pattern Acc: 0.725, Root Cause Acc: 0.650
LR: 0.000021
Saved checkpoint: checkpoints\\checkpoint_epoch_7.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 8/30
Train - Loss: 0.4729, Pattern Acc: 0.670, Root Cause Acc: 0.649
Val   - Loss: 0.4795, Pattern Acc: 0.750, Root Cause Acc: 0.650
LR: 0.000010
Saved checkpoint: checkpoints\\checkpoint_epoch_8.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 9/30
Train - Loss: 0.4400, Pattern Acc: 0.670, Root Cause Acc: 0.660
Val   - Loss: 0.4730, Pattern Acc: 0.725, Root Cause Acc: 0.675
LR: 0.000003

Epoch 10/30
Train - Loss: 0.4386, Pattern Acc: 0.681, Root Cause Acc: 0.639
Val   - Loss: 0.4657, Pattern Acc: 0.700, Root Cause Acc: 0.700
LR: 0.000100

Epoch 11/30
Train - Loss: 0.4016, Pattern Acc: 0.702, Root Cause Acc: 0.696
Val   - Loss: 0.3644, Pattern Acc: 0.800, Root Cause Acc: 0.725
LR: 0.000099
Saved checkpoint: checkpoints\\checkpoint_epoch_11.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 12/30
Train - Loss: 0.3507, Pattern Acc: 0.728, Root Cause Acc: 0.712
Val   - Loss: 0.3086, Pattern Acc: 0.800, Root Cause Acc: 0.800
LR: 0.000098

Epoch 13/30
Train - Loss: 0.2852, Pattern Acc: 0.780, Root Cause Acc: 0.770
Val   - Loss: 0.2515, Pattern Acc: 0.875, Root Cause Acc: 0.825
LR: 0.000095
Saved checkpoint: checkpoints\\checkpoint_epoch_13.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 14/30
Train - Loss: 0.2235, Pattern Acc: 0.864, Root Cause Acc: 0.832
Val   - Loss: 0.1691, Pattern Acc: 0.950, Root Cause Acc: 0.900
LR: 0.000091
Saved checkpoint: checkpoints\\checkpoint_epoch_14.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 15/30
Train - Loss: 0.1895, Pattern Acc: 0.864, Root Cause Acc: 0.838
Val   - Loss: 0.1191, Pattern Acc: 0.950, Root Cause Acc: 0.925
LR: 0.000086
Saved checkpoint: checkpoints\\checkpoint_epoch_15.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 16/30
Train - Loss: 0.1307, Pattern Acc: 0.895, Root Cause Acc: 0.901
Val   - Loss: 0.0805, Pattern Acc: 0.975, Root Cause Acc: 0.975
LR: 0.000080

Epoch 17/30
Train - Loss: 0.1135, Pattern Acc: 0.880, Root Cause Acc: 0.890
Val   - Loss: 0.0511, Pattern Acc: 1.000, Root Cause Acc: 0.975
LR: 0.000073
Saved checkpoint: checkpoints\\checkpoint_epoch_17.pth
⭐ Saved best model: checkpoints\\best_model.pth

Epoch 18/30
Train - Loss: 0.0850, Pattern Acc: 0.911, Root Cause Acc: 0.953
Val   - Loss: 0.0285, Pattern Acc: 0.975, Root Cause Acc: 0.950
LR: 0.000066

Epoch 19/30
Train - Loss: 0.0707, Pattern Acc: 0.942, Root Cause Acc: 0.916
Val   - Loss: 0.0192, Pattern Acc: 0.975, Root Cause Acc: 0.975
LR: 0.000058

Epoch 20/30
Train - Loss: 0.0497, Pattern Acc: 0.953, Root Cause Acc: 0.927
Val   - Loss: -0.0018, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000051

Epoch 21/30
Train - Loss: 0.0116, Pattern Acc: 0.979, Root Cause Acc: 0.969
Val   - Loss: -0.0055, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000043

Epoch 22/30
Train - Loss: 0.0163, Pattern Acc: 0.953, Root Cause Acc: 0.948
Val   - Loss: -0.0159, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000035

Epoch 23/30
Train - Loss: 0.0257, Pattern Acc: 0.937, Root Cause Acc: 0.948
Val   - Loss: -0.0272, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000028

Epoch 24/30
Train - Loss: -0.0092, Pattern Acc: 0.969, Root Cause Acc: 0.979
Val   - Loss: -0.0244, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000021

Epoch 25/30
Train - Loss: 0.0102, Pattern Acc: 0.927, Root Cause Acc: 0.937
Val   - Loss: -0.0348, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000015

Epoch 26/30
Train - Loss: 0.0025, Pattern Acc: 0.963, Root Cause Acc: 0.979
Val   - Loss: -0.0368, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000010

Epoch 27/30
Train - Loss: -0.0186, Pattern Acc: 0.974, Root Cause Acc: 0.984
Val   - Loss: -0.0304, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000006

Epoch 28/30
Train - Loss: -0.0060, Pattern Acc: 0.969, Root Cause Acc: 0.979
Val   - Loss: -0.0385, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000003

Epoch 29/30
Train - Loss: 0.0035, Pattern Acc: 0.927, Root Cause Acc: 0.948
Val   - Loss: -0.0366, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000002

Epoch 30/30
Train - Loss: -0.0147, Pattern Acc: 0.984, Root Cause Acc: 0.984
Val   - Loss: -0.0301, Pattern Acc: 1.000, Root Cause Acc: 1.000
LR: 0.000100
"""

def parse_training_log():
    """Parse training log and extract structured data"""
    
    metrics_history = []
    log_lines = []
    
    # Split log into lines
    lines = TRAINING_LOG.strip().split('\n')
    
    current_epoch_data = {}
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # Parse epoch number
        epoch_match = re.search(r'Epoch (\d+)/(\d+)', line)
        if epoch_match:
            if current_epoch_data:
                metrics_history.append(current_epoch_data)
            
            current_epoch_data = {
                'epoch': int(epoch_match.group(1)),
                'total_epochs': int(epoch_match.group(2)),
                'timestamp': datetime.utcnow().isoformat()
            }
            log_lines.append(f"[Epoch {epoch_match.group(1)}/{epoch_match.group(2)}]")
            continue
        
        # Parse train metrics
        train_match = re.search(r'Train - Loss: ([\d.-]+), Pattern Acc: ([\d.]+), Root Cause Acc: ([\d.]+)', line)
        if train_match:
            current_epoch_data['train_loss'] = float(train_match.group(1))
            current_epoch_data['train_pattern_acc'] = float(train_match.group(2))
            current_epoch_data['train_root_cause_acc'] = float(train_match.group(3))
            log_lines.append(f"  Train - Loss: {train_match.group(1)}, Pattern Acc: {float(train_match.group(2))*100:.1f}%, Root Cause Acc: {float(train_match.group(3))*100:.1f}%")
            continue
        
        # Parse val metrics
        val_match = re.search(r'Val\s+-\s+Loss: ([\d.-]+), Pattern Acc: ([\d.]+), Root Cause Acc: ([\d.]+)', line)
        if val_match:
            current_epoch_data['val_loss'] = float(val_match.group(1))
            current_epoch_data['val_pattern_acc'] = float(val_match.group(2))
            current_epoch_data['val_root_cause_acc'] = float(val_match.group(3))
            log_lines.append(f"  Val   - Loss: {val_match.group(1)}, Pattern Acc: {float(val_match.group(2))*100:.1f}%, Root Cause Acc: {float(val_match.group(3))*100:.1f}%")
            continue
        
        # Parse learning rate
        lr_match = re.search(r'LR: ([\d.]+)', line)
        if lr_match:
            current_epoch_data['learning_rate'] = float(lr_match.group(1))
            log_lines.append(f"  LR: {lr_match.group(1)}")
            continue
        
        # Parse checkpoint saves
        if 'Saved checkpoint' in line or 'Saved best model' in line:
            log_lines.append(f"  {line}")
    
    # Add last epoch
    if current_epoch_data:
        metrics_history.append(current_epoch_data)
    
    return metrics_history, log_lines

def create_training_status(metrics_history):
    """Create current training status"""
    if not metrics_history:
        return {}
    
    latest = metrics_history[-1]
    
    # Find best epoch
    best_epoch = max(metrics_history, key=lambda x: x.get('val_pattern_acc', 0))
    
    status = {
        'job_id': 'training_20260118',
        'status': 'completed',
        'model_architecture': 'EfficientNet-B3',
        'dataset_size': 273,
        'batch_size': 8,
        'start_time': '2026-01-18T10:00:00Z',
        'end_time': datetime.utcnow().isoformat(),
        'current_epoch': latest['epoch'],
        'total_epochs': latest['total_epochs'],
        'progress_percentage': (latest['epoch'] / latest['total_epochs']) * 100,
        'current_metrics': {
            'train_loss': latest.get('train_loss', 0),
            'train_pattern_acc': latest.get('train_pattern_acc', 0),
            'train_root_cause_acc': latest.get('train_root_cause_acc', 0),
            'val_loss': latest.get('val_loss', 0),
            'val_pattern_acc': latest.get('val_pattern_acc', 0),
            'val_root_cause_acc': latest.get('val_root_cause_acc', 0),
            'learning_rate': latest.get('learning_rate', 0)
        },
        'best_metrics': {
            'epoch': best_epoch['epoch'],
            'val_pattern_acc': best_epoch.get('val_pattern_acc', 0),
            'val_root_cause_acc': best_epoch.get('val_root_cause_acc', 0),
            'val_loss': best_epoch.get('val_loss', 0)
        },
        'metrics_history': metrics_history
    }
    
    return status

def main():
    """Main function"""
    print("="*80)
    print("PARSING TRAINING LOG")
    print("="*80)
    
    # Parse log
    print("\n1. Parsing training log...")
    metrics_history, log_lines = parse_training_log()
    print(f"   Parsed {len(metrics_history)} epochs")
    
    # Create status
    print("\n2. Creating training status...")
    status = create_training_status(metrics_history)
    
    # Save metrics history
    metrics_file = 'logs/training_metrics.json'
    print(f"\n3. Saving metrics to {metrics_file}...")
    with open(metrics_file, 'w') as f:
        json.dump(metrics_history, f, indent=2)
    
    # Save training status
    status_file = 'logs/training_status.json'
    print(f"\n4. Saving status to {status_file}...")
    with open(status_file, 'w') as f:
        json.dump(status, f, indent=2)
    
    # Save formatted log
    log_file = 'logs/training_current.log'
    print(f"\n5. Saving formatted log to {log_file}...")
    with open(log_file, 'w', encoding='utf-8') as f:
        for line in log_lines:
            f.write(line + '\n')
    
    # Print summary
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    print(f"\nTotal Epochs: {len(metrics_history)}")
    print(f"Final Pattern Accuracy: {status['current_metrics']['val_pattern_acc']*100:.1f}%")
    print(f"Final Root Cause Accuracy: {status['current_metrics']['val_root_cause_acc']*100:.1f}%")
    print(f"Best Pattern Accuracy: {status['best_metrics']['val_pattern_acc']*100:.1f}% (Epoch {status['best_metrics']['epoch']})")
    
    print("\n✅ Training data parsed and saved successfully!")
    print("\nFiles created:")
    print(f"  - {metrics_file}")
    print(f"  - {status_file}")
    print(f"  - {log_file}")
    
    print("\n" + "="*80)

if __name__ == '__main__':
    main()
