"""
Test script to verify Flask application setup
Run this after installing dependencies to ensure everything is configured correctly
"""
import sys
import os

def test_imports():
    """Test if all required packages can be imported"""
    print("Testing imports...")
    try:
        import flask
        print("✓ Flask imported successfully")
        
        import flask_cors
        print("✓ Flask-CORS imported successfully")
        
        import numpy
        print("✓ NumPy imported successfully")
        
        import pandas
        print("✓ Pandas imported successfully")
        
        import PIL
        print("✓ Pillow imported successfully")
        
        import psutil
        print("✓ psutil imported successfully")
        
        import filelock
        print("✓ filelock imported successfully")
        
        print("\n✅ All imports successful!")
        return True
    except ImportError as e:
        print(f"\n❌ Import failed: {e}")
        return False


def test_directories():
    """Test if required directories exist or can be created"""
    print("\nTesting directories...")
    dirs = ['data/wafer_images', 'data/models', 'data/temp', 'data/metadata', 'logs']
    
    for dir_path in dirs:
        try:
            os.makedirs(dir_path, exist_ok=True)
            print(f"✓ Directory created/verified: {dir_path}")
        except Exception as e:
            print(f"❌ Failed to create directory {dir_path}: {e}")
            return False
    
    print("\n✅ All directories created successfully!")
    return True


def test_flask_app():
    """Test if Flask app can be created"""
    print("\nTesting Flask application...")
    try:
        from app import create_app
        app = create_app('development')
        print(f"✓ Flask app created successfully")
        print(f"✓ App name: {app.name}")
        print(f"✓ Debug mode: {app.debug}")
        print(f"✓ Upload folder: {app.config['UPLOAD_FOLDER']}")
        print(f"✓ Metadata folder: {app.config['METADATA_FOLDER']}")
        print("\n✅ Flask application test passed!")
        return True
    except Exception as e:
        print(f"\n❌ Flask app creation failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_json_storage():
    """Test JSON storage utility"""
    print("\nTesting JSON storage...")
    try:
        from app.utils.json_storage import JSONStorage
        storage = JSONStorage('data/metadata')
        
        # Test write
        test_data = [{"id": "test1", "name": "Test"}]
        storage.write('test.json', test_data)
        print("✓ JSON write successful")
        
        # Test read
        data = storage.read('test.json')
        assert len(data) == 1
        print("✓ JSON read successful")
        
        # Clean up
        import os
        if os.path.exists('data/metadata/test.json'):
            os.remove('data/metadata/test.json')
        if os.path.exists('data/metadata/test.json.lock'):
            os.remove('data/metadata/test.json.lock')
        
        print("\n✅ JSON storage test passed!")
        return True
    except Exception as e:
        print(f"\n❌ JSON storage test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests"""
    print("=" * 60)
    print("Wafer Defect API - Setup Verification")
    print("=" * 60)
    
    results = []
    
    # Test imports
    results.append(("Imports", test_imports()))
    
    # Test directories
    results.append(("Directories", test_directories()))
    
    # Test Flask app
    results.append(("Flask App", test_flask_app()))
    
    # Test JSON storage
    results.append(("JSON Storage", test_json_storage()))
    
    # Summary
    print("\n" + "=" * 60)
    print("Test Summary")
    print("=" * 60)
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name}: {status}")
    
    all_passed = all(result[1] for result in results)
    
    if all_passed:
        print("\n🎉 All tests passed! Your setup is ready.")
        print("\nNext steps:")
        print("1. Run: python run.py")
        print("2. Test health endpoint: http://localhost:5000/health")
        print("3. Test API health: http://localhost:5000/api/v1/health")
    else:
        print("\n⚠️  Some tests failed. Please fix the issues above.")
        sys.exit(1)


if __name__ == '__main__':
    main()
