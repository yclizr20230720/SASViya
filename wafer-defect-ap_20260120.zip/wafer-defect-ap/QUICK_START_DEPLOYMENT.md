# Quick Start Deployment Guide
# Wafer Defect Pattern Recognition System

## 🚀 5-Minute Deployment

### Prerequisites
- ✅ Windows Server 2022
- ✅ Python 3.11+ installed
- ✅ Administrator access

---

## Step 1: Extract Files

Extract `wafer-defect-ap` to:
```
C:\Apps\wafer-defect-ap
```

---

## Step 2: Run Installer

Open **Command Prompt as Administrator**:

```cmd
cd C:\Apps\wafer-defect-ap
deploy\install.bat
```

Wait 5-10 minutes for installation to complete.

---

## Step 3: Configure

Edit `.env` file:

```bash
# Change this!
SECRET_KEY=your-secret-key-here

# Add your frontend URL
CORS_ORIGINS=http://localhost:5173,http://your-frontend-server

# GPU or CPU
INFERENCE_DEVICE=cuda  # or 'cpu'
```

---

## Step 4: Test

Start the server:

```cmd
deploy\start_service.bat
```

Test the API:

```cmd
curl http://localhost:5000/api/v1/health
```

Expected response:
```json
{"status": "healthy", "version": "1.0.0"}
```

---

## Step 5: Install as Service (Production)

### Download NSSM

1. Download from: https://nssm.cc/download
2. Extract `nssm.exe` (64-bit)
3. Copy to `deploy\nssm.exe`

### Install Service

```cmd
deploy\install_service.bat
```

Service will start automatically on boot.

---

## ✅ Verification Checklist

- [ ] Python 3.11+ installed
- [ ] Installation completed without errors
- [ ] `.env` file configured
- [ ] Health check passes
- [ ] API responds at http://localhost:5000
- [ ] Service installed (production)
- [ ] Firewall rule added
- [ ] Frontend can connect

---

## 🔧 Common Commands

**Start service:**
```cmd
net start WaferDefectAPI
```

**Stop service:**
```cmd
net stop WaferDefectAPI
```

**Check status:**
```cmd
sc query WaferDefectAPI
```

**View logs:**
```cmd
type logs\app.log
```

**Backup data:**
```cmd
deploy\backup.bat
```

**Health check:**
```cmd
python deploy\health_check.py
```

---

## 📁 Important Files

| File | Purpose |
|------|---------|
| `.env` | Configuration |
| `logs\app.log` | Application logs |
| `data\metadata\*.json` | Data storage |
| `checkpoints\best_model.pth` | Trained model |

---

## 🆘 Troubleshooting

### Service won't start

```cmd
type logs\service_stderr.log
```

### Port 5000 in use

```cmd
netstat -ano | findstr :5000
```

### Python not found

Add Python to PATH:
```
System Properties → Environment Variables → Path
```

### Need help?

Run health check:
```cmd
python deploy\health_check.py
```

See full guide: `DEPLOYMENT_GUIDE.md`

---

## 📞 Next Steps

1. ✅ Deploy backend (you are here)
2. ⏭️ Deploy frontend (`wafer-defect-gui`)
3. ⏭️ Train model (`scripts\train_model.py`)
4. ⏭️ Configure monitoring
5. ⏭️ Set up backups

---

**Ready to deploy!** 🎉

For detailed instructions, see: `DEPLOYMENT_GUIDE.md`
