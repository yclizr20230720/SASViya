"""
Generate synthetic augmented wafer images to increase dataset size

This script applies heavy augmentation to existing wafer images
to create a larger training dataset.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import json
import cv2
import numpy as np
from PIL import Image
import argparse
from tqdm import tqdm

def augment_image(image_path, num_augmentations=10):
    """Generate augmented versions of an image"""
    # Load image
    img = cv2.imread(str(image_path))
    if img is None:
        print(f"Warning: Could not load {image_path}")
        return []
    
    augmented_images = []
    
    for i in range(num_augmentations):
        aug_img = img.copy()
        
        # Random rotation
        angle = np.random.randint(0, 360)
        h, w = aug_img.shape[:2]
        M = cv2.getRotationMatrix2D((w/2, h/2), angle, 1.0)
        aug_img = cv2.warpAffine(aug_img, M, (w, h))
        
        # Random flip
        if np.random.rand() > 0.5:
            aug_img = cv2.flip(aug_img, 1)  # Horizontal flip
        if np.random.rand() > 0.5:
            aug_img = cv2.flip(aug_img, 0)  # Vertical flip
        
        # Random brightness/contrast
        alpha = np.random.uniform(0.8, 1.2)  # Contrast
        beta = np.random.randint(-20, 20)     # Brightness
        aug_img = cv2.convertScaleAbs(aug_img, alpha=alpha, beta=beta)
        
        # Random noise
        if np.random.rand() > 0.5:
            noise = np.random.normal(0, 5, aug_img.shape).astype(np.uint8)
            aug_img = cv2.add(aug_img, noise)
        
        augmented_images.append(aug_img)
    
    return augmented_images

def main():
    parser = argparse.ArgumentParser(description='Generate synthetic augmented wafer data')
    parser.add_argument('--input', type=str, default='data/processed/labeled_wafers.json',
                        help='Input labeled dataset JSON')
    parser.add_argument('--output', type=str, default='data/processed/augmented_wafers.json',
                        help='Output augmented dataset JSON')
    parser.add_argument('--augmentations_per_image', type=int, default=10,
                        help='Number of augmentations per image')
    parser.add_argument('--output_dir', type=str, default='data/wafer_images/augmented',
                        help='Directory to save augmented images')
    
    args = parser.parse_args()
    
    print("="*80)
    print("SYNTHETIC DATA GENERATION")
    print("="*80)
    
    # Load original dataset
    print(f"\n📂 Loading dataset from {args.input}...")
    with open(args.input, 'r') as f:
        original_data = json.load(f)
    
    print(f"   Original samples: {len(original_data)}")
    print(f"   Augmentations per image: {args.augmentations_per_image}")
    print(f"   Expected total: {len(original_data) * (args.augmentations_per_image + 1)}")
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Generate augmented dataset
    augmented_data = []
    
    # Add original images
    augmented_data.extend(original_data)
    
    print(f"\n🔄 Generating augmented images...")
    for record in tqdm(original_data, desc="Processing"):
        image_path = Path(record['image_path'])
        
        if not image_path.exists():
            print(f"\nWarning: Image not found: {image_path}")
            continue
        
        # Generate augmentations
        aug_images = augment_image(image_path, args.augmentations_per_image)
        
        # Save augmented images and create records
        for idx, aug_img in enumerate(aug_images):
            # Create filename
            aug_filename = f"{image_path.stem}_aug{idx}{image_path.suffix}"
            aug_path = output_dir / aug_filename
            
            # Save image
            cv2.imwrite(str(aug_path), aug_img)
            
            # Create record
            aug_record = record.copy()
            aug_record['wafer_id'] = f"{record['wafer_id']}_aug{idx}"
            aug_record['image_filename'] = aug_filename
            aug_record['image_path'] = str(aug_path.absolute())
            aug_record['is_augmented'] = True
            aug_record['original_wafer_id'] = record['wafer_id']
            
            augmented_data.append(aug_record)
    
    # Save augmented dataset
    print(f"\n💾 Saving augmented dataset to {args.output}...")
    with open(args.output, 'w') as f:
        json.dump(augmented_data, f, indent=2)
    
    print(f"\n✅ Synthetic data generation completed!")
    print(f"   Original samples: {len(original_data)}")
    print(f"   Augmented samples: {len(augmented_data) - len(original_data)}")
    print(f"   Total samples: {len(augmented_data)}")
    
    # Print pattern distribution
    pattern_counts = {}
    for record in augmented_data:
        pattern = record['pattern_class']
        pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
    
    print(f"\n📊 Pattern Distribution:")
    for pattern, count in sorted(pattern_counts.items()):
        print(f"   {pattern}: {count}")
    
    print(f"\n📝 Next step:")
    print(f"   python scripts/run_full_training_pipeline.py --data_file {args.output}")

if __name__ == '__main__':
    main()
