"""
Train Wafer Defect Model with GAN-based Data Augmentation

This script:
1. Trains a GAN on real wafer data
2. Generates synthetic wafer maps
3. Combines real + synthetic data
4. Trains the main classification model

Usage:
    python scripts/train_with_gan_augmentation.py --gan-epochs 100 --model-epochs 100 --synthetic-ratio 0.3
"""
import sys
import os
from pathlib import Path

# Add app directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import torch
from torch.utils.data import DataLoader, ConcatDataset
import argparse
import json
from datetime import datetime

from app.ml.gan import WaferGAN, train_gan
from app.ml.dataset import WaferDefectDataset
from app.ml.train import WaferTrainer
from app.ml.model import WaferDefectModel, PATTERN_CLASSES, ROOT_CAUSE_CLASSES


def train_gan_phase(args):
    """Phase 1: Train GAN on real data"""
    print("\n" + "="*60)
    print("PHASE 1: TRAINING GAN")
    print("="*60)
    
    # Load real training data
    data_dir = Path(args.data_dir)
    train_metadata = data_dir / 'splits' / 'train_metadata.json'
    
    if not train_metadata.exists():
        print(f"✗ Training metadata not found: {train_metadata}")
        print("Please run data preparation first")
        return None
    
    train_dataset = WaferDefectDataset(
        metadata_file=str(train_metadata),
        transform=None  # No augmentation for GAN training
    )
    
    print(f"Training dataset size: {len(train_dataset)}")
    
    # Create data loader
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.gan_batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True if args.device == 'cuda' else False
    )
    
    # Initialize GAN
    print("\nInitializing GAN...")
    gan = WaferGAN(
        noise_dim=100,
        num_patterns=len(PATTERN_CLASSES),
        img_size=224,
        device=args.device
    )
    
    # Train GAN
    print("\nTraining GAN...")
    gan_checkpoint_dir = Path(args.checkpoint_dir) / 'gan'
    train_gan(
        gan=gan,
        dataloader=train_loader,
        num_epochs=args.gan_epochs,
        n_critic=args.n_critic,
        lambda_gp=args.lambda_gp,
        save_interval=args.save_interval,
        checkpoint_dir=str(gan_checkpoint_dir)
    )
    
    print("\n✓ GAN training complete")
    return gan


def generate_synthetic_data(gan, args):
    """Phase 2: Generate synthetic wafer maps"""
    print("\n" + "="*60)
    print("PHASE 2: GENERATING SYNTHETIC DATA")
    print("="*60)
    
    # Load training data to analyze class distribution
    data_dir = Path(args.data_dir)
    train_metadata_file = data_dir / 'splits' / 'train_metadata.json'
    
    with open(train_metadata_file, 'r') as f:
        train_metadata = json.load(f)
    
    # Count samples per class
    class_counts = {}
    for item in train_metadata:
        pattern = item.get('pattern_class', 'Unknown')
        class_counts[pattern] = class_counts.get(pattern, 0) + 1
    
    print("\nReal data distribution:")
    for pattern, count in sorted(class_counts.items()):
        print(f"  {pattern}: {count}")
    
    # Calculate how many synthetic samples to generate per class
    total_real = len(train_metadata)
    total_synthetic = int(total_real * args.synthetic_ratio)
    
    print(f"\nGenerating {total_synthetic} synthetic samples...")
    print(f"Synthetic ratio: {args.synthetic_ratio:.1%}")
    
    # Generate balanced synthetic data
    synthetic_dir = Path(args.synthetic_dir)
    synthetic_dir.mkdir(parents=True, exist_ok=True)
    
    synthetic_metadata = []
    samples_per_class = total_synthetic // len(PATTERN_CLASSES)
    
    for pattern_idx, pattern_name in enumerate(PATTERN_CLASSES):
        print(f"\nGenerating {samples_per_class} samples for {pattern_name}...")
        
        # Generate in batches
        batch_size = min(32, samples_per_class)
        num_batches = (samples_per_class + batch_size - 1) // batch_size
        
        for batch_idx in range(num_batches):
            current_batch_size = min(batch_size, samples_per_class - batch_idx * batch_size)
            
            # Prepare conditions
            pattern_labels = torch.full((current_batch_size,), pattern_idx, dtype=torch.long, device=args.device)
            defect_density = torch.rand(current_batch_size, 1, device=args.device)
            
            # Generate images
            fake_images = gan.generate(pattern_labels, defect_density, num_samples=current_batch_size)
            
            # Save images
            for i in range(current_batch_size):
                sample_idx = batch_idx * batch_size + i
                density_value = defect_density[i].item()
                
                # Generate filename
                filename = f"synthetic_{pattern_name}_{sample_idx:04d}_{density_value:.3f}.png"
                filepath = synthetic_dir / filename
                
                # Save image
                from PIL import Image
                import numpy as np
                
                img = fake_images[i].permute(1, 2, 0).cpu().numpy()
                img = (img * 255).astype(np.uint8)
                Image.fromarray(img).save(filepath)
                
                # Add to metadata
                synthetic_metadata.append({
                    'image_path': str(filepath),
                    'pattern_class': pattern_name,
                    'root_cause_class': 'Unknown',  # GAN doesn't generate root cause
                    'defect_density': density_value,
                    'is_synthetic': True,
                    'generated_at': datetime.now().isoformat()
                })
        
        print(f"  ✓ Generated {samples_per_class} samples for {pattern_name}")
    
    # Save synthetic metadata
    synthetic_metadata_file = synthetic_dir / 'synthetic_metadata.json'
    with open(synthetic_metadata_file, 'w') as f:
        json.dump(synthetic_metadata, f, indent=2)
    
    print(f"\n✓ Generated {len(synthetic_metadata)} synthetic samples")
    print(f"✓ Saved to: {synthetic_dir}")
    print(f"✓ Metadata: {synthetic_metadata_file}")
    
    return synthetic_metadata_file


def train_model_with_augmentation(synthetic_metadata_file, args):
    """Phase 3: Train classification model with real + synthetic data"""
    print("\n" + "="*60)
    print("PHASE 3: TRAINING CLASSIFICATION MODEL")
    print("="*60)
    
    # Load real training data
    data_dir = Path(args.data_dir)
    train_metadata = data_dir / 'splits' / 'train_metadata.json'
    val_metadata = data_dir / 'splits' / 'val_metadata.json'
    
    # Create datasets
    real_train_dataset = WaferDefectDataset(
        metadata_file=str(train_metadata),
        transform=None  # Augmentation handled by dataset
    )
    
    synthetic_train_dataset = WaferDefectDataset(
        metadata_file=str(synthetic_metadata_file),
        transform=None
    )
    
    val_dataset = WaferDefectDataset(
        metadata_file=str(val_metadata),
        transform=None
    )
    
    # Combine real and synthetic data
    combined_train_dataset = ConcatDataset([real_train_dataset, synthetic_train_dataset])
    
    print(f"\nDataset sizes:")
    print(f"  Real training: {len(real_train_dataset)}")
    print(f"  Synthetic training: {len(synthetic_train_dataset)}")
    print(f"  Combined training: {len(combined_train_dataset)}")
    print(f"  Validation: {len(val_dataset)}")
    
    # Create data loaders
    train_loader = DataLoader(
        combined_train_dataset,
        batch_size=args.model_batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True if args.device == 'cuda' else False
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.model_batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True if args.device == 'cuda' else False
    )
    
    # Initialize model
    print("\nInitializing classification model...")
    model = WaferDefectModel(
        num_pattern_classes=len(PATTERN_CLASSES),
        num_root_cause_classes=len(ROOT_CAUSE_CLASSES)
    )
    
    # Initialize trainer
    trainer = WaferTrainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        device=args.device,
        learning_rate=args.model_lr,
        checkpoint_dir=args.checkpoint_dir
    )
    
    # Train model
    print("\nTraining classification model...")
    trainer.train(
        num_epochs=args.model_epochs,
        early_stopping_patience=args.patience
    )
    
    print("\n✓ Model training complete")
    print(f"✓ Best model saved to: {args.checkpoint_dir}/best_model.pth")


def main():
    parser = argparse.ArgumentParser(description='Train with GAN-based Data Augmentation')
    
    # Data arguments
    parser.add_argument('--data-dir', type=str, default='data/processed',
                        help='Directory containing processed training data')
    parser.add_argument('--synthetic-dir', type=str, default='data/synthetic',
                        help='Directory to save synthetic data')
    parser.add_argument('--synthetic-ratio', type=float, default=0.3,
                        help='Ratio of synthetic to real data (0.3 = 30%)')
    
    # GAN training arguments
    parser.add_argument('--gan-epochs', type=int, default=100,
                        help='Number of GAN training epochs')
    parser.add_argument('--gan-batch-size', type=int, default=32,
                        help='Batch size for GAN training')
    parser.add_argument('--n-critic', type=int, default=5,
                        help='Critic iterations per generator iteration')
    parser.add_argument('--lambda-gp', type=float, default=10.0,
                        help='Gradient penalty weight')
    
    # Model training arguments
    parser.add_argument('--model-epochs', type=int, default=100,
                        help='Number of model training epochs')
    parser.add_argument('--model-batch-size', type=int, default=32,
                        help='Batch size for model training')
    parser.add_argument('--model-lr', type=float, default=0.0001,
                        help='Learning rate for model training')
    parser.add_argument('--patience', type=int, default=10,
                        help='Early stopping patience')
    
    # Checkpoint arguments
    parser.add_argument('--checkpoint-dir', type=str, default='checkpoints',
                        help='Directory to save checkpoints')
    parser.add_argument('--save-interval', type=int, default=10,
                        help='Save GAN checkpoint every N epochs')
    parser.add_argument('--skip-gan-training', action='store_true',
                        help='Skip GAN training and use existing checkpoint')
    parser.add_argument('--gan-checkpoint', type=str, default=None,
                        help='Path to existing GAN checkpoint')
    
    # Device arguments
    parser.add_argument('--device', type=str, default='cuda',
                        choices=['cuda', 'cpu'],
                        help='Device to use for training')
    parser.add_argument('--num-workers', type=int, default=4,
                        help='Number of data loading workers')
    
    args = parser.parse_args()
    
    # Set device
    if args.device == 'cuda' and not torch.cuda.is_available():
        print("CUDA not available, using CPU")
        args.device = 'cpu'
    
    print("="*60)
    print("TRAINING WITH GAN-BASED DATA AUGMENTATION")
    print("="*60)
    print(f"Device: {args.device}")
    print(f"GAN epochs: {args.gan_epochs}")
    print(f"Model epochs: {args.model_epochs}")
    print(f"Synthetic ratio: {args.synthetic_ratio:.1%}")
    print("="*60)
    
    # Phase 1: Train GAN (or load existing)
    if args.skip_gan_training and args.gan_checkpoint:
        print(f"\nLoading existing GAN checkpoint: {args.gan_checkpoint}")
        gan = WaferGAN(
            noise_dim=100,
            num_patterns=len(PATTERN_CLASSES),
            img_size=224,
            device=args.device
        )
        gan.load(args.gan_checkpoint)
    else:
        gan = train_gan_phase(args)
        if gan is None:
            print("\n✗ GAN training failed")
            return 1
    
    # Phase 2: Generate synthetic data
    synthetic_metadata_file = generate_synthetic_data(gan, args)
    
    # Phase 3: Train classification model
    train_model_with_augmentation(synthetic_metadata_file, args)
    
    print("\n" + "="*60)
    print("TRAINING COMPLETE")
    print("="*60)
    print("\nAll phases completed successfully!")
    print(f"  ✓ GAN trained and saved")
    print(f"  ✓ Synthetic data generated: {args.synthetic_dir}")
    print(f"  ✓ Classification model trained: {args.checkpoint_dir}/best_model.pth")
    print()
    
    return 0


if __name__ == '__main__':
    exit(main())
