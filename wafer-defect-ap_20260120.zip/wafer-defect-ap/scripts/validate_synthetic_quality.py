"""
Validate Quality of Synthetic Wafer Maps

Implements quality metrics:
- FID (Fréchet Inception Distance)
- SSIM (Structural Similarity Index)
- Pattern Classifier Validation
- Physical Plausibility Checks

Usage:
    python scripts/validate_synthetic_quality.py --real-dir data/wafer_images --synthetic-dir data/synthetic
"""
import sys
import os
from pathlib import Path

# Add app directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import numpy as np
from PIL import Image
from scipy import linalg
from skimage.metrics import structural_similarity as ssim
import argparse
from typing import List, Tuple

from app.ml.preprocessing import WaferPreprocessor
from app.ml.model import WaferDefectModel, PATTERN_CLASSES


class ImageDataset(Dataset):
    """Simple image dataset"""
    
    def __init__(self, image_dir: str, preprocessor: WaferPreprocessor):
        self.image_paths = list(Path(image_dir).glob('*.png')) + list(Path(image_dir).glob('*.jpg'))
        self.preprocessor = preprocessor
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        image_path = str(self.image_paths[idx])
        image = self.preprocessor.preprocess_image(image_path)
        return image


def calculate_fid(real_features: np.ndarray, fake_features: np.ndarray) -> float:
    """
    Calculate Fréchet Inception Distance (FID)
    
    Args:
        real_features: Features from real images (N, D)
        fake_features: Features from fake images (M, D)
    
    Returns:
        FID score (lower is better)
    """
    # Calculate mean and covariance
    mu_real = np.mean(real_features, axis=0)
    mu_fake = np.mean(fake_features, axis=0)
    
    sigma_real = np.cov(real_features, rowvar=False)
    sigma_fake = np.cov(fake_features, rowvar=False)
    
    # Calculate FID
    diff = mu_real - mu_fake
    
    # Product might be almost singular
    covmean, _ = linalg.sqrtm(sigma_real.dot(sigma_fake), disp=False)
    
    if not np.isfinite(covmean).all():
        print("Warning: FID calculation produced singular product; adding epsilon to diagonal")
        offset = np.eye(sigma_real.shape[0]) * 1e-6
        covmean = linalg.sqrtm((sigma_real + offset).dot(sigma_fake + offset))
    
    # Numerical error might give slight imaginary component
    if np.iscomplexobj(covmean):
        covmean = covmean.real
    
    fid = diff.dot(diff) + np.trace(sigma_real + sigma_fake - 2 * covmean)
    
    return float(fid)


def extract_features(
    model: nn.Module,
    dataloader: DataLoader,
    device: str = 'cuda'
) -> np.ndarray:
    """
    Extract features from images using model
    
    Args:
        model: Feature extraction model
        dataloader: Data loader
        device: Device to use
    
    Returns:
        Feature array (N, D)
    """
    model.eval()
    features = []
    
    with torch.no_grad():
        for images in dataloader:
            images = images.to(device)
            
            # Extract features (use model's feature extractor)
            if hasattr(model, 'get_embeddings'):
                feats = model.get_embeddings(images)
            else:
                feats = model(images)[0]  # Use pattern logits as features
            
            features.append(feats.cpu().numpy())
    
    return np.concatenate(features, axis=0)


def calculate_ssim_score(
    real_images: List[np.ndarray],
    fake_images: List[np.ndarray]
) -> float:
    """
    Calculate average SSIM between real and fake images
    
    Args:
        real_images: List of real images
        fake_images: List of fake images
    
    Returns:
        Average SSIM score (higher is better, max 1.0)
    """
    ssim_scores = []
    
    # Compare each fake image with all real images
    for fake_img in fake_images[:min(100, len(fake_images))]:  # Limit to 100 for speed
        max_ssim = 0
        for real_img in real_images:
            score = ssim(real_img, fake_img, multichannel=True, channel_axis=2)
            max_ssim = max(max_ssim, score)
        ssim_scores.append(max_ssim)
    
    return np.mean(ssim_scores)


def validate_pattern_classifier(
    model: WaferDefectModel,
    dataloader: DataLoader,
    device: str = 'cuda'
) -> Tuple[float, dict]:
    """
    Validate synthetic images using pattern classifier
    
    Args:
        model: Trained pattern classifier
        dataloader: Data loader for synthetic images
        device: Device to use
    
    Returns:
        Average confidence and pattern distribution
    """
    model.eval()
    
    confidences = []
    pattern_counts = {pattern: 0 for pattern in PATTERN_CLASSES}
    
    with torch.no_grad():
        for images in dataloader:
            images = images.to(device)
            
            # Get predictions
            pattern_logits, _ = model(images)
            pattern_probs = torch.softmax(pattern_logits, dim=1)
            
            # Get max confidence and predicted class
            max_probs, pred_classes = pattern_probs.max(dim=1)
            
            confidences.extend(max_probs.cpu().numpy())
            
            for pred_class in pred_classes:
                pattern = PATTERN_CLASSES[pred_class.item()]
                pattern_counts[pattern] += 1
    
    avg_confidence = np.mean(confidences)
    
    return avg_confidence, pattern_counts


def main():
    parser = argparse.ArgumentParser(description='Validate Synthetic Wafer Map Quality')
    
    # Data arguments
    parser.add_argument('--real-dir', type=str, required=True,
                        help='Directory containing real wafer images')
    parser.add_argument('--synthetic-dir', type=str, required=True,
                        help='Directory containing synthetic wafer images')
    
    # Model arguments
    parser.add_argument('--model-checkpoint', type=str, default='checkpoints/best_model.pth',
                        help='Path to trained pattern classifier')
    
    # Validation arguments
    parser.add_argument('--batch-size', type=int, default=32,
                        help='Batch size')
    parser.add_argument('--num-samples', type=int, default=None,
                        help='Number of samples to use (default: all)')
    
    # Device arguments
    parser.add_argument('--device', type=str, default='cuda',
                        choices=['cuda', 'cpu'],
                        help='Device to use')
    
    args = parser.parse_args()
    
    # Set device
    if args.device == 'cuda' and not torch.cuda.is_available():
        print("CUDA not available, using CPU")
        args.device = 'cpu'
    
    print("="*60)
    print("SYNTHETIC WAFER MAP QUALITY VALIDATION")
    print("="*60)
    print(f"Real images: {args.real_dir}")
    print(f"Synthetic images: {args.synthetic_dir}")
    print(f"Model checkpoint: {args.model_checkpoint}")
    print(f"Device: {args.device}")
    print("="*60)
    
    # Initialize preprocessor
    preprocessor = WaferPreprocessor(target_size=(224, 224))
    
    # Load datasets
    print("\nLoading datasets...")
    real_dataset = ImageDataset(args.real_dir, preprocessor)
    fake_dataset = ImageDataset(args.synthetic_dir, preprocessor)
    
    print(f"Real images: {len(real_dataset)}")
    print(f"Synthetic images: {len(fake_dataset)}")
    
    # Create data loaders
    real_loader = DataLoader(real_dataset, batch_size=args.batch_size, shuffle=False)
    fake_loader = DataLoader(fake_dataset, batch_size=args.batch_size, shuffle=False)
    
    # Load pattern classifier
    print("\nLoading pattern classifier...")
    model = WaferDefectModel(
        num_pattern_classes=len(PATTERN_CLASSES),
        num_root_cause_classes=8
    )
    
    checkpoint = torch.load(args.model_checkpoint, map_location=args.device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.to(args.device)
    model.eval()
    
    # 1. Calculate FID
    print("\n1. Calculating FID (Fréchet Inception Distance)...")
    print("   Extracting features from real images...")
    real_features = extract_features(model, real_loader, args.device)
    
    print("   Extracting features from synthetic images...")
    fake_features = extract_features(model, fake_loader, args.device)
    
    fid_score = calculate_fid(real_features, fake_features)
    print(f"   ✓ FID Score: {fid_score:.2f} (lower is better, <50 is good)")
    
    # 2. Validate with pattern classifier
    print("\n2. Validating with Pattern Classifier...")
    avg_confidence, pattern_dist = validate_pattern_classifier(model, fake_loader, args.device)
    
    print(f"   ✓ Average Confidence: {avg_confidence:.4f}")
    print("   ✓ Pattern Distribution:")
    for pattern, count in sorted(pattern_dist.items(), key=lambda x: x[1], reverse=True):
        if count > 0:
            percentage = count / len(fake_dataset) * 100
            print(f"      {pattern}: {count} ({percentage:.1f}%)")
    
    # 3. Physical plausibility checks
    print("\n3. Physical Plausibility Checks...")
    
    # Check if images are in valid range
    valid_range = True
    for images in fake_loader:
        if images.min() < 0 or images.max() > 1:
            valid_range = False
            break
    
    print(f"   ✓ Valid pixel range [0, 1]: {'Yes' if valid_range else 'No'}")
    
    # Summary
    print("\n" + "="*60)
    print("QUALITY VALIDATION SUMMARY")
    print("="*60)
    print(f"FID Score: {fid_score:.2f}")
    print(f"Average Classifier Confidence: {avg_confidence:.4f}")
    print(f"Valid Pixel Range: {'Yes' if valid_range else 'No'}")
    
    # Quality assessment
    print("\nQuality Assessment:")
    if fid_score < 50:
        print("  ✓ FID Score: EXCELLENT (< 50)")
    elif fid_score < 100:
        print("  ⚠ FID Score: GOOD (50-100)")
    else:
        print("  ✗ FID Score: NEEDS IMPROVEMENT (> 100)")
    
    if avg_confidence > 0.7:
        print("  ✓ Classifier Confidence: HIGH (> 0.7)")
    elif avg_confidence > 0.5:
        print("  ⚠ Classifier Confidence: MODERATE (0.5-0.7)")
    else:
        print("  ✗ Classifier Confidence: LOW (< 0.5)")
    
    print("="*60)


if __name__ == '__main__':
    main()
