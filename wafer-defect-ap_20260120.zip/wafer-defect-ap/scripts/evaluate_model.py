"""
Command-line script for evaluating trained model

Usage:
    python scripts/evaluate_model.py --model checkpoints/best_model.pth --data_dir data/processed/test
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import argparse
import torch
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from tqdm import tqdm

from app.ml.model import WaferDefectModel, PATTERN_CLASSES, ROOT_CAUSE_CLASSES
from app.ml.dataset import WaferDefectDataset
from torch.utils.data import DataLoader


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Evaluate trained model')
    
    parser.add_argument('--model', type=str, required=True,
                       help='Path to trained model checkpoint')
    parser.add_argument('--data_dir', type=str, required=True,
                       help='Directory containing test images')
    parser.add_argument('--metadata', type=str, default='test_metadata.json',
                       help='Test metadata filename')
    parser.add_argument('--batch_size', type=int, default=32,
                       help='Batch size')
    parser.add_argument('--device', type=str, default='cuda',
                       choices=['cuda', 'cpu'],
                       help='Device to use')
    parser.add_argument('--output', type=str, default='results',
                       help='Output directory for results')
    parser.add_argument('--confusion_matrix', action='store_true',
                       help='Generate confusion matrix plots')
    parser.add_argument('--per_class_metrics', action='store_true',
                       help='Generate per-class metrics')
    
    return parser.parse_args()


@torch.no_grad()
def evaluate_model(model, test_loader, device):
    """
    Evaluate model on test set
    
    Returns:
        Dictionary with predictions and labels
    """
    model.eval()
    
    pattern_preds = []
    pattern_labels = []
    root_cause_preds = []
    root_cause_labels = []
    
    for images, p_labels, r_labels in tqdm(test_loader, desc='Evaluating'):
        images = images.to(device)
        
        # Forward pass
        p_logits, r_logits = model(images)
        
        # Get predictions
        p_pred = p_logits.argmax(1).cpu().numpy()
        r_pred = r_logits.argmax(1).cpu().numpy()
        
        pattern_preds.extend(p_pred)
        pattern_labels.extend(p_labels.numpy())
        root_cause_preds.extend(r_pred)
        root_cause_labels.extend(r_labels.numpy())
    
    return {
        'pattern_preds': np.array(pattern_preds),
        'pattern_labels': np.array(pattern_labels),
        'root_cause_preds': np.array(root_cause_preds),
        'root_cause_labels': np.array(root_cause_labels)
    }


def plot_confusion_matrix(cm, class_names, output_path, title):
    """Plot and save confusion matrix"""
    plt.figure(figsize=(12, 10))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=class_names,
                yticklabels=class_names)
    plt.title(title)
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved confusion matrix: {output_path}")


def main():
    """Main evaluation function"""
    args = parse_args()
    
    # Set device
    device = args.device if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")
    
    # Load model
    print(f"\nLoading model from {args.model}...")
    checkpoint = torch.load(args.model, map_location=device)
    
    model = WaferDefectModel(
        num_pattern_classes=len(PATTERN_CLASSES),
        num_root_cause_classes=len(ROOT_CAUSE_CLASSES)
    )
    model.load_state_dict(checkpoint['model_state_dict'])
    model.to(device)
    model.eval()
    
    print(f"  Epoch: {checkpoint.get('epoch', 'unknown')}")
    print(f"  Best val accuracy: {checkpoint.get('best_val_acc', 'unknown'):.3f}")
    
    # Load test dataset
    print(f"\nLoading test dataset from {args.data_dir}...")
    test_dataset = WaferDefectDataset(
        data_dir=args.data_dir,
        metadata_file=os.path.join(args.data_dir, args.metadata)
    )
    
    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=4
    )
    
    print(f"  Test samples: {len(test_dataset)}")
    
    # Evaluate
    print("\nEvaluating model...")
    results = evaluate_model(model, test_loader, device)
    
    # Create output directory
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Pattern classification metrics
    print("\n" + "="*80)
    print("PATTERN CLASSIFICATION RESULTS")
    print("="*80)
    
    pattern_report = classification_report(
        results['pattern_labels'],
        results['pattern_preds'],
        target_names=PATTERN_CLASSES,
        digits=3
    )
    print(pattern_report)
    
    # Save pattern report
    with open(output_dir / 'pattern_classification_report.txt', 'w') as f:
        f.write(pattern_report)
    
    # Root cause classification metrics
    print("\n" + "="*80)
    print("ROOT CAUSE CLASSIFICATION RESULTS")
    print("="*80)
    
    root_cause_report = classification_report(
        results['root_cause_labels'],
        results['root_cause_preds'],
        target_names=ROOT_CAUSE_CLASSES,
        digits=3
    )
    print(root_cause_report)
    
    # Save root cause report
    with open(output_dir / 'root_cause_classification_report.txt', 'w') as f:
        f.write(root_cause_report)
    
    # Confusion matrices
    if args.confusion_matrix:
        print("\nGenerating confusion matrices...")
        
        # Pattern confusion matrix
        pattern_cm = confusion_matrix(results['pattern_labels'], results['pattern_preds'])
        plot_confusion_matrix(
            pattern_cm,
            PATTERN_CLASSES,
            output_dir / 'pattern_confusion_matrix.png',
            'Pattern Classification Confusion Matrix'
        )
        
        # Root cause confusion matrix
        root_cause_cm = confusion_matrix(results['root_cause_labels'], results['root_cause_preds'])
        plot_confusion_matrix(
            root_cause_cm,
            ROOT_CAUSE_CLASSES,
            output_dir / 'root_cause_confusion_matrix.png',
            'Root Cause Classification Confusion Matrix'
        )
    
    print(f"\nResults saved to: {output_dir}")


if __name__ == '__main__':
    main()
