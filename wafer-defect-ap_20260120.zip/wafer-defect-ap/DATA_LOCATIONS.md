# Data Storage Locations

This document shows where all uploaded wafer data is stored in the backend system.

## Directory Structure

```
wafer-defect-ap/
└── data/
    ├── metadata/          # JSON metadata files
    ├── wafer_images/      # Uploaded wafer map images
    ├── models/            # Trained AI model files
    └── temp/              # Temporary files during upload
```

---

## 1. Metadata Files (JSON)

**Location**: `wafer-defect-ap/data/metadata/`

### Files:
- **`wafers.json`** - All uploaded wafer records
- **`defects.json`** - Defect data (future use)
- **`training_jobs.json`** - Model training job records (future use)
- **`inference_results.json`** - AI inference results (future use)
- **`models.json`** - Model version registry (future use)

### Example: wafers.json
```json
[
  {
    "id": "c317e565-e816-4d1a-bc7e-33907f5e447d",
    "job_id": "d351635c-011c-4eaf-bfe0-dccfca4ea4a9",
    "lot_id": "M93242.00",
    "wafer_id": "M93242.01",
    "tool_id": "LITHO-ASML-04",
    "scan_time": "2024-01-15T10:30:00Z",
    "process_step": "Lithography",
    "defect_count": 45,
    "image_path": "C:\\...\\wafer_images\\M93242.01_test_wafer.png",
    "image_filename": "M93242.01_test_wafer.png",
    "status": "uploaded",
    "upload_time": "2026-01-18T09:29:48.663493",
    "created_at": "2026-01-18T09:29:48.670178"
  }
]
```

---

## 2. Wafer Map Images

**Location**: `wafer-defect-ap/data/wafer_images/`

### Naming Convention:
- Format: `{WaferID}_{original_filename}`
- Example: `M93242.01_test_wafer.png`

### Supported Formats:
- JPG / JPEG
- PNG
- GIF

### Current Files:
```
wafer-defect-ap/data/wafer_images/
└── M93242.01_test_wafer.png
```

---

## 3. How to Access the Files

### View Metadata:
```bash
# Windows
type data\metadata\wafers.json

# Or open in any text editor
notepad data\metadata\wafers.json
```

### View Images:
```bash
# Open the image file
start data\wafer_images\M93242.01_test_wafer.png
```

### Using Python:
```python
import json

# Read metadata
with open('data/metadata/wafers.json', 'r') as f:
    wafers = json.load(f)
    print(f"Total wafers: {len(wafers)}")
    for wafer in wafers:
        print(f"Wafer ID: {wafer['wafer_id']}")
        print(f"Image: {wafer['image_filename']}")
```

---

## 4. API Endpoints to Access Data

### List All Wafers:
```bash
curl http://localhost:5000/api/v1/wafer/list
```

### Get Specific Wafer:
```bash
curl http://localhost:5000/api/v1/wafer/M93242.01
```

### Filter by Lot ID:
```bash
curl "http://localhost:5000/api/v1/wafer/list?lot_id=M93242.00"
```

---

## 5. Testing Files

### Test Upload Script:
**Location**: `wafer-defect-ap/test_upload.py`

Run the test:
```bash
python test_upload.py
```

This script:
1. Creates a sample wafer image (300x300 PNG with random defects)
2. Creates a sample JSON data file with wafer information
3. Uploads both files to the API
4. Verifies the upload was successful
5. Lists all wafers
6. Gets details of the uploaded wafer

---

## 6. Full File Paths (Absolute)

Based on your system:

### Metadata:
```
C:\VSMC\VSMC-FAB_Investigayion_Tool\wafer-defect-ap\data\metadata\wafers.json
```

### Images:
```
C:\VSMC\VSMC-FAB_Investigayion_Tool\wafer-defect-ap\data\wafer_images\M93242.01_test_wafer.png
```

---

## 7. Quick Commands

### Open metadata folder:
```cmd
cd C:\VSMC\VSMC-FAB_Investigayion_Tool\wafer-defect-ap\data\metadata
explorer .
```

### Open images folder:
```cmd
cd C:\VSMC\VSMC-FAB_Investigayion_Tool\wafer-defect-ap\data\wafer_images
explorer .
```

### View wafer image:
```cmd
start C:\VSMC\VSMC-FAB_Investigayion_Tool\wafer-defect-ap\data\wafer_images\M93242.01_test_wafer.png
```

---

## 8. Backup and Export

### Backup metadata:
```bash
python -c "from app.utils.json_storage import JSONStorage; storage = JSONStorage('data/metadata'); backup = storage.backup('wafers.json'); print(f'Backup created: {backup}')"
```

### Export to CSV:
```python
import json
import pandas as pd

# Read JSON
with open('data/metadata/wafers.json', 'r') as f:
    wafers = json.load(f)

# Convert to DataFrame and export
df = pd.DataFrame(wafers)
df.to_csv('wafers_export.csv', index=False)
print("Exported to wafers_export.csv")
```

---

## Summary

✅ **Metadata**: `data/metadata/wafers.json`  
✅ **Images**: `data/wafer_images/M93242.01_test_wafer.png`  
✅ **API**: http://localhost:5000/api/v1/wafer/list  
✅ **Test Script**: `test_upload.py`
