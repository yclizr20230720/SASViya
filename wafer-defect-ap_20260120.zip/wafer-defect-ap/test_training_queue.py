"""
Test training queue management API
"""
import requests
import json

API_URL = "http://localhost:5000/api/v1"


def test_training_queue():
    """Test training queue management"""
    print("\n" + "=" * 70)
    print("Testing Training Queue Management API")
    print("=" * 70)
    
    # 1. Create multiple training jobs with different priorities
    print("\n1. Creating training jobs with different priorities...")
    job_ids = []
    
    for i, priority in enumerate(['high', 'normal', 'low']):
        config = {
            "model_architecture": "efficientnet-b3",
            "epochs": 50 + (i * 10),
            "batch_size": 32,
            "learning_rate": 0.0001,
            "priority": priority,
            "dataset_filter": {
                "lot_ids": [f"M1234{i}.00"]
            }
        }
        
        response = requests.post(f"{API_URL}/training/start", json=config)
        if response.status_code == 200:
            result = response.json()
            job_ids.append(result['job_id'])
            print(f"   ✓ Job {i+1} created: {result['job_id'][:8]}... (Priority: {priority})")
    
    # 2. Get training queue
    print(f"\n2. Getting training queue...")
    response = requests.get(f"{API_URL}/training/queue")
    if response.status_code == 200:
        result = response.json()
        print(f"   ✓ Queue retrieved:")
        print(f"     - Total jobs: {result['count']}")
        print(f"     - Statistics: {json.dumps(result['statistics'], indent=6)}")
    
    # 3. Get queue statistics
    print(f"\n3. Getting queue statistics...")
    response = requests.get(f"{API_URL}/training/queue/statistics")
    if response.status_code == 200:
        result = response.json()
        stats = result['statistics']
        print(f"   ✓ Statistics:")
        print(f"     - Total jobs: {stats['total_jobs']}")
        print(f"     - By status: {json.dumps(stats['by_status'], indent=6)}")
        print(f"     - By priority: {json.dumps(stats['by_priority'], indent=6)}")
        print(f"     - Success rate: {stats['success_rate']}%")
    
    # 4. Update job priority
    if len(job_ids) > 0:
        job_id = job_ids[0]
        print(f"\n4. Updating job priority to 'high'...")
        response = requests.put(
            f"{API_URL}/training/queue/{job_id}/priority",
            json={"priority": "high"}
        )
        if response.status_code == 200:
            result = response.json()
            print(f"   ✓ Priority updated: {result['message']}")
    
    # 5. Cancel a job
    if len(job_ids) > 1:
        job_id = job_ids[1]
        print(f"\n5. Cancelling job...")
        response = requests.post(f"{API_URL}/training/queue/{job_id}/cancel")
        if response.status_code == 200:
            result = response.json()
            print(f"   ✓ Job cancelled: {result['message']}")
    
    # 6. Requeue the cancelled job
    if len(job_ids) > 1:
        job_id = job_ids[1]
        print(f"\n6. Requeuing cancelled job...")
        response = requests.post(f"{API_URL}/training/queue/{job_id}/requeue")
        if response.status_code == 200:
            result = response.json()
            print(f"   ✓ Job requeued: {result['message']}")
    
    # 7. Get filtered queue (only queued jobs)
    print(f"\n7. Getting queued jobs only...")
    response = requests.get(f"{API_URL}/training/queue?status=queued")
    if response.status_code == 200:
        result = response.json()
        print(f"   ✓ Found {result['count']} queued job(s)")
        for job in result['jobs']:
            print(f"     - {job['job_id'][:8]}... Priority: {job.get('priority', 'normal')} | Epochs: {job['total_epochs']}")
    
    # 8. Delete a job
    if len(job_ids) > 2:
        job_id = job_ids[2]
        print(f"\n8. Deleting job...")
        response = requests.delete(f"{API_URL}/training/queue/{job_id}")
        if response.status_code == 200:
            result = response.json()
            print(f"   ✓ Job deleted: {result['message']}")
    
    print("\n" + "=" * 70)
    print("✅ All training queue management tests completed!")
    print("=" * 70)
    print("\n📊 Summary:")
    print(f"   - Created {len(job_ids)} training jobs")
    print(f"   - Tested priority management")
    print(f"   - Tested job cancellation and requeuing")
    print(f"   - Tested job deletion")
    print(f"   - Tested queue filtering and statistics")


if __name__ == '__main__':
    test_training_queue()
