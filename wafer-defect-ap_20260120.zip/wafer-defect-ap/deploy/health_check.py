"""
Health check script for Wafer Defect Pattern Recognition System
Verifies all components are properly installed and configured
"""
import sys
import os
import subprocess
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

def check_python_version():
    """Check Python version"""
    print("Checking Python version...", end=" ")
    if sys.version_info >= (3, 11):
        print(f"✓ Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
        return True
    else:
        print(f"✗ Python {sys.version_info.major}.{sys.version_info.minor} (3.11+ required)")
        return False

def check_dependencies():
    """Check if required packages are installed"""
    print("Checking dependencies...", end=" ")
    required_packages = [
        'flask',
        'torch',
        'numpy',
        'pandas',
        'Pillow',
        'werkzeug'
    ]
    
    missing = []
    for package in required_packages:
        try:
            __import__(package.lower().replace('-', '_'))
        except ImportError:
            missing.append(package)
    
    if not missing:
        print(f"✓ All {len(required_packages)} packages installed")
        return True
    else:
        print(f"✗ Missing: {', '.join(missing)}")
        return False

def check_torch_cuda():
    """Check PyTorch CUDA availability"""
    print("Checking PyTorch CUDA...", end=" ")
    try:
        import torch
        if torch.cuda.is_available():
            print(f"✓ CUDA available (GPU: {torch.cuda.get_device_name(0)})")
            return True
        else:
            print("⚠ CUDA not available (CPU mode)")
            return True  # Not a failure, just a warning
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def check_directory_structure():
    """Check if required directories exist"""
    print("Checking directory structure...", end=" ")
    base_dir = Path(__file__).parent.parent
    
    required_dirs = [
        'app',
        'app/api',
        'app/ml',
        'app/utils',
        'data',
        'data/metadata',
        'data/wafer_images',
        'data/models',
        'data/temp',
        'logs',
        'checkpoints',
        'scripts'
    ]
    
    missing = []
    for dir_path in required_dirs:
        full_path = base_dir / dir_path
        if not full_path.exists():
            missing.append(dir_path)
    
    if not missing:
        print(f"✓ All {len(required_dirs)} directories exist")
        return True
    else:
        print(f"✗ Missing: {', '.join(missing)}")
        return False

def check_json_files():
    """Check if JSON storage files exist"""
    print("Checking JSON storage files...", end=" ")
    base_dir = Path(__file__).parent.parent
    metadata_dir = base_dir / 'data' / 'metadata'
    
    required_files = [
        'wafers.json',
        'defects.json',
        'training_jobs.json',
        'inference_results.json',
        'models.json'
    ]
    
    missing = []
    for file_name in required_files:
        file_path = metadata_dir / file_name
        if not file_path.exists():
            missing.append(file_name)
    
    if not missing:
        print(f"✓ All {len(required_files)} JSON files exist")
        return True
    else:
        print(f"⚠ Missing: {', '.join(missing)} (will be created on first run)")
        return True  # Not a failure

def check_config_file():
    """Check if configuration file exists"""
    print("Checking configuration file...", end=" ")
    base_dir = Path(__file__).parent.parent
    env_file = base_dir / '.env'
    
    if env_file.exists():
        print("✓ .env file exists")
        return True
    else:
        print("⚠ .env file not found (using defaults)")
        return True  # Not a failure

def check_model_file():
    """Check if trained model exists"""
    print("Checking trained model...", end=" ")
    base_dir = Path(__file__).parent.parent
    model_file = base_dir / 'checkpoints' / 'best_model.pth'
    
    if model_file.exists():
        size_mb = model_file.stat().st_size / (1024 * 1024)
        print(f"✓ Model found ({size_mb:.1f} MB)")
        return True
    else:
        print("⚠ No trained model found (inference will not work)")
        return True  # Not a failure for installation

def check_flask_app():
    """Check if Flask app can be imported"""
    print("Checking Flask application...", end=" ")
    try:
        from app import create_app
        app = create_app('production')
        print("✓ Flask app initialized successfully")
        return True
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def check_port_availability():
    """Check if port 5000 is available"""
    print("Checking port 5000 availability...", end=" ")
    import socket
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(('127.0.0.1', 5000))
    sock.close()
    
    if result != 0:
        print("✓ Port 5000 is available")
        return True
    else:
        print("⚠ Port 5000 is in use (API may already be running)")
        return True  # Not a failure

def main():
    """Run all health checks"""
    print("\n" + "="*70)
    print("Wafer Defect Pattern Recognition System - Health Check")
    print("="*70 + "\n")
    
    checks = [
        ("Python Version", check_python_version),
        ("Dependencies", check_dependencies),
        ("PyTorch CUDA", check_torch_cuda),
        ("Directory Structure", check_directory_structure),
        ("JSON Storage", check_json_files),
        ("Configuration", check_config_file),
        ("Trained Model", check_model_file),
        ("Flask Application", check_flask_app),
        ("Port Availability", check_port_availability)
    ]
    
    results = []
    for name, check_func in checks:
        try:
            result = check_func()
            results.append((name, result))
        except Exception as e:
            print(f"✗ Unexpected error: {e}")
            results.append((name, False))
    
    print("\n" + "="*70)
    print("Health Check Summary")
    print("="*70 + "\n")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{name:.<50} {status}")
    
    print(f"\nTotal: {passed}/{total} checks passed")
    
    if passed == total:
        print("\n✓ System is ready for deployment!")
        return 0
    else:
        print("\n⚠ Some checks failed. Please review and fix issues.")
        return 1

if __name__ == '__main__':
    sys.exit(main())
