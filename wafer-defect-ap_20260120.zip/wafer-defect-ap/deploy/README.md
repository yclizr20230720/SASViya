# Deployment Scripts
# Wafer Defect Pattern Recognition System

This folder contains all deployment and maintenance scripts for Windows Server 2022.

---

## 📋 Script Overview

### Installation Scripts

| Script | Purpose | Admin Required |
|--------|---------|----------------|
| `install.bat` | Initial installation and setup | ✅ Yes |
| `install_service.bat` | Install as Windows Service | ✅ Yes |
| `uninstall_service.bat` | Remove Windows Service | ✅ Yes |

### Service Management Scripts

| Script | Purpose | Admin Required |
|--------|---------|----------------|
| `start_service.bat` | Start API server (manual mode) | ❌ No |
| `stop_service.bat` | Stop Windows Service | ✅ Yes |

### Maintenance Scripts

| Script | Purpose | Admin Required |
|--------|---------|----------------|
| `backup.bat` | Backup data and configuration | ❌ No |
| `restore.bat` | Restore from backup | ❌ No |
| `health_check.py` | System health verification | ❌ No |

---

## 🚀 Quick Start

### First-Time Installation

```cmd
REM Run as Administrator
install.bat
```

### Install as Windows Service

```cmd
REM 1. Download NSSM from https://nssm.cc/download
REM 2. Copy nssm.exe to this folder
REM 3. Run as Administrator
install_service.bat
```

### Start/Stop Service

```cmd
REM Start
net start WaferDefectAPI

REM Stop
net stop WaferDefectAPI
```

---

## 📖 Detailed Usage

### install.bat

**Purpose:** Complete installation and setup

**What it does:**
1. Checks Python 3.11+ installation
2. Creates virtual environment
3. Installs all dependencies
4. Installs PyTorch (with CUDA if available)
5. Initializes data storage
6. Creates configuration file
7. Configures Windows Firewall
8. Runs health check

**Usage:**
```cmd
REM Run as Administrator
cd C:\Apps\wafer-defect-ap
deploy\install.bat
```

**Time:** 5-10 minutes

---

### install_service.bat

**Purpose:** Install API as Windows Service for production

**Prerequisites:**
- `install.bat` must be run first
- NSSM (nssm.exe) must be in this folder
- Download from: https://nssm.cc/download

**What it does:**
1. Checks for existing service
2. Installs service using NSSM
3. Configures automatic startup
4. Sets up logging
5. Starts the service

**Usage:**
```cmd
REM Run as Administrator
deploy\install_service.bat
```

**Service Details:**
- **Name:** WaferDefectAPI
- **Display Name:** Wafer Defect Pattern Recognition API
- **Startup:** Automatic
- **Logs:** logs\service_stdout.log, logs\service_stderr.log

---

### start_service.bat

**Purpose:** Start API server manually (for testing)

**What it does:**
1. Activates virtual environment
2. Starts Flask server
3. Runs in current terminal

**Usage:**
```cmd
REM No admin required
deploy\start_service.bat
```

**Note:** Press Ctrl+C to stop. For production, use Windows Service instead.

---

### stop_service.bat

**Purpose:** Stop Windows Service

**Usage:**
```cmd
REM Run as Administrator
deploy\stop_service.bat
```

---

### uninstall_service.bat

**Purpose:** Remove Windows Service

**What it does:**
1. Stops the service
2. Removes service registration
3. Cleans up service configuration

**Usage:**
```cmd
REM Run as Administrator
deploy\uninstall_service.bat
```

**Note:** This does NOT delete application files or data.

---

### backup.bat

**Purpose:** Create timestamped backup of all data

**What it backs up:**
- Data files (JSON, images)
- Configuration (.env, config.py)
- Logs
- Model checkpoints

**Usage:**
```cmd
REM No admin required
deploy\backup.bat
```

**Backup location:** `backups\backup_YYYYMMDD_HHMM\`

**Recommended:** Run daily via Task Scheduler

---

### restore.bat

**Purpose:** Restore data from backup

**What it does:**
1. Lists available backups
2. Prompts for backup selection
3. Confirms before overwriting
4. Restores all backed up files

**Usage:**
```cmd
REM No admin required
deploy\restore.bat
```

**Warning:** This will overwrite current data!

---

### health_check.py

**Purpose:** Verify system health and configuration

**What it checks:**
- ✓ Python version (3.11+)
- ✓ Dependencies installed
- ✓ PyTorch CUDA availability
- ✓ Directory structure
- ✓ JSON storage files
- ✓ Configuration file
- ✓ Trained model
- ✓ Flask application
- ✓ Port 5000 availability

**Usage:**
```cmd
REM No admin required
python deploy\health_check.py
```

**Output:** Detailed health report with pass/fail status

---

## 🔧 Common Workflows

### Initial Deployment

```cmd
REM 1. Install application
deploy\install.bat

REM 2. Edit configuration
notepad .env

REM 3. Test manually
deploy\start_service.bat

REM 4. Install as service
REM    (Download NSSM first)
deploy\install_service.bat
```

### Daily Operations

```cmd
REM Check service status
sc query WaferDefectAPI

REM View logs
type logs\app.log

REM Create backup
deploy\backup.bat
```

### Troubleshooting

```cmd
REM Run health check
python deploy\health_check.py

REM View error logs
type logs\service_stderr.log

REM Restart service
net stop WaferDefectAPI
net start WaferDefectAPI
```

### Model Update

```cmd
REM 1. Stop service
net stop WaferDefectAPI

REM 2. Backup current model
copy checkpoints\best_model.pth checkpoints\best_model_backup.pth

REM 3. Copy new model
copy new_model.pth checkpoints\best_model.pth

REM 4. Start service
net start WaferDefectAPI
```

### Disaster Recovery

```cmd
REM 1. Stop service
net stop WaferDefectAPI

REM 2. Restore from backup
deploy\restore.bat

REM 3. Verify health
python deploy\health_check.py

REM 4. Start service
net start WaferDefectAPI
```

---

## 📁 Required Files

### For Service Installation

You must download NSSM separately:

1. Go to: https://nssm.cc/download
2. Download the latest version
3. Extract the ZIP file
4. Copy `win64\nssm.exe` to this folder

**Why NSSM?**
- Reliable Windows Service wrapper
- Automatic restart on failure
- Proper logging
- Easy configuration

---

## 🔒 Security Notes

### Administrator Rights

Scripts requiring admin rights:
- `install.bat` - Firewall configuration
- `install_service.bat` - Service installation
- `stop_service.bat` - Service control
- `uninstall_service.bat` - Service removal

### Firewall Configuration

`install.bat` automatically adds firewall rule:
```cmd
netsh advfirewall firewall add rule name="Wafer Defect API" dir=in action=allow protocol=TCP localport=5000
```

To remove:
```cmd
netsh advfirewall firewall delete rule name="Wafer Defect API"
```

---

## 📊 Monitoring

### Service Status

```cmd
REM Check if running
sc query WaferDefectAPI

REM View in Services Manager
services.msc
```

### Logs

```cmd
REM Application log
type logs\app.log

REM Service output
type logs\service_stdout.log

REM Service errors
type logs\service_stderr.log

REM Real-time monitoring
powershell Get-Content logs\app.log -Wait -Tail 50
```

### Performance

```cmd
REM CPU and Memory
tasklist /FI "IMAGENAME eq python.exe" /FO TABLE

REM GPU (if available)
nvidia-smi

REM Disk space
dir /s data
```

---

## 🆘 Troubleshooting

### Installation Fails

**Python not found:**
```cmd
REM Check Python installation
python --version

REM Add to PATH if needed
REM System Properties → Environment Variables → Path
```

**Permission denied:**
```cmd
REM Run as Administrator
REM Right-click → Run as administrator
```

### Service Won't Start

**Check logs:**
```cmd
type logs\service_stderr.log
```

**Port in use:**
```cmd
netstat -ano | findstr :5000
```

**Restart service:**
```cmd
net stop WaferDefectAPI
timeout /t 5
net start WaferDefectAPI
```

### Backup/Restore Issues

**Backup folder not found:**
```cmd
REM Create backups directory
mkdir backups
```

**Restore fails:**
```cmd
REM Check backup exists
dir backups

REM Verify backup contents
dir backups\backup_YYYYMMDD_HHMM
```

---

## 📞 Support

For issues:
1. Run `python deploy\health_check.py`
2. Check logs in `logs\` directory
3. Review `DEPLOYMENT_GUIDE.md`
4. Contact system administrator

---

## 📝 Notes

- All scripts use Windows batch (.bat) format
- Python scripts use UTF-8 encoding
- Paths are relative to application root
- Logs are automatically rotated
- Backups are timestamped

---

**Last Updated:** January 20, 2026  
**Version:** 1.0  
**Platform:** Windows Server 2022
