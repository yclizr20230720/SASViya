# Deployment Checklist
# Wafer Defect Pattern Recognition System

Use this checklist to ensure a successful deployment on Windows Server 2022.

---

## Pre-Deployment Checklist

### Server Preparation

- [ ] Windows Server 2022 installed and updated
- [ ] Administrator access available
- [ ] Server meets hardware requirements:
  - [ ] CPU: 8+ cores
  - [ ] RAM: 32 GB
  - [ ] Storage: 500 GB SSD
  - [ ] GPU: NVIDIA 8GB+ VRAM (optional)
- [ ] Network connectivity verified
- [ ] Port 5000 available
- [ ] Firewall access configured

### Software Prerequisites

- [ ] Python 3.11+ installed
- [ ] Python added to PATH
- [ ] pip working correctly
- [ ] NVIDIA CUDA 11.8 installed (if using GPU)
- [ ] NSSM downloaded (for Windows Service)

### Files and Documentation

- [ ] Application files extracted to target location
- [ ] Deployment guide reviewed
- [ ] Quick start guide reviewed
- [ ] Configuration requirements understood

---

## Installation Checklist

### Step 1: Initial Installation

- [ ] Opened Command Prompt as Administrator
- [ ] Navigated to application directory
- [ ] Ran `deploy\install.bat`
- [ ] Installation completed without errors
- [ ] Virtual environment created
- [ ] Dependencies installed successfully
- [ ] PyTorch installed (CUDA or CPU)
- [ ] Data storage initialized
- [ ] Configuration file created
- [ ] Firewall rule added
- [ ] Health check passed

**Time**: 5-10 minutes

### Step 2: Configuration

- [ ] Opened `.env` file
- [ ] Generated secure SECRET_KEY
- [ ] Configured CORS_ORIGINS with frontend URL
- [ ] Set INFERENCE_DEVICE (cuda or cpu)
- [ ] Verified all paths are correct
- [ ] Saved configuration file

**Time**: 5 minutes

### Step 3: Manual Testing

- [ ] Ran `deploy\start_service.bat`
- [ ] Server started without errors
- [ ] Accessed http://localhost:5000/api/v1/health
- [ ] Received healthy response
- [ ] Tested from frontend server (if available)
- [ ] Stopped server (Ctrl+C)

**Time**: 5 minutes

### Step 4: Service Installation

- [ ] Downloaded NSSM from https://nssm.cc/download
- [ ] Extracted nssm.exe (64-bit)
- [ ] Copied nssm.exe to `deploy\` folder
- [ ] Ran `deploy\install_service.bat` as Administrator
- [ ] Service installed successfully
- [ ] Service started automatically
- [ ] Verified service status: `sc query WaferDefectAPI`

**Time**: 5 minutes

---

## Verification Checklist

### System Health

- [ ] Ran `python deploy\health_check.py`
- [ ] All checks passed:
  - [ ] Python version ✓
  - [ ] Dependencies ✓
  - [ ] PyTorch CUDA ✓
  - [ ] Directory structure ✓
  - [ ] JSON storage ✓
  - [ ] Configuration ✓
  - [ ] Trained model ✓ (or ⚠ if not trained yet)
  - [ ] Flask application ✓
  - [ ] Port availability ✓

### API Endpoints

- [ ] Health endpoint: `curl http://localhost:5000/api/v1/health`
- [ ] Wafer list: `curl http://localhost:5000/api/v1/wafer/list`
- [ ] Training queue: `curl http://localhost:5000/api/v1/training/queue`
- [ ] Analytics: `curl http://localhost:5000/api/v1/analytics/dashboard`

### Service Status

- [ ] Service running: `sc query WaferDefectAPI`
- [ ] Service set to automatic startup
- [ ] Logs being written: `type logs\service_stdout.log`
- [ ] No errors in logs: `type logs\service_stderr.log`

### Network Connectivity

- [ ] API accessible from localhost
- [ ] API accessible from frontend server
- [ ] Firewall rule active
- [ ] CORS configured correctly
- [ ] No connection errors

---

## Post-Deployment Checklist

### Backup Configuration

- [ ] Tested backup: `deploy\backup.bat`
- [ ] Backup created successfully
- [ ] Backup location verified: `backups\`
- [ ] Tested restore: `deploy\restore.bat`
- [ ] Scheduled daily backups (Task Scheduler)

### Monitoring Setup

- [ ] Configured log monitoring
- [ ] Set up performance monitoring
- [ ] Configured alerts (if applicable)
- [ ] Documented monitoring procedures

### Security Hardening

- [ ] Changed default SECRET_KEY
- [ ] Configured CORS properly
- [ ] Reviewed firewall rules
- [ ] Disabled unnecessary services
- [ ] Applied Windows updates
- [ ] Configured backup encryption (if needed)

### Documentation

- [ ] Deployment guide accessible
- [ ] Quick start guide accessible
- [ ] Script documentation reviewed
- [ ] Troubleshooting guide reviewed
- [ ] Contact information documented

### Training and Handover

- [ ] Operations team trained
- [ ] Maintenance procedures documented
- [ ] Escalation procedures defined
- [ ] Support contacts provided

---

## Model Deployment Checklist

### If Model is Already Trained

- [ ] Copied model to `checkpoints\best_model.pth`
- [ ] Verified model file size (should be ~48 MB)
- [ ] Restarted service: `net stop WaferDefectAPI && net start WaferDefectAPI`
- [ ] Tested inference endpoint
- [ ] Verified inference time < 500ms

### If Model Needs Training

- [ ] Prepared training data
- [ ] Labeled wafer images
- [ ] Ran `scripts\prepare_training_data.py`
- [ ] Started training: `scripts\train_model.py`
- [ ] Monitored training progress
- [ ] Evaluated model: `scripts\evaluate_model.py`
- [ ] Deployed trained model

---

## Frontend Integration Checklist

### Backend Configuration

- [ ] CORS_ORIGINS includes frontend URL
- [ ] API accessible from frontend server
- [ ] No CORS errors in browser console

### Frontend Configuration

- [ ] Frontend API URL points to backend
- [ ] Frontend can reach backend
- [ ] File uploads work
- [ ] Inference works
- [ ] Analytics display correctly

### End-to-End Testing

- [ ] Upload wafer images
- [ ] View wafer list
- [ ] Run inference
- [ ] View analytics
- [ ] Check training queue
- [ ] View training metrics

---

## Production Readiness Checklist

### Performance

- [ ] API response time < 500ms
- [ ] Inference time < 500ms (CPU) or < 100ms (GPU)
- [ ] No memory leaks
- [ ] CPU usage acceptable
- [ ] Disk space sufficient

### Reliability

- [ ] Service starts on boot
- [ ] Service restarts on failure
- [ ] Error handling works
- [ ] Logs rotating properly
- [ ] Backups running daily

### Security

- [ ] Firewall configured
- [ ] CORS configured
- [ ] Secret key secure
- [ ] File validation working
- [ ] No security warnings

### Monitoring

- [ ] Health checks running
- [ ] Logs being monitored
- [ ] Alerts configured
- [ ] Performance metrics tracked

### Documentation

- [ ] Deployment documented
- [ ] Configuration documented
- [ ] Maintenance procedures documented
- [ ] Troubleshooting guide available
- [ ] Contact information current

---

## Go-Live Checklist

### Final Verification

- [ ] All previous checklists completed
- [ ] System tested end-to-end
- [ ] Performance acceptable
- [ ] No critical errors
- [ ] Backups verified
- [ ] Monitoring active

### Communication

- [ ] Stakeholders notified
- [ ] Users informed
- [ ] Support team ready
- [ ] Escalation procedures in place

### Rollback Plan

- [ ] Backup created before go-live
- [ ] Rollback procedure documented
- [ ] Rollback tested
- [ ] Rollback decision criteria defined

### Go-Live

- [ ] System live
- [ ] Users can access
- [ ] No critical issues
- [ ] Monitoring active
- [ ] Support available

---

## Post-Go-Live Checklist

### First 24 Hours

- [ ] Monitor logs continuously
- [ ] Check error rates
- [ ] Verify performance
- [ ] Respond to issues quickly
- [ ] Document any problems

### First Week

- [ ] Daily health checks
- [ ] Review logs daily
- [ ] Monitor performance trends
- [ ] Gather user feedback
- [ ] Address issues promptly

### First Month

- [ ] Weekly health checks
- [ ] Review backup success
- [ ] Analyze performance data
- [ ] Plan optimizations
- [ ] Update documentation

---

## Maintenance Checklist

### Daily

- [ ] Check service status
- [ ] Review error logs
- [ ] Monitor disk space
- [ ] Verify backups ran

### Weekly

- [ ] Run health check
- [ ] Review performance metrics
- [ ] Check for updates
- [ ] Clean temporary files

### Monthly

- [ ] Review all logs
- [ ] Analyze performance trends
- [ ] Update documentation
- [ ] Test restore procedure
- [ ] Review security

### Quarterly

- [ ] Update dependencies
- [ ] Review and update configuration
- [ ] Performance tuning
- [ ] Security audit
- [ ] Disaster recovery test

---

## Troubleshooting Checklist

### Service Issues

- [ ] Check service status: `sc query WaferDefectAPI`
- [ ] Review error logs: `type logs\service_stderr.log`
- [ ] Check port availability: `netstat -ano | findstr :5000`
- [ ] Verify Python installation
- [ ] Check virtual environment

### Performance Issues

- [ ] Check CPU usage
- [ ] Check memory usage
- [ ] Check disk space
- [ ] Check GPU usage (if applicable)
- [ ] Review slow query logs

### Network Issues

- [ ] Test localhost connectivity
- [ ] Test remote connectivity
- [ ] Check firewall rules
- [ ] Verify CORS configuration
- [ ] Check DNS resolution

### Data Issues

- [ ] Verify JSON files exist
- [ ] Check file permissions
- [ ] Verify data integrity
- [ ] Check disk space
- [ ] Review backup status

---

## Sign-Off

### Deployment Team

- [ ] Installation completed by: _________________ Date: _______
- [ ] Configuration verified by: _________________ Date: _______
- [ ] Testing completed by: _________________ Date: _______
- [ ] Documentation reviewed by: _________________ Date: _______

### Approval

- [ ] Technical lead approval: _________________ Date: _______
- [ ] Operations approval: _________________ Date: _______
- [ ] Security approval: _________________ Date: _______
- [ ] Management approval: _________________ Date: _______

---

## Notes

Use this space to document any issues, deviations, or special configurations:

```
_________________________________________________________________

_________________________________________________________________

_________________________________________________________________

_________________________________________________________________

_________________________________________________________________
```

---

**Checklist Version**: 1.0  
**Last Updated**: January 20, 2026  
**Platform**: Windows Server 2022
