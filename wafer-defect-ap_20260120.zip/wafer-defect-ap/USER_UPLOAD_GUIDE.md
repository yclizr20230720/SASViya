# 📤 USER UPLOAD GUIDE - Step by Step

## Current Status (From Screenshot)

✅ **COMPLETED:**
- Image file uploaded: `M93242.01_test_wafer.png`
- Batch Metadata filled:
  - Lot ID: `M12345.00`
  - Process Step: `Etch`
  - Equipment ID: `ETCH-001`

❌ **MISSING:**
- **Data file** (CSV/JSON/XLSX) - **YOU MUST UPLOAD THIS!**

---

## 🎯 What You Need to Do NOW

### **STEP 1: Create or Prepare Data File**

You need a data file with wafer information. Choose ONE format:

#### **Option A: JSON File** (Recommended)
Create `wafer_data.json`:
```json
{
  "lot_id": "M12345.00",
  "wafer_id": "M12345.01",
  "tool_id": "ETCH-001",
  "scan_time": "2026-01-18T10:00:00Z",
  "process_step": "Etch",
  "defect_count": 0
}
```

#### **Option B: CSV File**
Create `wafer_data.csv`:
```csv
lot_id,wafer_id,tool_id,scan_time,process_step,defect_count
M12345.00,M12345.01,ETCH-001,2026-01-18T10:00:00Z,Etch,0
```

#### **Option C: Excel File**
Create `wafer_data.xlsx` with columns:
- lot_id
- wafer_id
- tool_id
- scan_time
- process_step
- defect_count

---

### **STEP 2: Upload the Data File**

1. In the upload area, click **"Browse Files"** button
2. Select your data file (JSON/CSV/XLSX)
3. The file will appear in the "Queue Management" section

---

### **STEP 3: Click "Commit to Library"**

Once you have BOTH files uploaded:
- ✅ Image file: `M93242.01_test_wafer.png`
- ✅ Data file: `wafer_data.json` (or CSV/XLSX)

Click the blue **"Commit to Library"** button!

This will:
1. Send both files to the backend API
2. Validate the data
3. Store the wafer information
4. Store the image
5. Show success message

---

## ⚠️ CRITICAL: ID Format Requirements

### **LotID Format Rules:**
- **Length**: Exactly 9 characters
- **Format**: `M12345.00`
- **Pattern**: M + 5 digits + .00
- **Examples**:
  - ✅ `M12345.00`
  - ✅ `M93242.00`
  - ❌ `M12345.01` (wrong ending)
  - ❌ `LOT-001` (wrong format)

### **WaferID Format Rules:**
- **Length**: Exactly 9 characters
- **Format**: `M12345.01` to `M12345.25`
- **Pattern**: M + 5 digits + .01 to .25
- **Examples**:
  - ✅ `M12345.01`
  - ✅ `M12345.25`
  - ❌ `M12345.00` (reserved for LotID)
  - ❌ `M12345.26` (exceeds max)

---

## 📁 Sample Files Available

I've created sample files for you:

### **Location:**
```
wafer-defect-ap/
├── sample_upload_data.json  ← Use this JSON file
└── sample_upload_data.csv   ← Or use this CSV file
```

### **How to Use:**
1. Copy one of these files
2. Rename it to match your wafer (e.g., `M12345.01_data.json`)
3. Update the values if needed
4. Upload it along with your image

---

## 🔄 Complete Upload Process

```
┌─────────────────────────────────────────┐
│ 1. Upload IMAGE file                    │
│    ✅ M93242.01_test_wafer.png          │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 2. Fill BATCH METADATA                  │
│    ✅ Lot ID: M12345.00                 │
│    ✅ Process Step: Etch                │
│    ✅ Equipment ID: ETCH-001            │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 3. Upload DATA file                     │
│    ❌ MISSING - DO THIS NOW!            │
│    → Upload JSON/CSV/XLSX file          │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 4. Click "Commit to Library"            │
│    🔵 This triggers backend API         │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 5. Backend processes files              │
│    → Validates data                     │
│    → Stores metadata                    │
│    → Stores image                       │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 6. Success!                             │
│    ✅ Wafer uploaded to library         │
└─────────────────────────────────────────┘
```

---

## 🚨 Common Errors and Solutions

### **Error: "No data file provided"**
**Solution**: You forgot to upload the data file (JSON/CSV/XLSX). Upload it!

### **Error: "Invalid LotID format"**
**Solution**: LotID must be exactly `M12345.00` format (9 characters, ending with .00)

### **Error: "Invalid WaferID format"**
**Solution**: WaferID must be `M12345.01` to `M12345.25` (9 characters, .01 to .25)

### **Error: "Missing required fields"**
**Solution**: Your data file must include:
- lot_id
- wafer_id
- tool_id (optional but recommended)
- scan_time (optional)
- process_step (optional)
- defect_count (optional)

---

## 📞 Quick Help

### **Backend API Endpoint:**
```
POST http://localhost:5000/api/v1/wafer/upload
```

### **Check Backend Status:**
```
http://localhost:5000/health
```

### **View Uploaded Wafers:**
```
http://localhost:5000/api/v1/wafer/list
```

---

## ✅ Checklist Before Clicking "Commit to Library"

- [ ] Image file uploaded (JPG/PNG/GIF)
- [ ] Data file uploaded (JSON/CSV/XLSX)
- [ ] Batch metadata filled (Lot ID, Process Step, Equipment ID)
- [ ] LotID format is correct (M12345.00)
- [ ] WaferID format is correct (M12345.01 to M12345.25)
- [ ] Backend server is running (http://localhost:5000)

**If all checked, click "Commit to Library"!** 🚀

---

## 🎉 After Successful Upload

Your wafer data will be stored in:
- **Metadata**: `wafer-defect-ap/data/metadata/wafers.json`
- **Image**: `wafer-defect-ap/data/wafer_images/M12345.01_test_wafer.png`

You can then:
1. View it in the Wafer Library
2. Use it for AI model training
3. Run inference/pattern recognition
4. View analytics and statistics
