# Wafer Defect Pattern Recognition - Backend API

## Overview
Python Flask-based backend API with microservices architecture for AI-powered semiconductor wafer defect pattern recognition.

## Technology Stack
- **Framework**: Python Flask 3.0
- **Database**: PostgreSQL
- **File Storage**: Local HDD/NAS
- **Async Processing**: Redis + Celery
- **AI/ML**: PyTorch, scikit-learn
- **Deployment**: Windows Server 2022

## Project Structure
```
wafer-defect-ap/
├── app/
│   ├── __init__.py          # Flask application factory
│   ├── models/              # Database models
│   ├── services/            # Business logic microservices
│   ├── api/                 # REST API endpoints
│   │   └── v1/
│   │       ├── health.py    # Health check endpoints
│   │       ├── wafer_upload.py
│   │       ├── training.py
│   │       ├── inference.py
│   │       └── analytics.py
│   ├── utils/               # Utility functions
│   └── ml/                  # ML models and pipelines
├── data/
│   ├── wafer_images/        # Uploaded wafer images
│   ├── models/              # Trained model artifacts
│   └── temp/                # Temporary files
├── logs/                    # Application logs
├── tests/                   # Unit and integration tests
├── config.py                # Configuration settings
├── run.py                   # Application entry point
├── requirements.txt         # Python dependencies
└── .env                     # Environment variables
```

## Setup Instructions

### Prerequisites
- Python 3.11+
- PostgreSQL 15+
- Redis 7+
- Windows Server 2022

### Installation

1. **Clone the repository**
   ```bash
   cd C:\VSMC\VSMC-FAB_Investigayion_Tool\wafer-defect-ap
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**
   ```bash
   copy .env.example .env
   # Edit .env with your configuration
   ```

5. **Initialize database**
   ```bash
   flask db init
   flask db migrate -m "Initial migration"
   flask db upgrade
   ```

6. **Run the application**
   ```bash
   python run.py
   ```

The API will be available at `http://localhost:5000`

## API Endpoints

### Health Check
- `GET /health` - Basic health check
- `GET /api/v1/health` - Detailed health status
- `GET /api/v1/status` - System status

### Wafer Upload (Coming Soon)
- `POST /api/v1/wafer/upload` - Upload wafer data and images
- `POST /api/v1/wafer/batch-upload` - Batch upload
- `GET /api/v1/wafer/upload-status/{job_id}` - Upload status

### Training (Coming Soon)
- `POST /api/v1/training/start` - Start training job
- `GET /api/v1/training/status/{job_id}` - Training status
- `GET /api/v1/training/models` - List trained models

### Inference (Coming Soon)
- `POST /api/v1/inference/predict` - Run inference
- `GET /api/v1/inference/history` - Inference history

### Analytics (Coming Soon)
- `GET /api/v1/analytics/dashboard` - Dashboard metrics
- `GET /api/v1/analytics/patterns` - Pattern distribution

## Development

### Running Tests
```bash
pytest tests/
```

### Code Style
```bash
flake8 app/
black app/
```

### Database Migrations
```bash
flask db migrate -m "Description"
flask db upgrade
```

## Deployment on Windows Server 2022

### Install Python
1. Download Python 3.11 from python.org
2. Install with "Add to PATH" option
3. Verify: `python --version`

### Install PostgreSQL
1. Download PostgreSQL 15 installer
2. Install and configure
3. Create database: `wafer_defect_db`

### Install Redis
1. Download Redis for Windows
2. Install as Windows Service
3. Start service: `net start Redis`

### Set up Flask as Windows Service
1. Install NSSM (Non-Sucking Service Manager)
2. Create service:
   ```bash
   nssm install WaferDefectAPI "C:\path\to\venv\Scripts\python.exe" "C:\path\to\run.py"
   ```
3. Start service: `net start WaferDefectAPI`

## Configuration

### Environment Variables
See `.env.example` for all available configuration options.

Key settings:
- `DATABASE_URL`: PostgreSQL connection string
- `UPLOAD_FOLDER`: Path for wafer images
- `MODEL_FOLDER`: Path for trained models
- `CORS_ORIGINS`: Allowed frontend origins

## Monitoring

### Logs
Application logs are stored in `logs/app.log`

### Health Checks
Monitor system health at `/api/v1/health`

## Support

For issues or questions, contact the development team.

## License

Proprietary - All rights reserved
