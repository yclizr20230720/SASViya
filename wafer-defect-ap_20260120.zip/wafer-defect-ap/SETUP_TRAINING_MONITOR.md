# 🚀 Setup Training Monitor - Complete Guide

## ✅ What We Have

1. **Training Data Files** (Created ✅)
   - `logs/training_status.json` - Complete training status
   - `logs/training_metrics.json` - All 30 epochs metrics
   - `logs/training_current.log` - Formatted logs
   - `data/metadata/training_jobs.json` - Job queue with your completed training

2. **Backend API** (Ready ✅)
   - `/api/v1/training/queue` - Get all training jobs
   - `/api/v1/training/logs/<job_id>` - Get training logs
   - `/api/v1/training/metrics/<job_id>` - Get training metrics

3. **Frontend Component** (Ready ✅)
   - `TrainingJobQueueIntegrated.tsx` - Shows jobs with real-time metrics

## 🔧 Setup Steps

### Step 1: Start Flask Backend

```bash
cd wafer-defect-ap
python run.py
```

**Expected Output:**
```
 * Running on http://127.0.0.1:5000
 * Running on http://localhost:5000
```

### Step 2: Test API Endpoint

Open a new terminal and test:

```bash
curl http://localhost:5000/api/v1/training/queue
```

**Expected Response:**
```json
{
  "status": "success",
  "count": 7,
  "jobs": [
    {
      "job_id": "training_20260118",
      "status": "completed",
      "current_epoch": 30,
      "total_epochs": 30,
      ...
    }
  ]
}
```

### Step 3: Start Frontend

```bash
cd wafer-defect-gui
npm start
```

**Expected Output:**
```
Compiled successfully!
Local: http://localhost:3000
```

### Step 4: View in Browser

1. Open: `http://localhost:3000`
2. Click "Training Queue" tab
3. You should see 7 training jobs including your completed one

## 🐛 Troubleshooting

### Issue: "No training jobs found"

**Cause:** Flask server not running or CORS issue

**Solution:**
1. Check Flask is running: `curl http://localhost:5000/api/v1/health`
2. Check training_jobs.json exists: `dir data\metadata\training_jobs.json`
3. Check API response: `curl http://localhost:5000/api/v1/training/queue`

### Issue: CORS Error in Browser Console

**Cause:** Flask CORS not configured

**Solution:** Add to `run.py`:
```python
from flask_cors import CORS
CORS(app)
```

### Issue: Jobs show but no metrics

**Cause:** Metrics API not finding the files

**Solution:**
1. Verify files exist:
   - `logs/training_status.json`
   - `logs/training_current.log`
2. Check API: `curl http://localhost:5000/api/v1/training/metrics/training_20260118`

## 📊 What You Should See

### Training Queue Table

| Job ID | Status | Priority | Progress | Pattern Acc | Root Cause Acc | Loss | Actions |
|--------|--------|----------|----------|-------------|----------------|------|---------|
| training_2026... | COMPLETED | normal | 30/30 (100%) | 100.0% | 100.0% | -0.0301 | [Expand] |

### Expanded Row (Click to expand)

**Current Metrics:**
- Train Loss: -0.0147
- Val Loss: -0.0301
- Train Pattern Acc: 98.4%
- Learning Rate: 1.00e-04

**Recent Logs:**
```
[Epoch 30/30]
  Train - Loss: -0.0147, Pattern Acc: 98.4%, Root Cause Acc: 98.4%
  Val   - Loss: -0.0301, Pattern Acc: 100.0%, Root Cause Acc: 100.0%
  LR: 0.000100
```

## ✅ Verification Checklist

- [ ] Flask server running on port 5000
- [ ] API responds: `curl http://localhost:5000/api/v1/training/queue`
- [ ] Frontend running on port 3000
- [ ] Browser shows training jobs
- [ ] Can expand job to see metrics
- [ ] Logs display correctly

## 🎯 Quick Test

Run this complete test:

```bash
# Terminal 1: Start Flask
cd wafer-defect-ap
python run.py

# Terminal 2: Test API
curl http://localhost:5000/api/v1/training/queue
curl http://localhost:5000/api/v1/training/metrics/training_20260118
curl http://localhost:5000/api/v1/training/logs/training_20260118?lines=10

# Terminal 3: Start Frontend
cd wafer-defect-gui
npm start

# Browser: Open http://localhost:3000
# Click "Training Queue" tab
# You should see your completed training!
```

## 📝 Summary

Your completed training (30 epochs, 100% accuracy) is now:
- ✅ Stored in `data/metadata/training_jobs.json`
- ✅ Metrics in `logs/training_status.json`
- ✅ Logs in `logs/training_current.log`
- ✅ API endpoints ready to serve data
- ✅ Frontend component ready to display

Just start the Flask server and frontend to see it!
