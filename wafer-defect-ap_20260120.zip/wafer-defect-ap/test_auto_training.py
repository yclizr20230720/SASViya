"""
Test script for auto-create training job on upload and FIFO queue with priority
"""
import requests
import json
import time
from pathlib import Path

BASE_URL = "http://localhost:5000/api/v1"

def test_auto_create_training_job():
    """Test that uploading wafers automatically creates a training job"""
    print("\n" + "="*80)
    print("TEST 1: Auto-Create Training Job on Upload")
    print("="*80)
    
    # Prepare test data
    lot_id = "M93242.00"
    process_step = "Lithography"
    equipment_id = "LITHO-ASML-04"
    
    # Find a test image
    test_image_path = Path("data/wafer_images/M93242.01_test_wafer.png")
    if not test_image_path.exists():
        print(f"❌ Test image not found: {test_image_path}")
        return False
    
    # Upload wafer files
    print(f"\n📤 Uploading wafer with lot_id: {lot_id}")
    
    with open(test_image_path, 'rb') as f:
        files = {'files': (test_image_path.name, f, 'image/png')}
        data = {
            'lot_id': lot_id,
            'process_step': process_step,
            'equipment_id': equipment_id
        }
        
        response = requests.post(f"{BASE_URL}/training/ingest", files=files, data=data)
    
    if response.status_code != 200:
        print(f"❌ Upload failed: {response.status_code}")
        print(response.text)
        return False
    
    result = response.json()
    print(f"✅ Upload successful: {result['uploaded_count']} wafer(s)")
    
    # Check if training job was created
    if 'training_job_id' not in result:
        print("❌ No training_job_id in response")
        return False
    
    training_job_id = result['training_job_id']
    print(f"✅ Training job auto-created: {training_job_id}")
    
    # Verify training job exists in queue
    print(f"\n🔍 Verifying training job in queue...")
    response = requests.get(f"{BASE_URL}/training/queue")
    
    if response.status_code != 200:
        print(f"❌ Failed to get queue: {response.status_code}")
        return False
    
    queue_data = response.json()
    jobs = queue_data.get('jobs', [])
    
    # Find the created job
    created_job = None
    for job in jobs:
        if job['job_id'] == training_job_id:
            created_job = job
            break
    
    if not created_job:
        print(f"❌ Training job not found in queue")
        return False
    
    print(f"✅ Training job found in queue")
    print(f"   Status: {created_job['status']}")
    print(f"   Priority: {created_job['priority']}")
    print(f"   Wafer Count: {created_job.get('wafer_count', 'N/A')}")
    print(f"   Lot ID: {created_job.get('lot_id', 'N/A')}")
    
    return True


def test_fifo_queue_with_priority():
    """Test FIFO queue with priority sorting"""
    print("\n" + "="*80)
    print("TEST 2: FIFO Queue with Priority Sorting")
    print("="*80)
    
    # Create multiple training jobs with different priorities
    print("\n📝 Creating training jobs with different priorities...")
    
    job_configs = [
        {'priority': 'normal', 'name': 'Job 1 (Normal)'},
        {'priority': 'low', 'name': 'Job 2 (Low)'},
        {'priority': 'high', 'name': 'Job 3 (High)'},
        {'priority': 'normal', 'name': 'Job 4 (Normal)'},
        {'priority': 'high', 'name': 'Job 5 (High)'},
    ]
    
    created_jobs = []
    
    for config in job_configs:
        data = {
            'model_architecture': 'efficientnet-b3',
            'epochs': 50,
            'batch_size': 32,
            'learning_rate': 0.0001,
            'priority': config['priority']
        }
        
        response = requests.post(f"{BASE_URL}/training/start", json=data)
        
        if response.status_code != 200:
            print(f"❌ Failed to create {config['name']}: {response.status_code}")
            continue
        
        result = response.json()
        job_id = result['job_id']
        created_jobs.append({
            'job_id': job_id,
            'priority': config['priority'],
            'name': config['name']
        })
        
        print(f"✅ Created {config['name']}: {job_id[:8]}...")
        time.sleep(0.1)  # Small delay to ensure different timestamps
    
    # Get queue and verify sorting
    print(f"\n🔍 Fetching queue to verify FIFO with priority sorting...")
    time.sleep(0.5)  # Wait for all jobs to be saved
    
    response = requests.get(f"{BASE_URL}/training/queue?status=queued")
    
    if response.status_code != 200:
        print(f"❌ Failed to get queue: {response.status_code}")
        return False
    
    queue_data = response.json()
    jobs = queue_data.get('jobs', [])
    
    print(f"\n📊 Queue Order (should be: high jobs first, then normal, then low):")
    print("-" * 80)
    
    for idx, job in enumerate(jobs, 1):
        priority = job.get('priority', 'unknown')
        job_id = job.get('job_id', 'unknown')
        queued_at = job.get('queued_at', 'unknown')
        
        print(f"{idx}. Priority: {priority:8} | Job ID: {job_id[:8]}... | Queued: {queued_at}")
    
    # Verify priority order
    print(f"\n✅ Verifying priority order...")
    
    priorities = [job.get('priority', 'unknown') for job in jobs]
    
    # Check that high priority jobs come first
    high_indices = [i for i, p in enumerate(priorities) if p == 'high']
    normal_indices = [i for i, p in enumerate(priorities) if p == 'normal']
    low_indices = [i for i, p in enumerate(priorities) if p == 'low']
    
    # Verify order: all high < all normal < all low
    if high_indices and normal_indices:
        if max(high_indices) >= min(normal_indices):
            print("❌ High priority jobs not before normal priority jobs")
            return False
    
    if normal_indices and low_indices:
        if max(normal_indices) >= min(low_indices):
            print("❌ Normal priority jobs not before low priority jobs")
            return False
    
    print("✅ Priority order is correct!")
    
    # Test priority update
    print(f"\n🔄 Testing priority update (change low to high)...")
    
    if low_indices:
        low_job = jobs[low_indices[0]]
        low_job_id = low_job['job_id']
        
        response = requests.put(
            f"{BASE_URL}/training/queue/{low_job_id}/priority",
            json={'priority': 'high'}
        )
        
        if response.status_code != 200:
            print(f"❌ Failed to update priority: {response.status_code}")
            return False
        
        print(f"✅ Updated job {low_job_id[:8]}... from low to high")
        
        # Verify new order
        time.sleep(0.5)
        response = requests.get(f"{BASE_URL}/training/queue?status=queued")
        queue_data = response.json()
        jobs = queue_data.get('jobs', [])
        
        # Find the updated job
        updated_job = None
        for idx, job in enumerate(jobs):
            if job['job_id'] == low_job_id:
                updated_job = job
                print(f"✅ Updated job now at position {idx + 1} with priority: {job['priority']}")
                break
        
        if not updated_job:
            print("❌ Updated job not found in queue")
            return False
    
    return True


def test_queue_statistics():
    """Test queue statistics"""
    print("\n" + "="*80)
    print("TEST 3: Queue Statistics")
    print("="*80)
    
    response = requests.get(f"{BASE_URL}/training/queue/statistics")
    
    if response.status_code != 200:
        print(f"❌ Failed to get statistics: {response.status_code}")
        return False
    
    stats = response.json().get('statistics', {})
    
    print(f"\n📊 Queue Statistics:")
    print("-" * 80)
    print(f"Total Jobs: {stats.get('total_jobs', 0)}")
    print(f"\nBy Status:")
    for status, count in stats.get('by_status', {}).items():
        print(f"  {status:12}: {count}")
    print(f"\nBy Priority:")
    for priority, count in stats.get('by_priority', {}).items():
        print(f"  {priority:12}: {count}")
    print(f"\nAverage Duration: {stats.get('average_duration_minutes', 0):.2f} minutes")
    print(f"Success Rate: {stats.get('success_rate', 0):.2f}%")
    
    print("\n✅ Statistics retrieved successfully")
    return True


def main():
    """Run all tests"""
    print("\n" + "="*80)
    print("TESTING AUTO-CREATE TRAINING JOB AND FIFO QUEUE WITH PRIORITY")
    print("="*80)
    
    results = []
    
    # Test 1: Auto-create training job
    results.append(("Auto-Create Training Job", test_auto_create_training_job()))
    
    # Test 2: FIFO queue with priority
    results.append(("FIFO Queue with Priority", test_fifo_queue_with_priority()))
    
    # Test 3: Queue statistics
    results.append(("Queue Statistics", test_queue_statistics()))
    
    # Summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name:40} {status}")
    
    all_passed = all(result[1] for result in results)
    
    if all_passed:
        print("\n🎉 All tests passed!")
    else:
        print("\n❌ Some tests failed")
    
    return all_passed


if __name__ == "__main__":
    main()
