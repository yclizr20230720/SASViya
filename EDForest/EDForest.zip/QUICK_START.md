# ⚡ VSMC Litho Platform - Quick Start Guide

## 🚀 Launch in 3 Steps (First Time Setup)

### Step 1: Install Backend Dependencies (One Time Only)

Open **Command Prompt** or **PowerShell** in the project folder:

```bash
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

### Step 2: Install Frontend Dependencies (One Time Only)

Open a **NEW** terminal:

```bash
cd frontend
npm install
```

### Step 3: Launch Both Services

**Option A: Use Batch Scripts (Easiest)**

Double-click these files:
- `start_backend.bat` - Starts backend on port 5000
- `start_frontend.bat` - Starts frontend on port 5174

**Option B: Manual Launch**

**Terminal 1 - Backend:**
```bash
cd backend
venv\Scripts\activate
python run.py
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```

---

## 🌐 Access the Application

Open your browser and go to:
```
http://localhost:5174
```

---

## 🎯 Quick Test

1. Open http://localhost:5174
2. Click "EDForest - Bossung Curve Analysis"
3. Click "Generate Mock Data"
4. Click "Run Analysis"
5. View results!

---

## 🛑 Stop Services

Press `Ctrl+C` in each terminal window

---

## 📋 Daily Usage (After First Setup)

Just run:
1. `start_backend.bat`
2. `start_frontend.bat`
3. Open http://localhost:5174

That's it! 🎉
