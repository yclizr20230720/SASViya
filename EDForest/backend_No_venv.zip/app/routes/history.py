"""
History Management Routes
"""
import os
import json
from datetime import datetime
from flask import Blueprint, request, jsonify, send_file
from werkzeug.utils import secure_filename

history_bp = Blueprint('history', __name__)

# History data directory
HISTORY_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'history')
INDEX_FILE = os.path.join(HISTORY_DIR, 'index.json')

# Ensure history directory exists
os.makedirs(HISTORY_DIR, exist_ok=True)


def load_index():
    """Load the history index file"""
    if os.path.exists(INDEX_FILE):
        try:
            with open(INDEX_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return []
    return []


def save_index(index_data):
    """Save the history index file"""
    with open(INDEX_FILE, 'w', encoding='utf-8') as f:
        json.dump(index_data, f, indent=2, ensure_ascii=False)


@history_bp.route('/save', methods=['POST'])
def save_analysis():
    """
    Save analysis results to history
    
    Expected JSON:
    {
        "username": "Daniel",
        "analysis_results": {...},
        "chart_data": {...},
        "parameters": {
            "target_cd": 45.0,
            "tolerance": 10,
            "filename": "data.csv"
        }
    }
    """
    try:
        data = request.json
        
        # Validate required fields
        if not data.get('username'):
            return jsonify({'error': 'Username is required'}), 400
        
        username = secure_filename(data['username'])
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        
        # Create filename: Username_YYYYMMDDHHMMSS.json
        filename = f"{username}_{timestamp}.json"
        filepath = os.path.join(HISTORY_DIR, filename)
        
        # Prepare data to save
        save_data = {
            'metadata': {
                'username': data['username'],
                'timestamp': timestamp,
                'datetime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'filename': filename
            },
            'parameters': data.get('parameters', {}),
            'analysis_results': data.get('analysis_results', {}),
            'chart_data': data.get('chart_data', {})
        }
        
        # Save analysis data
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(save_data, f, indent=2, ensure_ascii=False)
        
        # Update index
        index = load_index()
        index_entry = {
            'id': timestamp,
            'username': data['username'],
            'timestamp': timestamp,
            'datetime': save_data['metadata']['datetime'],
            'filename': filename,
            'parameters': {
                'target_cd': data.get('parameters', {}).get('target_cd'),
                'tolerance': data.get('parameters', {}).get('tolerance'),
                'data_file': data.get('parameters', {}).get('filename')
            },
            'summary': {
                'dof': data.get('analysis_results', {}).get('process_window', {}).get('dof'),
                'el': data.get('analysis_results', {}).get('process_window', {}).get('el'),
                'yield': data.get('analysis_results', {}).get('process_window', {}).get('yield_percent')
            }
        }
        index.append(index_entry)
        save_index(index)
        
        return jsonify({
            'success': True,
            'message': 'Analysis saved successfully',
            'filename': filename,
            'id': timestamp
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@history_bp.route('/list', methods=['GET'])
def list_history():
    """
    Get list of all saved analyses
    
    Query params:
    - username: Filter by username (optional)
    - limit: Number of results (optional, default: all)
    """
    try:
        index = load_index()
        
        # Filter by username if provided
        username = request.args.get('username')
        if username:
            index = [item for item in index if item['username'].lower() == username.lower()]
        
        # Sort by timestamp (newest first)
        index.sort(key=lambda x: x['timestamp'], reverse=True)
        
        # Limit results if specified
        limit = request.args.get('limit', type=int)
        if limit:
            index = index[:limit]
        
        return jsonify({
            'success': True,
            'count': len(index),
            'history': index
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@history_bp.route('/load/<analysis_id>', methods=['GET'])
def load_analysis(analysis_id):
    """
    Load a specific analysis by ID (timestamp)
    """
    try:
        # Find in index
        index = load_index()
        entry = next((item for item in index if item['id'] == analysis_id), None)
        
        if not entry:
            return jsonify({'error': 'Analysis not found'}), 404
        
        # Load full data
        filepath = os.path.join(HISTORY_DIR, entry['filename'])
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'Analysis file not found'}), 404
        
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return jsonify({
            'success': True,
            'data': data
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@history_bp.route('/delete/<analysis_id>', methods=['DELETE'])
def delete_analysis(analysis_id):
    """
    Delete a specific analysis by ID
    """
    try:
        # Find in index
        index = load_index()
        entry = next((item for item in index if item['id'] == analysis_id), None)
        
        if not entry:
            return jsonify({'error': 'Analysis not found'}), 404
        
        # Delete file
        filepath = os.path.join(HISTORY_DIR, entry['filename'])
        if os.path.exists(filepath):
            os.remove(filepath)
        
        # Remove from index
        index = [item for item in index if item['id'] != analysis_id]
        save_index(index)
        
        return jsonify({
            'success': True,
            'message': 'Analysis deleted successfully'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@history_bp.route('/export/<analysis_id>', methods=['GET'])
def export_analysis(analysis_id):
    """
    Export analysis as downloadable JSON file
    """
    try:
        # Find in index
        index = load_index()
        entry = next((item for item in index if item['id'] == analysis_id), None)
        
        if not entry:
            return jsonify({'error': 'Analysis not found'}), 404
        
        filepath = os.path.join(HISTORY_DIR, entry['filename'])
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'Analysis file not found'}), 404
        
        return send_file(
            filepath,
            mimetype='application/json',
            as_attachment=True,
            download_name=entry['filename']
        )
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@history_bp.route('/stats', methods=['GET'])
def get_stats():
    """
    Get statistics about saved analyses
    """
    try:
        index = load_index()
        
        # Calculate stats
        total = len(index)
        users = list(set(item['username'] for item in index))
        
        # Group by user
        by_user = {}
        for item in index:
            username = item['username']
            if username not in by_user:
                by_user[username] = 0
            by_user[username] += 1
        
        # Calculate monthly count (current month)
        from datetime import datetime
        now = datetime.now()
        current_month = now.month
        current_year = now.year
        
        monthly_count = 0
        for item in index:
            # Parse timestamp: YYYYMMDDHHMMSS
            timestamp = item['timestamp']
            year = int(timestamp[:4])
            month = int(timestamp[4:6])
            if year == current_year and month == current_month:
                monthly_count += 1
        
        # Group by tool (based on data filename or parameters)
        by_tool = {
            'EDForest': total  # For now, all analyses are EDForest
        }
        
        # Count unique users per tool
        users_per_tool = {
            'EDForest': len(users)
        }
        
        return jsonify({
            'success': True,
            'stats': {
                'total_analyses': total,
                'unique_users': len(users),
                'monthly_count': monthly_count,
                'users': users,
                'by_user': by_user,
                'by_tool': by_tool,
                'users_per_tool': users_per_tool
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
