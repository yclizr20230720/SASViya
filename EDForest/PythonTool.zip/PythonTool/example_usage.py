"""
Example Usage of Bossung Curve Plotter
======================================
This script demonstrates various ways to use the Bossung plotter tool.
"""

from bossung_plotter import BossungPlotter, generate_mock_data
import matplotlib.pyplot as plt


def example_1_basic_usage():
    """Example 1: Basic usage with mock data"""
    print("\n" + "="*70)
    print("Example 1: Basic Bossung Curve Generation")
    print("="*70)
    
    # Generate mock data
    data = generate_mock_data('example_data.csv')
    
    # Create plotter
    plotter = BossungPlotter(data_file='example_data.csv')
    
    # Set specifications
    plotter.set_target_specs(target_cd=45.0, tolerance_percent=10)
    
    # Generate basic Bossung curves
    fig, ax = plotter.plot_bossung_curves()
    plt.savefig('example1_bossung.png', dpi=300, bbox_inches='tight')
    print("\nSaved: example1_bossung.png")
    plt.close()


def example_2_process_window():
    """Example 2: Process window analysis"""
    print("\n" + "="*70)
    print("Example 2: Process Window Analysis")
    print("="*70)
    
    # Load existing data
    plotter = BossungPlotter(data_file='example_data.csv')
    plotter.set_target_specs(target_cd=45.0, tolerance_percent=10)
    
    # Calculate metrics
    metrics = plotter.calculate_process_window_metrics()
    
    print("\nProcess Window Metrics:")
    print(f"  Depth of Focus (DOF):    {metrics['DOF']:.3f} μm")
    print(f"  Exposure Latitude (EL):  {metrics['EL']:.2f} mJ/cm²")
    print(f"  Optimal Dose:            {metrics['optimal_dose']:.2f} mJ/cm²")
    print(f"  Optimal Focus:           {metrics['optimal_focus']:.3f} μm")
    print(f"  Yield (in spec):         {metrics['in_spec_points']/metrics['total_points']*100:.1f}%")
    
    # Generate process window plot
    fig, ax = plotter.plot_process_window()
    plt.savefig('example2_process_window.png', dpi=300, bbox_inches='tight')
    print("\nSaved: example2_process_window.png")
    plt.close()


def example_3_different_styles():
    """Example 3: Different plot styles"""
    print("\n" + "="*70)
    print("Example 3: Different Plot Styles")
    print("="*70)
    
    plotter = BossungPlotter(data_file='example_data.csv')
    plotter.set_target_specs(target_cd=45.0, tolerance_percent=10)
    
    styles = ['professional', 'colorful', 'minimal']
    
    for style in styles:
        fig, ax = plotter.plot_bossung_curves(style=style)
        filename = f'example3_style_{style}.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"Saved: {filename}")
        plt.close()


def example_4_comprehensive_report():
    """Example 4: Comprehensive analysis report"""
    print("\n" + "="*70)
    print("Example 4: Comprehensive Analysis Report")
    print("="*70)
    
    plotter = BossungPlotter(data_file='example_data.csv')
    plotter.set_target_specs(target_cd=45.0, tolerance_percent=10)
    
    # Generate comprehensive analysis
    fig = plotter.plot_comprehensive_analysis(figsize=(20, 12))
    plt.savefig('example4_comprehensive.png', dpi=300, bbox_inches='tight')
    print("\nSaved: example4_comprehensive.png")
    plt.close()
    
    # Save all plots in multiple formats
    plotter.save_plots(prefix='example4_full', formats=['png', 'pdf'])


def example_5_custom_specifications():
    """Example 5: Different target specifications"""
    print("\n" + "="*70)
    print("Example 5: Comparing Different Specifications")
    print("="*70)
    
    plotter = BossungPlotter(data_file='example_data.csv')
    
    # Test different tolerance levels
    tolerances = [5, 10, 15]  # ±5%, ±10%, ±15%
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    for idx, tol in enumerate(tolerances):
        plotter.set_target_specs(target_cd=45.0, tolerance_percent=tol)
        metrics = plotter.calculate_process_window_metrics()
        
        # Plot on subplot
        doses = sorted(plotter.data['Dose'].unique())
        colors = plt.cm.viridis(range(len(doses)))
        
        for dose_idx, dose in enumerate(doses):
            dose_data = plotter.data[plotter.data['Dose'] == dose].sort_values('Defocus')
            axes[idx].plot(dose_data['Defocus'], dose_data['CD'], 
                          marker='o', markersize=4, linewidth=1.5,
                          label=f'{dose:.1f}' if dose_idx % 2 == 0 else '')
        
        axes[idx].axhline(y=45.0, color='red', linestyle='--', linewidth=2)
        axes[idx].axhspan(45.0 - 45.0*tol/100, 45.0 + 45.0*tol/100,
                         alpha=0.15, color='green')
        axes[idx].set_xlabel('Defocus (μm)', fontweight='bold')
        axes[idx].set_ylabel('CD (nm)', fontweight='bold')
        axes[idx].set_title(f'Tolerance: ±{tol}%\nDOF: {metrics["DOF"]:.3f} μm', 
                           fontweight='bold')
        axes[idx].grid(True, alpha=0.3)
        axes[idx].legend(fontsize=8, title='Dose')
    
    plt.tight_layout()
    plt.savefig('example5_tolerance_comparison.png', dpi=300, bbox_inches='tight')
    print("\nSaved: example5_tolerance_comparison.png")
    plt.close()


def example_6_dataframe_input():
    """Example 6: Using DataFrame directly instead of CSV"""
    print("\n" + "="*70)
    print("Example 6: Direct DataFrame Input")
    print("="*70)
    
    # Generate data as DataFrame
    df = generate_mock_data('temp_data.csv')
    
    # Create plotter with DataFrame
    plotter = BossungPlotter(dataframe=df)
    plotter.set_target_specs(target_cd=45.0, tolerance_percent=10)
    
    # Generate plots
    fig, ax = plotter.plot_bossung_curves()
    plt.savefig('example6_dataframe.png', dpi=300, bbox_inches='tight')
    print("\nSaved: example6_dataframe.png")
    plt.close()


if __name__ == "__main__":
    print("\n" + "="*70)
    print("Bossung Curve Plotter - Example Usage Demonstrations")
    print("="*70)
    
    # Run all examples
    example_1_basic_usage()
    example_2_process_window()
    example_3_different_styles()
    example_4_comprehensive_report()
    example_5_custom_specifications()
    example_6_dataframe_input()
    
    print("\n" + "="*70)
    print("All examples completed successfully!")
    print("Check the generated PNG and PDF files.")
    print("="*70)
