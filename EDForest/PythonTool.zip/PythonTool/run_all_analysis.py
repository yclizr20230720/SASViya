"""
Run All Bossung Curve Analyses
===============================
This script runs all analysis tools in sequence and generates a complete report.
"""

import os
import sys
from datetime import datetime


def print_header(text):
    """Print a formatted header."""
    print("\n" + "="*80)
    print(f"  {text}")
    print("="*80 + "\n")


def print_section(text):
    """Print a formatted section header."""
    print("\n" + "-"*80)
    print(f"  {text}")
    print("-"*80)


def run_analysis():
    """Run all analysis scripts."""
    
    print_header("BOSSUNG CURVE ANALYSIS - COMPLETE WORKFLOW")
    print(f"Analysis started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Step 1: Generate data and basic plots
    print_section("Step 1: Generating Mock Data and Basic Plots")
    try:
        from bossung_plotter import generate_mock_data, BossungPlotter
        
        # Generate mock data
        print("Generating mock lithography data...")
        data = generate_mock_data('lithography_data.csv')
        print(f"✓ Generated {len(data)} data points")
        
        # Create plotter
        print("\nInitializing Bossung plotter...")
        plotter = BossungPlotter(data_file='lithography_data.csv')
        plotter.set_target_specs(target_cd=45.0, tolerance_percent=10)
        print("✓ Plotter initialized")
        
        # Calculate basic metrics
        print("\nCalculating process window metrics...")
        metrics = plotter.calculate_process_window_metrics()
        print(f"✓ DOF: {metrics['DOF']:.3f} μm")
        print(f"✓ EL: {metrics['EL']:.2f} mJ/cm²")
        print(f"✓ Optimal Dose: {metrics['optimal_dose']:.2f} mJ/cm²")
        print(f"✓ Yield: {metrics['in_spec_points']/metrics['total_points']*100:.1f}%")
        
        # Generate basic plots
        print("\nGenerating basic plots...")
        plotter.save_plots(prefix='bossung_analysis', formats=['png', 'pdf'])
        print("✓ Basic plots saved")
        
    except Exception as e:
        print(f"✗ Error in Step 1: {e}")
        return False
    
    # Step 2: Advanced analysis
    print_section("Step 2: Advanced Curve Fitting and Analysis")
    try:
        from advanced_analysis import AdvancedBossungAnalysis
        import matplotlib.pyplot as plt
        
        # Create advanced analyzer
        print("Initializing advanced analyzer...")
        analyzer = AdvancedBossungAnalysis(plotter)
        print("✓ Advanced analyzer initialized")
        
        # Generate report
        print("\nGenerating process capability report...")
        report = analyzer.generate_process_capability_report()
        
        # Print key findings
        print("\nKey Findings:")
        print(f"  Process Capability (Cp): {report['Process Capability']['Cp Index']:.3f}")
        print(f"  Interpretation: {report['Process Capability']['Interpretation']}")
        print(f"  Best Dose for Target: {report['Best Dose for Target CD']['Dose (mJ/cm²)']:.2f} mJ/cm²")
        print(f"  CD Error: {report['Best Dose for Target CD']['Error from Target (nm)']:.3f} nm")
        
        # Generate advanced plots
        print("\nGenerating advanced plots...")
        
        fig1, _ = analyzer.plot_dose_sensitivity()
        fig1.savefig('advanced_dose_sensitivity.png', dpi=300, bbox_inches='tight')
        plt.close(fig1)
        print("✓ Dose sensitivity plot saved")
        
        fig2, fit_results = analyzer.plot_best_focus_vs_dose()
        fig2.savefig('advanced_best_focus.png', dpi=300, bbox_inches='tight')
        plt.close(fig2)
        print("✓ Best focus analysis saved")
        
        fig3, _ = analyzer.plot_curvature_analysis()
        fig3.savefig('advanced_curvature.png', dpi=300, bbox_inches='tight')
        plt.close(fig3)
        print("✓ Curvature analysis saved")
        
        # Save fit parameters
        fit_results.to_csv('bossung_fit_parameters.csv', index=False)
        print("✓ Fit parameters saved to CSV")
        
    except Exception as e:
        print(f"✗ Error in Step 2: {e}")
        return False
    
    # Step 3: Generate summary report
    print_section("Step 3: Generating Summary Report")
    try:
        # Create summary text file
        with open('analysis_summary.txt', 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("BOSSUNG CURVE ANALYSIS - SUMMARY REPORT\n")
            f.write("="*80 + "\n\n")
            f.write(f"Analysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Data File: lithography_data.csv\n")
            f.write(f"Total Data Points: {len(data)}\n\n")
            
            f.write("-"*80 + "\n")
            f.write("PROCESS WINDOW METRICS\n")
            f.write("-"*80 + "\n")
            for key, value in report['Process Window'].items():
                f.write(f"{key:.<50} {value:.3f}\n")
            
            f.write("\n" + "-"*80 + "\n")
            f.write("CD STATISTICS\n")
            f.write("-"*80 + "\n")
            for key, value in report['CD Statistics'].items():
                f.write(f"{key:.<50} {value:.3f}\n")
            
            f.write("\n" + "-"*80 + "\n")
            f.write("BEST DOSE FOR TARGET CD\n")
            f.write("-"*80 + "\n")
            for key, value in report['Best Dose for Target CD'].items():
                f.write(f"{key:.<50} {value:.3f}\n")
            
            f.write("\n" + "-"*80 + "\n")
            f.write("PROCESS CAPABILITY\n")
            f.write("-"*80 + "\n")
            for key, value in report['Process Capability'].items():
                if isinstance(value, float):
                    f.write(f"{key:.<50} {value:.3f}\n")
                else:
                    f.write(f"{key:.<50} {value}\n")
            
            f.write("\n" + "="*80 + "\n")
            f.write("GENERATED FILES\n")
            f.write("="*80 + "\n\n")
            
            files = [
                'lithography_data.csv',
                'bossung_analysis_curves.png',
                'bossung_analysis_curves.pdf',
                'bossung_analysis_process_window.png',
                'bossung_analysis_process_window.pdf',
                'bossung_analysis_comprehensive.png',
                'bossung_analysis_comprehensive.pdf',
                'advanced_dose_sensitivity.png',
                'advanced_best_focus.png',
                'advanced_curvature.png',
                'bossung_fit_parameters.csv',
                'analysis_summary.txt'
            ]
            
            for file in files:
                if os.path.exists(file):
                    size = os.path.getsize(file)
                    f.write(f"✓ {file:<50} ({size:,} bytes)\n")
            
            f.write("\n" + "="*80 + "\n")
            f.write("END OF REPORT\n")
            f.write("="*80 + "\n")
        
        print("✓ Summary report saved to analysis_summary.txt")
        
    except Exception as e:
        print(f"✗ Error in Step 3: {e}")
        return False
    
    # Final summary
    print_section("Analysis Complete!")
    print("\nGenerated Files:")
    print("  Data Files:")
    print("    • lithography_data.csv")
    print("    • bossung_fit_parameters.csv")
    print("    • analysis_summary.txt")
    print("\n  Basic Plots:")
    print("    • bossung_analysis_curves.png/pdf")
    print("    • bossung_analysis_process_window.png/pdf")
    print("    • bossung_analysis_comprehensive.png/pdf")
    print("\n  Advanced Plots:")
    print("    • advanced_dose_sensitivity.png")
    print("    • advanced_best_focus.png")
    print("    • advanced_curvature.png")
    
    print_header("ALL ANALYSES COMPLETED SUCCESSFULLY!")
    print(f"Analysis finished at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    return True


if __name__ == "__main__":
    success = run_analysis()
    sys.exit(0 if success else 1)
