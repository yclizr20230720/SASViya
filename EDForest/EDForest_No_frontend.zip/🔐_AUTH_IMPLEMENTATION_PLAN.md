# 🔐 Authentication & Authorization Implementation Plan

## Overview
Implementing a complete authentication and authorization system with dark/light mode toggle.

---

## Features to Implement

### 1. **Backend Authentication**
- User registration with email/password
- Login with JWT token generation
- Password hashing with bcrypt
- Token refresh mechanism
- Role-based access control (RBAC)
- User roles: Admin, Engineer, Viewer

### 2. **Frontend Authentication**
- Login page
- Registration page
- Protected routes
- Auth context/provider
- Token storage (localStorage)
- Auto-logout on token expiry

### 3. **Authorization & Roles**
- **Admin**: Full access, user management
- **Engineer**: Create/edit/delete own analyses
- **Viewer**: Read-only access

### 4. **Dark/Light Mode**
- Theme toggle in header
- Persistent theme preference
- CSS variables for theming
- Smooth transitions

---

## Implementation Steps

### Backend:
1. Create user model/storage (JSON file)
2. Create auth routes (register, login, refresh)
3. Add JWT configuration
4. Create auth middleware
5. Protect existing routes
6. Add user management endpoints

### Frontend:
1. Create AuthContext
2. Create Login/Register pages
3. Create ProtectedRoute component
4. Update Header with user menu
5. Add theme toggle
6. Update CSS for dark mode
7. Protect existing routes

---

## File Structure

### Backend:
```
backend/
├── app/
│   ├── routes/
│   │   └── auth.py (NEW)
│   ├── middleware/
│   │   └── auth_middleware.py (NEW)
│   └── models/
│       └── user.py (NEW)
├── users/
│   └── users.json (NEW - user database)
```

### Frontend:
```
frontend/src/
├── context/
│   ├── AuthContext.jsx (NEW)
│   └── ThemeContext.jsx (NEW)
├── pages/
│   ├── Login.jsx (NEW)
│   └── Register.jsx (NEW)
├── components/
│   ├── ProtectedRoute.jsx (NEW)
│   └── ThemeToggle.jsx (NEW)
```

---

## User Roles & Permissions

| Feature | Admin | Engineer | Viewer |
|---------|-------|----------|--------|
| View analyses | ✅ | ✅ | ✅ |
| Run analysis | ✅ | ✅ | ❌ |
| Save analysis | ✅ | ✅ | ❌ |
| Delete own analysis | ✅ | ✅ | ❌ |
| Delete any analysis | ✅ | ❌ | ❌ |
| View history | ✅ | ✅ | ✅ |
| User management | ✅ | ❌ | ❌ |

---

## Dark/Light Mode

### Theme Variables:
```css
:root {
  --bg-primary: #ffffff;
  --bg-secondary: #f9fafb;
  --text-primary: #111827;
  --text-secondary: #6b7280;
}

[data-theme="dark"] {
  --bg-primary: #1f2937;
  --bg-secondary: #111827;
  --text-primary: #f9fafb;
  --text-secondary: #d1d5db;
}
```

---

## Security Considerations

1. **Password Security**:
   - Bcrypt hashing (cost factor: 12)
   - Minimum 8 characters
   - No plain text storage

2. **JWT Tokens**:
   - Access token: 1 hour expiry
   - Refresh token: 7 days expiry
   - Secure HTTP-only cookies (production)

3. **API Protection**:
   - All sensitive routes require authentication
   - Role-based authorization checks
   - CORS configuration

---

## Next Steps

This is a large implementation. I'll create the core files systematically:

1. Backend auth system
2. Frontend auth context
3. Login/Register pages
4. Theme system
5. Integration & testing

Ready to proceed?
