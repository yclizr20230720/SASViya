# 🚀 Quick Start Guide - With Authentication

## ✅ System Status
- **Backend**: Running on http://localhost:5000
- **Frontend**: Running on http://localhost:5173
- **Authentication**: Enabled

## 🔐 Login Credentials

### Default Admin Account
```
Username: admin
Password: admin123
Role: Admin
```

## 📋 How to Use

### 1. Access the Application
Open your browser and navigate to:
```
http://localhost:5173
```

### 2. You'll Be Redirected to Login
- The application now requires authentication
- All pages are protected
- You must login to access any features

### 3. Login Options

**Option A: Use Admin Account**
- Username: `admin`
- Password: `admin123`
- You'll have full admin privileges

**Option B: Register New Account**
- Click "Sign Up" link on login page
- Fill in username, email, and password
- You'll be automatically logged in after registration
- New users have "user" role by default

### 4. After Login
- You'll be redirected to the Home page
- Your username will appear in the header
- Admin users will see an "Admin" badge
- Click "Logout" button to sign out

## 🎯 Features Available

### For All Users
- ✅ Access all analysis tools (EDForest, etc.)
- ✅ View analysis history
- ✅ Save analysis results
- ✅ Export data
- ✅ Change password

### For Admin Users
- ✅ All user features
- ✅ View all users (future feature)
- ✅ Manage user roles (future feature)
- ✅ Delete users (future feature)

## 🔧 Troubleshooting

### Can't Login?
1. Make sure backend is running (http://localhost:5000)
2. Check browser console for errors
3. Try the default admin credentials
4. Clear browser cache and localStorage

### Forgot Password?
- Currently no password reset feature
- Admin can reset passwords via backend
- Or delete `users.json` to reset all users

### Token Expired?
- Tokens expire after 24 hours
- Simply login again
- Your session will be restored

## 📁 User Data Storage

### Location
```
backend/users.json
```

### Format
```json
{
  "username": {
    "username": "admin",
    "email": "admin@vsmc.com",
    "password": "<hashed>",
    "role": "admin",
    "created_at": "2026-01-24T...",
    "last_login": "2026-01-24T..."
  }
}
```

### Backup
- Regularly backup `users.json`
- Passwords are hashed with bcrypt
- Cannot recover passwords, only reset

## 🛡️ Security Features

- ✅ Bcrypt password hashing
- ✅ JWT token authentication
- ✅ 24-hour token expiration
- ✅ Protected API routes
- ✅ Role-based access control
- ✅ Secure token storage

## 🔄 Session Management

### Token Storage
- Tokens stored in browser localStorage
- Automatically included in API requests
- Persists across page refreshes

### Logout
- Clears token from localStorage
- Redirects to login page
- Must login again to access

## 📊 API Endpoints

### Public (No Auth Required)
```
POST /api/v1/auth/register
POST /api/v1/auth/login
```

### Protected (Auth Required)
```
GET  /api/v1/auth/me
POST /api/v1/auth/change-password
GET  /api/v1/edforest/*
GET  /api/v1/history/*
```

### Admin Only
```
GET    /api/v1/auth/users
PUT    /api/v1/auth/users/<username>
DELETE /api/v1/auth/users/<username>
```

## 🎨 UI Features

### Login Page
- Clean, professional design
- Gradient background
- Form validation
- Error messages
- Demo credentials shown

### Register Page
- User-friendly form
- Real-time validation
- Password confirmation
- Visual feedback

### Header
- Shows logged-in user
- Admin badge for admins
- Logout button
- Theme toggle

## 🚀 Next Steps

1. **Login** with admin credentials
2. **Explore** the EDForest tool
3. **Create** some analyses
4. **Register** additional users if needed
5. **Test** the authentication flow

## 💡 Tips

- Keep the admin password secure
- Create separate accounts for different users
- Admin account cannot be deleted
- Tokens are valid for 24 hours
- Use HTTPS in production

---
**Status**: ✅ READY TO USE
**Backend**: http://localhost:5000
**Frontend**: http://localhost:5173
**Login**: admin / admin123
