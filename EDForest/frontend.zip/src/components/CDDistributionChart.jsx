import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Cell } from 'recharts'
import { Info } from 'lucide-react'

const CDDistributionChart = ({ data, targetLines }) => {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg">
        <p className="text-gray-500">No data available</p>
      </div>
    )
  }

  // Color bars based on proximity to target
  const getBarColor = (cdMid) => {
    if (!targetLines) return '#3b82f6'
    
    const { target_cd, upper_limit, lower_limit } = targetLines
    
    if (cdMid >= lower_limit && cdMid <= upper_limit) {
      return '#10b981' // Green - in spec
    } else {
      return '#60a5fa' // Blue - out of spec
    }
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg border border-gray-200">
      {/* Header with explanation */}
      <div className="mb-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-xl font-bold text-gray-900">CD Distribution - Statistical Analysis</h3>
          <div className="group relative">
            <Info className="w-5 h-5 text-blue-500 cursor-help" />
            <div className="invisible group-hover:visible absolute right-0 w-96 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
              <p className="font-semibold mb-2">Understanding CD Distribution:</p>
              <ul className="space-y-1 text-xs">
                <li>• Histogram shows frequency of CD measurements</li>
                <li>• X-axis: CD values in nanometers</li>
                <li>• Y-axis: Number of measurements (frequency)</li>
                <li>• Green bars = CD within specification</li>
                <li>• Blue bars = CD outside tolerance</li>
                <li>• Red dashed line = Target CD</li>
                <li>• Narrow distribution = consistent process</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Quality Insight:</span> The CD distribution histogram reveals process consistency and capability. 
            A narrow, centered distribution indicates excellent process control with most measurements near the target. 
            Wide distributions or multiple peaks suggest process instability that may require investigation.
          </p>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={450}>
        <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.5} />
          <XAxis 
            dataKey="cd_mid" 
            label={{ 
              value: 'CD (nm)', 
              position: 'insideBottom', 
              offset: -10,
              style: { fontSize: 14, fontWeight: 'bold' }
            }}
            stroke="#374151"
            tick={{ fontSize: 11 }}
            tickFormatter={(value) => value.toFixed(1)}
            angle={-45}
            textAnchor="end"
            height={80}
          />
          <YAxis 
            label={{ 
              value: 'Frequency', 
              angle: -90, 
              position: 'insideLeft',
              style: { fontSize: 14, fontWeight: 'bold' }
            }}
            stroke="#374151"
            tick={{ fontSize: 11 }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#fff', 
              border: '1px solid #d1d5db', 
              borderRadius: '8px',
              padding: '12px'
            }}
            formatter={(value, name) => {
              if (name === 'count') return [value, 'Frequency']
              return [value, name]
            }}
            labelFormatter={(label) => `CD: ${Number(label).toFixed(2)} nm`}
          />
          
          {/* Target CD line */}
          {targetLines && (
            <>
              <ReferenceLine 
                x={targetLines.target_cd} 
                stroke="#dc2626" 
                strokeDasharray="5 5"
                strokeWidth={2.5}
                label={{ 
                  value: 'Target', 
                  fill: '#dc2626', 
                  fontSize: 12, 
                  fontWeight: 'bold',
                  position: 'top' 
                }}
              />
              <ReferenceLine 
                x={targetLines.lower_limit} 
                stroke="#059669" 
                strokeDasharray="3 3"
                strokeWidth={1.5}
                opacity={0.6}
              />
              <ReferenceLine 
                x={targetLines.upper_limit} 
                stroke="#059669" 
                strokeDasharray="3 3"
                strokeWidth={1.5}
                opacity={0.6}
              />
            </>
          )}
          
          <Bar dataKey="count" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={getBarColor(entry.cd_mid)} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      
      {/* Legend */}
      <div className="flex justify-center gap-6 mt-4">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-green-500"></div>
          <span className="text-sm text-gray-700">Within Tolerance</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-blue-400"></div>
          <span className="text-sm text-gray-700">Outside Tolerance</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 border-2 border-red-600 border-dashed"></div>
          <span className="text-sm text-gray-700">Target CD</span>
        </div>
      </div>
      
      {/* Key Takeaways */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
          <p className="text-xs font-semibold text-green-800 mb-1">✓ Centered Distribution</p>
          <p className="text-xs text-gray-700">Peak near target CD indicates well-tuned process</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
          <p className="text-xs font-semibold text-yellow-800 mb-1">⚠ Wide Spread</p>
          <p className="text-xs text-gray-700">Large standard deviation suggests process variation</p>
        </div>
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <p className="text-xs font-semibold text-blue-800 mb-1">💡 Process Capability</p>
          <p className="text-xs text-gray-700">More green bars = higher yield and better Cpk</p>
        </div>
      </div>
    </div>
  )
}

export default CDDistributionChart
