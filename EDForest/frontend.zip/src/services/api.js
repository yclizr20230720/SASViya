import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api/v1'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Health Check
export const healthCheck = async () => {
  const response = await api.get('/health')
  return response.data
}

// EDForest / Bossung Curve Analysis
export const uploadData = async (file) => {
  const formData = new FormData()
  formData.append('file', file)
  
  const response = await api.post('/edforest/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  })
  return response.data
}

export const analyzeBossung = async (filepath, targetCD, tolerancePercent) => {
  const response = await api.post('/edforest/analyze', {
    filepath,
    target_cd: targetCD,
    tolerance_percent: tolerancePercent,
  })
  return response.data
}

export const generatePlots = async (filepath, targetCD, tolerancePercent, plotTypes) => {
  const response = await api.post('/edforest/generate-plots', {
    filepath,
    target_cd: targetCD,
    tolerance_percent: tolerancePercent,
    plot_types: plotTypes,
  })
  return response.data
}

export const downloadFile = async (filename) => {
  const response = await api.get(`/edforest/download/${filename}`, {
    responseType: 'blob',
  })
  return response.data
}

export const generateMockData = async (doses = 9, defocusPoints = 17, targetCD = 45.0) => {
  const response = await api.post('/edforest/generate-mock-data', {
    doses,
    defocus_points: defocusPoints,
    target_cd: targetCD,
  })
  return response.data
}

// History Management
export const saveAnalysis = async (username, analysisResults, chartData, parameters) => {
  const response = await api.post('/history/save', {
    username,
    analysis_results: analysisResults,
    chart_data: chartData,
    parameters,
  })
  return response.data
}

export const listHistory = async (username = null, limit = null) => {
  const params = {}
  if (username) params.username = username
  if (limit) params.limit = limit
  
  const response = await api.get('/history/list', { params })
  return response.data
}

export const loadAnalysis = async (analysisId) => {
  const response = await api.get(`/history/load/${analysisId}`)
  return response.data
}

export const deleteAnalysis = async (analysisId) => {
  const response = await api.delete(`/history/delete/${analysisId}`)
  return response.data
}

export const exportAnalysis = async (analysisId, filename) => {
  const response = await api.get(`/history/export/${analysisId}`, {
    responseType: 'blob',
  })
  
  const blob = response.data
  const url = window.URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  window.URL.revokeObjectURL(url)
  document.body.removeChild(a)
}

export const getHistoryStats = async () => {
  const response = await api.get('/history/stats')
  return response.data
}

export default api
