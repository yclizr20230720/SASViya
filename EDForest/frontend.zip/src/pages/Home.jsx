import { Link } from 'react-router-dom'
import ToolCard from '../components/ToolCard'
import { 
  BarChart3, 
  Target, 
  Ruler, 
  RefreshCw, 
  Microscope, 
  Settings, 
  Search, 
  TrendingUp,
  Zap,
  Shield,
  Clock,
  Users,
  CheckCircle,
  ArrowRight,
  Sparkles
} from 'lucide-react'

const Home = () => {
  const tools = [
    {
      icon: BarChart3,
      title: 'EDForest - Bossung Curve Analysis',
      description: 'Generate professional Bossung curves and analyze process windows with advanced DOF and EL metrics calculation.',
      features: [
        'Upload CSV data or generate mock data',
        'Interactive Bossung curves visualization',
        'Process window metrics (DOF, EL)',
        'Export plots in PNG/PDF formats'
      ],
      link: '/edforest',
      status: 'active'
    },
    {
      icon: Target,
      title: 'Focus-Exposure Matrix (FEM)',
      description: 'Analyze dose-focus matrices to identify optimal lithography conditions and process margins.',
      features: [
        'Contour map visualization',
        'Optimal point detection',
        'Process window extraction',
        'Multi-pattern analysis'
      ],
      link: '/fem',
      status: 'coming-soon'
    },
    {
      icon: Ruler,
      title: 'CD Uniformity Analysis',
      description: 'Evaluate critical dimension uniformity across wafer with statistical analysis and trend monitoring.',
      features: [
        'Wafer map visualization',
        'Statistical analysis (mean, std, range)',
        'Trend charts and histograms',
        'Zone-based analysis'
      ],
      link: '/cd-uniformity',
      status: 'coming-soon'
    },
    {
      icon: RefreshCw,
      title: 'Overlay Analysis',
      description: 'Analyze overlay performance and alignment accuracy with vector plots and CPK analysis.',
      features: [
        'Vector field plots',
        'CPK and PPK analysis',
        'Trend monitoring',
        'Correctables extraction'
      ],
      link: '/overlay',
      status: 'coming-soon'
    },
    {
      icon: Microscope,
      title: 'Scanner Performance Monitor',
      description: 'Real-time scanner performance tracking with comprehensive diagnostics and alert system.',
      features: [
        'Live performance dashboards',
        'Alert and notification system',
        'Historical trend analysis',
        'Equipment health scoring'
      ],
      link: '/scanner-monitor',
      status: 'coming-soon'
    },
    {
      icon: Settings,
      title: 'Track Equipment Monitor',
      description: 'Monitor track equipment parameters including temperature, humidity, and maintenance status.',
      features: [
        'Real-time parameter tracking',
        'Maintenance alerts',
        'Recipe management',
        'Performance trending'
      ],
      link: '/track-monitor',
      status: 'coming-soon'
    },
    {
      icon: Search,
      title: 'Defect Analysis',
      description: 'Comprehensive defect pattern analysis with root cause identification and classification.',
      features: [
        'Pareto charts',
        'Spatial defect mapping',
        'Defect classification',
        'Root cause analysis'
      ],
      link: '/defect-analysis',
      status: 'coming-soon'
    },
    {
      icon: TrendingUp,
      title: 'Yield Prediction',
      description: 'Predict yield based on process parameters using machine learning models and what-if analysis.',
      features: [
        'ML-based predictions',
        'What-if scenario analysis',
        'Parameter optimization',
        'Actionable recommendations'
      ],
      link: '/yield-prediction',
      status: 'coming-soon'
    }
  ]

  const features = [
    {
      icon: Zap,
      title: 'Real-time Analysis',
      description: 'Instant data processing and visualization for quick decision-making'
    },
    {
      icon: Shield,
      title: 'Data Security',
      description: 'Secure storage and processing of sensitive lithography data'
    },
    {
      icon: Clock,
      title: '24/7 Availability',
      description: 'Access your analysis tools anytime, anywhere'
    },
    {
      icon: Users,
      title: 'Team Collaboration',
      description: 'Share analyses and insights with your team members'
    }
  ]

  const benefits = [
    'Reduce analysis time by 80% with automated workflows',
    'Improve process yield through data-driven insights',
    'Standardize analysis methods across teams',
    'Track historical trends and process improvements',
    'Export publication-ready charts and reports',
    'Integrate with existing fab data systems'
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary-600 to-secondary-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="animate-fade-in">
              <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-4">
                <Sparkles className="w-4 h-4" />
                <span className="text-sm font-medium">Advanced Lithography Analytics</span>
              </div>
              <h1 className="text-5xl font-extrabold mb-4">
                VSMC Litho Platform
              </h1>
              <p className="text-xl text-blue-100 mb-6">
                Modern web portal for scanner, track, and lithography process data analysis. 
                Transform your fab data into actionable insights.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/edforest"
                  className="inline-flex items-center space-x-2 bg-white text-primary-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
                >
                  <span>Start Analysis</span>
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <Link
                  to="/history"
                  className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/20 transition-colors border border-white/30"
                >
                  <span>View History</span>
                </Link>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="text-4xl font-bold mb-2">8</div>
                <div className="text-sm text-blue-100">Analysis Tools</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="text-4xl font-bold mb-2">∞</div>
                <div className="text-sm text-blue-100">Data Points</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="text-4xl font-bold mb-2">24/7</div>
                <div className="text-sm text-blue-100">Availability</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="text-4xl font-bold mb-2">100%</div>
                <div className="text-sm text-blue-100">Secure</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-lg flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-primary-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-sm text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Tools Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Analysis Tools</h2>
          <p className="text-gray-600">
            Comprehensive suite of lithography analysis tools for process optimization
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {tools.map((tool, index) => (
            <div key={index} className="animate-fade-in" style={{ animationDelay: `${index * 0.05}s` }}>
              <ToolCard {...tool} />
            </div>
          ))}
        </div>
      </div>

      {/* Benefits Section */}
      <div className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Why Choose VSMC Litho Platform?
              </h2>
              <p className="text-gray-600 mb-6">
                Streamline your lithography data analysis workflow with our comprehensive platform. 
                Built by engineers, for engineers.
              </p>
              <div className="space-y-3">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-2xl p-8 border border-primary-200">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Get Started Today</h3>
              <p className="text-gray-600 mb-6">
                Start analyzing your lithography data in minutes. No installation required, 
                just upload your data and get instant insights.
              </p>
              <div className="space-y-4">
                <Link
                  to="/edforest"
                  className="block w-full bg-primary-600 text-white text-center px-6 py-3 rounded-lg font-semibold hover:bg-primary-700 transition-colors"
                >
                  Try EDForest Tool
                </Link>
                <Link
                  to="/about"
                  className="block w-full bg-white text-primary-600 text-center px-6 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors border border-primary-200"
                >
                  Learn More
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-primary-600 to-secondary-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Optimize Your Process?</h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Join leading semiconductor fabs using VSMC Litho Platform for data-driven process optimization
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                to="/edforest"
                className="inline-flex items-center space-x-2 bg-white text-primary-600 px-8 py-4 rounded-lg font-semibold hover:bg-blue-50 transition-colors text-lg"
              >
                <span>Start Free Analysis</span>
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
