import { useState } from 'react'
import { Upload, Play, Download, Sparkles, AlertCircle, CheckCircle, Loader, Save } from 'lucide-react'
import { uploadData, analyzeBossung, generatePlots, generateMockData, downloadFile, saveAnalysis } from '../services/api'
import BossungChart from '../components/BossungChart'
import ProcessWindowChart from '../components/ProcessWindowChart'
import CDDistributionChart from '../components/CDDistributionChart'
import DoseSensitivityChart from '../components/DoseSensitivityChart'
import BestFocusChart from '../components/BestFocusChart'
import CDBestFocusChart from '../components/CDBestFocusChart'
import CurvatureChart from '../components/CurvatureChart'
import ModelFitChart from '../components/ModelFitChart'

const EDForest = () => {
  const [file, setFile] = useState(null)
  const [uploadedData, setUploadedData] = useState(null)
  const [targetCD, setTargetCD] = useState(45.0)
  const [tolerance, setTolerance] = useState(10)
  const [username, setUsername] = useState('')
  const [analysisResults, setAnalysisResults] = useState(null)
  const [chartData, setChartData] = useState(null)
  const [plots, setPlots] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [activeTab, setActiveTab] = useState('upload')

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0]
    if (selectedFile) {
      setFile(selectedFile)
      setError(null)
    }
  }

  const handleUpload = async () => {
    if (!file) {
      setError('Please select a file first')
      return
    }

    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const result = await uploadData(file)
      setUploadedData(result.data)
      setSuccess('File uploaded successfully!')
      setActiveTab('analyze')
    } catch (err) {
      setError(err.response?.data?.error || 'Upload failed')
    } finally {
      setLoading(false)
    }
  }

  const handleGenerateMockData = async () => {
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const result = await generateMockData(9, 17, targetCD)
      setUploadedData({
        filename: result.filename,
        filepath: result.filepath,
        rows: result.rows,
        preview: result.preview,
      })
      setSuccess('Mock data generated successfully!')
      setActiveTab('analyze')
    } catch (err) {
      setError(err.response?.data?.error || 'Mock data generation failed')
    } finally {
      setLoading(false)
    }
  }

  const handleAnalyze = async () => {
    if (!uploadedData) {
      setError('Please upload data first')
      return
    }

    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const result = await analyzeBossung(uploadedData.filepath, targetCD, tolerance)
      setAnalysisResults(result.results)
      setChartData(result.chart_data)
      setSuccess('Analysis completed successfully!')
      setActiveTab('results')
    } catch (err) {
      setError(err.response?.data?.error || 'Analysis failed')
    } finally {
      setLoading(false)
    }
  }

  const handleGeneratePlots = async () => {
    if (!uploadedData) {
      setError('Please upload data first')
      return
    }

    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const result = await generatePlots(
        uploadedData.filepath,
        targetCD,
        tolerance,
        ['bossung', 'process_window', 'comprehensive']
      )
      setPlots(result.plots)
      setSuccess('Plots generated successfully!')
    } catch (err) {
      setError(err.response?.data?.error || 'Plot generation failed')
    } finally {
      setLoading(false)
    }
  }

  const handleDownload = async (filename) => {
    try {
      const blob = await downloadFile(filename)
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (err) {
      setError('Download failed')
    }
  }

  const handleSaveAnalysis = async () => {
    if (!username.trim()) {
      setError('Please enter your username to save analysis')
      return
    }

    if (!analysisResults || !chartData) {
      setError('No analysis results to save')
      return
    }

    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const result = await saveAnalysis(
        username,
        analysisResults,
        chartData,
        {
          target_cd: targetCD,
          tolerance: tolerance,
          filename: uploadedData?.filename || 'unknown'
        }
      )
      setSuccess(`Analysis saved successfully! ID: ${result.id}`)
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to save analysis')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">EDForest - Bossung Curve Analysis</h1>
          <p className="text-gray-600">
            Generate professional Bossung curves and analyze process windows with advanced metrics
          </p>
        </div>

        {/* Alerts */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-start">
            <AlertCircle className="w-5 h-5 text-red-600 mr-3 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-medium text-red-800">Error</h3>
              <p className="text-sm text-red-700 mt-1">{error}</p>
            </div>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6 flex items-start">
            <CheckCircle className="w-5 h-5 text-green-600 mr-3 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-medium text-green-800">Success</h3>
              <p className="text-sm text-green-700 mt-1">{success}</p>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-lg mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6" aria-label="Tabs">
              {['upload', 'analyze', 'results'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm capitalize ${
                    activeTab === tab
                      ? 'border-primary-600 text-primary-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {/* Upload Tab */}
            {activeTab === 'upload' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Upload Data</h3>
                  
                  {/* File Upload */}
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary-400 transition-colors">
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <label className="cursor-pointer">
                      <span className="text-primary-600 hover:text-primary-700 font-medium">
                        Choose a file
                      </span>
                      <input
                        type="file"
                        className="hidden"
                        accept=".csv,.txt"
                        onChange={handleFileChange}
                      />
                    </label>
                    <p className="text-sm text-gray-500 mt-2">or drag and drop</p>
                    <p className="text-xs text-gray-400 mt-1">CSV or TXT (max 16MB)</p>
                    {file && (
                      <p className="text-sm text-gray-700 mt-4 font-medium">
                        Selected: {file.name}
                      </p>
                    )}
                  </div>

                  <button
                    onClick={handleUpload}
                    disabled={!file || loading}
                    className="mt-4 w-full bg-primary-600 text-white py-3 px-4 rounded-lg hover:bg-primary-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
                  >
                    {loading ? (
                      <>
                        <Loader className="w-5 h-5 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="w-5 h-5 mr-2" />
                        Upload File
                      </>
                    )}
                  </button>
                </div>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-300"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-white text-gray-500">OR</span>
                  </div>
                </div>

                {/* Generate Mock Data */}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Generate Mock Data</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Generate realistic lithography data for testing and demonstration
                  </p>
                  <button
                    onClick={handleGenerateMockData}
                    disabled={loading}
                    className="w-full bg-secondary-600 text-white py-3 px-4 rounded-lg hover:bg-secondary-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
                  >
                    {loading ? (
                      <>
                        <Loader className="w-5 h-5 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Generate Mock Data
                      </>
                    )}
                  </button>
                </div>

                {/* Data Preview */}
                {uploadedData && (
                  <div className="mt-6 bg-gray-50 rounded-lg p-4">
                    <h4 className="font-semibold text-gray-900 mb-2">Data Summary</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Filename:</span>
                        <span className="ml-2 font-medium">{uploadedData.filename}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Rows:</span>
                        <span className="ml-2 font-medium">{uploadedData.rows}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Analyze Tab */}
            {activeTab === 'analyze' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Analysis Parameters</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Username (for saving)
                      </label>
                      <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="Enter your name"
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Target CD (nm)
                      </label>
                      <input
                        type="number"
                        value={targetCD}
                        onChange={(e) => setTargetCD(parseFloat(e.target.value))}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        step="0.1"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Tolerance (%)
                      </label>
                      <input
                        type="number"
                        value={tolerance}
                        onChange={(e) => setTolerance(parseFloat(e.target.value))}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        step="1"
                      />
                    </div>
                  </div>

                  <button
                    onClick={handleAnalyze}
                    disabled={!uploadedData || loading}
                    className="mt-6 w-full bg-primary-600 text-white py-3 px-4 rounded-lg hover:bg-primary-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
                  >
                    {loading ? (
                      <>
                        <Loader className="w-5 h-5 mr-2 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Play className="w-5 h-5 mr-2" />
                        Run Analysis
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleGeneratePlots}
                    disabled={!uploadedData || loading}
                    className="mt-4 w-full bg-secondary-600 text-white py-3 px-4 rounded-lg hover:bg-secondary-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
                  >
                    {loading ? (
                      <>
                        <Loader className="w-5 h-5 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Generate Plots
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Results Tab */}
            {activeTab === 'results' && (
              <div className="space-y-8">
                {analysisResults ? (
                  <>
                    {/* Interactive Charts */}
                    {chartData && (
                      <div className="space-y-8">
                        {/* Introduction Banner */}
                        <div className="bg-gradient-to-r from-primary-50 to-secondary-50 rounded-lg p-6 border-l-4 border-primary-500">
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">📊 Interactive Charts - Process Window Analysis</h3>
                          <p className="text-sm text-gray-600 mb-3">
                            View and interact with your analysis results in real-time. Hover over data points for detailed information, zoom to explore specific regions.
                          </p>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                            <div className="bg-white rounded p-3">
                              <span className="font-semibold text-blue-700">💡 Tip:</span> Look for the intersection of curves near the target CD to identify the optimal process point.
                            </div>
                            <div className="bg-white rounded p-3">
                              <span className="font-semibold text-green-700">✓ Goal:</span> Maximize the green region (in-spec area) for robust manufacturing.
                            </div>
                            <div className="bg-white rounded p-3">
                              <span className="font-semibold text-purple-700">📈 Analysis:</span> Steeper curves indicate higher sensitivity to process variations.
                            </div>
                          </div>
                        </div>

                        {/* Section 1: Main Analysis */}
                        <div className="space-y-6">
                          <div className="border-l-4 border-blue-500 pl-4">
                            <h2 className="text-2xl font-bold text-gray-900 mb-1">Section 1: Main Analysis</h2>
                            <p className="text-sm text-gray-600">Core Bossung curve analysis and process window evaluation</p>
                          </div>

                          {/* Bossung Curves Chart */}
                          <BossungChart 
                            data={chartData.bossung_curves}
                            targetLines={chartData.target_lines}
                            doses={chartData.doses}
                          />

                          {/* Process Window Chart */}
                          <ProcessWindowChart 
                            data={chartData.process_window}
                            targetLines={chartData.target_lines}
                          />

                          {/* CD Distribution Chart */}
                          <CDDistributionChart 
                            data={chartData.cd_distribution}
                            targetLines={chartData.target_lines}
                          />
                        </div>

                        {/* Section 2: Advanced Analysis */}
                        {chartData.advanced_metrics && (
                          <div className="space-y-6">
                            <div className="border-l-4 border-purple-500 pl-4">
                              <h2 className="text-2xl font-bold text-gray-900 mb-1">Section 2: Advanced Analysis</h2>
                              <p className="text-sm text-gray-600">Curve fitting analysis and dose optimization metrics</p>
                            </div>

                            {/* Dose Sensitivity Chart */}
                            <DoseSensitivityChart 
                              data={chartData.bossung_curves}
                              targetLines={chartData.target_lines}
                            />

                            {/* Best Focus vs Dose */}
                            {chartData.advanced_metrics.best_focus_vs_dose && chartData.advanced_metrics.best_focus_vs_dose.length > 0 && (
                              <BestFocusChart 
                                data={chartData.advanced_metrics.best_focus_vs_dose}
                              />
                            )}

                            {/* CD at Best Focus vs Dose */}
                            {chartData.advanced_metrics.cd_at_best_focus && chartData.advanced_metrics.cd_at_best_focus.length > 0 && (
                              <CDBestFocusChart 
                                data={chartData.advanced_metrics.cd_at_best_focus}
                                targetLines={chartData.target_lines}
                              />
                            )}
                          </div>
                        )}

                        {/* Section 3: Model Quality */}
                        {chartData.advanced_metrics && (
                          <div className="space-y-6">
                            <div className="border-l-4 border-orange-500 pl-4">
                              <h2 className="text-2xl font-bold text-gray-900 mb-1">Section 3: Model Quality</h2>
                              <p className="text-sm text-gray-600">Curve fitting quality and process robustness indicators</p>
                            </div>

                            {/* Curvature Analysis */}
                            {chartData.advanced_metrics.curvature_vs_dose && chartData.advanced_metrics.curvature_vs_dose.length > 0 && (
                              <CurvatureChart 
                                data={chartData.advanced_metrics.curvature_vs_dose}
                              />
                            )}

                            {/* Model Fit Quality */}
                            {chartData.advanced_metrics.model_fit_quality && chartData.advanced_metrics.model_fit_quality.length > 0 && (
                              <ModelFitChart 
                                data={chartData.advanced_metrics.model_fit_quality}
                              />
                            )}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Section 4: Process Metrics */}
                    <div className="space-y-6">
                      <div className="border-l-4 border-green-500 pl-4">
                        <h2 className="text-2xl font-bold text-gray-900 mb-1">Section 4: Process Metrics Summary</h2>
                        <p className="text-sm text-gray-600">Key performance indicators for manufacturing decision-making</p>
                      </div>

                      {/* Save Analysis Button */}
                      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-6 border-l-4 border-green-500">
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">💾 Save This Analysis</h3>
                        <p className="text-sm text-gray-600 mb-4">
                          Save your analysis results to review later in the History page. All charts and metrics will be preserved.
                        </p>
                        <button
                          onClick={handleSaveAnalysis}
                          disabled={!username.trim() || loading}
                          className="w-full md:w-auto bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
                        >
                          {loading ? (
                            <>
                              <Loader className="w-5 h-5 mr-2 animate-spin" />
                              Saving...
                            </>
                          ) : (
                            <>
                              <Save className="w-5 h-5 mr-2" />
                              Save Analysis
                            </>
                          )}
                        </button>
                        {!username.trim() && (
                          <p className="text-xs text-orange-600 mt-2">
                            ⚠ Please enter your username in the Analyze tab to save
                          </p>
                        )}
                      </div>

                      {/* Process Window Metrics */}
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-4">Process Window Metrics</h3>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          <MetricCard
                            label="DOF (Depth of Focus)"
                            value={analysisResults.process_window.dof.toFixed(3)}
                            unit="μm"
                            description="Focus range where CD stays in spec"
                          />
                          <MetricCard
                            label="EL (Exposure Latitude)"
                            value={analysisResults.process_window.el.toFixed(2)}
                            unit="mJ/cm²"
                            description="Dose range where CD stays in spec"
                          />
                          <MetricCard
                            label="Optimal Dose"
                            value={analysisResults.process_window.optimal_dose.toFixed(2)}
                            unit="mJ/cm²"
                            description="Best exposure dose for target CD"
                          />
                          <MetricCard
                            label="Optimal Focus"
                            value={analysisResults.process_window.optimal_focus.toFixed(3)}
                            unit="μm"
                            description="Best focus position for target CD"
                          />
                          <MetricCard
                            label="Process Yield"
                            value={analysisResults.process_window.yield_percent.toFixed(1)}
                            unit="%"
                            description="Percentage of points within spec"
                          />
                          <MetricCard
                            label="In Spec Points"
                            value={`${analysisResults.process_window.in_spec_points}/${analysisResults.process_window.total_points}`}
                            unit="points"
                            description="Data points meeting specifications"
                          />
                        </div>
                      </div>

                      {/* CD Statistics */}
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-4">CD Statistics</h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <MetricCard
                            label="Mean CD"
                            value={analysisResults.cd_statistics.mean.toFixed(2)}
                            unit="nm"
                            description="Average critical dimension"
                          />
                          <MetricCard
                            label="Std Dev"
                            value={analysisResults.cd_statistics.std.toFixed(2)}
                            unit="nm"
                            description="CD variation (lower is better)"
                          />
                          <MetricCard
                            label="Min CD"
                            value={analysisResults.cd_statistics.min.toFixed(2)}
                            unit="nm"
                            description="Smallest measured CD"
                          />
                          <MetricCard
                            label="Max CD"
                            value={analysisResults.cd_statistics.max.toFixed(2)}
                            unit="nm"
                            description="Largest measured CD"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Section 5: Download Options */}
                    {plots && (
                      <div className="space-y-6">
                        <div className="border-l-4 border-indigo-500 pl-4">
                          <h2 className="text-2xl font-bold text-gray-900 mb-1">Section 5: Download Static Plots</h2>
                          <p className="text-sm text-gray-600">High-resolution PNG/PDF versions for reports and presentations</p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {Object.entries(plots).map(([key, filename]) => (
                            <button
                              key={key}
                              onClick={() => handleDownload(filename)}
                              className="flex items-center justify-center space-x-2 bg-white border-2 border-gray-200 rounded-lg p-4 hover:border-primary-400 hover:bg-primary-50 transition-colors"
                            >
                              <Download className="w-5 h-5 text-primary-600" />
                              <span className="text-sm font-medium text-gray-700">
                                {key.replace('_', ' ').toUpperCase()}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-gray-500">No analysis results yet. Run analysis first.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

const MetricCard = ({ label, value, unit, description }) => (
  <div className="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-lg p-4 hover:shadow-md transition-shadow">
    <div className="text-sm text-gray-600 mb-1">{label}</div>
    <div className="text-2xl font-bold text-gray-900 mb-1">
      {value} <span className="text-sm font-normal text-gray-600">{unit}</span>
    </div>
    {description && (
      <div className="text-xs text-gray-500 mt-1">{description}</div>
    )}
  </div>
)

export default EDForest
