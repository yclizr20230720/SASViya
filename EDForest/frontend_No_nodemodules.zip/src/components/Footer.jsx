const Footer = () => {
  const currentYear = new Date().getFullYear()
  
  return (
    <footer className="bg-white border-t border-gray-200 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-center md:text-left">
            <p className="text-sm text-gray-600">
              © {currentYear} <span className="font-semibold gradient-text">VSMC Litho Platform</span>
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Advanced Lithography Analysis Suite
            </p>
          </div>
          
          <div className="flex space-x-6 text-sm text-gray-600">
            <a href="#" className="hover:text-primary-600 transition-colors">Documentation</a>
            <a href="#" className="hover:text-primary-600 transition-colors">API</a>
            <a href="#" className="hover:text-primary-600 transition-colors">Support</a>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
