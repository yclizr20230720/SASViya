import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts'
import { Info } from 'lucide-react'

const BestFocusChart = ({ data }) => {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg">
        <p className="text-gray-500">No data available</p>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      {/* Header with explanation */}
      <div className="mb-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-xl font-bold text-gray-900">Best Focus Position vs Exposure Dose</h3>
          <div className="group relative">
            <Info className="w-5 h-5 text-blue-500 cursor-help" />
            <div className="invisible group-hover:visible absolute right-0 w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
              <p className="font-semibold mb-2">Understanding Best Focus:</p>
              <ul className="space-y-1 text-xs">
                <li>• Shows the optimal focus position for each dose</li>
                <li>• Calculated from parabolic fit of Bossung curves</li>
                <li>• Ideal: best focus near zero (nominal focus)</li>
                <li>• Large shifts indicate dose-dependent focus effects</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Engineering Insight:</span> This chart reveals how the optimal focus position 
            changes with exposure dose. Ideally, best focus should remain close to zero across all doses, indicating a 
            stable process. Large variations suggest dose-dependent aberrations or resist effects that may require 
            scanner optimization.
          </p>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.5} />
          <XAxis 
            dataKey="dose" 
            label={{ value: 'Exposure Dose (mJ/cm²)', position: 'insideBottom', offset: -10, style: { fontSize: 14, fontWeight: 'bold' } }}
            stroke="#374151"
            tick={{ fontSize: 12 }}
          />
          <YAxis 
            label={{ value: 'Best Focus (μm)', angle: -90, position: 'insideLeft', style: { fontSize: 14, fontWeight: 'bold' } }}
            stroke="#374151"
            tick={{ fontSize: 12 }}
          />
          <Tooltip 
            contentStyle={{ backgroundColor: '#fff', border: '1px solid #d1d5db', borderRadius: '8px', padding: '12px' }}
            formatter={(value) => [`${value.toFixed(3)} μm`, 'Best Focus']}
            labelFormatter={(label) => `Dose: ${label.toFixed(1)} mJ/cm²`}
          />
          <Legend wrapperStyle={{ paddingTop: '20px' }} />
          
          <ReferenceLine 
            y={0} 
            stroke="#dc2626" 
            strokeDasharray="5 5"
            strokeWidth={2}
            label={{ value: 'Nominal Focus', fill: '#dc2626', fontSize: 12, fontWeight: 'bold', position: 'right' }}
          />
          
          <Line
            type="monotone"
            dataKey="best_focus"
            name="Best Focus"
            stroke="#8b5cf6"
            strokeWidth={3}
            dot={{ r: 6, fill: '#8b5cf6' }}
            activeDot={{ r: 8 }}
          />
        </LineChart>
      </ResponsiveContainer>
      
      {/* Key Takeaways */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-green-800 mb-1">✓ Good Process</p>
          <p className="text-xs text-gray-700">Best focus stays within ±0.05 μm of nominal</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-yellow-800 mb-1">⚠ Watch Out</p>
          <p className="text-xs text-gray-700">Systematic drift indicates optical or resist issues</p>
        </div>
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-blue-800 mb-1">💡 Tip</p>
          <p className="text-xs text-gray-700">Use dose with best focus closest to zero</p>
        </div>
      </div>
    </div>
  )
}

export default BestFocusChart
