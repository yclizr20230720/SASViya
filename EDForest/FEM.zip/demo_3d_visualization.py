"""
Demo: 3D Visualization of FEM Data
Shows what the 3D plots look like without running full analysis
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

print("="*70)
print("3D FEM VISUALIZATION DEMO".center(70))
print("="*70)

# Generate sample FEM data
print("\nGenerating sample FEM data...")
focus_values = np.linspace(-0.3, 0.3, 7)
exposure_values = np.linspace(18, 26, 9)

# Create measurement points
F_data, E_data = np.meshgrid(focus_values, exposure_values)
F_data = F_data.ravel()
E_data = E_data.ravel()

# Simple CD model
Es = 22.0
F_best = 0.0
w = 130.0
delta = F_data - F_best
E_ratio = 1 - E_data / Es
CD_data = w * np.sqrt(np.maximum(0, 1 - 2 * E_ratio)) + 50 * delta**2 + 10 * delta**4
CD_data += np.random.normal(0, 2, size=len(CD_data))

# Create smooth surface for visualization
exp_range = np.linspace(18, 26, 50)
focus_range = np.linspace(-0.3, 0.3, 50)
E_grid, F_grid = np.meshgrid(exp_range, focus_range)

# Calculate CD on grid
delta_grid = F_grid - F_best
E_ratio_grid = 1 - E_grid / Es
CD_grid = w * np.sqrt(np.maximum(0, 1 - 2 * E_ratio_grid)) + 50 * delta_grid**2 + 10 * delta_grid**4

print(f"  Data points: {len(CD_data)}")
print(f"  Focus range: {F_data.min():.2f} to {F_data.max():.2f} μm")
print(f"  Exposure range: {E_data.min():.1f} to {E_data.max():.1f} mJ/cm²")
print(f"  CD range: {CD_data.min():.1f} to {CD_data.max():.1f} nm")

# ============================================================================
# Figure 1: Single 3D View
# ============================================================================
print("\nGenerating Figure 1: Single 3D Surface View...")

fig1 = plt.figure(figsize=(14, 10))
ax1 = fig1.add_subplot(111, projection='3d')

# Plot surface
surf1 = ax1.plot_surface(E_grid, F_grid, CD_grid, cmap='viridis', 
                        alpha=0.8, edgecolor='none', antialiased=True)

# Plot experimental data points
ax1.scatter(E_data, F_data, CD_data, 
           c='red', marker='o', s=50, edgecolors='black', linewidth=1,
           label='Experimental Data', alpha=0.9)

# Labels
ax1.set_xlabel('Exposure (mJ/cm²)', fontsize=12, fontweight='bold', labelpad=10)
ax1.set_ylabel('Focus (μm)', fontsize=12, fontweight='bold', labelpad=10)
ax1.set_zlabel('CD (nm)', fontsize=12, fontweight='bold', labelpad=10)
ax1.set_title('3D FEM Surface - Focus-Exposure-CD Relationship', 
             fontsize=14, fontweight='bold', pad=20)

# Colorbar
cbar1 = fig1.colorbar(surf1, ax=ax1, shrink=0.5, aspect=10)
cbar1.set_label('CD (nm)', fontsize=11, fontweight='bold')

# Legend
ax1.legend(loc='upper left', fontsize=10)

# Set viewing angle
ax1.view_init(elev=25, azim=45)

plt.tight_layout()

# ============================================================================
# Figure 2: Multi-Angle Views
# ============================================================================
print("Generating Figure 2: Multi-Angle 3D Views...")

fig2 = plt.figure(figsize=(16, 12))

angles = [
    (25, 45, 'Standard View'),
    (25, 135, 'Side View'),
    (60, 45, 'Top View'),
    (10, 225, 'Back View')
]

for idx, (elev, azim, view_name) in enumerate(angles, 1):
    ax = fig2.add_subplot(2, 2, idx, projection='3d')
    
    # Plot surface
    surf = ax.plot_surface(E_grid, F_grid, CD_grid, cmap='viridis', 
                          alpha=0.7, edgecolor='none', antialiased=True)
    
    # Plot experimental data points
    ax.scatter(E_data, F_data, CD_data, 
              c='red', marker='o', s=30, edgecolors='black', linewidth=0.5,
              alpha=0.8)
    
    # Labels
    ax.set_xlabel('Exposure\n(mJ/cm²)', fontsize=10, fontweight='bold')
    ax.set_ylabel('Focus\n(μm)', fontsize=10, fontweight='bold')
    ax.set_zlabel('CD (nm)', fontsize=10, fontweight='bold')
    ax.set_title(f'{view_name}', fontsize=11, fontweight='bold')
    
    # Set viewing angle
    ax.view_init(elev=elev, azim=azim)
    
    # Grid
    ax.grid(True, alpha=0.3)

fig2.suptitle('3D FEM Multi-View Analysis', fontsize=16, fontweight='bold', y=0.98)
plt.tight_layout()

# ============================================================================
# Summary
# ============================================================================
print("\n" + "="*70)
print("DEMO COMPLETE".center(70))
print("="*70)
print("\nGenerated Figures:")
print("  1. Single 3D Surface View")
print("  2. Multi-Angle 3D Views (4 perspectives)")
print("\nKey Features:")
print("  ✓ Smooth surface interpolation")
print("  ✓ Experimental data overlay (red points)")
print("  ✓ Color-coded CD values")
print("  ✓ Multiple viewing angles")
print("  ✓ Interactive rotation (use mouse in plot window)")
print("\nClose the plot windows to exit...")
print("="*70)

plt.show()
