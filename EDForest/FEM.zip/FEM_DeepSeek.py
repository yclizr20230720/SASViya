import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.optimize import curve_fit
from scipy import stats
from scipy.interpolate import griddata, interp1d
from sklearn.metrics import r2_score, mean_squared_error
import warnings
warnings.filterwarnings('ignore')
plt.style.use('seaborn-v0_8-darkgrid')

class PhysicsBasedFEMAnalyzer:
    """
    Physics-based Focus-Exposure Matrix (FEM) Data Analyzer
    Implementation of the algorithm from "Improved Model for Focus-Exposure Data Analysis"
    """
    
    def __init__(self):
        self.data = None
        self.focus_values = None
        self.exposure_values = None
        self.cd_values = None
        self.model_params = None
        self.model_type = None
        self.fitted_function = None
        self.residuals = None
        
    def load_data(self, focus, exposure, cd):
        """
        Load FEM data
        
        Args:
            focus: Array of focus values
            exposure: Array of exposure values
            cd: Array of critical dimension (CD) values
        """
        self.focus_values = np.array(focus)
        self.exposure_values = np.array(exposure)
        self.cd_values = np.array(cd)
        self.data = pd.DataFrame({
            'Focus': focus,
            'Exposure': exposure,
            'CD': cd
        })
        
        print(f"Data loaded: {len(focus)} data points")
        print(f"Focus range: {focus.min():.3f} to {focus.max():.3f}")
        print(f"Exposure range: {exposure.min():.3f} to {exposure.max():.3f}")
        print(f"CD range: {cd.min():.3f} to {cd.max():.3f}")
    
    def physics_based_model(self, X, c1, c2, c3, Es, alpha, beta, w):
        """
        Physics-based fitting model (Equations 12, 16)
        
        Args:
            X: Tuple of (focus, exposure)
            c1, c2, c3: Series coefficients
            Es: Size dose
            alpha, beta: Focus-related coefficients
            w: Nominal linewidth
        
        Returns:
            Predicted CD values
        """
        focus, exposure = X
        
        # Exposure-related part (Equation 12)
        exposure_term = 0
        dose_ratio = 1 - Es / exposure
        
        # Use up to 3 terms as suggested in paper
        if c1 != 0:
            exposure_term += c1 * dose_ratio
        if c2 != 0:
            exposure_term += c2 * dose_ratio**2
        if c3 != 0:
            exposure_term += c3 * dose_ratio**3
        
        # Focus-dependent correction (Extended Equation 16)
        # Includes both symmetric (even) and asymmetric (odd) terms
        focus_term = 1 + alpha * focus**2 + beta * focus
        
        # Calculate CD (Equation 12)
        cd = w * (1 + exposure_term * focus_term)
        
        return cd
    
    def simplified_polynomial_model(self, X, a00, a10, a01, a20, a11, a02, a30=0, a21=0, a12=0):
        """
        Simplified polynomial model based on Equation 1
        With reduced parameters as suggested in paper
        """
        focus, exposure = X
        cd = (a00 + a10*exposure + a01*focus + 
              a20*exposure**2 + a11*exposure*focus + a02*focus**2 +
              a30*exposure**3 + a21*exposure**2*focus + a12*exposure*focus**2)
        return cd
    
    def calculate_weights(self, center_weight=2.0):
        """
        Calculate weights for weighted least squares (Equation 4)
        Center points get higher weight
        """
        # Calculate distance to center
        focus_center = np.mean(self.focus_values)
        exposure_center = np.mean(self.exposure_values)
        
        focus_dist = np.abs(self.focus_values - focus_center)
        exposure_dist = np.abs(self.exposure_values - exposure_center)
        
        # Normalize distances
        focus_norm = focus_dist / np.max(focus_dist) if np.max(focus_dist) > 0 else 0
        exposure_norm = exposure_dist / np.max(exposure_dist) if np.max(exposure_dist) > 0 else 0
        
        # Combined distance (Euclidean)
        total_dist = np.sqrt(focus_norm**2 + exposure_norm**2)
        
        # Weight function: higher weight near center
        weights = 1.0 / (1.0 + total_dist * (center_weight - 1))
        
        return weights
    
    def fit_model(self, model_type='physics_based', remove_outliers=True, 
                  weighted_fit=True, center_weight=2.0):
        """
        Fit model to data
        
        Args:
            model_type: 'physics_based' or 'polynomial'
            remove_outliers: Whether to remove outliers
            weighted_fit: Whether to use weighted fitting
            center_weight: Weight multiplier for center points
        
        Returns:
            Fitted parameters
        """
        if self.data is None:
            raise ValueError("Please load data first")
        
        self.model_type = model_type
        
        # Prepare data
        X = (self.focus_values, self.exposure_values)
        y = self.cd_values
        
        # Calculate weights if needed
        if weighted_fit:
            weights = self.calculate_weights(center_weight)
        else:
            weights = np.ones_like(y)
        
        if model_type == 'physics_based':
            # Physics-based model fitting
            w_initial = np.median(self.cd_values)
            Es_initial = np.median(self.exposure_values)
            
            # Initial parameter guesses based on physical meaning
            initial_params = [
                0.15,    # c1 (related to 1/NILS)
                0.02,    # c2 (curvature term)
                0.001,   # c3 (higher order term)
                Es_initial,  # Es
                -0.5,    # alpha (focus quadratic term)
                0.1,     # beta (focus linear term for asymmetry)
                w_initial   # w (nominal linewidth)
            ]
            
            # Parameter bounds (physical constraints)
            bounds = (
                [-10, -1, -0.1, Es_initial*0.5, -5, -0.5, w_initial*0.5],
                [10, 1, 0.1, Es_initial*2, 5, 0.5, w_initial*1.5]
            )
            
            try:
                params, pcov = curve_fit(
                    self.physics_based_model, 
                    X, y, 
                    p0=initial_params,
                    bounds=bounds,
                    sigma=1/weights if weighted_fit else None,
                    maxfev=5000,
                    method='trf'
                )
                self.model_params = params
                self.fitted_function = lambda X: self.physics_based_model(X, *params)
                
                # Calculate fit statistics
                y_pred = self.physics_based_model(X, *params)
                self.residuals = y - y_pred
                
                r2 = r2_score(y, y_pred)
                rmse = np.sqrt(mean_squared_error(y, y_pred))
                chi2 = np.sum(weights**2 * (y - y_pred)**2)
                
                print("="*60)
                print("PHYSICS-BASED MODEL FITTING RESULTS")
                print("="*60)
                print(f"c1 (slope/1-NILS): {params[0]:.6f}")
                print(f"c2 (curvature): {params[1]:.6f}")
                print(f"c3 (higher order): {params[2]:.6f}")
                print(f"Es (size dose): {params[3]:.6f}")
                print(f"alpha (focus^2 coeff): {params[4]:.6f}")
                print(f"beta (focus coeff): {params[5]:.6f}")
                print(f"w (nominal linewidth): {params[6]:.6f}")
                print("-"*40)
                print(f"R² Score: {r2:.6f}")
                print(f"RMSE: {rmse:.6f}")
                print(f"Weighted χ²: {chi2:.6f}")
                print(f"Std of Residuals: {np.std(self.residuals):.6f}")
                
            except Exception as e:
                print(f"Fitting failed: {e}")
                print("Using initial parameters...")
                self.model_params = initial_params
                
        elif model_type == 'polynomial':
            # Polynomial model fitting
            def poly_func(X, *params):
                return self.simplified_polynomial_model(X, *params)
            
            initial_params = [np.mean(y)] + [0.1] * 6 + [0, 0, 0]
            
            try:
                params, pcov = curve_fit(poly_func, X, y, p0=initial_params[:9])
                self.model_params = params
                self.fitted_function = lambda X: poly_func(X, *params)
                
                y_pred = poly_func(X, *params)
                self.residuals = y - y_pred
                
                r2 = r2_score(y, y_pred)
                rmse = np.sqrt(mean_squared_error(y, y_pred))
                chi2 = np.sum((y - y_pred)**2)
                
                print("="*60)
                print("POLYNOMIAL MODEL FITTING RESULTS")
                print("="*60)
                param_names = ['a00', 'a10', 'a01', 'a20', 'a11', 'a02', 'a30', 'a21', 'a12']
                for i, (name, value) in enumerate(zip(param_names, params)):
                    print(f"{name}: {value:.6f}")
                print("-"*40)
                print(f"R² Score: {r2:.6f}")
                print(f"RMSE: {rmse:.6f}")
                print(f"χ²: {chi2:.6f}")
                print(f"Std of Residuals: {np.std(self.residuals):.6f}")
                
            except Exception as e:
                print(f"Polynomial fitting failed: {e}")
                return None
        
        # Remove outliers and refit if requested
        if remove_outliers and self.model_params is not None:
            self.remove_and_refit(threshold=2.0)
        
        return self.model_params
    
    def remove_and_refit(self, threshold=2.0):
        """
        Remove outliers based on residuals and refit
        """
        if self.residuals is None:
            return
        
        # Identify outliers (beyond threshold * std)
        std_residuals = np.std(self.residuals)
        outlier_mask = np.abs(self.residuals) > threshold * std_residuals
        
        if np.sum(outlier_mask) > 0:
            print(f"\nRemoving {np.sum(outlier_mask)} outliers...")
            
            # Keep clean data
            clean_mask = ~outlier_mask
            self.focus_values = self.focus_values[clean_mask]
            self.exposure_values = self.exposure_values[clean_mask]
            self.cd_values = self.cd_values[clean_mask]
            
            # Refit with clean data
            self.fit_model(
                model_type=self.model_type,
                remove_outliers=False,  # Avoid infinite recursion
                weighted_fit=True,
                center_weight=2.0
            )
    
    def predict(self, focus_range=None, exposure_range=None, grid_size=50):
        """
        Predict CD values using fitted model
        
        Args:
            focus_range: Tuple of (min_focus, max_focus)
            exposure_range: Tuple of (min_exposure, max_exposure)
            grid_size: Number of points in each dimension
        
        Returns:
            focus_mesh, exposure_mesh, cd_pred (gridded predictions)
        """
        if self.model_params is None:
            raise ValueError("Please fit model first")
        
        if focus_range is None:
            focus_range = (self.focus_values.min(), self.focus_values.max())
        if exposure_range is None:
            exposure_range = (self.exposure_values.min(), self.exposure_values.max())
        
        # Create prediction grid
        focus_grid = np.linspace(focus_range[0], focus_range[1], grid_size)
        exposure_grid = np.linspace(exposure_range[0], exposure_range[1], grid_size)
        focus_mesh, exposure_mesh = np.meshgrid(focus_grid, exposure_grid)
        
        # Predict CD values
        if self.fitted_function is not None:
            cd_pred = self.fitted_function((focus_mesh.flatten(), exposure_mesh.flatten()))
            cd_pred = cd_pred.reshape(focus_mesh.shape)
        else:
            # Fallback to interpolation
            cd_pred = griddata(
                np.column_stack((self.focus_values, self.exposure_values)),
                self.cd_values,
                (focus_mesh, exposure_mesh),
                method='cubic'
            )
        
        return focus_mesh, exposure_mesh, cd_pred
    
    def calculate_process_window(self, cd_target, cd_tolerance=0.1):
        """
        Calculate process window
        
        Args:
            cd_target: Target CD value
            cd_tolerance: CD tolerance (± fraction)
        
        Returns:
            Dictionary with process window metrics
        """
        if self.model_params is None:
            raise ValueError("Please fit model first")
        
        # Create fine grid for calculation
        focus_grid = np.linspace(self.focus_values.min(), self.focus_values.max(), 100)
        exposure_grid = np.linspace(self.exposure_values.min(), self.exposure_values.max(), 100)
        focus_mesh, exposure_mesh = np.meshgrid(focus_grid, exposure_grid)
        
        # Predict CD
        if self.fitted_function is not None:
            cd_pred = self.fitted_function((focus_mesh.flatten(), exposure_mesh.flatten()))
            cd_pred = cd_pred.reshape(focus_mesh.shape)
        else:
            cd_pred = griddata(
                np.column_stack((self.focus_values, self.exposure_values)),
                self.cd_values,
                (focus_mesh, exposure_mesh),
                method='cubic'
            )
        
        # Calculate in-spec region
        tolerance_abs = cd_target * cd_tolerance
        in_spec = np.abs(cd_pred - cd_target) <= tolerance_abs
        
        # Calculate process window metrics
        window_area_ratio = np.sum(in_spec) / in_spec.size
        
        if np.any(in_spec):
            valid_focus = focus_mesh[in_spec]
            valid_exposure = exposure_mesh[in_spec]
            valid_cd = cd_pred[in_spec]
            
            # Find best operating point (closest to target)
            cd_distance = np.abs(valid_cd - cd_target)
            best_idx = np.argmin(cd_distance)
            
            best_focus = valid_focus[best_idx]
            best_exposure = valid_exposure[best_idx]
            best_cd = valid_cd[best_idx]
            
            # Calculate process window boundaries
            focus_window = valid_focus.max() - valid_focus.min()
            exposure_window = valid_exposure.max() - valid_exposure.min()
            
            process_window = {
                'window_area_ratio': window_area_ratio,
                'window_area_percent': window_area_ratio * 100,
                'best_focus': best_focus,
                'best_exposure': best_exposure,
                'best_cd': best_cd,
                'focus_window_size': focus_window,
                'exposure_window_size': exposure_window,
                'in_spec_mask': in_spec,
                'focus_grid': focus_grid,
                'exposure_grid': exposure_grid,
                'cd_pred': cd_pred
            }
            
            return process_window
        else:
            print("Warning: No process window found within specifications")
            return None
    
    def plot_bossung_curves(self, num_exposures=5):
        """
        Plot Bossung curves (CD vs Focus at different exposures)
        
        Args:
            num_exposures: Number of exposure levels to plot
        
        Returns:
            Matplotlib figure
        """
        if self.data is None:
            raise ValueError("Please load data first")
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # Select exposure levels to plot
        exposure_levels = np.linspace(self.exposure_values.min(), 
                                    self.exposure_values.max(), 
                                    num_exposures)
        
        # Plot 1: Bossung curves with model predictions
        colors = plt.cm.viridis(np.linspace(0, 1, num_exposures))
        
        for i, exp in enumerate(exposure_levels):
            # Plot data points at this exposure level
            mask = np.abs(self.exposure_values - exp) < 1e-6
            if np.any(mask):
                ax1.scatter(self.focus_values[mask], self.cd_values[mask],
                          color=colors[i], alpha=0.6, s=50,
                          label=f'Exp={exp:.3f}' if i % 2 == 0 else None)
            
            # Plot model prediction if fitted
            if self.fitted_function is not None:
                focus_range = np.linspace(self.focus_values.min(), 
                                        self.focus_values.max(), 100)
                cd_pred = self.fitted_function((focus_range, np.full_like(focus_range, exp)))
                ax1.plot(focus_range, cd_pred, color=colors[i], 
                        linewidth=2, alpha=0.8)
        
        ax1.set_xlabel('Focus', fontsize=12)
        ax1.set_ylabel('Critical Dimension (CD)', fontsize=12)
        ax1.set_title('Bossung Curves: CD vs Focus', fontsize=14, fontweight='bold')
        ax1.grid(True, alpha=0.3)
        ax1.legend(loc='best')
        
        # Plot 2: CD vs Exposure at different focus levels
        focus_levels = np.linspace(self.focus_values.min(), 
                                 self.focus_values.max(), 
                                 min(5, len(np.unique(self.focus_values))))
        colors = plt.cm.plasma(np.linspace(0, 1, len(focus_levels)))
        
        for i, foc in enumerate(focus_levels):
            # Plot data points at this focus level
            mask = np.abs(self.focus_values - foc) < 1e-6
            if np.any(mask):
                ax2.scatter(self.exposure_values[mask], self.cd_values[mask],
                          color=colors[i], alpha=0.6, s=50,
                          label=f'Focus={foc:.3f}' if i % 2 == 0 else None)
            
            # Plot model prediction if fitted
            if self.fitted_function is not None:
                exposure_range = np.linspace(self.exposure_values.min(),
                                           self.exposure_values.max(), 100)
                cd_pred = self.fitted_function((np.full_like(exposure_range, foc), exposure_range))
                ax2.plot(exposure_range, cd_pred, color=colors[i],
                        linewidth=2, alpha=0.8)
        
        ax2.set_xlabel('Exposure', fontsize=12)
        ax2.set_ylabel('Critical Dimension (CD)', fontsize=12)
        ax2.set_title('CD vs Exposure at Different Focus Levels', fontsize=14, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        ax2.legend(loc='best')
        
        # Add model info
        model_info = f'Model: {self.model_type.upper()}' if self.model_type else 'No Model Fitted'
        fig.suptitle(f'FEM Data Analysis - {model_info}', fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        return fig
    
    def plot_3d_surface_and_contour(self):
        """
        Plot 3D surface and contour plots
        
        Returns:
            Matplotlib figure
        """
        if self.data is None:
            raise ValueError("Please load data first")
        
        # Generate prediction grid
        focus_mesh, exposure_mesh, cd_pred = self.predict(grid_size=30)
        
        fig = plt.figure(figsize=(16, 12))
        
        # 1. 3D Surface Plot
        ax1 = fig.add_subplot(221, projection='3d')
        surf = ax1.plot_surface(focus_mesh, exposure_mesh, cd_pred,
                              cmap='viridis', alpha=0.8, antialiased=True)
        ax1.scatter(self.focus_values, self.exposure_values, self.cd_values,
                  color='red', s=30, alpha=0.7, label='Data Points')
        ax1.set_xlabel('Focus', fontsize=10)
        ax1.set_ylabel('Exposure', fontsize=10)
        ax1.set_zlabel('CD', fontsize=10)
        ax1.set_title('3D Surface: CD vs Focus & Exposure', fontsize=12, fontweight='bold')
        fig.colorbar(surf, ax=ax1, shrink=0.5, label='CD')
        
        # 2. Contour Plot
        ax2 = fig.add_subplot(222)
        contour = ax2.contourf(focus_mesh, exposure_mesh, cd_pred, 20, cmap='viridis')
        ax2.scatter(self.focus_values, self.exposure_values,
                  color='white', s=20, alpha=0.7, edgecolors='black')
        ax2.set_xlabel('Focus', fontsize=10)
        ax2.set_ylabel('Exposure', fontsize=10)
        ax2.set_title('Contour Plot of CD', fontsize=12, fontweight='bold')
        fig.colorbar(contour, ax=ax2, shrink=0.8, label='CD')
        
        # 3. Residual Analysis
        if self.residuals is not None:
            ax3 = fig.add_subplot(223)
            if self.fitted_function is not None:
                y_pred = self.fitted_function((self.focus_values, self.exposure_values))
                ax3.scatter(y_pred, self.residuals, alpha=0.6)
                ax3.axhline(y=0, color='r', linestyle='--', alpha=0.5)
                ax3.set_xlabel('Predicted CD', fontsize=10)
                ax3.set_ylabel('Residuals (Actual - Predicted)', fontsize=10)
                ax3.set_title('Residual Analysis', fontsize=12, fontweight='bold')
                ax3.grid(True, alpha=0.3)
                
                # Add residual statistics
                res_mean = np.mean(self.residuals)
                res_std = np.std(self.residuals)
                ax3.text(0.05, 0.95, f'Mean: {res_mean:.4f}\nStd: {res_std:.4f}',
                        transform=ax3.transAxes, verticalalignment='top',
                        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        # 4. Model Comparison (if both models fitted)
        ax4 = fig.add_subplot(224)
        exposure_fixed = np.mean(self.exposure_values)
        focus_range = np.linspace(self.focus_values.min(), self.focus_values.max(), 100)
        
        ax4.scatter(self.focus_values, self.cd_values, color='gray',
                   alpha=0.5, s=20, label='Data')
        
        if self.fitted_function is not None:
            cd_model = self.fitted_function((focus_range, np.full_like(focus_range, exposure_fixed)))
            ax4.plot(focus_range, cd_model, 'b-', linewidth=2,
                    label=f'{self.model_type.capitalize()} Model')
        
        ax4.set_xlabel('Focus', fontsize=10)
        ax4.set_ylabel('CD', fontsize=10)
        ax4.set_title(f'Model Fit at Exposure={exposure_fixed:.3f}', fontsize=12, fontweight='bold')
        ax4.legend(loc='best')
        ax4.grid(True, alpha=0.3)
        
        plt.suptitle('Comprehensive FEM Data Analysis', fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        return fig
    
    def plot_process_window_analysis(self, cd_target, cd_tolerance=0.1):
        """
        Plot process window analysis
        
        Args:
            cd_target: Target CD value
            cd_tolerance: CD tolerance (± fraction)
        
        Returns:
            Matplotlib figure and process window dictionary
        """
        process_window = self.calculate_process_window(cd_target, cd_tolerance)
        
        if process_window is None:
            print("Cannot calculate process window")
            return None, None
        
        fig = plt.figure(figsize=(16, 12))
        
        # 1. Process Window Contour
        ax1 = fig.add_subplot(231)
        contour = ax1.contourf(process_window['focus_grid'],
                             process_window['exposure_grid'],
                             process_window['cd_pred'],
                             20, cmap='viridis')
        
        # Highlight process window
        if process_window['in_spec_mask'] is not None:
            from scipy.ndimage import binary_dilation
            boundary = binary_dilation(process_window['in_spec_mask']) & ~process_window['in_spec_mask']
            ax1.contour(process_window['focus_grid'],
                      process_window['exposure_grid'],
                      boundary, levels=[0.5],
                      colors='red', linewidths=2, linestyles='--')
        
        ax1.scatter(process_window['best_focus'], process_window['best_exposure'],
                  color='yellow', s=200, marker='*', edgecolors='black',
                  label=f'Best Point\nF={process_window["best_focus"]:.3f}\nE={process_window["best_exposure"]:.3f}')
        
        ax1.scatter(self.focus_values, self.exposure_values,
                  color='white', s=30, alpha=0.7, edgecolors='black', label='Data Points')
        
        ax1.set_xlabel('Focus', fontsize=10)
        ax1.set_ylabel('Exposure', fontsize=10)
        ax1.set_title(f'Process Window (Target CD={cd_target:.3f}±{cd_tolerance*100:.1f}%)',
                     fontsize=12, fontweight='bold')
        ax1.legend(loc='best')
        fig.colorbar(contour, ax=ax1, shrink=0.8, label='CD')
        
        # 2. CD vs Focus at Best Exposure
        ax2 = fig.add_subplot(232)
        best_exp = process_window['best_exposure']
        focus_range = np.linspace(self.focus_values.min(), self.focus_values.max(), 200)
        
        if self.fitted_function is not None:
            cd_at_best_exp = self.fitted_function((focus_range, np.full_like(focus_range, best_exp)))
            ax2.plot(focus_range, cd_at_best_exp, 'b-', linewidth=2, label='Model Prediction')
        
        ax2.axhline(y=cd_target, color='g', linestyle='--', alpha=0.7,
                   label=f'Target CD={cd_target:.3f}')
        ax2.axhline(y=cd_target*(1+cd_tolerance), color='r', linestyle=':', alpha=0.5)
        ax2.axhline(y=cd_target*(1-cd_tolerance), color='r', linestyle=':', alpha=0.5)
        ax2.fill_between(focus_range, cd_target*(1-cd_tolerance),
                        cd_target*(1+cd_tolerance), color='red', alpha=0.1)
        
        ax2.axvline(x=process_window['best_focus'], color='orange',
                   linestyle='--', alpha=0.7,
                   label=f'Best Focus={process_window["best_focus"]:.3f}')
        
        ax2.set_xlabel('Focus', fontsize=10)
        ax2.set_ylabel('CD', fontsize=10)
        ax2.set_title(f'CD vs Focus at Best Exposure (E={best_exp:.3f})',
                     fontsize=12, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        ax2.legend(loc='best')
        
        # 3. CD vs Exposure at Best Focus
        ax3 = fig.add_subplot(233)
        best_focus = process_window['best_focus']
        exposure_range = np.linspace(self.exposure_values.min(), self.exposure_values.max(), 200)
        
        if self.fitted_function is not None:
            cd_at_best_focus = self.fitted_function((np.full_like(exposure_range, best_focus), exposure_range))
            ax3.plot(exposure_range, cd_at_best_focus, 'b-', linewidth=2, label='Model Prediction')
        
        ax3.axhline(y=cd_target, color='g', linestyle='--', alpha=0.7)
        ax3.axhline(y=cd_target*(1+cd_tolerance), color='r', linestyle=':', alpha=0.5)
        ax3.axhline(y=cd_target*(1-cd_tolerance), color='r', linestyle=':', alpha=0.5)
        ax3.fill_between(exposure_range, cd_target*(1-cd_tolerance),
                        cd_target*(1+cd_tolerance), color='red', alpha=0.1)
        
        ax3.axvline(x=process_window['best_exposure'], color='orange',
                   linestyle='--', alpha=0.7,
                   label=f'Best Exposure={process_window["best_exposure"]:.3f}')
        
        ax3.set_xlabel('Exposure', fontsize=10)
        ax3.set_ylabel('CD', fontsize=10)
        ax3.set_title(f'CD vs Exposure at Best Focus (F={best_focus:.3f})',
                     fontsize=12, fontweight='bold')
        ax3.grid(True, alpha=0.3)
        ax3.legend(loc='best')
        
        # 4. Process Window Metrics
        ax4 = fig.add_subplot(234)
        ax4.axis('off')
        
        metrics_text = (
            f'PROCESS WINDOW METRICS\n'
            f'{"="*30}\n'
            f'Window Area: {process_window["window_area_percent"]:.1f}%\n'
            f'Focus Window Size: {process_window["focus_window_size"]:.3f}\n'
            f'Exposure Window Size: {process_window["exposure_window_size"]:.3f}\n'
            f'\nBEST OPERATING POINT\n'
            f'{"="*30}\n'
            f'Best Focus: {process_window["best_focus"]:.4f}\n'
            f'Best Exposure: {process_window["best_exposure"]:.4f}\n'
            f'Achieved CD: {process_window["best_cd"]:.4f}\n'
            f'CD Error: {process_window["best_cd"]-cd_target:.4f}\n'
            f'Error (%): {100*(process_window["best_cd"]-cd_target)/cd_target:.2f}%'
        )
        
        ax4.text(0.1, 0.5, metrics_text, fontsize=11,
                verticalalignment='center',
                bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.5))
        
        # 5. Histogram of CD values in window
        ax5 = fig.add_subplot(235)
        if process_window['in_spec_mask'] is not None:
            cd_in_window = process_window['cd_pred'][process_window['in_spec_mask']]
            ax5.hist(cd_in_window, bins=20, alpha=0.7, color='skyblue', edgecolor='black')
            ax5.axvline(x=cd_target, color='r', linestyle='--', linewidth=2,
                       label=f'Target: {cd_target:.3f}')
            ax5.axvline(x=np.mean(cd_in_window), color='g', linestyle='--', linewidth=2,
                       label=f'Mean: {np.mean(cd_in_window):.3f}')
            ax5.set_xlabel('CD in Process Window', fontsize=10)
            ax5.set_ylabel('Frequency', fontsize=10)
            ax5.set_title('CD Distribution in Process Window', fontsize=12, fontweight='bold')
            ax5.legend(loc='best')
            ax5.grid(True, alpha=0.3)
        
        # 6. Model Parameters
        ax6 = fig.add_subplot(236)
        ax6.axis('off')
        
        if self.model_params is not None and self.model_type == 'physics_based':
            params_text = (
                f'PHYSICS-BASED MODEL PARAMETERS\n'
                f'{"="*30}\n'
                f'c1 (slope/NILS): {self.model_params[0]:.4f}\n'
                f'c2 (curvature): {self.model_params[1]:.4f}\n'
                f'c3 (higher order): {self.model_params[2]:.4f}\n'
                f'Es (size dose): {self.model_params[3]:.4f}\n'
                f'α (focus² term): {self.model_params[4]:.4f}\n'
                f'β (focus term): {self.model_params[5]:.4f}\n'
                f'w (nominal CD): {self.model_params[6]:.4f}'
            )
        else:
            params_text = f'Model Type: {self.model_type}\nNo parameters to display'
        
        ax6.text(0.1, 0.5, params_text, fontsize=10,
                verticalalignment='center',
                bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.5))
        
        plt.suptitle(f'Process Window Analysis - Model: {self.model_type.upper()}',
                    fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        return fig, process_window


# ============================================
# Data Generation and Example Usage
# ============================================

def generate_mock_fem_data(n_points=150, noise_level=0.03, add_outliers=True):
    """
    Generate realistic mock FEM data based on physics-based model
    
    Args:
        n_points: Number of data points
        noise_level: Measurement noise level
        add_outliers: Whether to add outlier points
    
    Returns:
        focus, exposure, cd (with noise), cd_true (without noise)
    """
    np.random.seed(42)
    
    # Generate systematic grid of focus and exposure values
    # Follows typical FEM experimental design
    n_focus = int(np.sqrt(n_points))
    n_exposure = int(np.sqrt(n_points))
    
    focus_grid = np.linspace(-0.4, 0.4, n_focus)
    exposure_grid = np.linspace(0.7, 1.3, n_exposure)
    focus, exposure = np.meshgrid(focus_grid, exposure_grid)
    focus = focus.flatten()
    exposure = exposure.flatten()
    
    # Trim to desired number of points
    if len(focus) > n_points:
        indices = np.random.choice(len(focus), n_points, replace=False)
        focus = focus[indices]
        exposure = exposure[indices]
    
    # True physical parameters (similar to paper examples)
    w_nominal = 100.0  # nm, nominal linewidth
    Es = 1.0  # size dose
    c1 = 0.18  # related to exposure latitude (1/NILS)
    c2 = 0.025  # curvature term
    c3 = 0.001  # higher order term (small)
    alpha = -0.8  # defocus quadratic coefficient
    beta = 0.15   # defocus linear coefficient (asymmetry)
    
    # Calculate true CD values (noiseless)
    dose_ratio = 1 - Es / exposure
    exposure_term = c1 * dose_ratio + c2 * dose_ratio**2 + c3 * dose_ratio**3
    focus_term = 1 + alpha * focus**2 + beta * focus
    cd_true = w_nominal * (1 + exposure_term * focus