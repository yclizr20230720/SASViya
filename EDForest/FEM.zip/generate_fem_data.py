"""
FEM Data Generator
Creates realistic Focus-Exposure Matrix CSV data for lithography process analysis
"""

import numpy as np
import pandas as pd

def generate_fem_csv(
    filename='fem_experimental_data.csv',
    n_focus=7,
    n_exposure=9,
    focus_range=(-0.3, 0.3),  # μm
    exposure_range=(18.0, 26.0),  # mJ/cm²
    nominal_cd=130.0,  # nm
    dose_to_size=22.0,  # mJ/cm²
    best_focus=0.0,  # μm
    noise_level=2.0,  # nm RMS
    seed=42
):
    """
    Generate realistic FEM data and save to CSV
    
    Parameters:
        filename: Output CSV filename
        n_focus: Number of focus points
        n_exposure: Number of exposure doses
        focus_range: (min, max) focus in μm
        exposure_range: (min, max) exposure in mJ/cm²
        nominal_cd: Target CD in nm
        dose_to_size: Dose to size parameter in mJ/cm²
        best_focus: Best focus position in μm
        noise_level: Measurement noise RMS in nm
        seed: Random seed for reproducibility
    """
    
    np.random.seed(seed)
    
    # Create focus and exposure arrays
    focus_values = np.linspace(focus_range[0], focus_range[1], n_focus)
    exposure_values = np.linspace(exposure_range[0], exposure_range[1], n_exposure)
    
    # Create all combinations (FEM matrix)
    F, E = np.meshgrid(focus_values, exposure_values)
    F = F.ravel()
    E = E.ravel()
    
    # Physics-based CD model
    # Based on simplified lithography physics
    
    Es = dose_to_size
    F_best = best_focus
    w = nominal_cd
    
    # Defocus distance
    delta = F - F_best
    
    # NILS decay with defocus (simplified)
    p = 260.0  # Pitch (nm)
    wavelength = 248.0  # Wavelength (nm) - typical for DUV
    NILS_factor = np.cos(np.pi * delta**2 / (p * wavelength / 1000))
    
    # Calculate CD using simplified Bossung model
    # CD/w = sqrt(1 - 2(1 - E/Es))
    E_ratio = 1 - E / Es
    CD = w * np.sqrt(np.maximum(0, 1 - 2 * E_ratio * NILS_factor))
    
    # Add focus-dependent correction terms (Bossung curve shape)
    CD += 50 * (delta / 1.0)**2  # Quadratic term
    CD += 10 * (delta / 1.0)**4  # Quartic term
    
    # Add measurement noise
    if noise_level > 0:
        CD += np.random.normal(0, noise_level, size=len(CD))
    
    # Create DataFrame
    df = pd.DataFrame({
        'Focus': F,
        'Exposure': E,
        'CD': CD,
        'Weight': np.ones_like(CD)
    })
    
    # Save to CSV
    df.to_csv(filename, index=False)
    
    # Print summary
    print("="*70)
    print("FEM DATA GENERATION COMPLETE".center(70))
    print("="*70)
    print(f"\nFile saved: {filename}")
    print(f"\nData Parameters:")
    print(f"  Focus points: {n_focus}")
    print(f"  Exposure points: {n_exposure}")
    print(f"  Total measurements: {len(df)}")
    print(f"  Focus range: {focus_range[0]:.3f} to {focus_range[1]:.3f} μm")
    print(f"  Exposure range: {exposure_range[0]:.1f} to {exposure_range[1]:.1f} mJ/cm²")
    print(f"  CD range: {CD.min():.1f} to {CD.max():.1f} nm")
    print(f"  Noise level: {noise_level:.1f} nm RMS")
    print(f"\nPhysics Parameters:")
    print(f"  Nominal CD: {nominal_cd:.1f} nm")
    print(f"  Dose to Size: {dose_to_size:.1f} mJ/cm²")
    print(f"  Best Focus: {best_focus:.3f} μm")
    print("\n" + "="*70)
    
    # Show sample data
    print("\nSample Data (first 10 rows):")
    print(df.head(10).to_string(index=False))
    print("\n" + "="*70)
    
    return df


if __name__ == "__main__":
    # Example 1: Default parameters (DUV lithography, 130nm node)
    print("\nGenerating FEM data with default parameters...")
    df = generate_fem_csv(
        filename='fem_experimental_data.csv',
        n_focus=7,
        n_exposure=9,
        focus_range=(-0.3, 0.3),
        exposure_range=(18.0, 26.0),
        nominal_cd=130.0,
        dose_to_size=22.0,
        best_focus=0.0,
        noise_level=2.0,
        seed=42
    )
    
    # Example 2: Generate additional dataset with different parameters
    # Uncomment to create alternative datasets
    
    # print("\n\nGenerating alternative FEM data (90nm node)...")
    # df2 = generate_fem_csv(
    #     filename='fem_data_90nm.csv',
    #     n_focus=9,
    #     n_exposure=11,
    #     focus_range=(-0.4, 0.4),
    #     exposure_range=(25.0, 35.0),
    #     nominal_cd=90.0,
    #     dose_to_size=30.0,
    #     best_focus=-0.05,
    #     noise_level=1.5,
    #     seed=123
    # )
    
    print("\n✓ Ready to use with FEM.py!")
    print("  Run: python FEM.py")
