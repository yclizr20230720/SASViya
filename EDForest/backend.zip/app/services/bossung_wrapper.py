"""
Wrapper for Bossung Plotter to handle path issues and provide clean interface
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from datetime import datetime


class BossungPlotterWrapper:
    """
    Wrapper class for Bossung curve analysis that handles all path issues
    """
    
    def __init__(self, data_file=None, dataframe=None):
        """
        Initialize the Bossung plotter.
        
        Parameters:
        -----------
        data_file : str, optional
            Path to CSV file containing dose-focus-CD data
        dataframe : pd.DataFrame, optional
            DataFrame containing the data directly
        """
        if data_file:
            self.data = pd.read_csv(data_file)
        elif dataframe is not None:
            self.data = dataframe
        else:
            raise ValueError("Either data_file or dataframe must be provided")
        
        # Validate required columns
        required_cols = ['Dose', 'Defocus', 'CD']
        if not all(col in self.data.columns for col in required_cols):
            raise ValueError(f"Data must contain columns: {required_cols}")
        
        self.target_cd = None
        self.cd_tolerance = None
        
    def set_target_specs(self, target_cd, tolerance_percent=10):
        """
        Set target CD and tolerance specifications.
        
        Parameters:
        -----------
        target_cd : float
            Target critical dimension (nm)
        tolerance_percent : float
            Tolerance as percentage of target CD (default: 10%)
        """
        self.target_cd = target_cd
        self.cd_tolerance = target_cd * tolerance_percent / 100
        
    def plot_bossung_curves(self, figsize=(12, 8), style='professional'):
        """
        Generate professional Bossung curves.
        
        Parameters:
        -----------
        figsize : tuple
            Figure size (width, height)
        style : str
            Plot style: 'professional', 'colorful', or 'minimal'
        """
        if style == 'professional':
            plt.style.use('seaborn-v0_8-darkgrid')
            colors = plt.cm.viridis(np.linspace(0.2, 0.9, len(self.data['Dose'].unique())))
        elif style == 'colorful':
            plt.style.use('seaborn-v0_8-bright')
            colors = plt.cm.rainbow(np.linspace(0, 1, len(self.data['Dose'].unique())))
        else:
            plt.style.use('seaborn-v0_8-whitegrid')
            colors = plt.cm.coolwarm(np.linspace(0.2, 0.8, len(self.data['Dose'].unique())))
        
        fig, ax = plt.subplots(figsize=figsize)
        
        doses = sorted(self.data['Dose'].unique())
        
        for idx, dose in enumerate(doses):
            dose_data = self.data[self.data['Dose'] == dose].sort_values('Defocus')
            ax.plot(dose_data['Defocus'], dose_data['CD'], 
                   marker='o', markersize=6, linewidth=2.5,
                   color=colors[idx], label=f'{dose:.1f} mJ/cm²',
                   alpha=0.85)
        
        if self.target_cd is not None:
            ax.axhline(y=self.target_cd, color='red', linestyle='--', 
                      linewidth=2, label=f'Target CD: {self.target_cd:.1f} nm', alpha=0.7)
            
            if self.cd_tolerance is not None:
                ax.axhspan(self.target_cd - self.cd_tolerance, 
                          self.target_cd + self.cd_tolerance,
                          alpha=0.15, color='green', 
                          label=f'Tolerance: ±{self.cd_tolerance:.1f} nm')
        
        ax.set_xlabel('Defocus (μm)', fontsize=14, fontweight='bold')
        ax.set_ylabel('Critical Dimension (nm)', fontsize=14, fontweight='bold')
        ax.set_title('Bossung Curves - Process Window Analysis', 
                    fontsize=16, fontweight='bold', pad=20)
        ax.legend(loc='best', fontsize=10, framealpha=0.9)
        ax.grid(True, alpha=0.3, linestyle='--')
        ax.tick_params(labelsize=11)
        
        plt.tight_layout()
        return fig, ax
    
    def plot_process_window(self, figsize=(12, 8)):
        """
        Generate 2D process window contour plot.
        """
        fig, ax = plt.subplots(figsize=figsize)
        
        pivot_data = self.data.pivot_table(
            values='CD', 
            index='Defocus', 
            columns='Dose'
        )
        
        doses = pivot_data.columns.values
        defocus = pivot_data.index.values
        CD_grid = pivot_data.values
        
        contour = ax.contourf(doses, defocus, CD_grid, levels=15, cmap='RdYlGn_r', alpha=0.8)
        contour_lines = ax.contour(doses, defocus, CD_grid, levels=10, colors='black', 
                                   linewidths=0.5, alpha=0.4)
        ax.clabel(contour_lines, inline=True, fontsize=8, fmt='%.1f nm')
        
        cbar = plt.colorbar(contour, ax=ax, label='Critical Dimension (nm)')
        cbar.ax.tick_params(labelsize=10)
        
        if self.target_cd is not None:
            target_contour = ax.contour(doses, defocus, CD_grid, 
                                       levels=[self.target_cd], 
                                       colors='red', linewidths=3, linestyles='--')
            ax.clabel(target_contour, inline=True, fontsize=10, 
                     fmt=f'Target: {self.target_cd:.1f} nm')
        
        ax.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=14, fontweight='bold')
        ax.set_ylabel('Defocus (μm)', fontsize=14, fontweight='bold')
        ax.set_title('Process Window - Dose-Focus Matrix', 
                    fontsize=16, fontweight='bold', pad=20)
        ax.grid(True, alpha=0.2, linestyle='--')
        ax.tick_params(labelsize=11)
        
        plt.tight_layout()
        return fig, ax
    
    def plot_comprehensive_analysis(self, figsize=(18, 10)):
        """
        Generate comprehensive analysis with multiple subplots.
        """
        fig = plt.figure(figsize=figsize)
        gs = fig.add_gridspec(2, 2, hspace=0.3, wspace=0.3)
        
        # Bossung Curves
        ax1 = fig.add_subplot(gs[0, :])
        doses = sorted(self.data['Dose'].unique())
        colors = plt.cm.viridis(np.linspace(0.2, 0.9, len(doses)))
        
        for idx, dose in enumerate(doses):
            dose_data = self.data[self.data['Dose'] == dose].sort_values('Defocus')
            ax1.plot(dose_data['Defocus'], dose_data['CD'], 
                    marker='o', markersize=5, linewidth=2,
                    color=colors[idx], label=f'{dose:.1f} mJ/cm²', alpha=0.85)
        
        if self.target_cd is not None:
            ax1.axhline(y=self.target_cd, color='red', linestyle='--', 
                       linewidth=2, label=f'Target: {self.target_cd:.1f} nm')
            if self.cd_tolerance is not None:
                ax1.axhspan(self.target_cd - self.cd_tolerance, 
                           self.target_cd + self.cd_tolerance,
                           alpha=0.15, color='green')
        
        ax1.set_xlabel('Defocus (μm)', fontsize=12, fontweight='bold')
        ax1.set_ylabel('CD (nm)', fontsize=12, fontweight='bold')
        ax1.set_title('Bossung Curves', fontsize=14, fontweight='bold')
        ax1.legend(loc='best', fontsize=9, ncol=2)
        ax1.grid(True, alpha=0.3)
        
        # Process Window Contour
        ax2 = fig.add_subplot(gs[1, 0])
        pivot_data = self.data.pivot_table(values='CD', index='Defocus', columns='Dose')
        contour = ax2.contourf(pivot_data.columns, pivot_data.index, pivot_data.values, 
                              levels=15, cmap='RdYlGn_r', alpha=0.8)
        plt.colorbar(contour, ax=ax2, label='CD (nm)')
        ax2.set_xlabel('Dose (mJ/cm²)', fontsize=12, fontweight='bold')
        ax2.set_ylabel('Defocus (μm)', fontsize=12, fontweight='bold')
        ax2.set_title('Process Window', fontsize=14, fontweight='bold')
        ax2.grid(True, alpha=0.2)
        
        # CD Distribution
        ax3 = fig.add_subplot(gs[1, 1])
        ax3.hist(self.data['CD'], bins=20, color='steelblue', alpha=0.7, edgecolor='black')
        if self.target_cd is not None:
            ax3.axvline(x=self.target_cd, color='red', linestyle='--', linewidth=2)
        ax3.set_xlabel('CD (nm)', fontsize=12, fontweight='bold')
        ax3.set_ylabel('Frequency', fontsize=12, fontweight='bold')
        ax3.set_title('CD Distribution', fontsize=14, fontweight='bold')
        ax3.grid(True, alpha=0.3, axis='y')
        
        fig.suptitle('Comprehensive Lithography Process Window Analysis', 
                    fontsize=16, fontweight='bold', y=0.995)
        
        return fig
    
    def calculate_process_window_metrics(self):
        """
        Calculate process window metrics: DOF and EL.
        """
        if self.target_cd is None or self.cd_tolerance is None:
            raise ValueError("Target CD and tolerance must be set first")
        
        cd_min = self.target_cd - self.cd_tolerance
        cd_max = self.target_cd + self.cd_tolerance
        
        in_spec = self.data[
            (self.data['CD'] >= cd_min) & 
            (self.data['CD'] <= cd_max)
        ]
        
        if len(in_spec) == 0:
            return {
                'DOF': 0,
                'EL': 0,
                'optimal_dose': None,
                'optimal_focus': None,
                'message': 'No data points within specification'
            }
        
        dof = in_spec['Defocus'].max() - in_spec['Defocus'].min()
        el = in_spec['Dose'].max() - in_spec['Dose'].min()
        optimal_dose = (in_spec['Dose'].max() + in_spec['Dose'].min()) / 2
        optimal_focus = (in_spec['Defocus'].max() + in_spec['Defocus'].min()) / 2
        
        return {
            'DOF': dof,
            'EL': el,
            'optimal_dose': optimal_dose,
            'optimal_focus': optimal_focus,
            'in_spec_points': len(in_spec),
            'total_points': len(self.data)
        }


def generate_mock_data_wrapper(output_file, doses=9, defocus_points=17, target_cd=45.0):
    """
    Generate realistic mock lithography data.
    """
    dose_range = np.linspace(18, 26, doses)
    defocus_range = np.linspace(-0.4, 0.4, defocus_points)
    
    data_records = []
    
    for dose in dose_range:
        dose_offset = (dose - 22) * 0.8
        
        for defocus in defocus_range:
            cd_base = target_cd + dose_offset
            defocus_effect = 15 * (defocus ** 2)
            asymmetry = 2 * defocus if defocus > 0 else 1.5 * defocus
            cd = cd_base + defocus_effect + asymmetry + np.random.normal(0, 0.3)
            
            data_records.append({
                'Dose': dose,
                'Defocus': defocus,
                'CD': cd,
                'Wafer_ID': 'W001',
                'Field': 'Center'
            })
    
    df = pd.DataFrame(data_records)
    df.to_csv(output_file, index=False)
    
    return df
