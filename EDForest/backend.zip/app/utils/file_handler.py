"""
File handling utilities
"""
import os
from werkzeug.utils import secure_filename
from datetime import datetime


def allowed_file(filename, allowed_extensions):
    """
    Check if file extension is allowed
    
    Parameters:
    -----------
    filename : str
        Name of file to check
    allowed_extensions : set
        Set of allowed extensions
    
    Returns:
    --------
    bool : True if allowed, False otherwise
    """
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in allowed_extensions


def save_upload_file(file, filename, upload_folder):
    """
    Save uploaded file with timestamp
    
    Parameters:
    -----------
    file : FileStorage
        Uploaded file object
    filename : str
        Original filename
    upload_folder : str
        Folder to save file
    
    Returns:
    --------
    str : Path to saved file
    """
    # Add timestamp to filename
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    name, ext = os.path.splitext(filename)
    new_filename = f"{name}_{timestamp}{ext}"
    
    filepath = os.path.join(upload_folder, secure_filename(new_filename))
    file.save(filepath)
    
    return filepath


def cleanup_old_files(folder, max_age_hours=24):
    """
    Clean up old files from folder
    
    Parameters:
    -----------
    folder : str
        Folder to clean
    max_age_hours : int
        Maximum age of files in hours
    """
    import time
    
    now = time.time()
    max_age_seconds = max_age_hours * 3600
    
    for filename in os.listdir(folder):
        filepath = os.path.join(folder, filename)
        if os.path.isfile(filepath):
            file_age = now - os.path.getmtime(filepath)
            if file_age > max_age_seconds:
                try:
                    os.remove(filepath)
                except Exception:
                    pass
