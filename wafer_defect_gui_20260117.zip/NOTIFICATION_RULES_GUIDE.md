# Notification Rules & Configuration Guide

## Overview
Comprehensive guide for configuring email, SMS, and Microsoft Teams notifications when alerts occur in the Wafer Defect Analysis System.

## Accessing Notification Configuration

### Location
Navigate to: **Settings → Notification Rules** tab

**Path**: Settings page (sidebar menu) → Click "Notification Rules" tab (7th tab)

## Configuration Components

### 1. Notification Channels

Channels define HOW notifications are sent (Email, SMS, Teams).

#### Email Channel Configuration

**Purpose**: Send alert notifications via email using SMTP server

**Required Information**:
- **Channel Name**: Descriptive name (e.g., "Company Email Server")
- **SMTP Server**: Mail server address (e.g., smtp.company.com)
- **Port**: SMTP port number (typically 587 for TLS, 465 for SSL, 25 for non-encrypted)
- **Username**: SMTP authentication username
- **Password**: SMTP authentication password
- **From Address**: Email address that appears as sender

**Example Configuration**:
```
Channel Name: Company Email Server
SMTP Server: smtp.company.com
Port: 587
Username: wafer-alerts@company.com
Password: ••••••••
From Address: wafer-alerts@company.com
```

**Common SMTP Servers**:
- **Gmail**: smtp.gmail.com:587 (requires app password)
- **Outlook/Office 365**: smtp.office365.com:587
- **SendGrid**: smtp.sendgrid.net:587
- **AWS SES**: email-smtp.us-east-1.amazonaws.com:587

#### SMS Channel Configuration

**Purpose**: Send alert notifications via SMS/text message

**Required Information**:
- **Channel Name**: Descriptive name (e.g., "Twilio SMS")
- **SMS Provider**: Select from dropdown
  - Twilio
  - AWS SNS
  - Nexmo/Vonage
  - MessageBird
- **API Key**: Provider-specific API key or access token
- **Phone Numbers**: List of phone numbers to send to

**Example Configuration**:
```
Channel Name: Twilio SMS
Provider: Twilio
API Key: ••••••••••••••••••••
Phone Numbers: +1-555-0100, +1-555-0101
```

**Provider Setup**:

**Twilio**:
1. Sign up at twilio.com
2. Get Account SID and Auth Token
3. Purchase a phone number
4. Use Auth Token as API Key

**AWS SNS**:
1. Create AWS account
2. Enable SNS service
3. Create access key in IAM
4. Use access key as API Key

#### Microsoft Teams Channel Configuration

**Purpose**: Send alert notifications to Teams channels

**Required Information**:
- **Channel Name**: Descriptive name (e.g., "Engineering Team Channel")
- **Webhook URL**: Teams incoming webhook URL
- **Channel ID**: Teams channel identifier

**Example Configuration**:
```
Channel Name: Engineering Team Channel
Webhook URL: https://outlook.office.com/webhook/abc123...
Channel ID: engineering-alerts
```

**Setting up Teams Webhook**:
1. Open Microsoft Teams
2. Navigate to desired channel
3. Click "..." → Connectors
4. Search for "Incoming Webhook"
5. Click "Configure"
6. Name the webhook and upload image (optional)
7. Copy the webhook URL
8. Paste URL into configuration

### 2. Alert Rules

Rules define WHEN and TO WHOM notifications are sent.

#### Rule Components

**Rule Name**: Descriptive name for the rule

**Alert Type**: Which type of alerts trigger this rule
- All Types
- Defect Rate - Defect rate threshold exceeded
- Confidence - Model confidence issues
- Equipment - Equipment performance problems
- Pattern - Unusual pattern detection
- System - System updates and maintenance

**Severity**: Which severity levels trigger this rule
- All Severities
- Critical - Immediate attention required
- High - Important issues
- Medium - Moderate priority
- Low - Informational

**Channels**: Which notification channels to use
- Select one or more configured channels
- Can combine Email + SMS + Teams

**Recipients**: Who receives the notifications
- **Email Recipients**: List of email addresses
- **SMS Recipients**: List of phone numbers (E.164 format: +1-555-0100)
- **Teams Channels**: List of Teams channel IDs

**Conditions** (Optional): Additional filtering
- **Defect Rate Threshold**: Only alert if defect rate exceeds X%
- **Confidence Threshold**: Only alert if confidence drops below X%
- **Equipment IDs**: Only alert for specific equipment

**Schedule** (Optional): Time-based controls
- **Quiet Hours**: Don't send notifications during specified hours
  - Start Time: e.g., 22:00 (10 PM)
  - End Time: e.g., 06:00 (6 AM)
- **Days of Week**: Only send on specific days
  - 0 = Sunday, 1 = Monday, ..., 6 = Saturday

#### Example Rules

**Example 1: Critical Defect Rate Alert**
```
Rule Name: Critical Defect Rate Alert
Alert Type: Defect Rate
Severity: Critical
Channels: Email, SMS, Teams
Email Recipients: manager@company.com, engineer@company.com
SMS Recipients: +1-555-0100
Teams Channels: engineering-alerts
Conditions:
  - Defect Rate Threshold: 20%
Schedule: No quiet hours (24/7 alerts)
```

**Example 2: Equipment Performance Warning (Business Hours Only)**
```
Rule Name: Equipment Performance Warning
Alert Type: Equipment
Severity: High
Channels: Email, Teams
Email Recipients: maintenance@company.com
Teams Channels: maintenance-alerts
Conditions: None
Schedule:
  - Quiet Hours: 22:00 - 06:00
  - Days: Monday-Friday only
```

**Example 3: Low Priority System Updates**
```
Rule Name: System Update Notifications
Alert Type: System
Severity: Low
Channels: Email
Email Recipients: admin@company.com
Conditions: None
Schedule:
  - Quiet Hours: 18:00 - 08:00
  - Days: All days
```

### 3. Recipients Management

Centralized management of all notification recipients.

#### Email Recipients
- Add email addresses
- View all configured emails
- Remove recipients
- Emails can be used across multiple rules

#### SMS Recipients
- Add phone numbers in E.164 format (+country-area-number)
- View all configured phones
- Remove recipients
- Phone numbers can be used across multiple rules

**Phone Number Format**:
- ✅ Correct: +1-555-0100, +44-20-1234-5678
- ❌ Incorrect: 555-0100, (555) 010-0100

#### Teams Channels
- Add Teams channel IDs
- View all configured channels
- Remove channels
- Channels can be used across multiple rules

## Workflow: Setting Up Notifications

### Step 1: Configure Channels

1. Go to **Settings → Notification Rules**
2. Click **Notification Channels** tab
3. Click **Add Channel** button
4. Select channel type (Email/SMS/Teams)
5. Fill in required configuration
6. Enable the channel
7. Click **Test** to verify configuration
8. Click **Save Channel**

### Step 2: Add Recipients

1. Click **Recipients** tab
2. Add email addresses, phone numbers, and Teams channels
3. Recipients are now available for use in rules

### Step 3: Create Alert Rules

1. Click **Alert Rules** tab
2. Click **Add Rule** button
3. Configure rule:
   - Name the rule
   - Select alert type and severity
   - Choose notification channels
   - Add recipients
   - Set conditions (optional)
   - Configure schedule (optional)
4. Enable the rule
5. Click **Save Rule**

### Step 4: Test the Configuration

1. Go to **Notification Channels** tab
2. Click **Test** button on each channel
3. Verify test notifications are received
4. Adjust configuration if needed

## Notification Message Format

### Email Notification Example
```
Subject: [CRITICAL] Defect Rate Alert - Equipment EQP-001

Alert Details:
- Severity: Critical
- Type: Defect Rate
- Description: Defect rate has exceeded 20% threshold on Equipment EQP-001
- Timestamp: 2024-01-17 14:30:00
- Affected Items: Lot-2024-001, Lot-2024-002, Equipment EQP-001

Action Required:
Immediate attention required. Please investigate equipment performance.

View Alert: https://wafer-system.company.com/alerts/alert-123

---
This is an automated message from Wafer Defect Analysis System
```

### SMS Notification Example
```
[CRITICAL] Defect Rate Alert
Equipment EQP-001 defect rate exceeded 20%
View: https://wafer-system.company.com/alerts/alert-123
```

### Teams Notification Example
```
🚨 Critical Alert: Defect Rate Exceeded

Severity: Critical
Type: Defect Rate
Equipment: EQP-001

Defect rate has exceeded 20% threshold. Immediate attention required.

Affected Items:
• Lot-2024-001
• Lot-2024-002
• Equipment EQP-001

[View Alert Details]
```

## Best Practices

### Channel Configuration
1. **Test Before Production**: Always test channels before enabling
2. **Secure Credentials**: Use environment variables for sensitive data
3. **Backup Channels**: Configure multiple channels for critical alerts
4. **Monitor Delivery**: Check channel status regularly

### Rule Configuration
1. **Start Simple**: Begin with basic rules, add complexity as needed
2. **Avoid Alert Fatigue**: Don't over-alert on low-priority items
3. **Use Severity Appropriately**: Reserve Critical for truly urgent issues
4. **Set Quiet Hours**: Respect off-hours for non-critical alerts
5. **Group Recipients**: Create distribution lists for teams

### Recipient Management
1. **Keep Updated**: Remove inactive recipients
2. **Use Groups**: Organize recipients by role/team
3. **Verify Contacts**: Ensure phone numbers and emails are correct
4. **Document Ownership**: Note who owns each recipient list

## Troubleshooting

### Email Not Sending

**Check**:
- SMTP server address and port correct
- Username and password valid
- Firewall not blocking SMTP port
- From address is valid
- Test with telnet: `telnet smtp.server.com 587`

**Common Issues**:
- Gmail requires "App Password" not regular password
- Office 365 may require modern authentication
- Some servers require TLS/SSL

### SMS Not Sending

**Check**:
- API key is valid and active
- Phone numbers in correct format (+country-area-number)
- SMS provider account has credits
- Phone numbers are verified (some providers require verification)

**Common Issues**:
- Twilio requires phone number verification in trial mode
- AWS SNS requires phone numbers to opt-in
- Rate limits may apply

### Teams Not Receiving

**Check**:
- Webhook URL is correct and active
- Webhook not disabled in Teams
- Channel still exists
- Webhook has proper permissions

**Common Issues**:
- Webhooks expire if not used for 90 days
- Channel deletion removes webhook
- Webhook URL must be kept secret

## Security Considerations

### Credential Storage
- Passwords and API keys are encrypted at rest
- Use environment variables for production
- Rotate credentials regularly
- Limit access to configuration

### Access Control
- Only administrators can configure channels
- Audit log tracks all configuration changes
- Separate test and production configurations

### Data Privacy
- Alert messages may contain sensitive information
- Ensure recipients have proper clearance
- Consider data residency requirements
- Comply with GDPR/privacy regulations

## API Integration (For Developers)

### Trigger Notification Programmatically

```typescript
// Example: Trigger notification when alert is created
import { sendNotification } from './services/notificationService';

const alert = {
  id: 'alert-123',
  severity: 'critical',
  type: 'defect_rate',
  title: 'Critical Defect Rate Exceeded',
  description: 'Defect rate exceeded 20% on Equipment EQP-001',
  affectedItems: ['Lot-2024-001', 'Equipment EQP-001'],
};

// Send notification based on configured rules
await sendNotification(alert);
```

### Notification Service API

```typescript
interface NotificationService {
  // Send notification for an alert
  sendNotification(alert: Alert): Promise<void>;
  
  // Test a specific channel
  testChannel(channelId: string): Promise<boolean>;
  
  // Get notification history
  getNotificationHistory(alertId: string): Promise<NotificationLog[]>;
}
```

## Monitoring & Analytics

### Notification Metrics
- Total notifications sent
- Delivery success rate
- Average delivery time
- Failed deliveries
- Channel usage statistics

### Alert Analytics
- Most frequent alert types
- Peak alert times
- Response times
- Resolution rates

## Future Enhancements

Planned features:
1. **Webhook Integration**: Custom webhook endpoints
2. **Slack Integration**: Send to Slack channels
3. **PagerDuty Integration**: Escalation management
4. **Voice Calls**: Critical alert phone calls
5. **Mobile Push**: Native mobile app notifications
6. **Alert Aggregation**: Batch multiple alerts
7. **Smart Routing**: ML-based recipient selection
8. **Escalation Policies**: Auto-escalate unacknowledged alerts

## Support

For assistance with notification configuration:
- Email: support@company.com
- Documentation: https://docs.wafer-system.company.com
- Slack: #wafer-system-support
