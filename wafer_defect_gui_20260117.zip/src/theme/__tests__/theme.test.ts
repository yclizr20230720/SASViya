import { describe, it, expect } from 'vitest';
import { lightTheme, darkTheme } from '../theme';

describe('Theme Configuration', () => {
  it('should have correct primary color for light theme', () => {
    expect(lightTheme.palette.primary.main).toBe('#0066CC');
  });

  it('should have correct secondary color for light theme', () => {
    expect(lightTheme.palette.secondary.main).toBe('#00A3A3');
  });

  it('should have Inter as primary font family', () => {
    expect(lightTheme.typography.fontFamily).toContain('Inter');
  });

  it('should have 8px spacing unit', () => {
    expect(lightTheme.spacing(1)).toBe('8px');
  });

  it('should have dark mode configured', () => {
    expect(darkTheme.palette.mode).toBe('dark');
  });

  it('should have custom border radius', () => {
    expect(lightTheme.shape.borderRadius).toBe(8);
  });

  it('should have responsive breakpoints', () => {
    expect(lightTheme.breakpoints.values.xs).toBe(0);
    expect(lightTheme.breakpoints.values.sm).toBe(600);
    expect(lightTheme.breakpoints.values.md).toBe(960);
    expect(lightTheme.breakpoints.values.lg).toBe(1280);
    expect(lightTheme.breakpoints.values.xl).toBe(1920);
  });
});
