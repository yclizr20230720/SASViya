import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  LinearProgress,
  Chip,
  Alert,
  Grid,
} from '@mui/material';
import {
  CloudUpload,
  Delete,
  CheckCircle,
  Error as ErrorIcon,
} from '@mui/icons-material';
import { useAppDispatch } from '../store/hooks';
import { addWafer } from '../store/slices/waferSlice';

interface UploadFile {
  file: File;
  id: string;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
  error?: string;
}

export default function Upload() {
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [metadata, setMetadata] = useState({
    lotId: '',
    processStep: '',
    equipmentId: '',
  });
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'text/csv': ['.csv'],
      'application/json': ['.json'],
    },
    onDrop: (acceptedFiles) => {
      const newFiles = acceptedFiles.map((file) => ({
        file,
        id: Math.random().toString(36).substr(2, 9),
        progress: 0,
        status: 'pending' as const,
      }));
      setFiles((prev) => [...prev, ...newFiles]);
    },
  });

  const handleRemoveFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const simulateUpload = (fileId: string) => {
    const interval = setInterval(() => {
      setFiles((prev) =>
        prev.map((f) => {
          if (f.id === fileId) {
            const newProgress = Math.min(f.progress + 10, 100);
            return {
              ...f,
              progress: newProgress,
              status: newProgress === 100 ? 'completed' : 'uploading',
            };
          }
          return f;
        })
      );
    }, 200);

    setTimeout(() => {
      clearInterval(interval);
    }, 2000);
  };

  const handleUpload = () => {
    if (files.length === 0) return;

    files.forEach((file) => {
      if (file.status === 'pending') {
        simulateUpload(file.id);

        // Simulate adding to store after upload
        setTimeout(() => {
          const waferId = `W2026-${Math.floor(Math.random() * 1000)
            .toString()
            .padStart(3, '0')}`;
          dispatch(
            addWafer({
              id: file.id,
              waferId,
              lotId: metadata.lotId || 'LOT-AUTO',
              processStep: metadata.processStep || 'Unknown',
              equipmentId: metadata.equipmentId || 'EQ-AUTO',
              timestamp: new Date().toISOString(),
              status: 'processing',
            })
          );
        }, 2500);
      }
    });
  };

  const handleViewResults = () => {
    navigate('/history');
  };

  const allCompleted = files.length > 0 && files.every((f) => f.status === 'completed');

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 3, fontWeight: 600 }}>
        Upload Wafer Maps
      </Typography>

      <Grid container spacing={3}>
        {/* Upload Zone */}
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card>
            <CardContent>
              <Box
                {...getRootProps()}
                sx={{
                  border: '2px dashed',
                  borderColor: isDragActive ? 'primary.main' : 'grey.300',
                  borderRadius: 2,
                  p: 6,
                  textAlign: 'center',
                  cursor: 'pointer',
                  bgcolor: isDragActive ? 'action.hover' : 'background.paper',
                  transition: 'all 0.3s',
                  '&:hover': {
                    borderColor: 'primary.main',
                    bgcolor: 'action.hover',
                  },
                }}
              >
                <input {...getInputProps()} />
                <CloudUpload sx={{ fontSize: 64, color: 'primary.main', mb: 2 }} />
                <Typography variant="h6" gutterBottom>
                  {isDragActive
                    ? 'Drop files here...'
                    : 'Drag & drop wafer map files here'}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  or click to browse
                </Typography>
                <Chip label="CSV" size="small" sx={{ mr: 1 }} />
                <Chip label="JSON" size="small" />
              </Box>

              {/* File List */}
              {files.length > 0 && (
                <Box sx={{ mt: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    Files ({files.length})
                  </Typography>
                  <List>
                    {files.map((uploadFile) => (
                      <ListItem
                        key={uploadFile.id}
                        sx={{
                          border: 1,
                          borderColor: 'divider',
                          borderRadius: 1,
                          mb: 1,
                        }}
                      >
                        <Box sx={{ flex: 1 }}>
                          <ListItemText
                            primary={uploadFile.file.name}
                            secondary={`${(uploadFile.file.size / 1024).toFixed(2)} KB`}
                          />
                          {uploadFile.status === 'uploading' && (
                            <LinearProgress
                              variant="determinate"
                              value={uploadFile.progress}
                              sx={{ mt: 1 }}
                            />
                          )}
                          {uploadFile.status === 'completed' && (
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 1 }}>
                              <CheckCircle color="success" fontSize="small" />
                              <Typography variant="caption" color="success.main">
                                Upload completed
                              </Typography>
                            </Box>
                          )}
                          {uploadFile.status === 'error' && (
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 1 }}>
                              <ErrorIcon color="error" fontSize="small" />
                              <Typography variant="caption" color="error.main">
                                {uploadFile.error || 'Upload failed'}
                              </Typography>
                            </Box>
                          )}
                        </Box>
                        <ListItemSecondaryAction>
                          {uploadFile.status === 'pending' && (
                            <IconButton
                              edge="end"
                              onClick={() => handleRemoveFile(uploadFile.id)}
                            >
                              <Delete />
                            </IconButton>
                          )}
                        </ListItemSecondaryAction>
                      </ListItem>
                    ))}
                  </List>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Metadata Form */}
        <Grid size={{ xs: 12, lg: 4 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Wafer Metadata
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Optional information for batch processing
              </Typography>

              <TextField
                fullWidth
                label="Lot ID"
                value={metadata.lotId}
                onChange={(e) => setMetadata({ ...metadata, lotId: e.target.value })}
                sx={{ mb: 2 }}
                placeholder="e.g., LOT-2026-A001"
              />

              <TextField
                fullWidth
                label="Process Step"
                value={metadata.processStep}
                onChange={(e) => setMetadata({ ...metadata, processStep: e.target.value })}
                sx={{ mb: 2 }}
                placeholder="e.g., Lithography"
              />

              <TextField
                fullWidth
                label="Equipment ID"
                value={metadata.equipmentId}
                onChange={(e) => setMetadata({ ...metadata, equipmentId: e.target.value })}
                sx={{ mb: 3 }}
                placeholder="e.g., LITHO-001"
              />

              <Button
                fullWidth
                variant="contained"
                size="large"
                onClick={handleUpload}
                disabled={files.length === 0 || allCompleted}
                startIcon={<CloudUpload />}
              >
                {allCompleted ? 'Upload Complete' : 'Start Upload'}
              </Button>

              {allCompleted && (
                <Button
                  fullWidth
                  variant="outlined"
                  size="large"
                  onClick={handleViewResults}
                  sx={{ mt: 2 }}
                >
                  View Results
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Info Card */}
          <Card sx={{ mt: 2 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Supported Formats
              </Typography>
              <Alert severity="info" sx={{ mt: 2 }}>
                <Typography variant="body2">
                  • CSV files with die coordinates
                  <br />
                  • JSON format (SEMI standard)
                  <br />
                  • Maximum file size: 50MB
                  <br />• Batch upload supported
                </Typography>
              </Alert>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
