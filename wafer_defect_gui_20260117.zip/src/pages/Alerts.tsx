import { useState } from 'react';
import { Box, Typography } from '@mui/material';
import AlertManagement from '../components/AlertManagement';
import type { Alert } from '../components/AlertManagement';

// Mock data
const mockAlerts: Alert[] = [
  {
    id: 'alert-1',
    severity: 'critical',
    type: 'defect_rate',
    title: 'Critical Defect Rate Exceeded',
    description: 'Defect rate has exceeded 20% threshold on Equipment EQP-001. Immediate attention required.',
    timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    status: 'active',
    affectedItems: ['Lot-2024-001', 'Lot-2024-002', 'Equipment EQP-001'],
  },
  {
    id: 'alert-2',
    severity: 'high',
    type: 'confidence',
    title: 'Low Confidence Score Detected',
    description: 'Model confidence has dropped below 70% for pattern classification on recent wafers.',
    timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    status: 'acknowledged',
    acknowledgedBy: 'John Doe',
    acknowledgedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    affectedItems: ['Wafer-W123', 'Wafer-W124', 'Wafer-W125'],
  },
  {
    id: 'alert-3',
    severity: 'high',
    type: 'equipment',
    title: 'Equipment Performance Degradation',
    description: 'Equipment EQP-003 showing increased defect patterns. Maintenance may be required.',
    timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    status: 'active',
    affectedItems: ['Equipment EQP-003'],
  },
  {
    id: 'alert-4',
    severity: 'medium',
    type: 'pattern',
    title: 'Unusual Pattern Detected',
    description: 'New defect pattern detected that does not match known classifications.',
    timestamp: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    status: 'acknowledged',
    acknowledgedBy: 'Jane Smith',
    acknowledgedAt: new Date(Date.now() - 1000 * 60 * 150).toISOString(),
    affectedItems: ['Lot-2024-005'],
  },
  {
    id: 'alert-5',
    severity: 'low',
    type: 'system',
    title: 'System Update Available',
    description: 'A new model version is available for deployment.',
    timestamp: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
    status: 'active',
  },
  {
    id: 'alert-6',
    severity: 'critical',
    type: 'defect_rate',
    title: 'Yield Drop Alert',
    description: 'Significant yield drop detected in Process Step 5. Defect rate increased by 15%.',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    status: 'resolved',
    acknowledgedBy: 'Mike Johnson',
    acknowledgedAt: new Date(Date.now() - 1000 * 60 * 60 * 23).toISOString(),
    resolvedBy: 'Mike Johnson',
    resolvedAt: new Date(Date.now() - 1000 * 60 * 60 * 20).toISOString(),
    resolution: 'Equipment calibration performed. Defect rate returned to normal levels.',
    affectedItems: ['Process Step 5', 'Equipment EQP-002'],
  },
  {
    id: 'alert-7',
    severity: 'high',
    type: 'pattern',
    title: 'Edge Pattern Spike',
    description: 'Significant increase in edge-ring defect patterns detected across multiple lots.',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    status: 'active',
    affectedItems: ['Lot-2024-010', 'Lot-2024-011', 'Lot-2024-012'],
  },
];

export default function Alerts() {
  const [alerts, setAlerts] = useState<Alert[]>(mockAlerts);

  const handleAcknowledge = (id: string) => {
    setAlerts((prev) =>
      prev.map((alert) =>
        alert.id === id
          ? {
              ...alert,
              status: 'acknowledged',
              acknowledgedBy: 'Current User',
              acknowledgedAt: new Date().toISOString(),
            }
          : alert
      )
    );
  };

  const handleResolve = (id: string, resolution: string) => {
    setAlerts((prev) =>
      prev.map((alert) =>
        alert.id === id
          ? {
              ...alert,
              status: 'resolved',
              resolvedBy: 'Current User',
              resolvedAt: new Date().toISOString(),
              resolution,
            }
          : alert
      )
    );
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 3, fontWeight: 600 }}>
        System Alerts
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
        Monitor and manage system alerts, defect rate warnings, and equipment notifications
      </Typography>

      <AlertManagement
        alerts={alerts}
        onAcknowledge={handleAcknowledge}
        onResolve={handleResolve}
      />
    </Box>
  );
}
