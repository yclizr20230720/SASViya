import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Switch,
  FormControlLabel,
  Divider,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Grid,
  Tabs,
  Tab,
  Slider,
  Chip,
  Alert,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
} from '@mui/material';
import {
  Save,
  Refresh,
  Delete,
  Add,
  Security,
  Notifications,
  Palette,
  DataUsage,
  Assessment,
  CloudUpload,
  Key,
} from '@mui/icons-material';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { setTheme, setLanguage, updateNotifications } from '../store/slices/settingsSlice';
import NotificationRulesConfig from '../components/NotificationRulesConfig';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`settings-tabpanel-${index}`}
      aria-labelledby={`settings-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

export default function Settings() {
  const dispatch = useAppDispatch();
  const settings = useAppSelector((state) => state.settings);
  const [activeTab, setActiveTab] = useState(0);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Local state for settings
  const [confidenceThreshold, setConfidenceThreshold] = useState(75);
  const [autoRefreshInterval, setAutoRefreshInterval] = useState(30);
  const [dataRetentionDays, setDataRetentionDays] = useState(90);
  const [maxUploadSize, setMaxUploadSize] = useState(100);

  const handleSave = () => {
    // Save settings logic here
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          Settings & Preferences
        </Typography>
        <Button variant="contained" startIcon={<Save />} onClick={handleSave}>
          Save All Changes
        </Button>
      </Box>

      {saveSuccess && (
        <Alert severity="success" sx={{ mb: 3 }}>
          Settings saved successfully!
        </Alert>
      )}

      <Card>
        <Tabs
          value={activeTab}
          onChange={(_, newValue) => setActiveTab(newValue)}
          variant="scrollable"
          scrollButtons="auto"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab icon={<Palette />} label="Appearance" iconPosition="start" />
          <Tab icon={<Notifications />} label="Notifications" iconPosition="start" />
          <Tab icon={<DataUsage />} label="Data Display" iconPosition="start" />
          <Tab icon={<Assessment />} label="Analysis" iconPosition="start" />
          <Tab icon={<Security />} label="Security" iconPosition="start" />
          <Tab icon={<CloudUpload />} label="Integration" iconPosition="start" />
          <Tab icon={<Notifications />} label="Notification Rules" iconPosition="start" />
        </Tabs>

        {/* Appearance Tab */}
        <TabPanel value={activeTab} index={0}>
          <CardContent>
            <Grid container spacing={3}>
              <Grid size={{ xs: 12, md: 6 }}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Theme Settings
                </Typography>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Theme Mode</InputLabel>
                  <Select
                    value={settings.theme}
                    label="Theme Mode"
                    onChange={(e) => dispatch(setTheme(e.target.value as 'light' | 'dark'))}
                  >
                    <MenuItem value="light">Light</MenuItem>
                    <MenuItem value="dark">Dark</MenuItem>
                    <MenuItem value="auto">Auto (System)</MenuItem>
                  </Select>
                </FormControl>

                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Color Scheme</InputLabel>
                  <Select defaultValue="blue" label="Color Scheme">
                    <MenuItem value="blue">Blue (Default)</MenuItem>
                    <MenuItem value="green">Green</MenuItem>
                    <MenuItem value="purple">Purple</MenuItem>
                    <MenuItem value="orange">Orange</MenuItem>
                  </Select>
                </FormControl>

                <FormControl fullWidth>
                  <InputLabel>Density</InputLabel>
                  <Select defaultValue="comfortable" label="Density">
                    <MenuItem value="compact">Compact</MenuItem>
                    <MenuItem value="comfortable">Comfortable</MenuItem>
                    <MenuItem value="spacious">Spacious</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Localization
                </Typography>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Language</InputLabel>
                  <Select
                    value={settings.language}
                    label="Language"
                    onChange={(e) => dispatch(setLanguage(e.target.value))}
                  >
                    <MenuItem value="en">English</MenuItem>
                    <MenuItem value="zh">中文 (Chinese)</MenuItem>
                    <MenuItem value="ja">日本語 (Japanese)</MenuItem>
                    <MenuItem value="ko">한국어 (Korean)</MenuItem>
                  </Select>
                </FormControl>

                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Date Format</InputLabel>
                  <Select defaultValue="MM/DD/YYYY" label="Date Format">
                    <MenuItem value="MM/DD/YYYY">MM/DD/YYYY</MenuItem>
                    <MenuItem value="DD/MM/YYYY">DD/MM/YYYY</MenuItem>
                    <MenuItem value="YYYY-MM-DD">YYYY-MM-DD</MenuItem>
                  </Select>
                </FormControl>

                <FormControl fullWidth>
                  <InputLabel>Time Format</InputLabel>
                  <Select defaultValue="12h" label="Time Format">
                    <MenuItem value="12h">12-hour (AM/PM)</MenuItem>
                    <MenuItem value="24h">24-hour</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Display Options
                </Typography>
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Show tooltips"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Enable animations"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch />}
                  label="High contrast mode"
                  sx={{ display: 'block' }}
                />
              </Grid>
            </Grid>
          </CardContent>
        </TabPanel>

        {/* Notifications Tab */}
        <TabPanel value={activeTab} index={1}>
          <CardContent>
            <Grid container spacing={3}>
              <Grid size={{ xs: 12, md: 6 }}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Notification Channels
                </Typography>
                <FormControlLabel
                  control={
                    <Switch
                      checked={settings.notifications.email}
                      onChange={(e) =>
                        dispatch(updateNotifications({ email: e.target.checked }))
                      }
                    />
                  }
                  label="Email Notifications"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControlLabel
                  control={
                    <Switch
                      checked={settings.notifications.inApp}
                      onChange={(e) =>
                        dispatch(updateNotifications({ inApp: e.target.checked }))
                      }
                    />
                  }
                  label="In-App Notifications"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControlLabel
                  control={
                    <Switch
                      checked={settings.notifications.push}
                      onChange={(e) =>
                        dispatch(updateNotifications({ push: e.target.checked }))
                      }
                    />
                  }
                  label="Push Notifications"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="SMS Notifications"
                  sx={{ display: 'block' }}
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Notification Types
                </Typography>
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="High defect rate alerts"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Pattern detection alerts"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Model update notifications"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch />}
                  label="Daily summary reports"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch />}
                  label="System maintenance alerts"
                  sx={{ display: 'block' }}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Alert Thresholds
                </Typography>
                <Grid container spacing={2}>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <TextField
                      fullWidth
                      label="Defect Rate Threshold (%)"
                      type="number"
                      defaultValue="15"
                      helperText="Alert when defect rate exceeds this value"
                    />
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <TextField
                      fullWidth
                      label="Confidence Score Threshold (%)"
                      type="number"
                      defaultValue="70"
                      helperText="Alert when confidence drops below this value"
                    />
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </CardContent>
        </TabPanel>

        {/* Data Display Tab */}
        <TabPanel value={activeTab} index={2}>
          <CardContent>
            <Grid container spacing={3}>
              <Grid size={{ xs: 12 }}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Table & Grid Settings
                </Typography>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Default Page Size</InputLabel>
                  <Select defaultValue="25" label="Default Page Size">
                    <MenuItem value="10">10 rows</MenuItem>
                    <MenuItem value="25">25 rows</MenuItem>
                    <MenuItem value="50">50 rows</MenuItem>
                    <MenuItem value="100">100 rows</MenuItem>
                  </Select>
                </FormControl>

                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Show row numbers"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Enable column sorting"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Enable column filtering"
                  sx={{ display: 'block' }}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Wafer Map Display
                </Typography>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Default Color Scheme</InputLabel>
                  <Select defaultValue="heatmap" label="Default Color Scheme">
                    <MenuItem value="heatmap">Heatmap (Blue to Red)</MenuItem>
                    <MenuItem value="grayscale">Grayscale</MenuItem>
                    <MenuItem value="viridis">Viridis</MenuItem>
                    <MenuItem value="plasma">Plasma</MenuItem>
                  </Select>
                </FormControl>

                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Show die coordinates"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Show defect markers"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch />}
                  label="Enable zoom controls"
                  sx={{ display: 'block' }}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Chart Settings
                </Typography>
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Show data labels"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Enable chart animations"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Show legend"
                  sx={{ display: 'block' }}
                />
              </Grid>
            </Grid>
          </CardContent>
        </TabPanel>

        {/* Analysis Tab */}
        <TabPanel value={activeTab} index={3}>
          <CardContent>
            <Grid container spacing={3}>
              <Grid size={{ xs: 12 }}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Model Configuration
                </Typography>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Default Model</InputLabel>
                  <Select defaultValue="cnn-v2" label="Default Model">
                    <MenuItem value="cnn-v1">CNN v1 (Legacy)</MenuItem>
                    <MenuItem value="cnn-v2">CNN v2 (Recommended)</MenuItem>
                    <MenuItem value="resnet">ResNet-50</MenuItem>
                    <MenuItem value="efficientnet">EfficientNet</MenuItem>
                  </Select>
                </FormControl>

                <Typography variant="body2" gutterBottom>
                  Confidence Threshold: {confidenceThreshold}%
                </Typography>
                <Slider
                  value={confidenceThreshold}
                  onChange={(_, value) => setConfidenceThreshold(value as number)}
                  min={0}
                  max={100}
                  marks={[
                    { value: 0, label: '0%' },
                    { value: 50, label: '50%' },
                    { value: 100, label: '100%' },
                  ]}
                  sx={{ mb: 3 }}
                />

                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Enable automatic model updates"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Use ensemble predictions"
                  sx={{ display: 'block' }}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Pattern Detection
                </Typography>
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Enable pattern classification"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Detect edge patterns"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Detect center patterns"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch />}
                  label="Detect scratch patterns"
                  sx={{ display: 'block' }}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Processing Options
                </Typography>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Batch Processing Size</InputLabel>
                  <Select defaultValue="32" label="Batch Processing Size">
                    <MenuItem value="16">16 wafers</MenuItem>
                    <MenuItem value="32">32 wafers</MenuItem>
                    <MenuItem value="64">64 wafers</MenuItem>
                    <MenuItem value="128">128 wafers</MenuItem>
                  </Select>
                </FormControl>

                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Enable parallel processing"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch />}
                  label="Use GPU acceleration"
                  sx={{ display: 'block' }}
                />
              </Grid>
            </Grid>
          </CardContent>
        </TabPanel>

        {/* Security Tab */}
        <TabPanel value={activeTab} index={4}>
          <CardContent>
            <Grid container spacing={3}>
              <Grid size={{ xs: 12, md: 6 }}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Authentication
                </Typography>
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Require two-factor authentication"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Remember login for 30 days"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Session Timeout</InputLabel>
                  <Select defaultValue="60" label="Session Timeout">
                    <MenuItem value="15">15 minutes</MenuItem>
                    <MenuItem value="30">30 minutes</MenuItem>
                    <MenuItem value="60">1 hour</MenuItem>
                    <MenuItem value="240">4 hours</MenuItem>
                  </Select>
                </FormControl>
                <Button variant="outlined" startIcon={<Key />} fullWidth>
                  Change Password
                </Button>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Data Privacy
                </Typography>
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Encrypt data at rest"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Encrypt data in transit"
                  sx={{ mb: 2, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch />}
                  label="Enable audit logging"
                  sx={{ mb: 2, display: 'block' }}
                />
                <Typography variant="body2" gutterBottom>
                  Data Retention: {dataRetentionDays} days
                </Typography>
                <Slider
                  value={dataRetentionDays}
                  onChange={(_, value) => setDataRetentionDays(value as number)}
                  min={30}
                  max={365}
                  marks={[
                    { value: 30, label: '30d' },
                    { value: 90, label: '90d' },
                    { value: 180, label: '180d' },
                    { value: 365, label: '1y' },
                  ]}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  API Keys
                </Typography>
                <List>
                  <ListItem>
                    <ListItemText
                      primary="Production API Key"
                      secondary="Created: Jan 15, 2024 • Last used: 2 hours ago"
                    />
                    <ListItemSecondaryAction>
                      <IconButton edge="end" size="small">
                        <Refresh />
                      </IconButton>
                      <IconButton edge="end" size="small" color="error">
                        <Delete />
                      </IconButton>
                    </ListItemSecondaryAction>
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="Development API Key"
                      secondary="Created: Jan 10, 2024 • Last used: 1 day ago"
                    />
                    <ListItemSecondaryAction>
                      <IconButton edge="end" size="small">
                        <Refresh />
                      </IconButton>
                      <IconButton edge="end" size="small" color="error">
                        <Delete />
                      </IconButton>
                    </ListItemSecondaryAction>
                  </ListItem>
                </List>
                <Button variant="outlined" startIcon={<Add />} sx={{ mt: 2 }}>
                  Generate New API Key
                </Button>
              </Grid>
            </Grid>
          </CardContent>
        </TabPanel>

        {/* Integration Tab */}
        <TabPanel value={activeTab} index={5}>
          <CardContent>
            <Grid container spacing={3}>
              <Grid size={{ xs: 12 }}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Data Upload Settings
                </Typography>
                <Typography variant="body2" gutterBottom>
                  Maximum Upload Size: {maxUploadSize} MB
                </Typography>
                <Slider
                  value={maxUploadSize}
                  onChange={(_, value) => setMaxUploadSize(value as number)}
                  min={10}
                  max={500}
                  marks={[
                    { value: 10, label: '10MB' },
                    { value: 100, label: '100MB' },
                    { value: 250, label: '250MB' },
                    { value: 500, label: '500MB' },
                  ]}
                  sx={{ mb: 3 }}
                />

                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Allowed File Types</InputLabel>
                  <Select
                    multiple
                    defaultValue={['csv', 'xlsx', 'json']}
                    label="Allowed File Types"
                    renderValue={(selected) => (
                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {(selected as string[]).map((value) => (
                          <Chip key={value} label={value.toUpperCase()} size="small" />
                        ))}
                      </Box>
                    )}
                  >
                    <MenuItem value="csv">CSV</MenuItem>
                    <MenuItem value="xlsx">XLSX</MenuItem>
                    <MenuItem value="json">JSON</MenuItem>
                    <MenuItem value="xml">XML</MenuItem>
                    <MenuItem value="txt">TXT</MenuItem>
                  </Select>
                </FormControl>

                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Auto-process uploaded files"
                  sx={{ mb: 1, display: 'block' }}
                />
                <FormControlLabel
                  control={<Switch />}
                  label="Validate file format before upload"
                  sx={{ display: 'block' }}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Auto-Refresh Settings
                </Typography>
                <Typography variant="body2" gutterBottom>
                  Dashboard Refresh Interval: {autoRefreshInterval} seconds
                </Typography>
                <Slider
                  value={autoRefreshInterval}
                  onChange={(_, value) => setAutoRefreshInterval(value as number)}
                  min={10}
                  max={300}
                  marks={[
                    { value: 10, label: '10s' },
                    { value: 30, label: '30s' },
                    { value: 60, label: '1m' },
                    { value: 300, label: '5m' },
                  ]}
                  sx={{ mb: 2 }}
                />
                <FormControlLabel
                  control={<Switch defaultChecked />}
                  label="Enable auto-refresh"
                  sx={{ display: 'block' }}
                />
              </Grid>

              <Grid size={{ xs: 12 }}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  External Integrations
                </Typography>
                <List>
                  <ListItem>
                    <ListItemText
                      primary="MES System Integration"
                      secondary="Status: Connected • Last sync: 5 minutes ago"
                    />
                    <ListItemSecondaryAction>
                      <Switch defaultChecked />
                    </ListItemSecondaryAction>
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="ERP System Integration"
                      secondary="Status: Connected • Last sync: 1 hour ago"
                    />
                    <ListItemSecondaryAction>
                      <Switch defaultChecked />
                    </ListItemSecondaryAction>
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="Email Server (SMTP)"
                      secondary="Status: Configured • smtp.company.com"
                    />
                    <ListItemSecondaryAction>
                      <Switch defaultChecked />
                    </ListItemSecondaryAction>
                  </ListItem>
                  <ListItem>
                    <ListItemText
                      primary="Cloud Storage (S3)"
                      secondary="Status: Not configured"
                    />
                    <ListItemSecondaryAction>
                      <Switch />
                    </ListItemSecondaryAction>
                  </ListItem>
                </List>
                <Button variant="outlined" startIcon={<Add />} sx={{ mt: 2 }}>
                  Add New Integration
                </Button>
              </Grid>
            </Grid>
          </CardContent>
        </TabPanel>

        {/* Notification Rules Tab */}
        <TabPanel value={activeTab} index={6}>
          <CardContent>
            <NotificationRulesConfig />
          </CardContent>
        </TabPanel>
      </Card>
    </Box>
  );
}
