import { Box, Typography, Grid, Tabs, Tab } from '@mui/material';
import { useState } from 'react';
import PatternDistributionCharts from '../components/PatternDistributionCharts';
import TemporalTrendAnalysis from '../components/TemporalTrendAnalysis';
import YieldAnalysisCharts from '../components/YieldAnalysisCharts';
import EquipmentCorrelationAnalysis from '../components/EquipmentCorrelationAnalysis';
import ProcessStepAnalysis from '../components/ProcessStepAnalysis';

export default function Analytics() {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 3, fontWeight: 600 }}>
        Reports & Trends
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
        Comprehensive analytics and insights for wafer defect patterns, yield trends, and equipment performance
      </Typography>

      {/* Tab Navigation */}
      <Tabs
        value={activeTab}
        onChange={(_, newValue) => setActiveTab(newValue)}
        sx={{ mb: 3, borderBottom: 1, borderColor: 'divider' }}
      >
        <Tab label="Overview" />
        <Tab label="Equipment & Process" />
      </Tabs>

      {/* Overview Tab */}
      {activeTab === 0 && (
        <Grid container spacing={3}>
          <Grid size={{ xs: 12 }}>
            <PatternDistributionCharts />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <TemporalTrendAnalysis />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <YieldAnalysisCharts />
          </Grid>
        </Grid>
      )}

      {/* Equipment & Process Tab */}
      {activeTab === 1 && (
        <Grid container spacing={3}>
          <Grid size={{ xs: 12 }}>
            <EquipmentCorrelationAnalysis />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <ProcessStepAnalysis />
          </Grid>
        </Grid>
      )}
    </Box>
  );
}
