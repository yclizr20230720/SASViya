/**
 * Ingest Wafers Page
 * Upload and manage wafer map files for training data
 */

import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import {
  Box,
  Grid,
  Typography,
  Paper,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  LinearProgress,
  Chip,
  Alert,
  useTheme
} from '@mui/material';
import {
  CloudUpload,
  InsertDriveFile,
  Delete,
  CheckCircle,
  Storage,
  Add
} from '@mui/icons-material';

interface UploadFile {
  name: string;
  size: string;
  progress: number;
  status: 'uploading' | 'complete';
  id: string;
}

/**
 * Ingest Wafers Component
 */
const IngestWafers: React.FC = () => {
  const theme = useTheme();
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [metadata, setMetadata] = useState({
    lotId: '',
    equipmentId: '',
    processStep: 'Lithography'
  });

  // Dropzone configuration
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'text/csv': ['.csv'],
      'application/xml': ['.xml'],
      'application/octet-stream': ['.bin'],
    },
    onDrop: (acceptedFiles) => {
      acceptedFiles.forEach((file) => {
        const mockFile: UploadFile = {
          name: file.name,
          size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
          progress: 0,
          status: 'uploading',
          id: Math.random().toString(36).substring(2, 11)
        };
        
        setFiles((prev) => [...prev, mockFile]);

        // Simulate upload progress
        let prog = 0;
        const interval = setInterval(() => {
          prog += 10;
          setFiles((prev) =>
            prev.map((f) =>
              f.id === mockFile.id
                ? { ...f, progress: prog, status: prog >= 100 ? 'complete' : 'uploading' }
                : f
            )
          );
          if (prog >= 100) {
            clearInterval(interval);
          }
        }, 200);
      });
    }
  });

  const handleRemoveFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const handleCommit = () => {
    // Handle commit to library
    console.log('Committing files to library:', { files, metadata });
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={600} gutterBottom>
          Ingest Wafer Data
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Upload KLA, Applied Materials, or SEMI SECS/GEM compatible map files
        </Typography>
      </Box>

      <Grid container spacing={3}>
        {/* Left Column - Upload Zone and Queue */}
        <Grid size={{ xs: 12, lg: 8 }}>
          {/* Drag and Drop Zone */}
          <Paper
            {...getRootProps()}
            sx={{
              p: 6,
              mb: 3,
              border: '2px dashed',
              borderColor: isDragActive ? 'primary.main' : 'divider',
              borderRadius: 3,
              textAlign: 'center',
              cursor: 'pointer',
              bgcolor: isDragActive ? 'action.hover' : 'background.paper',
              transition: 'all 0.3s',
              '&:hover': {
                borderColor: 'primary.main',
                bgcolor: 'action.hover',
                transform: 'translateY(-2px)',
                boxShadow: theme.shadows[4]
              }
            }}
          >
            <input {...getInputProps()} />
            <Box
              sx={{
                width: 64,
                height: 64,
                borderRadius: '50%',
                bgcolor: 'success.lighter',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mx: 'auto',
                mb: 3,
                transition: 'transform 0.3s',
                '&:hover': {
                  transform: 'scale(1.1)'
                }
              }}
            >
              <CloudUpload sx={{ fontSize: 32, color: 'success.main' }} />
            </Box>
            <Typography variant="h6" gutterBottom>
              Drag and drop wafer maps
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Supports .csv, .xml, .bin, and proprietary KLARF formats
            </Typography>
            <Button
              variant="contained"
              sx={{
                borderRadius: 2,
                px: 4,
                py: 1.5,
                fontWeight: 600
              }}
            >
              Browse Files
            </Button>
          </Paper>

          {/* Queue Management */}
          <Paper sx={{ borderRadius: 3, overflow: 'hidden' }}>
            <Box
              sx={{
                p: 2,
                borderBottom: 1,
                borderColor: 'divider',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <Typography variant="h6" fontWeight={600}>
                Queue Management
              </Typography>
              <Chip
                label={`${files.length} Files Pending`}
                size="small"
                color="primary"
                variant="outlined"
              />
            </Box>

            {files.length === 0 ? (
              <Box sx={{ p: 6, textAlign: 'center' }}>
                <Typography variant="body2" color="text.secondary">
                  No files in queue
                </Typography>
              </Box>
            ) : (
              <List sx={{ p: 0 }}>
                {files.map((file) => (
                  <ListItem
                    key={file.id}
                    sx={{
                      borderBottom: 1,
                      borderColor: 'divider',
                      '&:last-child': {
                        borderBottom: 0
                      },
                      '&:hover': {
                        bgcolor: 'action.hover'
                      }
                    }}
                  >
                    <ListItemIcon>
                      <Box
                        sx={{
                          width: 40,
                          height: 40,
                          borderRadius: 1,
                          bgcolor: 'grey.100',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        <InsertDriveFile sx={{ color: 'text.secondary' }} />
                      </Box>
                    </ListItemIcon>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="body2" fontWeight={600}>
                            {file.name}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {file.size}
                          </Typography>
                        </Box>
                      }
                      secondary={
                        <LinearProgress
                          variant="determinate"
                          value={file.progress}
                          sx={{
                            height: 6,
                            borderRadius: 3,
                            bgcolor: 'grey.200',
                            '& .MuiLinearProgress-bar': {
                              borderRadius: 3,
                              bgcolor: file.status === 'complete' ? 'success.main' : 'primary.main'
                            }
                          }}
                        />
                      }
                    />
                    <ListItemSecondaryAction>
                      {file.status === 'complete' ? (
                        <CheckCircle sx={{ color: 'success.main' }} />
                      ) : (
                        <IconButton
                          edge="end"
                          onClick={() => handleRemoveFile(file.id)}
                          size="small"
                        >
                          <Delete sx={{ fontSize: 20 }} />
                        </IconButton>
                      )}
                    </ListItemSecondaryAction>
                  </ListItem>
                ))}
              </List>
            )}
          </Paper>
        </Grid>

        {/* Right Column - Metadata and Info */}
        <Grid size={{ xs: 12, lg: 4 }}>
          {/* Batch Metadata */}
          <Paper sx={{ p: 3, mb: 3, borderRadius: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
              <Add sx={{ color: 'text.secondary' }} />
              <Typography variant="h6" fontWeight={600}>
                Batch Metadata
              </Typography>
            </Box>

            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <TextField
                fullWidth
                label="Lot ID"
                placeholder="e.g. LOT-2024-X1"
                value={metadata.lotId}
                onChange={(e) => setMetadata({ ...metadata, lotId: e.target.value })}
                size="small"
              />

              <FormControl fullWidth size="small">
                <InputLabel>Process Step</InputLabel>
                <Select
                  value={metadata.processStep}
                  label="Process Step"
                  onChange={(e) => setMetadata({ ...metadata, processStep: e.target.value })}
                >
                  <MenuItem value="Lithography">Lithography</MenuItem>
                  <MenuItem value="Etch">Etch</MenuItem>
                  <MenuItem value="CMP">CMP</MenuItem>
                  <MenuItem value="CVD">CVD</MenuItem>
                  <MenuItem value="PVD">PVD</MenuItem>
                  <MenuItem value="Implant">Implant</MenuItem>
                </Select>
              </FormControl>

              <TextField
                fullWidth
                label="Equipment ID"
                placeholder="e.g. TOOL-ASML-04"
                value={metadata.equipmentId}
                onChange={(e) => setMetadata({ ...metadata, equipmentId: e.target.value })}
                size="small"
              />
            </Box>

            <Button
              fullWidth
              variant="contained"
              size="large"
              startIcon={<Storage />}
              onClick={handleCommit}
              disabled={files.length === 0}
              sx={{
                mt: 3,
                py: 1.5,
                borderRadius: 2,
                fontWeight: 600,
                boxShadow: theme.shadows[4]
              }}
            >
              Commit to Library
            </Button>
          </Paper>

          {/* Batch Processing Info */}
          <Alert
            severity="success"
            icon={<CheckCircle />}
            sx={{
              borderRadius: 3,
              '& .MuiAlert-message': {
                width: '100%'
              }
            }}
          >
            <Typography variant="subtitle2" fontWeight={600} gutterBottom>
              Batch Processing Active
            </Typography>
            <Typography variant="caption" sx={{ display: 'block', lineHeight: 1.6 }}>
              Multiple file uploads are processed in parallel using the distributed inference
              worker cluster.
            </Typography>
          </Alert>

          {/* Supported Formats */}
          <Paper sx={{ p: 3, mt: 3, borderRadius: 3 }}>
            <Typography variant="subtitle2" fontWeight={600} gutterBottom>
              Supported Formats
            </Typography>
            <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
              <Typography variant="caption" color="text.secondary">
                • CSV files with die coordinates
              </Typography>
              <Typography variant="caption" color="text.secondary">
                • XML format (KLARF standard)
              </Typography>
              <Typography variant="caption" color="text.secondary">
                • Binary format (.bin)
              </Typography>
              <Typography variant="caption" color="text.secondary">
                • Maximum file size: 50MB
              </Typography>
              <Typography variant="caption" color="text.secondary">
                • Batch upload supported
              </Typography>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default IngestWafers;
