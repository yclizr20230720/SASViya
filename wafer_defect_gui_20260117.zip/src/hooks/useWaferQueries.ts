import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { waferService } from '../services/waferService';
import type {
  WaferMapUploadRequest,
  PredictionRequest,
  FeedbackRequest,
} from '../types/api';

// Query keys
export const waferKeys = {
  all: ['wafers'] as const,
  lists: () => [...waferKeys.all, 'list'] as const,
  list: (page: number, pageSize: number) => [...waferKeys.lists(), { page, pageSize }] as const,
  details: () => [...waferKeys.all, 'detail'] as const,
  detail: (id: string) => [...waferKeys.details(), id] as const,
  predictions: () => [...waferKeys.all, 'predictions'] as const,
  prediction: (id: string) => [...waferKeys.predictions(), id] as const,
  analytics: () => [...waferKeys.all, 'analytics'] as const,
  similar: (id: string) => [...waferKeys.all, 'similar', id] as const,
};

// Get wafer maps list
export const useWaferMaps = (page = 1, pageSize = 20) => {
  return useQuery({
    queryKey: waferKeys.list(page, pageSize),
    queryFn: () => waferService.getWaferMaps(page, pageSize),
  });
};

// Get single wafer map
export const useWaferMap = (id: string) => {
  return useQuery({
    queryKey: waferKeys.detail(id),
    queryFn: () => waferService.getWaferMap(id),
    enabled: !!id,
  });
};

// Upload wafer map mutation
export const useUploadWaferMap = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: WaferMapUploadRequest) => waferService.uploadWaferMap(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: waferKeys.lists() });
    },
  });
};

// Delete wafer map mutation
export const useDeleteWaferMap = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => waferService.deleteWaferMap(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: waferKeys.lists() });
    },
  });
};

// Get prediction
export const usePrediction = (waferId: string, explain = false) => {
  return useQuery({
    queryKey: waferKeys.prediction(waferId),
    queryFn: () => waferService.getPrediction({ waferId, explain }),
    enabled: !!waferId,
  });
};

// Create prediction mutation
export const useCreatePrediction = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (request: PredictionRequest) => waferService.getPrediction(request),
    onSuccess: (data) => {
      queryClient.setQueryData(waferKeys.prediction(data.waferId), data);
    },
  });
};

// Submit feedback mutation
export const useSubmitFeedback = () => {
  return useMutation({
    mutationFn: (feedback: FeedbackRequest) => waferService.submitFeedback(feedback),
  });
};

// Get analytics
export const useAnalytics = (startDate?: string, endDate?: string) => {
  return useQuery({
    queryKey: [...waferKeys.analytics(), { startDate, endDate }],
    queryFn: () => waferService.getAnalytics(startDate, endDate),
  });
};

// Get similar cases
export const useSimilarCases = (waferId: string, topK = 5) => {
  return useQuery({
    queryKey: waferKeys.similar(waferId),
    queryFn: () => waferService.getSimilarCases(waferId, topK),
    enabled: !!waferId,
  });
};
