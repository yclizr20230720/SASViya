import {
  Card,
  CardContent,
  Box,
  Typography,
  Chip,
  Divider,
  Grid,
} from '@mui/material';

import {
  CheckCircle,
  Warning,
  Speed,
  Schedule,
} from '@mui/icons-material';
import ConfidenceGauge from './ConfidenceGauge';

interface PredictionSummaryCardProps {
  patternClass: string;
  patternConfidence: number;
  rootCauseClass: string;
  rootCauseConfidence: number;
  processingTimeMs: number;
  timestamp: string;
}

export default function PredictionSummaryCard({
  patternClass,
  patternConfidence,
  rootCauseClass,
  rootCauseConfidence,
  processingTimeMs,
  timestamp,
}: PredictionSummaryCardProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <Card sx={{ height: '100%' }}>
      <CardContent>
        <Typography variant="h5" gutterBottom sx={{ fontWeight: 600 }}>
          Prediction Summary
        </Typography>

        <Grid container spacing={3} sx={{ mt: 1 }}>
          {/* Pattern Classification */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Box sx={{ textAlign: 'center' }}>
              <CheckCircle
                sx={{ fontSize: 48, color: 'success.main', mb: 1 }}
              />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>
                {patternClass}
              </Typography>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Detected Pattern Type
              </Typography>
              <ConfidenceGauge
                value={patternConfidence}
                label="Pattern Confidence"
                size={180}
              />
            </Box>
          </Grid>

          {/* Root Cause */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Box sx={{ textAlign: 'center' }}>
              <Warning
                sx={{ fontSize: 48, color: 'warning.main', mb: 1 }}
              />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>
                {rootCauseClass}
              </Typography>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Probable Root Cause
              </Typography>
              <ConfidenceGauge
                value={rootCauseConfidence}
                label="Root Cause Confidence"
                size={180}
              />
            </Box>
          </Grid>
        </Grid>

        <Divider sx={{ my: 3 }} />

        {/* Metadata */}
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, sm: 6 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Speed color="primary" />
              <Box>
                <Typography variant="body2" color="text.secondary">
                  Processing Time
                </Typography>
                <Typography variant="body1" fontWeight={600}>
                  {processingTimeMs}ms
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Schedule color="primary" />
              <Box>
                <Typography variant="body2" color="text.secondary">
                  Analysis Time
                </Typography>
                <Typography variant="body1" fontWeight={600}>
                  {formatDate(timestamp)}
                </Typography>
              </Box>
            </Box>
          </Grid>
        </Grid>

        {/* Status Chips */}
        <Box sx={{ display: 'flex', gap: 1, mt: 3, flexWrap: 'wrap' }}>
          <Chip
            label={patternConfidence >= 0.9 ? 'High Confidence' : 'Review Recommended'}
            color={patternConfidence >= 0.9 ? 'success' : 'warning'}
            size="small"
          />
          <Chip
            label={processingTimeMs < 5000 ? 'Fast Processing' : 'Standard Processing'}
            color={processingTimeMs < 5000 ? 'success' : 'default'}
            size="small"
          />
        </Box>
      </CardContent>
    </Card>
  );
}
