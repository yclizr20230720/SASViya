import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  SpeedDial,
  SpeedDialAction,
  SpeedDialIcon,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  List,
  ListItem,
  ListItemText,
  Typography,
  Chip,
} from '@mui/material';
import {
  CloudUpload,
  Assessment,
  Analytics,
  Dashboard as DashboardIcon,
  Keyboard,
} from '@mui/icons-material';
import { useKeyboardShortcuts, formatShortcut } from '../hooks/useKeyboardShortcuts';

interface QuickActionsProps {
  variant?: 'buttons' | 'speedDial';
}

export default function QuickActions({ variant = 'buttons' }: QuickActionsProps) {
  const navigate = useNavigate();
  const { shortcuts } = useKeyboardShortcuts();
  const [shortcutsDialogOpen, setShortcutsDialogOpen] = useState(false);

  const actions = [
    {
      icon: <CloudUpload />,
      name: 'Upload Wafer Map',
      path: '/upload',
      shortcut: 'Ctrl + U',
    },
    {
      icon: <Assessment />,
      name: 'View Reports',
      path: '/history',
      shortcut: 'Ctrl + H',
    },
    {
      icon: <Analytics />,
      name: 'Analysis',
      path: '/analysis',
      shortcut: 'Ctrl + A',
    },
    {
      icon: <DashboardIcon />,
      name: 'Dashboard',
      path: '/dashboard',
      shortcut: 'Ctrl + D',
    },
  ];

  if (variant === 'speedDial') {
    return (
      <>
        <SpeedDial
          ariaLabel="Quick actions"
          sx={{ position: 'fixed', bottom: 24, right: 24 }}
          icon={<SpeedDialIcon />}
        >
          {actions.map((action) => (
            <SpeedDialAction
              key={action.name}
              icon={action.icon}
              tooltipTitle={
                <Box>
                  <Typography variant="body2">{action.name}</Typography>
                  <Typography variant="caption" color="text.secondary">
                    {action.shortcut}
                  </Typography>
                </Box>
              }
              onClick={() => navigate(action.path)}
            />
          ))}
          <SpeedDialAction
            icon={<Keyboard />}
            tooltipTitle="Keyboard Shortcuts"
            onClick={() => setShortcutsDialogOpen(true)}
          />
        </SpeedDial>

        <Dialog
          open={shortcutsDialogOpen}
          onClose={() => setShortcutsDialogOpen(false)}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>Keyboard Shortcuts</DialogTitle>
          <DialogContent>
            <List>
              {shortcuts.map((shortcut, index) => (
                <ListItem key={index}>
                  <ListItemText
                    primary={shortcut.description}
                    secondary={
                      <Chip
                        label={formatShortcut(shortcut)}
                        size="small"
                        sx={{ mt: 0.5 }}
                      />
                    }
                  />
                </ListItem>
              ))}
            </List>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return (
    <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
      <Button
        variant="contained"
        startIcon={<CloudUpload />}
        onClick={() => navigate('/upload')}
      >
        Upload Wafer Map
      </Button>
      <Button
        variant="outlined"
        startIcon={<Assessment />}
        onClick={() => navigate('/history')}
      >
        View Reports
      </Button>
      <Tooltip title="Keyboard Shortcuts (Ctrl+D, Ctrl+U, Ctrl+H, etc.)">
        <Button
          variant="text"
          startIcon={<Keyboard />}
          onClick={() => setShortcutsDialogOpen(true)}
          sx={{ minWidth: 'auto', px: 1 }}
        >
          Shortcuts
        </Button>
      </Tooltip>

      <Dialog
        open={shortcutsDialogOpen}
        onClose={() => setShortcutsDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Keyboard Shortcuts</DialogTitle>
        <DialogContent>
          <List>
            {shortcuts.map((shortcut, index) => (
              <ListItem key={index}>
                <ListItemText
                  primary={shortcut.description}
                  secondary={
                    <Chip
                      label={formatShortcut(shortcut)}
                      size="small"
                      sx={{ mt: 0.5 }}
                    />
                  }
                />
              </ListItem>
            ))}
          </List>
        </DialogContent>
      </Dialog>
    </Box>
  );
}
