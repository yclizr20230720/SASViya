import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  List,
  IconButton,
  Chip,
} from '@mui/material';
import {
  Link as LinkIcon,
  Share as ShareIcon,
  Delete as DeleteIcon,
  Visibility as VisibilityIcon,
} from '@mui/icons-material';
import type { GeneratedReport } from '../types/report';

export interface ReportExportProps {
  reports: GeneratedReport[];
  onExportPdf: (reportId: string, options: any) => Promise<void>;
  onExportPptx: (reportId: string, options: any) => Promise<void>;
  onGenerateLink: (reportId: string) => Promise<string>;
  onDeleteReport: (reportId: string) => void;
  onViewReport?: (reportId: string) => void;
}

const ReportExport: React.FC<ReportExportProps> = ({
  reports,
  onGenerateLink,
  onDeleteReport,
  onViewReport,
}) => {
  const [shareLink, setShareLink] = useState<string | null>(null);

  const handleGenerateLink = async (report: GeneratedReport) => {
    try {
      const link = await onGenerateLink(report.id);
      setShareLink(link);
    } catch (error) {
      console.error('Link generation failed:', error);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('✅ Link copied to clipboard!');
  };

  return (
    <Box>
      <Typography variant="h5" fontWeight={600} mb={3}>
        Generated Reports
      </Typography>

      <List>
        {reports.map((report) => (
          <Card key={report.id} sx={{ mb: 2 }}>
            <CardContent>
              <Box display="flex" justifyContent="space-between" alignItems="start">
                <Box flex={1}>
                  <Typography variant="h6" gutterBottom>
                    {report.name}
                  </Typography>
                  <Box display="flex" gap={1} mb={1}>
                    <Chip
                      label={report.format.toUpperCase()}
                      size="small"
                      color="primary"
                    />
                    <Chip
                      label={new Date(report.generatedAt).toLocaleString()}
                      size="small"
                      variant="outlined"
                    />
                    <Chip
                      label={`By: ${report.generatedBy}`}
                      size="small"
                      variant="outlined"
                    />
                  </Box>
                  {report.data && Object.keys(report.data).length > 0 && (
                    <Box mt={1}>
                      <Typography variant="caption" color="text.secondary" display="block">
                        Report Data Summary:
                      </Typography>
                      <Box display="flex" flexWrap="wrap" gap={1} mt={0.5}>
                        {Object.entries(report.data).slice(0, 4).map(([key, value]) => (
                          <Chip
                            key={key}
                            label={`${key}: ${typeof value === 'object' ? 'Multiple' : value}`}
                            size="small"
                            variant="outlined"
                            sx={{ fontSize: '0.7rem' }}
                          />
                        ))}
                      </Box>
                    </Box>
                  )}
                </Box>
                <Box display="flex" gap={1}>
                  {onViewReport && (
                    <IconButton
                      size="small"
                      onClick={() => onViewReport(report.id)}
                      title="View Report"
                      color="primary"
                    >
                      <VisibilityIcon fontSize="small" />
                    </IconButton>
                  )}
                  <IconButton
                    size="small"
                    onClick={() => handleGenerateLink(report)}
                    title="Generate shareable link"
                  >
                    <ShareIcon fontSize="small" />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => {
                      if (window.confirm(`Are you sure you want to delete "${report.name}"?`)) {
                        onDeleteReport(report.id);
                      }
                    }}
                    title="Delete"
                    color="error"
                  >
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Box>
              </Box>
            </CardContent>
          </Card>
        ))}
      </List>

      {reports.length === 0 && (
        <Card>
          <CardContent>
            <Box textAlign="center" py={4}>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                No generated reports
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Generate reports from templates to see them here
              </Typography>
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Share Link Dialog */}
      <Dialog open={!!shareLink} onClose={() => setShareLink(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Shareable Link</DialogTitle>
        <DialogContent>
          <Typography variant="body2" gutterBottom sx={{ mt: 2 }}>
            Share this link with others to give them access to the report:
          </Typography>
          <Box display="flex" gap={1} mt={2}>
            <TextField
              fullWidth
              value={shareLink || ''}
              slotProps={{ input: { readOnly: true } }}
            />
            <Button
              variant="contained"
              startIcon={<LinkIcon />}
              onClick={() => copyToClipboard(shareLink || '')}
            >
              Copy
            </Button>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShareLink(null)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ReportExport;
