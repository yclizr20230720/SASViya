/**
 * Training Wafer Canvas Component
 * Canvas-based wafer visualization for training data with MUI styling
 * Displays individual dies, defects, annotations, and optional heatmap overlay
 */

import React, { useEffect, useRef, useState } from 'react';
import {
  Box,
  Paper,
  Tooltip,
  Typography,
  Slider,
  FormControlLabel,
  Switch,
  useTheme
} from '@mui/material';
import type { WaferData, Die, Annotation } from '../../types/training';
import { PATTERN_COLORS } from '../../constants/training';

interface TrainingWaferCanvasProps {
  /** Wafer data to visualize */
  wafer: WaferData;
  /** Canvas size in pixels */
  size?: number;
  /** Callback when mouse hovers over a die */
  onDieHover?: (die: Die | null) => void;
  /** Callback when a die is clicked */
  onDieClick?: (die: Die) => void;
  /** Whether to show heatmap overlay */
  showHeatmap?: boolean;
  /** Heatmap intensity (0-1) */
  heatmapIntensity?: number;
  /** Whether to show controls */
  showControls?: boolean;
}

/**
 * Training Wafer Canvas Component
 * Renders wafer map with dies, defects, and annotations using HTML5 Canvas
 */
const TrainingWaferCanvas: React.FC<TrainingWaferCanvasProps> = ({
  wafer,
  size = 400,
  onDieHover,
  onDieClick,
  showHeatmap: initialShowHeatmap = false,
  heatmapIntensity: initialHeatmapIntensity = 0.5,
  showControls = true
}) => {
  const theme = useTheme();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hoveredDie, setHoveredDie] = useState<Die | null>(null);
  const [showHeatmap, setShowHeatmap] = useState(initialShowHeatmap);
  const [heatmapIntensity, setHeatmapIntensity] = useState(initialHeatmapIntensity);

  // Draw wafer map on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, size, size);

    const padding = 10;
    const drawSize = size - padding * 2;
    const cellSize = drawSize / wafer.gridSize;
    const centerX = size / 2;
    const centerY = size / 2;
    const radius = drawSize / 2;

    // Draw wafer boundary circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.strokeStyle = theme.palette.divider;
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = theme.palette.background.paper;
    ctx.fill();

    // Draw wafer notch (orientation marker)
    ctx.beginPath();
    ctx.arc(centerX, centerY - radius, 8, 0, Math.PI);
    ctx.fillStyle = theme.palette.text.secondary;
    ctx.fill();

    // Draw heatmap overlay if enabled
    if (showHeatmap) {
      const gradient = ctx.createRadialGradient(
        centerX,
        centerY,
        0,
        centerX,
        centerY,
        radius
      );
      
      // Use pattern color if available, otherwise use error color
      const patternColor = wafer.detectedPattern 
        ? PATTERN_COLORS[wafer.detectedPattern]
        : theme.palette.error.main;
      
      gradient.addColorStop(0, `${patternColor}${Math.round(heatmapIntensity * 102).toString(16).padStart(2, '0')}`);
      gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, size, size);
    }

    // Draw dies
    wafer.dies.forEach(die => {
      const px = padding + die.x * cellSize;
      const py = padding + die.y * cellSize;

      // Check if die is within wafer boundary
      const dieCenterX = px + cellSize / 2;
      const dieCenterY = py + cellSize / 2;
      const distFromCenter = Math.sqrt(
        Math.pow(dieCenterX - centerX, 2) + Math.pow(dieCenterY - centerY, 2)
      );

      if (distFromCenter <= radius - cellSize / 2) {
        // Determine die color
        if (die.status === 'Defect') {
          // Use pattern color for defects if available
          const patternColor = wafer.detectedPattern
            ? PATTERN_COLORS[wafer.detectedPattern]
            : theme.palette.error.main;
          ctx.fillStyle = patternColor;
        } else {
          ctx.fillStyle = theme.palette.grey[200];
        }

        // Draw die
        ctx.fillRect(px, py, cellSize - 0.5, cellSize - 0.5);

        // Highlight hovered die
        if (hoveredDie && hoveredDie.x === die.x && hoveredDie.y === die.y) {
          ctx.strokeStyle = theme.palette.primary.main;
          ctx.lineWidth = 2;
          ctx.strokeRect(px, py, cellSize - 0.5, cellSize - 0.5);
        }
      }
    });

    // Draw annotations
    if (wafer.annotations && wafer.annotations.length > 0) {
      wafer.annotations.forEach((ann: Annotation) => {
        const px = padding + ann.x * cellSize + cellSize / 2;
        const py = padding + ann.y * cellSize + cellSize / 2;

        // Draw annotation circle
        ctx.beginPath();
        ctx.arc(px, py, cellSize * 1.5, 0, Math.PI * 2);
        
        // Color based on annotation type
        const annotationColor = ann.type === 'Critical'
          ? theme.palette.error.main
          : ann.type === 'Investigation'
          ? theme.palette.warning.main
          : theme.palette.info.main;
        
        ctx.strokeStyle = annotationColor;
        ctx.lineWidth = 2;
        ctx.setLineDash([4, 4]);
        ctx.stroke();
        ctx.setLineDash([]);

        // Draw annotation label
        ctx.fillStyle = annotationColor;
        ctx.font = `bold ${Math.max(10, cellSize * 0.8)}px ${theme.typography.fontFamily}`;
        ctx.fillText(ann.label, px + cellSize, py - cellSize);
      });
    }
  }, [wafer, size, showHeatmap, heatmapIntensity, hoveredDie, theme]);

  // Handle mouse movement for die hover
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const padding = 10;
    const drawSize = size - padding * 2;
    const cellSize = drawSize / wafer.gridSize;

    const dieX = Math.floor((x - padding) / cellSize);
    const dieY = Math.floor((y - padding) / cellSize);

    const die = wafer.dies.find(d => d.x === dieX && d.y === dieY);
    
    setHoveredDie(die || null);
    
    if (onDieHover) {
      onDieHover(die || null);
    }
  };

  // Handle die click
  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!onDieClick) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const padding = 10;
    const drawSize = size - padding * 2;
    const cellSize = drawSize / wafer.gridSize;

    const dieX = Math.floor((x - padding) / cellSize);
    const dieY = Math.floor((y - padding) / cellSize);

    const die = wafer.dies.find(d => d.x === dieX && d.y === dieY);
    
    if (die) {
      onDieClick(die);
    }
  };

  // Handle mouse leave
  const handleMouseLeave = () => {
    setHoveredDie(null);
    if (onDieHover) {
      onDieHover(null);
    }
  };

  return (
    <Paper
      elevation={2}
      sx={{
        p: 2,
        display: 'inline-block',
        borderRadius: 2
      }}
    >
      {/* Controls */}
      {showControls && (
        <Box sx={{ mb: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
          <FormControlLabel
            control={
              <Switch
                checked={showHeatmap}
                onChange={(e) => setShowHeatmap(e.target.checked)}
                size="small"
              />
            }
            label={
              <Typography variant="body2">
                Show Heatmap
              </Typography>
            }
          />
          
          {showHeatmap && (
            <Box sx={{ px: 1 }}>
              <Typography variant="caption" color="text.secondary" gutterBottom>
                Heatmap Intensity
              </Typography>
              <Slider
                value={heatmapIntensity}
                onChange={(_, value) => setHeatmapIntensity(value as number)}
                min={0}
                max={1}
                step={0.1}
                size="small"
                valueLabelDisplay="auto"
                valueLabelFormat={(value) => `${Math.round(value * 100)}%`}
              />
            </Box>
          )}
        </Box>
      )}

      {/* Canvas */}
      <Tooltip
        title={
          hoveredDie ? (
            <Box>
              <Typography variant="caption" display="block">
                <strong>Position:</strong> ({hoveredDie.x}, {hoveredDie.y})
              </Typography>
              <Typography variant="caption" display="block">
                <strong>Status:</strong> {hoveredDie.status}
              </Typography>
              {hoveredDie.binCode !== undefined && (
                <Typography variant="caption" display="block">
                  <strong>Bin Code:</strong> {hoveredDie.binCode}
                </Typography>
              )}
            </Box>
          ) : ''
        }
        followCursor
        arrow
      >
        <Box
          sx={{
            position: 'relative',
            display: 'inline-block',
            cursor: 'crosshair',
            borderRadius: '50%',
            overflow: 'hidden',
            boxShadow: theme.shadows[1]
          }}
        >
          <canvas
            ref={canvasRef}
            width={size}
            height={size}
            onMouseMove={handleMouseMove}
            onClick={handleClick}
            onMouseLeave={handleMouseLeave}
            style={{
              display: 'block',
              borderRadius: '50%'
            }}
          />
        </Box>
      </Tooltip>

      {/* Wafer Info */}
      <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 0.5 }}>
        <Typography variant="caption" color="text.secondary">
          <strong>Wafer ID:</strong> {wafer.id}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          <strong>Lot ID:</strong> {wafer.lotId}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          <strong>Grid Size:</strong> {wafer.gridSize}x{wafer.gridSize}
        </Typography>
        {wafer.detectedPattern && (
          <Typography variant="caption" color="text.secondary">
            <strong>Pattern:</strong> {wafer.detectedPattern}
            {wafer.confidence && ` (${(wafer.confidence * 100).toFixed(1)}%)`}
          </Typography>
        )}
      </Box>
    </Paper>
  );
};

export default TrainingWaferCanvas;
