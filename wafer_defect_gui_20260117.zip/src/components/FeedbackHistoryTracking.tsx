import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Tooltip,
  TextField,
  InputAdornment,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  LinearProgress,
  Alert,
  Stack,
} from '@mui/material';
import {
  Search,
  Visibility,
  TrendingUp,
  CheckCircle,
  HourglassEmpty,
  RateReview,
} from '@mui/icons-material';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

export interface FeedbackRecord {
  id: string;
  waferId: string;
  submittedBy: string;
  submittedAt: string;
  rating: number;
  predictedPattern: string;
  correctPattern: string;
  predictedRootCause: string;
  correctRootCause: string;
  status: 'submitted' | 'reviewed' | 'incorporated';
  reviewedBy?: string;
  reviewedAt?: string;
  modelVersion?: string;
  impactScore?: number;
}

interface FeedbackHistoryTrackingProps {
  feedbackRecords?: FeedbackRecord[];
}

const mockFeedbackRecords: FeedbackRecord[] = [
  {
    id: 'fb-001',
    waferId: 'W2026-001-01',
    submittedBy: 'John Doe',
    submittedAt: '2026-01-17T08:45:00Z',
    rating: 4,
    predictedPattern: 'Edge Defect',
    correctPattern: 'Edge Defect',
    predictedRootCause: 'Edge Exclusion Issue',
    correctRootCause: 'Edge Exclusion Issue',
    status: 'incorporated',
    reviewedBy: 'Jane Smith',
    reviewedAt: '2026-01-17T10:30:00Z',
    modelVersion: 'v2.4',
    impactScore: 0.85,
  },
  {
    id: 'fb-002',
    waferId: 'W2026-001-02',
    submittedBy: 'Alice Johnson',
    submittedAt: '2026-01-17T09:20:00Z',
    rating: 3,
    predictedPattern: 'Center Defect',
    correctPattern: 'Ring Pattern',
    predictedRootCause: 'Process Drift',
    correctRootCause: 'CMP Non-Uniformity',
    status: 'reviewed',
    reviewedBy: 'Jane Smith',
    reviewedAt: '2026-01-17T11:00:00Z',
    impactScore: 0.92,
  },
  {
    id: 'fb-003',
    waferId: 'W2026-001-03',
    submittedBy: 'Bob Wilson',
    submittedAt: '2026-01-17T10:15:00Z',
    rating: 5,
    predictedPattern: 'Scratch Pattern',
    correctPattern: 'Scratch Pattern',
    predictedRootCause: 'Mechanical Damage',
    correctRootCause: 'Mechanical Damage',
    status: 'submitted',
    impactScore: 0.78,
  },
  {
    id: 'fb-004',
    waferId: 'W2026-002-01',
    submittedBy: 'Carol Martinez',
    submittedAt: '2026-01-17T11:30:00Z',
    rating: 2,
    predictedPattern: 'Random Defects',
    correctPattern: 'Systematic Pattern',
    predictedRootCause: 'Contamination',
    correctRootCause: 'Equipment Malfunction',
    status: 'reviewed',
    reviewedBy: 'Jane Smith',
    reviewedAt: '2026-01-17T12:15:00Z',
    impactScore: 0.95,
  },
  {
    id: 'fb-005',
    waferId: 'W2026-002-02',
    submittedBy: 'David Lee',
    submittedAt: '2026-01-17T12:00:00Z',
    rating: 4,
    predictedPattern: 'Ring Pattern',
    correctPattern: 'Ring Pattern',
    predictedRootCause: 'CMP Non-Uniformity',
    correctRootCause: 'Process Drift',
    status: 'submitted',
    impactScore: 0.88,
  },
];

const modelImprovementData = [
  { month: 'Sep', accuracy: 91.2, feedbackCount: 45 },
  { month: 'Oct', accuracy: 92.5, feedbackCount: 67 },
  { month: 'Nov', accuracy: 93.1, feedbackCount: 89 },
  { month: 'Dec', accuracy: 93.8, feedbackCount: 102 },
  { month: 'Jan', accuracy: 94.2, feedbackCount: 125 },
];

export default function FeedbackHistoryTracking({
  feedbackRecords = mockFeedbackRecords,
}: FeedbackHistoryTrackingProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'submitted':
        return 'default';
      case 'reviewed':
        return 'primary';
      case 'incorporated':
        return 'success';
      default:
        return 'default';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'submitted':
        return <HourglassEmpty fontSize="small" />;
      case 'reviewed':
        return <RateReview fontSize="small" />;
      case 'incorporated':
        return <CheckCircle fontSize="small" />;
      default:
        return null;
    }
  };

  const filteredRecords = feedbackRecords.filter((record) => {
    const matchesSearch =
      record.waferId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.submittedBy.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusCounts = {
    submitted: feedbackRecords.filter((r) => r.status === 'submitted').length,
    reviewed: feedbackRecords.filter((r) => r.status === 'reviewed').length,
    incorporated: feedbackRecords.filter((r) => r.status === 'incorporated').length,
  };

  const averageImpactScore =
    feedbackRecords.reduce((sum, r) => sum + (r.impactScore || 0), 0) / feedbackRecords.length;

  const correctionRate =
    (feedbackRecords.filter(
      (r) => r.predictedPattern !== r.correctPattern || r.predictedRootCause !== r.correctRootCause
    ).length /
      feedbackRecords.length) *
    100;

  return (
    <Box>
      {/* Summary Cards */}
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 2, mb: 3 }}>
        <Card>
          <CardContent>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Total Feedback
            </Typography>
            <Typography variant="h4" sx={{ fontWeight: 600 }}>
              {feedbackRecords.length}
            </Typography>
          </CardContent>
        </Card>
        <Card>
          <CardContent>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Incorporated
            </Typography>
            <Typography variant="h4" sx={{ fontWeight: 600, color: 'success.main' }}>
              {statusCounts.incorporated}
            </Typography>
          </CardContent>
        </Card>
        <Card>
          <CardContent>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Avg Impact Score
            </Typography>
            <Typography variant="h4" sx={{ fontWeight: 600 }}>
              {(averageImpactScore * 100).toFixed(1)}%
            </Typography>
          </CardContent>
        </Card>
        <Card>
          <CardContent>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Correction Rate
            </Typography>
            <Typography variant="h4" sx={{ fontWeight: 600, color: 'warning.main' }}>
              {correctionRate.toFixed(1)}%
            </Typography>
          </CardContent>
        </Card>
      </Box>

      {/* Model Improvement Visualization */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
            <TrendingUp color="primary" />
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              Model Improvement Impact
            </Typography>
          </Box>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Correlation between feedback submissions and model accuracy improvements
          </Typography>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={modelImprovementData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis yAxisId="left" domain={[90, 95]} />
              <YAxis yAxisId="right" orientation="right" />
              <RechartsTooltip />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="accuracy"
                stroke="#0066CC"
                strokeWidth={2}
                name="Model Accuracy (%)"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="feedbackCount"
                stroke="#00C853"
                strokeWidth={2}
                name="Feedback Count"
              />
            </LineChart>
          </ResponsiveContainer>
          <Alert severity="success" sx={{ mt: 2 }}>
            Model accuracy improved by 3.0% over the last 5 months thanks to {feedbackRecords.length} feedback submissions
          </Alert>
        </CardContent>
      </Card>

      {/* Feedback History Table */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
            Feedback History
          </Typography>

          {/* Filters */}
          <Stack direction="row" spacing={2} sx={{ mb: 2 }}>
            <TextField
              size="small"
              placeholder="Search by wafer ID or user..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search />
                  </InputAdornment>
                ),
              }}
              sx={{ flexGrow: 1 }}
            />
            <FormControl size="small" sx={{ minWidth: 150 }}>
              <InputLabel>Status</InputLabel>
              <Select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                label="Status"
              >
                <MenuItem value="all">All Status</MenuItem>
                <MenuItem value="submitted">Submitted</MenuItem>
                <MenuItem value="reviewed">Reviewed</MenuItem>
                <MenuItem value="incorporated">Incorporated</MenuItem>
              </Select>
            </FormControl>
          </Stack>

          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Wafer ID</TableCell>
                  <TableCell>Submitted By</TableCell>
                  <TableCell>Date</TableCell>
                  <TableCell>Rating</TableCell>
                  <TableCell>Pattern Correction</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Impact</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredRecords.map((record) => (
                  <TableRow key={record.id} hover>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {record.waferId}
                      </Typography>
                    </TableCell>
                    <TableCell>{record.submittedBy}</TableCell>
                    <TableCell>
                      {new Date(record.submittedAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={`${record.rating}/5`}
                        size="small"
                        color={record.rating >= 4 ? 'success' : record.rating >= 3 ? 'default' : 'error'}
                      />
                    </TableCell>
                    <TableCell>
                      {record.predictedPattern !== record.correctPattern ? (
                        <Tooltip title={`${record.predictedPattern} → ${record.correctPattern}`}>
                          <Chip label="Corrected" size="small" color="warning" />
                        </Tooltip>
                      ) : (
                        <Chip label="Confirmed" size="small" color="success" />
                      )}
                    </TableCell>
                    <TableCell>
                      <Chip
                        icon={getStatusIcon(record.status)}
                        label={record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                        size="small"
                        color={getStatusColor(record.status)}
                      />
                    </TableCell>
                    <TableCell>
                      {record.impactScore && (
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <LinearProgress
                            variant="determinate"
                            value={record.impactScore * 100}
                            sx={{ flexGrow: 1, height: 6, borderRadius: 3 }}
                          />
                          <Typography variant="caption">
                            {(record.impactScore * 100).toFixed(0)}%
                          </Typography>
                        </Box>
                      )}
                    </TableCell>
                    <TableCell>
                      <Tooltip title="View Details">
                        <IconButton size="small">
                          <Visibility fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          {filteredRecords.length === 0 && (
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <Typography variant="body2" color="text.secondary">
                No feedback records found
              </Typography>
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
