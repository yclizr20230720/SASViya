import {
  Box,
  Card,
  CardContent,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Chip,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Alert,
  Divider,
  List,
  ListItem,
  ListItemText,
} from '@mui/material';
import {
  ExpandMore,
  PriorityHigh,
  CheckCircle,
  TrendingUp,
  Lightbulb,
  Schedule,
  Person,
} from '@mui/icons-material';
import type { Recommendation } from '../utils/recommendationEngine';

interface RecommendationsPanelProps {
  recommendations: Recommendation[];
  overallHealth: 'excellent' | 'good' | 'fair' | 'poor';
  keyFindings: string[];
  topPriorities: string[];
}

export default function RecommendationsPanel({
  recommendations,
  overallHealth,
  keyFindings,
  topPriorities,
}: RecommendationsPanelProps) {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical':
        return 'error';
      case 'high':
        return 'warning';
      case 'medium':
        return 'info';
      case 'low':
        return 'success';
      default:
        return 'default';
    }
  };

  const getHealthColor = (health: string) => {
    switch (health) {
      case 'excellent':
        return 'success';
      case 'good':
        return 'info';
      case 'fair':
        return 'warning';
      case 'poor':
        return 'error';
      default:
        return 'default';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'immediate':
        return <PriorityHigh />;
      case 'preventive':
        return <CheckCircle />;
      case 'optimization':
        return <TrendingUp />;
      default:
        return <Lightbulb />;
    }
  };

  return (
    <Box>
      {/* Overall Health Status */}
      <Card sx={{ mb: 3, bgcolor: `${getHealthColor(overallHealth)}.light` }}>
        <CardContent>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
            <Typography variant="h5" sx={{ fontWeight: 600 }}>
              System Health Status
            </Typography>
            <Chip
              label={overallHealth.toUpperCase()}
              color={getHealthColor(overallHealth) as any}
              sx={{ fontWeight: 600 }}
            />
          </Box>

          {/* Key Findings */}
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, mt: 2 }}>
            Key Findings:
          </Typography>
          <List dense>
            {keyFindings.map((finding, index) => (
              <ListItem key={index}>
                <ListItemText primary={`• ${finding}`} />
              </ListItem>
            ))}
          </List>

          {/* Top Priorities */}
          {topPriorities.length > 0 && (
            <>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, mt: 2 }}>
                Top Priorities:
              </Typography>
              <List dense>
                {topPriorities.map((priority, index) => (
                  <ListItem key={index}>
                    <ListItemText
                      primary={`${index + 1}. ${priority}`}
                      primaryTypographyProps={{ fontWeight: 600, color: 'error.main' }}
                    />
                  </ListItem>
                ))}
              </List>
            </>
          )}
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Typography variant="h6" gutterBottom sx={{ fontWeight: 600, mb: 2 }}>
        Actionable Recommendations ({recommendations.length})
      </Typography>

      {recommendations.length === 0 ? (
        <Alert severity="success" icon={<CheckCircle />}>
          <Typography variant="body2" sx={{ fontWeight: 600 }}>
            All metrics are within acceptable ranges!
          </Typography>
          <Typography variant="caption">
            Continue monitoring for any changes and maintain current best practices.
          </Typography>
        </Alert>
      ) : (
        recommendations.map((recommendation, index) => (
          <Accordion key={index} defaultExpanded={index === 0}>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
                {getCategoryIcon(recommendation.category)}
                <Box sx={{ flex: 1 }}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                    {recommendation.title}
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 1, mt: 0.5 }}>
                    <Chip
                      label={recommendation.priority}
                      size="small"
                      color={getPriorityColor(recommendation.priority) as any}
                      sx={{ textTransform: 'capitalize' }}
                    />
                    <Chip
                      label={recommendation.category}
                      size="small"
                      variant="outlined"
                      sx={{ textTransform: 'capitalize' }}
                    />
                  </Box>
                </Box>
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              {/* Description */}
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                {recommendation.description}
              </Typography>

              <Divider sx={{ my: 2 }} />

              {/* Action Plan */}
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600, mb: 2 }}>
                Action Plan:
              </Typography>
              <Stepper orientation="vertical">
                {recommendation.actions.map((action, actionIndex) => (
                  <Step key={actionIndex} active>
                    <StepLabel>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        Step {action.step}: {action.action}
                      </Typography>
                    </StepLabel>
                    <StepContent>
                      <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', mt: 1 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <Person fontSize="small" color="action" />
                          <Typography variant="caption" color="text.secondary">
                            {action.owner}
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          <Schedule fontSize="small" color="action" />
                          <Typography variant="caption" color="text.secondary">
                            {action.estimatedTime}
                          </Typography>
                        </Box>
                      </Box>
                    </StepContent>
                  </Step>
                ))}
              </Stepper>

              <Divider sx={{ my: 2 }} />

              {/* Expected Impact */}
              <Alert severity="info" icon={<TrendingUp />} sx={{ mb: 2 }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                  Expected Impact:
                </Typography>
                <Typography variant="body2">{recommendation.expectedImpact}</Typography>
              </Alert>

              {/* Related Metrics */}
              <Box sx={{ mb: 2 }}>
                <Typography variant="caption" color="text.secondary" display="block" gutterBottom>
                  Related Metrics:
                </Typography>
                <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                  {recommendation.relatedMetrics.map((metric) => (
                    <Chip key={metric} label={metric} size="small" variant="outlined" />
                  ))}
                </Box>
              </Box>

              {/* References */}
              {recommendation.references && recommendation.references.length > 0 && (
                <Box>
                  <Typography variant="caption" color="text.secondary" display="block" gutterBottom>
                    References:
                  </Typography>
                  {recommendation.references.map((ref, refIndex) => (
                    <Typography key={refIndex} variant="caption" display="block" sx={{ ml: 1 }}>
                      • {ref}
                    </Typography>
                  ))}
                </Box>
              )}
            </AccordionDetails>
          </Accordion>
        ))
      )}
    </Box>
  );
}
