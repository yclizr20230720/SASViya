import { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Checkbox,
  FormControlLabel,
  FormGroup,
  Chip,
  Divider,
  Collapse,
  IconButton,
  Stack,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
} from '@mui/icons-material';

export interface FacetOption {
  value: string;
  label: string;
  count: number;
}

export interface Facet {
  id: string;
  name: string;
  options: FacetOption[];
}

export interface FacetedSearchProps {
  facets: Facet[];
  selectedFacets: Record<string, string[]>;
  onFacetChange: (facetId: string, values: string[]) => void;
  onClearAll?: () => void;
}

const FacetedSearch: React.FC<FacetedSearchProps> = ({
  facets,
  selectedFacets,
  onFacetChange,
  onClearAll,
}) => {
  const [expandedFacets, setExpandedFacets] = useState<Record<string, boolean>>({});

  // Initialize all facets as expanded
  useEffect(() => {
    const initialExpanded: Record<string, boolean> = {};
    facets.forEach((facet) => {
      initialExpanded[facet.id] = true;
    });
    setExpandedFacets(initialExpanded);
  }, [facets]);

  // Toggle facet expansion
  const toggleFacet = (facetId: string) => {
    setExpandedFacets((prev) => ({
      ...prev,
      [facetId]: !prev[facetId],
    }));
  };

  // Handle facet option selection
  const handleFacetOptionChange = (facetId: string, value: string, checked: boolean) => {
    const currentValues = selectedFacets[facetId] || [];
    const newValues = checked
      ? [...currentValues, value]
      : currentValues.filter((v) => v !== value);
    
    onFacetChange(facetId, newValues);
  };

  // Get total selected count
  const getTotalSelectedCount = () => {
    return Object.values(selectedFacets).reduce((sum, values) => sum + values.length, 0);
  };

  // Get selected count for a facet
  const getSelectedCount = (facetId: string) => {
    return (selectedFacets[facetId] || []).length;
  };

  return (
    <Box>
      {/* Header with clear all */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={1.5}>
        <Typography variant="subtitle1" fontWeight={600}>
          Filters
          {getTotalSelectedCount() > 0 && (
            <Chip
              label={getTotalSelectedCount()}
              size="small"
              color="primary"
              sx={{ ml: 1 }}
            />
          )}
        </Typography>
        {getTotalSelectedCount() > 0 && (
          <Typography
            variant="caption"
            color="primary"
            sx={{ cursor: 'pointer', textDecoration: 'underline' }}
            onClick={onClearAll}
          >
            Clear
          </Typography>
        )}
      </Box>

      {/* Active Filters */}
      {getTotalSelectedCount() > 0 && (
        <Box mb={1.5}>
          <Stack direction="row" flexWrap="wrap" gap={0.5}>
            {Object.entries(selectedFacets).map(([facetId, values]) =>
              values.map((value) => {
                const facet = facets.find((f) => f.id === facetId);
                const option = facet?.options.find((o) => o.value === value);
                return (
                  <Chip
                    key={`${facetId}-${value}`}
                    label={option?.label || value}
                    size="small"
                    onDelete={() => handleFacetOptionChange(facetId, value, false)}
                  />
                );
              })
            )}
          </Stack>
          <Divider sx={{ mt: 1.5 }} />
        </Box>
      )}

      {/* Facet Panels */}
      <Stack spacing={1.5}>
        {facets.map((facet) => (
          <Card key={facet.id} variant="outlined" sx={{ boxShadow: 'none' }}>
            <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
              {/* Facet Header */}
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                sx={{ cursor: 'pointer' }}
                onClick={() => toggleFacet(facet.id)}
              >
                <Box display="flex" alignItems="center" gap={0.5}>
                  <Typography variant="body2" fontWeight={600}>
                    {facet.name}
                  </Typography>
                  {getSelectedCount(facet.id) > 0 && (
                    <Chip size="small" label={getSelectedCount(facet.id)} color="primary" sx={{ height: 18, fontSize: '0.7rem' }} />
                  )}
                </Box>
                <IconButton size="small">
                  {expandedFacets[facet.id] ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
                </IconButton>
              </Box>

              {/* Facet Options */}
              <Collapse in={expandedFacets[facet.id]}>
                <FormGroup sx={{ mt: 0.5 }}>
                  {facet.options.map((option) => (
                    <FormControlLabel
                      key={option.value}
                      control={
                        <Checkbox
                          checked={(selectedFacets[facet.id] || []).includes(option.value)}
                          onChange={(e) =>
                            handleFacetOptionChange(facet.id, option.value, e.target.checked)
                          }
                          size="small"
                        />
                      }
                      label={
                        <Box display="flex" justifyContent="space-between" width="100%">
                          <Typography variant="caption">{option.label}</Typography>
                          <Typography variant="caption" color="text.secondary">
                            ({option.count})
                          </Typography>
                        </Box>
                      }
                      sx={{ width: '100%', ml: 0, mr: 0 }}
                    />
                  ))}
                </FormGroup>
              </Collapse>
            </CardContent>
          </Card>
        ))}
      </Stack>
    </Box>
  );
};

export default FacetedSearch;
