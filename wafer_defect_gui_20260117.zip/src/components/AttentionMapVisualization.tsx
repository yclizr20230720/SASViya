import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  Slider,
  FormControlLabel,
  Switch,
} from '@mui/material';
import { Layers } from '@mui/icons-material';

interface AttentionMapVisualizationProps {
  attentionLayers: {
    layerName: string;
    attentionWeights: number[][];
  }[];
  size?: number;
}

export default function AttentionMapVisualization({
  attentionLayers,
  size = 400,
}: AttentionMapVisualizationProps) {
  const [selectedLayer, setSelectedLayer] = useState(0);
  const [showAnimation, setShowAnimation] = useState(false);
  const [animationSpeed, setAnimationSpeed] = useState(1);

  const currentLayer = attentionLayers[selectedLayer];
  const gridSize = currentLayer.attentionWeights.length;
  const cellSize = size / gridSize;

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <Layers color="primary" />
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Attention Map Visualization
          </Typography>
        </Box>
        
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Model attention weights showing which regions influenced the prediction
        </Typography>

        {/* Layer Selection */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="body2" gutterBottom>
            Select Attention Layer:
          </Typography>
          <ToggleButtonGroup
            value={selectedLayer}
            exclusive
            onChange={(_, value) => value !== null && setSelectedLayer(value)}
            size="small"
            fullWidth
          >
            {attentionLayers.map((layer, index) => (
              <ToggleButton key={index} value={index}>
                {layer.layerName}
              </ToggleButton>
            ))}
          </ToggleButtonGroup>
        </Box>

        {/* Animation Controls */}
        <Box sx={{ mb: 2 }}>
          <FormControlLabel
            control={
              <Switch
                checked={showAnimation}
                onChange={(e) => setShowAnimation(e.target.checked)}
              />
            }
            label="Show Attention Flow Animation"
          />
          {showAnimation && (
            <Box sx={{ mt: 1 }}>
              <Typography variant="caption" gutterBottom>
                Animation Speed:
              </Typography>
              <Slider
                value={animationSpeed}
                onChange={(_, value) => setAnimationSpeed(value as number)}
                min={0.5}
                max={2}
                step={0.5}
                marks
                valueLabelDisplay="auto"
                size="small"
              />
            </Box>
          )}
        </Box>

        {/* Attention Map Canvas */}
        <Box
          sx={{
            border: 1,
            borderColor: 'divider',
            borderRadius: 1,
            overflow: 'hidden',
            position: 'relative',
          }}
        >
          <svg width={size} height={size}>
            {/* Background */}
            <rect width={size} height={size} fill="#f5f5f5" />
            
            {/* Attention Grid */}
            {currentLayer.attentionWeights.map((row, i) =>
              row.map((weight, j) => {
                const opacity = weight;
                const hue = 200; // Blue for attention
                return (
                  <rect
                    key={`${i}-${j}`}
                    x={j * cellSize}
                    y={i * cellSize}
                    width={cellSize}
                    height={cellSize}
                    fill={`hsla(${hue}, 80%, 50%, ${opacity})`}
                    stroke="#ddd"
                    strokeWidth={0.5}
                    className={showAnimation ? 'attention-pulse' : ''}
                    style={{
                      animation: showAnimation
                        ? `pulse ${2 / animationSpeed}s ease-in-out infinite`
                        : 'none',
                      animationDelay: `${(i + j) * 0.05}s`,
                    }}
                  />
                );
              })
            )}
          </svg>
        </Box>

        {/* Legend */}
        <Box sx={{ mt: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
          <Box
            sx={{
              width: 100,
              height: 20,
              background: 'linear-gradient(to right, hsla(200, 80%, 50%, 0), hsla(200, 80%, 50%, 1))',
              borderRadius: 0.5,
            }}
          />
          <Typography variant="caption">
            Low Attention → High Attention
          </Typography>
        </Box>

        {/* Layer Statistics */}
        <Box sx={{ mt: 2, p: 1, bgcolor: 'background.default', borderRadius: 1 }}>
          <Typography variant="caption" display="block">
            <strong>Layer:</strong> {currentLayer.layerName}
          </Typography>
          <Typography variant="caption" display="block">
            <strong>Max Attention:</strong>{' '}
            {Math.max(...currentLayer.attentionWeights.flat()).toFixed(3)}
          </Typography>
          <Typography variant="caption" display="block">
            <strong>Mean Attention:</strong>{' '}
            {(
              currentLayer.attentionWeights.flat().reduce((a, b) => a + b, 0) /
              currentLayer.attentionWeights.flat().length
            ).toFixed(3)}
          </Typography>
        </Box>
      </CardContent>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </Card>
  );
}
