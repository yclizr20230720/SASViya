import { useState, useEffect } from 'react';
import {
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Typography,
  Chip,
  Stack,
  Divider,
  Menu,
  MenuItem,
  Switch,
  FormControlLabel,
} from '@mui/material';
import {
  Bookmark as BookmarkIcon,
  BookmarkBorder as BookmarkBorderIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Share as ShareIcon,
  MoreVert as MoreVertIcon,
  Visibility as VisibilityIcon,
} from '@mui/icons-material';

export interface SavedView {
  id: string;
  name: string;
  description?: string;
  filters: Record<string, any>;
  sortOrder?: {
    field: string;
    direction: 'asc' | 'desc';
  };
  isShared: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}

export interface SavedViewsManagerProps {
  open: boolean;
  onClose: () => void;
  onLoadView: (view: SavedView) => void;
  onSaveView: (view: Omit<SavedView, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onDeleteView: (viewId: string) => void;
  onUpdateView: (viewId: string, updates: Partial<SavedView>) => void;
  savedViews: SavedView[];
  currentUserId: string;
}

const SavedViewsManager: React.FC<SavedViewsManagerProps> = ({
  open,
  onClose,
  onLoadView,
  onSaveView,
  onDeleteView,
  onUpdateView,
  savedViews,
  currentUserId,
}) => {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingView, setEditingView] = useState<SavedView | null>(null);
  const [viewName, setViewName] = useState('');
  const [viewDescription, setViewDescription] = useState('');
  const [isShared, setIsShared] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedView, setSelectedView] = useState<SavedView | null>(null);

  // Load saved views from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('savedViews');
    if (stored) {
      // Views are already managed by parent component
    }
  }, []);

  // Handle menu open
  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, view: SavedView) => {
    setAnchorEl(event.currentTarget);
    setSelectedView(view);
  };

  // Handle menu close
  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedView(null);
  };

  // Handle create view
  const handleCreateView = () => {
    if (!viewName.trim()) return;

    const newView: Omit<SavedView, 'id' | 'createdAt' | 'updatedAt'> = {
      name: viewName,
      description: viewDescription,
      filters: {}, // Current filters would be passed from parent
      isShared,
      createdBy: currentUserId,
    };

    onSaveView(newView);
    
    // Save to localStorage
    const views = JSON.parse(localStorage.getItem('savedViews') || '[]');
    const viewWithId = {
      ...newView,
      id: `view-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    views.push(viewWithId);
    localStorage.setItem('savedViews', JSON.stringify(views));

    // Reset form
    setViewName('');
    setViewDescription('');
    setIsShared(false);
    setShowCreateDialog(false);
  };

  // Handle edit view
  const handleEditView = () => {
    if (!selectedView || !viewName.trim()) return;

    onUpdateView(selectedView.id, {
      name: viewName,
      description: viewDescription,
      isShared,
      updatedAt: new Date().toISOString(),
    });

    // Update localStorage
    const views = JSON.parse(localStorage.getItem('savedViews') || '[]');
    const updated = views.map((v: SavedView) =>
      v.id === selectedView.id
        ? { ...v, name: viewName, description: viewDescription, isShared, updatedAt: new Date().toISOString() }
        : v
    );
    localStorage.setItem('savedViews', JSON.stringify(updated));

    // Reset form
    setEditingView(null);
    setViewName('');
    setViewDescription('');
    setIsShared(false);
    handleMenuClose();
  };

  // Handle delete view
  const handleDeleteView = (viewId: string) => {
    onDeleteView(viewId);
    
    // Remove from localStorage
    const views = JSON.parse(localStorage.getItem('savedViews') || '[]');
    const filtered = views.filter((v: SavedView) => v.id !== viewId);
    localStorage.setItem('savedViews', JSON.stringify(filtered));
    
    handleMenuClose();
  };

  // Handle load view
  const handleLoadView = (view: SavedView) => {
    onLoadView(view);
    onClose();
  };

  // Start editing
  const startEditing = (view: SavedView) => {
    setEditingView(view);
    setViewName(view.name);
    setViewDescription(view.description || '');
    setIsShared(view.isShared);
    handleMenuClose();
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  return (
    <>
      <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
        <DialogTitle>
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Typography variant="h6">Saved Views & Bookmarks</Typography>
            <Button
              variant="contained"
              startIcon={<BookmarkIcon />}
              onClick={() => setShowCreateDialog(true)}
            >
              Save Current View
            </Button>
          </Box>
        </DialogTitle>
        <DialogContent>
          {savedViews.length === 0 ? (
            <Box textAlign="center" py={4}>
              <BookmarkBorderIcon sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
              <Typography variant="h6" color="text.secondary" gutterBottom>
                No Saved Views
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Save your current filters and sort order for quick access later
              </Typography>
            </Box>
          ) : (
            <List>
              {savedViews.map((view, index) => (
                <Box key={view.id}>
                  <ListItem>
                    <ListItemText
                      primary={
                        <Box display="flex" alignItems="center" gap={1}>
                          <Typography variant="subtitle1">{view.name}</Typography>
                          {view.isShared && (
                            <Chip label="Shared" size="small" color="primary" icon={<ShareIcon />} />
                          )}
                        </Box>
                      }
                      secondary={
                        <Box>
                          {view.description && (
                            <Typography variant="body2" color="text.secondary">
                              {view.description}
                            </Typography>
                          )}
                          <Typography variant="caption" color="text.secondary">
                            Created: {formatDate(view.createdAt)} | Updated: {formatDate(view.updatedAt)}
                          </Typography>
                        </Box>
                      }
                    />
                    <ListItemSecondaryAction>
                      <Stack direction="row" spacing={1}>
                        <IconButton
                          edge="end"
                          onClick={() => handleLoadView(view)}
                          color="primary"
                        >
                          <VisibilityIcon />
                        </IconButton>
                        <IconButton
                          edge="end"
                          onClick={(e) => handleMenuOpen(e, view)}
                        >
                          <MoreVertIcon />
                        </IconButton>
                      </Stack>
                    </ListItemSecondaryAction>
                  </ListItem>
                  {index < savedViews.length - 1 && <Divider />}
                </Box>
              ))}
            </List>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Context Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={() => selectedView && startEditing(selectedView)}>
          <EditIcon sx={{ mr: 1 }} fontSize="small" />
          Edit
        </MenuItem>
        <MenuItem onClick={() => selectedView && handleDeleteView(selectedView.id)}>
          <DeleteIcon sx={{ mr: 1 }} fontSize="small" />
          Delete
        </MenuItem>
      </Menu>

      {/* Create/Edit View Dialog */}
      <Dialog
        open={showCreateDialog || editingView !== null}
        onClose={() => {
          setShowCreateDialog(false);
          setEditingView(null);
          setViewName('');
          setViewDescription('');
          setIsShared(false);
        }}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          {editingView ? 'Edit View' : 'Save Current View'}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              fullWidth
              label="View Name"
              value={viewName}
              onChange={(e) => setViewName(e.target.value)}
              required
            />
            <TextField
              fullWidth
              label="Description (Optional)"
              value={viewDescription}
              onChange={(e) => setViewDescription(e.target.value)}
              multiline
              rows={2}
            />
            <FormControlLabel
              control={
                <Switch
                  checked={isShared}
                  onChange={(e) => setIsShared(e.target.checked)}
                />
              }
              label="Share with team"
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setShowCreateDialog(false);
              setEditingView(null);
              setViewName('');
              setViewDescription('');
              setIsShared(false);
            }}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={editingView ? handleEditView : handleCreateView}
            disabled={!viewName.trim()}
          >
            {editingView ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default SavedViewsManager;
