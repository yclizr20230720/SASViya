import { Card, CardContent, Box, Typography, Chip } from '@mui/material';
import { type SvgIconComponent } from '@mui/icons-material';
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import { useEffect, useState } from 'react';

interface KPICardProps {
  title: string;
  value: string | number;
  trend?: number;
  trendLabel?: string;
  icon: React.ReactElement<SvgIconComponent>;
  sparklineData?: number[];
  suffix?: string;
  color?: 'primary' | 'success' | 'warning' | 'error';
  showProgress?: boolean;
  progressValue?: number;
  subtitle?: string;
}

export default function KPICard({
  title,
  value,
  trend,
  trendLabel = 'vs last week',
  icon,
  sparklineData,
  suffix = '',
  color = 'primary',
  showProgress = false,
  progressValue,
  subtitle,
}: KPICardProps) {
  const [animatedValue, setAnimatedValue] = useState(0);
  const [isAnimating, setIsAnimating] = useState(true);

  useEffect(() => {
    // Animate value on mount
    const numericValue = typeof value === 'number' ? value : parseFloat(value.toString());
    if (!isNaN(numericValue)) {
      const duration = 1000;
      const steps = 30;
      const increment = numericValue / steps;
      let current = 0;

      const timer = setInterval(() => {
        current += increment;
        if (current >= numericValue) {
          setAnimatedValue(numericValue);
          setIsAnimating(false);
          clearInterval(timer);
        } else {
          setAnimatedValue(current);
        }
      }, duration / steps);

      return () => clearInterval(timer);
    }
  }, [value]);

  const getTrendColor = () => {
    if (!trend) return 'default';
    return trend > 0 ? 'success' : 'error';
  };

  const formatValue = (val: number) => {
    if (typeof value === 'string' && value.includes('%')) {
      return val.toFixed(1);
    }
    return Math.floor(val).toLocaleString();
  };

  return (
    <Card
      sx={{
        height: '100%',
        transition: 'transform 0.2s, box-shadow 0.2s',
        '&:hover': {
          transform: 'translateY(-4px)',
          boxShadow: 4,
        },
      }}
    >
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
          <Typography color="text.secondary" variant="body2">
            {title}
          </Typography>
          {icon}
        </Box>

        <Typography
          variant="h4"
          sx={{
            mb: 1,
            fontWeight: 600,
            transition: 'all 0.3s',
            color: isAnimating ? 'text.secondary' : 'text.primary',
          }}
        >
          {formatValue(animatedValue)}
          {suffix}
        </Typography>

        {sparklineData && sparklineData.length > 0 && (
          <Box sx={{ height: 40, mb: 1, mt: 1 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sparklineData.map((val, idx) => ({ value: val, index: idx }))}>
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke={color === 'success' ? '#388E3C' : '#0066CC'}
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </Box>
        )}

        {showProgress && progressValue !== undefined && (
          <Box
            sx={{
              height: 6,
              bgcolor: 'grey.200',
              borderRadius: 3,
              overflow: 'hidden',
              mb: 1,
            }}
          >
            <Box
              sx={{
                height: '100%',
                width: `${progressValue}%`,
                bgcolor: `${color}.main`,
                transition: 'width 1s ease-in-out',
              }}
            />
          </Box>
        )}

        {trend !== undefined && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Chip
              label={`${trend > 0 ? '+' : ''}${trend}%`}
              size="small"
              color={getTrendColor()}
              sx={{ height: 20 }}
            />
            <Typography variant="caption" color="text.secondary">
              {trendLabel}
            </Typography>
          </Box>
        )}

        {subtitle && (
          <Typography variant="caption" color="text.secondary">
            {subtitle}
          </Typography>
        )}
      </CardContent>
    </Card>
  );
}
