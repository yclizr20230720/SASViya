import { Box, Paper } from '@mui/material';

interface VirtualizedListProps<T> {
  items: T[];
  itemHeight: number;
  height: number;
  width?: string | number;
  renderItem: (item: T, index: number) => React.ReactNode;
  overscanCount?: number;
}

/**
 * Virtualized list component for rendering large datasets efficiently
 * Only renders visible items in the viewport
 * 
 * NOTE: This is a placeholder implementation. For production use with react-window v2:
 * 1. Import: import { List, useListRef } from 'react-window';
 * 2. Use rowComponent prop instead of children
 * 3. Pass rowHeight, rowCount, defaultHeight props
 * 4. See react-window v2 documentation for updated API
 */
export default function VirtualizedList<T>({
  items,
  itemHeight,
  height,
  width = '100%',
  renderItem,
}: VirtualizedListProps<T>) {
  // Fallback implementation - renders all items
  // Replace with react-window List component for production
  return (
    <Paper 
      elevation={0} 
      sx={{ 
        width, 
        height, 
        overflow: 'auto'
      }}
    >
      {items.map((item, index) => (
        <Box 
          key={index} 
          sx={{ 
            px: 2, 
            py: 1, 
            height: itemHeight 
          }}
        >
          {renderItem(item, index)}
        </Box>
      ))}
    </Paper>
  );
}
