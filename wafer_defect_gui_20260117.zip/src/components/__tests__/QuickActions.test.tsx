import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import QuickActions from '../QuickActions';

const mockNavigate = vi.fn();

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom');
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

describe('QuickActions', () => {
  it('should render action buttons in button variant', () => {
    render(
      <BrowserRouter>
        <QuickActions variant="buttons" />
      </BrowserRouter>
    );

    expect(screen.getByText('Upload Wafer Map')).toBeInTheDocument();
    expect(screen.getByText('View Reports')).toBeInTheDocument();
    expect(screen.getByText('Shortcuts')).toBeInTheDocument();
  });

  it('should navigate to upload page when upload button is clicked', () => {
    render(
      <BrowserRouter>
        <QuickActions variant="buttons" />
      </BrowserRouter>
    );

    const uploadButton = screen.getByText('Upload Wafer Map');
    fireEvent.click(uploadButton);

    expect(mockNavigate).toHaveBeenCalledWith('/upload');
  });

  it('should navigate to history page when view reports button is clicked', () => {
    render(
      <BrowserRouter>
        <QuickActions variant="buttons" />
      </BrowserRouter>
    );

    const reportsButton = screen.getByText('View Reports');
    fireEvent.click(reportsButton);

    expect(mockNavigate).toHaveBeenCalledWith('/history');
  });

  it('should open shortcuts dialog when shortcuts button is clicked', () => {
    render(
      <BrowserRouter>
        <QuickActions variant="buttons" />
      </BrowserRouter>
    );

    const shortcutsButton = screen.getByText('Shortcuts');
    fireEvent.click(shortcutsButton);

    expect(screen.getByText('Keyboard Shortcuts')).toBeInTheDocument();
  });
});
