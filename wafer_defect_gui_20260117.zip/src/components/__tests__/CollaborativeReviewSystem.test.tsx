import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import CollaborativeReviewSystem from '../CollaborativeReviewSystem';

describe('CollaborativeReviewSystem', () => {
  const mockProps = {
    waferId: 'wafer-123',
    currentUserId: 'user-current',
    currentUserName: 'Current User',
    onCommentAdded: vi.fn(),
    onAssignmentCreated: vi.fn(),
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Component Rendering', () => {
    it('should render the collaborative review system', () => {
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      expect(screen.getByText('Active Reviewers')).toBeInTheDocument();
      expect(screen.getByText('Discussion & Comments')).toBeInTheDocument();
      expect(screen.getByPlaceholderText('Add a comment...')).toBeInTheDocument();
    });

    it('should display active users section', () => {
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      expect(screen.getByText('Active Reviewers')).toBeInTheDocument();
    });

    it('should show assign review button', () => {
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      expect(screen.getByText('Assign Review')).toBeInTheDocument();
    });
  });

  describe('Comment Functionality', () => {
    it('should allow posting a new comment', async () => {
      const user = userEvent.setup();
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      const commentInput = screen.getByPlaceholderText('Add a comment...');
      const postButton = screen.getByRole('button', { name: /post comment/i });

      await user.type(commentInput, 'This is a test comment');
      await user.click(postButton);

      await waitFor(() => {
        expect(mockProps.onCommentAdded).toHaveBeenCalled();
      });
    });

    it('should disable post button when comment is empty', () => {
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      const postButton = screen.getByRole('button', { name: /post comment/i });
      expect(postButton).toBeDisabled();
    });

    it('should clear comment input after posting', async () => {
      const user = userEvent.setup();
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      const commentInput = screen.getByPlaceholderText('Add a comment...') as HTMLTextAreaElement;
      const postButton = screen.getByRole('button', { name: /post comment/i });

      await user.type(commentInput, 'Test comment');
      await user.click(postButton);

      await waitFor(() => {
        expect(commentInput.value).toBe('');
      });
    });

    it('should display existing comments', async () => {
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      // Wait for mock comments to load
      await waitFor(() => {
        expect(screen.getByText(/I noticed a center pattern defect/i)).toBeInTheDocument();
      });
    });
  });

  describe('Assignment Functionality', () => {
    it('should open assignment dialog when assign button is clicked', async () => {
      const user = userEvent.setup();
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      const assignButton = screen.getByText('Assign Review');
      await user.click(assignButton);

      await waitFor(() => {
        expect(screen.getByRole('dialog')).toBeInTheDocument();
      });
    });

    it('should display review assignments section', async () => {
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      await waitFor(() => {
        expect(screen.getByText('Review Assignments')).toBeInTheDocument();
      });
    });
  });

  describe('Real-time Collaboration', () => {
    it('should display active user information', async () => {
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      await waitFor(() => {
        expect(screen.getByText(/online/i)).toBeInTheDocument();
      });
    });
  });

  describe('Error Handling', () => {
    it('should handle empty comment submission gracefully', () => {
      render(<CollaborativeReviewSystem {...mockProps} />);
      
      const postButton = screen.getByRole('button', { name: /post comment/i });
      expect(postButton).toBeDisabled();
    });

    it('should render without optional callbacks', () => {
      const propsWithoutCallbacks = {
        waferId: 'wafer-123',
        currentUserId: 'user-current',
        currentUserName: 'Current User',
      };
      
      expect(() => {
        render(<CollaborativeReviewSystem {...propsWithoutCallbacks} />);
      }).not.toThrow();
    });
  });
});
