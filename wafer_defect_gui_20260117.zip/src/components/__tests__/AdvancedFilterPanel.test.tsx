import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import AdvancedFilterPanel from '../AdvancedFilterPanel';

describe('AdvancedFilterPanel', () => {
  const mockOnClose = vi.fn();
  const mockOnApplyFilters = vi.fn();
  const mockOnSavePreset = vi.fn();
  const mockOnLoadPreset = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
  });

  it('renders when open', () => {
    render(
      <AdvancedFilterPanel
        open={true}
        onClose={mockOnClose}
        onApplyFilters={mockOnApplyFilters}
      />
    );

    expect(screen.getByText('Advanced Filters')).toBeInTheDocument();
  });

  it('does not render when closed', () => {
    render(
      <AdvancedFilterPanel
        open={false}
        onClose={mockOnClose}
        onApplyFilters={mockOnApplyFilters}
      />
    );

    expect(screen.queryByText('Advanced Filters')).not.toBeInTheDocument();
  });

  it('calls onClose when close button is clicked', () => {
    render(
      <AdvancedFilterPanel
        open={true}
        onClose={mockOnClose}
        onApplyFilters={mockOnApplyFilters}
      />
    );

    const closeButton = screen.getByRole('button', { name: /close/i });
    fireEvent.click(closeButton);

    expect(mockOnClose).toHaveBeenCalled();
  });

  it('shows filter logic options', () => {
    render(
      <AdvancedFilterPanel
        open={true}
        onClose={mockOnClose}
        onApplyFilters={mockOnApplyFilters}
      />
    );

    expect(screen.getByText('Filter Logic')).toBeInTheDocument();
    expect(screen.getByLabelText(/Match All \(AND\)/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Match Any \(OR\)/i)).toBeInTheDocument();
  });

  it('shows all filter sections', () => {
    render(
      <AdvancedFilterPanel
        open={true}
        onClose={mockOnClose}
        onApplyFilters={mockOnApplyFilters}
      />
    );

    expect(screen.getByText('Date Range')).toBeInTheDocument();
    expect(screen.getByText('Pattern Types')).toBeInTheDocument();
    expect(screen.getByText('Confidence Range')).toBeInTheDocument();
    expect(screen.getByText('Equipment')).toBeInTheDocument();
    expect(screen.getByText('Process Steps')).toBeInTheDocument();
  });

  it('applies filters when apply button is clicked', () => {
    render(
      <AdvancedFilterPanel
        open={true}
        onClose={mockOnClose}
        onApplyFilters={mockOnApplyFilters}
      />
    );

    // The apply button should be disabled initially (no filters active)
    const applyButton = screen.getByRole('button', { name: /Apply Filters \(0\)/i });
    expect(applyButton).toBeDisabled();
  });

  it('resets filters when reset button is clicked', () => {
    render(
      <AdvancedFilterPanel
        open={true}
        onClose={mockOnClose}
        onApplyFilters={mockOnApplyFilters}
      />
    );

    const resetButton = screen.getByRole('button', { name: /Reset All Filters/i });
    fireEvent.click(resetButton);

    // After reset, localStorage should be updated
    const savedFilters = localStorage.getItem('currentFilters');
    expect(savedFilters).toBeTruthy();
  });

  it('shows saved presets when provided', () => {
    const mockPresets = [
      {
        id: 'preset1',
        name: 'High Confidence',
        criteria: {
          confidenceRange: [80, 100],
        },
      },
    ];

    render(
      <AdvancedFilterPanel
        open={true}
        onClose={mockOnClose}
        onApplyFilters={mockOnApplyFilters}
        savedPresets={mockPresets}
      />
    );

    expect(screen.getByText('Saved Presets')).toBeInTheDocument();
  });

  it('loads preset when preset button is clicked', () => {
    const mockPresets = [
      {
        id: 'preset1',
        name: 'High Confidence',
        criteria: {
          confidenceRange: [80, 100],
        },
      },
    ];

    render(
      <AdvancedFilterPanel
        open={true}
        onClose={mockOnClose}
        onApplyFilters={mockOnApplyFilters}
        onLoadPreset={mockOnLoadPreset}
        savedPresets={mockPresets}
      />
    );

    // Expand the presets accordion
    const presetsAccordion = screen.getByText('Saved Presets');
    fireEvent.click(presetsAccordion);

    // Click the preset button
    const presetButton = screen.getByRole('button', { name: 'High Confidence' });
    fireEvent.click(presetButton);

    expect(mockOnLoadPreset).toHaveBeenCalledWith(mockPresets[0]);
  });

  it('shows save preset form when save button is clicked', () => {
    render(
      <AdvancedFilterPanel
        open={true}
        onClose={mockOnClose}
        onApplyFilters={mockOnApplyFilters}
      />
    );

    const saveButton = screen.getByRole('button', { name: /Save as Preset/i });
    
    // Button should be disabled initially (no filters active)
    expect(saveButton).toBeDisabled();
  });
});
