import type { WaferData } from '../components/AdvancedDataTable';

const patterns = ['Center', 'Edge-Ring', 'Edge-Loc', 'Loc', 'Near-full', 'Random', 'None'];
const rootCauses = [
  'Lithography Focus',
  'Etching Uniformity',
  'Particle Contamination',
  'CMP Pressure',
  'Edge Bead Removal',
  'Ion Implantation Dose',
  'Deposition Thickness',
  'Temperature Variation',
  'Chemical Residue',
  'Equipment Drift',
  'Unknown',
];
const equipment = ['EQP-001', 'EQP-002', 'EQP-003', 'EQP-004', 'EQP-005'];
const processSteps = ['Lithography', 'Etching', 'Deposition', 'CMP', 'Ion Implantation', 'Cleaning'];

// Generate a random date within the last 90 days
const generateRandomDate = () => {
  const now = new Date();
  const daysAgo = Math.floor(Math.random() * 90);
  const date = new Date(now.getTime() - daysAgo * 24 * 60 * 60 * 1000);
  return date.toISOString().split('T')[0];
};

// Generate a random number within a range
const randomInRange = (min: number, max: number, decimals: number = 0) => {
  const value = Math.random() * (max - min) + min;
  return Number(value.toFixed(decimals));
};

// Generate a lot ID based on date
const generateLotId = (date: string) => {
  const dateObj = new Date(date);
  const year = dateObj.getFullYear();
  const month = String(dateObj.getMonth() + 1).padStart(2, '0');
  const lotNum = String(Math.floor(Math.random() * 999) + 1).padStart(3, '0');
  return `LOT-${year}${month}-${lotNum}`;
};

// Generate mock wafer data
export const generateMockWaferData = (count: number = 50): WaferData[] => {
  const data: WaferData[] = [];
  const lots = new Set<string>();

  for (let i = 1; i <= count; i++) {
    const date = generateRandomDate();
    let lotId = generateLotId(date);
    
    // Ensure some wafers share the same lot
    if (i % 5 === 0 && lots.size > 0) {
      const lotsArray = Array.from(lots);
      lotId = lotsArray[Math.floor(Math.random() * lotsArray.length)];
    } else {
      lots.add(lotId);
    }

    const pattern = patterns[Math.floor(Math.random() * patterns.length)];
    const confidence = randomInRange(65, 99, 1);
    const rootCause = rootCauses[Math.floor(Math.random() * rootCauses.length)];
    const eqp = equipment[Math.floor(Math.random() * equipment.length)];
    const processStep = processSteps[Math.floor(Math.random() * processSteps.length)];
    const defectCount = Math.floor(randomInRange(5, 100));
    const yieldImpact = randomInRange(0.5, 8, 2);

    data.push({
      id: String(i),
      waferId: `W-2024-${String(i).padStart(4, '0')}`,
      lotId,
      pattern,
      confidence,
      rootCause,
      equipment: eqp,
      processStep,
      date,
      defectCount,
      yieldImpact,
    });
  }

  // Sort by date (newest first)
  return data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

// Generate specific test scenarios
export const generateTestScenarios = (): WaferData[] => {
  return [
    // High confidence center patterns
    {
      id: 'test-1',
      waferId: 'W-2024-TEST-001',
      lotId: 'LOT-202401-TEST',
      pattern: 'Center',
      confidence: 98.5,
      rootCause: 'Lithography Focus',
      equipment: 'EQP-001',
      processStep: 'Lithography',
      date: '2024-01-20',
      defectCount: 12,
      yieldImpact: 1.2,
    },
    // Low confidence random pattern
    {
      id: 'test-2',
      waferId: 'W-2024-TEST-002',
      lotId: 'LOT-202401-TEST',
      pattern: 'Random',
      confidence: 68.3,
      rootCause: 'Unknown',
      equipment: 'EQP-003',
      processStep: 'Deposition',
      date: '2024-01-20',
      defectCount: 87,
      yieldImpact: 7.8,
    },
    // Edge-ring with high defect count
    {
      id: 'test-3',
      waferId: 'W-2024-TEST-003',
      lotId: 'LOT-202401-EDGE',
      pattern: 'Edge-Ring',
      confidence: 92.1,
      rootCause: 'Edge Bead Removal',
      equipment: 'EQP-002',
      processStep: 'Lithography',
      date: '2024-01-19',
      defectCount: 95,
      yieldImpact: 6.5,
    },
  ];
};

// Get facet counts from data
export const getFacetCounts = (data: WaferData[]) => {
  const patternCounts: Record<string, number> = {};
  const equipmentCounts: Record<string, number> = {};
  const processStepCounts: Record<string, number> = {};

  data.forEach((item) => {
    patternCounts[item.pattern] = (patternCounts[item.pattern] || 0) + 1;
    equipmentCounts[item.equipment] = (equipmentCounts[item.equipment] || 0) + 1;
    processStepCounts[item.processStep] = (processStepCounts[item.processStep] || 0) + 1;
  });

  return {
    patterns: Object.entries(patternCounts).map(([value, count]) => ({
      value: value.toLowerCase().replace(/-/g, ''),
      label: value,
      count,
    })),
    equipment: Object.entries(equipmentCounts).map(([value, count]) => ({
      value: value.toLowerCase(),
      label: value,
      count,
    })),
    processSteps: Object.entries(processStepCounts).map(([value, count]) => ({
      value: value.toLowerCase().replace(/\s+/g, ''),
      label: value,
      count,
    })),
  };
};
