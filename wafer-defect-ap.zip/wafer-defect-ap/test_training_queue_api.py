"""
Test script to verify training queue API endpoints
"""
import requests
import json

BASE_URL = "http://localhost:5000/api/v1"

def test_training_queue():
    """Test GET /api/v1/training/queue"""
    print("\n=== Testing Training Queue API ===\n")
    
    try:
        response = requests.get(f"{BASE_URL}/training/queue")
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"✓ Success! Found {len(data)} training jobs")
            print("\nJobs:")
            for job in data:
                print(f"  - {job['job_id']}: {job['status']} ({job.get('current_epoch', 0)}/{job.get('total_epochs', 0)} epochs)")
        else:
            print(f"✗ Error: {response.text}")
    except requests.exceptions.ConnectionError:
        print("✗ Connection Error: Flask server is not running!")
        print("  Start the server with: python run.py")
    except Exception as e:
        print(f"✗ Error: {e}")

def test_training_metrics():
    """Test GET /api/v1/training/metrics/<job_id>"""
    print("\n=== Testing Training Metrics API ===\n")
    
    job_id = "training_20260118"
    
    try:
        response = requests.get(f"{BASE_URL}/training/metrics/{job_id}")
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"✓ Success! Retrieved metrics for job {job_id}")
            print(f"\nStatus: {data['status']}")
            print(f"Progress: {data['progress_percentage']}%")
            print(f"Current Epoch: {data['current_epoch']}/{data['total_epochs']}")
            print(f"\nCurrent Metrics:")
            print(f"  Train Loss: {data['current_metrics']['train_loss']:.4f}")
            print(f"  Train Pattern Acc: {data['current_metrics']['train_pattern_acc']:.1%}")
            print(f"  Val Pattern Acc: {data['current_metrics']['val_pattern_acc']:.1%}")
        else:
            print(f"✗ Error: {response.text}")
    except requests.exceptions.ConnectionError:
        print("✗ Connection Error: Flask server is not running!")
        print("  Start the server with: python run.py")
    except Exception as e:
        print(f"✗ Error: {e}")

def test_training_logs():
    """Test GET /api/v1/training/logs/<job_id>"""
    print("\n=== Testing Training Logs API ===\n")
    
    job_id = "training_20260118"
    
    try:
        response = requests.get(f"{BASE_URL}/training/logs/{job_id}")
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            logs = response.text
            lines = logs.split('\n')
            print(f"✓ Success! Retrieved {len(lines)} lines of logs")
            print("\nFirst 10 lines:")
            for line in lines[:10]:
                print(f"  {line}")
            print("\n  ...")
            print("\nLast 5 lines:")
            for line in lines[-5:]:
                print(f"  {line}")
        else:
            print(f"✗ Error: {response.text}")
    except requests.exceptions.ConnectionError:
        print("✗ Connection Error: Flask server is not running!")
        print("  Start the server with: python run.py")
    except Exception as e:
        print(f"✗ Error: {e}")

if __name__ == "__main__":
    print("=" * 60)
    print("Training Queue API Test Suite")
    print("=" * 60)
    
    test_training_queue()
    test_training_metrics()
    test_training_logs()
    
    print("\n" + "=" * 60)
    print("Test Complete!")
    print("=" * 60)
