# Model Training Guide - Wafer Defect Pattern Recognition

## Quick Start

This guide provides step-by-step instructions for training the wafer defect pattern recognition model.

---

## Prerequisites

### Hardware Requirements
- **GPU**: NVIDIA GPU with 8GB+ VRAM (RTX 3070 or better recommended)
- **CPU**: 8+ cores
- **RAM**: 32GB+ recommended
- **Storage**: 100GB+ free space

### Software Requirements
```bash
# Python 3.11+
python --version

# CUDA 11.8+ (for GPU training)
nvcc --version

# Install dependencies
pip install -r requirements.txt
```

---

## Step 1: Data Preparation

### 1.1 Organize Training Data

```
data/
├── wafer_images/          # Raw wafer map images
│   ├── M93242.01.png
│   ├── M93242.02.png
│   └── ...
├── metadata/
│   └── wafers.json        # Wafer metadata with labels
└── processed/
    ├── train/             # Training set (70%)
    ├── val/               # Validation set (15%)
    └── test/              # Test set (15%)
```

### 1.2 Create Dataset Split

```python
python scripts/prepare_dataset.py \
    --input data/wafer_images \
    --output data/processed \
    --split 0.7 0.15 0.15 \
    --seed 42
```


---

## Step 2: Train the Model

### 2.1 Basic Training

```bash
python train.py \
    --data_dir data/processed \
    --model efficientnet-b3 \
    --epochs 100 \
    --batch_size 32 \
    --learning_rate 0.0001 \
    --output_dir checkpoints/
```

### 2.2 Training with All Options

```bash
python train.py \
    --data_dir data/processed \
    --model efficientnet-b3 \
    --epochs 100 \
    --batch_size 32 \
    --learning_rate 0.0001 \
    --weight_decay 0.00001 \
    --dropout 0.3 \
    --num_workers 4 \
    --use_focal_loss \
    --focal_alpha 0.25 \
    --focal_gamma 2.0 \
    --early_stopping_patience 15 \
    --save_best_only \
    --output_dir checkpoints/ \
    --log_dir logs/ \
    --gpu 0
```

### 2.3 Resume Training from Checkpoint

```bash
python train.py \
    --resume checkpoints/checkpoint_epoch_50.pth \
    --epochs 100 \
    --output_dir checkpoints/
```

---

## Step 3: Monitor Training

### 3.1 TensorBoard

```bash
# Start TensorBoard
tensorboard --logdir logs/

# Open browser: http://localhost:6006
```

### 3.2 Training Metrics to Monitor

- **Loss**: Should decrease steadily
- **Pattern Accuracy**: Target > 95%
- **Root Cause Accuracy**: Target > 90%
- **Validation Loss**: Should not increase (overfitting indicator)
- **Learning Rate**: Should decrease with scheduler

---

## Step 4: Evaluate Model

### 4.1 Test Set Evaluation

```bash
python evaluate.py \
    --model checkpoints/best_model.pth \
    --data_dir data/processed/test \
    --output results/evaluation.json
```

### 4.2 Generate Confusion Matrix

```bash
python evaluate.py \
    --model checkpoints/best_model.pth \
    --data_dir data/processed/test \
    --confusion_matrix \
    --output results/confusion_matrix.png
```

### 4.3 Per-Class Metrics

```bash
python evaluate.py \
    --model checkpoints/best_model.pth \
    --data_dir data/processed/test \
    --per_class_metrics \
    --output results/per_class_metrics.csv
```


---

## Step 5: Hyperparameter Tuning

### 5.1 Grid Search

```python
# hyperparameter_search.py
from itertools import product

learning_rates = [1e-3, 1e-4, 1e-5]
batch_sizes = [16, 32, 64]
dropouts = [0.2, 0.3, 0.4]

for lr, bs, dropout in product(learning_rates, batch_sizes, dropouts):
    print(f"Training with lr={lr}, batch_size={bs}, dropout={dropout}")
    
    # Train model with these hyperparameters
    train_model(
        learning_rate=lr,
        batch_size=bs,
        dropout=dropout,
        output_dir=f"checkpoints/lr{lr}_bs{bs}_d{dropout}"
    )
```

### 5.2 Optuna (Automated Hyperparameter Optimization)

```python
import optuna

def objective(trial):
    # Suggest hyperparameters
    lr = trial.suggest_loguniform('learning_rate', 1e-5, 1e-3)
    batch_size = trial.suggest_categorical('batch_size', [16, 32, 64])
    dropout = trial.suggest_uniform('dropout', 0.1, 0.5)
    
    # Train and evaluate
    val_acc = train_and_evaluate(lr, batch_size, dropout)
    
    return val_acc

# Run optimization
study = optuna.create_study(direction='maximize')
study.optimize(objective, n_trials=50)

print(f"Best hyperparameters: {study.best_params}")
print(f"Best validation accuracy: {study.best_value}")
```

---

## Step 6: Generate Synthetic Data (Optional)

### 6.1 Train GAN

```bash
python train_gan.py \
    --data_dir data/processed/train \
    --epochs 50 \
    --batch_size 64 \
    --latent_dim 100 \
    --n_critic 5 \
    --lambda_gp 10 \
    --output_dir gan_checkpoints/
```

### 6.2 Generate Synthetic Wafers

```bash
python generate_synthetic.py \
    --gan_model gan_checkpoints/best_gan.pth \
    --num_samples 1000 \
    --pattern_class center \
    --output_dir data/synthetic/
```

### 6.3 Validate Synthetic Data Quality

```bash
python validate_synthetic.py \
    --real_dir data/processed/train \
    --synthetic_dir data/synthetic \
    --metrics fid ssim \
    --output results/synthetic_quality.json
```

---

## Step 7: Model Optimization

### 7.1 Quantization

```bash
python quantize_model.py \
    --model checkpoints/best_model.pth \
    --calibration_data data/processed/val \
    --output models/quantized_model.pth
```

### 7.2 ONNX Export

```bash
python export_onnx.py \
    --model checkpoints/best_model.pth \
    --output models/wafer_defect_model.onnx \
    --opset_version 11
```

### 7.3 TensorRT Optimization

```bash
python optimize_tensorrt.py \
    --onnx_model models/wafer_defect_model.onnx \
    --output models/wafer_defect_model.trt \
    --fp16
```


---

## Step 8: Deploy Model

### 8.1 Save for Production

```python
# Save complete model package
python save_production_model.py \
    --model checkpoints/best_model.pth \
    --output models/production/v1.0/ \
    --include_config \
    --include_preprocessing
```

### 8.2 Test Inference

```bash
python test_inference.py \
    --model models/production/v1.0/model.pth \
    --image data/test_images/M93242.01.png \
    --visualize
```

### 8.3 Benchmark Performance

```bash
python benchmark.py \
    --model models/production/v1.0/model.pth \
    --data_dir data/processed/test \
    --batch_sizes 1 8 16 32 \
    --device cuda \
    --output results/benchmark.json
```

---

## Troubleshooting

### Issue: Out of Memory (OOM)

**Solution:**
```bash
# Reduce batch size
python train.py --batch_size 16

# Use gradient accumulation
python train.py --batch_size 16 --accumulation_steps 2

# Use mixed precision training
python train.py --mixed_precision
```

### Issue: Model Not Converging

**Solution:**
1. Check learning rate (try 1e-4 or 1e-5)
2. Verify data preprocessing
3. Check for class imbalance
4. Use focal loss: `--use_focal_loss`
5. Increase model capacity: `--model efficientnet-b4`

### Issue: Overfitting

**Solution:**
```bash
# Increase dropout
python train.py --dropout 0.4

# Add weight decay
python train.py --weight_decay 0.0001

# Use data augmentation
python train.py --augmentation strong

# Early stopping
python train.py --early_stopping_patience 10
```

### Issue: Low Accuracy on Rare Classes

**Solution:**
```bash
# Use focal loss
python train.py --use_focal_loss --focal_gamma 2.0

# Oversample rare classes
python train.py --oversample_rare_classes

# Generate synthetic data for rare classes
python generate_synthetic.py --pattern_class donut --num_samples 500
```

---

## Best Practices

### 1. Data Quality
- Ensure consistent image quality
- Verify label accuracy
- Balance dataset (use synthetic data if needed)
- Remove corrupted images

### 2. Training Strategy
- Start with pretrained weights
- Use learning rate warmup
- Monitor validation metrics closely
- Save checkpoints frequently
- Use early stopping

### 3. Evaluation
- Test on held-out test set
- Calculate per-class metrics
- Analyze failure cases
- Validate on production-like data

### 4. Deployment
- Optimize model (quantization, ONNX)
- Benchmark inference speed
- Test on target hardware
- Monitor production performance

---

## Training Checklist

- [ ] Data prepared and split (70/15/15)
- [ ] Labels verified for accuracy
- [ ] Training script configured
- [ ] TensorBoard monitoring set up
- [ ] Baseline model trained
- [ ] Hyperparameters tuned
- [ ] Best model saved
- [ ] Test set evaluation completed
- [ ] Confusion matrix analyzed
- [ ] Model optimized (quantization/ONNX)
- [ ] Inference speed benchmarked
- [ ] Production deployment tested

---

## Additional Resources

- **API Documentation**: See `API_ENDPOINTS.md`
- **Architecture Details**: See `AI_MODEL_ARCHITECTURE.md`
- **Deployment Guide**: See `DEPLOYMENT_GUIDE.md`
- **Troubleshooting**: See `TROUBLESHOOTING.md`

---

**Last Updated:** January 18, 2026  
**Version:** 1.0
