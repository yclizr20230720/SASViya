"""
Conditional WGAN-GP for Synthetic Wafer Map Generation

Implements Task 10 from tasks_backend.md
Generates realistic synthetic wafer maps for data augmentation
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
from typing import Dict, List, Tuple, Optional
from pathlib import Path
import time

from .model import PATTERN_CLASSES


class Generator(nn.Module):
    """
    Conditional Generator for wafer map synthesis
    
    Generates 224x224 wafer maps conditioned on:
    - Pattern type (10 classes)
    - Defect density (continuous)
    """
    
    def __init__(
        self,
        noise_dim: int = 100,
        num_patterns: int = 10,
        img_size: int = 224
    ):
        super().__init__()
        
        self.noise_dim = noise_dim
        self.num_patterns = num_patterns
        self.img_size = img_size
        
        # Pattern embedding
        self.pattern_embed = nn.Embedding(num_patterns, 64)
        
        # Defect density embedding (1D continuous -> 64D)
        self.density_embed = nn.Sequential(
            nn.Linear(1, 32),
            nn.LeakyReLU(0.2),
            nn.Linear(32, 64)
        )
        
        # Combined condition dimension
        condition_dim = 64 + 64  # pattern + density
        
        # Initial projection
        self.fc = nn.Sequential(
            nn.Linear(noise_dim + condition_dim, 256 * 7 * 7),
            nn.BatchNorm1d(256 * 7 * 7),
            nn.ReLU()
        )
        
        # Upsampling layers: 7x7 -> 14x14 -> 28x28 -> 56x56 -> 112x112 -> 224x224
        self.deconv = nn.Sequential(
            # 7x7 -> 14x14
            nn.ConvTranspose2d(256, 256, 4, 2, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            
            # 14x14 -> 28x28
            nn.ConvTranspose2d(256, 128, 4, 2, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            
            # 28x28 -> 56x56
            nn.ConvTranspose2d(128, 64, 4, 2, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            
            # 56x56 -> 112x112
            nn.ConvTranspose2d(64, 32, 4, 2, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            
            # 112x112 -> 224x224
            nn.ConvTranspose2d(32, 16, 4, 2, 1),
            nn.BatchNorm2d(16),
            nn.ReLU(),
            
            # Final layer: 224x224 -> 224x224 (3 channels RGB)
            nn.Conv2d(16, 3, 3, 1, 1),
            nn.Sigmoid()
        )
    
    def forward(
        self,
        noise: torch.Tensor,
        pattern_labels: torch.Tensor,
        defect_density: torch.Tensor
    ) -> torch.Tensor:
        """
        Generate synthetic wafer maps
        
        Args:
            noise: Random noise (batch_size, noise_dim)
            pattern_labels: Pattern class indices (batch_size,)
            defect_density: Defect density values (batch_size, 1)
        
        Returns:
            Generated wafer maps (batch_size, 3, 224, 224)
        """
        # Embed conditions
        pattern_emb = self.pattern_embed(pattern_labels)  # (batch, 64)
        density_emb = self.density_embed(defect_density)  # (batch, 64)
        
        # Concatenate noise and conditions
        x = torch.cat([noise, pattern_emb, density_emb], dim=1)
        
        # Project and reshape
        x = self.fc(x)
        x = x.view(-1, 256, 7, 7)
        
        # Upsample to 224x224
        x = self.deconv(x)
        
        return x


class Discriminator(nn.Module):
    """
    Conditional Discriminator (Critic) for WGAN-GP
    
    Evaluates realism of wafer maps conditioned on pattern and density
    """
    
    def __init__(
        self,
        num_patterns: int = 10,
        img_size: int = 224
    ):
        super().__init__()
        
        self.num_patterns = num_patterns
        self.img_size = img_size
        
        # Pattern embedding
        self.pattern_embed = nn.Embedding(num_patterns, 64)
        
        # Defect density embedding
        self.density_embed = nn.Sequential(
            nn.Linear(1, 32),
            nn.LeakyReLU(0.2),
            nn.Linear(32, 64)
        )
        
        # Convolutional layers: 224x224 -> 112x112 -> 56x56 -> 28x28 -> 14x14 -> 7x7
        self.conv = nn.Sequential(
            # 224x224 -> 112x112
            nn.Conv2d(3, 16, 4, 2, 1),
            nn.LeakyReLU(0.2),
            
            # 112x112 -> 56x56
            nn.Conv2d(16, 32, 4, 2, 1),
            nn.InstanceNorm2d(32),
            nn.LeakyReLU(0.2),
            
            # 56x56 -> 28x28
            nn.Conv2d(32, 64, 4, 2, 1),
            nn.InstanceNorm2d(64),
            nn.LeakyReLU(0.2),
            
            # 28x28 -> 14x14
            nn.Conv2d(64, 128, 4, 2, 1),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(0.2),
            
            # 14x14 -> 7x7
            nn.Conv2d(128, 256, 4, 2, 1),
            nn.InstanceNorm2d(256),
            nn.LeakyReLU(0.2)
        )
        
        # Final classification with condition
        self.fc = nn.Sequential(
            nn.Linear(256 * 7 * 7 + 128, 512),  # +128 for conditions
            nn.LeakyReLU(0.2),
            nn.Linear(512, 1)
        )
    
    def forward(
        self,
        images: torch.Tensor,
        pattern_labels: torch.Tensor,
        defect_density: torch.Tensor
    ) -> torch.Tensor:
        """
        Evaluate realism of wafer maps
        
        Args:
            images: Wafer maps (batch_size, 3, 224, 224)
            pattern_labels: Pattern class indices (batch_size,)
            defect_density: Defect density values (batch_size, 1)
        
        Returns:
            Critic scores (batch_size, 1)
        """
        # Extract image features
        x = self.conv(images)
        x = x.view(x.size(0), -1)
        
        # Embed conditions
        pattern_emb = self.pattern_embed(pattern_labels)  # (batch, 64)
        density_emb = self.density_embed(defect_density)  # (batch, 64)
        
        # Concatenate features and conditions
        x = torch.cat([x, pattern_emb, density_emb], dim=1)
        
        # Final score
        x = self.fc(x)
        
        return x


class WaferGAN:
    """
    Conditional WGAN-GP for synthetic wafer map generation
    
    Features:
    - Wasserstein loss with gradient penalty
    - Conditional generation (pattern + density)
    - Quality validation (FID, SSIM)
    - Batch generation
    """
    
    def __init__(
        self,
        noise_dim: int = 100,
        num_patterns: int = 10,
        img_size: int = 224,
        device: str = 'cuda'
    ):
        """
        Initialize GAN
        
        Args:
            noise_dim: Dimension of noise vector
            num_patterns: Number of pattern classes
            img_size: Image size (224x224)
            device: 'cuda' or 'cpu'
        """
        self.noise_dim = noise_dim
        self.num_patterns = num_patterns
        self.img_size = img_size
        self.device = device
        
        # Initialize networks
        self.generator = Generator(noise_dim, num_patterns, img_size).to(device)
        self.discriminator = Discriminator(num_patterns, img_size).to(device)
        
        # Optimizers
        self.g_optimizer = optim.Adam(
            self.generator.parameters(),
            lr=0.0001,
            betas=(0.0, 0.9)
        )
        self.d_optimizer = optim.Adam(
            self.discriminator.parameters(),
            lr=0.0001,
            betas=(0.0, 0.9)
        )
        
        # Training history
        self.history = {
            'd_loss': [],
            'g_loss': [],
            'gp': [],
            'w_dist': []
        }
        
        print(f"WaferGAN initialized on {device}")
        print(f"Generator parameters: {sum(p.numel() for p in self.generator.parameters()):,}")
        print(f"Discriminator parameters: {sum(p.numel() for p in self.discriminator.parameters()):,}")
    
    def compute_gradient_penalty(
        self,
        real_images: torch.Tensor,
        fake_images: torch.Tensor,
        pattern_labels: torch.Tensor,
        defect_density: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute gradient penalty for WGAN-GP
        
        Args:
            real_images: Real wafer maps
            fake_images: Generated wafer maps
            pattern_labels: Pattern class indices
            defect_density: Defect density values
        
        Returns:
            Gradient penalty value
        """
        batch_size = real_images.size(0)
        
        # Random interpolation weight
        alpha = torch.rand(batch_size, 1, 1, 1, device=self.device)
        
        # Interpolate between real and fake
        interpolates = alpha * real_images + (1 - alpha) * fake_images
        interpolates.requires_grad_(True)
        
        # Discriminator output for interpolates
        d_interpolates = self.discriminator(interpolates, pattern_labels, defect_density)
        
        # Compute gradients
        gradients = torch.autograd.grad(
            outputs=d_interpolates,
            inputs=interpolates,
            grad_outputs=torch.ones_like(d_interpolates),
            create_graph=True,
            retain_graph=True,
            only_inputs=True
        )[0]
        
        # Flatten gradients
        gradients = gradients.view(batch_size, -1)
        
        # Compute gradient penalty
        gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
        
        return gradient_penalty
    
    def train_step(
        self,
        real_images: torch.Tensor,
        pattern_labels: torch.Tensor,
        defect_density: torch.Tensor,
        n_critic: int = 5,
        lambda_gp: float = 10.0
    ) -> Dict[str, float]:
        """
        Single training step
        
        Args:
            real_images: Real wafer maps (batch_size, 3, 224, 224)
            pattern_labels: Pattern class indices (batch_size,)
            defect_density: Defect density values (batch_size, 1)
            n_critic: Number of critic iterations per generator iteration
            lambda_gp: Gradient penalty weight
        
        Returns:
            Dictionary with loss values
        """
        batch_size = real_images.size(0)
        
        # Train Discriminator (Critic)
        d_losses = []
        gp_values = []
        
        for _ in range(n_critic):
            self.d_optimizer.zero_grad()
            
            # Generate fake images
            noise = torch.randn(batch_size, self.noise_dim, device=self.device)
            fake_images = self.generator(noise, pattern_labels, defect_density)
            
            # Discriminator outputs
            d_real = self.discriminator(real_images, pattern_labels, defect_density)
            d_fake = self.discriminator(fake_images.detach(), pattern_labels, defect_density)
            
            # Wasserstein loss
            d_loss = d_fake.mean() - d_real.mean()
            
            # Gradient penalty
            gp = self.compute_gradient_penalty(
                real_images, fake_images.detach(),
                pattern_labels, defect_density
            )
            
            # Total discriminator loss
            d_total_loss = d_loss + lambda_gp * gp
            
            d_total_loss.backward()
            self.d_optimizer.step()
            
            d_losses.append(d_loss.item())
            gp_values.append(gp.item())
        
        # Train Generator
        self.g_optimizer.zero_grad()
        
        # Generate fake images
        noise = torch.randn(batch_size, self.noise_dim, device=self.device)
        fake_images = self.generator(noise, pattern_labels, defect_density)
        
        # Generator loss (maximize discriminator output for fake images)
        g_loss = -self.discriminator(fake_images, pattern_labels, defect_density).mean()
        
        g_loss.backward()
        self.g_optimizer.step()
        
        # Return metrics
        return {
            'd_loss': np.mean(d_losses),
            'g_loss': g_loss.item(),
            'gp': np.mean(gp_values),
            'w_dist': -np.mean(d_losses)  # Wasserstein distance estimate
        }
    
    def generate(
        self,
        pattern_labels: torch.Tensor,
        defect_density: torch.Tensor,
        num_samples: int = 1
    ) -> torch.Tensor:
        """
        Generate synthetic wafer maps
        
        Args:
            pattern_labels: Pattern class indices (num_samples,)
            defect_density: Defect density values (num_samples, 1)
            num_samples: Number of samples to generate
        
        Returns:
            Generated wafer maps (num_samples, 3, 224, 224)
        """
        self.generator.eval()
        
        with torch.no_grad():
            noise = torch.randn(num_samples, self.noise_dim, device=self.device)
            fake_images = self.generator(noise, pattern_labels, defect_density)
        
        self.generator.train()
        
        return fake_images
    
    def save(self, path: str):
        """Save GAN checkpoint"""
        torch.save({
            'generator': self.generator.state_dict(),
            'discriminator': self.discriminator.state_dict(),
            'g_optimizer': self.g_optimizer.state_dict(),
            'd_optimizer': self.d_optimizer.state_dict(),
            'history': self.history
        }, path)
        print(f"GAN checkpoint saved to {path}")
    
    def load(self, path: str):
        """Load GAN checkpoint"""
        checkpoint = torch.load(path, map_location=self.device)
        self.generator.load_state_dict(checkpoint['generator'])
        self.discriminator.load_state_dict(checkpoint['discriminator'])
        self.g_optimizer.load_state_dict(checkpoint['g_optimizer'])
        self.d_optimizer.load_state_dict(checkpoint['d_optimizer'])
        self.history = checkpoint['history']
        print(f"GAN checkpoint loaded from {path}")


def train_gan(
    gan: WaferGAN,
    dataloader: DataLoader,
    num_epochs: int = 100,
    n_critic: int = 5,
    lambda_gp: float = 10.0,
    save_interval: int = 10,
    checkpoint_dir: str = 'checkpoints/gan'
):
    """
    Train GAN
    
    Args:
        gan: WaferGAN instance
        dataloader: Training data loader
        num_epochs: Number of training epochs
        n_critic: Critic iterations per generator iteration
        lambda_gp: Gradient penalty weight
        save_interval: Save checkpoint every N epochs
        checkpoint_dir: Directory to save checkpoints
    """
    Path(checkpoint_dir).mkdir(parents=True, exist_ok=True)
    
    print("="*60)
    print("TRAINING CONDITIONAL WGAN-GP")
    print("="*60)
    print(f"Epochs: {num_epochs}")
    print(f"Critic iterations: {n_critic}")
    print(f"Gradient penalty weight: {lambda_gp}")
    print(f"Checkpoint directory: {checkpoint_dir}")
    print("="*60)
    
    for epoch in range(1, num_epochs + 1):
        epoch_start = time.time()
        
        epoch_metrics = {
            'd_loss': [],
            'g_loss': [],
            'gp': [],
            'w_dist': []
        }
        
        for batch_idx, (images, pattern_labels, _, defect_density) in enumerate(dataloader):
            images = images.to(gan.device)
            pattern_labels = pattern_labels.to(gan.device)
            defect_density = defect_density.to(gan.device).unsqueeze(1)
            
            # Training step
            metrics = gan.train_step(
                images, pattern_labels, defect_density,
                n_critic=n_critic, lambda_gp=lambda_gp
            )
            
            # Accumulate metrics
            for key, value in metrics.items():
                epoch_metrics[key].append(value)
        
        # Average metrics
        avg_metrics = {key: np.mean(values) for key, values in epoch_metrics.items()}
        
        # Update history
        for key, value in avg_metrics.items():
            gan.history[key].append(value)
        
        epoch_time = time.time() - epoch_start
        
        # Print progress
        print(f"Epoch [{epoch}/{num_epochs}] ({epoch_time:.1f}s) - "
              f"D Loss: {avg_metrics['d_loss']:.4f}, "
              f"G Loss: {avg_metrics['g_loss']:.4f}, "
              f"GP: {avg_metrics['gp']:.4f}, "
              f"W-Dist: {avg_metrics['w_dist']:.4f}")
        
        # Save checkpoint
        if epoch % save_interval == 0:
            checkpoint_path = f"{checkpoint_dir}/gan_epoch_{epoch}.pth"
            gan.save(checkpoint_path)
    
    # Save final model
    final_path = f"{checkpoint_dir}/gan_final.pth"
    gan.save(final_path)
    
    print("="*60)
    print("TRAINING COMPLETE")
    print("="*60)
