"""
Loss functions for wafer defect pattern recognition

Implements loss functions from AI_MODEL_ARCHITECTURE.md Section 5
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class MultiTaskLoss(nn.Module):
    """
    Multi-task loss with learnable uncertainty weighting
    
    Based on: "Multi-Task Learning Using Uncertainty to Weigh Losses"
    (Kendall et al., CVPR 2018)
    
    Automatically balances the importance of pattern classification
    and root cause classification tasks.
    """
    
    def __init__(self):
        super(MultiTaskLoss, self).__init__()
        # Learnable uncertainty parameters (log variance)
        self.log_var_pattern = nn.Parameter(torch.zeros(1))
        self.log_var_root_cause = nn.Parameter(torch.zeros(1))
    
    def forward(
        self,
        pattern_pred: torch.Tensor,
        pattern_target: torch.Tensor,
        root_cause_pred: torch.Tensor,
        root_cause_target: torch.Tensor
    ) -> tuple:
        """
        Compute multi-task loss
        
        Args:
            pattern_pred: Pattern predictions [batch_size, num_pattern_classes]
            pattern_target: Pattern labels [batch_size]
            root_cause_pred: Root cause predictions [batch_size, num_root_cause_classes]
            root_cause_target: Root cause labels [batch_size]
        
        Returns:
            tuple: (total_loss, pattern_loss, root_cause_loss)
        """
        # Pattern classification loss (Cross Entropy)
        pattern_loss = F.cross_entropy(pattern_pred, pattern_target)
        
        # Root cause classification loss (Cross Entropy)
        root_cause_loss = F.cross_entropy(root_cause_pred, root_cause_target)
        
        # Weighted combination with uncertainty
        precision_pattern = torch.exp(-self.log_var_pattern)
        precision_root_cause = torch.exp(-self.log_var_root_cause)
        
        total_loss = (
            precision_pattern * pattern_loss + self.log_var_pattern +
            precision_root_cause * root_cause_loss + self.log_var_root_cause
        )
        
        return total_loss, pattern_loss, root_cause_loss
    
    def get_task_weights(self) -> dict:
        """
        Get current task weights
        
        Returns:
            Dictionary with task weights
        """
        return {
            'pattern_weight': torch.exp(-self.log_var_pattern).item(),
            'root_cause_weight': torch.exp(-self.log_var_root_cause).item()
        }


class FocalLoss(nn.Module):
    """
    Focal Loss for addressing class imbalance
    
    Focuses on hard-to-classify examples by down-weighting
    easy examples.
    
    Based on: "Focal Loss for Dense Object Detection"
    (Lin et al., ICCV 2017)
    """
    
    def __init__(self, alpha: float = 0.25, gamma: float = 2.0, reduction: str = 'mean'):
        """
        Initialize Focal Loss
        
        Args:
            alpha: Weighting factor for class imbalance
            gamma: Focusing parameter (higher = more focus on hard examples)
            reduction: 'mean', 'sum', or 'none'
        """
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
    
    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        Compute focal loss
        
        Args:
            inputs: Predictions [batch_size, num_classes]
            targets: Labels [batch_size]
        
        Returns:
            Focal loss
        """
        # Compute cross entropy
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        
        # Compute pt (probability of true class)
        pt = torch.exp(-ce_loss)
        
        # Compute focal loss
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss
        
        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss


class MultiTaskFocalLoss(nn.Module):
    """
    Multi-task loss combining focal loss with uncertainty weighting
    
    Best of both worlds:
    - Focal loss handles class imbalance
    - Uncertainty weighting balances tasks
    """
    
    def __init__(self, alpha: float = 0.25, gamma: float = 2.0):
        """
        Initialize multi-task focal loss
        
        Args:
            alpha: Focal loss alpha parameter
            gamma: Focal loss gamma parameter
        """
        super(MultiTaskFocalLoss, self).__init__()
        self.focal_loss = FocalLoss(alpha, gamma, reduction='mean')
        self.log_var_pattern = nn.Parameter(torch.zeros(1))
        self.log_var_root_cause = nn.Parameter(torch.zeros(1))
    
    def forward(
        self,
        pattern_pred: torch.Tensor,
        pattern_target: torch.Tensor,
        root_cause_pred: torch.Tensor,
        root_cause_target: torch.Tensor
    ) -> tuple:
        """
        Compute multi-task focal loss
        
        Args:
            pattern_pred: Pattern predictions
            pattern_target: Pattern labels
            root_cause_pred: Root cause predictions
            root_cause_target: Root cause labels
        
        Returns:
            tuple: (total_loss, pattern_loss, root_cause_loss)
        """
        # Compute focal losses
        pattern_loss = self.focal_loss(pattern_pred, pattern_target)
        root_cause_loss = self.focal_loss(root_cause_pred, root_cause_target)
        
        # Weighted combination with uncertainty
        precision_pattern = torch.exp(-self.log_var_pattern)
        precision_root_cause = torch.exp(-self.log_var_root_cause)
        
        total_loss = (
            precision_pattern * pattern_loss + self.log_var_pattern +
            precision_root_cause * root_cause_loss + self.log_var_root_cause
        )
        
        return total_loss, pattern_loss, root_cause_loss
    
    def get_task_weights(self) -> dict:
        """Get current task weights"""
        return {
            'pattern_weight': torch.exp(-self.log_var_pattern).item(),
            'root_cause_weight': torch.exp(-self.log_var_root_cause).item()
        }
