"""
Training engine for wafer defect pattern recognition

Implements training methodology from AI_MODEL_ARCHITECTURE.md Section 5
"""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
import numpy as np
from pathlib import Path
from typing import Optional, Dict, Tuple
from tqdm import tqdm
import json
from datetime import datetime

from .model import WaferDefectModel, PATTERN_CLASSES, ROOT_CAUSE_CLASSES
from .loss import MultiTaskLoss, MultiTaskFocalLoss


class EarlyStopping:
    """
    Early stopping to prevent overfitting
    """
    
    def __init__(self, patience: int = 10, min_delta: float = 0.001):
        """
        Initialize early stopping
        
        Args:
            patience: Number of epochs to wait before stopping
            min_delta: Minimum change to qualify as improvement
        """
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.early_stop = False
    
    def __call__(self, val_loss: float) -> bool:
        """
        Check if training should stop
        
        Args:
            val_loss: Current validation loss
        
        Returns:
            True if should stop, False otherwise
        """
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss > self.best_loss - self.min_delta:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_loss = val_loss
            self.counter = 0
        
        return self.early_stop


class WaferTrainer:
    """
    Training engine for wafer defect pattern recognition
    
    Features:
    - Multi-task learning (pattern + root cause)
    - Mixed precision training
    - Early stopping
    - Checkpointing
    - TensorBoard logging
    - Learning rate scheduling
    """
    
    def __init__(
        self,
        model: WaferDefectModel,
        train_loader: DataLoader,
        val_loader: DataLoader,
        device: str = 'cuda',
        learning_rate: float = 1e-4,
        weight_decay: float = 1e-5,
        use_focal_loss: bool = False,
        focal_alpha: float = 0.25,
        focal_gamma: float = 2.0,
        output_dir: str = 'checkpoints',
        log_dir: str = 'logs'
    ):
        """
        Initialize trainer
        
        Args:
            model: WaferDefectModel instance
            train_loader: Training data loader
            val_loader: Validation data loader
            device: 'cuda' or 'cpu'
            learning_rate: Initial learning rate
            weight_decay: L2 regularization weight
            use_focal_loss: Use focal loss for class imbalance
            focal_alpha: Focal loss alpha parameter
            focal_gamma: Focal loss gamma parameter
            output_dir: Directory for saving checkpoints
            log_dir: Directory for TensorBoard logs
        """
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        
        # Loss function
        if use_focal_loss:
            self.criterion = MultiTaskFocalLoss(focal_alpha, focal_gamma).to(device)
        else:
            self.criterion = MultiTaskLoss().to(device)
        
        # Optimizer: AdamW (Adam with weight decay)
        self.optimizer = optim.AdamW(
            list(self.model.parameters()) + list(self.criterion.parameters()),
            lr=learning_rate,
            weight_decay=weight_decay,
            betas=(0.9, 0.999)
        )
        
        # Learning rate scheduler: Cosine Annealing with Warm Restarts
        self.scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
            self.optimizer,
            T_0=10,  # Restart every 10 epochs
            T_mult=2,  # Double restart period each time
            eta_min=1e-6
        )
        
        # Mixed precision training
        self.scaler = torch.cuda.amp.GradScaler() if device == 'cuda' else None
        
        # Output directories
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # TensorBoard writer
        self.writer = SummaryWriter(log_dir)
        
        # Training state
        self.current_epoch = 0
        self.best_val_acc = 0.0
        self.best_val_loss = float('inf')
        self.train_history = []
        self.val_history = []
    
    def train_epoch(self) -> Dict[str, float]:
        """
        Train for one epoch
        
        Returns:
            Dictionary with training metrics
        """
        self.model.train()
        
        total_loss = 0.0
        pattern_loss_sum = 0.0
        root_cause_loss_sum = 0.0
        pattern_correct = 0
        root_cause_correct = 0
        total_samples = 0
        
        pbar = tqdm(self.train_loader, desc=f'Epoch {self.current_epoch + 1} [Train]')
        
        for batch_idx, (images, pattern_labels, root_cause_labels) in enumerate(pbar):
            images = images.to(self.device)
            pattern_labels = pattern_labels.to(self.device)
            root_cause_labels = root_cause_labels.to(self.device)
            
            self.optimizer.zero_grad()
            
            # Mixed precision forward pass
            if self.scaler:
                with torch.cuda.amp.autocast():
                    pattern_pred, root_cause_pred = self.model(images)
                    loss, pattern_loss, root_cause_loss = self.criterion(
                        pattern_pred, pattern_labels,
                        root_cause_pred, root_cause_labels
                    )
                
                # Backward pass with gradient scaling
                self.scaler.scale(loss).backward()
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                # Standard training
                pattern_pred, root_cause_pred = self.model(images)
                loss, pattern_loss, root_cause_loss = self.criterion(
                    pattern_pred, pattern_labels,
                    root_cause_pred, root_cause_labels
                )
                loss.backward()
                self.optimizer.step()
            
            # Calculate accuracy
            pattern_correct += (pattern_pred.argmax(1) == pattern_labels).sum().item()
            root_cause_correct += (root_cause_pred.argmax(1) == root_cause_labels).sum().item()
            total_samples += images.size(0)
            
            # Accumulate losses
            total_loss += loss.item()
            pattern_loss_sum += pattern_loss.item()
            root_cause_loss_sum += root_cause_loss.item()
            
            # Update progress bar
            pbar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'p_acc': f'{pattern_correct/total_samples:.3f}',
                'r_acc': f'{root_cause_correct/total_samples:.3f}'
            })
        
        # Calculate epoch metrics
        metrics = {
            'loss': total_loss / len(self.train_loader),
            'pattern_loss': pattern_loss_sum / len(self.train_loader),
            'root_cause_loss': root_cause_loss_sum / len(self.train_loader),
            'pattern_accuracy': pattern_correct / total_samples,
            'root_cause_accuracy': root_cause_correct / total_samples
        }
        
        return metrics

    
    @torch.no_grad()
    def validate_epoch(self) -> Dict[str, float]:
        """
        Validate for one epoch
        
        Returns:
            Dictionary with validation metrics
        """
        self.model.eval()
        
        total_loss = 0.0
        pattern_loss_sum = 0.0
        root_cause_loss_sum = 0.0
        pattern_correct = 0
        root_cause_correct = 0
        total_samples = 0
        
        pbar = tqdm(self.val_loader, desc=f'Epoch {self.current_epoch + 1} [Val]')
        
        for images, pattern_labels, root_cause_labels in pbar:
            images = images.to(self.device)
            pattern_labels = pattern_labels.to(self.device)
            root_cause_labels = root_cause_labels.to(self.device)
            
            # Forward pass
            pattern_pred, root_cause_pred = self.model(images)
            loss, pattern_loss, root_cause_loss = self.criterion(
                pattern_pred, pattern_labels,
                root_cause_pred, root_cause_labels
            )
            
            # Calculate accuracy
            pattern_correct += (pattern_pred.argmax(1) == pattern_labels).sum().item()
            root_cause_correct += (root_cause_pred.argmax(1) == root_cause_labels).sum().item()
            total_samples += images.size(0)
            
            # Accumulate losses
            total_loss += loss.item()
            pattern_loss_sum += pattern_loss.item()
            root_cause_loss_sum += root_cause_loss.item()
            
            # Update progress bar
            pbar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'p_acc': f'{pattern_correct/total_samples:.3f}',
                'r_acc': f'{root_cause_correct/total_samples:.3f}'
            })
        
        # Calculate epoch metrics
        metrics = {
            'loss': total_loss / len(self.val_loader),
            'pattern_loss': pattern_loss_sum / len(self.val_loader),
            'root_cause_loss': root_cause_loss_sum / len(self.val_loader),
            'pattern_accuracy': pattern_correct / total_samples,
            'root_cause_accuracy': root_cause_correct / total_samples
        }
        
        return metrics
    
    def train(
        self,
        epochs: int,
        early_stopping_patience: int = 15,
        save_best_only: bool = True
    ) -> Dict[str, list]:
        """
        Train the model
        
        Args:
            epochs: Number of epochs to train
            early_stopping_patience: Patience for early stopping
            save_best_only: Only save best model
        
        Returns:
            Training history
        """
        early_stopping = EarlyStopping(patience=early_stopping_patience)
        
        print(f"\n{'='*80}")
        print(f"Starting training for {epochs} epochs")
        print(f"Device: {self.device}")
        print(f"Model parameters: {sum(p.numel() for p in self.model.parameters()):,}")
        print(f"{'='*80}\n")
        
        for epoch in range(epochs):
            self.current_epoch = epoch
            
            # Train epoch
            train_metrics = self.train_epoch()
            self.train_history.append(train_metrics)
            
            # Validate epoch
            val_metrics = self.validate_epoch()
            self.val_history.append(val_metrics)
            
            # Update learning rate
            self.scheduler.step()
            current_lr = self.optimizer.param_groups[0]['lr']
            
            # Log to TensorBoard
            self._log_metrics(train_metrics, val_metrics, current_lr)
            
            # Print epoch summary
            print(f"\nEpoch {epoch + 1}/{epochs}")
            print(f"  Train - Loss: {train_metrics['loss']:.4f}, "
                  f"Pattern Acc: {train_metrics['pattern_accuracy']:.3f}, "
                  f"Root Cause Acc: {train_metrics['root_cause_accuracy']:.3f}")
            print(f"  Val   - Loss: {val_metrics['loss']:.4f}, "
                  f"Pattern Acc: {val_metrics['pattern_accuracy']:.3f}, "
                  f"Root Cause Acc: {val_metrics['root_cause_accuracy']:.3f}")
            print(f"  LR: {current_lr:.6f}")
            
            # Save checkpoint
            is_best = val_metrics['pattern_accuracy'] > self.best_val_acc
            if is_best:
                self.best_val_acc = val_metrics['pattern_accuracy']
                self.best_val_loss = val_metrics['loss']
            
            if not save_best_only or is_best:
                self.save_checkpoint(epoch, val_metrics, is_best)
            
            # Early stopping
            if early_stopping(val_metrics['loss']):
                print(f"\nEarly stopping triggered at epoch {epoch + 1}")
                break
        
        print(f"\n{'='*80}")
        print(f"Training completed!")
        print(f"Best validation accuracy: {self.best_val_acc:.3f}")
        print(f"{'='*80}\n")
        
        return {
            'train': self.train_history,
            'val': self.val_history
        }
    
    def save_checkpoint(
        self,
        epoch: int,
        metrics: Dict[str, float],
        is_best: bool = False
    ):
        """
        Save model checkpoint
        
        Args:
            epoch: Current epoch
            metrics: Validation metrics
            is_best: Whether this is the best model so far
        """
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'criterion_state_dict': self.criterion.state_dict(),
            'metrics': metrics,
            'best_val_acc': self.best_val_acc,
            'best_val_loss': self.best_val_loss,
            'pattern_classes': PATTERN_CLASSES,
            'root_cause_classes': ROOT_CAUSE_CLASSES,
            'timestamp': datetime.now().isoformat()
        }
        
        # Save regular checkpoint
        checkpoint_path = self.output_dir / f'checkpoint_epoch_{epoch + 1}.pth'
        torch.save(checkpoint, checkpoint_path)
        print(f"  Saved checkpoint: {checkpoint_path}")
        
        # Save best model
        if is_best:
            best_path = self.output_dir / 'best_model.pth'
            torch.save(checkpoint, best_path)
            print(f"  ⭐ Saved best model: {best_path}")
    
    def _log_metrics(
        self,
        train_metrics: Dict[str, float],
        val_metrics: Dict[str, float],
        learning_rate: float
    ):
        """Log metrics to TensorBoard"""
        epoch = self.current_epoch
        
        # Losses
        self.writer.add_scalars('Loss/total', {
            'train': train_metrics['loss'],
            'val': val_metrics['loss']
        }, epoch)
        
        self.writer.add_scalars('Loss/pattern', {
            'train': train_metrics['pattern_loss'],
            'val': val_metrics['pattern_loss']
        }, epoch)
        
        self.writer.add_scalars('Loss/root_cause', {
            'train': train_metrics['root_cause_loss'],
            'val': val_metrics['root_cause_loss']
        }, epoch)
        
        # Accuracies
        self.writer.add_scalars('Accuracy/pattern', {
            'train': train_metrics['pattern_accuracy'],
            'val': val_metrics['pattern_accuracy']
        }, epoch)
        
        self.writer.add_scalars('Accuracy/root_cause', {
            'train': train_metrics['root_cause_accuracy'],
            'val': val_metrics['root_cause_accuracy']
        }, epoch)
        
        # Learning rate
        self.writer.add_scalar('Learning_Rate', learning_rate, epoch)
        
        # Task weights (if using multi-task loss)
        if hasattr(self.criterion, 'get_task_weights'):
            weights = self.criterion.get_task_weights()
            self.writer.add_scalars('Task_Weights', weights, epoch)
    
    def load_checkpoint(self, checkpoint_path: str):
        """
        Load model from checkpoint
        
        Args:
            checkpoint_path: Path to checkpoint file
        """
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        self.criterion.load_state_dict(checkpoint['criterion_state_dict'])
        
        self.current_epoch = checkpoint['epoch']
        self.best_val_acc = checkpoint['best_val_acc']
        self.best_val_loss = checkpoint['best_val_loss']
        
        print(f"Loaded checkpoint from epoch {self.current_epoch + 1}")
        print(f"Best validation accuracy: {self.best_val_acc:.3f}")
