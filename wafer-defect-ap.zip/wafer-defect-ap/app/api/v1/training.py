"""
Training-related endpoints for wafer ingestion
"""
from flask import request, jsonify, current_app
from werkzeug.utils import secure_filename
from app.api.v1 import api_v1_bp
from app.utils.json_storage import JSONStorage
from app.utils.data_init import validate_lot_id, validate_wafer_id
import os
import uuid
from datetime import datetime


@api_v1_bp.route('/training/ingest', methods=['POST'])
def ingest_training_wafers():
    """
    Ingest wafer data for training
    This endpoint handles batch uploads from the training interface
    
    Request:
        - image_files: Multiple image files
        - lot_id: Lot ID from batch metadata
        - process_step: Process step from batch metadata
        - equipment_id: Equipment ID from batch metadata
    
    Returns:
        JSON response with ingestion status
    """
    try:
        # Get batch metadata from form
        lot_id = request.form.get('lot_id', '')
        process_step = request.form.get('process_step', '')
        equipment_id = request.form.get('equipment_id', '')
        
        # Validate lot_id if provided
        if lot_id and not validate_lot_id(lot_id):
            return jsonify({'error': f'Invalid LotID format. Expected: M93242.00 (9 characters)'}), 400
        
        # Get uploaded files
        if 'files' not in request.files and 'image_files' not in request.files:
            return jsonify({'error': 'No files provided'}), 400
        
        # Handle both 'files' and 'image_files' keys
        files = request.files.getlist('files') or request.files.getlist('image_files')
        
        if not files or len(files) == 0:
            return jsonify({'error': 'No files selected'}), 400
        
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        uploaded_wafers = []
        errors = []
        
        # Process each file
        for idx, file in enumerate(files):
            if file.filename == '':
                continue
            
            try:
                # Generate wafer_id from lot_id if provided, otherwise auto-generate
                if lot_id:
                    # Extract lot number from lot_id (e.g., M93242.00 -> 93242)
                    lot_number = lot_id[1:6]
                    wafer_number = idx + 1
                    if wafer_number > 25:
                        errors.append(f"File {file.filename}: Wafer number exceeds 25")
                        continue
                    wafer_id = f"M{lot_number}.{wafer_number:02d}"
                else:
                    # Auto-generate lot_id and wafer_id
                    import random
                    lot_number = random.randint(10000, 99999)
                    wafer_id = f"M{lot_number}.{idx+1:02d}"
                    lot_id = f"M{lot_number}.00"
                
                # Validate wafer_id
                if not validate_wafer_id(wafer_id):
                    errors.append(f"File {file.filename}: Invalid WaferID {wafer_id}")
                    continue
                
                # Save image file
                image_filename = secure_filename(f"{wafer_id}_{file.filename}")
                image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], image_filename)
                file.save(image_path)
                
                # Generate job_id
                job_id = str(uuid.uuid4())
                
                # Create wafer record
                wafer_record = {
                    'job_id': job_id,
                    'lot_id': lot_id,
                    'wafer_id': wafer_id,
                    'tool_id': equipment_id or '',
                    'scan_time': datetime.utcnow().isoformat(),
                    'process_step': process_step or '',
                    'defect_count': 0,  # Will be calculated later
                    'image_path': image_path,
                    'image_filename': image_filename,
                    'status': 'ingested',
                    'upload_time': datetime.utcnow().isoformat(),
                    'metadata': {
                        'batch_upload': True,
                        'equipment_id': equipment_id,
                        'original_filename': file.filename
                    }
                }
                
                # Save to JSON storage
                storage.append('wafers.json', wafer_record)
                
                uploaded_wafers.append({
                    'wafer_id': wafer_id,
                    'filename': image_filename,
                    'status': 'success'
                })
                
            except Exception as e:
                errors.append(f"File {file.filename}: {str(e)}")
                current_app.logger.error(f"Error processing file {file.filename}: {str(e)}")
        
        # Auto-create training job if wafers were uploaded successfully
        training_job_id = None
        if len(uploaded_wafers) > 0:
            try:
                # Generate training job ID
                training_job_id = str(uuid.uuid4())
                
                # Create default training configuration
                config = {
                    'model_architecture': 'efficientnet-b3',
                    'epochs': 100,
                    'batch_size': 32,
                    'learning_rate': 0.0001,
                    'dataset_filter': {
                        'lot_ids': [lot_id] if lot_id else [],
                        'wafer_ids': [w['wafer_id'] for w in uploaded_wafers]
                    }
                }
                
                # Create training job record
                training_job = {
                    'job_id': training_job_id,
                    'status': 'queued',
                    'priority': 'normal',
                    'config': config,
                    'start_time': None,
                    'queued_at': datetime.utcnow().isoformat(),
                    'current_epoch': 0,
                    'total_epochs': config['epochs'],
                    'metrics': {
                        'loss': 0.0,
                        'accuracy': 0.0,
                        'val_loss': 0.0,
                        'val_accuracy': 0.0
                    },
                    'estimated_duration_minutes': config['epochs'] * 2,
                    'wafer_count': len(uploaded_wafers),
                    'lot_id': lot_id
                }
                
                # Save to JSON storage
                storage.append('training_jobs.json', training_job)
                
                current_app.logger.info(f"Auto-created training job: {training_job_id} for {len(uploaded_wafers)} wafers")
                
            except Exception as e:
                current_app.logger.error(f"Failed to auto-create training job: {str(e)}")
                # Don't fail the upload if training job creation fails
        
        # Prepare response
        response = {
            'status': 'success' if len(uploaded_wafers) > 0 else 'error',
            'uploaded_count': len(uploaded_wafers),
            'error_count': len(errors),
            'wafers': uploaded_wafers,
            'training_job_id': training_job_id
        }
        
        if errors:
            response['errors'] = errors
        
        return jsonify(response), 200 if len(uploaded_wafers) > 0 else 400
    
    except Exception as e:
        current_app.logger.error(f"Ingest error: {str(e)}")
        return jsonify({'error': f'Ingestion failed: {str(e)}'}), 500


@api_v1_bp.route('/training/wafers', methods=['GET'])
def list_training_wafers():
    """
    List all wafers available for training
    
    Returns:
        JSON response with list of training wafers
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get all wafers
        wafers = storage.find('wafers.json')
        
        # Filter for training wafers (status: ingested or uploaded)
        training_wafers = [
            w for w in wafers 
            if w.get('status') in ['ingested', 'uploaded']
        ]
        
        return jsonify({
            'status': 'success',
            'count': len(training_wafers),
            'wafers': training_wafers
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"List training wafers error: {str(e)}")
        return jsonify({'error': f'Failed to list training wafers: {str(e)}'}), 500



@api_v1_bp.route('/training/start', methods=['POST'])
def start_training():
    """
    Start model training job
    
    Request:
        {
            "model_architecture": "efficientnet-b3",
            "epochs": 100,
            "batch_size": 32,
            "learning_rate": 0.0001,
            "dataset_filter": {
                "lot_ids": ["M93242.00"],
                "date_range": ["2024-01-01", "2024-01-31"]
            }
        }
    
    Returns:
        JSON response with job_id and status
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data:
            return jsonify({'error': 'No training configuration provided'}), 400
        
        # Generate training job ID
        job_id = str(uuid.uuid4())
        
        # Get training configuration
        config = {
            'model_architecture': data.get('model_architecture', 'efficientnet-b3'),
            'epochs': data.get('epochs', 100),
            'batch_size': data.get('batch_size', 32),
            'learning_rate': data.get('learning_rate', 0.0001),
            'dataset_filter': data.get('dataset_filter', {})
        }
        
        # Get priority (default: normal)
        priority = data.get('priority', 'normal')
        if priority not in ['high', 'normal', 'low']:
            priority = 'normal'
        
        # Create training job record
        training_job = {
            'job_id': job_id,
            'status': 'queued',  # Start as queued
            'priority': priority,
            'config': config,
            'start_time': None,  # Will be set when actually started
            'queued_at': datetime.utcnow().isoformat(),
            'current_epoch': 0,
            'total_epochs': config['epochs'],
            'metrics': {
                'loss': 0.0,
                'accuracy': 0.0,
                'val_loss': 0.0,
                'val_accuracy': 0.0
            },
            'estimated_duration_minutes': config['epochs'] * 2  # Rough estimate
        }
        
        # Save to JSON storage
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        storage.append('training_jobs.json', training_job)
        
        current_app.logger.info(f"Training job queued: {job_id} with priority: {priority}")
        
        return jsonify({
            'status': 'queued',
            'job_id': job_id,
            'priority': priority,
            'estimated_duration_minutes': training_job['estimated_duration_minutes'],
            'message': 'Training job queued successfully'
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Start training error: {str(e)}")
        return jsonify({'error': f'Failed to start training: {str(e)}'}), 500


@api_v1_bp.route('/training/status/<job_id>', methods=['GET'])
def get_training_status(job_id):
    """
    Get training job status
    
    Returns:
        JSON response with training progress and metrics
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Find training job
        job = storage.find_one('training_jobs.json', job_id=job_id)
        
        if not job:
            return jsonify({'error': 'Training job not found'}), 404
        
        # Calculate progress percentage
        progress = (job.get('current_epoch', 0) / job.get('total_epochs', 1)) * 100
        
        return jsonify({
            'status': 'success',
            'job_id': job_id,
            'training_status': job.get('status', 'unknown'),
            'progress': round(progress, 2),
            'current_epoch': job.get('current_epoch', 0),
            'total_epochs': job.get('total_epochs', 0),
            'metrics': job.get('metrics', {}),
            'start_time': job.get('start_time'),
            'end_time': job.get('end_time'),
            'estimated_time_remaining': job.get('estimated_time_remaining', 0)
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Get training status error: {str(e)}")
        return jsonify({'error': f'Failed to get training status: {str(e)}'}), 500


@api_v1_bp.route('/training/stop/<job_id>', methods=['POST'])
def stop_training(job_id):
    """
    Stop training job
    
    Returns:
        JSON response with stop status
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Find and update training job
        job = storage.find_one('training_jobs.json', job_id=job_id)
        
        if not job:
            return jsonify({'error': 'Training job not found'}), 404
        
        # Update job status
        updates = {
            'status': 'stopped',
            'end_time': datetime.utcnow().isoformat()
        }
        
        storage.update('training_jobs.json', job['id'], updates)
        
        current_app.logger.info(f"Training job stopped: {job_id}")
        
        return jsonify({
            'status': 'success',
            'job_id': job_id,
            'message': 'Training job stopped successfully',
            'final_metrics': job.get('metrics', {})
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Stop training error: {str(e)}")
        return jsonify({'error': f'Failed to stop training: {str(e)}'}), 500


@api_v1_bp.route('/training/models', methods=['GET'])
def list_models():
    """
    List all trained models
    
    Returns:
        JSON response with list of models
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get all models
        models = storage.find('models.json')
        
        return jsonify({
            'status': 'success',
            'count': len(models),
            'models': models
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"List models error: {str(e)}")
        return jsonify({'error': f'Failed to list models: {str(e)}'}), 500


@api_v1_bp.route('/training/model/<version>', methods=['GET'])
def get_model_details(version):
    """
    Get model details by version
    
    Returns:
        JSON response with model details
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Find model by version
        model = storage.find_one('models.json', version=version)
        
        if not model:
            return jsonify({'error': 'Model not found'}), 404
        
        return jsonify({
            'status': 'success',
            'model': model
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Get model details error: {str(e)}")
        return jsonify({'error': f'Failed to get model details: {str(e)}'}), 500



@api_v1_bp.route('/training/queue', methods=['GET'])
def get_training_queue():
    """
    Get all training jobs in queue
    
    Query Parameters:
        - status: Filter by status (queued, running, completed, failed, stopped)
        - limit: Number of results (default: 50)
    
    Returns:
        JSON response with training job queue
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get query parameters
        status_filter = request.args.get('status')
        limit = int(request.args.get('limit', 50))
        
        # Get all training jobs
        jobs = storage.find('training_jobs.json')
        
        # Filter by status if provided
        if status_filter:
            jobs = [j for j in jobs if j.get('status') == status_filter]
        
        # FIFO Queue with Priority Sorting
        # Priority order: high > normal > low
        # Within same priority: FIFO (earliest queued_at first)
        priority_order = {'high': 0, 'normal': 1, 'low': 2}
        
        def sort_key(job):
            # Get priority (default to 'normal' if not set)
            priority = job.get('priority', 'normal')
            priority_rank = priority_order.get(priority, 1)
            
            # Get queued_at timestamp (use empty string if not set, will sort last)
            queued_at = job.get('queued_at', '')
            
            # Return tuple: (priority_rank, queued_at)
            # Lower priority_rank comes first, earlier queued_at comes first
            return (priority_rank, queued_at)
        
        # Sort by priority first, then by queued_at (FIFO within same priority)
        jobs.sort(key=sort_key)
        
        # Limit results
        jobs = jobs[:limit]
        
        # Calculate queue statistics
        all_jobs = storage.find('training_jobs.json')
        stats = {
            'total': len(all_jobs),
            'queued': len([j for j in all_jobs if j.get('status') == 'queued']),
            'running': len([j for j in all_jobs if j.get('status') == 'running']),
            'completed': len([j for j in all_jobs if j.get('status') == 'completed']),
            'failed': len([j for j in all_jobs if j.get('status') == 'failed']),
            'stopped': len([j for j in all_jobs if j.get('status') == 'stopped'])
        }
        
        return jsonify({
            'status': 'success',
            'count': len(jobs),
            'statistics': stats,
            'jobs': jobs
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Get training queue error: {str(e)}")
        return jsonify({'error': f'Failed to get training queue: {str(e)}'}), 500


@api_v1_bp.route('/training/queue/<job_id>/cancel', methods=['POST'])
def cancel_training_job(job_id):
    """
    Cancel a training job in queue
    
    Returns:
        JSON response with cancellation status
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Find training job
        job = storage.find_one('training_jobs.json', job_id=job_id)
        
        if not job:
            return jsonify({'error': 'Training job not found'}), 404
        
        # Check if job can be cancelled
        if job.get('status') in ['completed', 'failed']:
            return jsonify({'error': f'Cannot cancel {job.get("status")} job'}), 400
        
        # Update job status
        updates = {
            'status': 'cancelled',
            'end_time': datetime.utcnow().isoformat(),
            'cancelled_at': datetime.utcnow().isoformat()
        }
        
        storage.update('training_jobs.json', job['id'], updates)
        
        current_app.logger.info(f"Training job cancelled: {job_id}")
        
        return jsonify({
            'status': 'success',
            'job_id': job_id,
            'message': 'Training job cancelled successfully'
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Cancel training job error: {str(e)}")
        return jsonify({'error': f'Failed to cancel training job: {str(e)}'}), 500


@api_v1_bp.route('/training/queue/<job_id>/requeue', methods=['POST'])
def requeue_training_job(job_id):
    """
    Requeue a failed or stopped training job
    
    Returns:
        JSON response with requeue status
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Find training job
        job = storage.find_one('training_jobs.json', job_id=job_id)
        
        if not job:
            return jsonify({'error': 'Training job not found'}), 404
        
        # Check if job can be requeued
        if job.get('status') not in ['failed', 'stopped', 'cancelled']:
            return jsonify({'error': f'Cannot requeue {job.get("status")} job'}), 400
        
        # Update job status
        updates = {
            'status': 'queued',
            'requeued_at': datetime.utcnow().isoformat(),
            'current_epoch': 0,
            'end_time': None
        }
        
        storage.update('training_jobs.json', job['id'], updates)
        
        current_app.logger.info(f"Training job requeued: {job_id}")
        
        return jsonify({
            'status': 'success',
            'job_id': job_id,
            'message': 'Training job requeued successfully'
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Requeue training job error: {str(e)}")
        return jsonify({'error': f'Failed to requeue training job: {str(e)}'}), 500


@api_v1_bp.route('/training/queue/<job_id>/priority', methods=['PUT'])
def update_job_priority(job_id):
    """
    Update training job priority
    
    Request:
        {
            "priority": "high" | "normal" | "low"
        }
    
    Returns:
        JSON response with update status
    """
    try:
        data = request.get_json()
        
        if not data or 'priority' not in data:
            return jsonify({'error': 'Priority not provided'}), 400
        
        priority = data['priority']
        if priority not in ['high', 'normal', 'low']:
            return jsonify({'error': 'Invalid priority. Must be: high, normal, or low'}), 400
        
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Find training job
        job = storage.find_one('training_jobs.json', job_id=job_id)
        
        if not job:
            return jsonify({'error': 'Training job not found'}), 404
        
        # Update job priority
        updates = {
            'priority': priority,
            'priority_updated_at': datetime.utcnow().isoformat()
        }
        
        storage.update('training_jobs.json', job['id'], updates)
        
        current_app.logger.info(f"Training job priority updated: {job_id} -> {priority}")
        
        return jsonify({
            'status': 'success',
            'job_id': job_id,
            'priority': priority,
            'message': 'Job priority updated successfully'
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Update job priority error: {str(e)}")
        return jsonify({'error': f'Failed to update job priority: {str(e)}'}), 500


@api_v1_bp.route('/training/queue/<job_id>', methods=['DELETE'])
def delete_training_job(job_id):
    """
    Delete a training job from queue
    
    Returns:
        JSON response with deletion status
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Find training job
        job = storage.find_one('training_jobs.json', job_id=job_id)
        
        if not job:
            return jsonify({'error': 'Training job not found'}), 404
        
        # Check if job can be deleted
        if job.get('status') == 'running':
            return jsonify({'error': 'Cannot delete running job. Stop it first.'}), 400
        
        # Delete job
        deleted = storage.delete('training_jobs.json', job['id'])
        
        if deleted:
            current_app.logger.info(f"Training job deleted: {job_id}")
            return jsonify({
                'status': 'success',
                'job_id': job_id,
                'message': 'Training job deleted successfully'
            }), 200
        else:
            return jsonify({'error': 'Failed to delete training job'}), 500
    
    except Exception as e:
        current_app.logger.error(f"Delete training job error: {str(e)}")
        return jsonify({'error': f'Failed to delete training job: {str(e)}'}), 500


@api_v1_bp.route('/training/queue/statistics', methods=['GET'])
def get_queue_statistics():
    """
    Get training queue statistics
    
    Returns:
        JSON response with queue statistics and metrics
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get all training jobs
        jobs = storage.find('training_jobs.json')
        
        # Calculate statistics
        stats = {
            'total_jobs': len(jobs),
            'by_status': {
                'queued': len([j for j in jobs if j.get('status') == 'queued']),
                'running': len([j for j in jobs if j.get('status') == 'running']),
                'completed': len([j for j in jobs if j.get('status') == 'completed']),
                'failed': len([j for j in jobs if j.get('status') == 'failed']),
                'stopped': len([j for j in jobs if j.get('status') == 'stopped']),
                'cancelled': len([j for j in jobs if j.get('status') == 'cancelled'])
            },
            'by_priority': {
                'high': len([j for j in jobs if j.get('priority') == 'high']),
                'normal': len([j for j in jobs if j.get('priority') == 'normal']),
                'low': len([j for j in jobs if j.get('priority') == 'low'])
            },
            'average_duration_minutes': 0,
            'success_rate': 0
        }
        
        # Calculate average duration for completed jobs
        completed_jobs = [j for j in jobs if j.get('status') == 'completed' and j.get('start_time') and j.get('end_time')]
        if completed_jobs:
            from datetime import datetime as dt
            durations = []
            for job in completed_jobs:
                try:
                    start = dt.fromisoformat(job['start_time'])
                    end = dt.fromisoformat(job['end_time'])
                    duration = (end - start).total_seconds() / 60  # minutes
                    durations.append(duration)
                except:
                    pass
            if durations:
                stats['average_duration_minutes'] = round(sum(durations) / len(durations), 2)
        
        # Calculate success rate
        finished_jobs = len([j for j in jobs if j.get('status') in ['completed', 'failed']])
        if finished_jobs > 0:
            stats['success_rate'] = round((stats['by_status']['completed'] / finished_jobs) * 100, 2)
        
        return jsonify({
            'status': 'success',
            'statistics': stats
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Get queue statistics error: {str(e)}")
        return jsonify({'error': f'Failed to get queue statistics: {str(e)}'}), 500


@api_v1_bp.route('/training/logs/<job_id>', methods=['GET'])
def get_training_logs(job_id):
    """
    Get training logs for a specific job
    
    Logic:
    - For completed/failed jobs: Return job-specific log file (logs/{job_id}.log)
    - For running jobs: Return current training log (logs/training_current.log)
    - For queued jobs: Return "waiting to start" message
    
    Query Parameters:
        - lines: Number of recent lines to return (default: all)
        - offset: Offset for pagination (default: 0)
    
    Returns:
        Plain text log content
    """
    try:
        import os
        import json
        
        # Get query parameters
        lines = request.args.get('lines', type=int)
        offset = int(request.args.get('offset', 0))
        
        # First, check if job exists and get its status
        jobs_file = os.path.join(current_app.config['METADATA_FOLDER'], 'training_jobs.json')
        
        if not os.path.exists(jobs_file):
            return 'Training jobs file not found', 404
        
        with open(jobs_file, 'r') as f:
            jobs = json.load(f)
        
        # Find the job
        job = None
        for j in jobs:
            if j.get('job_id') == job_id:
                job = j
                break
        
        if not job:
            return f'Job {job_id} not found', 404
        
        status = job.get('status', 'unknown')
        
        # Determine which log file to use
        if status in ['completed', 'failed', 'stopped', 'cancelled']:
            # Use job-specific log file
            log_file = os.path.join(current_app.config['BASE_DIR'], 'logs', f'{job_id}.log')
        elif status == 'running':
            # Use current training log
            log_file = os.path.join(current_app.config['BASE_DIR'], 'logs', 'training_current.log')
        else:
            # Queued or other status - no logs yet
            return f"Job {job_id} is {status}. Training has not started yet.", 200
        
        if not os.path.exists(log_file):
            return f'Log file not found for job {job_id}', 404
        
        # Read log file
        with open(log_file, 'r', encoding='utf-8') as f:
            all_lines = f.readlines()
        
        total_lines = len(all_lines)
        
        # Get requested lines with offset
        if lines:
            start_idx = max(0, total_lines - lines - offset)
            end_idx = total_lines - offset if offset > 0 else total_lines
            log_lines = all_lines[start_idx:end_idx]
        else:
            # Return all lines
            log_lines = all_lines
        
        # Return as plain text
        return ''.join(log_lines), 200, {'Content-Type': 'text/plain; charset=utf-8'}
    
    except Exception as e:
        current_app.logger.error(f"Get training logs error: {str(e)}")
        return f'Failed to get training logs: {str(e)}', 500


@api_v1_bp.route('/training/metrics/<job_id>', methods=['GET'])
def get_training_metrics(job_id):
    """
    Get detailed training metrics for a specific job
    
    Logic:
    - For completed/failed jobs: Load from logs/{job_id}_status.json
    - For running jobs: Load from logs/training_status.json
    - For queued jobs: Return basic job info from training_jobs.json
    
    Returns:
        JSON response with comprehensive training metrics
    """
    try:
        import os
        import json
        
        # First, check if job exists and get its status
        jobs_file = os.path.join(current_app.config['METADATA_FOLDER'], 'training_jobs.json')
        
        if not os.path.exists(jobs_file):
            return jsonify({'error': 'Training jobs file not found'}), 404
        
        with open(jobs_file, 'r') as f:
            jobs = json.load(f)
        
        # Find the job
        job = None
        for j in jobs:
            if j.get('job_id') == job_id:
                job = j
                break
        
        if not job:
            return jsonify({'error': f'Job {job_id} not found'}), 404
        
        status_value = job.get('status', 'unknown')
        
        # Determine which metrics file to use
        if status_value in ['completed', 'failed', 'stopped', 'cancelled']:
            # Try job-specific metrics file first
            metrics_file = os.path.join(current_app.config['BASE_DIR'], 'logs', f'{job_id}_status.json')
            if not os.path.exists(metrics_file):
                # Fall back to training_status.json if job_id matches
                metrics_file = os.path.join(current_app.config['BASE_DIR'], 'logs', 'training_status.json')
        elif status_value == 'running':
            # Use current training status
            metrics_file = os.path.join(current_app.config['BASE_DIR'], 'logs', 'training_status.json')
        else:
            # Queued - return basic job info
            return jsonify({
                'status': 'success',
                'job_id': job_id,
                'training_status': status_value,
                'progress': {
                    'current_epoch': 0,
                    'total_epochs': job.get('total_epochs', 0),
                    'percentage': 0.0,
                    'estimated_time_remaining_minutes': job.get('estimated_duration_minutes', 0)
                },
                'current_metrics': job.get('metrics', {}),
                'model_info': {
                    'architecture': job.get('config', {}).get('model_architecture', 'unknown'),
                    'batch_size': job.get('config', {}).get('batch_size', 0),
                    'learning_rate': job.get('config', {}).get('learning_rate', 0)
                },
                'timestamps': {
                    'queued_at': job.get('queued_at'),
                    'start_time': job.get('start_time'),
                    'end_time': job.get('end_time')
                }
            }), 200
        
        if not os.path.exists(metrics_file):
            return jsonify({'error': f'Metrics file not found for job {job_id}'}), 404
        
        with open(metrics_file, 'r') as f:
            status = json.load(f)
        
        # Verify this is the correct job
        if status.get('job_id') != job_id:
            # Metrics file doesn't match - return job data instead
            return jsonify({
                'status': 'success',
                'job_id': job_id,
                'training_status': status_value,
                'progress': {
                    'current_epoch': job.get('current_epoch', 0),
                    'total_epochs': job.get('total_epochs', 0),
                    'percentage': (job.get('current_epoch', 0) / max(job.get('total_epochs', 1), 1)) * 100,
                    'estimated_time_remaining_minutes': 0
                },
                'current_metrics': job.get('metrics', {}),
                'model_info': {
                    'architecture': job.get('config', {}).get('model_architecture', 'unknown'),
                    'batch_size': job.get('config', {}).get('batch_size', 0)
                },
                'timestamps': {
                    'start_time': job.get('start_time'),
                    'end_time': job.get('end_time')
                }
            }), 200
        
        # Calculate progress
        current_epoch = status.get('current_epoch', 0)
        total_epochs = status.get('total_epochs', 1)
        progress = (current_epoch / total_epochs) * 100
        
        # Estimate time remaining (if still running)
        estimated_time_remaining = 0
        if status.get('status') == 'running' and status.get('start_time'):
            from datetime import datetime as dt
            start = dt.fromisoformat(status['start_time'])
            now = dt.utcnow()
            elapsed_minutes = (now - start).total_seconds() / 60
            if current_epoch > 0:
                avg_time_per_epoch = elapsed_minutes / current_epoch
                remaining_epochs = total_epochs - current_epoch
                estimated_time_remaining = avg_time_per_epoch * remaining_epochs
        
        # Build comprehensive response
        response = {
            'status': 'success',
            'job_id': status.get('job_id', job_id),
            'training_status': status.get('status', 'unknown'),
            'progress': {
                'current_epoch': current_epoch,
                'total_epochs': total_epochs,
                'percentage': round(progress, 2),
                'estimated_time_remaining_minutes': round(estimated_time_remaining, 2)
            },
            'current_metrics': status.get('current_metrics', {}),
            'best_metrics': status.get('best_metrics', {}),
            'metrics_history': status.get('metrics_history', []),
            'model_info': {
                'architecture': status.get('model_architecture', 'unknown'),
                'batch_size': status.get('batch_size', 0),
                'dataset_size': status.get('dataset_size', 0),
                'total_parameters': 11684154
            },
            'timestamps': {
                'start_time': status.get('start_time'),
                'end_time': status.get('end_time'),
                'last_updated': status.get('end_time', datetime.utcnow().isoformat())
            }
        }
        
        return jsonify(response), 200
    
    except Exception as e:
        current_app.logger.error(f"Get training metrics error: {str(e)}")
        return jsonify({'error': f'Failed to get training metrics: {str(e)}'}), 500


@api_v1_bp.route('/training/metrics/<job_id>/tensorboard', methods=['GET'])
def get_tensorboard_data(job_id):
    """
    Get TensorBoard data for visualization
    
    Returns:
        JSON response with TensorBoard metrics formatted for charts
    """
    try:
        import os
        from tensorboard.backend.event_processing import event_accumulator
        
        # TensorBoard logs directory
        logs_dir = os.path.join(current_app.config['BASE_DIR'], 'logs')
        
        if not os.path.exists(logs_dir):
            return jsonify({
                'status': 'success',
                'message': 'No TensorBoard data available yet',
                'data': {}
            }), 200
        
        # Initialize event accumulator
        ea = event_accumulator.EventAccumulator(logs_dir)
        ea.Reload()
        
        # Extract scalar data
        tensorboard_data = {}
        
        # Get all scalar tags
        tags = ea.Tags().get('scalars', [])
        
        for tag in tags:
            events = ea.Scalars(tag)
            tensorboard_data[tag] = [
                {
                    'step': e.step,
                    'value': e.value,
                    'wall_time': e.wall_time
                }
                for e in events
            ]
        
        return jsonify({
            'status': 'success',
            'job_id': job_id,
            'data': tensorboard_data,
            'available_tags': tags
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Get TensorBoard data error: {str(e)}")
        # Return empty data instead of error for better UX
        return jsonify({
            'status': 'success',
            'message': 'TensorBoard data not available',
            'data': {},
            'error': str(e)
        }), 200
