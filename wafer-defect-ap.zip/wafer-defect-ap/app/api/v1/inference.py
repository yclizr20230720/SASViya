"""
Inference API endpoints for wafer defect pattern recognition

Implements Task 6 from tasks_backend.md
Enhanced with Task 11 explainability features
"""
from flask import request, jsonify, current_app, send_file
from werkzeug.utils import secure_filename
from app.api.v1 import api_v1_bp
from app.utils.json_storage import JSONStorage
from app.ml.inference import WaferInferenceEngine
import os
import uuid
from datetime import datetime
import torch
from PIL import Image
import numpy as np
import io


# Global inference engine (lazy loaded)
_inference_engine = None


def get_inference_engine():
    """
    Get or initialize inference engine (singleton pattern)
    
    Returns:
        WaferInferenceEngine instance
    """
    global _inference_engine
    
    if _inference_engine is None:
        # Path to best trained model
        model_path = os.path.join(
            current_app.config['BASE_DIR'],
            'checkpoints',
            'best_model.pth'
        )
        
        if not os.path.exists(model_path):
            raise FileNotFoundError(
                f"Trained model not found at {model_path}. "
                "Please train a model first using scripts/train_model.py"
            )
        
        # Determine device
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        
        # Initialize engine
        _inference_engine = WaferInferenceEngine(
            model_path=model_path,
            device=device,
            temperature=1.0  # Default temperature
        )
        
        current_app.logger.info(f"Inference engine initialized on {device}")
    
    return _inference_engine


@api_v1_bp.route('/inference/predict', methods=['POST'])
def predict_wafer():
    """
    Predict pattern and root cause for a wafer
    
    Request (Option 1 - Existing wafer):
        {
            "wafer_id": "M93242.01",
            "model_version": "v1.0",  # optional
            "explain": true  # optional, return full probabilities
        }
    
    Request (Option 2 - Upload new wafer):
        multipart/form-data:
        - image_file: Wafer map image
        - explain: true/false (optional)
    
    Returns:
        JSON response with prediction results
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Determine if this is existing wafer or new upload
        if request.is_json:
            # Option 1: Existing wafer
            data = request.get_json()
            wafer_id = data.get('wafer_id')
            
            if not wafer_id:
                return jsonify({'error': 'wafer_id is required'}), 400
            
            # Find wafer in storage
            wafer = storage.find_one('wafers.json', wafer_id=wafer_id)
            
            if not wafer:
                return jsonify({'error': f'Wafer {wafer_id} not found'}), 404
            
            image_path = wafer.get('image_path')
            
            if not image_path or not os.path.exists(image_path):
                return jsonify({'error': f'Image file not found for wafer {wafer_id}'}), 404
            
            explain = data.get('explain', False)
        
        else:
            # Option 2: New upload
            if 'image_file' not in request.files:
                return jsonify({'error': 'No image file provided'}), 400
            
            image_file = request.files['image_file']
            
            if image_file.filename == '':
                return jsonify({'error': 'No image file selected'}), 400
            
            # Save temporary image
            temp_filename = secure_filename(f"temp_{uuid.uuid4()}_{image_file.filename}")
            image_path = os.path.join(current_app.config['TEMP_FOLDER'], temp_filename)
            image_file.save(image_path)
            
            wafer_id = f"temp_{uuid.uuid4().hex[:8]}"
            explain = request.form.get('explain', 'false').lower() == 'true'
        
        # Get inference engine
        try:
            engine = get_inference_engine()
        except FileNotFoundError as e:
            return jsonify({'error': str(e)}), 503
        
        # Run inference
        start_time = datetime.utcnow()
        result = engine.predict(
            image_path=image_path,
            return_probabilities=explain
        )
        
        # Generate inference ID
        inference_id = str(uuid.uuid4())
        
        # Prepare inference record
        inference_record = {
            'inference_id': inference_id,
            'wafer_id': wafer_id,
            'pattern_class': result['pattern_class'],
            'pattern_confidence': result['pattern_confidence'],
            'root_cause': result['root_cause'],
            'root_cause_confidence': result['root_cause_confidence'],
            'processing_time_ms': result['processing_time_ms'],
            'timestamp': start_time.isoformat(),
            'model_version': 'v1.0',  # TODO: Get from model metadata
            'image_path': image_path
        }
        
        # Add probabilities if requested
        if explain:
            inference_record['pattern_probabilities'] = result.get('pattern_probabilities', {})
            inference_record['root_cause_probabilities'] = result.get('root_cause_probabilities', {})
        
        # Save to inference results
        storage.append('inference_results.json', inference_record)
        
        # Clean up temp file if it was an upload
        if not request.is_json and os.path.exists(image_path):
            try:
                os.remove(image_path)
            except:
                pass
        
        # Build response
        response = {
            'status': 'success',
            'inference_id': inference_id,
            'wafer_id': wafer_id,
            'pattern_class': result['pattern_class'],
            'pattern_confidence': round(result['pattern_confidence'], 4),
            'root_cause': result['root_cause'],
            'root_cause_confidence': round(result['root_cause_confidence'], 4),
            'processing_time_ms': round(result['processing_time_ms'], 2),
            'timestamp': result['timestamp']
        }
        
        # Add probabilities if requested
        if explain:
            response['pattern_probabilities'] = {
                k: round(v, 4) for k, v in result.get('pattern_probabilities', {}).items()
            }
            response['root_cause_probabilities'] = {
                k: round(v, 4) for k, v in result.get('root_cause_probabilities', {}).items()
            }
        
        current_app.logger.info(
            f"Inference completed: {wafer_id} -> {result['pattern_class']} "
            f"({result['pattern_confidence']:.2%}) in {result['processing_time_ms']:.0f}ms"
        )
        
        return jsonify(response), 200
    
    except Exception as e:
        current_app.logger.error(f"Inference error: {str(e)}")
        return jsonify({'error': f'Inference failed: {str(e)}'}), 500


@api_v1_bp.route('/inference/batch-predict', methods=['POST'])
def batch_predict_wafers():
    """
    Predict for multiple wafers in batch
    
    Request:
        {
            "wafer_ids": ["M93242.01", "M93242.02", "M93242.03"],
            "batch_size": 32  # optional
        }
    
    Returns:
        JSON response with batch prediction results
    """
    try:
        data = request.get_json()
        
        if not data or 'wafer_ids' not in data:
            return jsonify({'error': 'wafer_ids list is required'}), 400
        
        wafer_ids = data['wafer_ids']
        batch_size = data.get('batch_size', 32)
        
        if not isinstance(wafer_ids, list) or len(wafer_ids) == 0:
            return jsonify({'error': 'wafer_ids must be a non-empty list'}), 400
        
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Collect image paths
        image_paths = []
        valid_wafer_ids = []
        errors = []
        
        for wafer_id in wafer_ids:
            wafer = storage.find_one('wafers.json', wafer_id=wafer_id)
            
            if not wafer:
                errors.append(f"Wafer {wafer_id} not found")
                continue
            
            image_path = wafer.get('image_path')
            
            if not image_path or not os.path.exists(image_path):
                errors.append(f"Image file not found for wafer {wafer_id}")
                continue
            
            image_paths.append(image_path)
            valid_wafer_ids.append(wafer_id)
        
        if len(image_paths) == 0:
            return jsonify({
                'error': 'No valid wafers found',
                'errors': errors
            }), 400
        
        # Get inference engine
        try:
            engine = get_inference_engine()
        except FileNotFoundError as e:
            return jsonify({'error': str(e)}), 503
        
        # Run batch inference
        start_time = datetime.utcnow()
        results = engine.predict_batch(
            image_paths=image_paths,
            batch_size=batch_size
        )
        
        # Save inference records
        inference_records = []
        
        for i, result in enumerate(results):
            inference_id = str(uuid.uuid4())
            wafer_id = valid_wafer_ids[i]
            
            inference_record = {
                'inference_id': inference_id,
                'wafer_id': wafer_id,
                'pattern_class': result['pattern_class'],
                'pattern_confidence': result['pattern_confidence'],
                'root_cause': result['root_cause'],
                'root_cause_confidence': result['root_cause_confidence'],
                'processing_time_ms': result['processing_time_ms'],
                'timestamp': start_time.isoformat(),
                'model_version': 'v1.0',
                'batch_inference': True
            }
            
            storage.append('inference_results.json', inference_record)
            inference_records.append(inference_record)
        
        # Calculate total processing time
        total_time = (datetime.utcnow() - start_time).total_seconds() * 1000
        
        current_app.logger.info(
            f"Batch inference completed: {len(results)} wafers in {total_time:.0f}ms "
            f"({total_time/len(results):.0f}ms per wafer)"
        )
        
        return jsonify({
            'status': 'success',
            'processed_count': len(results),
            'error_count': len(errors),
            'total_processing_time_ms': round(total_time, 2),
            'avg_processing_time_ms': round(total_time / len(results), 2),
            'results': [
                {
                    'inference_id': rec['inference_id'],
                    'wafer_id': rec['wafer_id'],
                    'pattern_class': rec['pattern_class'],
                    'pattern_confidence': round(rec['pattern_confidence'], 4),
                    'root_cause': rec['root_cause'],
                    'root_cause_confidence': round(rec['root_cause_confidence'], 4)
                }
                for rec in inference_records
            ],
            'errors': errors if errors else None
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Batch inference error: {str(e)}")
        return jsonify({'error': f'Batch inference failed: {str(e)}'}), 500


@api_v1_bp.route('/inference/explain/<wafer_id>', methods=['GET'])
def explain_inference(wafer_id):
    """
    Get comprehensive explainability information for a wafer inference
    
    Includes:
    - Grad-CAM heatmap visualization
    - SHAP feature importance (if available)
    - Similar case retrieval
    - Prediction probabilities
    
    Query Parameters:
        - include_gradcam: Generate Grad-CAM heatmap (default: true)
        - include_similar: Find similar cases (default: true)
        - top_k_similar: Number of similar cases (default: 5)
    
    Returns:
        JSON response with comprehensive explanation data
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get query parameters
        include_gradcam = request.args.get('include_gradcam', 'true').lower() == 'true'
        include_similar = request.args.get('include_similar', 'true').lower() == 'true'
        top_k_similar = int(request.args.get('top_k_similar', 5))
        
        # Find most recent inference for this wafer
        all_inferences = storage.find('inference_results.json', wafer_id=wafer_id)
        
        if not all_inferences or len(all_inferences) == 0:
            return jsonify({'error': f'No inference found for wafer {wafer_id}'}), 404
        
        # Get most recent
        inference = sorted(
            all_inferences,
            key=lambda x: x.get('timestamp', ''),
            reverse=True
        )[0]
        
        # Get wafer details
        wafer = storage.find_one('wafers.json', wafer_id=wafer_id)
        
        if not wafer:
            return jsonify({'error': f'Wafer {wafer_id} not found'}), 404
        
        image_path = wafer.get('image_path')
        
        if not image_path or not os.path.exists(image_path):
            return jsonify({'error': f'Image file not found for wafer {wafer_id}'}), 404
        
        # Build base explanation response
        explanation = {
            'status': 'success',
            'wafer_id': wafer_id,
            'inference_id': inference.get('inference_id'),
            'prediction': {
                'pattern_class': inference.get('pattern_class'),
                'pattern_confidence': inference.get('pattern_confidence'),
                'root_cause': inference.get('root_cause'),
                'root_cause_confidence': inference.get('root_cause_confidence')
            },
            'probabilities': {
                'pattern': inference.get('pattern_probabilities', {}),
                'root_cause': inference.get('root_cause_probabilities', {})
            },
            'metadata': {
                'lot_id': wafer.get('lot_id'),
                'process_step': wafer.get('process_step'),
                'equipment_id': wafer.get('tool_id'),
                'defect_count': wafer.get('defect_count'),
                'timestamp': wafer.get('timestamp')
            },
            'timestamp': inference.get('timestamp')
        }
        
        # Generate Grad-CAM heatmap if requested
        if include_gradcam:
            try:
                from app.ml.explainability import GradCAMExplainer
                from app.ml.model import PATTERN_CLASSES
                
                # Get inference engine and model
                engine = get_inference_engine()
                
                # Create Grad-CAM explainer
                gradcam = GradCAMExplainer(engine.model)
                
                # Get predicted class index
                pattern_class = inference.get('pattern_class')
                class_idx = PATTERN_CLASSES.index(pattern_class)
                
                # Generate heatmap overlay
                overlay = gradcam.generate_overlay(
                    image_path=image_path,
                    class_idx=class_idx,
                    task='pattern',
                    alpha=0.5
                )
                
                # Save heatmap to temp folder
                heatmap_filename = f"gradcam_{wafer_id}_{uuid.uuid4().hex[:8]}.png"
                heatmap_path = os.path.join(
                    current_app.config['TEMP_FOLDER'],
                    heatmap_filename
                )
                
                Image.fromarray(overlay).save(heatmap_path)
                
                explanation['gradcam'] = {
                    'heatmap_path': heatmap_path,
                    'heatmap_url': f'/api/v1/inference/heatmap/{heatmap_filename}',
                    'description': 'Regions highlighted in red/yellow contributed most to the prediction'
                }
                
                current_app.logger.info(f"Generated Grad-CAM heatmap for {wafer_id}")
            
            except Exception as e:
                current_app.logger.warning(f"Failed to generate Grad-CAM: {e}")
                explanation['gradcam'] = {
                    'error': 'Grad-CAM generation failed',
                    'message': str(e)
                }
        
        # Find similar cases if requested
        if include_similar:
            try:
                # Load embedding database
                embedding_db_path = os.path.join(
                    current_app.config['METADATA_FOLDER'],
                    'embedding_database.json'
                )
                
                if os.path.exists(embedding_db_path):
                    import json
                    with open(embedding_db_path, 'r') as f:
                        embedding_db_data = json.load(f)
                    
                    # Convert to numpy arrays
                    embedding_db = {
                        wid: np.array(emb)
                        for wid, emb in embedding_db_data.items()
                    }
                    
                    from app.ml.explainability import SimilarCaseRetriever
                    
                    # Get inference engine
                    engine = get_inference_engine()
                    
                    # Create retriever
                    retriever = SimilarCaseRetriever(
                        model=engine.model,
                        embedding_database=embedding_db,
                        device=engine.device
                    )
                    
                    # Find similar cases
                    similar_cases = retriever.find_similar_by_wafer_id(
                        wafer_id=wafer_id,
                        top_k=top_k_similar
                    )
                    
                    # Enrich with wafer details
                    enriched_similar = []
                    for case in similar_cases:
                        similar_wafer = storage.find_one('wafers.json', wafer_id=case['wafer_id'])
                        
                        if similar_wafer:
                            # Find inference for similar wafer
                            similar_inference = storage.find_one(
                                'inference_results.json',
                                wafer_id=case['wafer_id']
                            )
                            
                            enriched_similar.append({
                                'wafer_id': case['wafer_id'],
                                'similarity': round(case['similarity'], 4),
                                'pattern_class': similar_inference.get('pattern_class') if similar_inference else None,
                                'lot_id': similar_wafer.get('lot_id'),
                                'process_step': similar_wafer.get('process_step'),
                                'image_path': similar_wafer.get('image_path')
                            })
                    
                    explanation['similar_cases'] = enriched_similar
                    
                    current_app.logger.info(f"Found {len(enriched_similar)} similar cases for {wafer_id}")
                
                else:
                    explanation['similar_cases'] = {
                        'error': 'Embedding database not found',
                        'message': 'Run build_embedding_database.py to create the database'
                    }
            
            except Exception as e:
                current_app.logger.warning(f"Failed to find similar cases: {e}")
                explanation['similar_cases'] = {
                    'error': 'Similar case retrieval failed',
                    'message': str(e)
                }
        
        return jsonify(explanation), 200
    
    except Exception as e:
        current_app.logger.error(f"Explain inference error: {str(e)}")
        return jsonify({'error': f'Failed to get explanation: {str(e)}'}), 500


@api_v1_bp.route('/inference/heatmap/<filename>', methods=['GET'])
def get_heatmap(filename):
    """
    Serve Grad-CAM heatmap image
    
    Args:
        filename: Heatmap filename
    
    Returns:
        Image file
    """
    try:
        heatmap_path = os.path.join(current_app.config['TEMP_FOLDER'], filename)
        
        if not os.path.exists(heatmap_path):
            return jsonify({'error': 'Heatmap not found'}), 404
        
        return send_file(heatmap_path, mimetype='image/png')
    
    except Exception as e:
        current_app.logger.error(f"Get heatmap error: {str(e)}")
        return jsonify({'error': f'Failed to get heatmap: {str(e)}'}), 500


@api_v1_bp.route('/inference/history', methods=['GET'])
def get_inference_history():
    """
    Get inference history with filtering
    
    Query Parameters:
        - wafer_id: Filter by wafer ID (optional)
        - pattern: Filter by pattern class (optional)
        - min_confidence: Minimum confidence threshold (optional)
        - start_date: Start date filter (ISO format) (optional)
        - end_date: End date filter (ISO format) (optional)
        - limit: Number of results (default: 100)
        - offset: Pagination offset (default: 0)
    
    Returns:
        JSON response with inference history
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get query parameters
        wafer_id = request.args.get('wafer_id')
        pattern = request.args.get('pattern')
        min_confidence = request.args.get('min_confidence', type=float)
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        limit = int(request.args.get('limit', 100))
        offset = int(request.args.get('offset', 0))
        
        # Get all inference results
        inferences = storage.find('inference_results.json')
        
        # Apply filters
        filtered = inferences
        
        if wafer_id:
            filtered = [i for i in filtered if i.get('wafer_id') == wafer_id]
        
        if pattern:
            filtered = [i for i in filtered if i.get('pattern_class') == pattern]
        
        if min_confidence is not None:
            filtered = [
                i for i in filtered
                if i.get('pattern_confidence', 0) >= min_confidence
            ]
        
        if start_date:
            filtered = [
                i for i in filtered
                if i.get('timestamp', '') >= start_date
            ]
        
        if end_date:
            filtered = [
                i for i in filtered
                if i.get('timestamp', '') <= end_date
            ]
        
        # Sort by timestamp (most recent first)
        filtered.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
        # Calculate statistics
        total_count = len(filtered)
        
        # Apply pagination
        paginated = filtered[offset:offset + limit]
        
        # Calculate pattern distribution
        pattern_counts = {}
        for inf in filtered:
            pattern_class = inf.get('pattern_class', 'Unknown')
            pattern_counts[pattern_class] = pattern_counts.get(pattern_class, 0) + 1
        
        return jsonify({
            'status': 'success',
            'total_count': total_count,
            'returned_count': len(paginated),
            'offset': offset,
            'limit': limit,
            'pattern_distribution': pattern_counts,
            'inferences': [
                {
                    'inference_id': inf.get('inference_id'),
                    'wafer_id': inf.get('wafer_id'),
                    'pattern_class': inf.get('pattern_class'),
                    'pattern_confidence': round(inf.get('pattern_confidence', 0), 4),
                    'root_cause': inf.get('root_cause'),
                    'root_cause_confidence': round(inf.get('root_cause_confidence', 0), 4),
                    'processing_time_ms': inf.get('processing_time_ms'),
                    'timestamp': inf.get('timestamp'),
                    'model_version': inf.get('model_version')
                }
                for inf in paginated
            ]
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Get inference history error: {str(e)}")
        return jsonify({'error': f'Failed to get inference history: {str(e)}'}), 500
