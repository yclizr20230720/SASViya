"""
Wafer upload and management endpoints
"""
from flask import request, jsonify, current_app
from werkzeug.utils import secure_filename
from app.api.v1 import api_v1_bp
from app.utils.json_storage import JSONStorage
from app.utils.data_init import validate_lot_id, validate_wafer_id
import os
import uuid
from datetime import datetime
import pandas as pd
import json


ALLOWED_DATA_EXTENSIONS = {'json', 'csv', 'xlsx'}
ALLOWED_IMAGE_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif'}


def allowed_file(filename, allowed_extensions):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in allowed_extensions


def parse_data_file(file_path, file_extension):
    """
    Parse uploaded data file (JSON/CSV/XLSX)
    
    Returns:
        dict: Parsed wafer data
    """
    try:
        if file_extension == 'json':
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data if isinstance(data, dict) else data[0] if isinstance(data, list) else {}
        
        elif file_extension == 'csv':
            df = pd.read_csv(file_path)
            return df.to_dict('records')[0] if len(df) > 0 else {}
        
        elif file_extension == 'xlsx':
            df = pd.read_excel(file_path)
            return df.to_dict('records')[0] if len(df) > 0 else {}
        
        return {}
    except Exception as e:
        raise ValueError(f"Error parsing data file: {str(e)}")


@api_v1_bp.route('/wafer/upload', methods=['POST'])
def upload_wafer():
    """
    Upload wafer data and image
    
    Request:
        - data_file: JSON/CSV/XLSX file with wafer information
        - image_file: JPG/PNG/GIF wafer map image
        - metadata: Additional metadata (optional)
    
    Returns:
        JSON response with upload status and wafer_id
    """
    try:
        # Check if files are present
        if 'data_file' not in request.files:
            return jsonify({'error': 'No data file provided'}), 400
        
        if 'image_file' not in request.files:
            return jsonify({'error': 'No image file provided'}), 400
        
        data_file = request.files['data_file']
        image_file = request.files['image_file']
        
        # Check if files are selected
        if data_file.filename == '':
            return jsonify({'error': 'No data file selected'}), 400
        
        if image_file.filename == '':
            return jsonify({'error': 'No image file selected'}), 400
        
        # Validate file extensions
        data_ext = data_file.filename.rsplit('.', 1)[1].lower() if '.' in data_file.filename else ''
        image_ext = image_file.filename.rsplit('.', 1)[1].lower() if '.' in image_file.filename else ''
        
        if not allowed_file(data_file.filename, ALLOWED_DATA_EXTENSIONS):
            return jsonify({'error': f'Invalid data file type. Allowed: {", ".join(ALLOWED_DATA_EXTENSIONS)}'}), 400
        
        if not allowed_file(image_file.filename, ALLOWED_IMAGE_EXTENSIONS):
            return jsonify({'error': f'Invalid image file type. Allowed: {", ".join(ALLOWED_IMAGE_EXTENSIONS)}'}), 400
        
        # Generate job ID
        job_id = str(uuid.uuid4())
        
        # Save data file temporarily
        temp_data_filename = secure_filename(f"{job_id}_{data_file.filename}")
        temp_data_path = os.path.join(current_app.config['TEMP_FOLDER'], temp_data_filename)
        data_file.save(temp_data_path)
        
        # Parse data file
        try:
            wafer_data = parse_data_file(temp_data_path, data_ext)
        except ValueError as e:
            os.remove(temp_data_path)
            return jsonify({'error': str(e)}), 400
        
        # Validate required fields
        required_fields = ['lot_id', 'wafer_id']
        missing_fields = [field for field in required_fields if field not in wafer_data]
        
        if missing_fields:
            os.remove(temp_data_path)
            return jsonify({'error': f'Missing required fields: {", ".join(missing_fields)}'}), 400
        
        lot_id = wafer_data['lot_id']
        wafer_id = wafer_data['wafer_id']
        
        # Validate ID formats
        if not validate_lot_id(lot_id):
            os.remove(temp_data_path)
            return jsonify({'error': f'Invalid LotID format. Expected: M93242.00'}), 400
        
        if not validate_wafer_id(wafer_id):
            os.remove(temp_data_path)
            return jsonify({'error': f'Invalid WaferID format. Expected: M93242.01 to M93242.25'}), 400
        
        # Save image file
        image_filename = secure_filename(f"{wafer_id}_{image_file.filename}")
        image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], image_filename)
        image_file.save(image_path)
        
        # Get additional metadata from form
        additional_metadata = {}
        if request.form:
            additional_metadata = dict(request.form)
        
        # Prepare wafer record
        wafer_record = {
            'job_id': job_id,
            'lot_id': lot_id,
            'wafer_id': wafer_id,
            'tool_id': wafer_data.get('tool_id', ''),
            'scan_time': wafer_data.get('scan_time', datetime.utcnow().isoformat()),
            'process_step': wafer_data.get('process_step', additional_metadata.get('process_step', '')),
            'defect_count': wafer_data.get('defect_count', 0),
            'image_path': image_path,
            'image_filename': image_filename,
            'data_file_path': temp_data_path,
            'status': 'uploaded',
            'upload_time': datetime.utcnow().isoformat(),
            'metadata': additional_metadata
        }
        
        # Save to JSON storage
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        storage.append('wafers.json', wafer_record)
        
        # Clean up temp data file
        os.remove(temp_data_path)
        
        return jsonify({
            'status': 'success',
            'wafer_id': wafer_id,
            'lot_id': lot_id,
            'job_id': job_id,
            'message': 'Upload successful',
            'image_filename': image_filename
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Upload error: {str(e)}")
        return jsonify({'error': f'Upload failed: {str(e)}'}), 500


@api_v1_bp.route('/wafer/list', methods=['GET'])
def list_wafers():
    """
    List all uploaded wafers
    
    Query Parameters:
        - lot_id: Filter by lot ID (optional)
        - status: Filter by status (optional)
        - limit: Number of results (default: 100)
    
    Returns:
        JSON response with list of wafers
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get query parameters
        lot_id = request.args.get('lot_id')
        status = request.args.get('status')
        limit = int(request.args.get('limit', 100))
        
        # Build filters
        filters = {}
        if lot_id:
            filters['lot_id'] = lot_id
        if status:
            filters['status'] = status
        
        # Get wafers
        wafers = storage.find('wafers.json', **filters)
        
        # Limit results
        wafers = wafers[:limit]
        
        return jsonify({
            'status': 'success',
            'count': len(wafers),
            'wafers': wafers
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"List wafers error: {str(e)}")
        return jsonify({'error': f'Failed to list wafers: {str(e)}'}), 500


@api_v1_bp.route('/wafer/<wafer_id>', methods=['GET'])
def get_wafer(wafer_id):
    """
    Get wafer details by ID
    
    Returns:
        JSON response with wafer details
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        wafer = storage.find_one('wafers.json', wafer_id=wafer_id)
        
        if not wafer:
            return jsonify({'error': 'Wafer not found'}), 404
        
        return jsonify({
            'status': 'success',
            'wafer': wafer
        }), 200
    
    except Exception as e:
        current_app.logger.error(f"Get wafer error: {str(e)}")
        return jsonify({'error': f'Failed to get wafer: {str(e)}'}), 500


@api_v1_bp.route('/wafer/<wafer_id>', methods=['DELETE'])
def delete_wafer(wafer_id):
    """
    Delete wafer by ID
    
    Returns:
        JSON response with deletion status
    """
    try:
        storage = JSONStorage(current_app.config['METADATA_FOLDER'])
        
        # Get wafer to delete image file
        wafer = storage.find_one('wafers.json', wafer_id=wafer_id)
        
        if not wafer:
            return jsonify({'error': 'Wafer not found'}), 404
        
        # Delete image file if exists
        if 'image_path' in wafer and os.path.exists(wafer['image_path']):
            os.remove(wafer['image_path'])
        
        # Delete from JSON storage
        deleted = storage.delete('wafers.json', wafer['id'])
        
        if deleted:
            return jsonify({
                'status': 'success',
                'message': f'Wafer {wafer_id} deleted successfully'
            }), 200
        else:
            return jsonify({'error': 'Failed to delete wafer'}), 500
    
    except Exception as e:
        current_app.logger.error(f"Delete wafer error: {str(e)}")
        return jsonify({'error': f'Failed to delete wafer: {str(e)}'}), 500
