"""
Test inference engine with real trained model on actual wafer images
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from app.ml.inference import WaferInferenceEngine
from pathlib import Path
import json

def test_inference():
    """Test inference on real wafer images"""
    
    print("="*80)
    print("WAFER DEFECT PATTERN RECOGNITION - INFERENCE TEST")
    print("="*80)
    
    # Initialize inference engine
    print("\n1. Loading trained model...")
    model_path = 'checkpoints/best_model.pth'
    
    if not os.path.exists(model_path):
        print(f"ERROR: Model not found at {model_path}")
        return
    
    engine = WaferInferenceEngine(
        model_path=model_path,
        device='cpu',
        temperature=1.0
    )
    
    # Get all real wafer images (not augmented)
    print("\n2. Finding real wafer images...")
    image_dir = Path('data/wafer_images')
    real_images = [f for f in image_dir.glob('*.png') if f.is_file()]
    
    print(f"   Found {len(real_images)} real wafer images")
    
    # Test inference on each image
    print("\n3. Running inference on all wafer images...")
    print("-"*80)
    
    results = []
    
    for i, image_path in enumerate(real_images, 1):
        print(f"\n[{i}/{len(real_images)}] Testing: {image_path.name}")
        
        try:
            # Run inference with full probabilities
            result = engine.predict(
                str(image_path),
                return_probabilities=True
            )
            
            # Display results
            print(f"   Pattern: {result['pattern_class']}")
            print(f"   Confidence: {result['pattern_confidence']:.2%}")
            print(f"   Root Cause: {result['root_cause']}")
            print(f"   Root Cause Confidence: {result['root_cause_confidence']:.2%}")
            print(f"   Processing Time: {result['processing_time_ms']:.1f}ms")
            
            # Show top 3 pattern predictions
            pattern_probs = result['pattern_probabilities']
            top_patterns = sorted(pattern_probs.items(), key=lambda x: x[1], reverse=True)[:3]
            print(f"   Top 3 Patterns:")
            for pattern, prob in top_patterns:
                print(f"      - {pattern}: {prob:.2%}")
            
            # Add to results
            results.append({
                'image': image_path.name,
                'pattern': result['pattern_class'],
                'pattern_confidence': result['pattern_confidence'],
                'root_cause': result['root_cause'],
                'root_cause_confidence': result['root_cause_confidence'],
                'processing_time_ms': result['processing_time_ms']
            })
            
        except Exception as e:
            print(f"   ERROR: {str(e)}")
            results.append({
                'image': image_path.name,
                'error': str(e)
            })
    
    # Summary statistics
    print("\n" + "="*80)
    print("INFERENCE SUMMARY")
    print("="*80)
    
    successful = [r for r in results if 'error' not in r]
    failed = [r for r in results if 'error' in r]
    
    print(f"\nTotal Images: {len(results)}")
    print(f"Successful: {len(successful)}")
    print(f"Failed: {len(failed)}")
    
    if successful:
        avg_time = sum(r['processing_time_ms'] for r in successful) / len(successful)
        avg_pattern_conf = sum(r['pattern_confidence'] for r in successful) / len(successful)
        avg_root_cause_conf = sum(r['root_cause_confidence'] for r in successful) / len(successful)
        
        print(f"\nAverage Processing Time: {avg_time:.1f}ms")
        print(f"Average Pattern Confidence: {avg_pattern_conf:.2%}")
        print(f"Average Root Cause Confidence: {avg_root_cause_conf:.2%}")
        
        # Pattern distribution
        print("\nPredicted Pattern Distribution:")
        pattern_counts = {}
        for r in successful:
            pattern = r['pattern']
            pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
        
        for pattern, count in sorted(pattern_counts.items(), key=lambda x: x[1], reverse=True):
            print(f"   {pattern}: {count}")
    
    # Save results
    output_file = 'inference_test_results.json'
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to: {output_file}")
    print("\n" + "="*80)
    print("INFERENCE TEST COMPLETE")
    print("="*80)

if __name__ == '__main__':
    test_inference()
