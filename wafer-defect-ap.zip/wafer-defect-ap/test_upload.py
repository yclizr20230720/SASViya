"""
Test wafer upload API endpoint
"""
import requests
import json
import os
from PIL import Image
import numpy as np

# API endpoint
API_URL = "http://localhost:5000/api/v1"


def create_sample_wafer_image(filename='test_wafer.png'):
    """Create a sample wafer map image"""
    # Create a 300x300 image with random defects
    img_size = 300
    img = Image.new('RGB', (img_size, img_size), color='white')
    pixels = img.load()
    
    # Draw wafer circle (black background)
    center = img_size // 2
    radius = img_size // 2 - 10
    
    for x in range(img_size):
        for y in range(img_size):
            dist = np.sqrt((x - center)**2 + (y - center)**2)
            if dist <= radius:
                pixels[x, y] = (200, 200, 200)  # Gray wafer
    
    # Add some random defects (red dots)
    np.random.seed(42)
    num_defects = 45
    for _ in range(num_defects):
        x = np.random.randint(center - radius + 20, center + radius - 20)
        y = np.random.randint(center - radius + 20, center + radius - 20)
        # Draw small red dot
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                if 0 <= x+dx < img_size and 0 <= y+dy < img_size:
                    pixels[x+dx, y+dy] = (255, 0, 0)  # Red defect
    
    img.save(filename)
    print(f"✓ Created sample wafer image: {filename}")
    return filename


def create_sample_data_json(filename='test_wafer_data.json'):
    """Create sample wafer data JSON file"""
    data = {
        "lot_id": "M93242.00",
        "wafer_id": "M93242.01",
        "tool_id": "LITHO-ASML-04",
        "scan_time": "2024-01-15T10:30:00Z",
        "process_step": "Lithography",
        "defect_count": 45
    }
    
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)
    
    print(f"✓ Created sample data file: {filename}")
    return filename


def test_upload():
    """Test wafer upload endpoint"""
    print("\n" + "=" * 60)
    print("Testing Wafer Upload API")
    print("=" * 60)
    
    # Create sample files
    image_file = create_sample_wafer_image()
    data_file = create_sample_data_json()
    
    try:
        # Prepare files for upload
        with open(data_file, 'rb') as df, open(image_file, 'rb') as if_:
            files = {
                'data_file': (data_file, df, 'application/json'),
                'image_file': (image_file, if_, 'image/png')
            }
            
            data = {
                'process_step': 'Lithography'
            }
            
            print("\n1. Uploading wafer...")
            response = requests.post(f"{API_URL}/wafer/upload", files=files, data=data)
            
            if response.status_code == 200:
                result = response.json()
                print(f"✓ Upload successful!")
                print(f"  - Wafer ID: {result['wafer_id']}")
                print(f"  - Lot ID: {result['lot_id']}")
                print(f"  - Job ID: {result['job_id']}")
                print(f"  - Image: {result['image_filename']}")
                
                wafer_id = result['wafer_id']
                
                # Test list wafers
                print("\n2. Listing wafers...")
                response = requests.get(f"{API_URL}/wafer/list")
                if response.status_code == 200:
                    result = response.json()
                    print(f"✓ Found {result['count']} wafer(s)")
                    for wafer in result['wafers']:
                        print(f"  - {wafer['wafer_id']} ({wafer['lot_id']}) - {wafer['status']}")
                
                # Test get wafer
                print(f"\n3. Getting wafer details for {wafer_id}...")
                response = requests.get(f"{API_URL}/wafer/{wafer_id}")
                if response.status_code == 200:
                    result = response.json()
                    wafer = result['wafer']
                    print(f"✓ Wafer details retrieved:")
                    print(f"  - Wafer ID: {wafer['wafer_id']}")
                    print(f"  - Lot ID: {wafer['lot_id']}")
                    print(f"  - Tool ID: {wafer['tool_id']}")
                    print(f"  - Defect Count: {wafer['defect_count']}")
                    print(f"  - Status: {wafer['status']}")
                
                print("\n" + "=" * 60)
                print("✅ All tests passed!")
                print("=" * 60)
            else:
                print(f"✗ Upload failed: {response.status_code}")
                print(f"  Error: {response.json()}")
    
    except Exception as e:
        print(f"\n✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Clean up test files
        if os.path.exists(image_file):
            os.remove(image_file)
        if os.path.exists(data_file):
            os.remove(data_file)
        print("\n✓ Cleaned up test files")


if __name__ == '__main__':
    test_upload()
