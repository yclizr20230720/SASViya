"""
Test monitoring API endpoints with real training data
"""
import requests
import json

BASE_URL = 'http://localhost:5000/api/v1'
JOB_ID = 'training_20260118'

def test_get_logs():
    """Test GET /training/logs endpoint"""
    print("\n" + "="*80)
    print("TEST 1: Get Training Logs")
    print("="*80)
    
    url = f"{BASE_URL}/training/logs/{JOB_ID}?lines=20"
    print(f"\nGET {url}")
    
    try:
        response = requests.get(url)
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"\nTotal Lines: {data.get('total_lines')}")
            print(f"Returned Lines: {data.get('returned_lines')}")
            print("\nSample Logs:")
            for log in data.get('logs', [])[:10]:
                print(f"  {log}")
            print("  ...")
            return True
        else:
            print(f"Error: {response.text}")
            return False
    except Exception as e:
        print(f"Exception: {str(e)}")
        return False

def test_get_metrics():
    """Test GET /training/metrics endpoint"""
    print("\n" + "="*80)
    print("TEST 2: Get Training Metrics")
    print("="*80)
    
    url = f"{BASE_URL}/training/metrics/{JOB_ID}"
    print(f"\nGET {url}")
    
    try:
        response = requests.get(url)
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            
            print(f"\nJob ID: {data.get('job_id')}")
            print(f"Status: {data.get('training_status')}")
            
            progress = data.get('progress', {})
            print(f"\nProgress:")
            print(f"  Epoch: {progress.get('current_epoch')}/{progress.get('total_epochs')}")
            print(f"  Percentage: {progress.get('percentage')}%")
            
            current = data.get('current_metrics', {})
            print(f"\nCurrent Metrics:")
            print(f"  Train Loss: {current.get('train_loss')}")
            print(f"  Val Loss: {current.get('val_loss')}")
            print(f"  Pattern Acc: {current.get('val_pattern_acc')*100:.1f}%")
            print(f"  Root Cause Acc: {current.get('val_root_cause_acc')*100:.1f}%")
            
            best = data.get('best_metrics', {})
            print(f"\nBest Metrics:")
            print(f"  Epoch: {best.get('epoch')}")
            print(f"  Pattern Acc: {best.get('val_pattern_acc')*100:.1f}%")
            print(f"  Root Cause Acc: {best.get('val_root_cause_acc')*100:.1f}%")
            
            history = data.get('metrics_history', [])
            print(f"\nMetrics History: {len(history)} epochs")
            
            return True
        else:
            print(f"Error: {response.text}")
            return False
    except Exception as e:
        print(f"Exception: {str(e)}")
        return False

def main():
    """Run all tests"""
    print("="*80)
    print("TRAINING MONITORING API TESTS")
    print("="*80)
    print(f"\nBase URL: {BASE_URL}")
    print(f"Job ID: {JOB_ID}")
    
    print("\nNOTE: Make sure Flask server is running:")
    print("  cd wafer-defect-ap")
    print("  python run.py")
    
    input("\nPress Enter to start tests...")
    
    # Run tests
    test1 = test_get_logs()
    test2 = test_get_metrics()
    
    # Summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    print(f"\nTest 1 (Get Logs): {'✅ PASSED' if test1 else '❌ FAILED'}")
    print(f"Test 2 (Get Metrics): {'✅ PASSED' if test2 else '❌ FAILED'}")
    
    if test1 and test2:
        print("\n🎉 All tests passed!")
        print("\nThe monitoring API is working correctly with real training data.")
        print("You can now use the frontend to view the training progress!")
    else:
        print("\n⚠️ Some tests failed.")
        print("Make sure:")
        print("  1. Flask server is running (python run.py)")
        print("  2. Training data files exist in logs/")
        print("  3. API endpoints are correctly configured")

if __name__ == '__main__':
    main()
