# 📊 Training Monitoring System Guide

**Real-Time AI Model Training Monitoring**

---

## 🎯 Overview

The Training Monitoring System provides real-time visibility into AI model training progress, including:

- **Live Console Output** - Stream training logs to web interface
- **Real-Time Metrics** - Track loss, accuracy, and learning rate
- **Progress Tracking** - Monitor epoch progress and time remaining
- **Interactive Charts** - Visualize training metrics over time
- **Job Management** - Start, stop, and monitor training jobs

---

## 🏗️ Architecture

### Backend Components

1. **Training Monitor (`app/utils/training_monitor.py`)**
   - Captures console output to log files
   - Parses training metrics from output
   - Updates job status in real-time
   - Tracks epoch progress and metrics history

2. **Training API Endpoints (`app/api/v1/training.py`)**
   - `/api/v1/training/logs/<job_id>` - Get training logs
   - `/api/v1/training/metrics/<job_id>` - Get detailed metrics
   - `/api/v1/training/status/<job_id>` - Get job status
   - `/api/v1/training/stop/<job_id>` - Stop training job

3. **JSON Storage (`app/utils/json_storage.py`)**
   - Persists training job metadata
   - Stores metrics history
   - Tracks job status and progress

### Frontend Components

1. **TrainingMonitor Component (`src/components/training/TrainingMonitor.tsx`)**
   - Real-time metrics display
   - Live console output
   - Interactive charts (Chart.js)
   - Progress bar with time estimation
   - Job control buttons

2. **Auto-Polling System**
   - Polls backend every 2 seconds
   - Updates metrics and logs automatically
   - Stops polling when training completes

---

## 📡 API Endpoints

### 1. Get Training Logs

```http
GET /api/v1/training/logs/<job_id>?lines=100&offset=0
```

**Query Parameters:**
- `lines` (optional): Number of recent lines to return (default: 100)
- `offset` (optional): Offset for pagination (default: 0)

**Response:**
```json
{
  "status": "success",
  "job_id": "abc-123",
  "logs": [
    "[2026-01-18 10:30:15] Epoch 17/30",
    "[2026-01-18 10:30:16] Train - Loss: 0.1135, Pattern Acc: 0.880",
    "[2026-01-18 10:30:17] Val - Loss: 0.0511, Pattern Acc: 1.000"
  ],
  "total_lines": 1523,
  "returned_lines": 100,
  "offset": 0
}
```

### 2. Get Training Metrics

```http
GET /api/v1/training/metrics/<job_id>
```

**Response:**
```json
{
  "status": "success",
  "job_id": "abc-123",
  "training_status": "running",
  "progress": {
    "current_epoch": 17,
    "total_epochs": 30,
    "percentage": 56.67,
    "estimated_time_remaining_minutes": 26.5
  },
  "current_metrics": {
    "epoch": 17,
    "train_loss": 0.1135,
    "train_pattern_acc": 0.880,
    "train_root_cause_acc": 0.890,
    "val_loss": 0.0511,
    "val_pattern_acc": 1.000,
    "val_root_cause_acc": 0.975,
    "learning_rate": 0.000073
  },
  "metrics_history": [
    {
      "epoch": 1,
      "train_loss": 0.8287,
      "train_pattern_acc": 0.204,
      "val_loss": 0.8282,
      "val_pattern_acc": 0.300
    },
    ...
  ],
  "model_info": {
    "architecture": "efficientnet-b3",
    "batch_size": 8,
    "learning_rate": 0.0001,
    "total_parameters": 11684154
  },
  "timestamps": {
    "queued_at": "2026-01-18T10:00:00Z",
    "start_time": "2026-01-18T10:05:00Z",
    "end_time": null,
    "last_updated": "2026-01-18T10:30:17Z"
  }
}
```

### 3. Get Training Status

```http
GET /api/v1/training/status/<job_id>
```

**Response:**
```json
{
  "status": "success",
  "job_id": "abc-123",
  "training_status": "running",
  "progress": 56.67,
  "current_epoch": 17,
  "total_epochs": 30,
  "metrics": {
    "train_loss": 0.1135,
    "val_loss": 0.0511,
    "val_pattern_acc": 1.000
  },
  "start_time": "2026-01-18T10:05:00Z",
  "estimated_time_remaining": 26.5
}
```

### 4. Stop Training

```http
POST /api/v1/training/stop/<job_id>
```

**Response:**
```json
{
  "status": "success",
  "job_id": "abc-123",
  "message": "Training job stopped successfully",
  "final_metrics": {
    "train_loss": 0.1135,
    "val_pattern_acc": 1.000
  }
}
```

---

## 🎨 Frontend Integration

### Using the TrainingMonitor Component

```tsx
import TrainingMonitor from '@/components/training/TrainingMonitor';

function TrainingPage() {
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);

  return (
    <div>
      {selectedJobId && (
        <TrainingMonitor
          jobId={selectedJobId}
          onClose={() => setSelectedJobId(null)}
        />
      )}
    </div>
  );
}
```

### Features

1. **Real-Time Updates**
   - Polls backend every 2 seconds
   - Auto-updates metrics and logs
   - Smooth progress bar animation

2. **Interactive Charts**
   - Loss over time (train vs val)
   - Accuracy over time (pattern vs root cause)
   - Zoom and pan capabilities
   - Responsive design

3. **Console Output**
   - Live streaming logs
   - Auto-scroll to bottom
   - Manual scroll control
   - Download logs as text file

4. **Job Controls**
   - Stop training button
   - Refresh button
   - Download logs button
   - Status indicator chip

---

## 📊 Key Metrics Displayed

### Training Metrics

| Metric | Description | Target |
|--------|-------------|--------|
| **Train Loss** | Training set loss | Decreasing |
| **Val Loss** | Validation set loss | Decreasing |
| **Train Pattern Acc** | Pattern classification accuracy (train) | > 95% |
| **Val Pattern Acc** | Pattern classification accuracy (val) | > 95% |
| **Train Root Cause Acc** | Root cause classification accuracy (train) | > 90% |
| **Val Root Cause Acc** | Root cause classification accuracy (val) | > 90% |
| **Learning Rate** | Current learning rate | Decreasing |

### Progress Metrics

| Metric | Description |
|--------|-------------|
| **Current Epoch** | Current training epoch |
| **Total Epochs** | Total epochs to train |
| **Progress %** | Training completion percentage |
| **Time Remaining** | Estimated time to completion |

---

## 🔧 Implementation Details

### Log File Format

Training logs are stored in: `logs/training_<job_id>.log`

```
[2026-01-18 10:30:15] Training started for job: abc-123
[2026-01-18 10:30:16] Epoch 1/30
[2026-01-18 10:30:17] Train - Loss: 0.8287, Pattern Acc: 0.204
[2026-01-18 10:30:18] Val - Loss: 0.8282, Pattern Acc: 0.300
[2026-01-18 10:30:19] LR: 0.000100
[2026-01-18 10:30:20] Saved checkpoint: checkpoints/checkpoint_epoch_1.pth
```

### Metrics Parsing

The `TrainingMonitor` class parses console output using regex patterns:

```python
# Parse epoch number
epoch_match = re.search(r'Epoch (\d+)/(\d+)', message)

# Parse train metrics
train_match = re.search(r'Train - Loss: ([\d.]+), Pattern Acc: ([\d.]+)', message)

# Parse validation metrics
val_match = re.search(r'Val\s+-\s+Loss: ([\d.]+), Pattern Acc: ([\d.]+)', message)

# Parse learning rate
lr_match = re.search(r'LR: ([\d.]+)', message)
```

### Job Status Updates

Training job status is updated in `data/metadata/training_jobs.json`:

```json
{
  "job_id": "abc-123",
  "status": "running",
  "current_epoch": 17,
  "total_epochs": 30,
  "metrics": {
    "train_loss": 0.1135,
    "val_pattern_acc": 1.000
  },
  "metrics_history": [...],
  "last_updated": "2026-01-18T10:30:17Z"
}
```

---

## 🚀 Usage Examples

### 1. Monitor Running Training Job

```typescript
// Frontend
const TrainingDashboard = () => {
  const [jobs, setJobs] = useState([]);
  
  useEffect(() => {
    // Fetch running jobs
    fetch('http://localhost:5000/api/v1/training/queue?status=running')
      .then(res => res.json())
      .then(data => setJobs(data.jobs));
  }, []);
  
  return (
    <div>
      {jobs.map(job => (
        <TrainingMonitor key={job.job_id} jobId={job.job_id} />
      ))}
    </div>
  );
};
```

### 2. Start Training with Monitoring

```python
# Backend
from app.utils.training_monitor import setup_training_monitor

# Setup monitor
monitor = setup_training_monitor(
    job_id='abc-123',
    metadata_folder='data/metadata',
    log_folder='logs'
)

# Train model (output will be captured)
trainer.train(epochs=30)

# Mark as completed
monitor.mark_completed(success=True)
```

### 3. Download Training Logs

```typescript
const downloadLogs = async (jobId: string) => {
  const response = await fetch(
    `http://localhost:5000/api/v1/training/logs/${jobId}?lines=10000`
  );
  const data = await response.json();
  
  const blob = new Blob([data.logs.join('\n')], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `training_${jobId}_logs.txt`;
  a.click();
};
```

---

## 📈 Performance Considerations

### Backend

- **Log File Size**: Logs are appended, not overwritten. Consider log rotation for long training jobs.
- **Polling Frequency**: Default 2 seconds. Adjust based on training speed.
- **Metrics Storage**: Metrics history stored in memory and checkpoint files.

### Frontend

- **Auto-Scroll**: Can be disabled for better performance with large logs.
- **Chart Rendering**: Uses Chart.js with canvas rendering for performance.
- **Polling**: Automatically stops when training completes.

---

## 🐛 Troubleshooting

### Issue: Logs Not Appearing

**Solution:**
1. Check log file exists: `logs/training_<job_id>.log`
2. Verify training monitor is initialized
3. Check file permissions

### Issue: Metrics Not Updating

**Solution:**
1. Verify job status is "running"
2. Check `training_jobs.json` is being updated
3. Ensure polling interval is active

### Issue: Charts Not Rendering

**Solution:**
1. Check metrics_history has data
2. Verify Chart.js is installed
3. Check browser console for errors

---

## 🎓 Best Practices

1. **Monitor Early**: Start monitoring from epoch 1 to catch issues early
2. **Save Logs**: Download logs after training for analysis
3. **Watch Validation**: Focus on validation metrics to detect overfitting
4. **Time Estimates**: Use time remaining to plan resources
5. **Stop Gracefully**: Use stop button instead of killing process

---

## 📝 Next Steps

1. **Implement TensorBoard Integration** - Add TensorBoard data endpoint
2. **Add Email Notifications** - Notify when training completes
3. **Implement Model Comparison** - Compare multiple training runs
4. **Add Resource Monitoring** - Track CPU/GPU/Memory usage
5. **Implement Auto-Restart** - Restart failed training jobs

---

**Status**: ✅ Implemented and Ready to Use

**Last Updated**: January 18, 2026
