"""
Mock Data Generator for Focus-Exposure Matrix
Generates realistic CD data based on physics-based polynomial model from the paper
"""

import numpy as np
import pandas as pd
from typing import Tuple, Optional
import warnings

warnings.filterwarnings('ignore')


class BosungMockDataGenerator:
    """
    Generate realistic focus-exposure matrix data based on physics model.
    
    The model is derived from the paper's Equation (1):
    CD = Σ(i=0 to 3) Σ(j=0 to 4) a_ij * E^i * F^j
    
    Where:
    - E: Exposure dose (mJ/cm²)
    - F: Focus (μm)
    - CD: Critical Dimension (nm)
    """
    
    def __init__(self, 
                 target_cd: float = 250.0,
                 cd_tolerance: float = 0.1,
                 noise_level: float = 0.05):
        """
        Initialize the mock data generator.
        
        Args:
            target_cd: Target critical dimension in nm (default: 250 nm)
            cd_tolerance: CD tolerance as fraction of target (default: ±10%)
            noise_level: Measurement noise as fraction of CD (default: ±5%)
        """
        self.target_cd = target_cd
        self.cd_tolerance = cd_tolerance
        self.noise_level = noise_level
        
        # Physics-based coefficients (simplified model)
        # These are derived from lithography physics and typical process conditions
        self.coefficients = {
            'a00': 300.0,      # Base CD offset
            'a10': -0.8,       # Linear exposure effect
            'a20': 0.002,      # Quadratic exposure effect
            'a01': 50.0,       # Linear focus effect (parabolic)
            'a02': 80.0,       # Quadratic focus effect (main U-shape)
            'a11': -0.05,      # Cross-term: exposure-focus interaction
            'a12': 0.1,        # Cross-term: exposure-focus²
            'a21': -0.001,     # Cross-term: exposure²-focus
            'a03': 20.0,       # Cubic focus effect
        }
        
    def _cd_model(self, exposure: float, focus: float) -> float:
        """
        Physics-based CD model (simplified from paper's Equation 1).
        
        Args:
            exposure: Exposure dose in mJ/cm²
            focus: Focus in μm
            
        Returns:
            Critical dimension in nm
        """
        E = exposure / 100.0  # Normalize exposure
        F = focus
        
        cd = (self.coefficients['a00'] +
              self.coefficients['a10'] * E +
              self.coefficients['a20'] * E**2 +
              self.coefficients['a01'] * F +
              self.coefficients['a02'] * F**2 +
              self.coefficients['a11'] * E * F +
              self.coefficients['a12'] * E * F**2 +
              self.coefficients['a21'] * E**2 * F +
              self.coefficients['a03'] * F**3)
        
        return cd
    
    def generate_matrix(self,
                       exposure_range: Tuple[float, float] = (160.0, 320.0),
                       exposure_points: int = 9,
                       focus_range: Tuple[float, float] = (-1.5, 0.5),
                       focus_points: int = 15,
                       add_noise: bool = True,
                       add_outliers: bool = True,
                       outlier_fraction: float = 0.02) -> pd.DataFrame:
        """
        Generate a complete focus-exposure matrix.
        
        Args:
            exposure_range: (min, max) exposure dose in mJ/cm²
            exposure_points: Number of exposure levels
            focus_range: (min, max) focus in μm
            focus_points: Number of focus points per exposure
            add_noise: Whether to add measurement noise
            add_outliers: Whether to add some outlier data points
            outlier_fraction: Fraction of data points to be outliers
            
        Returns:
            DataFrame with columns: exposure_dose, focus, critical_dimension, measurement_uncertainty
        """
        
        # Create meshgrid
        exposures = np.linspace(exposure_range[0], exposure_range[1], exposure_points)
        focuses = np.linspace(focus_range[0], focus_range[1], focus_points)
        
        data = []
        
        for exposure in exposures:
            for focus in focuses:
                # Calculate ideal CD
                cd_ideal = self._cd_model(exposure, focus)
                
                # Add measurement noise
                if add_noise:
                    noise = np.random.normal(0, cd_ideal * self.noise_level)
                else:
                    noise = 0.0
                
                cd_measured = cd_ideal + noise
                
                # Measurement uncertainty (typically 2-3% of CD)
                uncertainty = cd_measured * 0.025
                
                data.append({
                    'exposure_dose': exposure,
                    'focus': focus,
                    'critical_dimension': cd_measured,
                    'measurement_uncertainty': uncertainty
                })
        
        df = pd.DataFrame(data)
        
        # Add some outliers if requested
        if add_outliers and len(df) > 0:
            n_outliers = max(1, int(len(df) * outlier_fraction))
            outlier_indices = np.random.choice(len(df), n_outliers, replace=False)
            
            for idx in outlier_indices:
                # Add large deviation (3-5σ)
                deviation = np.random.choice([-1, 1]) * np.random.uniform(3, 5)
                df.loc[idx, 'critical_dimension'] += deviation * df.loc[idx, 'measurement_uncertainty']
        
        return df.reset_index(drop=True)
    
    def generate_bossung_curves(self,
                               exposure_levels: Optional[list] = None,
                               focus_range: Tuple[float, float] = (-1.5, 0.5),
                               focus_points: int = 50) -> dict:
        """
        Generate Bossung curves (CD vs Focus at constant Exposure).
        
        Args:
            exposure_levels: List of exposure doses for curves (if None, use default)
            focus_range: (min, max) focus in μm
            focus_points: Number of points per curve
            
        Returns:
            Dictionary with exposure as key and (focus, cd) arrays as values
        """
        
        if exposure_levels is None:
            exposure_levels = [160.0, 180.0, 200.0, 220.0, 240.0, 260.0, 280.0, 300.0, 320.0]
        
        curves = {}
        focuses = np.linspace(focus_range[0], focus_range[1], focus_points)
        
        for exposure in exposure_levels:
            cds = np.array([self._cd_model(exposure, f) for f in focuses])
            curves[exposure] = {
                'focus': focuses,
                'cd': cds
            }
        
        return curves
    
    def generate_process_window(self,
                               exposure_range: Tuple[float, float] = (160.0, 320.0),
                               focus_range: Tuple[float, float] = (-1.5, 0.5),
                               grid_points: int = 50) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Generate process window data (CD values on a 2D grid).
        
        Args:
            exposure_range: (min, max) exposure dose in mJ/cm²
            focus_range: (min, max) focus in μm
            grid_points: Number of points per dimension
            
        Returns:
            Tuple of (exposures, focuses, cd_grid)
        """
        
        exposures = np.linspace(exposure_range[0], exposure_range[1], grid_points)
        focuses = np.linspace(focus_range[0], focus_range[1], grid_points)
        
        E_grid, F_grid = np.meshgrid(exposures, focuses)
        CD_grid = np.zeros_like(E_grid)
        
        for i in range(len(focuses)):
            for j in range(len(exposures)):
                CD_grid[i, j] = self._cd_model(E_grid[i, j], F_grid[i, j])
        
        return exposures, focuses, CD_grid
    
    def export_to_csv(self, df: pd.DataFrame, filename: str) -> None:
        """Export DataFrame to CSV file."""
        df.to_csv(filename, index=False)
        print(f"✓ Data exported to {filename}")
        print(f"  Total data points: {len(df)}")
        print(f"  Exposure range: {df['exposure_dose'].min():.1f} - {df['exposure_dose'].max():.1f} mJ/cm²")
        print(f"  Focus range: {df['focus'].min():.2f} - {df['focus'].max():.2f} μm")
        print(f"  CD range: {df['critical_dimension'].min():.1f} - {df['critical_dimension'].max():.1f} nm")


def main():
    """Generate mock data and save to CSV."""
    
    print("=" * 70)
    print("Bossung Curve Mock Data Generator")
    print("=" * 70)
    
    # Create generator
    generator = BosungMockDataGenerator(
        target_cd=250.0,
        cd_tolerance=0.10,
        noise_level=0.05
    )
    
    # Generate focus-exposure matrix
    print("\n[1] Generating focus-exposure matrix...")
    df_matrix = generator.generate_matrix(
        exposure_range=(160.0, 320.0),
        exposure_points=9,
        focus_range=(-1.5, 0.5),
        focus_points=15,
        add_noise=True,
        add_outliers=True,
        outlier_fraction=0.02
    )
    
    # Export to CSV
    print("\n[2] Exporting to CSV...")
    generator.export_to_csv(df_matrix, '/home/ubuntu/bossung_app/mock_data.csv')
    
    # Display sample data
    print("\n[3] Sample data (first 10 rows):")
    print(df_matrix.head(10).to_string(index=False))
    
    # Generate Bossung curves
    print("\n[4] Generating Bossung curves...")
    curves = generator.generate_bossung_curves()
    print(f"  Generated {len(curves)} Bossung curves")
    for exposure in sorted(curves.keys()):
        print(f"    Exposure {exposure:.1f} mJ/cm²: {len(curves[exposure]['focus'])} points")
    
    # Generate process window
    print("\n[5] Generating process window grid...")
    exp_grid, foc_grid, cd_grid = generator.generate_process_window(grid_points=30)
    print(f"  Grid size: {cd_grid.shape}")
    print(f"  CD range: {cd_grid.min():.1f} - {cd_grid.max():.1f} nm")
    
    print("\n" + "=" * 70)
    print("Mock data generation completed successfully!")
    print("=" * 70)


if __name__ == "__main__":
    main()
