#!/usr/bin/env python3.11
"""
Bossung Curve Analysis Application
Integrated tool for lithography process window analysis
"""

import argparse
import sys
import os
from pathlib import Path
import pandas as pd
import numpy as np
from typing import Optional

from data_generator import BosungMockDataGenerator
from polynomial_fitter import PolynomialFitter
from bossung_plotter import BosungPlotter
from process_window_analyzer import ProcessWindowAnalyzer


class BosungAnalysisApp:
    """Main application class for Bossung curve analysis."""
    
    def __init__(self, output_dir: str = './output'):
        """
        Initialize the application.
        
        Args:
            output_dir: Directory for output files
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        self.data = None
        self.fitter = None
        self.plotter = None
        self.analyzer = None
    
    def generate_mock_data(self,
                          exposure_range: tuple = (160.0, 320.0),
                          exposure_points: int = 9,
                          focus_range: tuple = (-1.5, 0.5),
                          focus_points: int = 15,
                          add_noise: bool = True,
                          add_outliers: bool = True) -> pd.DataFrame:
        """
        Generate mock focus-exposure matrix data.
        
        Args:
            exposure_range: (min, max) exposure dose
            exposure_points: Number of exposure levels
            focus_range: (min, max) focus
            focus_points: Number of focus points per exposure
            add_noise: Whether to add measurement noise
            add_outliers: Whether to add outliers
            
        Returns:
            DataFrame with mock data
        """
        print("\n[1] Generating mock data...")
        
        generator = BosungMockDataGenerator(
            target_cd=250.0,
            cd_tolerance=0.10,
            noise_level=0.05
        )
        
        self.data = generator.generate_matrix(
            exposure_range=exposure_range,
            exposure_points=exposure_points,
            focus_range=focus_range,
            focus_points=focus_points,
            add_noise=add_noise,
            add_outliers=add_outliers
        )
        
        # Save to CSV
        csv_path = self.output_dir / 'mock_data.csv'
        self.data.to_csv(csv_path, index=False)
        print(f"  ✓ Generated {len(self.data)} data points")
        print(f"  ✓ Saved to {csv_path}")
        
        return self.data
    
    def load_data(self, csv_file: str) -> pd.DataFrame:
        """
        Load focus-exposure data from CSV file.
        
        Args:
            csv_file: Path to CSV file
            
        Returns:
            DataFrame with data
        """
        print(f"\n[1] Loading data from {csv_file}...")
        
        self.data = pd.read_csv(csv_file)
        print(f"  ✓ Loaded {len(self.data)} data points")
        print(f"  Columns: {', '.join(self.data.columns)}")
        
        return self.data
    
    def fit_polynomial_model(self, use_weights: bool = True) -> dict:
        """
        Fit polynomial model to data.
        
        Args:
            use_weights: Whether to use measurement uncertainty as weights
            
        Returns:
            Dictionary with fit results
        """
        if self.data is None:
            raise ValueError("No data loaded. Call load_data() or generate_mock_data() first.")
        
        print("\n[2] Fitting polynomial model...")
        
        self.fitter = PolynomialFitter(max_iterations=2, sigma_threshold=2.0)
        results = self.fitter.fit(self.data, use_weights=use_weights)
        
        print(f"  ✓ Fit completed")
        print(f"  R²: {results['r_squared']:.6f}")
        
        return results
    
    def plot_bossung_curves(self,
                           target_cd: float = 250.0,
                           cd_tolerance: float = 0.10,
                           figsize: tuple = (12, 8)) -> str:
        """
        Generate Bossung curve plots.
        
        Args:
            target_cd: Target CD in nm
            cd_tolerance: CD tolerance as fraction
            figsize: Figure size
            
        Returns:
            Path to saved figure
        """
        if self.data is None:
            raise ValueError("No data loaded.")
        
        print("\n[3] Plotting Bossung curves...")
        
        self.plotter = BosungPlotter(style='seaborn-v0_8-darkgrid', dpi=150)
        
        fig, ax = self.plotter.plot_bossung_curves(
            self.data,
            target_cd=target_cd,
            cd_tolerance=cd_tolerance,
            figsize=figsize,
            show_spec_limits=True,
            show_data_points=True,
            colormap='viridis'
        )
        
        output_path = self.output_dir / 'bossung_curves.png'
        self.plotter.save_figure(str(output_path))
        print(f"  ✓ Saved to {output_path}")
        
        return str(output_path)
    
    def plot_process_window(self,
                           target_cd: float = 250.0,
                           cd_tolerance: float = 0.10,
                           grid_points: int = 50) -> str:
        """
        Generate process window contour plot.
        
        Args:
            target_cd: Target CD in nm
            cd_tolerance: CD tolerance as fraction
            grid_points: Number of grid points per dimension
            
        Returns:
            Path to saved figure
        """
        print("\n[4] Generating process window...")
        
        # Generate process window grid
        generator = BosungMockDataGenerator(target_cd=target_cd)
        exp_grid, foc_grid, cd_grid = generator.generate_process_window(
            grid_points=grid_points
        )
        
        print(f"  ✓ Generated {grid_points}×{grid_points} grid")
        
        # Plot
        if self.plotter is None:
            self.plotter = BosungPlotter(style='seaborn-v0_8-darkgrid', dpi=150)
        
        fig, ax = self.plotter.plot_process_window_contour(
            exp_grid, foc_grid, cd_grid,
            target_cd=target_cd,
            cd_tolerance=cd_tolerance,
            figsize=(10, 8),
            levels=25
        )
        
        output_path = self.output_dir / 'process_window.png'
        self.plotter.save_figure(str(output_path))
        print(f"  ✓ Saved to {output_path}")
        
        return str(output_path)
    
    def analyze_process_window(self,
                              target_cd: float = 250.0,
                              cd_tolerance: float = 0.10,
                              grid_points: int = 50) -> dict:
        """
        Analyze process window characteristics.
        
        Args:
            target_cd: Target CD in nm
            cd_tolerance: CD tolerance as fraction
            grid_points: Number of grid points for MIR calculation
            
        Returns:
            Dictionary with analysis results
        """
        if self.data is None:
            raise ValueError("No data loaded.")
        
        print("\n[5] Analyzing process window...")
        
        self.analyzer = ProcessWindowAnalyzer(
            target_cd=target_cd,
            cd_tolerance=cd_tolerance
        )
        
        # Calculate DOF and EL
        dof_el = self.analyzer.calculate_dof_el(self.data)
        
        # Find optimal process point
        optimal = self.analyzer.find_optimal_process_point(self.data)
        
        # Generate process window grid and find MIR
        generator = BosungMockDataGenerator(target_cd=target_cd)
        exp_grid, foc_grid, cd_grid = generator.generate_process_window(
            grid_points=grid_points
        )
        mir = self.analyzer.find_maximum_inscribed_rectangle(
            exp_grid, foc_grid, cd_grid
        )
        
        # Generate report
        report = self.analyzer.generate_report()
        report_path = self.output_dir / 'process_window_report.txt'
        with open(report_path, 'w') as f:
            f.write(report)
        print(f"  ✓ Report saved to {report_path}")
        
        return {
            'dof_el': dof_el,
            'optimal': optimal,
            'mir': mir,
            'report': report
        }
    
    def run_full_analysis(self,
                         input_file: Optional[str] = None,
                         target_cd: float = 250.0,
                         cd_tolerance: float = 0.10):
        """
        Run complete analysis pipeline.
        
        Args:
            input_file: Path to input CSV (if None, generate mock data)
            target_cd: Target CD in nm
            cd_tolerance: CD tolerance as fraction
        """
        print("\n" + "="*70)
        print("BOSSUNG CURVE ANALYSIS APPLICATION")
        print("="*70)
        
        # Load or generate data
        if input_file:
            self.load_data(input_file)
        else:
            self.generate_mock_data()
        
        # Fit model
        self.fit_polynomial_model()
        
        # Generate plots
        self.plot_bossung_curves(target_cd=target_cd, cd_tolerance=cd_tolerance)
        self.plot_process_window(target_cd=target_cd, cd_tolerance=cd_tolerance)
        
        # Analyze process window
        analysis = self.analyze_process_window(
            target_cd=target_cd,
            cd_tolerance=cd_tolerance
        )
        
        print("\n" + "="*70)
        print("ANALYSIS COMPLETED SUCCESSFULLY")
        print("="*70)
        print(f"\nOutput files saved to: {self.output_dir.absolute()}")
        print("  - mock_data.csv (input data)")
        print("  - bossung_curves.png (Bossung curve plot)")
        print("  - process_window.png (process window contour plot)")
        print("  - process_window_report.txt (analysis report)")
        
        return analysis


def main():
    """Command-line interface."""
    
    parser = argparse.ArgumentParser(
        description='Bossung Curve Analysis Tool for Lithography Process Window',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run with mock data (default)
  python bossung_app.py
  
  # Use custom input file
  python bossung_app.py --input my_data.csv
  
  # Specify output directory
  python bossung_app.py --output ./results
  
  # Custom target CD and tolerance
  python bossung_app.py --target-cd 300 --tolerance 0.15
        """
    )
    
    parser.add_argument('--input', '-i', type=str, default=None,
                       help='Input CSV file with focus-exposure data')
    parser.add_argument('--output', '-o', type=str, default='./output',
                       help='Output directory for results (default: ./output)')
    parser.add_argument('--target-cd', type=float, default=250.0,
                       help='Target critical dimension in nm (default: 250)')
    parser.add_argument('--tolerance', type=float, default=0.10,
                       help='CD tolerance as fraction (default: 0.10 for ±10%)')
    parser.add_argument('--grid-points', type=int, default=50,
                       help='Grid points for process window (default: 50)')
    
    args = parser.parse_args()
    
    # Create and run application
    app = BosungAnalysisApp(output_dir=args.output)
    
    try:
        app.run_full_analysis(
            input_file=args.input,
            target_cd=args.target_cd,
            cd_tolerance=args.tolerance
        )
    except Exception as e:
        print(f"\n✗ Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
