# Bossung Curve Visualization Application - Architecture Design

## System Overview

```mermaid
graph TB
    subgraph Data["Data Layer"]
        CSV["CSV Input Data<br/>Focus-Exposure Matrix"]
        MockGen["Mock Data Generator"]
    end
    
    subgraph Processing["Processing Layer"]
        Parser["Data Parser"]
        Fitter["Polynomial Fitter<br/>Chi-squared Optimization"]
        PW["Process Window<br/>Analyzer"]
    end
    
    subgraph Visualization["Visualization Layer"]
        Bossung["Bossung Curve<br/>Plotter"]
        PW_Plot["Process Window<br/>Plot"]
        Export["Export to PNG/PDF"]
    end
    
    subgraph UI["User Interface"]
        CLI["CLI Interface"]
        WebUI["Web Dashboard<br/>Flask + React"]
    end
    
    CSV --> Parser
    MockGen --> Parser
    Parser --> Fitter
    Fitter --> PW
    Fitter --> Bossung
    PW --> PW_Plot
    Bossung --> Export
    Bossung --> WebUI
    PW_Plot --> WebUI
    WebUI --> UI
    CLI --> UI
```

## Module Structure

### 1. **data_generator.py**
- Generate mock focus-exposure matrix data
- Simulate realistic CD variations based on physics model
- Export to CSV format

### 2. **data_parser.py**
- Load CSV data
- Validate data structure
- Handle missing values and outliers

### 3. **polynomial_fitter.py**
- Implement polynomial fitting (Equation 1 from paper)
- Chi-squared optimization
- Weighted fitting support
- Data flier removal (2σ threshold)

### 4. **bossung_plotter.py**
- Plot Bossung curves (Focus vs. CD at constant Exposure)
- Multiple curves for different exposure levels
- Professional styling with matplotlib/seaborn
- Tolerance band visualization

### 5. **process_window_analyzer.py**
- Calculate Depth of Focus (DOF)
- Calculate Exposure Latitude (EL)
- Find Maximum Inscribed Rectangle
- Generate process window contour plots

### 6. **app.py** (Flask Backend)
- REST API endpoints
- Data upload and processing
- Result caching

### 7. **frontend/** (React)
- Interactive visualization
- Parameter adjustment
- Real-time plot updates

## Data Structure

### Input CSV Format
```
exposure_dose,focus,critical_dimension,measurement_uncertainty
160.0,-1.5,700.0,10.0
160.0,-1.4,680.0,10.0
160.0,-1.3,650.0,10.0
...
320.0,0.5,100.0,8.0
```

### Internal Data Model
```python
@dataclass
class FocusExposureData:
    exposure: np.ndarray      # Exposure dose values
    focus: np.ndarray         # Focus values
    cd: np.ndarray           # Critical dimension measurements
    uncertainty: np.ndarray   # Measurement uncertainty (optional)
    
@dataclass
class PolynomialModel:
    coefficients: np.ndarray  # a_ij coefficients
    residuals: np.ndarray
    r_squared: float
    
@dataclass
class ProcessWindow:
    dof: float               # Depth of Focus
    el: float                # Exposure Latitude
    center_exposure: float
    center_focus: float
    max_rectangle: dict      # MIR parameters
```

## Workflow

1. **Data Input**: Load CSV or generate mock data
2. **Data Validation**: Check structure and quality
3. **Polynomial Fitting**: Optimize coefficients using chi-squared
4. **Outlier Removal**: Remove data fliers exceeding 2σ
5. **Refitting**: Refit with cleaned data
6. **Bossung Curve Generation**: Plot multiple curves
7. **Process Window Analysis**: Calculate DOF, EL, MIR
8. **Visualization**: Generate professional plots
9. **Export**: Save to PNG/PDF

## Key Features

### Bossung Curve Visualization
- Multiple exposure levels on single plot
- Color-coded by exposure dose
- Fitted polynomial curves
- Confidence intervals (optional)
- Specification limits (±10% CD tolerance)

### Process Window Analysis
- 2D contour plot (Exposure vs. Focus)
- Specification boundary visualization
- Maximum Inscribed Rectangle highlighting
- DOF and EL metrics display

### Professional Output
- High-resolution plots (300+ DPI)
- Publication-ready styling
- Customizable color schemes
- Legend and annotations
- Grid and axis labels

## Technology Stack

| Component | Technology |
|-----------|-----------|
| Backend | Python 3.11, Flask |
| Data Processing | NumPy, SciPy, Pandas |
| Visualization | Matplotlib, Seaborn, Plotly |
| Frontend | React, TypeScript, TailwindCSS |
| Data Fitting | scikit-learn (Random Forest for EDForest) |
| Export | Pillow, ReportLab, WeasyPrint |

## Deployment Options

1. **CLI Tool**: Standalone Python script with command-line interface
2. **Web Application**: Flask backend + React frontend
3. **Jupyter Notebook**: Interactive analysis environment
4. **Docker Container**: Containerized deployment

## Performance Considerations

- Vectorized NumPy operations for speed
- Caching of fitted coefficients
- Lazy loading of visualization data
- Parallel processing for multiple curves (optional)
