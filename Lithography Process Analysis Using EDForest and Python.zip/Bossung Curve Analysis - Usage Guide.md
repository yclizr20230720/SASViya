# Bossung Curve Analysis - Usage Guide

## Table of Contents
1. [Getting Started](#getting-started)
2. [Basic Examples](#basic-examples)
3. [Advanced Usage](#advanced-usage)
4. [Data Preparation](#data-preparation)
5. [Interpreting Results](#interpreting-results)
6. [Tips and Best Practices](#tips-and-best-practices)

## Getting Started

### Installation
```bash
# Navigate to application directory
cd /home/ubuntu/bossung_app

# Verify Python version
python3.11 --version

# Check dependencies
python3.11 -c "import numpy, pandas, matplotlib, scipy; print('✓ All dependencies installed')"
```

### First Run
```bash
# Run with default settings (generates mock data)
python3.11 bossung_app.py

# Check output directory
ls -la output/
```

## Basic Examples

### Example 1: Generate and Analyze Mock Data
```bash
python3.11 bossung_app.py --output ./example1_output
```

**Output**:
- `bossung_curves.png`: Shows CD vs Focus at different exposure levels
- `process_window.png`: 2D contour map of the process window
- `process_window_report.txt`: Analysis metrics (DOF, EL, etc.)
- `mock_data.csv`: Input data used

### Example 2: Analyze Your Own Data
```bash
# Prepare your CSV file with columns:
# exposure_dose, focus, critical_dimension, measurement_uncertainty

python3.11 bossung_app.py \
  --input my_lithography_data.csv \
  --output ./my_results
```

### Example 3: Custom Target CD and Tolerance
```bash
# For 300 nm target CD with ±15% tolerance
python3.11 bossung_app.py \
  --target-cd 300 \
  --tolerance 0.15 \
  --output ./custom_cd_results
```

### Example 4: High-Resolution Process Window
```bash
# Generate finer grid for more detailed analysis
python3.11 bossung_app.py \
  --grid-points 100 \
  --output ./high_res_output
```

## Advanced Usage

### Using the Python API

#### Complete Analysis Workflow
```python
from bossung_app import BosungAnalysisApp
import pandas as pd

# Initialize application
app = BosungAnalysisApp(output_dir='./api_results')

# Option A: Generate mock data
app.generate_mock_data(
    exposure_range=(150.0, 330.0),
    exposure_points=12,
    focus_range=(-1.8, 0.8),
    focus_points=20,
    add_noise=True,
    add_outliers=True
)

# Option B: Load your data
# app.load_data('my_data.csv')

# Fit polynomial model
fit_results = app.fit_polynomial_model(use_weights=True)
print(f"Model R²: {fit_results['r_squared']:.6f}")
print(f"Removed outliers: {fit_results['removed_points']}")

# Generate visualizations
bossung_path = app.plot_bossung_curves(
    target_cd=250.0,
    cd_tolerance=0.10,
    figsize=(14, 9)
)

pw_path = app.plot_process_window(
    target_cd=250.0,
    cd_tolerance=0.10,
    grid_points=60
)

# Analyze process window
analysis = app.analyze_process_window(
    target_cd=250.0,
    cd_tolerance=0.10,
    grid_points=60
)

# Print report
print(analysis['report'])
```

#### Accessing Fitted Coefficients
```python
from polynomial_fitter import PolynomialFitter
import pandas as pd

# Load data
df = pd.read_csv('mock_data.csv')

# Fit model
fitter = PolynomialFitter(max_iterations=2, sigma_threshold=2.0)
results = fitter.fit(df, use_weights=True)

# Get coefficients
coefficients = fitter.get_coefficients_dict()
print("Polynomial Coefficients:")
for name, value in coefficients.items():
    print(f"  {name}: {value:.6f}")

# Make predictions
import numpy as np
exposure = np.array([200.0, 240.0, 280.0])
focus = np.array([0.0, 0.0, 0.0])
predictions = fitter.predict(exposure, focus)

for e, f, pred in zip(exposure, focus, predictions):
    print(f"E={e:.0f} mJ/cm², F={f:.2f} μm → CD={pred:.2f} nm")
```

#### Custom Visualization
```python
from bossung_plotter import BosungPlotter
import pandas as pd

# Load data
df = pd.read_csv('mock_data.csv')

# Create plotter with custom settings
plotter = BosungPlotter(style='seaborn-v0_8-darkgrid', dpi=300)

# Plot with custom parameters
fig, ax = plotter.plot_bossung_curves(
    df,
    target_cd=250.0,
    cd_tolerance=0.10,
    figsize=(16, 10),
    show_spec_limits=True,
    show_data_points=True,
    colormap='coolwarm'
)

# Save with high resolution
plotter.save_figure('high_res_bossung.png', dpi=300)

# Display
plotter.show()
```

#### Detailed Process Window Analysis
```python
from process_window_analyzer import ProcessWindowAnalyzer
from data_generator import BosungMockDataGenerator
import pandas as pd

# Load data
df = pd.read_csv('mock_data.csv')

# Create analyzer
analyzer = ProcessWindowAnalyzer(target_cd=250.0, cd_tolerance=0.10)

# Calculate DOF and EL
dof_el = analyzer.calculate_dof_el(df)
print(f"Average DOF: {dof_el['avg_dof']:.4f} μm")
print(f"Average EL: {dof_el['avg_el']:.2f} mJ/cm²")

# Find optimal process point
optimal = analyzer.find_optimal_process_point(df)
print(f"Optimal E: {optimal['exposure']:.1f} mJ/cm²")
print(f"Optimal F: {optimal['focus']:.3f} μm")
print(f"CD deviation: {optimal['cd_deviation']:+.2f} nm")

# Find Maximum Inscribed Rectangle
generator = BosungMockDataGenerator()
exp_grid, foc_grid, cd_grid = generator.generate_process_window(grid_points=50)
mir = analyzer.find_maximum_inscribed_rectangle(exp_grid, foc_grid, cd_grid)

if mir['found']:
    print(f"MIR Area: {mir['area']:.4f} (mJ/cm² × μm)")
    print(f"MIR Center: E={mir['center_exposure']:.1f}, F={mir['center_focus']:.3f}")
```

## Data Preparation

### Creating Input CSV

**Step 1: Collect lithography simulation or experimental data**
- Multiple exposure levels (typically 8-12 levels)
- Multiple focus positions per exposure (typically 12-20 positions)
- Measure critical dimension (CD) at each point
- Estimate measurement uncertainty

**Step 2: Format as CSV**
```csv
exposure_dose,focus,critical_dimension,measurement_uncertainty
160.0,-1.5,337.83,8.45
160.0,-1.36,309.39,7.73
...
```

**Step 3: Validate data**
```python
import pandas as pd

df = pd.read_csv('my_data.csv')

# Check structure
print(f"Rows: {len(df)}")
print(f"Columns: {list(df.columns)}")

# Check ranges
print(f"Exposure range: {df['exposure_dose'].min():.1f} - {df['exposure_dose'].max():.1f}")
print(f"Focus range: {df['focus'].min():.2f} - {df['focus'].max():.2f}")
print(f"CD range: {df['critical_dimension'].min():.1f} - {df['critical_dimension'].max():.1f}")

# Check for missing values
print(f"Missing values: {df.isnull().sum().sum()}")
```

### Data Quality Considerations

| Issue | Impact | Solution |
|-------|--------|----------|
| Sparse data | Poor fitting | Increase number of measurements |
| High noise | Low R² | Improve measurement technique |
| Outliers | Biased fit | Application removes automatically |
| Missing uncertainty | Unweighted fit | Estimate or use defaults |

## Interpreting Results

### Bossung Curves
- **X-axis**: Focus position (μm)
- **Y-axis**: Critical dimension (nm)
- **Each curve**: Constant exposure level
- **U-shape**: Typical parabolic behavior
- **Shaded region**: Specification window (green)

**Interpretation**:
- Wider U-shape → Better depth of focus (DOF)
- Curves closer together → Better exposure latitude (EL)
- Curves within green band → In-specification process window

### Process Window Contour Map
- **X-axis**: Exposure dose (mJ/cm²)
- **Y-axis**: Focus position (μm)
- **Color**: Critical dimension (nm)
- **Blue contour**: Lower specification limit
- **Red contour**: Upper specification limit
- **Green contour**: Target CD

**Interpretation**:
- Larger green region → Larger process window
- Centered region → Robust process
- Narrow region → Tight process control needed

### Analysis Metrics

| Metric | Definition | Good Value |
|--------|-----------|-----------|
| **DOF** | Depth of Focus | >0.3 μm |
| **EL** | Exposure Latitude | >50 mJ/cm² |
| **R²** | Model fit quality | >0.8 |
| **σ** | Residual std dev | <5% of CD |

### Report Interpretation
```
DOF: 0.1190 μm
  → Focus can vary by ±0.06 μm and stay in spec
  
EL: 70.00 mJ/cm²
  → Exposure can vary by ±35 mJ/cm² and stay in spec
  
Optimal Point: E=200 mJ/cm², F=-0.5 μm
  → Best process settings for robustness
```

## Tips and Best Practices

### 1. Data Collection
- Collect data on a regular grid (uniform spacing)
- Include edge cases (extreme focus/exposure)
- Measure multiple times for uncertainty estimation
- Use consistent measurement technique

### 2. Fitting
- Start with default parameters (2 iterations, 2σ threshold)
- Check R² value (should be >0.7)
- Review residuals plot for patterns
- Increase iterations if outliers remain

### 3. Analysis
- Compare DOF and EL values across different process conditions
- Use optimal process point as starting condition
- Validate MIR results visually on contour plot
- Document target CD and tolerance assumptions

### 4. Visualization
- Export plots at 300 DPI for publications
- Use consistent color schemes across reports
- Include specification limits on all plots
- Add annotations for key features

### 5. Batch Processing
```python
import os
from bossung_app import BosungAnalysisApp

# Process multiple files
data_files = [
    'wafer_lot1.csv',
    'wafer_lot2.csv',
    'wafer_lot3.csv'
]

for filename in data_files:
    print(f"\nProcessing {filename}...")
    
    app = BosungAnalysisApp(output_dir=f'./results/{filename[:-4]}')
    app.load_data(filename)
    app.fit_polynomial_model()
    app.plot_bossung_curves()
    app.analyze_process_window()
    
    print(f"✓ Completed {filename}")
```

### 6. Troubleshooting Checklist
- [ ] Input CSV has correct column names
- [ ] Data values are in expected ranges
- [ ] No missing values in required columns
- [ ] Target CD matches data range
- [ ] Tolerance is reasonable (typically 5-20%)
- [ ] Output directory is writable
- [ ] Sufficient disk space for plots

## Common Workflows

### Workflow 1: Quick Process Characterization
```bash
python3.11 bossung_app.py --input process_data.csv
# Takes ~3 seconds
# Generates complete analysis with default parameters
```

### Workflow 2: Detailed Optimization Study
```bash
# Run with different tolerances to find optimal window
for tol in 0.05 0.10 0.15 0.20; do
    python3.11 bossung_app.py \
      --input process_data.csv \
      --tolerance $tol \
      --output "./results_tol_$tol"
done
```

### Workflow 3: Multi-Process Comparison
```bash
# Compare multiple lithography processes
for process in process_A process_B process_C; do
    python3.11 bossung_app.py \
      --input "${process}_data.csv" \
      --output "./comparison/$process"
done
```

---

**For more information**, refer to:
- `README.md`: Complete documentation
- `bossung_app.py`: Main application code
- Reference paper: "Improved Model for Focus-Exposure Data Analysis" (Mack & Byers, 2003)
