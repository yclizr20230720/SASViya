"""
Process Window Analyzer
Calculates DOF, EL, and Maximum Inscribed Rectangle for lithography process window
"""

import numpy as np
import pandas as pd
from scipy.ndimage import label, find_objects
from scipy.optimize import minimize
from typing import Dict, Tuple, Optional
import warnings

warnings.filterwarnings('ignore')


class ProcessWindowAnalyzer:
    """
    Analyze process window characteristics from focus-exposure matrix data.
    
    Calculates:
    - Depth of Focus (DOF): Range of focus values where CD is within spec
    - Exposure Latitude (EL): Range of exposure values where CD is within spec
    - Maximum Inscribed Rectangle (MIR): Optimal process window
    """
    
    def __init__(self, target_cd: float = 250.0, cd_tolerance: float = 0.10):
        """
        Initialize the analyzer.
        
        Args:
            target_cd: Target critical dimension in nm
            cd_tolerance: CD tolerance as fraction (e.g., 0.10 for ±10%)
        """
        self.target_cd = target_cd
        self.cd_tolerance = cd_tolerance
        self.cd_min = target_cd * (1 - cd_tolerance)
        self.cd_max = target_cd * (1 + cd_tolerance)
        
        self.results = {}
    
    def calculate_dof_el(self, df: pd.DataFrame) -> Dict:
        """
        Calculate Depth of Focus (DOF) and Exposure Latitude (EL).
        
        DOF: For each exposure level, find the range of focus values where CD is within spec
        EL: For each focus level, find the range of exposure values where CD is within spec
        
        Args:
            df: DataFrame with columns: exposure_dose, focus, critical_dimension
            
        Returns:
            Dictionary with DOF and EL statistics
        """
        
        print("\n" + "="*70)
        print("Process Window Analysis: DOF and EL Calculation")
        print("="*70)
        print(f"Target CD: {self.target_cd:.1f} nm")
        print(f"Spec Limits: {self.cd_min:.1f} - {self.cd_max:.1f} nm (±{self.cd_tolerance*100:.0f}%)")
        
        # Calculate DOF for each exposure level
        dof_data = []
        for exposure in sorted(df['exposure_dose'].unique()):
            mask = df['exposure_dose'] == exposure
            data_exp = df[mask].sort_values('focus')
            
            # Find focus range where CD is within spec
            in_spec = (data_exp['critical_dimension'] >= self.cd_min) & \
                     (data_exp['critical_dimension'] <= self.cd_max)
            
            if in_spec.any():
                focus_in_spec = data_exp[in_spec]['focus'].values
                focus_min = focus_in_spec.min()
                focus_max = focus_in_spec.max()
                dof = focus_max - focus_min
                
                dof_data.append({
                    'exposure': exposure,
                    'focus_min': focus_min,
                    'focus_max': focus_max,
                    'dof': dof,
                    'points_in_spec': in_spec.sum()
                })
        
        dof_df = pd.DataFrame(dof_data)
        
        if len(dof_df) > 0:
            print(f"\nDepth of Focus (DOF) Analysis:")
            print(f"  Average DOF: {dof_df['dof'].mean():.4f} μm")
            print(f"  Min DOF: {dof_df['dof'].min():.4f} μm (at E={dof_df.loc[dof_df['dof'].idxmin(), 'exposure']:.0f} mJ/cm²)")
            print(f"  Max DOF: {dof_df['dof'].max():.4f} μm (at E={dof_df.loc[dof_df['dof'].idxmax(), 'exposure']:.0f} mJ/cm²)")
        
        # Calculate EL for each focus level
        el_data = []
        for focus in sorted(df['focus'].unique()):
            mask = df['focus'] == focus
            data_foc = df[mask].sort_values('exposure_dose')
            
            # Find exposure range where CD is within spec
            in_spec = (data_foc['critical_dimension'] >= self.cd_min) & \
                     (data_foc['critical_dimension'] <= self.cd_max)
            
            if in_spec.any():
                exp_in_spec = data_foc[in_spec]['exposure_dose'].values
                exp_min = exp_in_spec.min()
                exp_max = exp_in_spec.max()
                el = exp_max - exp_min
                
                el_data.append({
                    'focus': focus,
                    'exposure_min': exp_min,
                    'exposure_max': exp_max,
                    'el': el,
                    'points_in_spec': in_spec.sum()
                })
        
        el_df = pd.DataFrame(el_data)
        
        if len(el_df) > 0:
            print(f"\nExposure Latitude (EL) Analysis:")
            print(f"  Average EL: {el_df['el'].mean():.2f} mJ/cm²")
            print(f"  Min EL: {el_df['el'].min():.2f} mJ/cm² (at F={el_df.loc[el_df['el'].idxmin(), 'focus']:.2f} μm)")
            print(f"  Max EL: {el_df['el'].max():.2f} mJ/cm² (at F={el_df.loc[el_df['el'].idxmax(), 'focus']:.2f} μm)")
        
        self.results['dof'] = dof_df
        self.results['el'] = el_df
        
        return {
            'dof_df': dof_df,
            'el_df': el_df,
            'avg_dof': dof_df['dof'].mean() if len(dof_df) > 0 else 0,
            'avg_el': el_df['el'].mean() if len(el_df) > 0 else 0
        }
    
    def find_maximum_inscribed_rectangle(self, 
                                        exposures: np.ndarray,
                                        focuses: np.ndarray,
                                        cd_grid: np.ndarray) -> Dict:
        """
        Find the Maximum Inscribed Rectangle (MIR) in the process window.
        
        The MIR is the largest rectangle in the E-F plane where all CD values
        are within specification limits.
        
        Args:
            exposures: 1D array of exposure values
            focuses: 1D array of focus values
            cd_grid: 2D grid of CD values (focus × exposure)
            
        Returns:
            Dictionary with MIR parameters
        """
        
        print("\n" + "="*70)
        print("Maximum Inscribed Rectangle (MIR) Analysis")
        print("="*70)
        
        # Create binary mask: 1 where CD is in spec, 0 otherwise
        in_spec_mask = (cd_grid >= self.cd_min) & (cd_grid <= self.cd_max)
        
        # Find connected components
        labeled_array, num_features = label(in_spec_mask)
        
        print(f"In-spec region: {in_spec_mask.sum()} / {in_spec_mask.size} points ({100*in_spec_mask.sum()/in_spec_mask.size:.1f}%)")
        
        if num_features == 0:
            print("Warning: No in-spec region found!")
            return {
                'found': False,
                'area': 0,
                'exposure_range': (0, 0),
                'focus_range': (0, 0)
            }
        
        # Find the largest connected component
        slices = find_objects(labeled_array)
        max_area = 0
        best_slice = None
        
        for slice_obj in slices:
            if slice_obj is not None:
                area = (slice_obj[0].stop - slice_obj[0].start) * (slice_obj[1].stop - slice_obj[1].start)
                if area > max_area:
                    max_area = area
                    best_slice = slice_obj
        
        if best_slice is None:
            return {
                'found': False,
                'area': 0,
                'exposure_range': (0, 0),
                'focus_range': (0, 0)
            }
        
        # Extract MIR bounds
        focus_slice, exp_slice = best_slice
        
        focus_idx_min = focus_slice.start
        focus_idx_max = focus_slice.stop - 1
        exp_idx_min = exp_slice.start
        exp_idx_max = exp_slice.stop - 1
        
        focus_min = focuses[focus_idx_min]
        focus_max = focuses[focus_idx_max]
        exp_min = exposures[exp_idx_min]
        exp_max = exposures[exp_idx_max]
        
        mir_dof = focus_max - focus_min
        mir_el = exp_max - exp_min
        mir_area = mir_dof * mir_el
        
        print(f"\nMIR Found:")
        print(f"  Exposure range: {exp_min:.1f} - {exp_max:.1f} mJ/cm² (EL = {mir_el:.1f})")
        print(f"  Focus range: {focus_min:.3f} - {focus_max:.3f} μm (DOF = {mir_dof:.3f})")
        print(f"  Area: {mir_area:.4f} (mJ/cm² × μm)")
        print(f"  Center: E={exp_min + mir_el/2:.1f} mJ/cm², F={focus_min + mir_dof/2:.3f} μm")
        
        mir_result = {
            'found': True,
            'area': mir_area,
            'exposure_range': (exp_min, exp_max),
            'focus_range': (focus_min, focus_max),
            'center_exposure': exp_min + mir_el / 2,
            'center_focus': focus_min + mir_dof / 2,
            'dof': mir_dof,
            'el': mir_el,
            'slice': best_slice
        }
        
        self.results['mir'] = mir_result
        
        return mir_result
    
    def find_optimal_process_point(self, df: pd.DataFrame) -> Dict:
        """
        Find the optimal process point (center of process window).
        
        This is the point that maximizes DOF and EL simultaneously.
        
        Args:
            df: DataFrame with focus-exposure data
            
        Returns:
            Dictionary with optimal point information
        """
        
        print("\n" + "="*70)
        print("Optimal Process Point Analysis")
        print("="*70)
        
        # Group by exposure and calculate DOF at each exposure
        exposure_levels = sorted(df['exposure_dose'].unique())
        dof_values = []
        
        for exposure in exposure_levels:
            mask = df['exposure_dose'] == exposure
            data_exp = df[mask].sort_values('focus')
            
            in_spec = (data_exp['critical_dimension'] >= self.cd_min) & \
                     (data_exp['critical_dimension'] <= self.cd_max)
            
            if in_spec.any():
                focus_in_spec = data_exp[in_spec]['focus'].values
                dof = focus_in_spec.max() - focus_in_spec.min()
                dof_values.append(dof)
        
        # Find exposure with maximum DOF
        if len(dof_values) > 0:
            max_dof_idx = np.argmax(dof_values)
            optimal_exposure = exposure_levels[max_dof_idx]
            
            # Find optimal focus at this exposure (minimum CD deviation)
            mask = df['exposure_dose'] == optimal_exposure
            data_exp = df[mask]
            
            cd_deviation = np.abs(data_exp['critical_dimension'] - self.target_cd)
            optimal_focus_idx = cd_deviation.idxmin()
            optimal_focus = data_exp.loc[optimal_focus_idx, 'focus']
            optimal_cd = data_exp.loc[optimal_focus_idx, 'critical_dimension']
            
            print(f"\nOptimal Process Point:")
            print(f"  Exposure: {optimal_exposure:.1f} mJ/cm²")
            print(f"  Focus: {optimal_focus:.3f} μm")
            print(f"  CD: {optimal_cd:.2f} nm (deviation: {optimal_cd - self.target_cd:+.2f} nm)")
            print(f"  DOF at this exposure: {dof_values[max_dof_idx]:.4f} μm")
            
            return {
                'exposure': optimal_exposure,
                'focus': optimal_focus,
                'cd': optimal_cd,
                'cd_deviation': optimal_cd - self.target_cd,
                'dof': dof_values[max_dof_idx]
            }
        
        return {'found': False}
    
    def generate_report(self) -> str:
        """Generate a text report of process window analysis."""
        
        report = "\n" + "="*70 + "\n"
        report += "PROCESS WINDOW ANALYSIS REPORT\n"
        report += "="*70 + "\n\n"
        
        report += f"Target CD: {self.target_cd:.1f} nm\n"
        report += f"CD Tolerance: ±{self.cd_tolerance*100:.0f}%\n"
        report += f"Spec Limits: {self.cd_min:.1f} - {self.cd_max:.1f} nm\n\n"
        
        if 'dof' in self.results:
            dof_df = self.results['dof']
            report += f"Depth of Focus (DOF):\n"
            report += f"  Average: {dof_df['dof'].mean():.4f} μm\n"
            report += f"  Range: {dof_df['dof'].min():.4f} - {dof_df['dof'].max():.4f} μm\n\n"
        
        if 'el' in self.results:
            el_df = self.results['el']
            report += f"Exposure Latitude (EL):\n"
            report += f"  Average: {el_df['el'].mean():.2f} mJ/cm²\n"
            report += f"  Range: {el_df['el'].min():.2f} - {el_df['el'].max():.2f} mJ/cm²\n\n"
        
        if 'mir' in self.results:
            mir = self.results['mir']
            if mir['found']:
                report += f"Maximum Inscribed Rectangle (MIR):\n"
                report += f"  Exposure: {mir['exposure_range'][0]:.1f} - {mir['exposure_range'][1]:.1f} mJ/cm²\n"
                report += f"  Focus: {mir['focus_range'][0]:.3f} - {mir['focus_range'][1]:.3f} μm\n"
                report += f"  Area: {mir['area']:.4f} (mJ/cm² × μm)\n"
                report += f"  Center: E={mir['center_exposure']:.1f}, F={mir['center_focus']:.3f}\n\n"
        
        report += "="*70 + "\n"
        
        return report


def main():
    """Test process window analyzer with mock data."""
    
    print("="*70)
    print("Process Window Analyzer Test")
    print("="*70)
    
    # Load mock data
    print("\n[1] Loading mock data...")
    df = pd.read_csv('mock_data.csv')
    
    # Create analyzer
    print("\n[2] Creating analyzer...")
    analyzer = ProcessWindowAnalyzer(target_cd=250.0, cd_tolerance=0.10)
    
    # Calculate DOF and EL
    print("\n[3] Calculating DOF and EL...")
    dof_el_results = analyzer.calculate_dof_el(df)
    
    # Find optimal process point
    print("\n[4] Finding optimal process point...")
    optimal = analyzer.find_optimal_process_point(df)
    
    # Generate process window grid
    print("\n[5] Generating process window grid...")
    from data_generator import BosungMockDataGenerator
    generator = BosungMockDataGenerator()
    exp_grid, foc_grid, cd_grid = generator.generate_process_window(grid_points=50)
    
    # Find MIR
    print("\n[6] Finding Maximum Inscribed Rectangle...")
    mir = analyzer.find_maximum_inscribed_rectangle(exp_grid, foc_grid, cd_grid)
    
    # Generate report
    print("\n[7] Generating report...")
    report = analyzer.generate_report()
    print(report)
    
    # Save report
    with open('process_window_report.txt', 'w', encoding='utf-8') as f:
        f.write(report)
    print("✓ Report saved to process_window_report.txt")


if __name__ == "__main__":
    main()
