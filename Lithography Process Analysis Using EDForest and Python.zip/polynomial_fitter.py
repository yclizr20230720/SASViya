"""
Polynomial Fitter for Focus-Exposure Data
Implements chi-squared optimization and data flier removal as described in the paper.
"""

import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from typing import Tuple, Dict, Optional
import warnings

warnings.filterwarnings('ignore')


class PolynomialFitter:
    """
    Fit polynomial model to focus-exposure matrix data.
    
    Implements the physics-based polynomial model from the paper:
    CD = Σ(i=0 to 3) Σ(j=0 to 4) a_ij * E^i * F^j
    """
    
    def __init__(self, max_iterations: int = 2, sigma_threshold: float = 2.0):
        """
        Initialize the fitter.
        
        Args:
            max_iterations: Number of fit-remove-refit iterations
            sigma_threshold: Threshold for outlier removal in standard deviations
        """
        self.max_iterations = max_iterations
        self.sigma_threshold = sigma_threshold
        self.coefficients = None
        self.residuals = None
        self.r_squared = None
        self.fit_data = None
        
    def _polynomial_model(self, 
                         params: np.ndarray,
                         exposure: np.ndarray,
                         focus: np.ndarray) -> np.ndarray:
        """
        Evaluate polynomial model at given points.
        
        Args:
            params: Flattened coefficient array [a00, a10, a20, a01, a02, a11, a12, a21, a03, ...]
            exposure: Exposure dose values (normalized)
            focus: Focus values
            
        Returns:
            Predicted CD values
        """
        E = exposure / 100.0  # Normalize exposure
        F = focus
        
        # Reconstruct coefficient matrix
        a00, a10, a20, a01, a02, a11, a12, a21, a03 = params[:9]
        
        cd = (a00 +
              a10 * E +
              a20 * E**2 +
              a01 * F +
              a02 * F**2 +
              a11 * E * F +
              a12 * E * F**2 +
              a21 * E**2 * F +
              a03 * F**3)
        
        return cd
    
    def _residuals(self,
                  params: np.ndarray,
                  exposure: np.ndarray,
                  focus: np.ndarray,
                  cd_measured: np.ndarray,
                  weights: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Calculate weighted residuals.
        
        Args:
            params: Coefficient parameters
            exposure: Exposure values
            focus: Focus values
            cd_measured: Measured CD values
            weights: Optional weights for each point
            
        Returns:
            Weighted residuals
        """
        cd_predicted = self._polynomial_model(params, exposure, focus)
        residuals = cd_measured - cd_predicted
        
        if weights is not None:
            residuals = residuals * np.sqrt(weights)
        
        return residuals
    
    def fit(self,
           df: pd.DataFrame,
           initial_guess: Optional[np.ndarray] = None,
           use_weights: bool = True) -> Dict:
        """
        Fit polynomial model to data with iterative outlier removal.
        
        Args:
            df: DataFrame with columns: exposure_dose, focus, critical_dimension, measurement_uncertainty
            initial_guess: Initial coefficient guess (if None, use defaults)
            use_weights: Whether to use measurement uncertainty as weights
            
        Returns:
            Dictionary with fit results
        """
        
        # Extract data
        exposure = df['exposure_dose'].values
        focus = df['focus'].values
        cd = df['critical_dimension'].values
        
        if use_weights and 'measurement_uncertainty' in df.columns:
            uncertainty = df['measurement_uncertainty'].values
            # Weight inversely proportional to uncertainty
            weights = 1.0 / (uncertainty ** 2)
            weights = weights / weights.mean()  # Normalize
        else:
            weights = np.ones_like(cd)
        
        # Initial guess
        if initial_guess is None:
            initial_guess = np.array([300.0, -0.8, 0.002, 50.0, 80.0, -0.05, 0.1, -0.001, 20.0])
        
        print(f"\n{'='*70}")
        print("Polynomial Fitting with Iterative Outlier Removal")
        print(f"{'='*70}")
        print(f"Initial data points: {len(df)}")
        
        current_data = df.copy()
        current_weights = weights.copy()
        
        for iteration in range(self.max_iterations):
            print(f"\n[Iteration {iteration + 1}/{self.max_iterations}]")
            print(f"  Data points: {len(current_data)}")
            
            # Extract current data
            exposure_iter = current_data['exposure_dose'].values
            focus_iter = current_data['focus'].values
            cd_iter = current_data['critical_dimension'].values
            weights_iter = current_weights
            
            # Perform least squares fit
            result = least_squares(
                self._residuals,
                initial_guess,
                args=(exposure_iter, focus_iter, cd_iter, weights_iter),
                max_nfev=10000
            )
            
            coefficients = result.x
            residuals_raw = self._residuals(coefficients, exposure_iter, focus_iter, cd_iter, None)
            
            # Calculate statistics
            chi_squared = np.sum((residuals_raw ** 2) * weights_iter)
            dof = len(cd_iter) - len(coefficients)
            chi_squared_reduced = chi_squared / dof if dof > 0 else chi_squared
            
            # Calculate R-squared
            ss_res = np.sum((residuals_raw ** 2) * weights_iter)
            ss_tot = np.sum(((cd_iter - np.average(cd_iter, weights=weights_iter)) ** 2) * weights_iter)
            r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
            
            print(f"  χ² (reduced): {chi_squared_reduced:.4f}")
            print(f"  R²: {r_squared:.6f}")
            print(f"  Residual std dev: {np.std(residuals_raw):.4f} nm")
            
            # Remove outliers if not last iteration
            if iteration < self.max_iterations - 1:
                std_dev = np.std(residuals_raw)
                outlier_mask = np.abs(residuals_raw) > self.sigma_threshold * std_dev
                n_outliers = np.sum(outlier_mask)
                
                if n_outliers > 0:
                    print(f"  Removing {n_outliers} outliers (>{self.sigma_threshold}σ)")
                    current_data = current_data[~outlier_mask].reset_index(drop=True)
                    current_weights = current_weights[~outlier_mask]
                else:
                    print(f"  No outliers found, stopping iteration")
                    break
            
            initial_guess = coefficients
        
        # Store final results
        self.coefficients = coefficients
        self.residuals = residuals_raw
        self.r_squared = r_squared
        self.fit_data = current_data
        
        print(f"\n{'='*70}")
        print("Fitting completed")
        print(f"{'='*70}")
        
        return {
            'coefficients': coefficients,
            'residuals': residuals_raw,
            'r_squared': r_squared,
            'chi_squared_reduced': chi_squared_reduced,
            'final_data_points': len(current_data),
            'removed_points': len(df) - len(current_data)
        }
    
    def predict(self, exposure: np.ndarray, focus: np.ndarray) -> np.ndarray:
        """
        Predict CD values using fitted model.
        
        Args:
            exposure: Exposure dose values
            focus: Focus values
            
        Returns:
            Predicted CD values
        """
        if self.coefficients is None:
            raise ValueError("Model not fitted yet. Call fit() first.")
        
        return self._polynomial_model(self.coefficients, exposure, focus)
    
    def get_coefficients_dict(self) -> Dict[str, float]:
        """Return coefficients as dictionary."""
        if self.coefficients is None:
            raise ValueError("Model not fitted yet.")
        
        names = ['a00', 'a10', 'a20', 'a01', 'a02', 'a11', 'a12', 'a21', 'a03']
        return {name: coef for name, coef in zip(names, self.coefficients)}
    
    def print_coefficients(self):
        """Print fitted coefficients in readable format."""
        if self.coefficients is None:
            raise ValueError("Model not fitted yet.")
        
        coef_dict = self.get_coefficients_dict()
        print("\n" + "="*70)
        print("Fitted Polynomial Coefficients")
        print("="*70)
        print("CD = Σ(i,j) a_ij * E^i * F^j")
        print("\nCoefficients:")
        for name, value in coef_dict.items():
            print(f"  {name}: {value:12.6f}")
        print("="*70)


def main():
    """Test polynomial fitter with mock data."""
    
    # Load mock data
    print("Loading mock data...")
    df = pd.read_csv('/home/ubuntu/bossung_app/mock_data.csv')
    
    # Create and fit model
    fitter = PolynomialFitter(max_iterations=2, sigma_threshold=2.0)
    results = fitter.fit(df, use_weights=True)
    
    # Print results
    print(f"\nFit Results:")
    print(f"  Final data points: {results['final_data_points']}")
    print(f"  Removed points: {results['removed_points']}")
    print(f"  R²: {results['r_squared']:.6f}")
    
    # Print coefficients
    fitter.print_coefficients()
    
    # Test prediction
    print("\nTest Predictions:")
    test_exposure = np.array([200.0, 240.0, 280.0])
    test_focus = np.array([0.0, 0.0, 0.0])
    predictions = fitter.predict(test_exposure, test_focus)
    
    for e, f, pred in zip(test_exposure, test_focus, predictions):
        print(f"  E={e:.1f} mJ/cm², F={f:.2f} μm → CD={pred:.2f} nm")


if __name__ == "__main__":
    main()
