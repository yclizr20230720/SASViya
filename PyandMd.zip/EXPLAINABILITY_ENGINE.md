# Explainability Engine Implementation

## Overview

The Explainability Engine provides interpretable explanations for wafer defect pattern predictions, enabling engineers to understand and trust the AI model's decisions. This implementation fulfills **Task 11** from the backend development plan.

## Features

### 1. Grad-CAM (Gradient-weighted Class Activation Mapping)

**Purpose**: Visual explanations showing which regions of the wafer map contributed most to the prediction.

**How it works**:
- Computes gradients of the predicted class with respect to feature maps
- Generates a heatmap highlighting important spatial regions
- Overlays the heatmap on the original wafer map

**Benefits**:
- Intuitive visual feedback for engineers
- Identifies specific defect locations driving the prediction
- Helps validate model reasoning

**Example Usage**:
```python
from app.ml.explainability import GradCAMExplainer
from app.ml.model import WaferDefectModel

# Load model
model = WaferDefectModel()
model.load_state_dict(torch.load('checkpoints/best_model.pth'))

# Create explainer
gradcam = GradCAMExplainer(model)

# Generate heatmap overlay
overlay = gradcam.generate_overlay(
    image_path='path/to/wafer.png',
    class_idx=0,  # Pattern class index
    task='pattern',  # or 'root_cause'
    alpha=0.5  # Overlay transparency
)

# Save or display
from PIL import Image
Image.fromarray(overlay).save('gradcam_output.png')
```

### 2. SHAP (SHapley Additive exPlanations)

**Purpose**: Feature-level explanations showing which spatial regions and features contribute most to predictions.

**How it works**:
- Uses game theory (Shapley values) to assign importance to each feature
- Provides consistent and locally accurate explanations
- Identifies top-k most important spatial regions

**Benefits**:
- Quantitative feature importance scores
- Consistent explanations across different inputs
- Helps identify systematic patterns in model behavior

**Example Usage**:
```python
from app.ml.explainability import SHAPExplainer

# Create explainer with background data
explainer = SHAPExplainer(
    model=model,
    background_data=background_images,  # Sample of training data
    device='cuda'
)

# Compute SHAP values
shap_values, expected_values = explainer.explain(
    input_tensor=wafer_image,
    num_samples=100
)

# Get top features
top_features = explainer.get_top_features(
    shap_values=shap_values,
    class_idx=0,
    top_k=10
)

for feature_name, importance in top_features:
    print(f"{feature_name}: {importance:.4f}")
```

**Note**: SHAP requires the `shap` package:
```bash
pip install shap
```

### 3. Similar Case Retrieval

**Purpose**: Find wafers with similar defect patterns using feature embeddings.

**How it works**:
- Extracts 256-dimensional feature embeddings from the model
- Uses cosine similarity to find nearest neighbors
- Returns top-k most similar wafers with metadata

**Benefits**:
- Helps engineers find historical precedents
- Enables case-based reasoning
- Supports knowledge transfer across similar defects

**Example Usage**:
```python
from app.ml.explainability import SimilarCaseRetriever, build_embedding_database

# Build embedding database (one-time setup)
embedding_db = build_embedding_database(
    model=model,
    wafer_data=all_wafers,  # List of {'wafer_id', 'image_path'}
    device='cuda'
)

# Create retriever
retriever = SimilarCaseRetriever(
    model=model,
    embedding_database=embedding_db,
    device='cuda'
)

# Find similar cases
similar_cases = retriever.find_similar_by_wafer_id(
    wafer_id='M93242.01',
    top_k=5
)

for case in similar_cases:
    print(f"Wafer: {case['wafer_id']}, Similarity: {case['similarity']:.4f}")
```

## API Endpoints

### Enhanced Explain Endpoint

**Endpoint**: `GET /api/v1/inference/explain/<wafer_id>`

**Query Parameters**:
- `include_gradcam` (bool, default: true) - Generate Grad-CAM heatmap
- `include_similar` (bool, default: true) - Find similar cases
- `top_k_similar` (int, default: 5) - Number of similar cases to return

**Response**:
```json
{
  "status": "success",
  "wafer_id": "M93242.01",
  "inference_id": "uuid",
  "prediction": {
    "pattern_class": "Center",
    "pattern_confidence": 0.9523,
    "root_cause": "CVD Process Variation",
    "root_cause_confidence": 0.8845
  },
  "probabilities": {
    "pattern": {
      "Center": 0.9523,
      "Donut": 0.0234,
      ...
    },
    "root_cause": {
      "CVD Process Variation": 0.8845,
      "Lithography Issues": 0.0623,
      ...
    }
  },
  "gradcam": {
    "heatmap_url": "/api/v1/inference/heatmap/gradcam_M93242.01_abc123.png",
    "description": "Regions highlighted in red/yellow contributed most to the prediction"
  },
  "similar_cases": [
    {
      "wafer_id": "M93242.05",
      "similarity": 0.9234,
      "pattern_class": "Center",
      "lot_id": "M93242.00",
      "process_step": "Lithography"
    },
    ...
  ],
  "metadata": {
    "lot_id": "M93242.00",
    "process_step": "Lithography",
    "equipment_id": "LITHO-ASML-04",
    "defect_count": 45,
    "timestamp": "2026-01-19T10:30:45Z"
  },
  "timestamp": "2026-01-19T10:30:45Z"
}
```

### Heatmap Image Endpoint

**Endpoint**: `GET /api/v1/inference/heatmap/<filename>`

**Returns**: PNG image file with Grad-CAM overlay

## Setup and Usage

### 1. Install Dependencies

```bash
# Core dependencies (already in requirements.txt)
pip install torch torchvision opencv-python pillow numpy

# Optional: SHAP for feature importance
pip install shap
```

### 2. Build Embedding Database

Before using similar case retrieval, build the embedding database:

```bash
python scripts/build_embedding_database.py \
    --model checkpoints/best_model.pth \
    --output data/metadata/embedding_database.json \
    --device cuda
```

This extracts embeddings for all wafers and saves them to JSON for fast similarity search.

**Output**:
```
Building Embedding Database for Similar Case Retrieval
================================================================================
Model: checkpoints/best_model.pth
Output: data/metadata/embedding_database.json
Device: cuda

Loading model...
  Model loaded from epoch 50

Loading wafer data...
  Found 150 wafers
  150 wafers have valid images

Extracting embeddings...
  Processed 100/150 wafers
  Processed 150/150 wafers

Embedding database built: 150 wafers

Saving to data/metadata/embedding_database.json...
  Saved successfully

Statistics:
  Total wafers: 150
  Embedding dimension: 256
  Database size: 0.95 MB

================================================================================
Embedding database built successfully!
================================================================================
```

### 3. Test Explainability Features

Run the test suite to verify all features work:

```bash
python test_explainability.py
```

**Expected Output**:
```
================================================================================
EXPLAINABILITY ENGINE TEST SUITE
================================================================================

================================================================================
TEST 1: Grad-CAM Heatmap Generation
================================================================================
Loading model...
✓ Model loaded
✓ Using test wafer: M93242.01
Creating Grad-CAM explainer...
✓ Grad-CAM explainer created
Generating heatmap overlay...
✓ Heatmap generated: shape (224, 224, 3)
✓ Heatmap saved to test_gradcam_output.png

================================================================================
TEST 2: Similar Case Retrieval
================================================================================
Loading model...
✓ Model loaded
✓ Found 150 valid wafers
Building embedding database...
✓ Embedding database built: 150 wafers
Creating similar case retriever...
✓ Retriever created
Finding similar cases for M93242.01...
✓ Found 3 similar cases:
  1. M93242.05 (similarity: 0.9234)
  2. M93242.12 (similarity: 0.8956)
  3. M93242.18 (similarity: 0.8723)

================================================================================
TEST 3: Explainability API Endpoints
================================================================================
✓ Server is running
✓ Using test wafer: M93242.01
Testing /inference/explain endpoint...
✓ Explain endpoint successful
  Status: success
  Prediction: Center
  Grad-CAM: /api/v1/inference/heatmap/gradcam_M93242.01_abc123.png
  Similar cases: 5 found

================================================================================
TEST RESULTS SUMMARY
================================================================================
Grad-CAM: ✓ PASSED
Similar Case Retrieval: ✓ PASSED
API Endpoints: ✓ PASSED

Total: 3/3 tests passed
================================================================================
```

### 4. Use in Production

**Example API Call**:
```bash
# Get comprehensive explanation for a wafer
curl -X GET "http://localhost:5000/api/v1/inference/explain/M93242.01?include_gradcam=true&include_similar=true&top_k_similar=5"

# Download Grad-CAM heatmap
curl -X GET "http://localhost:5000/api/v1/inference/heatmap/gradcam_M93242.01_abc123.png" \
    --output gradcam_heatmap.png
```

## Architecture

### Component Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    Explainability Engine                     │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────┐  ┌──────────────────┐  ┌────────────┐│
│  │  GradCAMExplainer│  │  SHAPExplainer   │  │  Similar   ││
│  │                  │  │                  │  │  Case      ││
│  │  - Heatmap Gen   │  │  - Feature Imp   │  │  Retriever ││
│  │  - Overlay       │  │  - Top-k         │  │            ││
│  │  - Visualization │  │  - Quantitative  │  │  - Cosine  ││
│  └──────────────────┘  └──────────────────┘  │    Sim     ││
│           │                     │             │  - Top-k   ││
│           │                     │             │  - Metadata││
│           └─────────┬───────────┘             └────────────┘│
│                     │                               │        │
│              ┌──────▼───────┐              ┌────────▼──────┐│
│              │ WaferDefect  │              │  Embedding    ││
│              │    Model     │              │  Database     ││
│              │              │              │               ││
│              │ - Backbone   │              │ - 256D vectors││
│              │ - Embeddings │              │ - JSON storage││
│              └──────────────┘              └───────────────┘│
│                                                               │
└─────────────────────────────────────────────────────────────┘
                              │
                              │
                    ┌─────────▼──────────┐
                    │  Inference API     │
                    │                    │
                    │  /explain/<id>     │
                    │  /heatmap/<file>   │
                    └────────────────────┘
```

### Data Flow

```
User Request
    │
    ▼
┌─────────────────────────────────────┐
│  GET /inference/explain/<wafer_id>  │
└─────────────────────────────────────┘
    │
    ├─────────────────────────────────┐
    │                                 │
    ▼                                 ▼
┌──────────────┐              ┌──────────────┐
│  Load Wafer  │              │ Load Inference│
│  Metadata    │              │  Result       │
└──────────────┘              └──────────────┘
    │                                 │
    └─────────────┬───────────────────┘
                  │
                  ▼
    ┌─────────────────────────────┐
    │  Generate Grad-CAM Heatmap  │
    │  (if include_gradcam=true)  │
    └─────────────────────────────┘
                  │
                  ▼
    ┌─────────────────────────────┐
    │  Find Similar Cases         │
    │  (if include_similar=true)  │
    └─────────────────────────────┘
                  │
                  ▼
    ┌─────────────────────────────┐
    │  Build Response JSON        │
    │  - Prediction               │
    │  - Probabilities            │
    │  - Grad-CAM URL             │
    │  - Similar Cases            │
    │  - Metadata                 │
    └─────────────────────────────┘
                  │
                  ▼
            Return to User
```

## Performance Considerations

### Grad-CAM
- **Computation Time**: ~50-100ms per heatmap (GPU)
- **Memory**: Minimal overhead (stores gradients temporarily)
- **Caching**: Heatmaps saved to temp folder, can be cached

### SHAP
- **Computation Time**: ~1-5 seconds per explanation (depends on num_samples)
- **Memory**: Requires background dataset (~100 samples)
- **Recommendation**: Use sparingly, cache results

### Similar Case Retrieval
- **Computation Time**: ~1-10ms for similarity search (depends on database size)
- **Memory**: Embedding database loaded in memory (~1MB per 1000 wafers)
- **Scalability**: Linear search, consider FAISS for >10,000 wafers

## Best Practices

### 1. Grad-CAM Interpretation
- **Red/Yellow regions**: High importance for prediction
- **Blue/Purple regions**: Low importance
- **Validate**: Check if highlighted regions align with actual defects
- **Multiple classes**: Generate heatmaps for top-k predicted classes

### 2. Similar Case Usage
- **Threshold**: Consider similarity > 0.8 as "very similar"
- **Context**: Check if similar cases have same pattern class
- **Historical**: Use for finding precedents and solutions
- **Validation**: Manually verify a sample of similar cases

### 3. API Integration
- **Caching**: Cache heatmaps and similar cases for repeated requests
- **Async**: Consider async processing for SHAP (slow)
- **Batch**: Process multiple wafers in batch for efficiency
- **Cleanup**: Periodically clean up temp heatmap files

## Troubleshooting

### Issue: Grad-CAM heatmap is all blue
**Cause**: Model not confident or wrong target layer
**Solution**: 
- Check model confidence scores
- Try different target layers
- Verify model is trained properly

### Issue: Similar cases not relevant
**Cause**: Embedding database outdated or model not trained well
**Solution**:
- Rebuild embedding database with latest model
- Retrain model with more diverse data
- Check embedding dimension and normalization

### Issue: SHAP computation too slow
**Cause**: Too many samples or large background dataset
**Solution**:
- Reduce num_samples (try 50-100)
- Use smaller background dataset (50-100 images)
- Consider using Grad-CAM instead for faster explanations

## Future Enhancements

1. **Attention Visualization**: Add attention mechanism visualization
2. **Counterfactual Explanations**: Show what changes would flip the prediction
3. **Feature Attribution**: Decompose prediction by spatial regions
4. **Interactive Explanations**: Allow users to query specific regions
5. **Explanation Quality Metrics**: Quantify explanation faithfulness
6. **FAISS Integration**: Scale similar case retrieval to millions of wafers

## References

1. Selvaraju et al., "Grad-CAM: Visual Explanations from Deep Networks via Gradient-based Localization", ICCV 2017
2. Lundberg & Lee, "A Unified Approach to Interpreting Model Predictions", NeurIPS 2017
3. Ribeiro et al., "Why Should I Trust You?: Explaining the Predictions of Any Classifier", KDD 2016

## Summary

The Explainability Engine provides three complementary explanation methods:

1. **Grad-CAM**: Visual, intuitive, fast
2. **SHAP**: Quantitative, consistent, slower
3. **Similar Cases**: Historical, contextual, fast

Together, these methods enable engineers to understand, trust, and act on AI predictions for wafer defect pattern recognition.
