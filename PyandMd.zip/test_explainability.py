"""
Test script for explainability features

Tests:
1. Grad-CAM heatmap generation
2. SHAP feature importance (if shap is installed)
3. Similar case retrieval
4. Explainability API endpoints
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

import torch
import numpy as np
from pathlib import Path

from app.ml.model import WaferDefectModel, PATTERN_CLASSES
from app.ml.explainability import (
    GradCAMExplainer,
    SimilarCaseRetriever,
    build_embedding_database
)
from app.utils.json_storage import JSONStorage
from config import Config


def test_gradcam():
    """Test Grad-CAM heatmap generation"""
    print("\n" + "=" * 80)
    print("TEST 1: Grad-CAM Heatmap Generation")
    print("=" * 80)
    
    # Check if model exists
    model_path = 'checkpoints/best_model.pth'
    if not os.path.exists(model_path):
        print("❌ Model not found. Please train a model first.")
        return False
    
    # Load model
    print("Loading model...")
    checkpoint = torch.load(model_path, map_location='cpu')
    model = WaferDefectModel(num_pattern_classes=10, num_root_cause_classes=8)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    print("✓ Model loaded")
    
    # Get a test wafer
    storage = JSONStorage(Config.METADATA_FOLDER)
    wafers = storage.find('wafers.json')
    
    if not wafers or len(wafers) == 0:
        print("❌ No wafers found. Please upload wafers first.")
        return False
    
    test_wafer = wafers[0]
    image_path = test_wafer.get('image_path')
    
    if not image_path or not os.path.exists(image_path):
        print("❌ Test wafer image not found")
        return False
    
    print(f"✓ Using test wafer: {test_wafer['wafer_id']}")
    
    # Create Grad-CAM explainer
    print("Creating Grad-CAM explainer...")
    gradcam = GradCAMExplainer(model)
    print("✓ Grad-CAM explainer created")
    
    # Generate heatmap overlay
    print("Generating heatmap overlay...")
    try:
        overlay = gradcam.generate_overlay(
            image_path=image_path,
            class_idx=0,  # Test with first class
            task='pattern',
            alpha=0.5
        )
        print(f"✓ Heatmap generated: shape {overlay.shape}")
        
        # Save heatmap
        from PIL import Image
        output_path = 'test_gradcam_output.png'
        Image.fromarray(overlay).save(output_path)
        print(f"✓ Heatmap saved to {output_path}")
        
        return True
    
    except Exception as e:
        print(f"❌ Grad-CAM generation failed: {e}")
        return False


def test_similar_case_retrieval():
    """Test similar case retrieval"""
    print("\n" + "=" * 80)
    print("TEST 2: Similar Case Retrieval")
    print("=" * 80)
    
    # Check if model exists
    model_path = 'checkpoints/best_model.pth'
    if not os.path.exists(model_path):
        print("❌ Model not found. Please train a model first.")
        return False
    
    # Load model
    print("Loading model...")
    checkpoint = torch.load(model_path, map_location='cpu')
    model = WaferDefectModel(num_pattern_classes=10, num_root_cause_classes=8)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    print("✓ Model loaded")
    
    # Get wafers
    storage = JSONStorage(Config.METADATA_FOLDER)
    wafers = storage.find('wafers.json')
    
    if not wafers or len(wafers) < 2:
        print("❌ Need at least 2 wafers for similarity testing")
        return False
    
    # Filter valid wafers
    valid_wafers = []
    for wafer in wafers:
        image_path = wafer.get('image_path')
        if image_path and os.path.exists(image_path):
            valid_wafers.append({
                'wafer_id': wafer['wafer_id'],
                'image_path': image_path
            })
    
    if len(valid_wafers) < 2:
        print("❌ Need at least 2 wafers with valid images")
        return False
    
    print(f"✓ Found {len(valid_wafers)} valid wafers")
    
    # Build embedding database
    print("Building embedding database...")
    try:
        embedding_db = build_embedding_database(
            model=model,
            wafer_data=valid_wafers[:10],  # Limit to 10 for testing
            device='cpu'
        )
        print(f"✓ Embedding database built: {len(embedding_db)} wafers")
    
    except Exception as e:
        print(f"❌ Failed to build embedding database: {e}")
        return False
    
    # Create retriever
    print("Creating similar case retriever...")
    try:
        retriever = SimilarCaseRetriever(
            model=model,
            embedding_database=embedding_db,
            device='cpu'
        )
        print("✓ Retriever created")
    
    except Exception as e:
        print(f"❌ Failed to create retriever: {e}")
        return False
    
    # Find similar cases
    test_wafer_id = valid_wafers[0]['wafer_id']
    print(f"Finding similar cases for {test_wafer_id}...")
    
    try:
        similar_cases = retriever.find_similar_by_wafer_id(
            wafer_id=test_wafer_id,
            top_k=3
        )
        
        print(f"✓ Found {len(similar_cases)} similar cases:")
        for i, case in enumerate(similar_cases, 1):
            print(f"  {i}. {case['wafer_id']} (similarity: {case['similarity']:.4f})")
        
        return True
    
    except Exception as e:
        print(f"❌ Similar case retrieval failed: {e}")
        return False


def test_explainability_api():
    """Test explainability API endpoints"""
    print("\n" + "=" * 80)
    print("TEST 3: Explainability API Endpoints")
    print("=" * 80)
    
    import requests
    
    # Check if server is running
    base_url = 'http://localhost:5000/api/v1'
    
    try:
        response = requests.get(f'{base_url}/health', timeout=2)
        if response.status_code != 200:
            print("❌ Server not responding. Please start the Flask server.")
            return False
    except:
        print("❌ Server not running. Please start the Flask server with: python run.py")
        return False
    
    print("✓ Server is running")
    
    # Get a wafer with inference
    storage = JSONStorage(Config.METADATA_FOLDER)
    inferences = storage.find('inference_results.json')
    
    if not inferences or len(inferences) == 0:
        print("❌ No inferences found. Please run inference first.")
        return False
    
    test_wafer_id = inferences[0]['wafer_id']
    print(f"✓ Using test wafer: {test_wafer_id}")
    
    # Test explain endpoint
    print("Testing /inference/explain endpoint...")
    try:
        response = requests.get(
            f'{base_url}/inference/explain/{test_wafer_id}',
            params={
                'include_gradcam': 'true',
                'include_similar': 'true',
                'top_k_similar': 3
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            print("✓ Explain endpoint successful")
            print(f"  Status: {data.get('status')}")
            print(f"  Prediction: {data.get('prediction', {}).get('pattern_class')}")
            
            if 'gradcam' in data:
                print(f"  Grad-CAM: {data['gradcam'].get('heatmap_url', 'Generated')}")
            
            if 'similar_cases' in data and isinstance(data['similar_cases'], list):
                print(f"  Similar cases: {len(data['similar_cases'])} found")
            
            return True
        else:
            print(f"❌ Explain endpoint failed: {response.status_code}")
            print(f"  Response: {response.text}")
            return False
    
    except Exception as e:
        print(f"❌ API test failed: {e}")
        return False


def main():
    """Run all tests"""
    print("\n" + "=" * 80)
    print("EXPLAINABILITY ENGINE TEST SUITE")
    print("=" * 80)
    
    results = {
        'Grad-CAM': test_gradcam(),
        'Similar Case Retrieval': test_similar_case_retrieval(),
        'API Endpoints': test_explainability_api()
    }
    
    print("\n" + "=" * 80)
    print("TEST RESULTS SUMMARY")
    print("=" * 80)
    
    for test_name, passed in results.items():
        status = "✓ PASSED" if passed else "❌ FAILED"
        print(f"{test_name}: {status}")
    
    total_passed = sum(results.values())
    total_tests = len(results)
    
    print()
    print(f"Total: {total_passed}/{total_tests} tests passed")
    print("=" * 80)
    
    return 0 if total_passed == total_tests else 1


if __name__ == '__main__':
    sys.exit(main())
