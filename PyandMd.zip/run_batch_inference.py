"""
Batch Inference Script
Runs inference on all uploaded wafers to populate inference_results.json
"""
import json
import os
from datetime import datetime
from pathlib import Path
import sys

# Add app directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'app'))

from app.ml.inference import WaferInferenceEngine
from app.utils.json_storage import JSONStorage

def run_batch_inference():
    """Run inference on all uploaded wafers"""
    
    # Initialize
    data_dir = Path(__file__).parent / 'data' / 'metadata'
    storage = JSONStorage(str(data_dir))
    
    # Find the best model checkpoint
    checkpoint_dir = Path(__file__).parent / 'checkpoints'
    best_model_path = checkpoint_dir / 'best_model.pth'
    
    if not best_model_path.exists():
        print(f"✗ Model not found: {best_model_path}")
        print("Please train a model first using scripts/train_model.py")
        return
    
    # Initialize inference engine
    device = 'cuda' if __import__('torch').cuda.is_available() else 'cpu'
    print(f"Using device: {device}")
    inference_engine = WaferInferenceEngine(
        model_path=str(best_model_path),
        device=device
    )
    
    # Load all wafers
    wafers = storage.read('wafers.json', default=[])
    print(f"Found {len(wafers)} wafers to process")
    
    if len(wafers) == 0:
        print("No wafers found. Please upload wafers first.")
        return
    
    # Load existing inference results
    inference_results = storage.read('inference_results.json', default=[])
    existing_wafer_ids = {result['wafer_id'] for result in inference_results}
    
    # Process each wafer
    success_count = 0
    error_count = 0
    
    for i, wafer in enumerate(wafers, 1):
        wafer_id = wafer['wafer_id']
        image_path = wafer['image_path']
        
        # Skip if already processed
        if wafer_id in existing_wafer_ids:
            print(f"[{i}/{len(wafers)}] Skipping {wafer_id} - already processed")
            continue
        
        print(f"[{i}/{len(wafers)}] Processing {wafer_id}...")
        
        try:
            # Check if image exists
            if not os.path.exists(image_path):
                print(f"  ⚠️  Image not found: {image_path}")
                error_count += 1
                continue
            
            # Run inference
            result = inference_engine.predict(image_path)
            
            # Create inference result record
            inference_result = {
                'id': f"inf_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{wafer_id}",
                'wafer_id': wafer_id,
                'lot_id': wafer.get('lot_id', 'UNKNOWN'),
                'timestamp': datetime.now().isoformat(),
                'pattern': result['pattern_class'],
                'pattern_confidence': result['pattern_confidence'],
                'root_cause': result['root_cause'],
                'root_cause_confidence': result['root_cause_confidence'],
                'overall_confidence': (result['pattern_confidence'] + result['root_cause_confidence']) / 2,
                'processing_time_ms': result.get('processing_time_ms', 0),
                'model_version': '1.0.0',
                'metadata': {
                    'tool_id': wafer.get('tool_id', 'UNKNOWN'),
                    'process_step': wafer.get('process_step', 'UNKNOWN'),
                    'scan_time': wafer.get('scan_time', datetime.now().isoformat()),
                }
            }
            
            # Add to results
            inference_results.append(inference_result)
            
            print(f"  ✓ Pattern: {result['pattern_class']} ({result['pattern_confidence']:.2%})")
            print(f"    Root Cause: {result['root_cause']} ({result['root_cause_confidence']:.2%})")
            
            success_count += 1
            
        except Exception as e:
            print(f"  ✗ Error: {str(e)}")
            error_count += 1
    
    # Save all results
    if success_count > 0:
        storage.write('inference_results.json', inference_results)
        print(f"\n✓ Successfully processed {success_count} wafers")
        print(f"✓ Saved to: {storage._get_file_path('inference_results.json')}")
    
    if error_count > 0:
        print(f"⚠️  {error_count} wafers failed to process")
    
    # Print summary
    print(f"\n{'='*60}")
    print(f"BATCH INFERENCE SUMMARY")
    print(f"{'='*60}")
    print(f"Total wafers: {len(wafers)}")
    print(f"Already processed: {len(existing_wafer_ids)}")
    print(f"Newly processed: {success_count}")
    print(f"Errors: {error_count}")
    print(f"Total inference results: {len(inference_results)}")
    print(f"{'='*60}")

if __name__ == '__main__':
    print("="*60)
    print("BATCH INFERENCE FOR DASHBOARD")
    print("="*60)
    print()
    
    try:
        run_batch_inference()
    except Exception as e:
        print(f"\n✗ Fatal error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
