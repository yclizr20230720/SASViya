# Frontend Integration Guide

## Upload API Integration

### API Endpoint
```
POST http://localhost:5000/api/v1/wafer/upload
```

### Request Format
**Content-Type**: `multipart/form-data`

**Form Fields**:
- `data_file`: File (JSON/CSV/XLSX)
- `image_file`: File (JPG/PNG/GIF)
- `process_step`: String (optional metadata)

---

## Frontend Code Example (React)

### 1. API Service Function

Add this to `wafer-defect-gui/src/services/waferService.ts`:

```typescript
/**
 * Upload wafer data and image to backend
 */
export const uploadWaferData = async (
  dataFile: File,
  imageFile: File,
  metadata?: { process_step?: string }
): Promise<{
  status: string;
  wafer_id: string;
  lot_id: string;
  job_id: string;
  image_filename: string;
}> => {
  const formData = new FormData();
  formData.append('data_file', dataFile);
  formData.append('image_file', imageFile);
  
  if (metadata?.process_step) {
    formData.append('process_step', metadata.process_step);
  }

  const response = await fetch('http://localhost:5000/api/v1/wafer/upload', {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Upload failed');
  }

  return response.json();
};

/**
 * List all uploaded wafers
 */
export const listWafers = async (filters?: {
  lot_id?: string;
  status?: string;
  limit?: number;
}): Promise<{
  status: string;
  count: number;
  wafers: any[];
}> => {
  const params = new URLSearchParams();
  if (filters?.lot_id) params.append('lot_id', filters.lot_id);
  if (filters?.status) params.append('status', filters.status);
  if (filters?.limit) params.append('limit', filters.limit.toString());

  const response = await fetch(
    `http://localhost:5000/api/v1/wafer/list?${params.toString()}`
  );

  if (!response.ok) {
    throw new Error('Failed to fetch wafers');
  }

  return response.json();
};

/**
 * Get wafer details by ID
 */
export const getWaferById = async (waferId: string): Promise<{
  status: string;
  wafer: any;
}> => {
  const response = await fetch(
    `http://localhost:5000/api/v1/wafer/${waferId}`
  );

  if (!response.ok) {
    throw new Error('Wafer not found');
  }

  return response.json();
};
```

---

### 2. Update IngestWafers Component

Update `wafer-defect-gui/src/pages/training/IngestWafers.tsx`:

```typescript
import { uploadWaferData } from '../../services/waferService';

// Inside your component, update the handleUpload function:

const handleUpload = async () => {
  if (dataFiles.length === 0 || imageFiles.length === 0) {
    // Show error: both files required
    return;
  }

  setUploading(true);
  
  try {
    // Upload each pair of data file + image file
    for (let i = 0; i < Math.min(dataFiles.length, imageFiles.length); i++) {
      const dataFile = dataFiles[i];
      const imageFile = imageFiles[i];
      
      const result = await uploadWaferData(dataFile, imageFile, {
        process_step: processStep || 'Lithography'
      });
      
      console.log('Upload successful:', result);
      
      // Show success notification
      // Update UI with result.wafer_id, result.lot_id, etc.
    }
    
    // Clear files after successful upload
    setDataFiles([]);
    setImageFiles([]);
    
    // Show success message
    alert('Upload successful!');
    
  } catch (error) {
    console.error('Upload failed:', error);
    // Show error message
    alert(`Upload failed: ${error.message}`);
  } finally {
    setUploading(false);
  }
};
```

---

### 3. CORS Configuration

The backend is already configured to accept requests from `http://localhost:5173`.

If you need to add more origins, update `wafer-defect-ap/config.py`:

```python
CORS_ORIGINS = os.environ.get('CORS_ORIGINS', 'http://localhost:5173,http://localhost:3000').split(',')
```

---

## Data File Format Examples

### JSON Format (Recommended)
```json
{
  "lot_id": "M93242.00",
  "wafer_id": "M93242.01",
  "tool_id": "LITHO-ASML-04",
  "scan_time": "2024-01-15T10:30:00Z",
  "process_step": "Lithography",
  "defect_count": 45
}
```

### CSV Format
```csv
lot_id,wafer_id,tool_id,scan_time,process_step,defect_count
M93242.00,M93242.01,LITHO-ASML-04,2024-01-15T10:30:00Z,Lithography,45
M93242.00,M93242.02,LITHO-ASML-04,2024-01-15T10:35:00Z,Lithography,38
```

### XLSX Format
Excel file with columns:
| lot_id | wafer_id | tool_id | scan_time | process_step | defect_count |
|--------|----------|---------|-----------|--------------|--------------|
| M93242.00 | M93242.01 | LITHO-ASML-04 | 2024-01-15T10:30:00Z | Lithography | 45 |

---

## Validation Rules

### LotID Format
- **Format**: `M93242.00`
- **Length**: 9 characters
- **Pattern**: M + 5 digits + .00
- **Example**: M93242.00, M12345.00

### WaferID Format
- **Format**: `M93242.01` to `M93242.25`
- **Length**: 9 characters
- **Pattern**: M + 5 digits + .01 to .25
- **Example**: M93242.01, M93242.25

### Image Files
- **Formats**: JPG, JPEG, PNG, GIF
- **Max Size**: 50MB (configurable)

### Data Files
- **Formats**: JSON, CSV, XLSX
- **Max Size**: 50MB (configurable)

---

## API Response Examples

### Success Response
```json
{
  "status": "success",
  "wafer_id": "M93242.01",
  "lot_id": "M93242.00",
  "job_id": "d351635c-011c-4eaf-bfe0-dccfca4ea4a9",
  "message": "Upload successful",
  "image_filename": "M93242.01_wafer_map.png"
}
```

### Error Response
```json
{
  "error": "Invalid LotID format. Expected: M93242.00"
}
```

---

## Testing the Integration

### 1. Start Backend Server
```bash
cd wafer-defect-ap
python run.py
```

Backend runs on: `http://localhost:5000`

### 2. Start Frontend Server
```bash
cd wafer-defect-gui
npm run dev
```

Frontend runs on: `http://localhost:5173`

### 3. Test Upload
1. Navigate to: `http://localhost:5173/training/ingest-wafers`
2. Upload a data file (JSON/CSV/XLSX)
3. Upload an image file (JPG/PNG/GIF)
4. Click "Submit" or "Upload"
5. Check console for response
6. Verify files in `wafer-defect-ap/data/`

---

## Troubleshooting

### CORS Error
If you see CORS errors in browser console:
1. Check backend is running on port 5000
2. Verify CORS_ORIGINS in config.py includes your frontend URL
3. Restart backend server

### Upload Fails
1. Check file formats are correct
2. Verify LotID and WaferID formats in data file
3. Check backend logs for detailed error messages
4. Ensure both data_file and image_file are provided

### Backend Not Responding
```bash
# Check if backend is running
curl http://localhost:5000/health

# Should return:
# {"status": "healthy", "version": "v1"}
```

---

## Next Steps

After successful upload, the wafer data is stored and ready for:
1. **Training**: Use uploaded wafers to train AI models
2. **Inference**: Run pattern recognition on uploaded wafers
3. **Analytics**: View statistics and patterns across wafers
4. **Library**: Browse and manage uploaded wafers
