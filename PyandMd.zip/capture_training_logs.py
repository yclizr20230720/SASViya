"""
Capture training logs and metrics from running training process

This script monitors the training output and saves:
1. Console logs to: logs/training_current.log
2. Metrics to: logs/training_metrics.json
"""
import os
import json
import re
from datetime import datetime
from pathlib import Path

# Create logs directory
os.makedirs('logs', exist_ok=True)

# Initialize metrics storage
metrics_file = 'logs/training_metrics.json'
log_file = 'logs/training_current.log'

def parse_epoch_line(line):
    """Parse epoch information from training output"""
    # Example: "Epoch 17/30"
    match = re.search(r'Epoch (\d+)/(\d+)', line)
    if match:
        return {
            'current_epoch': int(match.group(1)),
            'total_epochs': int(match.group(2))
        }
    return None

def parse_train_metrics(line):
    """Parse training metrics"""
    # Example: "Train - Loss: 0.1135, Pattern Acc: 0.880, Root Cause Acc: 0.890"
    match = re.search(r'Train.*Loss:\s*([\d.]+).*Pattern Acc:\s*([\d.]+).*Root Cause Acc:\s*([\d.]+)', line)
    if match:
        return {
            'train_loss': float(match.group(1)),
            'train_pattern_acc': float(match.group(2)),
            'train_root_cause_acc': float(match.group(3))
        }
    return None

def parse_val_metrics(line):
    """Parse validation metrics"""
    # Example: "Val   - Loss: 0.0511, Pattern Acc: 1.000, Root Cause Acc: 0.975"
    match = re.search(r'Val.*Loss:\s*([\d.]+).*Pattern Acc:\s*([\d.]+).*Root Cause Acc:\s*([\d.]+)', line)
    if match:
        return {
            'val_loss': float(match.group(1)),
            'val_pattern_acc': float(match.group(2)),
            'val_root_cause_acc': float(match.group(3))
        }
    return None

def parse_learning_rate(line):
    """Parse learning rate"""
    # Example: "LR: 0.000073"
    match = re.search(r'LR:\s*([\d.]+)', line)
    if match:
        return {'learning_rate': float(match.group(1))}
    return None

def load_metrics():
    """Load existing metrics"""
    if os.path.exists(metrics_file):
        with open(metrics_file, 'r') as f:
            return json.load(f)
    return {
        'job_id': 'current_training',
        'status': 'running',
        'start_time': datetime.utcnow().isoformat(),
        'current_epoch': 0,
        'total_epochs': 30,
        'metrics_history': [],
        'current_metrics': {}
    }

def save_metrics(metrics):
    """Save metrics to JSON file"""
    with open(metrics_file, 'w') as f:
        json.dump(metrics, f, indent=2)

def append_log(line):
    """Append line to log file"""
    with open(log_file, 'a', encoding='utf-8') as f:
        timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"[{timestamp}] {line}\n")

# Example: Simulate capturing your current training output
if __name__ == '__main__':
    print("Training Log Capture System")
    print("This will capture training output and save to logs/")
    print("\nTo use with your running training:")
    print("1. Redirect training output: python train.py > logs/training_output.txt 2>&1")
    print("2. Or use: python train.py | tee logs/training_output.txt")
    print("3. This script will parse and structure the data")
