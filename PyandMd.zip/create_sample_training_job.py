"""
Create sample training job from completed training

This adds your completed training (training_20260118) to the training queue
so it appears in the web interface with real metrics and logs.
"""
import json
import os
from datetime import datetime

def create_sample_job():
    """Create sample training job entry"""
    
    # Load training status
    status_file = 'logs/training_status.json'
    if not os.path.exists(status_file):
        print(f"ERROR: {status_file} not found. Run parse_training_log.py first.")
        return
    
    with open(status_file, 'r') as f:
        training_status = json.load(f)
    
    # Create training job entry
    training_job = {
        'id': 1,
        'job_id': training_status['job_id'],
        'status': training_status['status'],
        'priority': 'normal',
        'config': {
            'model_architecture': training_status['model_architecture'],
            'epochs': training_status['total_epochs'],
            'batch_size': training_status['batch_size'],
            'learning_rate': 0.0001,
            'dataset_filter': {
                'dataset_size': training_status['dataset_size']
            }
        },
        'start_time': training_status['start_time'],
        'end_time': training_status['end_time'],
        'queued_at': training_status['start_time'],
        'current_epoch': training_status['current_epoch'],
        'total_epochs': training_status['total_epochs'],
        'metrics': {
            'loss': training_status['current_metrics']['train_loss'],
            'accuracy': training_status['current_metrics']['train_pattern_acc'],
            'val_loss': training_status['current_metrics']['val_loss'],
            'val_accuracy': training_status['current_metrics']['val_pattern_acc']
        },
        'estimated_duration_minutes': 120,
        'wafer_count': training_status['dataset_size'],
        'created_at': training_status['start_time']
    }
    
    # Create metadata directory if it doesn't exist
    metadata_dir = 'data/metadata'
    os.makedirs(metadata_dir, exist_ok=True)
    
    # Save to training_jobs.json
    jobs_file = os.path.join(metadata_dir, 'training_jobs.json')
    
    # Load existing jobs or create new list
    if os.path.exists(jobs_file):
        with open(jobs_file, 'r') as f:
            try:
                jobs = json.load(f)
                if not isinstance(jobs, list):
                    jobs = []
            except:
                jobs = []
    else:
        jobs = []
    
    # Check if job already exists
    existing_job = next((j for j in jobs if j.get('job_id') == training_job['job_id']), None)
    if existing_job:
        # Update existing job
        jobs = [j if j.get('job_id') != training_job['job_id'] else training_job for j in jobs]
        print(f"Updated existing job: {training_job['job_id']}")
    else:
        # Add new job
        jobs.append(training_job)
        print(f"Added new job: {training_job['job_id']}")
    
    # Save jobs
    with open(jobs_file, 'w') as f:
        json.dump(jobs, f, indent=2)
    
    print(f"\n✅ Sample training job created successfully!")
    print(f"\nJob Details:")
    print(f"  Job ID: {training_job['job_id']}")
    print(f"  Status: {training_job['status']}")
    print(f"  Epochs: {training_job['current_epoch']}/{training_job['total_epochs']}")
    print(f"  Pattern Accuracy: {training_status['current_metrics']['val_pattern_acc']*100:.1f}%")
    print(f"  Root Cause Accuracy: {training_status['current_metrics']['val_root_cause_acc']*100:.1f}%")
    print(f"\nFile saved to: {jobs_file}")
    print(f"\nNow start the Flask server and frontend to see the job in the queue!")

if __name__ == '__main__':
    print("="*80)
    print("CREATE SAMPLE TRAINING JOB")
    print("="*80)
    print("\nThis will add your completed training to the training queue")
    print("so it appears in the web interface with real metrics.\n")
    
    create_sample_job()
    
    print("\n" + "="*80)
    print("NEXT STEPS")
    print("="*80)
    print("\n1. Start Flask server:")
    print("   cd wafer-defect-ap")
    print("   python run.py")
    print("\n2. Start frontend:")
    print("   cd wafer-defect-gui")
    print("   npm start")
    print("\n3. Navigate to:")
    print("   http://localhost:3000/training/queue")
    print("\n4. You should see your completed training job with:")
    print("   - Status: COMPLETED")
    print("   - Progress: 30/30 (100%)")
    print("   - Pattern Acc: 100.0%")
    print("   - Root Cause Acc: 100.0%")
    print("   - Click expand to see detailed metrics and logs")
    print("\n" + "="*80)
