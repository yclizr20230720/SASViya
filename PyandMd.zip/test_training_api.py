"""
Test training API endpoints
"""
import requests
import json
import time

# API endpoint
API_URL = "http://localhost:5000/api/v1"


def test_start_training():
    """Test starting a training job"""
    print("\n" + "=" * 60)
    print("Testing Training API")
    print("=" * 60)
    
    # Training configuration
    config = {
        "model_architecture": "efficientnet-b3",
        "epochs": 10,
        "batch_size": 32,
        "learning_rate": 0.0001,
        "dataset_filter": {
            "lot_ids": ["M12345.00"],
            "date_range": ["2024-01-01", "2024-01-31"]
        }
    }
    
    print("\n1. Starting training job...")
    print(f"   Config: {json.dumps(config, indent=2)}")
    
    response = requests.post(f"{API_URL}/training/start", json=config)
    
    if response.status_code == 200:
        result = response.json()
        print(f"✓ Training started!")
        print(f"  - Job ID: {result['job_id']}")
        print(f"  - Estimated Duration: {result['estimated_duration_minutes']} minutes")
        
        job_id = result['job_id']
        
        # Test get training status
        print(f"\n2. Getting training status...")
        response = requests.get(f"{API_URL}/training/status/{job_id}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"✓ Training status retrieved:")
            print(f"  - Status: {result['training_status']}")
            print(f"  - Progress: {result['progress']}%")
            print(f"  - Current Epoch: {result['current_epoch']}/{result['total_epochs']}")
            print(f"  - Metrics: {json.dumps(result['metrics'], indent=4)}")
        
        # Test stop training
        print(f"\n3. Stopping training job...")
        response = requests.post(f"{API_URL}/training/stop/{job_id}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"✓ Training stopped!")
            print(f"  - Message: {result['message']}")
        
        # Test list models
        print(f"\n4. Listing all models...")
        response = requests.get(f"{API_URL}/training/models")
        
        if response.status_code == 200:
            result = response.json()
            print(f"✓ Found {result['count']} model(s)")
            for model in result['models']:
                print(f"  - {model.get('version', 'unknown')} - {model.get('status', 'unknown')}")
        
        # Test list training wafers
        print(f"\n5. Listing training wafers...")
        response = requests.get(f"{API_URL}/training/wafers")
        
        if response.status_code == 200:
            result = response.json()
            print(f"✓ Found {result['count']} training wafer(s)")
            for wafer in result['wafers'][:5]:  # Show first 5
                print(f"  - {wafer['wafer_id']} ({wafer['lot_id']}) - {wafer['status']}")
        
        print("\n" + "=" * 60)
        print("✅ All training API tests passed!")
        print("=" * 60)
    else:
        print(f"✗ Training start failed: {response.status_code}")
        print(f"  Error: {response.json()}")


if __name__ == '__main__':
    test_start_training()
