"""
Test GAN API Endpoints

Tests all GAN-related API endpoints
"""
import requests
import json
import time

BASE_URL = 'http://localhost:5000/api/v1'


def test_list_gan_models():
    """Test listing GAN models"""
    print("="*60)
    print("TEST 1: List GAN Models")
    print("="*60)
    
    response = requests.get(f'{BASE_URL}/gan/models')
    
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    if response.status_code == 200:
        print("✅ TEST PASSED")
    else:
        print("❌ TEST FAILED")
    
    print()


def test_start_gan_training():
    """Test starting GAN training"""
    print("="*60)
    print("TEST 2: Start GAN Training")
    print("="*60)
    
    payload = {
        "epochs": 10,  # Small number for testing
        "batch_size": 16,
        "n_critic": 5,
        "lambda_gp": 10.0,
        "learning_rate": 0.0001,
        "data_split": "train",
        "checkpoint_dir": "checkpoints/gan_test"
    }
    
    response = requests.post(f'{BASE_URL}/gan/train', json=payload)
    
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    if response.status_code == 200:
        print("✅ TEST PASSED")
        return response.json().get('job_id')
    else:
        print("❌ TEST FAILED")
        return None
    
    print()


def test_get_gan_training_status(job_id):
    """Test getting GAN training status"""
    print("="*60)
    print("TEST 3: Get GAN Training Status")
    print("="*60)
    
    if not job_id:
        print("⚠️  Skipping - no job_id")
        return
    
    response = requests.get(f'{BASE_URL}/gan/status/{job_id}')
    
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    if response.status_code == 200:
        print("✅ TEST PASSED")
    else:
        print("❌ TEST FAILED")
    
    print()


def test_generate_synthetic_wafers():
    """Test generating synthetic wafers"""
    print("="*60)
    print("TEST 4: Generate Synthetic Wafers")
    print("="*60)
    
    payload = {
        "num_samples": 10,
        "pattern": "Center",
        "defect_density": 0.5,
        "checkpoint": "checkpoints/gan/gan_final.pth",
        "output_dir": "data/synthetic_test"
    }
    
    response = requests.post(f'{BASE_URL}/gan/generate', json=payload)
    
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    if response.status_code == 200:
        print("✅ TEST PASSED")
        return response.json().get('job_id')
    else:
        print("❌ TEST FAILED")
        return None
    
    print()


def test_list_gan_jobs():
    """Test listing GAN jobs"""
    print("="*60)
    print("TEST 5: List GAN Jobs")
    print("="*60)
    
    response = requests.get(f'{BASE_URL}/gan/jobs')
    
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    if response.status_code == 200:
        print("✅ TEST PASSED")
    else:
        print("❌ TEST FAILED")
    
    print()


def test_validate_synthetic_quality():
    """Test validating synthetic quality"""
    print("="*60)
    print("TEST 6: Validate Synthetic Quality")
    print("="*60)
    
    payload = {
        "real_dir": "data/wafer_images",
        "synthetic_dir": "data/synthetic",
        "model_checkpoint": "checkpoints/best_model.pth"
    }
    
    response = requests.post(f'{BASE_URL}/gan/validate', json=payload)
    
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    if response.status_code == 200:
        print("✅ TEST PASSED")
        return response.json().get('job_id')
    else:
        print("❌ TEST FAILED")
        return None
    
    print()


def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("GAN API ENDPOINT TESTS")
    print("="*60)
    print(f"Base URL: {BASE_URL}")
    print("="*60)
    print()
    
    try:
        # Test 1: List GAN models
        test_list_gan_models()
        
        # Test 2: Start GAN training (commented out to avoid long-running process)
        # training_job_id = test_start_gan_training()
        # if training_job_id:
        #     time.sleep(2)
        #     test_get_gan_training_status(training_job_id)
        
        # Test 3: Generate synthetic wafers (requires trained GAN)
        # generation_job_id = test_generate_synthetic_wafers()
        
        # Test 4: List GAN jobs
        test_list_gan_jobs()
        
        # Test 5: Validate synthetic quality (requires synthetic data)
        # validation_job_id = test_validate_synthetic_quality()
        
        print("="*60)
        print("TEST SUMMARY")
        print("="*60)
        print("✅ List GAN Models")
        print("⚠️  Start GAN Training (skipped - long-running)")
        print("⚠️  Generate Synthetic Wafers (skipped - requires trained GAN)")
        print("✅ List GAN Jobs")
        print("⚠️  Validate Synthetic Quality (skipped - requires synthetic data)")
        print("="*60)
        print()
        print("NOTE: Some tests are skipped because they require:")
        print("  - Trained GAN model")
        print("  - Synthetic data")
        print("  - Long-running processes")
        print()
        print("To test these endpoints:")
        print("  1. Train a GAN using: python scripts/train_gan.py")
        print("  2. Generate synthetic data using: python scripts/generate_synthetic_wafers.py")
        print("  3. Then run the full API tests")
        print()
        
    except requests.exceptions.ConnectionError:
        print("\n❌ ERROR: Could not connect to API server")
        print("Please ensure the Flask server is running:")
        print("  python run.py")
        print()
        return 1
    
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == '__main__':
    exit(main())
