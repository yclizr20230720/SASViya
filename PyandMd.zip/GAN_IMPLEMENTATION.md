# GAN for Synthetic Wafer Map Generation - Implementation Guide

## Overview

This document describes the implementation of Task 10: **Conditional WGAN-GP for Synthetic Wafer Map Generation**.

The GAN generates realistic synthetic wafer maps for data augmentation, helping to:
- Balance class distribution in training data
- Increase dataset size for better model generalization
- Generate rare defect patterns for testing
- Simulate various defect densities and spatial distributions

## Architecture

### Conditional WGAN-GP

We implement a **Conditional Wasserstein GAN with Gradient Penalty (WGAN-GP)** which provides:
- Stable training (no mode collapse)
- Meaningful loss metrics (Wasserstein distance)
- High-quality image generation
- Conditional control over generated patterns

### Generator Network

**Input**:
- Noise vector: 100-dimensional random noise
- Pattern label: One of 10 pattern classes (embedded to 64D)
- Defect density: Continuous value 0.0-1.0 (embedded to 64D)

**Architecture**:
```
Input: noise (100) + pattern_emb (64) + density_emb (64) = 228D
  ↓
FC Layer: 228 → 256×7×7
  ↓
Reshape: (256, 7, 7)
  ↓
ConvTranspose2d: 7×7 → 14×14 (256 → 256 channels)
  ↓
ConvTranspose2d: 14×14 → 28×28 (256 → 128 channels)
  ↓
ConvTranspose2d: 28×28 → 56×56 (128 → 64 channels)
  ↓
ConvTranspose2d: 56×56 → 112×112 (64 → 32 channels)
  ↓
ConvTranspose2d: 112×112 → 224×224 (32 → 16 channels)
  ↓
Conv2d: 224×224 → 224×224 (16 → 3 channels RGB)
  ↓
Sigmoid: Output in [0, 1]
```

**Parameters**: ~15M

### Discriminator (Critic) Network

**Input**:
- Wafer map image: (3, 224, 224)
- Pattern label: Embedded to 64D
- Defect density: Embedded to 64D

**Architecture**:
```
Input: (3, 224, 224)
  ↓
Conv2d: 224×224 → 112×112 (3 → 16 channels)
  ↓
Conv2d: 112×112 → 56×56 (16 → 32 channels)
  ↓
Conv2d: 56×56 → 28×28 (32 → 64 channels)
  ↓
Conv2d: 28×28 → 14×14 (64 → 128 channels)
  ↓
Conv2d: 14×14 → 7×7 (128 → 256 channels)
  ↓
Flatten: 256×7×7 = 12,544
  ↓
Concatenate with conditions: 12,544 + 128 = 12,672
  ↓
FC Layers: 12,672 → 512 → 1
  ↓
Output: Critic score (no sigmoid)
```

**Parameters**: ~12M

## Training Procedure

### WGAN-GP Training Loop

For each training iteration:

1. **Train Discriminator (5 iterations)**:
   - Sample real images from dataset
   - Generate fake images from generator
   - Compute Wasserstein loss: `D(fake) - D(real)`
   - Compute gradient penalty on interpolated images
   - Total loss: `W_loss + λ_gp × GP`
   - Update discriminator

2. **Train Generator (1 iteration)**:
   - Generate fake images
   - Compute generator loss: `-D(fake)`
   - Update generator

### Hyperparameters

```python
# Training
epochs = 100
batch_size = 32
n_critic = 5  # Critic iterations per generator iteration
lambda_gp = 10.0  # Gradient penalty weight

# Optimizer
optimizer = Adam
learning_rate = 0.0001
betas = (0.0, 0.9)  # β1=0, β2=0.9 for WGAN

# Architecture
noise_dim = 100
img_size = 224
num_patterns = 10
```

### Loss Functions

**Wasserstein Loss**:
```
W_loss = E[D(fake)] - E[D(real)]
```

**Gradient Penalty**:
```
GP = E[(||∇_x D(x)||_2 - 1)^2]
where x = α×real + (1-α)×fake, α ~ U(0,1)
```

**Total Discriminator Loss**:
```
D_loss = W_loss + λ_gp × GP
```

**Generator Loss**:
```
G_loss = -E[D(fake)]
```

## Usage

### 1. Train GAN

```bash
# Basic training
python scripts/train_gan.py \
    --epochs 100 \
    --batch-size 32 \
    --data-dir data/processed \
    --checkpoint-dir checkpoints/gan

# Advanced options
python scripts/train_gan.py \
    --epochs 200 \
    --batch-size 64 \
    --n-critic 5 \
    --lambda-gp 10.0 \
    --lr 0.0001 \
    --split all \
    --save-interval 10 \
    --device cuda

# Resume from checkpoint
python scripts/train_gan.py \
    --resume checkpoints/gan/gan_epoch_50.pth \
    --epochs 100
```

### 2. Generate Synthetic Wafer Maps

```bash
# Generate 100 random samples
python scripts/generate_synthetic_wafers.py \
    --checkpoint checkpoints/gan/gan_final.pth \
    --num-samples 100 \
    --output-dir data/synthetic \
    --save-metadata

# Generate specific pattern
python scripts/generate_synthetic_wafers.py \
    --checkpoint checkpoints/gan/gan_final.pth \
    --num-samples 50 \
    --pattern Center \
    --defect-density 0.5 \
    --output-dir data/synthetic/center

# Generate with specific density
python scripts/generate_synthetic_wafers.py \
    --checkpoint checkpoints/gan/gan_final.pth \
    --num-samples 100 \
    --defect-density 0.8 \
    --output-dir data/synthetic/high_density
```

### 3. Validate Quality

```bash
# Validate synthetic images
python scripts/validate_synthetic_quality.py \
    --real-dir data/wafer_images \
    --synthetic-dir data/synthetic \
    --model-checkpoint checkpoints/best_model.pth

# With specific batch size
python scripts/validate_synthetic_quality.py \
    --real-dir data/wafer_images \
    --synthetic-dir data/synthetic \
    --model-checkpoint checkpoints/best_model.pth \
    --batch-size 64 \
    --device cuda
```

## Quality Metrics

### 1. FID (Fréchet Inception Distance)

Measures similarity between real and synthetic image distributions.

- **Score < 50**: Excellent quality
- **Score 50-100**: Good quality
- **Score > 100**: Needs improvement

### 2. SSIM (Structural Similarity Index)

Measures structural similarity between images.

- **Score > 0.8**: High similarity
- **Score 0.6-0.8**: Moderate similarity
- **Score < 0.6**: Low similarity

### 3. Pattern Classifier Validation

Uses trained pattern classifier to validate synthetic images.

- **Confidence > 0.7**: High quality, recognizable patterns
- **Confidence 0.5-0.7**: Moderate quality
- **Confidence < 0.5**: Low quality, unclear patterns

### 4. Physical Plausibility

Checks if generated images satisfy physical constraints:
- Pixel values in valid range [0, 1]
- Circular wafer boundary
- Realistic defect distributions
- Consistent with pattern semantics

## Integration with Training Pipeline

### Data Augmentation Strategy

1. **Balanced Sampling**:
   - Identify underrepresented pattern classes
   - Generate synthetic samples to balance distribution
   - Mix ratio: 70% real + 30% synthetic (configurable)

2. **On-the-Fly Generation**:
   - Generate synthetic samples during training
   - Cache generated samples for efficiency
   - Refresh cache periodically

3. **Quality Filtering**:
   - Only use high-confidence synthetic samples
   - Filter based on classifier confidence > 0.7
   - Validate physical plausibility

### Example Integration

```python
from app.ml.gan import WaferGAN
from app.ml.dataset import WaferDefectDataset

# Load GAN
gan = WaferGAN(device='cuda')
gan.load('checkpoints/gan/gan_final.pth')

# Generate synthetic samples for underrepresented class
pattern_label = torch.tensor([2])  # Donut pattern
defect_density = torch.tensor([[0.5]])
synthetic_images = gan.generate(pattern_label, defect_density, num_samples=100)

# Add to training dataset
# ... (implementation in dataset.py)
```

## Expected Performance

### Training Time

- **GPU (NVIDIA RTX 3090)**: ~2-3 hours for 100 epochs
- **GPU (NVIDIA GTX 1080)**: ~4-6 hours for 100 epochs
- **CPU**: Not recommended (very slow)

### Generation Speed

- **GPU**: ~100 images/second
- **CPU**: ~10 images/second

### Quality Targets

After 100 epochs of training:
- FID Score: < 50
- Classifier Confidence: > 0.7
- SSIM: > 0.6
- Physical Plausibility: 100%

## Files Created

### Core Implementation

1. **`app/ml/gan.py`** (600+ lines)
   - `Generator` class - Conditional generator network
   - `Discriminator` class - Conditional critic network
   - `WaferGAN` class - Main GAN trainer
   - `train_gan()` function - Training loop
   - Gradient penalty computation
   - Checkpoint save/load

### Scripts

2. **`scripts/train_gan.py`** (150+ lines)
   - CLI for GAN training
   - Hyperparameter configuration
   - Resume from checkpoint
   - Progress monitoring

3. **`scripts/generate_synthetic_wafers.py`** (200+ lines)
   - CLI for synthetic generation
   - Batch generation
   - Metadata saving
   - Pattern-specific generation

4. **`scripts/validate_synthetic_quality.py`** (300+ lines)
   - FID calculation
   - SSIM calculation
   - Pattern classifier validation
   - Physical plausibility checks
   - Quality assessment report

## Troubleshooting

### Common Issues

**1. Mode Collapse**
- **Symptom**: Generator produces same image repeatedly
- **Solution**: 
  - Increase n_critic (try 10)
  - Increase lambda_gp (try 20)
  - Reduce learning rate

**2. Training Instability**
- **Symptom**: Loss oscillates wildly
- **Solution**:
  - Use gradient clipping
  - Reduce learning rate
  - Check data normalization

**3. Low Quality Images**
- **Symptom**: Blurry or unrealistic images
- **Solution**:
  - Train longer (200+ epochs)
  - Increase model capacity
  - Improve conditioning mechanism

**4. Memory Issues**
- **Symptom**: CUDA out of memory
- **Solution**:
  - Reduce batch size
  - Use gradient accumulation
  - Enable mixed precision training

## Future Enhancements

### Planned Improvements

1. **Progressive Growing**
   - Start with low resolution (56×56)
   - Gradually increase to 224×224
   - Improves training stability

2. **StyleGAN Architecture**
   - Better control over generated features
   - Higher quality images
   - More diverse outputs

3. **Conditional Augmentation**
   - Add more conditioning signals
   - Spatial location control
   - Defect size control

4. **Quality-Aware Training**
   - Integrate FID into training loop
   - Automatic quality filtering
   - Adaptive synthetic ratio

## References

1. Arjovsky, M., Chintala, S., & Bottou, L. (2017). Wasserstein GAN. arXiv:1701.07875
2. Gulrajani, I., Ahmed, F., Arjovsky, M., Dumoulin, V., & Courville, A. (2017). Improved Training of Wasserstein GANs. arXiv:1704.00028
3. Mirza, M., & Osindero, S. (2014). Conditional Generative Adversarial Nets. arXiv:1411.1784

## Status

✅ **COMPLETED** - Task 10: GAN for Synthetic Data Generation

**Implementation Date**: January 19, 2026

**Files Created**: 4 files, 1,250+ lines of code

**Next Steps**:
1. Prepare training dataset with labeled wafer maps
2. Train GAN for 100-200 epochs
3. Generate synthetic samples
4. Validate quality metrics
5. Integrate with main training pipeline
6. Test data augmentation effectiveness

---

**Note**: GAN training requires a substantial dataset of labeled wafer maps. Ensure you have at least 500-1000 real wafer images before training the GAN for best results.
