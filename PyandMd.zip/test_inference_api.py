"""
Test script for Inference API endpoints

Tests all inference endpoints to verify functionality
"""
import requests
import json
import os
from pathlib import Path

# API base URL
BASE_URL = "http://localhost:5000/api/v1"

# Test configuration
TEST_WAFER_ID = "M93242.01"  # Adjust based on your data
TEST_IMAGE_PATH = "data/wafer_images/M93242.01_test_wafer.png"  # Adjust based on your data


def print_section(title):
    """Print section header"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")


def test_predict_existing_wafer():
    """Test 1: Predict for existing wafer"""
    print_section("TEST 1: Predict for Existing Wafer")
    
    url = f"{BASE_URL}/inference/predict"
    payload = {
        "wafer_id": TEST_WAFER_ID,
        "explain": True
    }
    
    print(f"POST {url}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    
    try:
        response = requests.post(url, json=payload)
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: Prediction successful")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Prediction failed")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def test_predict_upload_new():
    """Test 2: Predict with new image upload"""
    print_section("TEST 2: Predict with New Image Upload")
    
    if not os.path.exists(TEST_IMAGE_PATH):
        print(f"⚠️  TEST SKIPPED: Image file not found at {TEST_IMAGE_PATH}")
        return None
    
    url = f"{BASE_URL}/inference/predict"
    
    print(f"POST {url}")
    print(f"Uploading: {TEST_IMAGE_PATH}")
    
    try:
        with open(TEST_IMAGE_PATH, 'rb') as f:
            files = {'image_file': f}
            data = {'explain': 'true'}
            
            response = requests.post(url, files=files, data=data)
        
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: Upload and prediction successful")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Upload and prediction failed")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def test_batch_predict():
    """Test 3: Batch prediction"""
    print_section("TEST 3: Batch Prediction")
    
    url = f"{BASE_URL}/inference/batch-predict"
    payload = {
        "wafer_ids": [
            "M93242.01",
            "M34264.01",
            "M34264.02"
        ],
        "batch_size": 32
    }
    
    print(f"POST {url}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    
    try:
        response = requests.post(url, json=payload)
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: Batch prediction successful")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Batch prediction failed")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def test_explain_inference():
    """Test 4: Get explanation for inference"""
    print_section("TEST 4: Get Inference Explanation")
    
    url = f"{BASE_URL}/inference/explain/{TEST_WAFER_ID}"
    
    print(f"GET {url}")
    
    try:
        response = requests.get(url)
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: Explanation retrieved successfully")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Failed to get explanation")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def test_inference_history():
    """Test 5: Get inference history"""
    print_section("TEST 5: Get Inference History")
    
    url = f"{BASE_URL}/inference/history"
    params = {
        "limit": 10,
        "offset": 0
    }
    
    print(f"GET {url}")
    print(f"Params: {params}")
    
    try:
        response = requests.get(url, params=params)
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: History retrieved successfully")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Failed to get history")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def test_inference_history_filtered():
    """Test 6: Get filtered inference history"""
    print_section("TEST 6: Get Filtered Inference History")
    
    url = f"{BASE_URL}/inference/history"
    params = {
        "wafer_id": TEST_WAFER_ID,
        "min_confidence": 0.8,
        "limit": 5
    }
    
    print(f"GET {url}")
    print(f"Params: {params}")
    
    try:
        response = requests.get(url, params=params)
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: Filtered history retrieved successfully")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Failed to get filtered history")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("  INFERENCE API ENDPOINT TESTS")
    print("="*60)
    print(f"\nBase URL: {BASE_URL}")
    print(f"Test Wafer ID: {TEST_WAFER_ID}")
    print(f"Test Image: {TEST_IMAGE_PATH}")
    
    # Check if server is running
    try:
        response = requests.get(f"{BASE_URL.rsplit('/api/v1', 1)[0]}/health")
        if response.status_code != 200:
            print("\n❌ ERROR: Backend server is not running!")
            print("Please start the server with: python run.py")
            return
    except Exception as e:
        print("\n❌ ERROR: Cannot connect to backend server!")
        print(f"Error: {str(e)}")
        print("Please start the server with: python run.py")
        return
    
    # Run tests
    results = []
    
    # Test 1: Predict existing wafer
    result = test_predict_existing_wafer()
    results.append(("Predict Existing Wafer", result is not None))
    
    # Test 2: Predict with upload (optional - requires image file)
    result = test_predict_upload_new()
    if result is not None:
        results.append(("Predict with Upload", True))
    
    # Test 3: Batch predict
    result = test_batch_predict()
    results.append(("Batch Prediction", result is not None))
    
    # Test 4: Explain inference
    result = test_explain_inference()
    results.append(("Explain Inference", result is not None))
    
    # Test 5: Inference history
    result = test_inference_history()
    results.append(("Inference History", result is not None))
    
    # Test 6: Filtered history
    result = test_inference_history_filtered()
    results.append(("Filtered History", result is not None))
    
    # Print summary
    print_section("TEST SUMMARY")
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for test_name, success in results:
        status = "✅ PASSED" if success else "❌ FAILED"
        print(f"{status}: {test_name}")
    
    print(f"\n{'='*60}")
    print(f"  TOTAL: {passed}/{total} tests passed")
    print(f"{'='*60}\n")
    
    if passed == total:
        print("🎉 All tests passed! Inference API is working correctly.")
    else:
        print("⚠️  Some tests failed. Please check the errors above.")
    
    print("\nNOTE: Full inference testing requires a trained model.")
    print("If you see 'Model not found' errors, train a model first:")
    print("  python scripts/train_model.py")


if __name__ == "__main__":
    main()
