"""
Test script for Analytics API endpoints

Tests all analytics endpoints to verify functionality
"""
import requests
import json


# API base URL
BASE_URL = "http://localhost:5000/api/v1"


def print_section(title):
    """Print section header"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")


def test_dashboard_analytics():
    """Test 1: Get dashboard analytics"""
    print_section("TEST 1: Dashboard Analytics")
    
    url = f"{BASE_URL}/analytics/dashboard"
    params = {'date_range': 30}
    
    print(f"GET {url}")
    print(f"Params: {params}")
    
    try:
        response = requests.get(url, params=params)
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: Dashboard analytics retrieved")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Failed to get dashboard analytics")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def test_pattern_analytics():
    """Test 2: Get pattern analytics"""
    print_section("TEST 2: Pattern Analytics")
    
    url = f"{BASE_URL}/analytics/patterns"
    params = {
        'date_range': 30,
        'granularity': 'day'
    }
    
    print(f"GET {url}")
    print(f"Params: {params}")
    
    try:
        response = requests.get(url, params=params)
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: Pattern analytics retrieved")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Failed to get pattern analytics")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def test_yield_analytics():
    """Test 3: Get yield analytics"""
    print_section("TEST 3: Yield Analytics")
    
    url = f"{BASE_URL}/analytics/yield"
    params = {'date_range': 30}
    
    print(f"GET {url}")
    print(f"Params: {params}")
    
    try:
        response = requests.get(url, params=params)
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: Yield analytics retrieved")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Failed to get yield analytics")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def test_equipment_analytics():
    """Test 4: Get equipment analytics"""
    print_section("TEST 4: Equipment Analytics")
    
    url = f"{BASE_URL}/analytics/equipment"
    params = {'date_range': 30}
    
    print(f"GET {url}")
    print(f"Params: {params}")
    
    try:
        response = requests.get(url, params=params)
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: Equipment analytics retrieved")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Failed to get equipment analytics")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def test_temporal_analytics():
    """Test 5: Get temporal analytics"""
    print_section("TEST 5: Temporal Analytics")
    
    url = f"{BASE_URL}/analytics/temporal"
    params = {
        'date_range': 90,
        'granularity': 'day'
    }
    
    print(f"GET {url}")
    print(f"Params: {params}")
    
    try:
        response = requests.get(url, params=params)
        print(f"\nStatus Code: {response.status_code}")
        print(f"Response:\n{json.dumps(response.json(), indent=2)}")
        
        if response.status_code == 200:
            print("\n✅ TEST PASSED: Temporal analytics retrieved")
            return response.json()
        else:
            print("\n❌ TEST FAILED: Failed to get temporal analytics")
            return None
    except Exception as e:
        print(f"\n❌ TEST FAILED: {str(e)}")
        return None


def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("  ANALYTICS API ENDPOINT TESTS")
    print("="*60)
    print(f"\nBase URL: {BASE_URL}")
    
    # Check if server is running
    try:
        response = requests.get(f"{BASE_URL.rsplit('/api/v1', 1)[0]}/health")
        if response.status_code != 200:
            print("\n❌ ERROR: Backend server is not running!")
            print("Please start the server with: python run.py")
            return
    except Exception as e:
        print("\n❌ ERROR: Cannot connect to backend server!")
        print(f"Error: {str(e)}")
        print("Please start the server with: python run.py")
        return
    
    # Run tests
    results = []
    
    # Test 1: Dashboard analytics
    result = test_dashboard_analytics()
    results.append(("Dashboard Analytics", result is not None))
    
    # Test 2: Pattern analytics
    result = test_pattern_analytics()
    results.append(("Pattern Analytics", result is not None))
    
    # Test 3: Yield analytics
    result = test_yield_analytics()
    results.append(("Yield Analytics", result is not None))
    
    # Test 4: Equipment analytics
    result = test_equipment_analytics()
    results.append(("Equipment Analytics", result is not None))
    
    # Test 5: Temporal analytics
    result = test_temporal_analytics()
    results.append(("Temporal Analytics", result is not None))
    
    # Print summary
    print_section("TEST SUMMARY")
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for test_name, success in results:
        status = "✅ PASSED" if success else "❌ FAILED"
        print(f"{status}: {test_name}")
    
    print(f"\n{'='*60}")
    print(f"  TOTAL: {passed}/{total} tests passed")
    print(f"{'='*60}\n")
    
    if passed == total:
        print("🎉 All tests passed! Analytics API is working correctly.")
    else:
        print("⚠️  Some tests failed. Please check the errors above.")
    
    print("\nNOTE: Analytics are based on real data in the system.")
    print("Upload wafers and run inferences to see meaningful analytics.")


if __name__ == "__main__":
    main()
