    # GAN Training Data Requirements

## Overview

To train the GAN (Generative Adversarial Network) for synthetic wafer map generation, you need **real wafer defect map images** with proper labels. The GAN learns from these real images to generate realistic synthetic wafer maps.

## Required Data

### 1. Wafer Map Images

**Format:**
- **Image Type:** PNG or JPEG
- **Size:** 224×224 pixels (RGB)
- **Color:** RGB (3 channels)
- **Content:** Wafer defect pattern maps

**Example Images:**
```
data/wafer_images/
├── M34264.01_center1.png
├── M34264.01_Donut1.png
├── M34264.02_Edge_Loc1.png
├── M34264.03_Edge_Ring1.png
├── M34264.04_loc1.png
├── M34264.05_Near_Full1.png
├── M34264.06_Random1.png
├── M34264.07_Scrach1.png
└── ... (more images)
```

### 2. Metadata File

**Location:** `data/processed/splits/train_metadata.json`

**Format:** JSON array with the following structure:

```json
[
  {
    "image_path": "data/wafer_images/M34264.01_center1.png",
    "pattern_class": "Center",
    "root_cause_class": "Process Variation",
    "defect_density": 0.45,
    "lot_id": "M34264.01",
    "wafer_id": "M34264.01",
    "equipment_id": "EQ001"
  },
  {
    "image_path": "data/wafer_images/M34264.01_Donut1.png",
    "pattern_class": "Donut",
    "root_cause_class": "Equipment Issue",
    "defect_density": 0.62,
    "lot_id": "M34264.01",
    "wafer_id": "M34264.01",
    "equipment_id": "EQ002"
  }
]
```

**Required Fields:**
- `image_path`: Path to the wafer image file
- `pattern_class`: Defect pattern type (see Pattern Classes below)
- `root_cause_class`: Root cause of defect (optional for GAN)
- `defect_density`: Density of defects (0.0 to 1.0)

## Pattern Classes

The GAN supports 10 defect pattern classes:

1. **Center** - Defects concentrated in the center
2. **Donut** - Ring-shaped defect pattern
3. **Edge-Loc** - Defects at specific edge locations
4. **Edge-Ring** - Defects around the entire edge
5. **Loc** - Localized defects
6. **Near-full** - Nearly full wafer coverage
7. **Random** - Random defect distribution
8. **Scratch** - Scratch patterns
9. **none** - No defects (good wafer)
10. **Mixed** - Multiple pattern types

## Minimum Data Requirements

### For Effective GAN Training:

**Recommended:**
- **Minimum:** 500-1000 wafer images
- **Optimal:** 2000+ wafer images
- **Per Class:** 50-100 images per pattern class

**Current Dataset:**
- You currently have **13 wafer images** in `data/wafer_images/`
- This is **NOT sufficient** for effective GAN training
- You need to upload more wafer images

### Why More Data is Needed:

1. **GAN Quality:** GANs need diverse examples to learn realistic patterns
2. **Class Balance:** Each pattern type needs sufficient samples
3. **Generalization:** More data = better synthetic quality
4. **Stability:** Larger datasets lead to more stable training

## Data Preparation Steps

### Step 1: Upload Wafer Images

Use the **Upload** page in the web interface:

1. Navigate to `http://localhost:5173/upload`
2. Upload wafer map images (PNG/JPEG, 224×224)
3. Provide metadata:
   - Lot ID (e.g., M93242.01)
   - Wafer ID (e.g., M93242.01)
   - Pattern Class (select from dropdown)
   - Equipment ID (optional)

### Step 2: Prepare Training Data

Run the data preparation script:

```bash
cd wafer-defect-ap
python scripts/prepare_training_data.py
```

This script:
- Reads uploaded wafer images
- Creates train/validation/test splits
- Generates metadata files
- Saves to `data/processed/splits/`

### Step 3: Verify Data

Check that the metadata file exists:

```bash
# Check training metadata
cat data/processed/splits/train_metadata.json

# Count images per class
python -c "
import json
with open('data/processed/splits/train_metadata.json') as f:
    data = json.load(f)
    classes = {}
    for item in data:
        pattern = item['pattern_class']
        classes[pattern] = classes.get(pattern, 0) + 1
    for pattern, count in sorted(classes.items()):
        print(f'{pattern}: {count}')
"
```

## Current Data Status

Based on your current setup:

```
Current Status:
├── Uploaded Wafers: 12 wafers
├── Wafer Images: 13 images (including augmented)
├── Training Data: Available in data/processed/splits/
└── Status: ⚠️ INSUFFICIENT for GAN training
```

**You need to:**
1. Upload at least 500-1000 more wafer images
2. Ensure balanced distribution across pattern classes
3. Run data preparation script
4. Then start GAN training

## Data Sources

### Where to Get Wafer Data:

1. **Real Production Data:**
   - Export from your semiconductor fab
   - Historical defect inspection data
   - Quality control records

2. **Public Datasets:**
   - WM-811K dataset (811,457 wafer maps)
   - MixedWM38 dataset
   - Semiconductor manufacturing datasets

3. **Synthetic Data (Bootstrap):**
   - Use existing 13 images with heavy augmentation
   - Generate initial synthetic data
   - Iteratively improve

## GAN Training Workflow

Once you have sufficient data:

### 1. Via Web Interface:

1. Navigate to `http://localhost:5173/training/gan-management`
2. Click "GAN Training" tab
3. Configure parameters:
   - Epochs: 100-200
   - Batch Size: 32
   - Data Split: "All Data"
4. Click "Start GAN Training"
5. Monitor progress in real-time

### 2. Via Command Line:

```bash
cd wafer-defect-ap

# Train GAN
python scripts/train_gan.py \
    --epochs 100 \
    --batch-size 32 \
    --split all \
    --checkpoint-dir checkpoints/gan
```

## Expected Training Time

With sufficient data:

- **100 epochs:** 2-3 hours (GPU)
- **200 epochs:** 4-6 hours (GPU)
- **CPU only:** 10-20x slower (not recommended)

## Quality Metrics

After training, validate GAN quality:

```bash
# Generate test samples
python scripts/generate_synthetic_wafers.py \
    --checkpoint checkpoints/gan/gan_final.pth \
    --num-samples 100 \
    --output-dir data/synthetic_test

# Validate quality
python scripts/validate_synthetic_quality.py \
    --real-dir data/wafer_images \
    --synthetic-dir data/synthetic_test \
    --model-checkpoint checkpoints/best_model.pth
```

**Target Metrics:**
- FID Score: < 50 (lower is better)
- Classifier Confidence: > 0.7 (higher is better)
- Visual Quality: Realistic patterns

## Troubleshooting

### Issue: "Training metadata not found"

**Solution:**
```bash
# Run data preparation
python scripts/prepare_training_data.py
```

### Issue: "Insufficient data for training"

**Solution:**
- Upload more wafer images (target: 500+)
- Use data augmentation
- Consider using public datasets

### Issue: "GAN produces poor quality images"

**Causes:**
- Insufficient training data
- Imbalanced class distribution
- Too few training epochs
- Learning rate too high/low

**Solutions:**
- Increase dataset size
- Balance classes
- Train for more epochs (200+)
- Adjust learning rate

## Summary

**To start GAN training, you need:**

✅ **Minimum Requirements:**
- 500-1000 wafer map images (224×224 RGB)
- Labeled with pattern classes
- Metadata file with image paths and labels
- Prepared training data splits

⚠️ **Current Status:**
- You have 13 images (insufficient)
- Need to upload 487-987 more images
- Or use public datasets

📋 **Next Steps:**
1. Upload more wafer images via web interface
2. Run data preparation script
3. Verify data with validation script
4. Start GAN training via web interface
5. Monitor training progress
6. Generate synthetic data
7. Validate quality

---

**Need Help?**
- Check `wafer-defect-ap/GAN_IMPLEMENTATION.md` for technical details
- See `wafer-defect-ap/USER_UPLOAD_GUIDE.md` for upload instructions
- Review `GAN_INTEGRATION_COMPLETE.md` for API documentation
