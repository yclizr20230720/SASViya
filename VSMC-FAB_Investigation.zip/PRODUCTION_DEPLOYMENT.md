# VSMC AI Wafer Map - Production Deployment Guide

## System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                  Windows Server 2022                     │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  ┌──────────────────┐         ┌──────────────────┐     │
│  │   IIS (Port 80)  │         │  Backend Service │     │
│  │                  │         │   (Port 5000)    │     │
│  │  Frontend (React)│◄────────┤  Flask API       │     │
│  │  Static Files    │  HTTP   │  Python 3.10+    │     │
│  └──────────────────┘         └──────────────────┘     │
│                                                           │
│  ┌──────────────────────────────────────────────────┐   │
│  │           Data Storage (Local HDD)               │   │
│  │  - JSON Metadata                                 │   │
│  │  - Wafer Images                                  │   │
│  │  - Model Checkpoints                             │   │
│  └──────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
```

## Prerequisites

### System Requirements

- **OS**: Windows Server 2022
- **RAM**: 16GB minimum (32GB recommended)
- **Storage**: 500GB minimum
- **CPU**: 8 cores minimum
- **GPU**: NVIDIA GPU with CUDA support (optional, for training)

### Software Requirements

1. **Python 3.10+**
   - Download: https://www.python.org/downloads/
   - Add to PATH during installation

2. **Node.js 18+**
   - Download: https://nodejs.org/
   - Includes npm

3. **IIS (Internet Information Services)**
   - Install via Server Manager
   - Enable: Web Server (IIS) role
   - Features needed:
     - Static Content
     - Default Document
     - HTTP Errors
     - HTTP Redirection
     - URL Rewrite Module

4. **NSSM (Non-Sucking Service Manager)**
   - Download: https://nssm.cc/download
   - Extract to `C:\nssm` or add to PATH

5. **Git** (for deployment)
   - Download: https://git-scm.com/download/win

## Quick Start Deployment

### One-Command Deployment

Run as Administrator:

```cmd
deploy-all.bat
```

This script will:
1. Install backend Python dependencies
2. Configure backend as Windows Service
3. Build frontend production bundle
4. Deploy frontend to IIS
5. Start all services

### Verification

After deployment:

1. **Backend Health Check**
```cmd
curl http://localhost:5000/api/v1/health
```

Expected response:
```json
{"status": "healthy", "version": "1.0.0"}
```

2. **Frontend Access**

Open browser: `http://localhost` or `http://your-server-ip`

You should see the VSMC AI Wafer Map dashboard.

## Manual Deployment

### Backend Deployment

1. **Navigate to backend directory**
```cmd
cd wafer-defect-ap\deploy
```

2. **Install dependencies**
```cmd
install.bat
```

3. **Install as Windows Service**
```cmd
install_service.bat
```

4. **Start service**
```cmd
start_service.bat
```

5. **Verify service**
```cmd
sc query VSMCWaferDefectAPI
```

### Frontend Deployment

1. **Navigate to frontend directory**
```cmd
cd wafer-defect-gui\deploy
```

2. **Build production bundle**
```cmd
build.bat
```

3. **Install on IIS**
```cmd
install_iis.bat
```

4. **Verify IIS site**

Open IIS Manager and check "VSMCAIWaferMap" site is running.

## Configuration

### Backend Configuration

Edit `wafer-defect-ap\config.py`:

```python
class ProductionConfig(Config):
    DEBUG = False
    TESTING = False
    
    # API Configuration
    API_VERSION = '1.0.0'
    
    # CORS Origins
    CORS_ORIGINS = ['http://localhost', 'http://your-domain.com']
    
    # File Storage
    UPLOAD_FOLDER = 'data/wafer_images'
    MODEL_FOLDER = 'data/models'
    
    # Database
    METADATA_FOLDER = 'data/metadata'
```

### Frontend Configuration

Edit `wafer-defect-gui\.env.production`:

```env
VITE_API_BASE_URL=http://localhost:5000/api/v1
VITE_ENV=production
```

For production domain:
```env
VITE_API_BASE_URL=http://your-domain.com:5000/api/v1
```

### IIS Configuration

Edit `wafer-defect-gui\deploy\install_iis.bat` for custom settings:

```batch
set SITE_NAME=VSMCAIWaferMap
set APP_POOL_NAME=VSMCAIWaferMapPool
set SITE_PORT=80
```

## Service Management

### Backend Service

**Check Status**
```cmd
sc query VSMCWaferDefectAPI
```

**Start Service**
```cmd
cd wafer-defect-ap\deploy
start_service.bat
```

**Stop Service**
```cmd
cd wafer-defect-ap\deploy
stop_service.bat
```

**View Logs**
```cmd
type wafer-defect-ap\logs\service.log
```

### Frontend (IIS)

**Stop Site**
```cmd
%windir%\system32\inetsrv\appcmd.exe stop site "VSMCAIWaferMap"
```

**Start Site**
```cmd
%windir%\system32\inetsrv\appcmd.exe start site "VSMCAIWaferMap"
```

**Restart Site**
```cmd
%windir%\system32\inetsrv\appcmd.exe stop site "VSMCAIWaferMap"
%windir%\system32\inetsrv\appcmd.exe start site "VSMCAIWaferMap"
```

## Backup and Restore

### Backup

```cmd
cd wafer-defect-ap\deploy
backup.bat
```

Creates backup in `backups\backup_YYYYMMDD_HHMMSS\`:
- Data files
- Configuration
- Model checkpoints

### Restore

```cmd
cd wafer-defect-ap\deploy
restore.bat
```

Select backup to restore from list.

## Monitoring

### Health Checks

**Automated Health Check**
```cmd
cd wafer-defect-ap\deploy
python health_check.py
```

Checks:
- API responsiveness
- Model availability
- Disk space
- Memory usage
- Service status

**Manual Checks**

Backend:
```cmd
curl http://localhost:5000/api/v1/health
```

Frontend:
```cmd
curl http://localhost
```

### Logs

**Backend Logs**
- Service logs: `wafer-defect-ap\logs\service.log`
- Application logs: `wafer-defect-ap\logs\app.log`
- Training logs: `wafer-defect-ap\logs\training_*.log`

**IIS Logs**
- Location: `C:\inetpub\logs\LogFiles\W3SVC*\`
- Format: W3C Extended Log Format

## Troubleshooting

### Backend Issues

**Service won't start**
1. Check Python installation: `python --version`
2. Verify dependencies: `pip list`
3. Check logs: `type wafer-defect-ap\logs\service.log`
4. Test manually: `cd wafer-defect-ap && python run.py`

**API returns 500 errors**
1. Check application logs
2. Verify data directories exist
3. Check file permissions
4. Verify model files are present

### Frontend Issues

**IIS site won't start**
1. Verify IIS is installed
2. Check Application Pool status
3. Verify `dist` folder exists
4. Check IIS logs

**404 on routes**
1. Ensure `web.config` is in `dist` folder
2. Install URL Rewrite module for IIS
3. Restart IIS site

**API connection fails**
1. Verify backend service is running
2. Check CORS configuration
3. Verify API URL in `.env.production`
4. Check firewall rules

### Performance Issues

**Slow response times**
1. Check system resources (CPU, RAM, Disk)
2. Review application logs for errors
3. Optimize database queries
4. Enable caching

**High memory usage**
1. Restart services
2. Check for memory leaks in logs
3. Adjust model batch sizes
4. Increase system RAM

## Security

### Network Security

1. **Firewall Rules**
   - Allow inbound: Port 80 (HTTP), Port 443 (HTTPS)
   - Allow inbound: Port 5000 (Backend API) - restrict to localhost
   - Block all other inbound traffic

2. **HTTPS Configuration**
   - Obtain SSL certificate
   - Configure in IIS Manager
   - Update frontend API URL to HTTPS

### Application Security

1. **Backend**
   - API authentication (implement JWT tokens)
   - Input validation
   - Rate limiting
   - CORS restrictions

2. **Frontend**
   - Content Security Policy
   - XSS protection headers
   - Secure cookies

### Data Security

1. **File Permissions**
   - Restrict data folder access
   - Use service accounts with minimal privileges

2. **Backup Encryption**
   - Encrypt backup files
   - Store backups securely

## Updates and Maintenance

### Updating the Application

1. **Stop services**
```cmd
cd wafer-defect-ap\deploy
stop_service.bat

%windir%\system32\inetsrv\appcmd.exe stop site "VSMCAIWaferMap"
```

2. **Backup current version**
```cmd
cd wafer-defect-ap\deploy
backup.bat
```

3. **Pull latest code**
```cmd
git pull origin main
```

4. **Update backend**
```cmd
cd wafer-defect-ap
pip install -r requirements.txt --upgrade
```

5. **Rebuild frontend**
```cmd
cd wafer-defect-gui\deploy
build.bat
```

6. **Restart services**
```cmd
cd wafer-defect-ap\deploy
start_service.bat

%windir%\system32\inetsrv\appcmd.exe start site "VSMCAIWaferMap"
```

### Database Maintenance

- Regular backups (daily recommended)
- Clean old logs (weekly)
- Archive old inference results (monthly)

## Performance Tuning

### Backend Optimization

1. **Python Configuration**
   - Use production WSGI server (Waitress)
   - Enable response compression
   - Configure worker processes

2. **Model Optimization**
   - Use model quantization
   - Enable GPU acceleration
   - Batch inference requests

### Frontend Optimization

1. **IIS Configuration**
   - Enable static compression
   - Configure caching headers
   - Use CDN for assets

2. **Build Optimization**
   - Code splitting
   - Lazy loading
   - Asset optimization

## Support and Documentation

### Documentation Files

- Backend: `wafer-defect-ap\README.md`
- Frontend: `wafer-defect-gui\README.md`
- API: `wafer-defect-ap\API_ENDPOINTS.md`
- Training: `wafer-defect-ap\MODEL_TRAINING_GUIDE.md`

### Quick Reference

**Start Everything**
```cmd
start-all.bat
```

**Deploy Everything**
```cmd
deploy-all.bat
```

**Health Check**
```cmd
cd wafer-defect-ap\deploy
python health_check.py
```

**Backup**
```cmd
cd wafer-defect-ap\deploy
backup.bat
```

## Production Checklist

Before going live:

- [ ] All services start successfully
- [ ] Health checks pass
- [ ] Frontend loads correctly
- [ ] API endpoints respond
- [ ] Model inference works
- [ ] File uploads work
- [ ] Backups configured
- [ ] Monitoring enabled
- [ ] Firewall configured
- [ ] HTTPS enabled (recommended)
- [ ] Documentation reviewed
- [ ] Team trained on operations

## Contact

For technical support or questions about deployment, contact your system administrator or refer to the project documentation.
