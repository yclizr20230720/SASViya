# Training Queue Monitoring - Startup Guide

## Overview
This guide will help you start the backend and frontend servers to view the training job queue with real-time monitoring.

## Prerequisites
- Python 3.8+ installed
- Node.js 16+ installed
- All dependencies installed (see below)

## Step 1: Start the Backend (Flask API)

### Install Python Dependencies
```bash
cd wafer-defect-ap
pip install -r requirements.txt
```

### Start Flask Server
```bash
cd wafer-defect-ap
python run.py
```

**Expected Output:**
```
 * Serving Flask app 'app'
 * Debug mode: on
WARNING: This is a development server. Do not use it in a production deployment.
 * Running on all addresses (0.0.0.0)
 * Running on http://127.0.0.1:5000
 * Running on http://192.168.x.x:5000
```

**Verify Backend is Running:**
```bash
# In a new terminal
cd wafer-defect-ap
python test_training_queue_api.py
```

This should show:
- ✓ Success! Found 7 training jobs
- ✓ Success! Retrieved metrics for job training_20260118
- ✓ Success! Retrieved logs

## Step 2: Start the Frontend (React + Vite)

### Install Node Dependencies
```bash
cd wafer-defect-gui
npm install
```

### Start Development Server
```bash
cd wafer-defect-gui
npm run dev
```

**Expected Output:**
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: http://192.168.x.x:5173/
```

## Step 3: Access the Training Queue

1. Open your browser to: **http://localhost:5173**
2. Navigate to: **Training → Queue** (or directly to http://localhost:5173/training/queue)

## What You Should See

### Training Job Queue Table
The page displays all training jobs with:

**Columns:**
- **Job ID**: Unique identifier (e.g., training_20260118)
- **Status**: completed, running, queued, failed
- **Priority**: high, normal, low
- **Progress**: Visual progress bar with percentage
- **Model**: Architecture (e.g., EfficientNet-B3)
- **Epochs**: Current/Total (e.g., 30/30)
- **Metrics**: Real-time accuracy and loss
- **Actions**: View Details, View Logs, Cancel

### Expandable Details
Click on any row to see:
- **Configuration**: Model architecture, batch size, learning rate, dataset info
- **Real-Time Metrics**: Train/Val Loss, Pattern Accuracy, Root Cause Accuracy
- **Training Logs**: Live console output from training process
- **Metrics Chart**: Visual representation of training progress

### Sample Completed Job
The first job "training_20260118" shows:
- ✓ Status: Completed
- Progress: 100%
- Final Accuracy: 100% (Pattern), 100% (Root Cause)
- 30 epochs completed
- Full training logs available

## API Endpoints

The frontend connects to these Flask API endpoints:

1. **GET /api/v1/training/queue**
   - Returns list of all training jobs
   - URL: http://localhost:5000/api/v1/training/queue

2. **GET /api/v1/training/metrics/{job_id}**
   - Returns detailed metrics for a specific job
   - URL: http://localhost:5000/api/v1/training/metrics/training_20260118

3. **GET /api/v1/training/logs/{job_id}**
   - Returns console logs for a specific job
   - URL: http://localhost:5000/api/v1/training/logs/training_20260118

## Troubleshooting

### "No training jobs found"
**Cause:** Frontend can't connect to backend API

**Solutions:**
1. Verify Flask server is running on port 5000
2. Check browser console for CORS errors
3. Verify API URL in `.env` file: `VITE_API_BASE_URL=http://localhost:5000/api/v1`
4. Test API directly: `curl http://localhost:5000/api/v1/training/queue`

### CORS Errors
**Cause:** Cross-Origin Resource Sharing not configured

**Solution:** Flask app already has CORS enabled in `app/__init__.py`. If issues persist:
```python
# In app/__init__.py, verify CORS configuration:
CORS(app, resources={
    r"/api/*": {
        "origins": ["http://localhost:5173"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})
```

### Port Already in Use
**Backend (5000):**
```bash
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:5000 | xargs kill -9
```

**Frontend (5173):**
```bash
# Windows
netstat -ano | findstr :5173
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:5173 | xargs kill -9
```

### Empty Logs or Metrics
**Cause:** Log files not found or job_id mismatch

**Verify files exist:**
```bash
cd wafer-defect-ap
dir logs\training_current.log
dir logs\training_status.json
dir data\metadata\training_jobs.json
```

**Check job_id in training_jobs.json:**
```bash
cd wafer-defect-ap
type data\metadata\training_jobs.json
```

Look for job with `"job_id": "training_20260118"`

## File Locations

### Backend Files
- **Training Jobs**: `wafer-defect-ap/data/metadata/training_jobs.json`
- **Training Logs**: `wafer-defect-ap/logs/training_current.log`
- **Training Metrics**: `wafer-defect-ap/logs/training_status.json`
- **API Endpoints**: `wafer-defect-ap/app/api/v1/training.py`

### Frontend Files
- **Queue Component**: `wafer-defect-gui/src/pages/training/TrainingJobQueueIntegrated.tsx`
- **API Client**: `wafer-defect-gui/src/services/api.ts`
- **Routes**: `wafer-defect-gui/src/routes/index.tsx`
- **Environment**: `wafer-defect-gui/.env`

## Quick Start Commands

### Terminal 1 - Backend
```bash
cd wafer-defect-ap
python run.py
```

### Terminal 2 - Frontend
```bash
cd wafer-defect-gui
npm run dev
```

### Terminal 3 - Test API (Optional)
```bash
cd wafer-defect-ap
python test_training_queue_api.py
```

## Success Indicators

✓ Flask server running on http://localhost:5000
✓ React dev server running on http://localhost:5173
✓ API test shows 7 training jobs
✓ Browser shows training queue table
✓ First job "training_20260118" shows as completed
✓ Clicking job shows logs and metrics
✓ Logs display 30 epochs of training output

## Next Steps

Once the system is running:
1. Review the completed training job (training_20260118)
2. Examine the training logs to see epoch-by-epoch progress
3. Check the metrics to see accuracy improvements
4. Create new training jobs from the Training Dashboard
5. Monitor real-time progress of running jobs

## Support

If you encounter issues:
1. Check both terminal outputs for error messages
2. Verify all files exist in the locations listed above
3. Test API endpoints directly with curl or the test script
4. Check browser console for JavaScript errors
5. Verify CORS configuration in Flask app
