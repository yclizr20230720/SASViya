# Report Export Setup Guide

This guide explains how to set up PDF and PowerPoint export functionality for the Report Generator.

## Required Libraries

To enable full export functionality, install the following npm packages:

```bash
npm install jspdf html2canvas pptxgenjs
```

### Library Details

1. **jsPDF** - PDF generation library
   - Used for creating professional PDF reports
   - Supports custom layouts, fonts, and images
   - Documentation: https://github.com/parallax/jsPDF

2. **html2canvas** - Screenshot library
   - Captures charts and visualizations as images
   - Used to embed charts in PDF and PowerPoint
   - Documentation: https://html2canvas.hertzen.com/

3. **PptxGenJS** - PowerPoint generation library
   - Creates professional PowerPoint presentations
   - Supports slides, charts, tables, and images
   - Documentation: https://gitbrent.github.io/PptxGenJS/

## Implementation

The export service is located at `src/utils/reportExportService.ts` and includes:

### PDF Export Features
- Professional title pages
- Multi-column layouts
- Embedded charts and wafer maps
- Data tables
- Custom page sizes (A4, Letter, Legal)
- Portrait/Landscape orientation

### PowerPoint Export Features
- Title slides with branding
- Chart slides (pie, bar, line, funnel)
- Wafer map visualization slides
- Data table slides
- Metric dashboard slides
- Professional templates for each report type

## Template Structures

### Daily Summary Report
**PDF Layout:**
- Title page
- 4-column KPI metrics section
- 2-column charts section (Pattern Distribution, Hourly Volume)
- Full-width table (Top 10 Defect Wafers)

**PowerPoint Slides:**
1. Title slide
2. KPI metrics (4-up layout)
3. Pattern Distribution (pie chart)
4. Hourly Processing Volume (line chart)
5. Top 10 Defect Wafers (table)

### Pattern Analysis Report
**PDF Layout:**
- Title page
- Executive summary section
- 2-column wafer maps section
- 2-column charts section (Trends, Classification)
- Full-width pattern details table

**PowerPoint Slides:**
1. Title slide
2. Executive Summary
3. Representative Wafer Map
4. Pattern Trend Over Time (line chart)
5. Pattern Classification (bar chart)
6. Root Cause Distribution (pie chart)
7. Pattern Details (table)

### Yield Report
**PDF Layout:**
- Title page
- 3-column yield metrics section
- 2-column charts section (Yield Trend, Equipment Performance)
- Full-width equipment yield summary table

**PowerPoint Slides:**
1. Title slide
2. Yield Metrics (3-up layout)
3. Yield Trend (line chart)
4. Equipment Performance (bar chart)
5. Process Step Analysis (funnel chart)
6. Equipment Yield Summary (table)

## Usage Example

```typescript
import { exportToPDF, exportToPowerPoint } from './utils/reportExportService';

// Export as PDF
const pdfResult = await exportToPDF(report, template, {
  includeCharts: true,
  includeData: true,
  pageSize: 'A4',
  orientation: 'portrait',
});

// Export as PowerPoint
const pptxResult = await exportToPowerPoint(report, template, {
  includeCharts: true,
  includeData: true,
  pageSize: 'A4',
  orientation: 'landscape',
});
```

## Customization

To customize the export templates:

1. Edit `PDF_TEMPLATES` in `reportExportService.ts` for PDF layouts
2. Edit `PPTX_TEMPLATES` in `reportExportService.ts` for PowerPoint layouts
3. Modify section types, columns, and chart types as needed

## Notes

- The current implementation includes placeholder code with detailed comments
- Uncomment and implement the actual export logic after installing the libraries
- Charts and wafer maps need to be captured as images using html2canvas
- Consider implementing server-side export for better performance with large reports
