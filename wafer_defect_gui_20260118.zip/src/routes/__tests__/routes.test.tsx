import { describe, it, expect } from 'vitest';
import { router } from '../index';

describe('Router Configuration', () => {
  it('should have root route configured', () => {
    const routes = router.routes;
    expect(routes).toHaveLength(1);
    expect(routes[0].path).toBe('/');
  });

  it('should have all main routes configured', () => {
    const mainRoute = router.routes[0];
    const children = mainRoute.children || [];
    
    const paths = children.map(child => child.path || 'index');
    expect(paths).toContain('dashboard');
    expect(paths).toContain('upload');
    expect(paths).toContain('analysis/:waferId?');
    expect(paths).toContain('history');
    expect(paths).toContain('settings');
    expect(paths).toContain('admin');
  });

  it('should redirect root to dashboard', () => {
    const mainRoute = router.routes[0];
    const indexRoute = mainRoute.children?.find(child => child.index);
    expect(indexRoute).toBeDefined();
  });
});
