/**
 * Ingest Wafers Page
 * Upload and manage wafer map files for training data
 */

import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import {
  Box,
  Grid,
  Typography,
  Paper,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  LinearProgress,
  Chip,
  Alert,
  useTheme
} from '@mui/material';
import {
  CloudUpload,
  InsertDriveFile,
  Delete,
  CheckCircle,
  Storage,
  Add
} from '@mui/icons-material';

interface UploadFile {
  name: string;
  size: string;
  progress: number;
  status: 'uploading' | 'complete';
  id: string;
}

/**
 * Ingest Wafers Component
 */
const IngestWafers: React.FC = () => {
  const theme = useTheme();
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [metadata, setMetadata] = useState({
    lotId: '',
    equipmentId: '',
    processStep: 'Lithography'
  });

  // Dropzone configuration
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif'],
      'text/csv': ['.csv'],
      'application/xml': ['.xml'],
      'application/octet-stream': ['.bin'],
    },
    multiple: true, // Enable multiple file upload
    onDrop: (acceptedFiles) => {
      acceptedFiles.forEach((file) => {
        const mockFile: UploadFile = {
          name: file.name,
          size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
          progress: 0,
          status: 'uploading',
          id: Math.random().toString(36).substring(2, 11)
        };
        
        setFiles((prev) => [...prev, mockFile]);

        // Simulate upload progress
        let prog = 0;
        const interval = setInterval(() => {
          prog += 10;
          setFiles((prev) =>
            prev.map((f) =>
              f.id === mockFile.id
                ? { ...f, progress: prog, status: prog >= 100 ? 'complete' : 'uploading' }
                : f
            )
          );
          if (prog >= 100) {
            clearInterval(interval);
          }
        }, 200);
      });
    }
  });

  const handleRemoveFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const handleCommit = () => {
    // Handle commit to library
    console.log('Committing files to library:', { files, metadata });
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={600} gutterBottom>
          Ingest Wafer Data
        </Typography>
        <Typography variant="body1" color="text.secondary" gutterBottom>
          Upload wafer map image files for training and analysis
        </Typography>
        <Box sx={{ mt: 2, display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
          <Chip 
            label="📁 Folder Upload Supported" 
            color="primary" 
            variant="outlined"
            size="small"
          />
          <Chip 
            label="📤 Multiple Files Upload" 
            color="success" 
            variant="outlined"
            size="small"
          />
          <Chip 
            label="🖼️ Image Formats: JPG, PNG, GIF" 
            color="info" 
            variant="outlined"
            size="small"
          />
        </Box>
      </Box>

      {/* Important Information Alert */}
      <Alert 
        severity="info" 
        sx={{ mb: 3, borderRadius: 2 }}
        icon={<CloudUpload />}
      >
        <Typography variant="subtitle2" fontWeight={600} gutterBottom>
          📋 Upload Instructions
        </Typography>
        <Box component="ul" sx={{ m: 0, pl: 2, '& li': { mb: 0.5 } }}>
          <li>
            <Typography variant="body2">
              <strong>Image Files:</strong> Supports JPG, JPEG, PNG, GIF formats for wafer map images
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>Folder Upload:</strong> You can select entire folders containing wafer map files
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>Multiple Files:</strong> Upload hundreds of files at once - batch processing is automatic
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>Large Files:</strong> Supports huge files up to 50MB per file
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>Data Formats:</strong> Also supports CSV, XML (KLARF), and binary formats
            </Typography>
          </li>
        </Box>
      </Alert>

      <Grid container spacing={3}>
        {/* Left Column - Upload Zone and Queue */}
        <Grid size={{ xs: 12, lg: 8 }}>
          {/* Drag and Drop Zone */}
          <Paper
            {...getRootProps()}
            sx={{
              p: 6,
              mb: 3,
              border: '2px dashed',
              borderColor: isDragActive ? 'primary.main' : 'divider',
              borderRadius: 3,
              textAlign: 'center',
              cursor: 'pointer',
              bgcolor: isDragActive ? 'action.hover' : 'background.paper',
              transition: 'all 0.3s',
              '&:hover': {
                borderColor: 'primary.main',
                bgcolor: 'action.hover',
                transform: 'translateY(-2px)',
                boxShadow: theme.shadows[4]
              }
            }}
          >
            <input {...getInputProps()} />
            <Box
              sx={{
                width: 64,
                height: 64,
                borderRadius: '50%',
                bgcolor: 'success.lighter',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mx: 'auto',
                mb: 3,
                transition: 'transform 0.3s',
                '&:hover': {
                  transform: 'scale(1.1)'
                }
              }}
            >
              <CloudUpload sx={{ fontSize: 32, color: 'success.main' }} />
            </Box>
            <Typography variant="h6" gutterBottom>
              Drag and drop wafer map files or folders
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              <strong>Image Files:</strong> JPG, JPEG, PNG, GIF
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              <strong>Data Files:</strong> CSV, XML, BIN, KLARF formats
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
              <Button
                variant="contained"
                sx={{
                  borderRadius: 2,
                  px: 4,
                  py: 1.5,
                  fontWeight: 600
                }}
              >
                Browse Files
              </Button>
              <Button
                variant="outlined"
                sx={{
                  borderRadius: 2,
                  px: 4,
                  py: 1.5,
                  fontWeight: 600
                }}
              >
                Select Folder
              </Button>
            </Box>
            <Typography variant="caption" color="text.secondary" sx={{ mt: 2, display: 'block' }}>
              💡 Tip: You can upload multiple files or entire folders at once
            </Typography>
          </Paper>

          {/* Queue Management */}
          <Paper sx={{ borderRadius: 3, overflow: 'hidden' }}>
            <Box
              sx={{
                p: 2,
                borderBottom: 1,
                borderColor: 'divider',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <Typography variant="h6" fontWeight={600}>
                Queue Management
              </Typography>
              <Chip
                label={`${files.length} Files Pending`}
                size="small"
                color="primary"
                variant="outlined"
              />
            </Box>

            {files.length === 0 ? (
              <Box sx={{ p: 6, textAlign: 'center' }}>
                <Typography variant="body2" color="text.secondary">
                  No files in queue
                </Typography>
              </Box>
            ) : (
              <List sx={{ p: 0 }}>
                {files.map((file) => (
                  <ListItem
                    key={file.id}
                    sx={{
                      borderBottom: 1,
                      borderColor: 'divider',
                      '&:last-child': {
                        borderBottom: 0
                      },
                      '&:hover': {
                        bgcolor: 'action.hover'
                      }
                    }}
                  >
                    <ListItemIcon>
                      <Box
                        sx={{
                          width: 40,
                          height: 40,
                          borderRadius: 1,
                          bgcolor: 'grey.100',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        <InsertDriveFile sx={{ color: 'text.secondary' }} />
                      </Box>
                    </ListItemIcon>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="body2" fontWeight={600}>
                            {file.name}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {file.size}
                          </Typography>
                        </Box>
                      }
                      secondary={
                        <LinearProgress
                          variant="determinate"
                          value={file.progress}
                          sx={{
                            height: 6,
                            borderRadius: 3,
                            bgcolor: 'grey.200',
                            '& .MuiLinearProgress-bar': {
                              borderRadius: 3,
                              bgcolor: file.status === 'complete' ? 'success.main' : 'primary.main'
                            }
                          }}
                        />
                      }
                    />
                    <ListItemSecondaryAction>
                      {file.status === 'complete' ? (
                        <CheckCircle sx={{ color: 'success.main' }} />
                      ) : (
                        <IconButton
                          edge="end"
                          onClick={() => handleRemoveFile(file.id)}
                          size="small"
                        >
                          <Delete sx={{ fontSize: 20 }} />
                        </IconButton>
                      )}
                    </ListItemSecondaryAction>
                  </ListItem>
                ))}
              </List>
            )}
          </Paper>
        </Grid>

        {/* Right Column - Metadata and Info */}
        <Grid size={{ xs: 12, lg: 4 }}>
          {/* Batch Metadata */}
          <Paper sx={{ p: 3, mb: 3, borderRadius: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
              <Add sx={{ color: 'text.secondary' }} />
              <Typography variant="h6" fontWeight={600}>
                Batch Metadata
              </Typography>
            </Box>

            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <TextField
                fullWidth
                label="Lot ID"
                placeholder="e.g. LOT-2024-X1"
                value={metadata.lotId}
                onChange={(e) => setMetadata({ ...metadata, lotId: e.target.value })}
                size="small"
              />

              <FormControl fullWidth size="small">
                <InputLabel>Process Step</InputLabel>
                <Select
                  value={metadata.processStep}
                  label="Process Step"
                  onChange={(e) => setMetadata({ ...metadata, processStep: e.target.value })}
                >
                  <MenuItem value="Lithography">Lithography</MenuItem>
                  <MenuItem value="Etch">Etch</MenuItem>
                  <MenuItem value="CMP">CMP</MenuItem>
                  <MenuItem value="CVD">CVD</MenuItem>
                  <MenuItem value="PVD">PVD</MenuItem>
                  <MenuItem value="Implant">Implant</MenuItem>
                </Select>
              </FormControl>

              <TextField
                fullWidth
                label="Equipment ID"
                placeholder="e.g. TOOL-ASML-04"
                value={metadata.equipmentId}
                onChange={(e) => setMetadata({ ...metadata, equipmentId: e.target.value })}
                size="small"
              />
            </Box>

            <Button
              fullWidth
              variant="contained"
              size="large"
              startIcon={<Storage />}
              onClick={handleCommit}
              disabled={files.length === 0}
              sx={{
                mt: 3,
                py: 1.5,
                borderRadius: 2,
                fontWeight: 600,
                boxShadow: theme.shadows[4]
              }}
            >
              Commit to Library
            </Button>
          </Paper>

          {/* Batch Processing Info */}
          <Alert
            severity="success"
            icon={<CheckCircle />}
            sx={{
              borderRadius: 3,
              '& .MuiAlert-message': {
                width: '100%'
              }
            }}
          >
            <Typography variant="subtitle2" fontWeight={600} gutterBottom>
              Batch Processing Active
            </Typography>
            <Typography variant="caption" sx={{ display: 'block', lineHeight: 1.6 }}>
              Multiple file uploads are processed in parallel using the distributed inference
              worker cluster.
            </Typography>
          </Alert>

          {/* Supported Formats */}
          <Paper sx={{ p: 3, mt: 3, borderRadius: 3 }}>
            <Typography variant="subtitle2" fontWeight={600} gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <InsertDriveFile sx={{ fontSize: 20 }} />
              Supported File Formats
            </Typography>
            <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
              <Box>
                <Typography variant="body2" fontWeight={600} color="primary.main" gutterBottom>
                  🖼️ Image Formats (Wafer Maps)
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • JPG / JPEG - Standard image format
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • PNG - High quality images
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • GIF - Animated or static images
                </Typography>
              </Box>
              
              <Box>
                <Typography variant="body2" fontWeight={600} color="success.main" gutterBottom>
                  📊 Data Formats
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • CSV - Die coordinates and data
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • XML - KLARF standard format
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • BIN - Binary format files
                </Typography>
              </Box>

              <Box sx={{ mt: 1, p: 2, bgcolor: 'info.lighter', borderRadius: 1 }}>
                <Typography variant="caption" fontWeight={600} color="info.dark" sx={{ display: 'block', mb: 0.5 }}>
                  📁 Folder Upload
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Select entire folders containing wafer map files for batch processing
                </Typography>
              </Box>

              <Box sx={{ mt: 1, p: 2, bgcolor: 'success.lighter', borderRadius: 1 }}>
                <Typography variant="caption" fontWeight={600} color="success.dark" sx={{ display: 'block', mb: 0.5 }}>
                  📤 Multiple Files
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Upload hundreds of files simultaneously with automatic batch processing
                </Typography>
              </Box>

              <Box sx={{ mt: 1, p: 2, bgcolor: 'warning.lighter', borderRadius: 1 }}>
                <Typography variant="caption" fontWeight={600} color="warning.dark" sx={{ display: 'block', mb: 0.5 }}>
                  💾 File Size Limit
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Maximum 50MB per file • No limit on number of files
                </Typography>
              </Box>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default IngestWafers;
