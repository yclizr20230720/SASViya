import { useState } from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Button,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Menu,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tabs,
  Tab,
  Card,
  CardContent,
  Divider,
  Tooltip,
  Alert,
  AlertTitle,
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import type { GridColDef, GridRenderCellParams } from '@mui/x-data-grid';
import {
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  CheckCircle as CheckCircleIcon,
  CompareArrows as CompareIcon,
  CloudUpload as DeployIcon,
  Archive as ArchiveIcon,
  Download as DownloadIcon,
  MoreVert as MoreIcon,
  Info as InfoIcon,
  Speed as SpeedIcon,
  Memory as MemoryIcon,
  Timer as TimerIcon,
  Code as CodeIcon,
  Assessment as MetricsIcon,
  Help as HelpIcon,
  Visibility as ViewIcon,
} from '@mui/icons-material';
import { XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

// Model version interface
interface ModelVersion {
  id: string;
  version: string;
  architecture: string;
  status: 'active' | 'staging' | 'development' | 'archived';
  accuracy: number;
  f1Score: number;
  precision: number;
  recall: number;
  trainedDate: string;
  trainedBy: string;
  trainingDuration: string;
  datasetSize: number;
  epochs: number;
  batchSize: number;
  learningRate: number;
  optimizer: string;
  tags: string[];
  deployments: {
    environment: string;
    deployedDate: string;
    status: string;
  }[];
  artifacts: {
    modelWeights: string;
    onnxExport: string;
    tensorrtExport: string;
  };
}

// Mock model versions data
const mockModelVersions: ModelVersion[] = [
  {
    id: 'model-v4.2',
    version: 'v4.2.0',
    architecture: 'ResNet50-WV',
    status: 'active',
    accuracy: 0.972,
    f1Score: 0.955,
    precision: 0.962,
    recall: 0.948,
    trainedDate: '2024-05-20 14:30',
    trainedBy: 'Dr. Sarah Chen',
    trainingDuration: '4h 23m',
    datasetSize: 14224,
    epochs: 50,
    batchSize: 32,
    learningRate: 0.001,
    optimizer: 'AdamW',
    tags: ['production', 'validated', 'high-accuracy'],
    deployments: [
      { environment: 'Production', deployedDate: '2024-05-20 16:00', status: 'active' },
      { environment: 'Staging', deployedDate: '2024-05-20 15:00', status: 'active' },
    ],
    artifacts: {
      modelWeights: 'resnet50-wv-v4.2.pth',
      onnxExport: 'resnet50-wv-v4.2.onnx',
      tensorrtExport: 'resnet50-wv-v4.2.trt',
    },
  },
  {
    id: 'model-v4.1',
    version: 'v4.1.0',
    architecture: 'ResNet50-WV',
    status: 'staging',
    accuracy: 0.968,
    f1Score: 0.951,
    precision: 0.958,
    recall: 0.944,
    trainedDate: '2024-05-18 10:15',
    trainedBy: 'Dr. Sarah Chen',
    trainingDuration: '4h 18m',
    datasetSize: 13890,
    epochs: 50,
    batchSize: 32,
    learningRate: 0.001,
    optimizer: 'AdamW',
    tags: ['staging', 'validated'],
    deployments: [{ environment: 'Staging', deployedDate: '2024-05-18 12:00', status: 'replaced' }],
    artifacts: {
      modelWeights: 'resnet50-wv-v4.1.pth',
      onnxExport: 'resnet50-wv-v4.1.onnx',
      tensorrtExport: 'resnet50-wv-v4.1.trt',
    },
  },
  {
    id: 'model-v4.0',
    version: 'v4.0.0',
    architecture: 'ResNet50-WV',
    status: 'development',
    accuracy: 0.964,
    f1Score: 0.947,
    precision: 0.954,
    recall: 0.940,
    trainedDate: '2024-05-15 09:00',
    trainedBy: 'Dr. Michael Zhang',
    trainingDuration: '4h 10m',
    datasetSize: 13200,
    epochs: 45,
    batchSize: 32,
    learningRate: 0.001,
    optimizer: 'Adam',
    tags: ['development', 'experimental'],
    deployments: [],
    artifacts: {
      modelWeights: 'resnet50-wv-v4.0.pth',
      onnxExport: 'resnet50-wv-v4.0.onnx',
      tensorrtExport: '',
    },
  },
  {
    id: 'model-v3.5',
    version: 'v3.5.2',
    architecture: 'EfficientNet-B3',
    status: 'archived',
    accuracy: 0.958,
    f1Score: 0.942,
    precision: 0.950,
    recall: 0.934,
    trainedDate: '2024-05-10 14:00',
    trainedBy: 'Dr. Sarah Chen',
    trainingDuration: '3h 45m',
    datasetSize: 12800,
    epochs: 40,
    batchSize: 24,
    learningRate: 0.0005,
    optimizer: 'SGD',
    tags: ['archived', 'legacy'],
    deployments: [{ environment: 'Production', deployedDate: '2024-05-10 16:00', status: 'decommissioned' }],
    artifacts: {
      modelWeights: 'efficientnet-b3-v3.5.pth',
      onnxExport: 'efficientnet-b3-v3.5.onnx',
      tensorrtExport: '',
    },
  },
];

// Training metrics data for selected model
const trainingMetricsData = [
  { epoch: 1, trainAcc: 0.62, valAcc: 0.60, trainLoss: 1.05, valLoss: 1.08 },
  { epoch: 10, trainAcc: 0.82, valAcc: 0.80, trainLoss: 0.52, valLoss: 0.56 },
  { epoch: 20, trainAcc: 0.91, valAcc: 0.89, trainLoss: 0.28, valLoss: 0.32 },
  { epoch: 30, trainAcc: 0.95, valAcc: 0.93, trainLoss: 0.15, valLoss: 0.19 },
  { epoch: 40, trainAcc: 0.97, valAcc: 0.95, trainLoss: 0.09, valLoss: 0.13 },
  { epoch: 50, trainAcc: 0.98, valAcc: 0.97, trainLoss: 0.06, valLoss: 0.10 },
];

// Confusion matrix data
const confusionMatrix = [
  { predicted: 'Edge', actual: 'Edge', value: 98 },
  { predicted: 'Edge', actual: 'Center', value: 1 },
  { predicted: 'Edge', actual: 'Scratch', value: 0 },
  { predicted: 'Center', actual: 'Edge', value: 2 },
  { predicted: 'Center', actual: 'Center', value: 95 },
  { predicted: 'Center', actual: 'Scratch', value: 1 },
  { predicted: 'Scratch', actual: 'Edge', value: 0 },
  { predicted: 'Scratch', actual: 'Center', value: 2 },
  { predicted: 'Scratch', actual: 'Scratch', value: 97 },
];

const patterns = ['Edge', 'Center', 'Scratch'];

// Metric quality thresholds and explanations
const metricInfo = {
  accuracy: {
    name: 'Accuracy',
    description: 'Overall correctness of the model across all classes. Measures the ratio of correct predictions to total predictions.',
    formula: '(TP + TN) / (TP + TN + FP + FN)',
    excellent: 0.97,
    good: 0.95,
    fair: 0.90,
    interpretation: {
      excellent: '≥97%: Outstanding performance, production-ready',
      good: '95-97%: Good performance, suitable for most applications',
      fair: '90-95%: Acceptable performance, may need improvement',
      poor: '<90%: Poor performance, requires retraining',
    },
  },
  f1Score: {
    name: 'F1 Score',
    description: 'Harmonic mean of precision and recall. Provides a balanced measure when you need to balance false positives and false negatives.',
    formula: '2 × (Precision × Recall) / (Precision + Recall)',
    excellent: 0.95,
    good: 0.92,
    fair: 0.85,
    interpretation: {
      excellent: '≥0.95: Excellent balance between precision and recall',
      good: '0.92-0.95: Good balance, reliable for production',
      fair: '0.85-0.92: Acceptable, monitor performance',
      poor: '<0.85: Poor balance, needs improvement',
    },
  },
  precision: {
    name: 'Precision',
    description: 'Accuracy of positive predictions. High precision means low false positive rate - when the model predicts a defect, it is usually correct.',
    formula: 'TP / (TP + FP)',
    excellent: 0.96,
    good: 0.93,
    fair: 0.88,
    interpretation: {
      excellent: '≥0.96: Very few false alarms, high confidence in predictions',
      good: '0.93-0.96: Low false alarm rate, trustworthy',
      fair: '0.88-0.93: Moderate false alarms, acceptable',
      poor: '<0.88: High false alarm rate, unreliable',
    },
  },
  recall: {
    name: 'Recall (Sensitivity)',
    description: 'Ability to find all positive cases. High recall means low false negative rate - the model catches most actual defects.',
    formula: 'TP / (TP + FN)',
    excellent: 0.95,
    good: 0.92,
    fair: 0.85,
    interpretation: {
      excellent: '≥0.95: Catches almost all defects, minimal misses',
      good: '0.92-0.95: Catches most defects, reliable detection',
      fair: '0.85-0.92: Misses some defects, monitor closely',
      poor: '<0.85: Misses many defects, critical issue',
    },
  },
};

export default function ModelMetrics() {
  const [selectedModel, setSelectedModel] = useState<ModelVersion>(mockModelVersions[0]);
  const [compareDialogOpen, setCompareDialogOpen] = useState(false);
  const [compareModel, setCompareModel] = useState<ModelVersion | null>(null);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [activeTab, setActiveTab] = useState(0);
  const [helpDialogOpen, setHelpDialogOpen] = useState(false);

  const getStatusColor = (status: string): 'success' | 'info' | 'warning' | 'default' => {
    switch (status) {
      case 'active':
        return 'success';
      case 'staging':
        return 'info';
      case 'development':
        return 'warning';
      default:
        return 'default';
    }
  };

  const getMetricQuality = (value: number, metric: keyof typeof metricInfo): { label: string; color: string } => {
    const thresholds = metricInfo[metric];
    if (value >= thresholds.excellent) return { label: 'Excellent', color: '#10b981' };
    if (value >= thresholds.good) return { label: 'Good', color: '#3b82f6' };
    if (value >= thresholds.fair) return { label: 'Fair', color: '#f59e0b' };
    return { label: 'Poor', color: '#ef4444' };
  };

  const getConfusionValue = (predicted: string, actual: string) => {
    const item = confusionMatrix.find((m) => m.predicted === predicted && m.actual === actual);
    return item?.value || 0;
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleCompare = () => {
    setCompareModel(mockModelVersions[1]);
    setCompareDialogOpen(true);
    handleMenuClose();
  };

  const handleDeploy = () => {
    console.log('Deploying model:', selectedModel.version);
    handleMenuClose();
  };

  const handleArchive = () => {
    console.log('Archiving model:', selectedModel.version);
    handleMenuClose();
  };

  const handleDownload = (artifact: string) => {
    console.log('Downloading:', artifact);
  };

  // DataGrid columns
  const columns: GridColDef[] = [
    {
      field: 'version',
      headerName: 'Version',
      width: 120,
      renderCell: (params: GridRenderCellParams) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {params.row.status === 'active' && <CheckCircleIcon color="success" fontSize="small" />}
          <Typography variant="body2" sx={{ fontWeight: 600 }}>
            {params.value}
          </Typography>
        </Box>
      ),
    },
    {
      field: 'architecture',
      headerName: 'Architecture',
      width: 150,
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 120,
      renderCell: (params: GridRenderCellParams) => (
        <Chip label={params.value} size="small" color={getStatusColor(params.value as string)} />
      ),
    },
    {
      field: 'accuracy',
      headerName: 'Accuracy',
      width: 130,
      renderCell: (params: GridRenderCellParams) => {
        const quality = getMetricQuality(params.value as number, 'accuracy');
        return (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              {((params.value as number) * 100).toFixed(1)}%
            </Typography>
            <Chip label={quality.label} size="small" sx={{ bgcolor: quality.color, color: 'white', fontSize: '0.65rem' }} />
          </Box>
        );
      },
    },
    {
      field: 'f1Score',
      headerName: 'F1 Score',
      width: 130,
      renderCell: (params: GridRenderCellParams) => {
        const quality = getMetricQuality(params.value as number, 'f1Score');
        return (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              {(params.value as number).toFixed(3)}
            </Typography>
            <Chip label={quality.label} size="small" sx={{ bgcolor: quality.color, color: 'white', fontSize: '0.65rem' }} />
          </Box>
        );
      },
    },
    {
      field: 'precision',
      headerName: 'Precision',
      width: 110,
      renderCell: (params: GridRenderCellParams) => (
        <Typography variant="body2" sx={{ fontWeight: 600 }}>
          {(params.value as number).toFixed(3)}
        </Typography>
      ),
    },
    {
      field: 'recall',
      headerName: 'Recall',
      width: 110,
      renderCell: (params: GridRenderCellParams) => (
        <Typography variant="body2" sx={{ fontWeight: 600 }}>
          {(params.value as number).toFixed(3)}
        </Typography>
      ),
    },
    {
      field: 'trainedDate',
      headerName: 'Trained Date',
      width: 150,
    },
    {
      field: 'trainedBy',
      headerName: 'Trained By',
      width: 150,
    },
    {
      field: 'datasetSize',
      headerName: 'Dataset Size',
      width: 120,
      renderCell: (params: GridRenderCellParams) => (
        <Typography variant="body2">{(params.value as number).toLocaleString()}</Typography>
      ),
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 150,
      sortable: false,
      renderCell: (params: GridRenderCellParams) => (
        <Box sx={{ display: 'flex', gap: 0.5 }}>
          <Tooltip title="View Details">
            <IconButton size="small" onClick={() => setSelectedModel(params.row as ModelVersion)}>
              <ViewIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <Tooltip title="Deploy">
            <IconButton size="small" color="primary">
              <DeployIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <Tooltip title="Download">
            <IconButton size="small" color="success">
              <DownloadIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <Tooltip title="More">
            <IconButton size="small">
              <MoreIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ];

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 600, mb: 0.5 }}>
            Model Registry & Performance
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Comprehensive model versioning, metrics tracking, and deployment management
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Tooltip title="Learn about metrics and how to judge model quality">
            <Button variant="outlined" startIcon={<HelpIcon />} onClick={() => setHelpDialogOpen(true)} size="small">
              Metrics Guide
            </Button>
          </Tooltip>
          <Button variant="outlined" startIcon={<CompareIcon />} onClick={handleCompare} size="small">
            Compare
          </Button>
          <Button variant="outlined" startIcon={<DeployIcon />} onClick={handleDeploy} size="small">
            Deploy
          </Button>
          <Button variant="outlined" startIcon={<ArchiveIcon />} onClick={handleArchive} size="small">
            Archive
          </Button>
        </Box>
      </Box>

      {/* Metrics Guide Alert */}
      <Alert severity="info" icon={<InfoIcon />} sx={{ mb: 3 }}>
        <AlertTitle sx={{ fontWeight: 600 }}>Understanding Model Metrics</AlertTitle>
        <Typography variant="body2">
          Click the "Metrics Guide" button above to learn about each metric, quality thresholds, and how to judge if your model is performing well.
          Hover over metric values below to see detailed explanations.
        </Typography>
      </Alert>

      {/* Model Registry DataGrid */}
      <Paper sx={{ mb: 3 }}>
        <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Model Registry
          </Typography>
          <Typography variant="body2" color="text.secondary">
            All trained models with comprehensive metrics and management options
          </Typography>
        </Box>
        <Box sx={{ height: 400, width: '100%' }}>
          <DataGrid
            rows={mockModelVersions}
            columns={columns}
            initialState={{
              pagination: {
                paginationModel: { page: 0, pageSize: 10 },
              },
            }}
            pageSizeOptions={[5, 10, 25]}
            checkboxSelection
            disableRowSelectionOnClick
            sx={{
              border: 0,
              '& .MuiDataGrid-cell:focus': {
                outline: 'none',
              },
              '& .MuiDataGrid-row:hover': {
                bgcolor: 'action.hover',
              },
            }}
          />
        </Box>
      </Paper>

      {/* Selected Model Details */}
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
        {/* Model Metadata Card */}
        <Paper sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', mb: 3 }}>
            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
                <Typography variant="h5" sx={{ fontWeight: 600 }}>
                  {selectedModel.version}
                </Typography>
                <Chip label={selectedModel.status} color={getStatusColor(selectedModel.status)} />
                {selectedModel.status === 'active' && <Chip label="PRODUCTION" color="success" variant="outlined" size="small" />}
              </Box>
              <Typography variant="body2" color="text.secondary">
                {selectedModel.architecture} • Trained by {selectedModel.trainedBy} • {selectedModel.trainedDate}
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              {selectedModel.tags.map((tag) => (
                <Chip key={tag} label={tag} size="small" variant="outlined" />
              ))}
            </Box>
          </Box>

          <Grid container spacing={2}>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Card variant="outlined">
                <CardContent sx={{ textAlign: 'center', py: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0.5, mb: 1 }}>
                    <Typography variant="h4" sx={{ fontWeight: 700, color: 'success.main' }}>
                      {(selectedModel.accuracy * 100).toFixed(1)}%
                    </Typography>
                    <Tooltip title={metricInfo.accuracy.description}>
                      <InfoIcon fontSize="small" color="action" />
                    </Tooltip>
                  </Box>
                  <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                    Accuracy
                  </Typography>
                  <Chip
                    label={getMetricQuality(selectedModel.accuracy, 'accuracy').label}
                    size="small"
                    sx={{
                      mt: 1,
                      bgcolor: getMetricQuality(selectedModel.accuracy, 'accuracy').color,
                      color: 'white',
                      fontSize: '0.65rem',
                    }}
                  />
                </CardContent>
              </Card>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Card variant="outlined">
                <CardContent sx={{ textAlign: 'center', py: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0.5, mb: 1 }}>
                    <Typography variant="h4" sx={{ fontWeight: 700, color: 'info.main' }}>
                      {selectedModel.f1Score.toFixed(3)}
                    </Typography>
                    <Tooltip title={metricInfo.f1Score.description}>
                      <InfoIcon fontSize="small" color="action" />
                    </Tooltip>
                  </Box>
                  <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                    F1 Score
                  </Typography>
                  <Chip
                    label={getMetricQuality(selectedModel.f1Score, 'f1Score').label}
                    size="small"
                    sx={{
                      mt: 1,
                      bgcolor: getMetricQuality(selectedModel.f1Score, 'f1Score').color,
                      color: 'white',
                      fontSize: '0.65rem',
                    }}
                  />
                </CardContent>
              </Card>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Card variant="outlined">
                <CardContent sx={{ textAlign: 'center', py: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0.5, mb: 1 }}>
                    <Typography variant="h4" sx={{ fontWeight: 700, color: 'warning.main' }}>
                      {selectedModel.precision.toFixed(3)}
                    </Typography>
                    <Tooltip title={metricInfo.precision.description}>
                      <InfoIcon fontSize="small" color="action" />
                    </Tooltip>
                  </Box>
                  <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                    Precision
                  </Typography>
                  <Chip
                    label={getMetricQuality(selectedModel.precision, 'precision').label}
                    size="small"
                    sx={{
                      mt: 1,
                      bgcolor: getMetricQuality(selectedModel.precision, 'precision').color,
                      color: 'white',
                      fontSize: '0.65rem',
                    }}
                  />
                </CardContent>
              </Card>
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <Card variant="outlined">
                <CardContent sx={{ textAlign: 'center', py: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0.5, mb: 1 }}>
                    <Typography variant="h4" sx={{ fontWeight: 700, color: 'error.main' }}>
                      {selectedModel.recall.toFixed(3)}
                    </Typography>
                    <Tooltip title={metricInfo.recall.description}>
                      <InfoIcon fontSize="small" color="action" />
                    </Tooltip>
                  </Box>
                  <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontWeight: 600, display: 'block' }}>
                    Recall
                  </Typography>
                  <Chip
                    label={getMetricQuality(selectedModel.recall, 'recall').label}
                    size="small"
                    sx={{
                      mt: 1,
                      bgcolor: getMetricQuality(selectedModel.recall, 'recall').color,
                      color: 'white',
                      fontSize: '0.65rem',
                    }}
                  />
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>

        {/* Tabs for different views */}
        <Paper>
          <Tabs value={activeTab} onChange={(_, value) => setActiveTab(value)} sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tab label="Performance Metrics" icon={<MetricsIcon />} iconPosition="start" />
            <Tab label="Training Details" icon={<InfoIcon />} iconPosition="start" />
            <Tab label="Deployments" icon={<DeployIcon />} iconPosition="start" />
            <Tab label="Artifacts" icon={<CodeIcon />} iconPosition="start" />
          </Tabs>

          <Box sx={{ p: 3 }}>
            {/* Tab 0: Performance Metrics */}
            {activeTab === 0 && (
              <Grid container spacing={3}>
                {/* Learning Curves */}
                <Grid size={{ xs: 12, lg: 8 }}>
                  <Box>
                    <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                      Learning Curves
                    </Typography>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={trainingMetricsData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="epoch" label={{ value: 'Epoch', position: 'insideBottom', offset: -5 }} />
                        <YAxis label={{ value: 'Accuracy', angle: -90, position: 'insideLeft' }} />
                        <RechartsTooltip />
                        <Line type="monotone" dataKey="trainAcc" stroke="#10b981" strokeWidth={2} name="Train Accuracy" />
                        <Line type="monotone" dataKey="valAcc" stroke="#3b82f6" strokeWidth={2} name="Val Accuracy" />
                      </LineChart>
                    </ResponsiveContainer>
                  </Box>
                </Grid>

                {/* Confusion Matrix */}
                <Grid size={{ xs: 12, lg: 4 }}>
                  <Box>
                    <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                      Confusion Matrix
                    </Typography>
                    <TableContainer>
                      <Table size="small">
                        <TableHead>
                          <TableRow>           
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.7rem' }}>T \ P</TableCell>
                            {patterns.map((pattern) => (
                              <TableCell key={pattern} align="center" sx={{ fontWeight: 600, fontSize: '0.7rem' }}>
                                {pattern}
                              </TableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {patterns.map((actual) => (
                            <TableRow key={actual}>
                              <TableCell sx={{ fontWeight: 600, fontSize: '0.7rem' }}>{actual}</TableCell>
                              {patterns.map((predicted) => {
                                const value = getConfusionValue(predicted, actual);
                                const isDiagonal = actual === predicted;
                                return (
                                  <TableCell key={predicted} align="center" sx={{ p: 0.5 }}>
                                    <Box
                                      sx={{
                                        py: 1,
                                        borderRadius: 1,
                                        fontFamily: 'monospace',
                                        fontSize: '0.875rem',
                                        fontWeight: 600,
                                        bgcolor: isDiagonal ? 'success.lighter' : 'grey.100',
                                        color: isDiagonal ? 'success.dark' : 'text.secondary',
                                      }}
                                    >
                                      {value}%
                                    </Box>
                                  </TableCell>
                                );
                              })}
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Box>
                </Grid>
              </Grid>
            )}

            {/* Tab 1: Training Details */}
            {activeTab === 1 && (
              <Grid container spacing={3}>
                <Grid size={{ xs: 12, md: 6 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2, textTransform: 'uppercase', color: 'text.secondary' }}>
                    Training Configuration
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <TimerIcon fontSize="small" color="action" />
                        <Typography variant="body2" color="text.secondary">
                          Training Duration
                        </Typography>
                      </Box>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.trainingDuration}
                      </Typography>
                    </Box>
                    <Divider />
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <MemoryIcon fontSize="small" color="action" />
                        <Typography variant="body2" color="text.secondary">
                          Dataset Size
                        </Typography>
                      </Box>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.datasetSize.toLocaleString()} samples
                      </Typography>
                    </Box>
                    <Divider />
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" color="text.secondary">
                        Epochs
                      </Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.epochs}
                      </Typography>
                    </Box>
                    <Divider />
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" color="text.secondary">
                        Batch Size
                      </Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.batchSize}
                      </Typography>
                    </Box>
                    <Divider />
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" color="text.secondary">
                        Learning Rate
                      </Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600, fontFamily: 'monospace' }}>
                        {selectedModel.learningRate}
                      </Typography>
                    </Box>
                    <Divider />
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" color="text.secondary">
                        Optimizer
                      </Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.optimizer}
                      </Typography>
                    </Box>
                  </Box>
                </Grid>

                <Grid size={{ xs: 12, md: 6 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2, textTransform: 'uppercase', color: 'text.secondary' }}>
                    Model Information
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" color="text.secondary">
                        Architecture
                      </Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.architecture}
                      </Typography>
                    </Box>
                    <Divider />
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" color="text.secondary">
                        Version
                      </Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.version}
                      </Typography>
                    </Box>
                    <Divider />
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" color="text.secondary">
                        Trained By
                      </Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.trainedBy}
                      </Typography>
                    </Box>
                    <Divider />
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" color="text.secondary">
                        Trained Date
                      </Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.trainedDate}
                      </Typography>
                    </Box>
                    <Divider />
                    <Box>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                        Tags
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                        {selectedModel.tags.map((tag) => (
                          <Chip key={tag} label={tag} size="small" />
                        ))}
                      </Box>
                    </Box>
                  </Box>
                </Grid>

                {/* Loss Curves */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                    Loss Curves
                  </Typography>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={trainingMetricsData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="epoch" label={{ value: 'Epoch', position: 'insideBottom', offset: -5 }} />
                      <YAxis label={{ value: 'Loss', angle: -90, position: 'insideLeft' }} />
                      <RechartsTooltip />
                      <Line type="monotone" dataKey="trainLoss" stroke="#ef4444" strokeWidth={2} name="Train Loss" />
                      <Line type="monotone" dataKey="valLoss" stroke="#f97316" strokeWidth={2} name="Val Loss" strokeDasharray="5 5" />
                    </LineChart>
                  </ResponsiveContainer>
                </Grid>
              </Grid>
            )}

            {/* Tab 2: Deployments */}
            {activeTab === 2 && (
              <Box>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Deployment History
                </Typography>
                {selectedModel.deployments.length > 0 ? (
                  <TableContainer>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell sx={{ fontWeight: 600 }}>Environment</TableCell>
                          <TableCell sx={{ fontWeight: 600 }}>Deployed Date</TableCell>
                          <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                          <TableCell sx={{ fontWeight: 600 }}>Metrics</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {selectedModel.deployments.map((deployment, index) => (
                          <TableRow key={index}>
                            <TableCell>
                              <Chip label={deployment.environment} size="small" color="primary" variant="outlined" />
                            </TableCell>
                            <TableCell>{deployment.deployedDate}</TableCell>
                            <TableCell>
                              <Chip
                                label={deployment.status}
                                size="small"
                                color={deployment.status === 'active' ? 'success' : 'default'}
                                icon={deployment.status === 'active' ? <CheckCircleIcon /> : undefined}
                              />
                            </TableCell>
                            <TableCell>
                              <Box sx={{ display: 'flex', gap: 2 }}>
                                <Tooltip title="Average Latency">
                                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                    <SpeedIcon fontSize="small" color="action" />
                                    <Typography variant="caption">42ms</Typography>
                                  </Box>
                                </Tooltip>
                                <Tooltip title="Throughput">
                                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                    <TrendingUpIcon fontSize="small" color="success" />
                                    <Typography variant="caption">1.2K/s</Typography>
                                  </Box>
                                </Tooltip>
                              </Box>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                ) : (
                  <Alert severity="info">This model has not been deployed to any environment yet.</Alert>
                )}

                {/* Deployment Actions */}
                <Box sx={{ mt: 3 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    Deploy to Environment
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 2 }}>
                    <Button variant="outlined" startIcon={<DeployIcon />} disabled={selectedModel.status === 'active'}>
                      Deploy to Production
                    </Button>
                    <Button variant="outlined" startIcon={<DeployIcon />}>
                      Deploy to Staging
                    </Button>
                    <Button variant="outlined" startIcon={<DeployIcon />}>
                      Deploy to Development
                    </Button>
                  </Box>
                </Box>
              </Box>
            )}

            {/* Tab 3: Artifacts */}
            {activeTab === 3 && (
              <Box>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Model Artifacts
                </Typography>
                <Grid container spacing={2}>
                  <Grid size={{ xs: 12, md: 4 }}>
                    <Card variant="outlined">
                      <CardContent>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                          <CodeIcon color="primary" />
                          <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                            Model Weights
                          </Typography>
                        </Box>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2, fontFamily: 'monospace', fontSize: '0.75rem' }}>
                          {selectedModel.artifacts.modelWeights}
                        </Typography>
                        <Button
                          variant="outlined"
                          size="small"
                          startIcon={<DownloadIcon />}
                          fullWidth
                          onClick={() => handleDownload(selectedModel.artifacts.modelWeights)}
                        >
                          Download
                        </Button>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid size={{ xs: 12, md: 4 }}>
                    <Card variant="outlined">
                      <CardContent>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                          <CodeIcon color="success" />
                          <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                            ONNX Export
                          </Typography>
                        </Box>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2, fontFamily: 'monospace', fontSize: '0.75rem' }}>
                          {selectedModel.artifacts.onnxExport}
                        </Typography>
                        <Button
                          variant="outlined"
                          size="small"
                          startIcon={<DownloadIcon />}
                          fullWidth
                          onClick={() => handleDownload(selectedModel.artifacts.onnxExport)}
                        >
                          Download
                        </Button>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid size={{ xs: 12, md: 4 }}>
                    <Card variant="outlined">
                      <CardContent>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                          <CodeIcon color="warning" />
                          <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                            TensorRT Export
                          </Typography>
                        </Box>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2, fontFamily: 'monospace', fontSize: '0.75rem' }}>
                          {selectedModel.artifacts.tensorrtExport || 'Not available'}
                        </Typography>
                        <Button
                          variant="outlined"
                          size="small"
                          startIcon={<DownloadIcon />}
                          fullWidth
                          disabled={!selectedModel.artifacts.tensorrtExport}
                          onClick={() => handleDownload(selectedModel.artifacts.tensorrtExport)}
                        >
                          Download
                        </Button>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>

                <Alert severity="info" sx={{ mt: 3 }}>
                  <Typography variant="body2">
                    <strong>Note:</strong> Model artifacts are stored in the artifact registry. ONNX and TensorRT exports are optimized for
                    production inference with reduced latency.
                  </Typography>
                </Alert>
              </Box>
            )}
          </Box>
        </Paper>
      </Box>

      {/* Action Menu */}
      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
        <MenuItem onClick={handleCompare}>
          <CompareIcon fontSize="small" sx={{ mr: 1 }} />
          Compare Models
        </MenuItem>
        <MenuItem onClick={handleDeploy}>
          <DeployIcon fontSize="small" sx={{ mr: 1 }} />
          Deploy Model
        </MenuItem>
        <MenuItem onClick={handleArchive}>
          <ArchiveIcon fontSize="small" sx={{ mr: 1 }} />
          Archive Model
        </MenuItem>
        <MenuItem onClick={handleMenuClose}>
          <DownloadIcon fontSize="small" sx={{ mr: 1 }} />
          Export Report
        </MenuItem>
      </Menu>

      {/* Metrics Guide Dialog */}
      <Dialog open={helpDialogOpen} onClose={() => setHelpDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <HelpIcon color="primary" />
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Model Metrics Guide
          </Typography>
        </DialogTitle>
        <Divider />
        <DialogContent sx={{ pt: 3 }}>
          {Object.entries(metricInfo).map(([key, info]) => (
            <Box key={key} sx={{ mb: 4 }}>
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 1, color: 'primary.main' }}>
                {info.name}
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                {info.description}
              </Typography>
              <Box sx={{ bgcolor: 'grey.100', p: 2, borderRadius: 1, mb: 2 }}>
                <Typography variant="caption" sx={{ fontFamily: 'monospace', fontWeight: 600 }}>
                  Formula: {info.formula}
                </Typography>
              </Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
                Quality Thresholds:
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: '#10b981' }} />
                  <Typography variant="body2">{info.interpretation.excellent}</Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: '#3b82f6' }} />
                  <Typography variant="body2">{info.interpretation.good}</Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: '#f59e0b' }} />
                  <Typography variant="body2">{info.interpretation.fair}</Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: '#ef4444' }} />
                  <Typography variant="body2">{info.interpretation.poor}</Typography>
                </Box>
              </Box>
            </Box>
          ))}

          <Alert severity="success" sx={{ mt: 3 }}>
            <AlertTitle sx={{ fontWeight: 600 }}>How to Judge Model Quality</AlertTitle>
            <Typography variant="body2" paragraph>
              <strong>Production-Ready Model:</strong> All metrics should be in the "Excellent" or "Good" range (green/blue indicators).
            </Typography>
            <Typography variant="body2" paragraph>
              <strong>Needs Improvement:</strong> If any metric is in the "Fair" range (orange), monitor closely and consider retraining with more data or hyperparameter tuning.
            </Typography>
            <Typography variant="body2">
              <strong>Critical Issues:</strong> If any metric is in the "Poor" range (red), the model should NOT be deployed to production. Investigate data quality, model architecture, or training process.
            </Typography>
          </Alert>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setHelpDialogOpen(false)} variant="contained">
            Got It
          </Button>
        </DialogActions>
      </Dialog>

      {/* Compare Dialog */}
      <Dialog open={compareDialogOpen} onClose={() => setCompareDialogOpen(false)} maxWidth="lg" fullWidth>
        <DialogTitle>Model Comparison</DialogTitle>
        <DialogContent>
          {compareModel && (
            <Grid container spacing={3}>
              <Grid size={{ xs: 12, md: 6 }}>
                <Paper sx={{ p: 2, bgcolor: 'primary.lighter' }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    {selectedModel.version} (Selected)
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2">Accuracy:</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {(selectedModel.accuracy * 100).toFixed(2)}%
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2">F1 Score:</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.f1Score.toFixed(3)}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2">Precision:</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.precision.toFixed(3)}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2">Recall:</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.recall.toFixed(3)}
                      </Typography>
                    </Box>
                  </Box>
                </Paper>
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <Paper sx={{ p: 2, bgcolor: 'grey.100' }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    {compareModel.version} (Comparison)
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2">Accuracy:</Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {(compareModel.accuracy * 100).toFixed(2)}%
                        </Typography>
                        {compareModel.accuracy < selectedModel.accuracy ? (
                          <TrendingDownIcon fontSize="small" color="error" />
                        ) : (
                          <TrendingUpIcon fontSize="small" color="success" />
                        )}
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2">F1 Score:</Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {compareModel.f1Score.toFixed(3)}
                        </Typography>
                        {compareModel.f1Score < selectedModel.f1Score ? (
                          <TrendingDownIcon fontSize="small" color="error" />
                        ) : (
                          <TrendingUpIcon fontSize="small" color="success" />
                        )}
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2">Precision:</Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {compareModel.precision.toFixed(3)}
                        </Typography>
                        {compareModel.precision < selectedModel.precision ? (
                          <TrendingDownIcon fontSize="small" color="error" />
                        ) : (
                          <TrendingUpIcon fontSize="small" color="success" />
                        )}
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2">Recall:</Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {compareModel.recall.toFixed(3)}
                        </Typography>
                        {compareModel.recall < selectedModel.recall ? (
                          <TrendingDownIcon fontSize="small" color="error" />
                        ) : (
                          <TrendingUpIcon fontSize="small" color="success" />
                        )}
                      </Box>
                    </Box>
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCompareDialogOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
