
import React, { useState } from 'react';
import { Sparkles, Sliders, Play, Save, Info, Layers } from 'lucide-react';
import WaferCanvas from './WaferCanvas';
import { generateSyntheticWafer } from '../services/waferGenerator';
import { GANConfig, WaferData, DefectPattern } from '../types';

const GANGenerator: React.FC = () => {
  const [config, setConfig] = useState<GANConfig>({
    patternType: 'Edge',
    defectDensity: 0.1,
    noiseLevel: 0.02,
    symmetry: true
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [samples, setSamples] = useState<WaferData[]>([]);

  const handleGenerate = () => {
    setIsGenerating(true);
    // Simulate GAN latency
    setTimeout(() => {
      const newSamples = Array.from({ length: 4 }).map(() => generateSyntheticWafer(config));
      setSamples(newSamples);
      setIsGenerating(false);
    }, 1500);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">GAN-Based Data Augmentation</h2>
          <p className="text-slate-500">Synthesize realistic defect patterns to resolve data scarcity for rare failure modes.</p>
        </div>
        <div className="p-3 bg-indigo-50 rounded-2xl border border-indigo-100 flex items-center gap-3">
          <Sparkles className="w-5 h-5 text-indigo-500" />
          <span className="text-xs font-bold text-indigo-700 uppercase tracking-wider">StyleGAN-v2 Core Active</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Controls */}
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-8 h-fit">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <Sliders className="w-5 h-5 text-slate-400" />
            Generation Parameters
          </h3>

          <div className="space-y-6">
            <div>
              <label className="text-xs font-bold text-slate-400 uppercase block mb-3">Defect Template</label>
              <select 
                value={config.patternType}
                onChange={e => setConfig({...config, patternType: e.target.value as DefectPattern})}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
              >
                <option value="Edge">Edge Ring Failure</option>
                <option value="Center">Center Cluster</option>
                <option value="Scratch">Linear Scratch</option>
                <option value="Ring">Radial Ring</option>
                <option value="Cluster">Localized Cluster</option>
              </select>
            </div>

            <div>
              <div className="flex justify-between items-center mb-3">
                <label className="text-xs font-bold text-slate-400 uppercase block">Defect Density</label>
                <span className="text-xs font-bold text-emerald-600">{Math.round(config.defectDensity * 100)}%</span>
              </div>
              <input 
                type="range" min="0.01" max="0.5" step="0.01"
                value={config.defectDensity}
                onChange={e => setConfig({...config, defectDensity: parseFloat(e.target.value)})}
                className="w-full accent-emerald-500"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-3">
                <label className="text-xs font-bold text-slate-400 uppercase block">Noise Latent Variance</label>
                <span className="text-xs font-bold text-emerald-600">{Math.round(config.noiseLevel * 100)}%</span>
              </div>
              <input 
                type="range" min="0" max="0.2" step="0.01"
                value={config.noiseLevel}
                onChange={e => setConfig({...config, noiseLevel: parseFloat(e.target.value)})}
                className="w-full accent-emerald-500"
              />
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-sm font-bold text-slate-600">Preserve Symmetry</span>
              <button 
                onClick={() => setConfig({...config, symmetry: !config.symmetry})}
                className={`w-12 h-6 rounded-full transition-all relative ${config.symmetry ? 'bg-emerald-500' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${config.symmetry ? 'left-7' : 'left-1'}`} />
              </button>
            </div>
          </div>

          <button 
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-emerald-600 transition-all disabled:opacity-50 shadow-xl shadow-emerald-500/10"
          >
            {isGenerating ? <div className="w-5 h-5 border-2 border-white border-t-transparent animate-spin rounded-full" /> : <Play className="w-5 h-5 fill-white" />}
            {isGenerating ? 'Synthesizing...' : 'Trigger Latent Walk'}
          </button>
        </div>

        {/* Results */}
        <div className="lg:col-span-3 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {samples.length > 0 ? samples.map((wafer, idx) => (
              <div key={idx} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm relative group">
                <div className="flex justify-between items-center mb-4">
                  <div className="text-sm font-bold text-slate-800">Synthetic Batch 0x{idx + 1}A</div>
                  <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-2 bg-slate-100 hover:bg-emerald-50 text-slate-400 hover:text-emerald-500 rounded-lg transition-colors">
                      <Save className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div className="flex justify-center py-4">
                   <WaferCanvas wafer={wafer} size={260} />
                </div>
                <div className="mt-4 flex justify-between items-center text-[10px] font-bold uppercase tracking-widest">
                  <span className="text-slate-400">FID Score: 12.4</span>
                  <span className="text-emerald-500">Plausibility: High</span>
                </div>
              </div>
            )) : (
              <div className="col-span-2 h-96 flex flex-col items-center justify-center p-12 bg-white rounded-3xl border border-dashed border-slate-300 text-center text-slate-400">
                <Layers className="w-12 h-12 mb-4 opacity-20" />
                <p>No synthetic samples in current memory buffer.</p>
                <p className="text-sm mt-1">Adjust parameters and trigger generator to view output.</p>
              </div>
            )}
          </div>

          {samples.length > 0 && (
            <div className="bg-amber-50 p-6 rounded-3xl border border-amber-100 flex gap-4">
              <div className="p-3 bg-amber-100 rounded-2xl h-fit">
                <Info className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <h4 className="font-bold text-amber-800 mb-1">Production Guardrail Warning</h4>
                <p className="text-sm text-amber-700 leading-relaxed">
                  Synthetic data should not exceed 35% of the total training set to avoid overfitting to generator artifacts. Ensure physical plausibility review before committing to main model pipeline.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GANGenerator;
