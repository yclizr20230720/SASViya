import { useState } from 'react';
import {
  Box,
  Typography,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  Pagination,
  Menu,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
} from '@mui/material';
import {
  FilterList as FilterIcon,
  Download as DownloadIcon,
  MoreVert as MoreIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Pending as PendingIcon,
  Storage as DatabaseIcon,
  Search as SearchIcon,
} from '@mui/icons-material';
import { PATTERN_COLORS } from '../../constants/training';
import type { DefectPattern } from '../../types/training';

interface WaferRecord {
  id: string;
  lot: string;
  pattern: DefectPattern;
  density: string;
  date: string;
  status: 'Reviewed' | 'Pending' | 'Flagged';
}

const mockLibrary: WaferRecord[] = [
  { id: 'W-9901-A', lot: 'LOT-X-204', pattern: 'Edge', density: '12.4%', date: '2024-05-20 14:22', status: 'Reviewed' },
  { id: 'W-9902-A', lot: 'LOT-X-204', pattern: 'Center', density: '8.1%', date: '2024-05-20 14:23', status: 'Pending' },
  { id: 'W-9903-A', lot: 'LOT-X-204', pattern: 'None', density: '0.2%', date: '2024-05-20 14:25', status: 'Reviewed' },
  { id: 'W-4412-B', lot: 'LOT-Y-112', pattern: 'Scratch', density: '15.9%', date: '2024-05-20 12:10', status: 'Flagged' },
  { id: 'W-4413-B', lot: 'LOT-Y-112', pattern: 'None', density: '0.1%', date: '2024-05-20 12:12', status: 'Reviewed' },
  { id: 'W-4414-B', lot: 'LOT-Y-112', pattern: 'Ring', density: '6.7%', date: '2024-05-20 12:15', status: 'Reviewed' },
  { id: 'W-5501-C', lot: 'LOT-Z-089', pattern: 'Cluster', density: '10.3%', date: '2024-05-19 16:45', status: 'Pending' },
  { id: 'W-5502-C', lot: 'LOT-Z-089', pattern: 'Edge', density: '14.2%', date: '2024-05-19 16:47', status: 'Flagged' },
];

export default function WaferLibrary() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPattern, setFilterPattern] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [page, setPage] = useState(1);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const rowsPerPage = 5;

  // Filter data
  const filteredData = mockLibrary.filter((wafer) => {
    const matchesSearch =
      wafer.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wafer.lot.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPattern = filterPattern === 'all' || wafer.pattern === filterPattern;
    const matchesStatus = filterStatus === 'all' || wafer.status === filterStatus;
    return matchesSearch && matchesPattern && matchesStatus;
  });

  // Paginate data
  const paginatedData = filteredData.slice((page - 1) * rowsPerPage, page * rowsPerPage);
  const totalPages = Math.ceil(filteredData.length / rowsPerPage);

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, waferId: string) => {
    setAnchorEl(event.currentTarget);
    console.log('Opening menu for wafer:', waferId);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleExport = () => {
    console.log('Exporting CSV...');
    // TODO: Implement CSV export
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Reviewed':
        return <CheckCircleIcon fontSize="small" />;
      case 'Flagged':
        return <WarningIcon fontSize="small" />;
      case 'Pending':
        return <PendingIcon fontSize="small" />;
      default:
        return <PendingIcon fontSize="small" />;
    }
  };

  const getStatusColor = (status: string): 'success' | 'warning' | 'error' => {
    switch (status) {
      case 'Reviewed':
        return 'success';
      case 'Flagged':
        return 'error';
      case 'Pending':
        return 'warning';
      default:
        return 'warning';
    }
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 600, mb: 0.5 }}>
            Historical Wafer Library
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Browse and manage historical inspection records.
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button variant="outlined" startIcon={<FilterIcon />} size="small">
            Filter
          </Button>
          <Button variant="contained" startIcon={<DownloadIcon />} onClick={handleExport} size="small">
            Export CSV
          </Button>
        </Box>
      </Box>

      {/* Search and Filters */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <TextField
            placeholder="Search by Wafer ID or Lot ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            size="small"
            sx={{ flexGrow: 1, minWidth: 250 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" />
                </InputAdornment>
              ),
            }}
          />
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <InputLabel>Pattern</InputLabel>
            <Select value={filterPattern} label="Pattern" onChange={(e) => setFilterPattern(e.target.value)}>
              <MenuItem value="all">All Patterns</MenuItem>
              <MenuItem value="Edge">Edge</MenuItem>
              <MenuItem value="Center">Center</MenuItem>
              <MenuItem value="Scratch">Scratch</MenuItem>
              <MenuItem value="Ring">Ring</MenuItem>
              <MenuItem value="Cluster">Cluster</MenuItem>
              <MenuItem value="None">None</MenuItem>
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <InputLabel>Status</InputLabel>
            <Select value={filterStatus} label="Status" onChange={(e) => setFilterStatus(e.target.value)}>
              <MenuItem value="all">All Status</MenuItem>
              <MenuItem value="Reviewed">Reviewed</MenuItem>
              <MenuItem value="Pending">Pending</MenuItem>
              <MenuItem value="Flagged">Flagged</MenuItem>
            </Select>
          </FormControl>
        </Box>
      </Paper>

      {/* Data Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow sx={{ bgcolor: 'background.default' }}>
              <TableCell sx={{ fontWeight: 600, textTransform: 'uppercase', fontSize: '0.75rem' }}>Wafer ID</TableCell>
              <TableCell sx={{ fontWeight: 600, textTransform: 'uppercase', fontSize: '0.75rem' }}>Lot ID</TableCell>
              <TableCell sx={{ fontWeight: 600, textTransform: 'uppercase', fontSize: '0.75rem' }}>Detected Pattern</TableCell>
              <TableCell sx={{ fontWeight: 600, textTransform: 'uppercase', fontSize: '0.75rem' }}>Defect Density</TableCell>
              <TableCell sx={{ fontWeight: 600, textTransform: 'uppercase', fontSize: '0.75rem' }}>Timestamp</TableCell>
              <TableCell sx={{ fontWeight: 600, textTransform: 'uppercase', fontSize: '0.75rem' }}>Status</TableCell>
              <TableCell sx={{ fontWeight: 600, textTransform: 'uppercase', fontSize: '0.75rem' }} align="right">
                Actions
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {paginatedData.map((wafer) => (
              <TableRow
                key={wafer.id}
                sx={{
                  '&:hover': { bgcolor: 'action.hover' },
                  transition: 'background-color 0.2s',
                }}
              >
                <TableCell>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <Box
                      sx={{
                        width: 32,
                        height: 32,
                        bgcolor: 'background.default',
                        borderRadius: 1,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <DatabaseIcon fontSize="small" color="action" />
                    </Box>
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      {wafer.id}
                    </Typography>
                  </Box>
                </TableCell>
                <TableCell>
                  <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                    {wafer.lot}
                  </Typography>
                </TableCell>
                <TableCell>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Box
                      sx={{
                        width: 8,
                        height: 8,
                        borderRadius: '50%',
                        bgcolor: PATTERN_COLORS[wafer.pattern] || '#94a3b8',
                      }}
                    />
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      {wafer.pattern}
                    </Typography>
                  </Box>
                </TableCell>
                <TableCell>
                  <Typography variant="body2" sx={{ fontFamily: 'monospace' }} color="text.secondary">
                    {wafer.density}
                  </Typography>
                </TableCell>
                <TableCell>
                  <Typography variant="body2" color="text.secondary">
                    {wafer.date}
                  </Typography>
                </TableCell>
                <TableCell>
                  <Chip
                    icon={getStatusIcon(wafer.status)}
                    label={wafer.status}
                    color={getStatusColor(wafer.status)}
                    size="small"
                    sx={{ fontWeight: 600, fontSize: '0.7rem' }}
                  />
                </TableCell>
                <TableCell align="right">
                  <IconButton size="small" onClick={(e) => handleMenuOpen(e, wafer.id)}>
                    <MoreIcon fontSize="small" />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Pagination */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 3 }}>
        <Typography variant="body2" color="text.secondary">
          Showing {(page - 1) * rowsPerPage + 1}-{Math.min(page * rowsPerPage, filteredData.length)} of {filteredData.length}{' '}
          wafers
        </Typography>
        <Pagination count={totalPages} page={page} onChange={(_, value) => setPage(value)} color="primary" />
      </Box>

      {/* Action Menu */}
      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
        <MenuItem onClick={handleMenuClose}>View Details</MenuItem>
        <MenuItem onClick={handleMenuClose}>Download Report</MenuItem>
        <MenuItem onClick={handleMenuClose}>Mark as Reviewed</MenuItem>
        <MenuItem onClick={handleMenuClose}>Flag for Review</MenuItem>
        <MenuItem onClick={handleMenuClose} sx={{ color: 'error.main' }}>
          Delete
        </MenuItem>
      </Menu>
    </Box>
  );
}
