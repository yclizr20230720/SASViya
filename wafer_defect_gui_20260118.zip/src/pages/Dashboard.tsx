import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Grid,
} from '@mui/material';
import {
  Speed,
  CheckCircle,
  Warning,
  Info,
} from '@mui/icons-material';
import {
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { systemHealth, recentActivity, mockWafers } from '../mock/mockData';
import KPICard from '../components/KPICard';
import QuickActions from '../components/QuickActions';
import { useRealTimeKPI } from '../hooks/useRealTimeKPI';
import { TrendingUp } from '@mui/icons-material';

const COLORS = ['#0066CC', '#00A3A3', '#F57C00', '#388E3C', '#D32F2F', '#9C27B0'];

export default function Dashboard() {
  // Use real-time KPI hook
  const { kpiData, sparklineData } = useRealTimeKPI(5000);

  // Pattern distribution data
  const patternData = mockWafers.reduce((acc, wafer) => {
    const existing = acc.find((item) => item.name === wafer.patternType);
    if (existing) {
      existing.value += 1;
    } else {
      acc.push({ name: wafer.patternType, value: 1 });
    }
    return acc;
  }, [] as { name: string; value: number }[]);

  // Trend data
  const trendData = [
    { date: 'Mon', wafers: 42, defects: 18 },
    { date: 'Tue', wafers: 38, defects: 15 },
    { date: 'Wed', wafers: 45, defects: 22 },
    { date: 'Thu', wafers: 51, defects: 19 },
    { date: 'Fri', wafers: 48, defects: 17 },
    { date: 'Sat', wafers: 35, defects: 12 },
    { date: 'Sun', wafers: 28, defects: 9 },
  ];

  const getHealthColor = (status: string) => {
    switch (status) {
      case 'healthy':
        return 'success';
      case 'warning':
        return 'warning';
      case 'error':
        return 'error';
      default:
        return 'default';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'warning':
        return <Warning color="warning" />;
      case 'error':
        return <Warning color="error" />;
      case 'success':
        return <CheckCircle color="success" />;
      default:
        return <Info color="info" />;
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          Dashboard
        </Typography>
        <QuickActions variant="buttons" />
      </Box>

      {/* KPI Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Total Wafers Processed"
            value={kpiData.totalWafersProcessed}
            trend={kpiData.weeklyTrend}
            trendLabel="vs last week"
            icon={<TrendingUp color="success" fontSize="small" />}
            sparklineData={sparklineData.wafers}
            color="success"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Average Accuracy"
            value={kpiData.averageAccuracy.toFixed(1)}
            suffix="%"
            icon={<CheckCircle color="success" fontSize="small" />}
            sparklineData={sparklineData.accuracy}
            showProgress
            progressValue={kpiData.averageAccuracy}
            color="success"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Avg Processing Time"
            value={kpiData.averageProcessingTime.toFixed(1)}
            suffix="s"
            icon={<Speed color="primary" fontSize="small" />}
            sparklineData={sparklineData.processingTime}
            subtitle="Target: <5s per wafer"
            color="primary"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Defect Detection Rate"
            value={kpiData.defectDetectionRate.toFixed(1)}
            suffix="%"
            icon={<CheckCircle color="success" fontSize="small" />}
            sparklineData={sparklineData.detectionRate}
            showProgress
            progressValue={kpiData.defectDetectionRate}
            color="success"
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        {/* Trend Chart */}
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Weekly Processing Trend
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="wafers"
                    stroke="#0066CC"
                    strokeWidth={2}
                    name="Wafers Processed"
                  />
                  <Line
                    type="monotone"
                    dataKey="defects"
                    stroke="#F57C00"
                    strokeWidth={2}
                    name="Defects Detected"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Pattern Distribution */}
        <Grid size={{ xs: 12, lg: 4 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Pattern Distribution
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={patternData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(item) => item.name}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {patternData.map((_item, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* System Health */}
        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                System Health
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
                {Object.entries(systemHealth).map(([service, status]) => (
                  <Box
                    key={service}
                    sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
                  >
                    <Typography variant="body2" sx={{ textTransform: 'capitalize' }}>
                      {service.replace(/([A-Z])/g, ' $1').trim()}
                    </Typography>
                    <Chip
                      label={status}
                      color={getHealthColor(status)}
                      size="small"
                      sx={{ textTransform: 'capitalize' }}
                    />
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Recent Activity */}
        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Recent Activity
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
                {recentActivity.map((activity) => (
                  <Box
                    key={activity.id}
                    sx={{
                      display: 'flex',
                      gap: 2,
                      p: 1.5,
                      borderRadius: 1,
                      bgcolor: 'background.default',
                    }}
                  >
                    {getSeverityIcon(activity.severity)}
                    <Box sx={{ flex: 1 }}>
                      <Typography variant="body2">{activity.message}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {activity.timestamp}
                      </Typography>
                    </Box>
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
