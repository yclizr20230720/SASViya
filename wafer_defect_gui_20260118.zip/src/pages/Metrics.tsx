import { useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Tabs,
  Tab,
  TextField,
  InputAdornment,
  Alert,
  Chip,
  Card,
  CardContent,
} from '@mui/material';
import { Search, Warning, CheckCircle } from '@mui/icons-material';
import InteractiveMetricCard from '../components/InteractiveMetricCard';
import RecommendationsPanel from '../components/RecommendationsPanel';
import {
  metricDefinitions,
  metricCategories,
  getMetricsByCategory,
} from '../utils/metricDefinitions';
import { generateRecommendations, generateSummaryInsights } from '../utils/recommendationEngine';

// Mock current values for metrics
const mockMetricValues: Record<string, { current: number; previous: number }> = {
  defectDensity: { current: 0.42, previous: 0.38 },
  yieldRate: { current: 94.2, previous: 93.8 },
  defectRate: { current: 4.8, previous: 5.2 },
  processingTime: { current: 52, previous: 54 },
  patternRecognitionAccuracy: { current: 96.5, previous: 95.8 },
  equipmentUptime: { current: 88.2, previous: 94.1 }, // Below target - will trigger alert
  firstPassYield: { current: 97.1, previous: 96.8 },
  cycleTime: { current: 35, previous: 38 },
  overallEquipmentEffectiveness: { current: 62.5, previous: 80.3 }, // Below minimum - will trigger alert
  meanTimeBetweenFailures: { current: 450, previous: 1020 }, // Below minimum - will trigger alert
};

export default function Metrics() {
  const [activeTab, setActiveTab] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMetric, setSelectedMetric] = useState<string | null>(null);

  const categories = Object.keys(metricCategories);
  const currentCategory = categories[activeTab];

  // Filter metrics by search query
  const filterMetrics = (metrics: typeof metricDefinitions) => {
    if (!searchQuery) return Object.values(metrics);
    
    const query = searchQuery.toLowerCase();
    return Object.values(metrics).filter(
      (metric) =>
        metric.name.toLowerCase().includes(query) ||
        metric.description.toLowerCase().includes(query) ||
        metric.category.toLowerCase().includes(query)
    );
  };

  const filteredMetrics = searchQuery
    ? filterMetrics(metricDefinitions)
    : getMetricsByCategory(currentCategory);

  // Calculate alerts
  const alerts = Object.entries(mockMetricValues).filter(([id, values]) => {
    const metric = metricDefinitions[id];
    if (!metric?.industryStandard) return false;
    
    const { min, max } = metric.industryStandard;
    return (min !== undefined && values.current < min) || (max !== undefined && values.current > max);
  });

  // Generate recommendations for current category only
  const categoryMetricIds = filteredMetrics.map((m) => m.id);
  const categoryMetricContexts = Object.entries(mockMetricValues)
    .filter(([id]) => categoryMetricIds.includes(id))
    .map(([id, values]) => ({
      metricId: id,
      currentValue: values.current,
      previousValue: values.previous,
      target: metricDefinitions[id]?.industryStandard?.target,
      min: metricDefinitions[id]?.industryStandard?.min,
      max: metricDefinitions[id]?.industryStandard?.max,
    }));

  const categoryRecommendations = generateRecommendations(categoryMetricContexts);
  const categoryInsights = generateSummaryInsights(categoryMetricContexts);

  const handleRelatedMetricClick = (metricId: string) => {
    setSelectedMetric(metricId);
    // Scroll to the metric card
    const element = document.getElementById(`metric-${metricId}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 1, fontWeight: 600 }}>
        Metrics & KPIs
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
        Comprehensive metrics library with detailed explanations and industry benchmarks
      </Typography>

      {/* Alerts Summary */}
      {alerts.length > 0 && (
        <Alert
          severity="warning"
          icon={<Warning />}
          sx={{ mb: 3 }}
          action={
            <Chip
              label={`${alerts.length} Alert${alerts.length > 1 ? 's' : ''}`}
              color="warning"
              size="small"
            />
          }
        >
          <Typography variant="body2" sx={{ fontWeight: 600 }}>
            {alerts.length} metric{alerts.length > 1 ? 's' : ''} outside threshold
          </Typography>
          <Typography variant="caption">
            {alerts.map(([id]) => metricDefinitions[id].name).join(', ')}
          </Typography>
        </Alert>
      )}

      {/* Search Bar */}
      <TextField
        fullWidth
        placeholder="Search metrics by name, description, or category..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        sx={{ mb: 3 }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Search />
            </InputAdornment>
          ),
        }}
      />

      {/* Category Tabs */}
      {!searchQuery && (
        <Tabs
          value={activeTab}
          onChange={(_, newValue) => setActiveTab(newValue)}
          sx={{ mb: 3, borderBottom: 1, borderColor: 'divider' }}
        >
          {categories.map((category) => (
            <Tab
              key={category}
              label={metricCategories[category as keyof typeof metricCategories].name}
            />
          ))}
        </Tabs>
      )}

      {/* Category Recommendations - Show only for current category */}
      {!searchQuery && categoryRecommendations.length > 0 && (
        <Box sx={{ mb: 4 }}>
          <RecommendationsPanel
            recommendations={categoryRecommendations}
            overallHealth={categoryInsights.overallHealth}
            keyFindings={categoryInsights.keyFindings}
            topPriorities={categoryInsights.topPriorities}
          />
        </Box>
      )}

      {/* Metrics Grid */}
      <Grid container spacing={3}>
        {filteredMetrics.map((metric) => {
          const values = mockMetricValues[metric.id];
          if (!values) return null;

          return (
            <Grid key={metric.id} size={{ xs: 12, md: 6, lg: 4 }} id={`metric-${metric.id}`}>
              <Box
                sx={{
                  outline: selectedMetric === metric.id ? 3 : 0,
                  outlineColor: 'primary.main',
                  outlineOffset: 4,
                  borderRadius: 1,
                  transition: 'outline 0.3s',
                }}
              >
                <InteractiveMetricCard
                  metric={metric}
                  currentValue={values.current}
                  previousValue={values.previous}
                  benchmark={
                    metric.industryStandard?.benchmark
                      ? {
                          value: metric.industryStandard.target || 0,
                          label: 'Industry Target',
                        }
                      : undefined
                  }
                  onRelatedMetricClick={handleRelatedMetricClick}
                />
              </Box>
            </Grid>
          );
        })}
      </Grid>

      {/* No Results */}
      {filteredMetrics.length === 0 && (
        <Card>
          <CardContent sx={{ textAlign: 'center', py: 6 }}>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No metrics found
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Try adjusting your search query
            </Typography>
          </CardContent>
        </Card>
      )}

      {/* Summary Statistics */}
      <Box sx={{ mt: 4, p: 3, bgcolor: 'background.default', borderRadius: 2 }}>
        <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
          Metrics Summary
        </Typography>
        <Grid container spacing={2}>
          <Grid size={{ xs: 6, sm: 3 }}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Total Metrics
              </Typography>
              <Typography variant="h5" sx={{ fontWeight: 600 }}>
                {Object.keys(metricDefinitions).length}
              </Typography>
            </Box>
          </Grid>
          <Grid size={{ xs: 6, sm: 3 }}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Within Target
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <CheckCircle fontSize="small" color="success" />
                <Typography variant="h5" sx={{ fontWeight: 600, color: 'success.main' }}>
                  {Object.keys(mockMetricValues).length - alerts.length}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid size={{ xs: 6, sm: 3 }}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Alerts
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Warning fontSize="small" color="warning" />
                <Typography variant="h5" sx={{ fontWeight: 600, color: 'warning.main' }}>
                  {alerts.length}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid size={{ xs: 6, sm: 3 }}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Categories
              </Typography>
              <Typography variant="h5" sx={{ fontWeight: 600 }}>
                {categories.length}
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
}
