import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  InputAdornment,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  TableSortLabel,
  Chip,
  IconButton,
  Menu,
  MenuItem,
} from '@mui/material';
import {
  Search,
  MoreVert,
  Visibility,
  CloudUpload,
  Delete,
  FilterList,
} from '@mui/icons-material';
import { mockWafers } from '../mock/mockData';

type Order = 'asc' | 'desc';
type OrderBy = 'waferId' | 'lotId' | 'timestamp' | 'defectCount' | 'status';

export default function History() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [order, setOrder] = useState<Order>('desc');
  const [orderBy, setOrderBy] = useState<OrderBy>('timestamp');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedWafer, setSelectedWafer] = useState<string | null>(null);

  const handleSort = (property: OrderBy) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, waferId: string) => {
    setAnchorEl(event.currentTarget);
    setSelectedWafer(waferId);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedWafer(null);
  };

  const handleView = (waferId: string) => {
    navigate(`/analysis/${waferId}`);
    handleMenuClose();
  };

  const handleReupload = (waferId: string) => {
    console.log('Reupload:', waferId);
    handleMenuClose();
  };

  const handleDelete = (waferId: string) => {
    console.log('Delete:', waferId);
    handleMenuClose();
  };

  // Filter and sort data
  const filteredWafers = mockWafers.filter(
    (wafer) =>
      wafer.waferId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wafer.lotId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wafer.processStep.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedWafers = [...filteredWafers].sort((a, b) => {
    let aValue: any = a[orderBy];
    let bValue: any = b[orderBy];

    if (orderBy === 'timestamp') {
      aValue = new Date(aValue).getTime();
      bValue = new Date(bValue).getTime();
    }

    if (order === 'asc') {
      return aValue < bValue ? -1 : 1;
    } else {
      return aValue > bValue ? -1 : 1;
    }
  });

  const paginatedWafers = sortedWafers.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'success';
      case 'processing':
        return 'info';
      case 'error':
        return 'error';
      default:
        return 'default';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          Upload History
        </Typography>
        <IconButton>
          <FilterList />
        </IconButton>
      </Box>

      <Card>
        <CardContent>
          <TextField
            fullWidth
            placeholder="Search by Wafer ID, Lot ID, or Process Step..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
            sx={{ mb: 3 }}
          />

          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>
                    <TableSortLabel
                      active={orderBy === 'waferId'}
                      direction={orderBy === 'waferId' ? order : 'asc'}
                      onClick={() => handleSort('waferId')}
                    >
                      Wafer ID
                    </TableSortLabel>
                  </TableCell>
                  <TableCell>
                    <TableSortLabel
                      active={orderBy === 'lotId'}
                      direction={orderBy === 'lotId' ? order : 'asc'}
                      onClick={() => handleSort('lotId')}
                    >
                      Lot ID
                    </TableSortLabel>
                  </TableCell>
                  <TableCell>Process Step</TableCell>
                  <TableCell>Equipment</TableCell>
                  <TableCell>
                    <TableSortLabel
                      active={orderBy === 'timestamp'}
                      direction={orderBy === 'timestamp' ? order : 'asc'}
                      onClick={() => handleSort('timestamp')}
                    >
                      Upload Time
                    </TableSortLabel>
                  </TableCell>
                  <TableCell align="right">
                    <TableSortLabel
                      active={orderBy === 'defectCount'}
                      direction={orderBy === 'defectCount' ? order : 'asc'}
                      onClick={() => handleSort('defectCount')}
                    >
                      Defects
                    </TableSortLabel>
                  </TableCell>
                  <TableCell>
                    <TableSortLabel
                      active={orderBy === 'status'}
                      direction={orderBy === 'status' ? order : 'asc'}
                      onClick={() => handleSort('status')}
                    >
                      Status
                    </TableSortLabel>
                  </TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedWafers.map((wafer) => (
                  <TableRow
                    key={wafer.id}
                    hover
                    sx={{ cursor: 'pointer' }}
                    onClick={() => navigate(`/analysis/${wafer.waferId}`)}
                  >
                    <TableCell>
                      <Typography variant="body2" fontWeight={600}>
                        {wafer.waferId}
                      </Typography>
                    </TableCell>
                    <TableCell>{wafer.lotId}</TableCell>
                    <TableCell>{wafer.processStep}</TableCell>
                    <TableCell>{wafer.equipmentId}</TableCell>
                    <TableCell>{formatDate(wafer.timestamp)}</TableCell>
                    <TableCell align="right">
                      <Chip
                        label={wafer.defectCount}
                        size="small"
                        color={wafer.defectCount > 50 ? 'error' : 'default'}
                      />
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={wafer.status}
                        size="small"
                        color={getStatusColor(wafer.status)}
                        sx={{ textTransform: 'capitalize' }}
                      />
                    </TableCell>
                    <TableCell align="right" onClick={(e) => e.stopPropagation()}>
                      <IconButton
                        size="small"
                        onClick={(e) => handleMenuOpen(e, wafer.waferId)}
                      >
                        <MoreVert />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <TablePagination
            rowsPerPageOptions={[5, 10, 25, 50]}
            component="div"
            count={sortedWafers.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={(_, newPage) => setPage(newPage)}
            onRowsPerPageChange={(e) => {
              setRowsPerPage(parseInt(e.target.value, 10));
              setPage(0);
            }}
          />
        </CardContent>
      </Card>

      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
        <MenuItem onClick={() => selectedWafer && handleView(selectedWafer)}>
          <Visibility fontSize="small" sx={{ mr: 1 }} />
          View Analysis
        </MenuItem>
        <MenuItem onClick={() => selectedWafer && handleReupload(selectedWafer)}>
          <CloudUpload fontSize="small" sx={{ mr: 1 }} />
          Re-upload
        </MenuItem>
        <MenuItem onClick={() => selectedWafer && handleDelete(selectedWafer)}>
          <Delete fontSize="small" sx={{ mr: 1 }} />
          Delete
        </MenuItem>
      </Menu>
    </Box>
  );
}
