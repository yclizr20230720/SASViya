/**
 * Google Gemini AI service for wafer pattern analysis
 * Provides AI-powered defect pattern classification and root cause analysis
 */

import { GoogleGenAI, Type } from '@google/genai';
import type { AnalysisResult, WaferData } from '../types/training';

// API key from environment variables
const API_KEY = import.meta.env.VITE_GEMINI_API_KEY || '';

/**
 * Mock analysis results for development/testing when API key is not available
 * Provides realistic responses for each defect pattern type
 */
const MOCK_ANALYSES: Record<string, AnalysisResult> = {
  'Edge': {
    pattern: 'Edge',
    confidence: 0.98,
    rootCause: 'CMP (Chemical Mechanical Polishing) pad wear or Edge Exclusion Ring misalignment.',
    explanation: 'The defect distribution is heavily concentrated on the outer 5mm of the wafer. This typically indicates a mechanical issue during planarization or a failure in the edge bead removal fluid dynamics. Recommend inspecting CMP pad condition and verifying edge ring alignment.',
    featureImportance: [
      { feature: 'Edge Density', score: 0.92 },
      { feature: 'Radial Distribution', score: 0.85 },
      { feature: 'Pattern Symmetry', score: 0.73 }
    ]
  },
  'Center': {
    pattern: 'Center',
    confidence: 0.95,
    rootCause: 'CVD (Chemical Vapor Deposition) nozzle obstruction or localized thermal hot-spot.',
    explanation: 'High defect density at the wafer center suggests a stagnation point in the process gas flow or a non-uniformity in the heating element beneath the wafer chuck. This pattern is characteristic of CVD process issues. Recommend checking gas flow distribution and heater calibration.',
    featureImportance: [
      { feature: 'Center Density', score: 0.94 },
      { feature: 'Radial Gradient', score: 0.88 },
      { feature: 'Thermal Profile', score: 0.81 }
    ]
  },
  'Scratch': {
    pattern: 'Scratch',
    confidence: 0.99,
    rootCause: 'Wafer handling robotic end-effector malfunction or particle on transport rail.',
    explanation: 'The linear nature of the defect cluster across multiple die rows is a classic signature of mechanical abrasion during transfer between process modules. This indicates a physical contact event during wafer handling. Immediate inspection of robotic handling equipment and transport rails is recommended.',
    featureImportance: [
      { feature: 'Linear Pattern', score: 0.97 },
      { feature: 'Directional Consistency', score: 0.95 },
      { feature: 'Width Uniformity', score: 0.89 }
    ]
  },
  'Ring': {
    pattern: 'Ring',
    confidence: 0.92,
    rootCause: 'Photoresist viscosity fluctuation or spin-coater acceleration drift.',
    explanation: 'A concentric ring pattern suggests radial dependency in the coating thickness or drying rate, leading to systematic lithography failures at specific radii. This is typically caused by spin coating process variations. Verify photoresist viscosity and spin coater calibration.',
    featureImportance: [
      { feature: 'Radial Periodicity', score: 0.91 },
      { feature: 'Ring Width', score: 0.87 },
      { feature: 'Concentric Symmetry', score: 0.84 }
    ]
  },
  'Cluster': {
    pattern: 'Cluster',
    confidence: 0.94,
    rootCause: 'Micro-particle contamination in the load-lock or localized focus shift.',
    explanation: 'A dense, localized grouping of defects often points to a single event of particle contamination or a localized topographical defect on the reticle/wafer interface. This suggests a contamination event or equipment issue at a specific location. Recommend cleanroom audit and reticle inspection.',
    featureImportance: [
      { feature: 'Spatial Clustering', score: 0.93 },
      { feature: 'Defect Density', score: 0.89 },
      { feature: 'Cluster Compactness', score: 0.86 }
    ]
  },
  'Random': {
    pattern: 'Random',
    confidence: 0.88,
    rootCause: 'Baseline environmental particles or normal process variation.',
    explanation: 'No systematic pattern detected. Defects follow a Poisson distribution consistent with cleanroom baseline levels. This indicates normal process variation within acceptable limits. Continue monitoring for any trend changes.',
    featureImportance: [
      { feature: 'Spatial Randomness', score: 0.87 },
      { feature: 'Uniform Distribution', score: 0.82 },
      { feature: 'Low Density', score: 0.79 }
    ]
  },
  'Unknown': {
    pattern: 'Unknown',
    confidence: 0.65,
    rootCause: 'Uncharacterized defect pattern requiring further investigation.',
    explanation: 'The defect pattern does not match known failure modes. This may indicate a new process issue, equipment drift, or novel failure mechanism. Recommend detailed failure analysis and correlation with recent process changes.',
    featureImportance: [
      { feature: 'Pattern Complexity', score: 0.71 },
      { feature: 'Spatial Irregularity', score: 0.68 },
      { feature: 'Multi-modal Distribution', score: 0.62 }
    ]
  }
};

/**
 * Analyze wafer pattern using Google Gemini AI
 * Falls back to mock analysis if API key is not configured
 * 
 * @param wafer - Wafer data to analyze
 * @returns Analysis result with pattern classification and root cause
 * @throws Error if API call fails and no mock data available
 */
export const analyzeWaferPattern = async (wafer: WaferData): Promise<AnalysisResult> => {
  // Use mock analysis if no API key is configured
  if (!API_KEY) {
    console.info('Gemini API key not configured, using mock analysis');
    
    // Simulate realistic API delay
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    const hint = wafer.detectedPattern || 'Unknown';
    return MOCK_ANALYSES[hint] || MOCK_ANALYSES['Random'];
  }

  try {
    // Initialize Gemini AI client
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    
    // Calculate wafer statistics
    const defectCount = wafer.dies.filter(d => d.status === 'Defect').length;
    const totalDies = wafer.dies.length;
    const density = (defectCount / totalDies * 100).toFixed(2);

    // Construct analysis prompt
    const prompt = `
      Analyze this semiconductor wafer defect data:
      
      Wafer ID: ${wafer.id}
      Lot ID: ${wafer.lotId}
      Defect Density: ${density}%
      Grid Size: ${wafer.gridSize}x${wafer.gridSize}
      Total Dies: ${totalDies}
      Defective Dies: ${defectCount}
      Pattern Hint: ${wafer.detectedPattern || 'Unknown'}
      
      Provide a professional yield engineering analysis:
      1. Classify the defect pattern (Edge, Center, Scratch, Ring, Cluster, Random, or Unknown)
      2. Provide a confidence score between 0 and 1
      3. Suggest the most likely root cause in the fabrication process
      4. Explain your reasoning with technical details
      
      Consider spatial distribution, defect density, and pattern characteristics.
    `;

    // Call Gemini API with structured output
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            pattern: { type: Type.STRING },
            confidence: { type: Type.NUMBER },
            rootCause: { type: Type.STRING },
            explanation: { type: Type.STRING }
          },
          required: ['pattern', 'confidence', 'rootCause', 'explanation']
        }
      }
    });

    // Parse and return the analysis result
    const responseText = response.text?.trim() || '{}';
    const result = JSON.parse(responseText) as AnalysisResult;
    
    // Add feature importance (would come from model in production)
    result.featureImportance = generateFeatureImportance(result.pattern);
    
    return result;
    
  } catch (error) {
    console.error('Gemini Analysis Error:', error);
    
    // Fall back to mock analysis on error
    console.warn('Falling back to mock analysis due to API error');
    const hint = wafer.detectedPattern || 'Unknown';
    return MOCK_ANALYSES[hint] || MOCK_ANALYSES['Random'];
  }
};

/**
 * Generate feature importance scores based on pattern type
 * In production, this would come from the actual model
 * 
 * @param pattern - Detected pattern type
 * @returns Array of feature importance scores
 */
const generateFeatureImportance = (pattern: string): { feature: string; score: number }[] => {
  const mockData = MOCK_ANALYSES[pattern];
  return mockData?.featureImportance || [
    { feature: 'Spatial Distribution', score: 0.85 },
    { feature: 'Defect Density', score: 0.78 },
    { feature: 'Pattern Symmetry', score: 0.72 }
  ];
};

/**
 * Batch analyze multiple wafers
 * 
 * @param wafers - Array of wafers to analyze
 * @param onProgress - Optional progress callback
 * @returns Array of analysis results
 */
export const analyzeWaferBatch = async (
  wafers: WaferData[],
  onProgress?: (completed: number, total: number) => void
): Promise<AnalysisResult[]> => {
  const results: AnalysisResult[] = [];
  
  for (let i = 0; i < wafers.length; i++) {
    try {
      const result = await analyzeWaferPattern(wafers[i]);
      results.push(result);
      
      if (onProgress) {
        onProgress(i + 1, wafers.length);
      }
    } catch (error) {
      console.error(`Failed to analyze wafer ${wafers[i].id}:`, error);
      // Continue with next wafer
    }
  }
  
  return results;
};

/**
 * Validate Gemini API key
 * 
 * @returns True if API key is configured and valid
 */
export const validateApiKey = async (): Promise<boolean> => {
  if (!API_KEY) {
    return false;
  }

  try {
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    
    // Make a simple test call
    await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: 'Test connection',
      config: {
        maxOutputTokens: 10
      }
    });
    
    return true;
  } catch (error) {
    console.error('API key validation failed:', error);
    return false;
  }
};

/**
 * Get available Gemini models
 * 
 * @returns List of available models
 */
export const getAvailableModels = (): string[] => {
  return [
    'gemini-3-flash-preview',
    'gemini-2.0-flash-exp',
    'gemini-1.5-pro',
    'gemini-1.5-flash'
  ];
};
