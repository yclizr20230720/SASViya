/**
 * Wafer generation service for synthetic data creation
 * Generates realistic wafer maps with various defect patterns for training
 */

import type { WaferData, Die, DefectPattern, GANConfig } from '../types/training';

/**
 * Generate a synthetic wafer with specified defect pattern
 * 
 * @param id - Unique identifier for the wafer
 * @param pattern - Type of defect pattern to generate
 * @param density - Defect density (0-1), controls how many defects appear
 * @param gridSize - Size of the die grid (NxN)
 * @returns Complete wafer data structure with dies and defects
 */
export const generateWafer = (
  id: string, 
  pattern: DefectPattern = 'None', 
  density: number = 0.05,
  gridSize: number = 40
): WaferData => {
  const dies: Die[] = [];
  const radius = gridSize / 2;
  const centerX = radius;
  const centerY = radius;

  // Generate dies in a circular wafer pattern
  for (let x = 0; x < gridSize; x++) {
    for (let y = 0; y < gridSize; y++) {
      // Check if die is within circular wafer boundary
      const dist = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2));
      
      if (dist <= radius) {
        // Base random noise (1% baseline defect rate)
        let isDefect = Math.random() < 0.01;

        // Apply pattern-specific defect logic
        switch (pattern) {
          case 'Center':
            // Defects concentrated in center 30% of wafer
            if (dist < radius * 0.3) {
              isDefect = isDefect || Math.random() < density * 5;
            }
            break;

          case 'Edge':
            // Defects concentrated in outer 20% of wafer
            if (dist > radius * 0.8) {
              isDefect = isDefect || Math.random() < density * 4;
            }
            break;

          case 'Ring':
            // Defects in concentric ring pattern
            if (dist > radius * 0.5 && dist < radius * 0.65) {
              isDefect = isDefect || Math.random() < density * 6;
            }
            break;

          case 'Scratch':
            // Linear scratch pattern across wafer
            const lineY = x * 0.8 + 5;
            if (Math.abs(y - lineY) < 1.5) {
              isDefect = isDefect || Math.random() < density * 8;
            }
            break;

          case 'Cluster':
            // Localized cluster of defects
            const clusterX = radius * 1.2;
            const clusterY = radius * 0.8;
            const distToCluster = Math.sqrt(
              Math.pow(x - clusterX, 2) + Math.pow(y - clusterY, 2)
            );
            if (distToCluster < 5) {
              isDefect = isDefect || Math.random() < density * 10;
            }
            break;

          case 'Random':
            // Random defect distribution
            isDefect = isDefect || Math.random() < density;
            break;

          case 'None':
          case 'Unknown':
          default:
            // Keep only baseline noise
            break;
        }

        // Create die with appropriate status and bin code
        dies.push({
          x,
          y,
          status: isDefect ? 'Defect' : 'Good',
          binCode: isDefect ? Math.floor(Math.random() * 5) + 1 : 0
        });
      }
    }
  }

  return {
    id,
    lotId: `LOT-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
    timestamp: new Date().toISOString(),
    dies,
    diameter: 300, // Default 300mm wafer
    gridSize,
    detectedPattern: pattern,
    confidence: pattern !== 'None' ? 0.85 + Math.random() * 0.15 : undefined
  };
};

/**
 * Generate synthetic wafer using GAN configuration
 * 
 * @param config - GAN configuration parameters
 * @returns Synthetic wafer data
 */
export const generateSyntheticWafer = (config: GANConfig): WaferData => {
  const id = `SYNTH-${Math.random().toString(36).substring(2, 11).toUpperCase()}`;
  
  let wafer = generateWafer(
    id,
    config.patternType,
    config.defectDensity,
    40 // Default grid size
  );

  // Apply noise level to simulate realistic variation
  if (config.noiseLevel > 0) {
    wafer = applyNoise(wafer, config.noiseLevel);
  }

  // Apply symmetry if requested
  if (config.symmetry) {
    wafer = applySymmetry(wafer);
  }

  return wafer;
};

/**
 * Apply noise to wafer data for realistic variation
 * 
 * @param wafer - Original wafer data
 * @param noiseLevel - Amount of noise to apply (0-1)
 * @returns Wafer with applied noise
 */
const applyNoise = (wafer: WaferData, noiseLevel: number): WaferData => {
  const noisyDies = wafer.dies.map(die => {
    // Randomly flip some die statuses based on noise level
    if (Math.random() < noiseLevel * 0.1) {
      return {
        ...die,
        status: die.status === 'Good' ? 'Defect' : 'Good',
        binCode: die.status === 'Good' ? Math.floor(Math.random() * 5) + 1 : 0
      } as Die;
    }
    return die;
  });

  return {
    ...wafer,
    dies: noisyDies
  };
};

/**
 * Apply symmetry to wafer defect pattern
 * 
 * @param wafer - Original wafer data
 * @returns Wafer with symmetric defect pattern
 */
const applySymmetry = (wafer: WaferData): WaferData => {
  const centerX = wafer.gridSize / 2;
  const centerY = wafer.gridSize / 2;

  // Create a map of defect positions
  const defectMap = new Map<string, Die>();
  wafer.dies.forEach(die => {
    if (die.status === 'Defect') {
      defectMap.set(`${die.x},${die.y}`, die);
    }
  });

  // Apply 4-way symmetry
  const symmetricDies = wafer.dies.map(die => {
    const mirrorX = Math.round(2 * centerX - die.x);
    const mirrorY = Math.round(2 * centerY - die.y);
    
    // Check if mirrored position has a defect
    const hasMirrorDefect = 
      defectMap.has(`${mirrorX},${die.y}`) ||
      defectMap.has(`${die.x},${mirrorY}`) ||
      defectMap.has(`${mirrorX},${mirrorY}`);

    if (hasMirrorDefect && die.status === 'Good') {
      return {
        ...die,
        status: 'Defect' as const,
        binCode: Math.floor(Math.random() * 5) + 1
      };
    }

    return die;
  });

  return {
    ...wafer,
    dies: symmetricDies
  };
};

/**
 * Calculate defect statistics for a wafer
 * 
 * @param wafer - Wafer data to analyze
 * @returns Statistics object with defect metrics
 */
export const calculateWaferStats = (wafer: WaferData) => {
  const totalDies = wafer.dies.length;
  const defectDies = wafer.dies.filter(d => d.status === 'Defect').length;
  const goodDies = totalDies - defectDies;

  return {
    totalDies,
    defectDies,
    goodDies,
    defectRate: (defectDies / totalDies) * 100,
    yield: (goodDies / totalDies) * 100,
    binDistribution: calculateBinDistribution(wafer.dies)
  };
};

/**
 * Calculate bin code distribution
 * 
 * @param dies - Array of dies
 * @returns Distribution of bin codes
 */
const calculateBinDistribution = (dies: Die[]): Record<number, number> => {
  const distribution: Record<number, number> = {};
  
  dies.forEach(die => {
    const bin = die.binCode ?? 0;
    distribution[bin] = (distribution[bin] || 0) + 1;
  });

  return distribution;
};

/**
 * Generate batch of synthetic wafers
 * 
 * @param count - Number of wafers to generate
 * @param config - GAN configuration
 * @returns Array of synthetic wafers
 */
export const generateWaferBatch = (
  count: number,
  config: GANConfig
): WaferData[] => {
  const wafers: WaferData[] = [];
  
  for (let i = 0; i < count; i++) {
    wafers.push(generateSyntheticWafer(config));
  }

  return wafers;
};
