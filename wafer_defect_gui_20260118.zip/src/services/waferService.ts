import apiClient from './api';
import type {
    WaferMapUploadRequest,
    WaferMapResponse,
    PredictionRequest,
    PredictionResponse,
    FeedbackRequest,
    FeedbackResponse,
    AnalyticsResponse,
    PaginatedResponse,
} from '../types/api';

export const waferService = {
    // Upload wafer map
    uploadWaferMap: async (data: WaferMapUploadRequest): Promise<WaferMapResponse> => {
        const formData = new FormData();
        formData.append('file', data.file);
        formData.append('waferId', data.waferId);
        formData.append('lotId', data.lotId);
        formData.append('processStep', data.processStep);
        formData.append('equipmentId', data.equipmentId);
        if (data.metadata) {
            formData.append('metadata', JSON.stringify(data.metadata));
        }

        const response = await apiClient.post<WaferMapResponse>('/wafer-maps', formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
        return response.data;
    },

    // Get wafer map by ID
    getWaferMap: async (id: string): Promise<WaferMapResponse> => {
        const response = await apiClient.get<WaferMapResponse>(`/wafer-maps/${id}`);
        return response.data;
    },

    // Get all wafer maps with pagination
    getWaferMaps: async (page = 1, pageSize = 20): Promise<PaginatedResponse<WaferMapResponse>> => {
        const response = await apiClient.get<PaginatedResponse<WaferMapResponse>>('/wafer-maps', {
            params: { page, pageSize },
        });
        return response.data;
    },

    // Delete wafer map
    deleteWaferMap: async (id: string): Promise<void> => {
        await apiClient.delete(`/wafer-maps/${id}`);
    },

    // Get prediction for wafer
    getPrediction: async (request: PredictionRequest): Promise<PredictionResponse> => {
        const response = await apiClient.post<PredictionResponse>('/predictions', request);
        return response.data;
    },

    // Get prediction by ID
    getPredictionById: async (id: string): Promise<PredictionResponse> => {
        const response = await apiClient.get<PredictionResponse>(`/predictions/${id}`);
        return response.data;
    },

    // Submit feedback
    submitFeedback: async (feedback: FeedbackRequest): Promise<FeedbackResponse> => {
        const response = await apiClient.post<FeedbackResponse>('/feedback', feedback);
        return response.data;
    },

    // Get analytics data
    getAnalytics: async (startDate?: string, endDate?: string): Promise<AnalyticsResponse> => {
        const response = await apiClient.get<AnalyticsResponse>('/analytics', {
            params: { startDate, endDate },
        });
        return response.data;
    },

    // Get similar wafer cases
    getSimilarCases: async (waferId: string, topK = 5): Promise<WaferMapResponse[]> => {
        const response = await apiClient.get<WaferMapResponse[]>(`/wafer-maps/${waferId}/similar`, {
            params: { topK },
        });
        return response.data;
    },
};
