// Report types and interfaces

export type ReportType = 'daily-summary' | 'pattern-analysis' | 'yield-report' | 'custom';

export type ReportWidgetType = 
  | 'chart' 
  | 'table' 
  | 'wafer-map' 
  | 'metric' 
  | 'text' 
  | 'image';

export interface ReportWidget {
  id: string;
  type: ReportWidgetType;
  title: string;
  config: Record<string, any>;
  position: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export interface ReportTemplate {
  id: string;
  name: string;
  description: string;
  type: ReportType;
  widgets: ReportWidget[];
  layout: 'grid' | 'flow';
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  isDefault: boolean;
}

export interface ReportSchedule {
  id: string;
  templateId: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'custom';
  time: string;
  recipients: string[];
  enabled: boolean;
  lastRun?: string;
  nextRun: string;
}

export interface GeneratedReport {
  id: string;
  templateId: string;
  name: string;
  generatedAt: string;
  generatedBy: string;
  data: any;
  format: 'pdf' | 'pptx' | 'html';
  url?: string;
}
