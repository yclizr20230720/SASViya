// Wafer Map Types
export interface WaferMapUploadRequest {
  file: File;
  waferId: string;
  lotId: string;
  processStep: string;
  equipmentId: string;
  metadata?: Record<string, any>;
}

export interface WaferMapResponse {
  id: string;
  waferId: string;
  lotId: string;
  processStep: string;
  equipmentId: string;
  timestamp: string;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  imageUrl?: string;
}

// Prediction Types
export interface PredictionRequest {
  waferId: string;
  explain?: boolean;
}

export interface PredictionResponse {
  id: string;
  waferId: string;
  patternClass: string;
  patternConfidence: number;
  rootCauseClass: string;
  rootCauseConfidence: number;
  processingTimeMs: number;
  timestamp: string;
  explanation?: {
    heatmapUrl?: string;
    shapValues?: Record<string, number>;
    narrative?: string;
  };
}

// Feedback Types
export interface FeedbackRequest {
  predictionId: string;
  correctPattern?: string;
  correctRootCause?: string;
  comments: string;
  rating?: number;
}

export interface FeedbackResponse {
  id: string;
  predictionId: string;
  userId: string;
  timestamp: string;
  status: 'submitted' | 'reviewed' | 'incorporated';
}

// Analytics Types
export interface AnalyticsResponse {
  totalWafers: number;
  averageAccuracy: number;
  averageProcessingTime: number;
  defectDetectionRate: number;
  patternDistribution: Record<string, number>;
  trendData: {
    date: string;
    count: number;
    accuracy: number;
  }[];
}

// Pagination
export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// Error Response
export interface ApiError {
  message: string;
  code: string;
  details?: Record<string, any>;
}
