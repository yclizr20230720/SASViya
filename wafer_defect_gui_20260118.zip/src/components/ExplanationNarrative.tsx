import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Alert,
  Chip,
} from '@mui/material';
import { Psychology, Science, Info } from '@mui/icons-material';

interface ExplanationNarrativeProps {
  patternClass: string;
  patternConfidence: number;
  rootCauseClass: string;
  rootCauseConfidence: number;
  shapValues: Record<string, number>;
  defectCount: number;
  defectDensity: number;
  processStep: string;
  equipmentId: string;
}

type ExplanationMode = 'technical' | 'non-technical';

export default function ExplanationNarrative({
  patternClass,
  patternConfidence,
  rootCauseClass,
  rootCauseConfidence,
  shapValues,
  defectCount,
  defectDensity,
  processStep,
  equipmentId,
}: ExplanationNarrativeProps) {
  const [mode, setMode] = useState<ExplanationMode>('non-technical');

  // Get top contributing features
  const topFeatures = Object.entries(shapValues)
    .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
    .slice(0, 3);

  const generateNonTechnicalExplanation = () => {
    const steps = [
      {
        label: 'Pattern Detection',
        description: `The AI system analyzed the wafer map and identified a ${patternClass.toLowerCase()} pattern with ${(patternConfidence * 100).toFixed(1)}% confidence.`,
        details: `This pattern was detected by examining the spatial distribution of ${defectCount} defects across the wafer surface. The defect density of ${(defectDensity * 100).toFixed(2)}% indicates ${defectDensity > 0.05 ? 'elevated' : 'normal'} defect levels.`,
      },
      {
        label: 'Key Factors',
        description: `The classification was primarily influenced by three key factors:`,
        details: topFeatures
          .map(
            ([feature, value]) =>
              `• ${feature}: ${value > 0 ? 'Strongly supported' : 'Contradicted'} the classification (impact: ${Math.abs(value).toFixed(3)})`
          )
          .join('\n'),
      },
      {
        label: 'Root Cause Analysis',
        description: `Based on the pattern characteristics, the most likely root cause is ${rootCauseClass.toLowerCase()}.`,
        details: `This conclusion has ${(rootCauseConfidence * 100).toFixed(1)}% confidence and is based on historical correlations between this pattern type and known failure modes in ${processStep} operations.`,
      },
      {
        label: 'Recommended Actions',
        description: 'To address this issue, consider the following steps:',
        details: `• Inspect ${equipmentId} for potential issues\n• Review process parameters for ${processStep}\n• Check for ${rootCauseClass.toLowerCase()} indicators\n• Monitor subsequent wafers for pattern recurrence`,
      },
    ];

    return steps;
  };

  const generateTechnicalExplanation = () => {
    const steps = [
      {
        label: 'Model Architecture & Inference',
        description: `Deep learning model (ResNet-50 backbone) processed wafer map through convolutional layers, extracting spatial features at multiple scales.`,
        details: `Input: 30x30 die grid → Feature extraction → Pattern classification head → Softmax output\nPredicted class: ${patternClass} (logit: ${Math.log(patternConfidence / (1 - patternConfidence)).toFixed(3)}, probability: ${patternConfidence.toFixed(4)})`,
      },
      {
        label: 'Feature Attribution (SHAP)',
        description: `SHAP (SHapley Additive exPlanations) analysis quantified feature contributions:`,
        details: topFeatures
          .map(
            ([feature, value]) =>
              `• ${feature}: SHAP value = ${value.toFixed(4)} (${value > 0 ? 'positive' : 'negative'} contribution)`
          )
          .join('\n') +
          `\n\nBase value: 0.5, Final prediction: ${patternConfidence.toFixed(4)}`,
      },
      {
        label: 'Attention Mechanism Analysis',
        description: `Multi-head attention layers focused on specific wafer regions:`,
        details: `Grad-CAM heatmap highlights high-activation regions corresponding to defect clusters. Attention weights concentrated in ${defectDensity > 0.05 ? 'edge and peripheral' : 'central'} regions, consistent with ${patternClass.toLowerCase()} characteristics.`,
      },
      {
        label: 'Root Cause Inference',
        description: `Secondary classifier (XGBoost ensemble) predicted root cause from pattern features:`,
        details: `Input features: pattern class probabilities, spatial statistics, process metadata\nPredicted cause: ${rootCauseClass} (confidence: ${rootCauseConfidence.toFixed(4)})\nDecision path: ${processStep} → Equipment ${equipmentId} → Historical correlation score: 0.87`,
      },
      {
        label: 'Uncertainty Quantification',
        description: `Model uncertainty analysis using Monte Carlo dropout:`,
        details: `Pattern confidence: ${(patternConfidence * 100).toFixed(2)}% (std: ${((1 - patternConfidence) * 0.1).toFixed(3)})\nRoot cause confidence: ${(rootCauseConfidence * 100).toFixed(2)}% (std: ${((1 - rootCauseConfidence) * 0.1).toFixed(3)})\nRecommendation: ${patternConfidence > 0.9 ? 'High confidence - proceed with automated actions' : 'Medium confidence - manual review recommended'}`,
      },
    ];

    return steps;
  };

  const steps = mode === 'technical' ? generateTechnicalExplanation() : generateNonTechnicalExplanation();

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <Psychology color="primary" />
          <Typography variant="h6" sx={{ fontWeight: 600, flex: 1 }}>
            AI Explanation
          </Typography>
          <Chip
            label={mode === 'technical' ? 'Technical Mode' : 'Simple Mode'}
            size="small"
            color="primary"
            variant="outlined"
          />
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Step-by-step explanation of how the AI reached this conclusion
        </Typography>

        {/* Mode Toggle */}
        <Box sx={{ mb: 3 }}>
          <ToggleButtonGroup
            value={mode}
            exclusive
            onChange={(_, value) => value && setMode(value)}
            size="small"
            fullWidth
          >
            <ToggleButton value="non-technical">
              <Info sx={{ mr: 1 }} fontSize="small" />
              Simple Explanation
            </ToggleButton>
            <ToggleButton value="technical">
              <Science sx={{ mr: 1 }} fontSize="small" />
              Technical Details
            </ToggleButton>
          </ToggleButtonGroup>
        </Box>

        {/* Reasoning Steps */}
        <Stepper orientation="vertical" activeStep={steps.length}>
          {steps.map((step) => (
            <Step key={step.label} active completed>
              <StepLabel>
                <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                  {step.label}
                </Typography>
              </StepLabel>
              <StepContent>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  {step.description}
                </Typography>
                <Box
                  sx={{
                    p: 1.5,
                    bgcolor: 'background.default',
                    borderRadius: 1,
                    fontFamily: 'monospace',
                    fontSize: '0.75rem',
                    whiteSpace: 'pre-line',
                  }}
                >
                  {step.details}
                </Box>
              </StepContent>
            </Step>
          ))}
        </Stepper>

        {/* Summary Alert */}
        <Alert
          severity={patternConfidence > 0.9 ? 'success' : 'warning'}
          sx={{ mt: 3 }}
        >
          <Typography variant="body2" sx={{ fontWeight: 600, mb: 0.5 }}>
            {mode === 'technical' ? 'Model Output Summary' : 'Summary'}
          </Typography>
          <Typography variant="body2">
            {mode === 'technical'
              ? `The model classified this wafer with ${patternClass} pattern (p=${patternConfidence.toFixed(4)}) and identified ${rootCauseClass} as the probable root cause (p=${rootCauseConfidence.toFixed(4)}). Confidence metrics indicate ${patternConfidence > 0.9 ? 'high reliability' : 'moderate uncertainty'} in the prediction.`
              : `The AI is ${(patternConfidence * 100).toFixed(1)}% confident that this is a ${patternClass.toLowerCase()} pattern, likely caused by ${rootCauseClass.toLowerCase()}. ${patternConfidence > 0.9 ? 'This is a highly reliable prediction.' : 'Consider manual verification for this prediction.'}`}
          </Typography>
        </Alert>
      </CardContent>
    </Card>
  );
}
