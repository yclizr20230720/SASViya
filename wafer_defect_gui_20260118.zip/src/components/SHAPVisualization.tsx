import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  Tooltip,
} from '@mui/material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  Cell,
  ReferenceLine,
} from 'recharts';
import { TrendingUp, TrendingDown, Info } from '@mui/icons-material';

interface SHAPVisualizationProps {
  shapValues: Record<string, number>;
  baseValue?: number;
  predictionValue?: number;
}

type VisualizationType = 'waterfall' | 'force' | 'bar';

export default function SHAPVisualization({
  shapValues,
  baseValue = 0.5,
  predictionValue = 0.96,
}: SHAPVisualizationProps) {
  const [vizType, setVizType] = useState<VisualizationType>('waterfall');

  // Prepare data for visualizations
  const shapData = Object.entries(shapValues)
    .map(([feature, value]) => ({
      feature,
      value,
      absValue: Math.abs(value),
      impact: value > 0 ? 'positive' : 'negative',
    }))
    .sort((a, b) => b.absValue - a.absValue);

  // Waterfall data
  const waterfallData = [
    { feature: 'Base Value', value: baseValue, cumulative: baseValue },
    ...shapData.reduce((acc, item, index) => {
      const prevCumulative = index === 0 ? baseValue : acc[index - 1].cumulative;
      const cumulative = prevCumulative + item.value;
      acc.push({
        feature: item.feature,
        value: item.value,
        cumulative,
        start: prevCumulative,
      });
      return acc;
    }, [] as any[]),
    { feature: 'Prediction', value: 0, cumulative: predictionValue },
  ];

  const renderWaterfallChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={waterfallData} layout="vertical">
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis type="number" domain={[0, 1]} />
        <YAxis dataKey="feature" type="category" width={150} />
        <RechartsTooltip
          content={({ active, payload }) => {
            if (active && payload && payload.length) {
              const data = payload[0].payload;
              return (
                <Box sx={{ bgcolor: 'background.paper', p: 1, border: 1, borderColor: 'divider' }}>
                  <Typography variant="caption" display="block">
                    <strong>{data.feature}</strong>
                  </Typography>
                  {data.value !== 0 && (
                    <Typography variant="caption" display="block">
                      Impact: {data.value > 0 ? '+' : ''}
                      {data.value.toFixed(3)}
                    </Typography>
                  )}
                  <Typography variant="caption" display="block">
                    Cumulative: {data.cumulative.toFixed(3)}
                  </Typography>
                </Box>
              );
            }
            return null;
          }}
        />
        <Bar dataKey="cumulative" fill="#0066CC" />
      </BarChart>
    </ResponsiveContainer>
  );

  const renderForceChart = () => (
    <Box>
      <Box sx={{ position: 'relative', height: 200, mb: 2 }}>
        {/* Base value line */}
        <Box
          sx={{
            position: 'absolute',
            left: `${baseValue * 100}%`,
            top: 0,
            bottom: 0,
            width: 2,
            bgcolor: 'grey.400',
            zIndex: 1,
          }}
        >
          <Typography
            variant="caption"
            sx={{
              position: 'absolute',
              top: -20,
              left: -30,
              bgcolor: 'background.paper',
              px: 0.5,
            }}
          >
            Base: {baseValue.toFixed(2)}
          </Typography>
        </Box>

        {/* Prediction value line */}
        <Box
          sx={{
            position: 'absolute',
            left: `${predictionValue * 100}%`,
            top: 0,
            bottom: 0,
            width: 2,
            bgcolor: 'primary.main',
            zIndex: 1,
          }}
        >
          <Typography
            variant="caption"
            sx={{
              position: 'absolute',
              top: -20,
              left: -35,
              bgcolor: 'background.paper',
              px: 0.5,
              color: 'primary.main',
              fontWeight: 600,
            }}
          >
            Pred: {predictionValue.toFixed(2)}
          </Typography>
        </Box>

        {/* Force arrows */}
        <Box sx={{ position: 'relative', top: 50 }}>
          {shapData.map((item, index) => {
            const startPos = baseValue * 100;
            const width = Math.abs(item.value) * 100;
            const isPositive = item.value > 0;
            
            return (
              <Tooltip key={item.feature} title={`${item.feature}: ${item.value.toFixed(3)}`}>
                <Box
                  sx={{
                    position: 'absolute',
                    left: isPositive ? `${startPos}%` : `${startPos - width}%`,
                    top: index * 15,
                    width: `${width}%`,
                    height: 10,
                    bgcolor: isPositive ? 'success.light' : 'error.light',
                    opacity: 0.7,
                    cursor: 'pointer',
                    '&:hover': { opacity: 1 },
                  }}
                />
              </Tooltip>
            );
          })}
        </Box>
      </Box>

      {/* Legend */}
      <Box sx={{ display: 'flex', gap: 3, justifyContent: 'center', mt: 4 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Box sx={{ width: 20, height: 10, bgcolor: 'success.light' }} />
          <Typography variant="caption">Positive Impact</Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Box sx={{ width: 20, height: 10, bgcolor: 'error.light' }} />
          <Typography variant="caption">Negative Impact</Typography>
        </Box>
      </Box>
    </Box>
  );

  const renderBarChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={shapData} layout="vertical">
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis type="number" />
        <YAxis dataKey="feature" type="category" width={150} />
        <RechartsTooltip />
        <ReferenceLine x={0} stroke="#666" />
        <Bar dataKey="value">
          {shapData.map((entry, index) => (
            <Cell
              key={`cell-${index}`}
              fill={entry.value > 0 ? '#4caf50' : '#f44336'}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <Typography variant="h6" sx={{ fontWeight: 600, flex: 1 }}>
            SHAP Feature Importance
          </Typography>
          <Tooltip title="SHAP values show how each feature contributed to the prediction">
            <Info fontSize="small" color="action" />
          </Tooltip>
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Explainable AI showing feature contributions to the classification
        </Typography>

        {/* Visualization Type Selector */}
        <Box sx={{ mb: 3 }}>
          <ToggleButtonGroup
            value={vizType}
            exclusive
            onChange={(_, value) => value && setVizType(value)}
            size="small"
            fullWidth
          >
            <ToggleButton value="waterfall">
              Waterfall Chart
            </ToggleButton>
            <ToggleButton value="force">
              Force Plot
            </ToggleButton>
            <ToggleButton value="bar">
              Bar Chart
            </ToggleButton>
          </ToggleButtonGroup>
        </Box>

        {/* Render selected visualization */}
        {vizType === 'waterfall' && renderWaterfallChart()}
        {vizType === 'force' && renderForceChart()}
        {vizType === 'bar' && renderBarChart()}

        {/* Top Features Summary */}
        <Box sx={{ mt: 3, p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
          <Typography variant="subtitle2" gutterBottom>
            Top Contributing Features:
          </Typography>
          {shapData.slice(0, 3).map((item) => (
            <Box
              key={item.feature}
              sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}
            >
              {item.value > 0 ? (
                <TrendingUp fontSize="small" color="success" />
              ) : (
                <TrendingDown fontSize="small" color="error" />
              )}
              <Typography variant="body2">
                <strong>{item.feature}:</strong> {item.value > 0 ? '+' : ''}
                {item.value.toFixed(3)}
              </Typography>
            </Box>
          ))}
        </Box>
      </CardContent>
    </Card>
  );
}
