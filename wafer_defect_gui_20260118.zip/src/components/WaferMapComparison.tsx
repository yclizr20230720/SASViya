import { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  FormControlLabel,
  Switch,
  Divider,
  Chip,
  Grid,
} from '@mui/material';

import WaferMapCanvas from './WaferMapCanvas';

interface WaferMapComparisonProps {
  wafer1: {
    id: string;
    name: string;
    heatmap: number[][];
  };
  wafer2: {
    id: string;
    name: string;
    heatmap: number[][];
  };
}

export default function WaferMapComparison({ wafer1, wafer2 }: WaferMapComparisonProps) {
  const [syncZoomPan, setSyncZoomPan] = useState(true);
  const [showDifference, setShowDifference] = useState(false);
  const [differenceMap, setDifferenceMap] = useState<number[][]>([]);
  const [metrics, setMetrics] = useState({
    totalDifference: 0,
    maxDifference: 0,
    avgDifference: 0,
    similarityScore: 0,
  });

  useEffect(() => {
    calculateDifference();
  }, [wafer1, wafer2]);

  const calculateDifference = () => {
    const size = wafer1.heatmap.length;
    const diff: number[][] = [];
    let totalDiff = 0;
    let maxDiff = 0;
    let count = 0;

    for (let i = 0; i < size; i++) {
      diff[i] = [];
      for (let j = 0; j < size; j++) {
        const difference = Math.abs(wafer1.heatmap[i][j] - wafer2.heatmap[i][j]);
        diff[i][j] = difference;
        totalDiff += difference;
        maxDiff = Math.max(maxDiff, difference);
        count++;
      }
    }

    const avgDiff = totalDiff / count;
    const similarityScore = (1 - avgDiff) * 100;

    setDifferenceMap(diff);
    setMetrics({
      totalDifference: totalDiff,
      maxDifference: maxDiff,
      avgDifference: avgDiff,
      similarityScore,
    });
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', gap: 2, mb: 3, alignItems: 'center' }}>
        <FormControlLabel
          control={
            <Switch
              checked={syncZoomPan}
              onChange={(e) => setSyncZoomPan(e.target.checked)}
            />
          }
          label="Synchronized Zoom & Pan"
        />
        <FormControlLabel
          control={
            <Switch
              checked={showDifference}
              onChange={(e) => setShowDifference(e.target.checked)}
            />
          }
          label="Show Difference Map"
        />
      </Box>

      <Grid container spacing={3}>
        {/* Wafer 1 */}
        <Grid size={{ xs: 12, md: showDifference ? 4 : 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                {wafer1.name}
              </Typography>
              <WaferMapCanvas heatmap={wafer1.heatmap} size={400} />
            </CardContent>
          </Card>
        </Grid>

        {/* Wafer 2 */}
        <Grid size={{ xs: 12, md: showDifference ? 4 : 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                {wafer2.name}
              </Typography>
              <WaferMapCanvas heatmap={wafer2.heatmap} size={400} />
            </CardContent>
          </Card>
        </Grid>

        {/* Difference Map */}
        {showDifference && (
          <Grid size={{ xs: 12, md: 4 }}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Difference Map
                </Typography>
                <WaferMapCanvas heatmap={differenceMap} size={400} />
              </CardContent>
            </Card>
          </Grid>
        )}

        {/* Comparison Metrics */}
        <Grid size={{ xs: 12 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Comparison Metrics
              </Typography>
              <Divider sx={{ my: 2 }} />
              <Grid container spacing={2}>
                <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Similarity Score
                    </Typography>
                    <Typography variant="h5" sx={{ fontWeight: 600 }}>
                      {metrics.similarityScore.toFixed(1)}%
                    </Typography>
                    <Chip
                      label={metrics.similarityScore > 80 ? 'High' : 'Low'}
                      size="small"
                      color={metrics.similarityScore > 80 ? 'success' : 'warning'}
                      sx={{ mt: 1 }}
                    />
                  </Box>
                </Grid>
                <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Average Difference
                    </Typography>
                    <Typography variant="h5" sx={{ fontWeight: 600 }}>
                      {metrics.avgDifference.toFixed(3)}
                    </Typography>
                  </Box>
                </Grid>
                <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Max Difference
                    </Typography>
                    <Typography variant="h5" sx={{ fontWeight: 600 }}>
                      {metrics.maxDifference.toFixed(3)}
                    </Typography>
                  </Box>
                </Grid>
                <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Total Difference
                    </Typography>
                    <Typography variant="h5" sx={{ fontWeight: 600 }}>
                      {metrics.totalDifference.toFixed(2)}
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
