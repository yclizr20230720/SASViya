import {
  Card,
  CardContent,
  Typography,
  Box,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Chip,
  Alert,
  Divider,
} from '@mui/material';
import {
  CheckCircle,
  Build,
  Science,
  Warning,
  TrendingUp,
} from '@mui/icons-material';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from 'recharts';

interface RootCause {
  cause: string;
  probability: number;
  category: 'equipment' | 'process' | 'material' | 'environmental';
  isPrimary: boolean;
}

interface Recommendation {
  action: string;
  priority: 'high' | 'medium' | 'low';
}

interface RootCauseAnalysisPanelProps {
  rootCauses: RootCause[];
  recommendations: Recommendation[];
  historicalOccurrences?: number;
}

const COLORS = ['#0066CC', '#00A3A3', '#F57C00', '#388E3C', '#9C27B0'];

export default function RootCauseAnalysisPanel({
  rootCauses,
  recommendations,
  historicalOccurrences = 0,
}: RootCauseAnalysisPanelProps) {
  const chartData = rootCauses.map((rc) => ({
    name: rc.cause,
    value: rc.probability,
  }));

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'equipment':
        return <Build />;
      case 'process':
        return <Science />;
      case 'material':
        return <CheckCircle />;
      case 'environmental':
        return <Warning />;
      default:
        return <CheckCircle />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'error';
      case 'medium':
        return 'warning';
      case 'low':
        return 'info';
      default:
        return 'default';
    }
  };

  return (
    <Card>
      <CardContent>
        <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
          Root Cause Analysis
        </Typography>

        {historicalOccurrences > 0 && (
          <Alert severity="info" sx={{ mb: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <TrendingUp />
              <Typography variant="body2">
                This pattern has occurred <strong>{historicalOccurrences} times</strong> in the past 30 days
              </Typography>
            </Box>
          </Alert>
        )}

        {/* Probability Distribution Chart */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" gutterBottom>
            Probability Distribution
          </Typography>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry) => `${entry.name}: ${entry.value.toFixed(1)}%`}
                outerRadius={80}
                dataKey="value"
              >
                {chartData.map((_entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => `${value}%`} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Box>

        <Divider sx={{ my: 2 }} />

        {/* Root Causes List */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" gutterBottom>
            Identified Root Causes
          </Typography>
          <List dense>
            {rootCauses.map((rc, index) => (
              <ListItem
                key={index}
                sx={{
                  border: 1,
                  borderColor: 'divider',
                  borderRadius: 1,
                  mb: 1,
                  bgcolor: rc.isPrimary ? 'action.selected' : 'background.paper',
                }}
              >
                <ListItemIcon>{getCategoryIcon(rc.category)}</ListItemIcon>
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body2" fontWeight={rc.isPrimary ? 600 : 400}>
                        {rc.cause}
                      </Typography>
                      {rc.isPrimary && (
                        <Chip label="Primary" size="small" color="primary" />
                      )}
                    </Box>
                  }
                  secondary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Chip
                        label={rc.category}
                        size="small"
                        sx={{ textTransform: 'capitalize' }}
                      />
                      <Typography variant="caption">
                        {rc.probability.toFixed(1)}% probability
                      </Typography>
                    </Box>
                  }
                />
              </ListItem>
            ))}
          </List>
        </Box>

        <Divider sx={{ my: 2 }} />

        {/* Recommendations */}
        <Box>
          <Typography variant="subtitle2" gutterBottom>
            Recommended Actions
          </Typography>
          <List dense>
            {recommendations.map((rec, index) => (
              <ListItem
                key={index}
                sx={{
                  border: 1,
                  borderColor: 'divider',
                  borderRadius: 1,
                  mb: 1,
                }}
              >
                <ListItemText
                  primary={rec.action}
                  secondary={
                    <Chip
                      label={`${rec.priority} priority`}
                      size="small"
                      color={getPriorityColor(rec.priority) as any}
                      sx={{ mt: 0.5, textTransform: 'capitalize' }}
                    />
                  }
                />
              </ListItem>
            ))}
          </List>
        </Box>
      </CardContent>
    </Card>
  );
}
