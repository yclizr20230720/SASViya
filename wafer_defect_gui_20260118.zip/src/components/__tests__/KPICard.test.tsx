import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import KPICard from '../KPICard';
import { TrendingUp } from '@mui/icons-material';

describe('KPICard', () => {
  it('should render title and value', () => {
    render(
      <KPICard
        title="Test Metric"
        value={1234}
        icon={<TrendingUp data-testid="icon" />}
      />
    );

    expect(screen.getByText('Test Metric')).toBeInTheDocument();
    expect(screen.getByTestId('icon')).toBeInTheDocument();
  });

  it('should display trend when provided', () => {
    render(
      <KPICard
        title="Test Metric"
        value={100}
        trend={12.5}
        icon={<TrendingUp />}
      />
    );

    expect(screen.getByText('+12.5%')).toBeInTheDocument();
    expect(screen.getByText('vs last week')).toBeInTheDocument();
  });

  it('should display suffix when provided', () => {
    render(
      <KPICard
        title="Test Metric"
        value={94.5}
        suffix="%"
        icon={<TrendingUp />}
      />
    );

    // Value should be animated, so we check for the suffix
    const element = screen.getByText(/%/);
    expect(element).toBeInTheDocument();
  });

  it('should display subtitle when provided', () => {
    render(
      <KPICard
        title="Test Metric"
        value={100}
        subtitle="Target: <5s"
        icon={<TrendingUp />}
      />
    );

    expect(screen.getByText('Target: <5s')).toBeInTheDocument();
  });
});
