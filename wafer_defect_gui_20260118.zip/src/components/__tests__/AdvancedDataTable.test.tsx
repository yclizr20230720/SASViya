import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import AdvancedDataTable, { WaferData } from '../AdvancedDataTable';

describe('AdvancedDataTable', () => {
  const mockData: WaferData[] = [
    {
      id: '1',
      waferId: 'W-2024-001',
      lotId: 'LOT-001',
      pattern: 'Center',
      confidence: 95.5,
      rootCause: 'Lithography Focus',
      equipment: 'EQP-001',
      processStep: 'Lithography',
      date: '2024-01-15',
      defectCount: 25,
      yieldImpact: 2.5,
    },
    {
      id: '2',
      waferId: 'W-2024-002',
      lotId: 'LOT-001',
      pattern: 'Edge-Ring',
      confidence: 88.2,
      rootCause: 'Etching Uniformity',
      equipment: 'EQP-002',
      processStep: 'Etching',
      date: '2024-01-16',
      defectCount: 18,
      yieldImpact: 1.8,
    },
  ];

  const mockOnViewDetails = vi.fn();
  const mockOnDelete = vi.fn();
  const mockOnCompare = vi.fn();
  const mockOnExport = vi.fn();

  it('renders table with data', () => {
    render(
      <AdvancedDataTable
        data={mockData}
        onViewDetails={mockOnViewDetails}
        onDelete={mockOnDelete}
        onCompare={mockOnCompare}
        onExport={mockOnExport}
      />
    );

    // Check if wafer IDs are rendered
    expect(screen.getByText('W-2024-001')).toBeInTheDocument();
    expect(screen.getByText('W-2024-002')).toBeInTheDocument();
  });

  it('renders column headers', () => {
    render(
      <AdvancedDataTable
        data={mockData}
        onViewDetails={mockOnViewDetails}
      />
    );

    expect(screen.getByText('Wafer ID')).toBeInTheDocument();
    expect(screen.getByText('Lot ID')).toBeInTheDocument();
    expect(screen.getByText('Pattern')).toBeInTheDocument();
    expect(screen.getByText('Confidence')).toBeInTheDocument();
  });

  it('renders export buttons', () => {
    render(
      <AdvancedDataTable
        data={mockData}
        onExport={mockOnExport}
      />
    );

    expect(screen.getByText('Export CSV')).toBeInTheDocument();
    expect(screen.getByText('Export Excel')).toBeInTheDocument();
  });

  it('renders with empty data', () => {
    render(
      <AdvancedDataTable
        data={[]}
        onViewDetails={mockOnViewDetails}
      />
    );

    // Table should still render with headers
    expect(screen.getByText('Wafer ID')).toBeInTheDocument();
  });

  it('displays confidence with color coding', () => {
    render(
      <AdvancedDataTable
        data={mockData}
        onViewDetails={mockOnViewDetails}
      />
    );

    // High confidence should be displayed
    expect(screen.getByText('95.5%')).toBeInTheDocument();
    expect(screen.getByText('88.2%')).toBeInTheDocument();
  });

  it('displays pattern as chips', () => {
    render(
      <AdvancedDataTable
        data={mockData}
        onViewDetails={mockOnViewDetails}
      />
    );

    expect(screen.getByText('Center')).toBeInTheDocument();
    expect(screen.getByText('Edge-Ring')).toBeInTheDocument();
  });
});
