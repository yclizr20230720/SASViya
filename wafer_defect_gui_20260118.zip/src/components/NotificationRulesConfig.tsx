import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Switch,
  FormControlLabel,
  Grid,
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  ListItemSecondaryAction,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Chip,
  Alert,
  Tabs,
  Tab,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Email as EmailIcon,
  Sms as SmsIcon,
  Chat as TeamsIcon,
  Notifications as NotificationIcon,
  Save as SaveIcon,
  Send as TestIcon,
} from '@mui/icons-material';

interface NotificationChannel {
  id: string;
  type: 'email' | 'sms' | 'teams';
  name: string;
  enabled: boolean;
  config: {
    // Email
    smtpServer?: string;
    smtpPort?: number;
    username?: string;
    password?: string;
    fromAddress?: string;
    // SMS
    provider?: string;
    apiKey?: string;
    phoneNumbers?: string[];
    // Teams
    webhookUrl?: string;
    channelId?: string;
  };
}

interface NotificationRule {
  id: string;
  name: string;
  enabled: boolean;
  alertType: 'defect_rate' | 'confidence' | 'equipment' | 'pattern' | 'system' | 'all';
  severity: 'critical' | 'high' | 'medium' | 'low' | 'all';
  channels: string[]; // channel IDs
  recipients: {
    emails?: string[];
    phones?: string[];
    teamsChannels?: string[];
  };
  conditions: {
    defectRateThreshold?: number;
    confidenceThreshold?: number;
    equipmentIds?: string[];
  };
  schedule: {
    enabled: boolean;
    quietHoursStart?: string;
    quietHoursEnd?: string;
    daysOfWeek?: number[]; // 0-6, Sunday-Saturday
  };
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`notification-tabpanel-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

const NotificationRulesConfig: React.FC = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [channels, setChannels] = useState<NotificationChannel[]>([
    {
      id: 'email-1',
      type: 'email',
      name: 'Company Email Server',
      enabled: true,
      config: {
        smtpServer: 'smtp.company.com',
        smtpPort: 587,
        username: 'wafer-alerts@company.com',
        fromAddress: 'wafer-alerts@company.com',
      },
    },
    {
      id: 'sms-1',
      type: 'sms',
      name: 'Twilio SMS',
      enabled: true,
      config: {
        provider: 'Twilio',
        phoneNumbers: ['+1-555-0100', '+1-555-0101'],
      },
    },
    {
      id: 'teams-1',
      type: 'teams',
      name: 'Engineering Team Channel',
      enabled: true,
      config: {
        channelId: 'engineering-alerts',
      },
    },
  ]);

  const [rules, setRules] = useState<NotificationRule[]>([
    {
      id: 'rule-1',
      name: 'Critical Defect Rate Alert',
      enabled: true,
      alertType: 'defect_rate',
      severity: 'critical',
      channels: ['email-1', 'sms-1', 'teams-1'],
      recipients: {
        emails: ['manager@company.com', 'engineer@company.com'],
        phones: ['+1-555-0100'],
        teamsChannels: ['engineering-alerts'],
      },
      conditions: {
        defectRateThreshold: 20,
      },
      schedule: {
        enabled: false,
      },
    },
    {
      id: 'rule-2',
      name: 'Equipment Performance Warning',
      enabled: true,
      alertType: 'equipment',
      severity: 'high',
      channels: ['email-1', 'teams-1'],
      recipients: {
        emails: ['maintenance@company.com'],
        teamsChannels: ['maintenance-alerts'],
      },
      conditions: {},
      schedule: {
        enabled: true,
        quietHoursStart: '22:00',
        quietHoursEnd: '06:00',
        daysOfWeek: [1, 2, 3, 4, 5], // Monday-Friday
      },
    },
  ]);

  const [editingChannel, setEditingChannel] = useState<NotificationChannel | null>(null);
  const [editingRule, setEditingRule] = useState<NotificationRule | null>(null);
  const [testResult, setTestResult] = useState<string | null>(null);

  const handleSaveChannel = (channel: NotificationChannel) => {
    if (channel.id) {
      setChannels(channels.map((c) => (c.id === channel.id ? channel : c)));
    } else {
      setChannels([...channels, { ...channel, id: `channel-${Date.now()}` }]);
    }
    setEditingChannel(null);
  };

  const handleDeleteChannel = (id: string) => {
    if (window.confirm('Are you sure you want to delete this channel?')) {
      setChannels(channels.filter((c) => c.id !== id));
    }
  };

  const handleSaveRule = (rule: NotificationRule) => {
    if (rule.id) {
      setRules(rules.map((r) => (r.id === rule.id ? rule : r)));
    } else {
      setRules([...rules, { ...rule, id: `rule-${Date.now()}` }]);
    }
    setEditingRule(null);
  };

  const handleDeleteRule = (id: string) => {
    if (window.confirm('Are you sure you want to delete this rule?')) {
      setRules(rules.filter((r) => r.id !== id));
    }
  };

  const handleTestChannel = async (channel: NotificationChannel) => {
    setTestResult('Sending test notification...');
    // Simulate API call
    setTimeout(() => {
      setTestResult(`✅ Test ${channel.type} sent successfully to ${channel.name}`);
      setTimeout(() => setTestResult(null), 5000);
    }, 1500);
  };

  const getChannelIcon = (type: string) => {
    switch (type) {
      case 'email':
        return <EmailIcon />;
      case 'sms':
        return <SmsIcon />;
      case 'teams':
        return <TeamsIcon />;
      default:
        return <NotificationIcon />;
    }
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h5" fontWeight={600}>
          Notification Rules & Configuration
        </Typography>
        <Button variant="contained" startIcon={<SaveIcon />}>
          Save All Changes
        </Button>
      </Box>

      {testResult && (
        <Alert severity="success" sx={{ mb: 3 }} onClose={() => setTestResult(null)}>
          {testResult}
        </Alert>
      )}

      <Card>
        <Tabs
          value={activeTab}
          onChange={(_, value) => setActiveTab(value)}
          variant="fullWidth"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label="Notification Channels" />
          <Tab label="Alert Rules" />
          <Tab label="Recipients" />
        </Tabs>

        {/* Notification Channels Tab */}
        <TabPanel value={activeTab} index={0}>
          <CardContent>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6">Configure Notification Channels</Typography>
              <Button
                variant="outlined"
                startIcon={<AddIcon />}
                onClick={() =>
                  setEditingChannel({
                    id: '',
                    type: 'email',
                    name: '',
                    enabled: true,
                    config: {},
                  })
                }
              >
                Add Channel
              </Button>
            </Box>

            <List>
              {channels.map((channel) => (
                <Card key={channel.id} sx={{ mb: 2 }}>
                  <ListItem>
                    <ListItemIcon>{getChannelIcon(channel.type)}</ListItemIcon>
                    <ListItemText
                      primary={
                        <Box display="flex" alignItems="center" gap={1}>
                          <Typography variant="subtitle1" fontWeight={600}>
                            {channel.name}
                          </Typography>
                          <Chip
                            label={channel.type.toUpperCase()}
                            size="small"
                            color="primary"
                            variant="outlined"
                          />
                          <Chip
                            label={channel.enabled ? 'Enabled' : 'Disabled'}
                            size="small"
                            color={channel.enabled ? 'success' : 'default'}
                          />
                        </Box>
                      }
                      secondary={
                        <Box mt={1}>
                          {channel.type === 'email' && (
                            <Typography variant="body2" color="text.secondary">
                              SMTP: {channel.config.smtpServer}:{channel.config.smtpPort} | From:{' '}
                              {channel.config.fromAddress}
                            </Typography>
                          )}
                          {channel.type === 'sms' && (
                            <Typography variant="body2" color="text.secondary">
                              Provider: {channel.config.provider} | {channel.config.phoneNumbers?.length || 0}{' '}
                              phone numbers configured
                            </Typography>
                          )}
                          {channel.type === 'teams' && (
                            <Typography variant="body2" color="text.secondary">
                              Channel: {channel.config.channelId}
                            </Typography>
                          )}
                        </Box>
                      }
                    />
                    <ListItemSecondaryAction>
                      <Box display="flex" gap={1}>
                        <Button
                          size="small"
                          startIcon={<TestIcon />}
                          onClick={() => handleTestChannel(channel)}
                          variant="outlined"
                        >
                          Test
                        </Button>
                        <IconButton size="small" onClick={() => setEditingChannel(channel)}>
                          <EditIcon fontSize="small" />
                        </IconButton>
                        <IconButton
                          size="small"
                          color="error"
                          onClick={() => handleDeleteChannel(channel.id)}
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </ListItemSecondaryAction>
                  </ListItem>
                </Card>
              ))}
            </List>
          </CardContent>
        </TabPanel>

        {/* Alert Rules Tab */}
        <TabPanel value={activeTab} index={1}>
          <CardContent>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6">Alert Notification Rules</Typography>
              <Button
                variant="outlined"
                startIcon={<AddIcon />}
                onClick={() =>
                  setEditingRule({
                    id: '',
                    name: '',
                    enabled: true,
                    alertType: 'all',
                    severity: 'all',
                    channels: [],
                    recipients: {},
                    conditions: {},
                    schedule: { enabled: false },
                  })
                }
              >
                Add Rule
              </Button>
            </Box>

            <List>
              {rules.map((rule) => (
                <Card key={rule.id} sx={{ mb: 2 }}>
                  <ListItem>
                    <ListItemText
                      primary={
                        <Box display="flex" alignItems="center" gap={1}>
                          <Typography variant="subtitle1" fontWeight={600}>
                            {rule.name}
                          </Typography>
                          <Chip
                            label={rule.enabled ? 'Active' : 'Inactive'}
                            size="small"
                            color={rule.enabled ? 'success' : 'default'}
                          />
                        </Box>
                      }
                      secondary={
                        <Box mt={1}>
                          <Typography variant="body2" color="text.secondary" gutterBottom>
                            Alert Type: {rule.alertType} | Severity: {rule.severity}
                          </Typography>
                          <Box display="flex" gap={0.5} flexWrap="wrap" mt={0.5}>
                            {rule.channels.map((channelId) => {
                              const channel = channels.find((c) => c.id === channelId);
                              return channel ? (
                                <Chip
                                  key={channelId}
                                  label={channel.name}
                                  size="small"
                                  icon={getChannelIcon(channel.type)}
                                  variant="outlined"
                                />
                              ) : null;
                            })}
                          </Box>
                          {rule.recipients.emails && rule.recipients.emails.length > 0 && (
                            <Typography variant="caption" color="text.secondary" display="block" mt={0.5}>
                              📧 {rule.recipients.emails.length} email recipients
                            </Typography>
                          )}
                          {rule.recipients.phones && rule.recipients.phones.length > 0 && (
                            <Typography variant="caption" color="text.secondary" display="block">
                              📱 {rule.recipients.phones.length} SMS recipients
                            </Typography>
                          )}
                          {rule.schedule.enabled && (
                            <Typography variant="caption" color="text.secondary" display="block">
                              🕐 Quiet hours: {rule.schedule.quietHoursStart} - {rule.schedule.quietHoursEnd}
                            </Typography>
                          )}
                        </Box>
                      }
                    />
                    <ListItemSecondaryAction>
                      <Box display="flex" gap={1}>
                        <IconButton size="small" onClick={() => setEditingRule(rule)}>
                          <EditIcon fontSize="small" />
                        </IconButton>
                        <IconButton
                          size="small"
                          color="error"
                          onClick={() => handleDeleteRule(rule.id)}
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </ListItemSecondaryAction>
                  </ListItem>
                </Card>
              ))}
            </List>
          </CardContent>
        </TabPanel>

        {/* Recipients Tab */}
        <TabPanel value={activeTab} index={2}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Manage Recipients
            </Typography>

            <Grid container spacing={3}>
              <Grid size={{ xs: 12, md: 4 }}>
                <Card variant="outlined">
                  <CardContent>
                    <Box display="flex" alignItems="center" gap={1} mb={2}>
                      <EmailIcon color="primary" />
                      <Typography variant="subtitle1" fontWeight={600}>
                        Email Recipients
                      </Typography>
                    </Box>
                    <TextField
                      fullWidth
                      label="Add Email Address"
                      placeholder="user@company.com"
                      size="small"
                      sx={{ mb: 2 }}
                    />
                    <Button variant="outlined" startIcon={<AddIcon />} fullWidth size="small">
                      Add Email
                    </Button>
                    <Divider sx={{ my: 2 }} />
                    <Typography variant="caption" color="text.secondary" display="block" mb={1}>
                      Configured Emails:
                    </Typography>
                    <Box display="flex" flexDirection="column" gap={0.5}>
                      <Chip label="manager@company.com" size="small" onDelete={() => {}} />
                      <Chip label="engineer@company.com" size="small" onDelete={() => {}} />
                      <Chip label="maintenance@company.com" size="small" onDelete={() => {}} />
                    </Box>
                  </CardContent>
                </Card>
              </Grid>

              <Grid size={{ xs: 12, md: 4 }}>
                <Card variant="outlined">
                  <CardContent>
                    <Box display="flex" alignItems="center" gap={1} mb={2}>
                      <SmsIcon color="primary" />
                      <Typography variant="subtitle1" fontWeight={600}>
                        SMS Recipients
                      </Typography>
                    </Box>
                    <TextField
                      fullWidth
                      label="Add Phone Number"
                      placeholder="+1-555-0100"
                      size="small"
                      sx={{ mb: 2 }}
                    />
                    <Button variant="outlined" startIcon={<AddIcon />} fullWidth size="small">
                      Add Phone
                    </Button>
                    <Divider sx={{ my: 2 }} />
                    <Typography variant="caption" color="text.secondary" display="block" mb={1}>
                      Configured Phones:
                    </Typography>
                    <Box display="flex" flexDirection="column" gap={0.5}>
                      <Chip label="+1-555-0100" size="small" onDelete={() => {}} />
                      <Chip label="+1-555-0101" size="small" onDelete={() => {}} />
                    </Box>
                  </CardContent>
                </Card>
              </Grid>

              <Grid size={{ xs: 12, md: 4 }}>
                <Card variant="outlined">
                  <CardContent>
                    <Box display="flex" alignItems="center" gap={1} mb={2}>
                      <TeamsIcon color="primary" />
                      <Typography variant="subtitle1" fontWeight={600}>
                        Teams Channels
                      </Typography>
                    </Box>
                    <TextField
                      fullWidth
                      label="Add Teams Channel"
                      placeholder="engineering-alerts"
                      size="small"
                      sx={{ mb: 2 }}
                    />
                    <Button variant="outlined" startIcon={<AddIcon />} fullWidth size="small">
                      Add Channel
                    </Button>
                    <Divider sx={{ my: 2 }} />
                    <Typography variant="caption" color="text.secondary" display="block" mb={1}>
                      Configured Channels:
                    </Typography>
                    <Box display="flex" flexDirection="column" gap={0.5}>
                      <Chip label="engineering-alerts" size="small" onDelete={() => {}} />
                      <Chip label="maintenance-alerts" size="small" onDelete={() => {}} />
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </CardContent>
        </TabPanel>
      </Card>

      {/* Channel Edit Dialog */}
      <Dialog
        open={!!editingChannel}
        onClose={() => setEditingChannel(null)}
        maxWidth="md"
        fullWidth
      >
        {editingChannel && (
          <>
            <DialogTitle>
              {editingChannel.id ? 'Edit' : 'Add'} Notification Channel
            </DialogTitle>
            <DialogContent>
              <Grid container spacing={2} sx={{ mt: 1 }}>
                <Grid size={{ xs: 12 }}>
                  <TextField
                    fullWidth
                    label="Channel Name"
                    value={editingChannel.name}
                    onChange={(e) =>
                      setEditingChannel({ ...editingChannel, name: e.target.value })
                    }
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 6 }}>
                  <FormControl fullWidth>
                    <InputLabel>Channel Type</InputLabel>
                    <Select
                      value={editingChannel.type}
                      label="Channel Type"
                      onChange={(e) =>
                        setEditingChannel({
                          ...editingChannel,
                          type: e.target.value as any,
                        })
                      }
                    >
                      <MenuItem value="email">Email (SMTP)</MenuItem>
                      <MenuItem value="sms">SMS</MenuItem>
                      <MenuItem value="teams">Microsoft Teams</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid size={{ xs: 12, md: 6 }}>
                  <FormControlLabel
                    control={
                      <Switch
                        checked={editingChannel.enabled}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            enabled: e.target.checked,
                          })
                        }
                      />
                    }
                    label="Enabled"
                  />
                </Grid>

                {editingChannel.type === 'email' && (
                  <>
                    <Grid size={{ xs: 12, md: 8 }}>
                      <TextField
                        fullWidth
                        label="SMTP Server"
                        placeholder="smtp.company.com"
                        value={editingChannel.config.smtpServer || ''}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            config: { ...editingChannel.config, smtpServer: e.target.value },
                          })
                        }
                      />
                    </Grid>
                    <Grid size={{ xs: 12, md: 4 }}>
                      <TextField
                        fullWidth
                        label="Port"
                        type="number"
                        value={editingChannel.config.smtpPort || 587}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            config: {
                              ...editingChannel.config,
                              smtpPort: parseInt(e.target.value),
                            },
                          })
                        }
                      />
                    </Grid>
                    <Grid size={{ xs: 12, md: 6 }}>
                      <TextField
                        fullWidth
                        label="Username"
                        value={editingChannel.config.username || ''}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            config: { ...editingChannel.config, username: e.target.value },
                          })
                        }
                      />
                    </Grid>
                    <Grid size={{ xs: 12, md: 6 }}>
                      <TextField
                        fullWidth
                        label="Password"
                        type="password"
                        value={editingChannel.config.password || ''}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            config: { ...editingChannel.config, password: e.target.value },
                          })
                        }
                      />
                    </Grid>
                    <Grid size={{ xs: 12 }}>
                      <TextField
                        fullWidth
                        label="From Address"
                        placeholder="wafer-alerts@company.com"
                        value={editingChannel.config.fromAddress || ''}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            config: { ...editingChannel.config, fromAddress: e.target.value },
                          })
                        }
                      />
                    </Grid>
                  </>
                )}

                {editingChannel.type === 'sms' && (
                  <>
                    <Grid size={{ xs: 12 }}>
                      <FormControl fullWidth>
                        <InputLabel>SMS Provider</InputLabel>
                        <Select
                          value={editingChannel.config.provider || 'Twilio'}
                          label="SMS Provider"
                          onChange={(e) =>
                            setEditingChannel({
                              ...editingChannel,
                              config: { ...editingChannel.config, provider: e.target.value },
                            })
                          }
                        >
                          <MenuItem value="Twilio">Twilio</MenuItem>
                          <MenuItem value="AWS SNS">AWS SNS</MenuItem>
                          <MenuItem value="Nexmo">Nexmo/Vonage</MenuItem>
                          <MenuItem value="MessageBird">MessageBird</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid size={{ xs: 12 }}>
                      <TextField
                        fullWidth
                        label="API Key"
                        type="password"
                        value={editingChannel.config.apiKey || ''}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            config: { ...editingChannel.config, apiKey: e.target.value },
                          })
                        }
                      />
                    </Grid>
                  </>
                )}

                {editingChannel.type === 'teams' && (
                  <>
                    <Grid size={{ xs: 12 }}>
                      <TextField
                        fullWidth
                        label="Webhook URL"
                        placeholder="https://outlook.office.com/webhook/..."
                        value={editingChannel.config.webhookUrl || ''}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            config: { ...editingChannel.config, webhookUrl: e.target.value },
                          })
                        }
                      />
                    </Grid>
                    <Grid size={{ xs: 12 }}>
                      <TextField
                        fullWidth
                        label="Channel ID"
                        placeholder="engineering-alerts"
                        value={editingChannel.config.channelId || ''}
                        onChange={(e) =>
                          setEditingChannel({
                            ...editingChannel,
                            config: { ...editingChannel.config, channelId: e.target.value },
                          })
                        }
                      />
                    </Grid>
                  </>
                )}
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setEditingChannel(null)}>Cancel</Button>
              <Button
                variant="contained"
                onClick={() => handleSaveChannel(editingChannel)}
                disabled={!editingChannel.name}
              >
                Save Channel
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      {/* Rule Edit Dialog - Simplified for brevity */}
      <Dialog
        open={!!editingRule}
        onClose={() => setEditingRule(null)}
        maxWidth="md"
        fullWidth
      >
        {editingRule && (
          <>
            <DialogTitle>{editingRule.id ? 'Edit' : 'Add'} Alert Rule</DialogTitle>
            <DialogContent>
              <Grid container spacing={2} sx={{ mt: 1 }}>
                <Grid size={{ xs: 12 }}>
                  <TextField
                    fullWidth
                    label="Rule Name"
                    value={editingRule.name}
                    onChange={(e) => setEditingRule({ ...editingRule, name: e.target.value })}
                  />
                </Grid>
                <Grid size={{ xs: 12, md: 6 }}>
                  <FormControl fullWidth>
                    <InputLabel>Alert Type</InputLabel>
                    <Select
                      value={editingRule.alertType}
                      label="Alert Type"
                      onChange={(e) =>
                        setEditingRule({ ...editingRule, alertType: e.target.value as any })
                      }
                    >
                      <MenuItem value="all">All Types</MenuItem>
                      <MenuItem value="defect_rate">Defect Rate</MenuItem>
                      <MenuItem value="confidence">Confidence</MenuItem>
                      <MenuItem value="equipment">Equipment</MenuItem>
                      <MenuItem value="pattern">Pattern</MenuItem>
                      <MenuItem value="system">System</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid size={{ xs: 12, md: 6 }}>
                  <FormControl fullWidth>
                    <InputLabel>Severity</InputLabel>
                    <Select
                      value={editingRule.severity}
                      label="Severity"
                      onChange={(e) =>
                        setEditingRule({ ...editingRule, severity: e.target.value as any })
                      }
                    >
                      <MenuItem value="all">All Severities</MenuItem>
                      <MenuItem value="critical">Critical</MenuItem>
                      <MenuItem value="high">High</MenuItem>
                      <MenuItem value="medium">Medium</MenuItem>
                      <MenuItem value="low">Low</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid size={{ xs: 12 }}>
                  <FormControlLabel
                    control={
                      <Switch
                        checked={editingRule.enabled}
                        onChange={(e) =>
                          setEditingRule({ ...editingRule, enabled: e.target.checked })
                        }
                      />
                    }
                    label="Rule Enabled"
                  />
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setEditingRule(null)}>Cancel</Button>
              <Button
                variant="contained"
                onClick={() => handleSaveRule(editingRule)}
                disabled={!editingRule.name}
              >
                Save Rule
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
};

export default NotificationRulesConfig;
