import { useState, useRef, useEffect } from 'react';
import {
  Box,
  ToggleButtonGroup,
  ToggleButton,
  IconButton,
  Tooltip,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Popover,
  Stack,
  Typography,
  Divider,
} from '@mui/material';
import {
  Create,
  Circle,
  ArrowForward,
  Delete,
  Save,
  Share,
  Visibility,
  VisibilityOff,
  Hexagon,
  Gesture,
  TextFields,
  Download,
  Palette,
  FormatSize,
} from '@mui/icons-material';

export interface Annotation {
  id: string;
  type: 'rectangle' | 'circle' | 'arrow' | 'text' | 'polygon' | 'freehand';
  x: number;
  y: number;
  width?: number;
  height?: number;
  radius?: number;
  endX?: number;
  endY?: number;
  text?: string;
  points?: { x: number; y: number }[];
  color: string;
  strokeWidth: number;
  fontSize?: number;
  visible: boolean;
}

interface WaferMapAnnotationProps {
  annotations: Annotation[];
  onAnnotationsChange: (annotations: Annotation[]) => void;
  canvasSize?: number;
}

const COLORS = ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF', '#FFA500', '#800080'];
const STROKE_WIDTHS = [1, 2, 3, 4, 5];
const FONT_SIZES = [12, 16, 20, 24, 32];

export default function WaferMapAnnotation({
  annotations,
  onAnnotationsChange,
  canvasSize = 500,
}: WaferMapAnnotationProps) {
  const [tool, setTool] = useState<'select' | 'rectangle' | 'circle' | 'arrow' | 'text' | 'polygon' | 'freehand'>('select');
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [annotationName, setAnnotationName] = useState('');
  const [currentColor, setCurrentColor] = useState('#FF0000');
  const [currentStrokeWidth, setCurrentStrokeWidth] = useState(2);
  const [currentFontSize, setCurrentFontSize] = useState(16);
  const [styleAnchorEl, setStyleAnchorEl] = useState<HTMLButtonElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPoints, setCurrentPoints] = useState<{ x: number; y: number }[]>([]);
  const [startPoint, setStartPoint] = useState<{ x: number; y: number } | null>(null);
  const [textDialogOpen, setTextDialogOpen] = useState(false);
  const [textInput, setTextInput] = useState('');
  const [textPosition, setTextPosition] = useState<{ x: number; y: number } | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    drawAnnotations();
  }, [annotations]);

  const handleToolChange = (_: React.MouseEvent<HTMLElement>, newTool: string | null) => {
    if (newTool) {
      setTool(newTool as any);
      setIsDrawing(false);
      setCurrentPoints([]);
      setStartPoint(null);
    }
  };

  const handleDeleteAnnotation = (id: string) => {
    onAnnotationsChange(annotations.filter((a) => a.id !== id));
  };

  const handleToggleVisibility = (id: string) => {
    onAnnotationsChange(
      annotations.map((a) => (a.id === id ? { ...a, visible: !a.visible } : a))
    );
  };

  const handleSave = () => {
    const data = JSON.stringify(annotations);
    localStorage.setItem(`wafer-annotations-${annotationName}`, data);
    setSaveDialogOpen(false);
    setAnnotationName('');
  };

  const handleExport = () => {
    const data = JSON.stringify(annotations, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wafer-annotations-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleShare = () => {
    const data = JSON.stringify(annotations);
    navigator.clipboard.writeText(data);
    setShareDialogOpen(false);
  };

  const getCanvasCoordinates = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (tool === 'select') return;
    
    const point = getCanvasCoordinates(e);
    setIsDrawing(true);
    setStartPoint(point);

    if (tool === 'freehand' || tool === 'polygon') {
      setCurrentPoints([point]);
    } else if (tool === 'text') {
      setTextPosition(point);
      setTextDialogOpen(true);
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !startPoint) return;

    const point = getCanvasCoordinates(e);

    if (tool === 'freehand') {
      setCurrentPoints([...currentPoints, point]);
      drawPreview(point);
    } else if (tool !== 'polygon' && tool !== 'text') {
      drawPreview(point);
    }
  };

  const handleCanvasMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !startPoint) return;

    const point = getCanvasCoordinates(e);

    if (tool === 'polygon') {
      setCurrentPoints([...currentPoints, point]);
      return; // Don't finish polygon yet
    }

    if (tool === 'text') {
      setIsDrawing(false);
      return; // Text handled by dialog
    }

    createAnnotation(point);
    setIsDrawing(false);
    setStartPoint(null);
    setCurrentPoints([]);
  };

  const handleCanvasDoubleClick = () => {
    if (tool === 'polygon' && currentPoints.length > 2) {
      const newAnnotation: Annotation = {
        id: `annotation-${Date.now()}`,
        type: 'polygon',
        x: currentPoints[0].x,
        y: currentPoints[0].y,
        points: currentPoints,
        color: currentColor,
        strokeWidth: currentStrokeWidth,
        visible: true,
      };
      onAnnotationsChange([...annotations, newAnnotation]);
      setCurrentPoints([]);
      setIsDrawing(false);
    }
  };

  const createAnnotation = (endPoint: { x: number; y: number }) => {
    if (!startPoint) return;

    const newAnnotation: Annotation = {
      id: `annotation-${Date.now()}`,
      type: tool as any,
      x: startPoint.x,
      y: startPoint.y,
      color: currentColor,
      strokeWidth: currentStrokeWidth,
      visible: true,
    };

    switch (tool) {
      case 'rectangle':
        newAnnotation.width = endPoint.x - startPoint.x;
        newAnnotation.height = endPoint.y - startPoint.y;
        break;
      case 'circle':
        const radius = Math.sqrt(
          Math.pow(endPoint.x - startPoint.x, 2) + Math.pow(endPoint.y - startPoint.y, 2)
        );
        newAnnotation.radius = radius;
        break;
      case 'arrow':
        newAnnotation.endX = endPoint.x;
        newAnnotation.endY = endPoint.y;
        break;
      case 'freehand':
        newAnnotation.points = currentPoints;
        break;
    }

    onAnnotationsChange([...annotations, newAnnotation]);
  };

  const handleTextSubmit = () => {
    if (!textPosition || !textInput) return;

    const newAnnotation: Annotation = {
      id: `annotation-${Date.now()}`,
      type: 'text',
      x: textPosition.x,
      y: textPosition.y,
      text: textInput,
      color: currentColor,
      strokeWidth: currentStrokeWidth,
      fontSize: currentFontSize,
      visible: true,
    };

    onAnnotationsChange([...annotations, newAnnotation]);
    setTextDialogOpen(false);
    setTextInput('');
    setTextPosition(null);
    setIsDrawing(false);
  };

  const drawPreview = (currentPoint: { x: number; y: number }) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx || !startPoint) return;

    drawAnnotations();

    ctx.strokeStyle = currentColor;
    ctx.lineWidth = currentStrokeWidth;
    ctx.setLineDash([5, 5]);

    switch (tool) {
      case 'rectangle':
        ctx.strokeRect(
          startPoint.x,
          startPoint.y,
          currentPoint.x - startPoint.x,
          currentPoint.y - startPoint.y
        );
        break;
      case 'circle':
        const radius = Math.sqrt(
          Math.pow(currentPoint.x - startPoint.x, 2) + Math.pow(currentPoint.y - startPoint.y, 2)
        );
        ctx.beginPath();
        ctx.arc(startPoint.x, startPoint.y, radius, 0, 2 * Math.PI);
        ctx.stroke();
        break;
      case 'arrow':
        drawArrow(ctx, startPoint.x, startPoint.y, currentPoint.x, currentPoint.y);
        break;
      case 'freehand':
        if (currentPoints.length > 1) {
          ctx.beginPath();
          ctx.moveTo(currentPoints[0].x, currentPoints[0].y);
          currentPoints.forEach((p) => ctx.lineTo(p.x, p.y));
          ctx.stroke();
        }
        break;
    }

    ctx.setLineDash([]);
  };

  const drawAnnotations = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    annotations.forEach((annotation) => {
      if (!annotation.visible) return;

      ctx.strokeStyle = annotation.color;
      ctx.fillStyle = annotation.color;
      ctx.lineWidth = annotation.strokeWidth;

      switch (annotation.type) {
        case 'rectangle':
          if (annotation.width && annotation.height) {
            ctx.strokeRect(annotation.x, annotation.y, annotation.width, annotation.height);
          }
          break;
        case 'circle':
          if (annotation.radius) {
            ctx.beginPath();
            ctx.arc(annotation.x, annotation.y, annotation.radius, 0, 2 * Math.PI);
            ctx.stroke();
          }
          break;
        case 'arrow':
          if (annotation.endX !== undefined && annotation.endY !== undefined) {
            drawArrow(ctx, annotation.x, annotation.y, annotation.endX, annotation.endY);
          }
          break;
        case 'polygon':
          if (annotation.points && annotation.points.length > 2) {
            ctx.beginPath();
            ctx.moveTo(annotation.points[0].x, annotation.points[0].y);
            annotation.points.forEach((p) => ctx.lineTo(p.x, p.y));
            ctx.closePath();
            ctx.stroke();
          }
          break;
        case 'freehand':
          if (annotation.points && annotation.points.length > 1) {
            ctx.beginPath();
            ctx.moveTo(annotation.points[0].x, annotation.points[0].y);
            annotation.points.forEach((p) => ctx.lineTo(p.x, p.y));
            ctx.stroke();
          }
          break;
        case 'text':
          if (annotation.text) {
            ctx.font = `${annotation.fontSize || 16}px Arial`;
            ctx.fillText(annotation.text, annotation.x, annotation.y);
          }
          break;
      }
    });

    // Draw current polygon points
    if (tool === 'polygon' && currentPoints.length > 0) {
      ctx.strokeStyle = currentColor;
      ctx.lineWidth = currentStrokeWidth;
      ctx.fillStyle = currentColor;
      
      currentPoints.forEach((p) => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, 3, 0, 2 * Math.PI);
        ctx.fill();
      });

      if (currentPoints.length > 1) {
        ctx.beginPath();
        ctx.moveTo(currentPoints[0].x, currentPoints[0].y);
        currentPoints.forEach((p) => ctx.lineTo(p.x, p.y));
        ctx.stroke();
      }
    }
  };

  const drawArrow = (
    ctx: CanvasRenderingContext2D,
    fromX: number,
    fromY: number,
    toX: number,
    toY: number
  ) => {
    const headLength = 15;
    const angle = Math.atan2(toY - fromY, toX - fromX);

    ctx.beginPath();
    ctx.moveTo(fromX, fromY);
    ctx.lineTo(toX, toY);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(toX, toY);
    ctx.lineTo(
      toX - headLength * Math.cos(angle - Math.PI / 6),
      toY - headLength * Math.sin(angle - Math.PI / 6)
    );
    ctx.moveTo(toX, toY);
    ctx.lineTo(
      toX - headLength * Math.cos(angle + Math.PI / 6),
      toY - headLength * Math.sin(angle + Math.PI / 6)
    );
    ctx.stroke();
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
        <ToggleButtonGroup
          value={tool}
          exclusive
          onChange={handleToolChange}
          size="small"
        >
          <ToggleButton value="rectangle">
            <Tooltip title="Draw Rectangle">
              <Create />
            </Tooltip>
          </ToggleButton>
          <ToggleButton value="circle">
            <Tooltip title="Draw Circle">
              <Circle />
            </Tooltip>
          </ToggleButton>
          <ToggleButton value="arrow">
            <Tooltip title="Draw Arrow">
              <ArrowForward />
            </Tooltip>
          </ToggleButton>
          <ToggleButton value="polygon">
            <Tooltip title="Draw Polygon (double-click to finish)">
              <Hexagon />
            </Tooltip>
          </ToggleButton>
          <ToggleButton value="freehand">
            <Tooltip title="Freehand Drawing">
              <Gesture />
            </Tooltip>
          </ToggleButton>
          <ToggleButton value="text">
            <Tooltip title="Add Text">
              <TextFields />
            </Tooltip>
          </ToggleButton>
        </ToggleButtonGroup>

        <Tooltip title="Style Options">
          <IconButton size="small" onClick={(e) => setStyleAnchorEl(e.currentTarget)}>
            <Palette />
          </IconButton>
        </Tooltip>

        <Box sx={{ flexGrow: 1 }} />

        <Tooltip title="Save Annotations">
          <IconButton size="small" onClick={() => setSaveDialogOpen(true)}>
            <Save />
          </IconButton>
        </Tooltip>
        <Tooltip title="Export Annotations">
          <IconButton size="small" onClick={handleExport}>
            <Download />
          </IconButton>
        </Tooltip>
        <Tooltip title="Share Annotations">
          <IconButton size="small" onClick={() => setShareDialogOpen(true)}>
            <Share />
          </IconButton>
        </Tooltip>
      </Box>

      {/* Canvas for drawing annotations */}
      <Box
        sx={{
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: 1,
          overflow: 'hidden',
          mb: 2,
        }}
      >
        <canvas
          ref={canvasRef}
          width={canvasSize}
          height={canvasSize}
          onMouseDown={handleCanvasMouseDown}
          onMouseMove={handleCanvasMouseMove}
          onMouseUp={handleCanvasMouseUp}
          onDoubleClick={handleCanvasDoubleClick}
          style={{ cursor: tool === 'select' ? 'default' : 'crosshair', display: 'block' }}
        />
      </Box>

      {annotations.length > 0 && (
        <Box sx={{ mt: 2 }}>
          <Typography variant="subtitle2" gutterBottom>
            Annotations ({annotations.length})
          </Typography>
          <List dense>
            {annotations.map((annotation) => (
              <ListItem key={annotation.id}>
                <Box
                  sx={{
                    width: 16,
                    height: 16,
                    bgcolor: annotation.color,
                    borderRadius: 0.5,
                    mr: 1,
                  }}
                />
                <ListItemText
                  primary={`${annotation.type.charAt(0).toUpperCase() + annotation.type.slice(1)} annotation`}
                  secondary={annotation.text || `Position: (${Math.round(annotation.x)}, ${Math.round(annotation.y)})`}
                />
                <ListItemSecondaryAction>
                  <IconButton
                    size="small"
                    onClick={() => handleToggleVisibility(annotation.id)}
                  >
                    {annotation.visible ? <Visibility /> : <VisibilityOff />}
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => handleDeleteAnnotation(annotation.id)}
                  >
                    <Delete />
                  </IconButton>
                </ListItemSecondaryAction>
              </ListItem>
            ))}
          </List>
        </Box>
      )}

      {/* Style Popover */}
      <Popover
        open={Boolean(styleAnchorEl)}
        anchorEl={styleAnchorEl}
        onClose={() => setStyleAnchorEl(null)}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
      >
        <Box sx={{ p: 2, minWidth: 200 }}>
          <Typography variant="subtitle2" gutterBottom>
            Color
          </Typography>
          <Stack direction="row" spacing={1} sx={{ mb: 2, flexWrap: 'wrap' }}>
            {COLORS.map((color) => (
              <IconButton
                key={color}
                size="small"
                onClick={() => setCurrentColor(color)}
                sx={{
                  bgcolor: color,
                  width: 32,
                  height: 32,
                  border: currentColor === color ? '2px solid black' : 'none',
                  '&:hover': { bgcolor: color, opacity: 0.8 },
                }}
              />
            ))}
          </Stack>

          <Divider sx={{ my: 2 }} />

          <Typography variant="subtitle2" gutterBottom>
            Stroke Width
          </Typography>
          <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
            {STROKE_WIDTHS.map((width) => (
              <Button
                key={width}
                size="small"
                variant={currentStrokeWidth === width ? 'contained' : 'outlined'}
                onClick={() => setCurrentStrokeWidth(width)}
              >
                {width}
              </Button>
            ))}
          </Stack>

          <Divider sx={{ my: 2 }} />

          <Typography variant="subtitle2" gutterBottom>
            Font Size
          </Typography>
          <Stack direction="row" spacing={1}>
            {FONT_SIZES.map((size) => (
              <Button
                key={size}
                size="small"
                variant={currentFontSize === size ? 'contained' : 'outlined'}
                onClick={() => setCurrentFontSize(size)}
              >
                {size}
              </Button>
            ))}
          </Stack>
        </Box>
      </Popover>

      {/* Text Input Dialog */}
      <Dialog open={textDialogOpen} onClose={() => setTextDialogOpen(false)}>
        <DialogTitle>Add Text Annotation</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            fullWidth
            label="Text"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            sx={{ mt: 2 }}
            multiline
            rows={3}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTextDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleTextSubmit} variant="contained" disabled={!textInput}>
            Add
          </Button>
        </DialogActions>
      </Dialog>

      {/* Save Dialog */}
      <Dialog open={saveDialogOpen} onClose={() => setSaveDialogOpen(false)}>
        <DialogTitle>Save Annotations</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            fullWidth
            label="Annotation Set Name"
            value={annotationName}
            onChange={(e) => setAnnotationName(e.target.value)}
            sx={{ mt: 2 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSaveDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleSave} variant="contained" disabled={!annotationName}>
            Save
          </Button>
        </DialogActions>
      </Dialog>

      {/* Share Dialog */}
      <Dialog open={shareDialogOpen} onClose={() => setShareDialogOpen(false)}>
        <DialogTitle>Share Annotations</DialogTitle>
        <DialogContent>
          Annotations have been copied to clipboard. Share the JSON data with your team members.
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShareDialogOpen(false)}>Close</Button>
          <Button onClick={handleShare} variant="contained">
            Copy to Clipboard
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
