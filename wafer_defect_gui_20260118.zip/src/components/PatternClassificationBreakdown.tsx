import { useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  List,
  ListItem,
  ListItemText,
  LinearProgress,
  IconButton,
  Collapse,
  Chip,
  Link,
} from '@mui/material';
import {
  ExpandMore,
  ExpandLess,
  Info,
} from '@mui/icons-material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface PatternProbability {
  pattern: string;
  probability: number;
  description: string;
  isDetected: boolean;
}

interface PatternClassificationBreakdownProps {
  patterns: PatternProbability[];
  onExplainPattern?: (pattern: string) => void;
}

export default function PatternClassificationBreakdown({
  patterns,
  onExplainPattern,
}: PatternClassificationBreakdownProps) {
  const [sortBy, setSortBy] = useState<'name' | 'probability'>('probability');
  const [expandedPattern, setExpandedPattern] = useState<string | null>(null);

  const sortedPatterns = [...patterns].sort((a, b) => {
    if (sortBy === 'probability') {
      return b.probability - a.probability;
    }
    return a.pattern.localeCompare(b.pattern);
  });

  const chartData = sortedPatterns.map((p) => ({
    name: p.pattern,
    value: p.probability,
    isDetected: p.isDetected,
  }));

  const handleToggleExpand = (pattern: string) => {
    setExpandedPattern(expandedPattern === pattern ? null : pattern);
  };

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Pattern Classification Breakdown
          </Typography>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Chip
              label="By Probability"
              size="small"
              color={sortBy === 'probability' ? 'primary' : 'default'}
              onClick={() => setSortBy('probability')}
            />
            <Chip
              label="By Name"
              size="small"
              color={sortBy === 'name' ? 'primary' : 'default'}
              onClick={() => setSortBy('name')}
            />
          </Box>
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Probability distribution across all pattern classes
        </Typography>

        {/* Bar Chart */}
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={chartData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis type="number" domain={[0, 100]} />
            <YAxis dataKey="name" type="category" width={120} />
            <Tooltip formatter={(value) => `${value}%`} />
            <Bar dataKey="value" radius={[0, 8, 8, 0]}>
              {chartData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.isDetected ? '#0066CC' : '#BDBDBD'}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>

        {/* Pattern List */}
        <List sx={{ mt: 3 }}>
          {sortedPatterns.map((pattern) => (
            <Box key={pattern.pattern}>
              <ListItem
                sx={{
                  border: 1,
                  borderColor: 'divider',
                  borderRadius: 1,
                  mb: 1,
                  bgcolor: pattern.isDetected ? 'action.selected' : 'background.paper',
                }}
              >
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body1" fontWeight={pattern.isDetected ? 600 : 400}>
                        {pattern.pattern}
                      </Typography>
                      {pattern.isDetected && (
                        <Chip label="Detected" size="small" color="primary" />
                      )}
                    </Box>
                  }
                  secondary={
                    <Box sx={{ mt: 1 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                        <Typography variant="body2">
                          {pattern.probability.toFixed(1)}%
                        </Typography>
                      </Box>
                      <LinearProgress
                        variant="determinate"
                        value={pattern.probability}
                        sx={{ height: 6, borderRadius: 3 }}
                        color={pattern.isDetected ? 'primary' : 'inherit'}
                      />
                    </Box>
                  }
                />
                <IconButton
                  size="small"
                  onClick={() => handleToggleExpand(pattern.pattern)}
                >
                  {expandedPattern === pattern.pattern ? <ExpandLess /> : <ExpandMore />}
                </IconButton>
              </ListItem>

              <Collapse in={expandedPattern === pattern.pattern}>
                <Box sx={{ p: 2, bgcolor: 'action.hover', borderRadius: 1, mb: 1 }}>
                  <Typography variant="body2" paragraph>
                    {pattern.description}
                  </Typography>
                  {onExplainPattern && (
                    <Link
                      component="button"
                      variant="body2"
                      onClick={() => onExplainPattern(pattern.pattern)}
                      sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}
                    >
                      <Info fontSize="small" />
                      Why this pattern?
                    </Link>
                  )}
                </Box>
              </Collapse>
            </Box>
          ))}
        </List>
      </CardContent>
    </Card>
  );
}
