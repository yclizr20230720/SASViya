import { Box, Alert, AlertTitle, IconButton, Slide } from '@mui/material';
import { Close as CloseIcon } from '@mui/icons-material';
import { TransitionGroup } from 'react-transition-group';

export interface Toast {
  id: string;
  type: 'error' | 'warning' | 'info' | 'success';
  title?: string;
  message: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

interface ToastContainerProps {
  toasts: Toast[];
  onClose: (id: string) => void;
}

const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onClose }) => {
  return (
    <Box
      sx={{
        position: 'fixed',
        top: 80,
        right: 16,
        zIndex: 9999,
        display: 'flex',
        flexDirection: 'column',
        gap: 1,
        maxWidth: 500,
      }}
    >
      <TransitionGroup>
        {toasts.map((toast) => (
          <Slide key={toast.id} direction="left" in mountOnEnter unmountOnExit>
            <Alert
              severity={toast.type}
              variant="filled"
              onClose={() => onClose(toast.id)}
              action={
                <>
                  {toast.action && (
                    <IconButton
                      size="small"
                      color="inherit"
                      onClick={() => {
                        toast.action?.onClick();
                        onClose(toast.id);
                      }}
                      sx={{ mr: 1 }}
                    >
                      {toast.action.label}
                    </IconButton>
                  )}
                  <IconButton size="small" color="inherit" onClick={() => onClose(toast.id)}>
                    <CloseIcon fontSize="small" />
                  </IconButton>
                </>
              }
              sx={{
                minWidth: 300,
                boxShadow: 3,
                mb: 1,
              }}
            >
              {toast.title && <AlertTitle>{toast.title}</AlertTitle>}
              {toast.message}
            </Alert>
          </Slide>
        ))}
      </TransitionGroup>
    </Box>
  );
};

export default ToastContainer;
