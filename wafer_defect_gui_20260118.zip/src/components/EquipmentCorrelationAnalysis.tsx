import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  Chip,
  Tooltip as MuiTooltip,
} from '@mui/material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { Engineering, Warning, CheckCircle } from '@mui/icons-material';

interface EquipmentCorrelationAnalysisProps {
  data?: {
    heatmapData: {
      equipment: string;
      patterns: Record<string, number>;
      totalDefects: number;
      status: 'good' | 'warning' | 'critical';
    }[];
    performanceData: {
      equipment: string;
      uptime: number;
      defectRate: number;
      efficiency: number;
    }[];
  };
}

type ViewMode = 'heatmap' | 'performance' | 'comparison';

const PATTERN_COLORS: Record<string, string> = {
  'Edge Defect': '#0066CC',
  'Center Defect': '#00C49F',
  'Scratch': '#FFBB28',
  'Ring': '#FF8042',
  'Random': '#8884D8',
};

export default function EquipmentCorrelationAnalysis({
  data = generateMockData(),
}: EquipmentCorrelationAnalysisProps) {
  const [viewMode, setViewMode] = useState<ViewMode>('heatmap');
  const [selectedEquipment, setSelectedEquipment] = useState<string | null>(null);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'good':
        return <CheckCircle fontSize="small" color="success" />;
      case 'warning':
        return <Warning fontSize="small" color="warning" />;
      case 'critical':
        return <Warning fontSize="small" color="error" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good':
        return '#4caf50';
      case 'warning':
        return '#ff9800';
      case 'critical':
        return '#f44336';
      default:
        return '#9e9e9e';
    }
  };

  const renderHeatmap = () => {
    const patterns = Object.keys(data.heatmapData[0].patterns);
    const maxValue = Math.max(
      ...data.heatmapData.flatMap((eq) => Object.values(eq.patterns))
    );

    return (
      <Box>
        <Box sx={{ display: 'flex', mb: 2, borderBottom: 1, borderColor: 'divider', pb: 1 }}>
          <Box sx={{ width: 150 }} />
          {patterns.map((pattern) => (
            <Box
              key={pattern}
              sx={{
                flex: 1,
                textAlign: 'center',
                px: 1,
              }}
            >
              <Typography variant="caption" sx={{ fontWeight: 600 }}>
                {pattern}
              </Typography>
            </Box>
          ))}
          <Box sx={{ width: 100, textAlign: 'center' }}>
            <Typography variant="caption" sx={{ fontWeight: 600 }}>
              Total
            </Typography>
          </Box>
        </Box>

        {data.heatmapData.map((equipment) => (
          <Box
            key={equipment.equipment}
            sx={{
              display: 'flex',
              mb: 1,
              alignItems: 'center',
              '&:hover': { bgcolor: 'action.hover' },
              borderRadius: 1,
              p: 0.5,
            }}
          >
            <Box sx={{ width: 150, display: 'flex', alignItems: 'center', gap: 1 }}>
              {getStatusIcon(equipment.status)}
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {equipment.equipment}
              </Typography>
            </Box>
            {patterns.map((pattern) => {
              const value = equipment.patterns[pattern];
              const intensity = value / maxValue;
              const bgColor = `rgba(0, 102, 204, ${intensity})`;

              return (
                <MuiTooltip
                  key={pattern}
                  title={`${pattern}: ${value} defects`}
                  arrow
                >
                  <Box
                    sx={{
                      flex: 1,
                      height: 40,
                      bgcolor: bgColor,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      mx: 0.5,
                      borderRadius: 0.5,
                      cursor: 'pointer',
                      border: 1,
                      borderColor: 'divider',
                    }}
                    onClick={() => setSelectedEquipment(equipment.equipment)}
                  >
                    <Typography
                      variant="caption"
                      sx={{
                        fontWeight: 600,
                        color: intensity > 0.5 ? 'white' : 'text.primary',
                      }}
                    >
                      {value}
                    </Typography>
                  </Box>
                </MuiTooltip>
              );
            })}
            <Box
              sx={{
                width: 100,
                textAlign: 'center',
                px: 1,
              }}
            >
              <Chip
                label={equipment.totalDefects}
                size="small"
                sx={{
                  bgcolor: getStatusColor(equipment.status),
                  color: 'white',
                  fontWeight: 600,
                }}
              />
            </Box>
          </Box>
        ))}

        {/* Legend */}
        <Box sx={{ mt: 3, display: 'flex', alignItems: 'center', gap: 2 }}>
          <Typography variant="caption">Defect Intensity:</Typography>
          <Box
            sx={{
              width: 200,
              height: 20,
              background: 'linear-gradient(to right, rgba(0, 102, 204, 0), rgba(0, 102, 204, 1))',
              borderRadius: 0.5,
              border: 1,
              borderColor: 'divider',
            }}
          />
          <Typography variant="caption">Low → High</Typography>
        </Box>
      </Box>
    );
  };

  const renderPerformanceChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={data.performanceData} layout="vertical">
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis type="number" domain={[0, 100]} />
        <YAxis dataKey="equipment" type="category" width={100} />
        <Tooltip />
        <Legend />
        <Bar dataKey="uptime" fill="#4caf50" name="Uptime (%)" />
        <Bar dataKey="efficiency" fill="#2196f3" name="Efficiency (%)" />
      </BarChart>
    </ResponsiveContainer>
  );

  const renderComparisonChart = () => {
    const comparisonData = data.heatmapData.map((eq) => ({
      equipment: eq.equipment,
      ...eq.patterns,
    }));

    const patterns = Object.keys(data.heatmapData[0].patterns);

    return (
      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={comparisonData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="equipment" />
          <YAxis />
          <Tooltip />
          <Legend />
          {patterns.map((pattern) => (
            <Bar
              key={pattern}
              dataKey={pattern}
              fill={PATTERN_COLORS[pattern] || '#8884d8'}
              stackId="a"
            />
          ))}
        </BarChart>
      </ResponsiveContainer>
    );
  };

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <Engineering color="primary" />
          <Typography variant="h6" sx={{ fontWeight: 600, flex: 1 }}>
            Equipment Correlation Analysis
          </Typography>
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Defect pattern correlation by equipment with performance metrics
        </Typography>

        {/* View Mode Selector */}
        <Box sx={{ mb: 3 }}>
          <ToggleButtonGroup
            value={viewMode}
            exclusive
            onChange={(_, value) => value && setViewMode(value)}
            size="small"
            fullWidth
          >
            <ToggleButton value="heatmap">
              Correlation Heatmap
            </ToggleButton>
            <ToggleButton value="performance">
              Performance Metrics
            </ToggleButton>
            <ToggleButton value="comparison">
              Equipment Comparison
            </ToggleButton>
          </ToggleButtonGroup>
        </Box>

        {/* Render Selected View */}
        {viewMode === 'heatmap' && renderHeatmap()}
        {viewMode === 'performance' && renderPerformanceChart()}
        {viewMode === 'comparison' && renderComparisonChart()}

        {/* Equipment Status Summary */}
        <Box sx={{ mt: 3, p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
            Equipment Status Summary
          </Typography>
          <Box sx={{ display: 'flex', gap: 3, mt: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <CheckCircle fontSize="small" color="success" />
              <Typography variant="body2">
                <strong>{data.heatmapData.filter((e) => e.status === 'good').length}</strong> Good
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Warning fontSize="small" color="warning" />
              <Typography variant="body2">
                <strong>{data.heatmapData.filter((e) => e.status === 'warning').length}</strong> Warning
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Warning fontSize="small" color="error" />
              <Typography variant="body2">
                <strong>{data.heatmapData.filter((e) => e.status === 'critical').length}</strong> Critical
              </Typography>
            </Box>
          </Box>
        </Box>

        {/* Selected Equipment Details */}
        {selectedEquipment && (
          <Box sx={{ mt: 2, p: 2, bgcolor: 'info.light', borderRadius: 1 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
              Selected: {selectedEquipment}
            </Typography>
            <Typography variant="body2">
              Click on heatmap cells to view detailed equipment analysis
            </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
}

// Mock data generator
function generateMockData() {
  const equipmentList = ['LITHO-001', 'LITHO-002', 'ETCH-001', 'ETCH-002', 'DEP-001', 'CMP-001'];
  const patterns = ['Edge Defect', 'Center Defect', 'Scratch', 'Ring', 'Random'];

  const heatmapData = equipmentList.map((equipment) => {
    const patternData: Record<string, number> = {};
    let total = 0;

    patterns.forEach((pattern) => {
      const value = Math.floor(Math.random() * 50) + 5;
      patternData[pattern] = value;
      total += value;
    });

    let status: 'good' | 'warning' | 'critical' = 'good';
    if (total > 150) status = 'critical';
    else if (total > 100) status = 'warning';

    return {
      equipment,
      patterns: patternData,
      totalDefects: total,
      status,
    };
  });

  const performanceData = equipmentList.map((equipment) => ({
    equipment,
    uptime: Number((Math.random() * 15 + 85).toFixed(1)),
    defectRate: Number((Math.random() * 5 + 2).toFixed(2)),
    efficiency: Number((Math.random() * 20 + 75).toFixed(1)),
  }));

  return { heatmapData, performanceData };
}
