import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Switch,
  FormControlLabel,
  Chip,
  IconButton,
  List,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Schedule as ScheduleIcon,
} from '@mui/icons-material';
import type { ReportSchedule, ReportTemplate } from '../types/report';

export interface ReportSchedulerProps {
  schedules: ReportSchedule[];
  templates: ReportTemplate[];
  onCreateSchedule: (schedule: Omit<ReportSchedule, 'id' | 'lastRun' | 'nextRun'>) => void;
  onUpdateSchedule: (scheduleId: string, updates: Partial<ReportSchedule>) => void;
  onDeleteSchedule: (scheduleId: string) => void;
}

const ReportScheduler: React.FC<ReportSchedulerProps> = ({
  schedules,
  templates,
  onCreateSchedule,
  onUpdateSchedule,
  onDeleteSchedule,
}) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<ReportSchedule | null>(null);
  const [formData, setFormData] = useState({
    templateId: '',
    frequency: 'daily' as ReportSchedule['frequency'],
    time: '09:00',
    recipients: '',
    enabled: true,
  });

  const handleOpenDialog = (schedule?: ReportSchedule) => {
    if (schedule) {
      setEditingSchedule(schedule);
      setFormData({
        templateId: schedule.templateId,
        frequency: schedule.frequency,
        time: schedule.time,
        recipients: schedule.recipients.join(', '),
        enabled: schedule.enabled,
      });
    } else {
      setEditingSchedule(null);
      setFormData({
        templateId: '',
        frequency: 'daily',
        time: '09:00',
        recipients: '',
        enabled: true,
      });
    }
    setDialogOpen(true);
  };

  const handleSave = () => {
    const recipients = formData.recipients
      .split(',')
      .map((email) => email.trim())
      .filter((email) => email);

    if (editingSchedule) {
      onUpdateSchedule(editingSchedule.id, {
        ...formData,
        recipients,
      });
    } else {
      onCreateSchedule({
        ...formData,
        recipients,
      });
    }
    setDialogOpen(false);
  };

  const getFrequencyLabel = (frequency: ReportSchedule['frequency']) => {
    return frequency.charAt(0).toUpperCase() + frequency.slice(1);
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h5" fontWeight={600}>
          Report Schedules
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          Create Schedule
        </Button>
      </Box>

      <List>
        {schedules.map((schedule) => {
          const template = templates.find((t) => t.id === schedule.templateId);
          return (
            <Card key={schedule.id} sx={{ mb: 2 }}>
              <CardContent>
                <Box display="flex" justifyContent="space-between" alignItems="start">
                  <Box flex={1}>
                    <Box display="flex" alignItems="center" gap={1} mb={1}>
                      <ScheduleIcon color="primary" />
                      <Typography variant="h6">{template?.name || 'Unknown Template'}</Typography>
                      <Chip
                        label={getFrequencyLabel(schedule.frequency)}
                        size="small"
                        color="primary"
                      />
                      <Chip
                        label={schedule.enabled ? 'Active' : 'Paused'}
                        size="small"
                        color={schedule.enabled ? 'success' : 'default'}
                      />
                    </Box>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Time: {schedule.time} • Recipients: {schedule.recipients.length}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {schedule.lastRun && `Last run: ${new Date(schedule.lastRun).toLocaleString()}`}
                      {' • '}
                      Next run: {new Date(schedule.nextRun).toLocaleString()}
                    </Typography>
                  </Box>
                  <Box display="flex" gap={1}>
                    <IconButton size="small" onClick={() => handleOpenDialog(schedule)}>
                      <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton size="small" onClick={() => onDeleteSchedule(schedule.id)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                    <Switch
                      checked={schedule.enabled}
                      onChange={(e) =>
                        onUpdateSchedule(schedule.id, { enabled: e.target.checked })
                      }
                    />
                  </Box>
                </Box>
              </CardContent>
            </Card>
          );
        })}
      </List>

      {schedules.length === 0 && (
        <Card>
          <CardContent>
            <Box textAlign="center" py={4}>
              <ScheduleIcon sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
              <Typography variant="h6" color="text.secondary" gutterBottom>
                No scheduled reports
              </Typography>
              <Typography variant="body2" color="text.secondary" mb={2}>
                Create a schedule to automatically generate and send reports
              </Typography>
              <Button variant="contained" startIcon={<AddIcon />} onClick={() => handleOpenDialog()}>
                Create First Schedule
              </Button>
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Schedule Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingSchedule ? 'Edit Schedule' : 'Create New Schedule'}
        </DialogTitle>
        <DialogContent>
          <TextField
            label="Report Template"
            fullWidth
            margin="normal"
            select
            value={formData.templateId}
            onChange={(e) => setFormData({ ...formData, templateId: e.target.value })}
          >
            {templates.map((template) => (
              <MenuItem key={template.id} value={template.id}>
                {template.name}
              </MenuItem>
            ))}
          </TextField>

          <TextField
            label="Frequency"
            fullWidth
            margin="normal"
            select
            value={formData.frequency}
            onChange={(e) =>
              setFormData({ ...formData, frequency: e.target.value as ReportSchedule['frequency'] })
            }
          >
            <MenuItem value="daily">Daily</MenuItem>
            <MenuItem value="weekly">Weekly</MenuItem>
            <MenuItem value="monthly">Monthly</MenuItem>
            <MenuItem value="custom">Custom</MenuItem>
          </TextField>

          <TextField
            label="Time"
            fullWidth
            margin="normal"
            type="time"
            value={formData.time}
            onChange={(e) => setFormData({ ...formData, time: e.target.value })}
            InputLabelProps={{ shrink: true }}
          />

          <TextField
            label="Recipients (comma-separated emails)"
            fullWidth
            margin="normal"
            multiline
            rows={3}
            value={formData.recipients}
            onChange={(e) => setFormData({ ...formData, recipients: e.target.value })}
            placeholder="user1@example.com, user2@example.com"
          />

          <FormControlLabel
            control={
              <Switch
                checked={formData.enabled}
                onChange={(e) => setFormData({ ...formData, enabled: e.target.checked })}
              />
            }
            label="Enable schedule"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button
            onClick={handleSave}
            variant="contained"
            disabled={!formData.templateId || !formData.recipients}
          >
            {editingSchedule ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ReportScheduler;
