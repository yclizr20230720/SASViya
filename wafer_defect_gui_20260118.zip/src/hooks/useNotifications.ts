import { useState, useCallback, useEffect } from 'react';

export interface Notification {
  id: string;
  type: 'error' | 'warning' | 'info' | 'success';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  actionUrl?: string;
}

export interface Toast {
  id: string;
  type: 'error' | 'warning' | 'info' | 'success';
  title?: string;
  message: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export const useNotifications = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Add notification
  const addNotification = useCallback((
    type: Notification['type'],
    title: string,
    message: string,
    actionUrl?: string
  ) => {
    const notification: Notification = {
      id: `notif-${Date.now()}-${Math.random()}`,
      type,
      title,
      message,
      timestamp: new Date().toISOString(),
      read: false,
      actionUrl,
    };
    setNotifications((prev) => [notification, ...prev]);
    return notification.id;
  }, []);

  // Add toast
  const addToast = useCallback((
    type: Toast['type'],
    message: string,
    title?: string,
    duration?: number,
    action?: Toast['action']
  ) => {
    const toast: Toast = {
      id: `toast-${Date.now()}-${Math.random()}`,
      type,
      title,
      message,
      duration: duration || 6000,
      action,
    };
    setToasts((prev) => [...prev, toast]);

    // Auto-remove toast after duration
    setTimeout(() => {
      removeToast(toast.id);
    }, toast.duration);

    return toast.id;
  }, []);

  // Remove toast
  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Mark notification as read
  const markAsRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  }, []);

  // Mark all notifications as read
  const markAllAsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  // Clear all notifications
  const clearAllNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  // Clear all toasts
  const clearAllToasts = useCallback(() => {
    setToasts([]);
  }, []);

  // Convenience methods
  const showSuccess = useCallback(
    (message: string, title?: string) => addToast('success', message, title),
    [addToast]
  );

  const showError = useCallback(
    (message: string, title?: string) => addToast('error', message, title, 8000),
    [addToast]
  );

  const showWarning = useCallback(
    (message: string, title?: string) => addToast('warning', message, title),
    [addToast]
  );

  const showInfo = useCallback(
    (message: string, title?: string) => addToast('info', message, title),
    [addToast]
  );

  return {
    notifications,
    toasts,
    addNotification,
    addToast,
    removeToast,
    markAsRead,
    markAllAsRead,
    clearAllNotifications,
    clearAllToasts,
    showSuccess,
    showError,
    showWarning,
    showInfo,
  };
};
