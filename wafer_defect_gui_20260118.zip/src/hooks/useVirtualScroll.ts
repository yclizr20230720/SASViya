import { useState, useCallback, useEffect } from 'react';

interface UseVirtualScrollOptions {
  itemsPerPage: number;
  totalItems: number;
}

interface UseVirtualScrollReturn {
  visibleItems: number;
  hasMore: boolean;
  loadMore: () => void;
  reset: () => void;
  isLoading: boolean;
}

/**
 * Hook for managing virtual scrolling with infinite loading
 * Progressively loads more items as user scrolls
 */
export function useVirtualScroll({
  itemsPerPage,
  totalItems,
}: UseVirtualScrollOptions): UseVirtualScrollReturn {
  const [visibleItems, setVisibleItems] = useState(itemsPerPage);
  const [isLoading, setIsLoading] = useState(false);

  const hasMore = visibleItems < totalItems;

  const loadMore = useCallback(() => {
    if (isLoading || !hasMore) return;

    setIsLoading(true);
    // Simulate async loading
    setTimeout(() => {
      setVisibleItems((prev) => Math.min(prev + itemsPerPage, totalItems));
      setIsLoading(false);
    }, 100);
  }, [isLoading, hasMore, itemsPerPage, totalItems]);

  const reset = useCallback(() => {
    setVisibleItems(itemsPerPage);
    setIsLoading(false);
  }, [itemsPerPage]);

  return {
    visibleItems,
    hasMore,
    loadMore,
    reset,
    isLoading,
  };
}

/**
 * Hook for detecting when user has scrolled near the bottom
 */
export function useScrollThreshold(
  threshold: number = 0.8,
  onThresholdReached: () => void
) {
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const scrollHeight = document.documentElement.scrollHeight;
      const clientHeight = document.documentElement.clientHeight;

      const scrollPercentage = (scrollTop + clientHeight) / scrollHeight;

      if (scrollPercentage >= threshold) {
        onThresholdReached();
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [threshold, onThresholdReached]);
}
