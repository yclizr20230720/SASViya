/**
 * Image optimization utilities for better performance
 */

/**
 * Preload images to cache them before they're needed
 */
export function preloadImages(urls: string[]): Promise<void[]> {
  const promises = urls.map((url) => {
    return new Promise<void>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve();
      img.onerror = () => reject(new Error(`Failed to load image: ${url}`));
      img.src = url;
    });
  });

  return Promise.all(promises);
}

/**
 * Convert image to WebP format if supported
 */
export function getOptimizedImageUrl(url: string): string {
  // Check if browser supports WebP
  const supportsWebP = document
    .createElement('canvas')
    .toDataURL('image/webp')
    .indexOf('data:image/webp') === 0;

  if (supportsWebP && !url.endsWith('.webp')) {
    // Replace extension with .webp if available
    return url.replace(/\.(jpg|jpeg|png)$/i, '.webp');
  }

  return url;
}

/**
 * Generate responsive image sources for different screen sizes
 */
export function generateResponsiveSources(
  baseUrl: string,
  widths: number[]
): Array<{ src: string; width: number }> {
  return widths.map((width) => ({
    src: `${baseUrl}?w=${width}`,
    width,
  }));
}

/**
 * Compress canvas to blob with quality control
 */
export function compressCanvas(
  canvas: HTMLCanvasElement,
  quality: number = 0.8,
  type: string = 'image/jpeg'
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) {
          resolve(blob);
        } else {
          reject(new Error('Failed to compress canvas'));
        }
      },
      type,
      quality
    );
  });
}

/**
 * Resize image to fit within max dimensions while maintaining aspect ratio
 */
export function resizeImage(
  file: File,
  maxWidth: number,
  maxHeight: number
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      reject(new Error('Failed to get canvas context'));
      return;
    }

    img.onload = () => {
      let { width, height } = img;

      // Calculate new dimensions
      if (width > maxWidth) {
        height = (height * maxWidth) / width;
        width = maxWidth;
      }
      if (height > maxHeight) {
        width = (width * maxHeight) / height;
        height = maxHeight;
      }

      canvas.width = width;
      canvas.height = height;
      ctx.drawImage(img, 0, 0, width, height);

      compressCanvas(canvas, 0.8)
        .then(resolve)
        .catch(reject);
    };

    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = URL.createObjectURL(file);
  });
}

/**
 * Create thumbnail from image file
 */
export function createThumbnail(
  file: File,
  size: number = 200
): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      reject(new Error('Failed to get canvas context'));
      return;
    }

    img.onload = () => {
      const scale = Math.min(size / img.width, size / img.height);
      const width = img.width * scale;
      const height = img.height * scale;

      canvas.width = width;
      canvas.height = height;
      ctx.drawImage(img, 0, 0, width, height);

      resolve(canvas.toDataURL('image/jpeg', 0.7));
    };

    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = URL.createObjectURL(file);
  });
}

/**
 * Check if image format is supported
 */
export function isSupportedImageFormat(file: File): boolean {
  const supportedFormats = [
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml',
  ];
  return supportedFormats.includes(file.type);
}

/**
 * Get optimal image quality based on file size
 */
export function getOptimalQuality(fileSize: number): number {
  // Larger files get more compression
  if (fileSize > 5 * 1024 * 1024) return 0.6; // > 5MB
  if (fileSize > 2 * 1024 * 1024) return 0.7; // > 2MB
  if (fileSize > 1 * 1024 * 1024) return 0.8; // > 1MB
  return 0.9; // < 1MB
}
