// Comprehensive metric definition library for semiconductor manufacturing

export interface MetricDefinition {
  id: string;
  name: string;
  category: 'quality' | 'performance' | 'yield' | 'efficiency' | 'reliability';
  description: string;
  formula: string;
  unit: string;
  importance: 'critical' | 'high' | 'medium' | 'low';
  interpretation: {
    good: string;
    warning: string;
    critical: string;
  };
  industryStandard?: {
    min?: number;
    max?: number;
    target?: number;
    benchmark?: string;
  };
  relatedMetrics: string[];
  calculationExample?: string;
}

export const metricDefinitions: Record<string, MetricDefinition> = {
  defectDensity: {
    id: 'defectDensity',
    name: 'Defect Density',
    category: 'quality',
    description: 'The number of defects per unit area on the wafer surface. A key indicator of manufacturing process quality and cleanliness.',
    formula: 'Defect Density = Total Defects / Wafer Area',
    unit: 'defects/cm²',
    importance: 'critical',
    interpretation: {
      good: 'Low defect density (<0.5 defects/cm²) indicates excellent process control and clean room conditions.',
      warning: 'Moderate defect density (0.5-1.0 defects/cm²) suggests potential process drift or contamination issues.',
      critical: 'High defect density (>1.0 defects/cm²) requires immediate investigation and corrective action.',
    },
    industryStandard: {
      target: 0.3,
      max: 1.0,
      benchmark: 'SEMI Standard: <0.5 defects/cm² for advanced nodes',
    },
    relatedMetrics: ['yieldRate', 'defectRate', 'patternDensity'],
    calculationExample: 'For a 300mm wafer (706.86 cm²) with 150 defects: 150 / 706.86 = 0.212 defects/cm²',
  },

  yieldRate: {
    id: 'yieldRate',
    name: 'Yield Rate',
    category: 'yield',
    description: 'Percentage of functional dies out of total dies on a wafer. The primary metric for manufacturing profitability.',
    formula: 'Yield Rate = (Good Dies / Total Dies) × 100%',
    unit: '%',
    importance: 'critical',
    interpretation: {
      good: 'High yield (>95%) indicates mature, stable manufacturing process with excellent quality control.',
      warning: 'Moderate yield (85-95%) suggests opportunities for process optimization and defect reduction.',
      critical: 'Low yield (<85%) indicates serious process issues requiring immediate attention.',
    },
    industryStandard: {
      target: 95,
      min: 85,
      benchmark: 'Industry average: 90-95% for mature processes',
    },
    relatedMetrics: ['defectDensity', 'diePerWafer', 'firstPassYield'],
  },

  defectRate: {
    id: 'defectRate',
    name: 'Defect Rate',
    category: 'quality',
    description: 'Percentage of wafers or dies with defects. Inverse indicator of manufacturing quality.',
    formula: 'Defect Rate = (Defective Units / Total Units) × 100%',
    unit: '%',
    importance: 'high',
    interpretation: {
      good: 'Low defect rate (<5%) demonstrates robust process control and quality assurance.',
      warning: 'Moderate defect rate (5-10%) indicates need for process improvement initiatives.',
      critical: 'High defect rate (>10%) signals systematic quality issues requiring root cause analysis.',
    },
    industryStandard: {
      target: 3,
      max: 10,
      benchmark: 'Six Sigma target: <3.4 defects per million opportunities',
    },
    relatedMetrics: ['defectDensity', 'yieldRate', 'escapeRate'],
  },

  processingTime: {
    id: 'processingTime',
    name: 'Processing Time',
    category: 'performance',
    description: 'Average time required to complete wafer processing through all manufacturing steps.',
    formula: 'Processing Time = Sum of Step Times / Number of Wafers',
    unit: 'hours',
    importance: 'high',
    interpretation: {
      good: 'Short processing time indicates efficient workflow and minimal bottlenecks.',
      warning: 'Extended processing time suggests potential equipment or scheduling issues.',
      critical: 'Excessive processing time impacts throughput and delivery commitments.',
    },
    industryStandard: {
      target: 48,
      max: 72,
      benchmark: 'Industry standard: 48-72 hours for typical process flows',
    },
    relatedMetrics: ['cycleTime', 'throughput', 'equipmentUtilization'],
  },

  patternRecognitionAccuracy: {
    id: 'patternRecognitionAccuracy',
    name: 'Pattern Recognition Accuracy',
    category: 'performance',
    description: 'Percentage of correctly identified defect patterns by the AI model. Measures model effectiveness.',
    formula: 'Accuracy = (Correct Predictions / Total Predictions) × 100%',
    unit: '%',
    importance: 'critical',
    interpretation: {
      good: 'High accuracy (>95%) indicates reliable AI model suitable for production use.',
      warning: 'Moderate accuracy (85-95%) suggests need for model retraining or additional data.',
      critical: 'Low accuracy (<85%) requires immediate model improvement or manual verification.',
    },
    industryStandard: {
      target: 95,
      min: 90,
      benchmark: 'Production-ready AI models: >95% accuracy',
    },
    relatedMetrics: ['modelConfidence', 'falsePositiveRate', 'falseNegativeRate'],
  },

  equipmentUptime: {
    id: 'equipmentUptime',
    name: 'Equipment Uptime',
    category: 'efficiency',
    description: 'Percentage of time equipment is operational and available for production.',
    formula: 'Uptime = (Operating Time / Total Time) × 100%',
    unit: '%',
    importance: 'high',
    interpretation: {
      good: 'High uptime (>95%) demonstrates excellent preventive maintenance and reliability.',
      warning: 'Moderate uptime (85-95%) indicates potential maintenance or reliability issues.',
      critical: 'Low uptime (<85%) severely impacts production capacity and requires intervention.',
    },
    industryStandard: {
      target: 95,
      min: 90,
      benchmark: 'World-class manufacturing: >95% equipment uptime',
    },
    relatedMetrics: ['meanTimeBetweenFailures', 'meanTimeToRepair', 'overallEquipmentEffectiveness'],
  },

  firstPassYield: {
    id: 'firstPassYield',
    name: 'First Pass Yield (FPY)',
    category: 'yield',
    description: 'Percentage of units passing all quality checks on the first attempt without rework.',
    formula: 'FPY = (Units Passing First Time / Total Units) × 100%',
    unit: '%',
    importance: 'critical',
    interpretation: {
      good: 'High FPY (>98%) indicates excellent process capability and minimal rework.',
      warning: 'Moderate FPY (90-98%) suggests opportunities to reduce rework and improve efficiency.',
      critical: 'Low FPY (<90%) indicates significant quality issues and high rework costs.',
    },
    industryStandard: {
      target: 98,
      min: 95,
      benchmark: 'Lean manufacturing target: >98% FPY',
    },
    relatedMetrics: ['yieldRate', 'reworkRate', 'scrapRate'],
  },

  cycleTime: {
    id: 'cycleTime',
    name: 'Cycle Time',
    category: 'performance',
    description: 'Total time from wafer start to completion, including processing and queue times.',
    formula: 'Cycle Time = Completion Time - Start Time',
    unit: 'days',
    importance: 'high',
    interpretation: {
      good: 'Short cycle time enables faster time-to-market and better customer responsiveness.',
      warning: 'Extended cycle time may indicate bottlenecks or inefficient scheduling.',
      critical: 'Excessive cycle time impacts competitiveness and customer satisfaction.',
    },
    industryStandard: {
      target: 30,
      max: 45,
      benchmark: 'Industry average: 30-45 days for advanced processes',
    },
    relatedMetrics: ['processingTime', 'queueTime', 'throughput'],
  },

  overallEquipmentEffectiveness: {
    id: 'overallEquipmentEffectiveness',
    name: 'Overall Equipment Effectiveness (OEE)',
    category: 'efficiency',
    description: 'Composite metric measuring equipment availability, performance, and quality.',
    formula: 'OEE = Availability × Performance × Quality',
    unit: '%',
    importance: 'critical',
    interpretation: {
      good: 'World-class OEE (>85%) indicates optimal equipment utilization and productivity.',
      warning: 'Average OEE (65-85%) suggests room for improvement in one or more factors.',
      critical: 'Low OEE (<65%) requires comprehensive analysis and improvement initiatives.',
    },
    industryStandard: {
      target: 85,
      min: 65,
      benchmark: 'World-class: >85%, Industry average: 60-65%',
    },
    relatedMetrics: ['equipmentUptime', 'throughput', 'yieldRate'],
  },

  meanTimeBetweenFailures: {
    id: 'meanTimeBetweenFailures',
    name: 'Mean Time Between Failures (MTBF)',
    category: 'reliability',
    description: 'Average time between equipment failures. Key reliability indicator.',
    formula: 'MTBF = Total Operating Time / Number of Failures',
    unit: 'hours',
    importance: 'high',
    interpretation: {
      good: 'High MTBF (>1000 hours) indicates reliable equipment with good maintenance.',
      warning: 'Moderate MTBF (500-1000 hours) suggests need for preventive maintenance review.',
      critical: 'Low MTBF (<500 hours) indicates poor reliability requiring immediate attention.',
    },
    industryStandard: {
      target: 1000,
      min: 500,
      benchmark: 'Semiconductor equipment: >1000 hours MTBF',
    },
    relatedMetrics: ['meanTimeToRepair', 'equipmentUptime', 'maintenanceCost'],
  },
};

export const metricCategories = {
  quality: {
    name: 'Quality Metrics',
    description: 'Metrics measuring product quality and defect levels',
    icon: 'CheckCircle',
  },
  performance: {
    name: 'Performance Metrics',
    description: 'Metrics measuring system and process performance',
    icon: 'Speed',
  },
  yield: {
    name: 'Yield Metrics',
    description: 'Metrics measuring manufacturing yield and productivity',
    icon: 'TrendingUp',
  },
  efficiency: {
    name: 'Efficiency Metrics',
    description: 'Metrics measuring resource utilization and efficiency',
    icon: 'Insights',
  },
  reliability: {
    name: 'Reliability Metrics',
    description: 'Metrics measuring equipment and process reliability',
    icon: 'Verified',
  },
};

export function getMetricsByCategory(category: string): MetricDefinition[] {
  return Object.values(metricDefinitions).filter((m) => m.category === category);
}

export function getRelatedMetrics(metricId: string): MetricDefinition[] {
  const metric = metricDefinitions[metricId];
  if (!metric) return [];
  
  return metric.relatedMetrics
    .map((id) => metricDefinitions[id])
    .filter((m) => m !== undefined);
}

export function getMetricInterpretation(
  metricId: string,
  value: number
): { level: 'good' | 'warning' | 'critical'; text: string } {
  const metric = metricDefinitions[metricId];
  if (!metric) return { level: 'warning', text: 'Unknown metric' };

  const { industryStandard, interpretation } = metric;
  
  if (!industryStandard) {
    return { level: 'warning', text: interpretation.warning };
  }

  // Determine level based on thresholds
  if (industryStandard.target !== undefined) {
    const tolerance = industryStandard.target * 0.1; // 10% tolerance
    if (Math.abs(value - industryStandard.target) <= tolerance) {
      return { level: 'good', text: interpretation.good };
    }
  }

  if (industryStandard.min !== undefined && value < industryStandard.min) {
    return { level: 'critical', text: interpretation.critical };
  }

  if (industryStandard.max !== undefined && value > industryStandard.max) {
    return { level: 'critical', text: interpretation.critical };
  }

  return { level: 'warning', text: interpretation.warning };
}
