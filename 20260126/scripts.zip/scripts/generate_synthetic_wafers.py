"""
Generate Synthetic Wafer Maps using Trained GAN

Usage:
    python scripts/generate_synthetic_wafers.py --checkpoint checkpoints/gan/gan_final.pth --num-samples 100
"""
import sys
import os
from pathlib import Path

# Add app directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import torch
import numpy as np
from PIL import Image
import argparse
import json
from datetime import datetime

from app.ml.gan import WaferGAN
from app.ml.model import PATTERN_CLASSES


def save_image(tensor: torch.Tensor, path: str):
    """Save tensor as image"""
    # Convert from (C, H, W) to (H, W, C)
    img = tensor.permute(1, 2, 0).cpu().numpy()
    
    # Denormalize from [0, 1] to [0, 255]
    img = (img * 255).astype(np.uint8)
    
    # Save
    Image.fromarray(img).save(path)


def main():
    parser = argparse.ArgumentParser(description='Generate Synthetic Wafer Maps')
    
    # Model arguments
    parser.add_argument('--checkpoint', type=str, required=True,
                        help='Path to trained GAN checkpoint')
    parser.add_argument('--noise-dim', type=int, default=100,
                        help='Dimension of noise vector')
    parser.add_argument('--img-size', type=int, default=224,
                        help='Image size')
    
    # Generation arguments
    parser.add_argument('--num-samples', type=int, default=100,
                        help='Number of synthetic samples to generate')
    parser.add_argument('--pattern', type=str, default=None,
                        choices=PATTERN_CLASSES + [None],
                        help='Specific pattern to generate (default: random)')
    parser.add_argument('--defect-density', type=float, default=None,
                        help='Defect density (0.0-1.0, default: random)')
    parser.add_argument('--batch-size', type=int, default=32,
                        help='Batch size for generation')
    
    # Output arguments
    parser.add_argument('--output-dir', type=str, default='data/synthetic',
                        help='Directory to save generated images')
    parser.add_argument('--save-metadata', action='store_true',
                        help='Save metadata JSON file')
    
    # Device arguments
    parser.add_argument('--device', type=str, default='cuda',
                        choices=['cuda', 'cpu'],
                        help='Device to use')
    
    args = parser.parse_args()
    
    # Set device
    if args.device == 'cuda' and not torch.cuda.is_available():
        print("CUDA not available, using CPU")
        args.device = 'cpu'
    
    print("="*60)
    print("SYNTHETIC WAFER MAP GENERATION")
    print("="*60)
    print(f"Checkpoint: {args.checkpoint}")
    print(f"Number of samples: {args.num_samples}")
    print(f"Pattern: {args.pattern if args.pattern else 'Random'}")
    print(f"Defect density: {args.defect_density if args.defect_density else 'Random'}")
    print(f"Output directory: {args.output_dir}")
    print(f"Device: {args.device}")
    print("="*60)
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Initialize GAN
    print("\nInitializing GAN...")
    gan = WaferGAN(
        noise_dim=args.noise_dim,
        num_patterns=len(PATTERN_CLASSES),
        img_size=args.img_size,
        device=args.device
    )
    
    # Load checkpoint
    print(f"Loading checkpoint: {args.checkpoint}")
    gan.load(args.checkpoint)
    
    # Generate samples
    print(f"\nGenerating {args.num_samples} synthetic wafer maps...")
    
    metadata = []
    num_generated = 0
    
    while num_generated < args.num_samples:
        # Determine batch size
        current_batch_size = min(args.batch_size, args.num_samples - num_generated)
        
        # Generate pattern labels
        if args.pattern:
            pattern_idx = PATTERN_CLASSES.index(args.pattern)
            pattern_labels = torch.full((current_batch_size,), pattern_idx, dtype=torch.long, device=args.device)
        else:
            pattern_labels = torch.randint(0, len(PATTERN_CLASSES), (current_batch_size,), device=args.device)
        
        # Generate defect densities
        if args.defect_density is not None:
            defect_density = torch.full((current_batch_size, 1), args.defect_density, device=args.device)
        else:
            defect_density = torch.rand(current_batch_size, 1, device=args.device)
        
        # Generate images
        fake_images = gan.generate(pattern_labels, defect_density, num_samples=current_batch_size)
        
        # Save images
        for i in range(current_batch_size):
            sample_idx = num_generated + i
            pattern_name = PATTERN_CLASSES[pattern_labels[i].item()]
            density_value = defect_density[i].item()
            
            # Generate filename
            filename = f"synthetic_{sample_idx:04d}_{pattern_name}_{density_value:.3f}.png"
            filepath = output_dir / filename
            
            # Save image
            save_image(fake_images[i], str(filepath))
            
            # Add to metadata
            if args.save_metadata:
                metadata.append({
                    'filename': filename,
                    'pattern': pattern_name,
                    'defect_density': density_value,
                    'generated_at': datetime.now().isoformat(),
                    'model_checkpoint': args.checkpoint
                })
            
            # Progress
            if (sample_idx + 1) % 10 == 0:
                print(f"  Generated {sample_idx + 1}/{args.num_samples} samples...")
        
        num_generated += current_batch_size
    
    print(f"\n✓ Generated {num_generated} synthetic wafer maps")
    print(f"✓ Saved to: {output_dir}")
    
    # Save metadata
    if args.save_metadata:
        metadata_file = output_dir / 'synthetic_metadata.json'
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        print(f"✓ Metadata saved to: {metadata_file}")
    
    # Print pattern distribution
    if args.save_metadata:
        pattern_counts = {}
        for item in metadata:
            pattern = item['pattern']
            pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
        
        print("\nPattern Distribution:")
        for pattern, count in sorted(pattern_counts.items()):
            print(f"  {pattern}: {count} ({count/len(metadata)*100:.1f}%)")


if __name__ == '__main__':
    main()
