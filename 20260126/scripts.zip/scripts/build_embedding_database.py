"""
Build embedding database for similar case retrieval

This script extracts feature embeddings for all wafers in the system
and saves them to a JSON file for fast similarity search.

Usage:
    python scripts/build_embedding_database.py --model checkpoints/best_model.pth
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import argparse
import json
import torch
from pathlib import Path

from app.ml.model import WaferDefectModel
from app.ml.explainability import build_embedding_database
from app.utils.json_storage import JSONStorage
from config import Config


def main():
    parser = argparse.ArgumentParser(description='Build embedding database for similar case retrieval')
    parser.add_argument(
        '--model',
        type=str,
        default='checkpoints/best_model.pth',
        help='Path to trained model checkpoint'
    )
    parser.add_argument(
        '--output',
        type=str,
        default='data/metadata/embedding_database.json',
        help='Output path for embedding database'
    )
    parser.add_argument(
        '--device',
        type=str,
        default='cuda' if torch.cuda.is_available() else 'cpu',
        help='Device to use (cuda or cpu)'
    )
    parser.add_argument(
        '--batch-size',
        type=int,
        default=32,
        help='Batch size for processing'
    )
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("Building Embedding Database for Similar Case Retrieval")
    print("=" * 80)
    print(f"Model: {args.model}")
    print(f"Output: {args.output}")
    print(f"Device: {args.device}")
    print()
    
    # Check if model exists
    if not os.path.exists(args.model):
        print(f"Error: Model not found at {args.model}")
        print("Please train a model first using scripts/train_model.py")
        return 1
    
    # Load model
    print("Loading model...")
    checkpoint = torch.load(args.model, map_location=args.device)
    
    model = WaferDefectModel(
        num_pattern_classes=10,
        num_root_cause_classes=8
    )
    model.load_state_dict(checkpoint['model_state_dict'])
    model.to(args.device)
    model.eval()
    
    print(f"  Model loaded from epoch {checkpoint.get('epoch', 'unknown')}")
    print()
    
    # Load wafer data
    print("Loading wafer data...")
    storage = JSONStorage(Config.METADATA_FOLDER)
    wafers = storage.find('wafers.json')
    
    if not wafers or len(wafers) == 0:
        print("Error: No wafers found in database")
        print("Please upload wafers first")
        return 1
    
    print(f"  Found {len(wafers)} wafers")
    print()
    
    # Filter wafers with valid image paths
    valid_wafers = []
    for wafer in wafers:
        image_path = wafer.get('image_path')
        if image_path and os.path.exists(image_path):
            valid_wafers.append({
                'wafer_id': wafer['wafer_id'],
                'image_path': image_path
            })
    
    print(f"  {len(valid_wafers)} wafers have valid images")
    print()
    
    if len(valid_wafers) == 0:
        print("Error: No wafers with valid images found")
        return 1
    
    # Build embedding database
    print("Extracting embeddings...")
    embedding_db = build_embedding_database(
        model=model,
        wafer_data=valid_wafers,
        device=args.device
    )
    
    print()
    print(f"Embedding database built: {len(embedding_db)} wafers")
    print()
    
    # Convert numpy arrays to lists for JSON serialization
    embedding_db_serializable = {
        wafer_id: embedding.tolist()
        for wafer_id, embedding in embedding_db.items()
    }
    
    # Save to JSON
    print(f"Saving to {args.output}...")
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    with open(args.output, 'w') as f:
        json.dump(embedding_db_serializable, f, indent=2)
    
    print("  Saved successfully")
    print()
    
    # Print statistics
    embedding_dim = len(next(iter(embedding_db.values())))
    print("Statistics:")
    print(f"  Total wafers: {len(embedding_db)}")
    print(f"  Embedding dimension: {embedding_dim}")
    print(f"  Database size: {os.path.getsize(args.output) / 1024 / 1024:.2f} MB")
    print()
    
    print("=" * 80)
    print("Embedding database built successfully!")
    print("=" * 80)
    print()
    print("You can now use the /api/v1/inference/explain/<wafer_id> endpoint")
    print("with include_similar=true to find similar cases.")
    print()
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
