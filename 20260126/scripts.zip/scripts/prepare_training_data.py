"""
Prepare labeled training data for wafer defect pattern recognition

This script creates a labeled dataset from the available wafer images
by inferring pattern types from filenames and creating a metadata file.
"""
import json
import os
from pathlib import Path

# Pattern class names (10 classes)
PATTERN_CLASSES = [
    'Center',      # Defects concentrated at wafer center
    'Donut',       # Ring-shaped defect pattern
    'Edge-Ring',   # Defects along wafer edge
    'Edge-Loc',    # Localized edge defects
    'Loc',         # Localized cluster anywhere
    'Random',      # Randomly distributed defects
    'Scratch',     # Linear scratch patterns
    'Near-Full',   # Nearly complete wafer coverage
    'None',        # No significant defects
    'Mixed'        # Multiple pattern types
]

# Root cause class names (8 classes)
ROOT_CAUSE_CLASSES = [
    'Lithography Issues',      # Exposure, focus, alignment
    'CVD Process Variation',   # Chemical vapor deposition
    'CMP Non-uniformity',      # Chemical mechanical polishing
    'Etch Process Drift',      # Etching parameter variations
    'Particle Contamination',  # Foreign material
    'Equipment Malfunction',   # Tool-related defects
    'Material Defects',        # Substrate or material issues
    'Unknown'                  # Cannot determine root cause
]

def infer_pattern_from_filename(filename):
    """Infer pattern class from filename"""
    filename_lower = filename.lower()
    
    if 'center' in filename_lower:
        return 'Center', 'CVD Process Variation'
    elif 'donut' in filename_lower:
        return 'Donut', 'CMP Non-uniformity'
    elif 'edge_ring' in filename_lower or 'edge-ring' in filename_lower:
        return 'Edge-Ring', 'Etch Process Drift'
    elif 'edge_loc' in filename_lower or 'edge-loc' in filename_lower:
        return 'Edge-Loc', 'Equipment Malfunction'
    elif 'loc' in filename_lower and 'edge' not in filename_lower:
        return 'Loc', 'Particle Contamination'
    elif 'random' in filename_lower:
        return 'Random', 'Material Defects'
    elif 'scratch' in filename_lower or 'scrach' in filename_lower:
        return 'Scratch', 'Equipment Malfunction'
    elif 'near_full' in filename_lower or 'near-full' in filename_lower:
        return 'Near-Full', 'Lithography Issues'
    elif 'none' in filename_lower:
        return 'None', 'Unknown'
    else:
        return 'Mixed', 'Unknown'

def create_labeled_dataset():
    """Create labeled dataset metadata file"""
    
    # Base directory
    base_dir = Path(__file__).parent.parent
    image_dir = base_dir / 'data' / 'wafer_images'
    output_dir = base_dir / 'data' / 'processed'
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Get all image files
    image_files = list(image_dir.glob('*.png')) + list(image_dir.glob('*.jpg'))
    
    print(f"Found {len(image_files)} wafer images")
    
    # Create labeled dataset
    labeled_data = []
    
    for image_file in image_files:
        # Infer pattern and root cause from filename
        pattern_class, root_cause = infer_pattern_from_filename(image_file.name)
        
        # Create record
        record = {
            'wafer_id': image_file.stem,
            'image_filename': image_file.name,
            'image_path': str(image_file.absolute()),
            'pattern_class': pattern_class,
            'root_cause': root_cause
        }
        
        labeled_data.append(record)
        print(f"  {image_file.name} -> Pattern: {pattern_class}, Root Cause: {root_cause}")
    
    # Save labeled dataset
    output_file = output_dir / 'labeled_wafers.json'
    with open(output_file, 'w') as f:
        json.dump(labeled_data, f, indent=2)
    
    print(f"\n✅ Created labeled dataset: {output_file}")
    print(f"   Total samples: {len(labeled_data)}")
    
    # Print pattern distribution
    pattern_counts = {}
    for record in labeled_data:
        pattern = record['pattern_class']
        pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
    
    print("\n📊 Pattern Distribution:")
    for pattern, count in sorted(pattern_counts.items()):
        print(f"   {pattern}: {count}")
    
    return output_file

if __name__ == '__main__':
    create_labeled_dataset()
