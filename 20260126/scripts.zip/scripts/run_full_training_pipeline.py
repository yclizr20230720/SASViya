"""
Complete training pipeline for wafer defect pattern recognition

This script runs the full training pipeline:
1. Load labeled data
2. Generate synthetic augmented samples
3. Split into train/val/test
4. Train the model
5. Evaluate performance
"""
import sys
import os
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import json
import torch
import argparse
from app.ml.model import WaferDefectModel, PATTERN_CLASSES, ROOT_CAUSE_CLASSES
from app.ml.dataset import WaferDefectDataset, create_data_loaders
from app.ml.train import WaferTrainer
from app.ml.loss import MultiTaskLoss, MultiTaskFocalLoss

def main():
    parser = argparse.ArgumentParser(description='Train wafer defect pattern recognition model')
    parser.add_argument('--data_file', type=str, default='data/processed/labeled_wafers.json',
                        help='Path to labeled dataset JSON file')
    parser.add_argument('--epochs', type=int, default=50,
                        help='Number of training epochs (default: 50 for small dataset)')
    parser.add_argument('--batch_size', type=int, default=4,
                        help='Batch size (default: 4 for small dataset)')
    parser.add_argument('--learning_rate', type=float, default=0.0001,
                        help='Learning rate')
    parser.add_argument('--use_focal_loss', action='store_true',
                        help='Use focal loss for class imbalance')
    parser.add_argument('--augmentation', type=str, default='strong', choices=['light', 'medium', 'strong'],
                        help='Augmentation strength')
    parser.add_argument('--output_dir', type=str, default='checkpoints',
                        help='Output directory for checkpoints')
    parser.add_argument('--log_dir', type=str, default='logs',
                        help='Directory for TensorBoard logs')
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu',
                        help='Device to use (cuda/cpu)')
    parser.add_argument('--early_stopping_patience', type=int, default=10,
                        help='Early stopping patience')
    
    args = parser.parse_args()
    
    print("="*80)
    print("WAFER DEFECT PATTERN RECOGNITION - TRAINING PIPELINE")
    print("="*80)
    print(f"\n📋 Configuration:")
    print(f"   Data file: {args.data_file}")
    print(f"   Epochs: {args.epochs}")
    print(f"   Batch size: {args.batch_size}")
    print(f"   Learning rate: {args.learning_rate}")
    print(f"   Device: {args.device}")
    print(f"   Focal loss: {args.use_focal_loss}")
    print(f"   Augmentation: {args.augmentation}")
    
    # Check if CUDA is available
    if args.device == 'cuda' and not torch.cuda.is_available():
        print("\n⚠️  CUDA not available, falling back to CPU")
        args.device = 'cpu'
    
    # Load labeled dataset
    print(f"\n📂 Loading dataset from {args.data_file}...")
    with open(args.data_file, 'r') as f:
        labeled_data = json.load(f)
    
    print(f"   Total samples: {len(labeled_data)}")
    
    # Check dataset size
    if len(labeled_data) < 10:
        print("\n⚠️  WARNING: Very small dataset detected!")
        print("   For production use, you need at least 100+ samples per class.")
        print("   This training is for demonstration purposes only.")
        print("   Consider:")
        print("   1. Collecting more real wafer data")
        print("   2. Using data augmentation (enabled by default)")
        print("   3. Implementing GAN for synthetic data generation")
    
    # Split dataset
    print(f"\n🔄 Splitting dataset...")
    from app.ml.dataset import split_dataset
    
    split_dir = Path('data/processed/splits')
    train_metadata, val_metadata, test_metadata = split_dataset(
        metadata_file=args.data_file,
        output_dir=str(split_dir),
        train_ratio=0.7,
        val_ratio=0.15,
        test_ratio=0.15,
        seed=42
    )
    
    # Create datasets
    print(f"\n🔄 Creating datasets...")
    from app.ml.dataset import WaferDefectDataset
    from app.ml.preprocessing import WaferAugmentation
    from torch.utils.data import DataLoader
    
    # Get image directory from first sample
    image_dir = Path(labeled_data[0]['image_path']).parent
    
    train_dataset = WaferDefectDataset(
        data_dir=str(image_dir),
        metadata_file=train_metadata,
        augmentation=WaferAugmentation(args.augmentation) if args.augmentation != 'light' else None
    )
    
    val_dataset = WaferDefectDataset(
        data_dir=str(image_dir),
        metadata_file=val_metadata,
        augmentation=None
    )
    
    test_dataset = WaferDefectDataset(
        data_dir=str(image_dir),
        metadata_file=test_metadata,
        augmentation=None
    )
    
    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=0,  # Windows compatibility
        pin_memory=False
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=False
    )
    
    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=False
    )
    
    print(f"   Train samples: {len(train_dataset)}, batches: {len(train_loader)}")
    print(f"   Val samples: {len(val_dataset)}, batches: {len(val_loader)}")
    print(f"   Test samples: {len(test_dataset)}, batches: {len(test_loader)}")
    
    # Create model
    print(f"\n🤖 Creating model...")
    model = WaferDefectModel(
        num_pattern_classes=len(PATTERN_CLASSES),
        num_root_cause_classes=len(ROOT_CAUSE_CLASSES),
        dropout=0.3,
        pretrained=True
    )
    
    print(f"   Model: EfficientNet-B3 Multi-Task")
    print(f"   Pattern classes: {len(PATTERN_CLASSES)}")
    print(f"   Root cause classes: {len(ROOT_CAUSE_CLASSES)}")
    print(f"   Parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    # Create trainer
    print(f"\n🏋️  Initializing trainer...")
    trainer = WaferTrainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        device=args.device,
        learning_rate=args.learning_rate,
        use_focal_loss=args.use_focal_loss,
        output_dir=args.output_dir,
        log_dir=args.log_dir
    )
    
    # Start training
    print(f"\n🚀 Starting training...")
    print(f"   Monitor progress: tensorboard --logdir {args.log_dir}")
    print()
    
    try:
        history = trainer.train(
            epochs=args.epochs,
            early_stopping_patience=args.early_stopping_patience,
            save_best_only=True
        )
        
        print(f"\n✅ Training completed successfully!")
        print(f"   Best validation accuracy: {trainer.best_val_acc:.3f}")
        print(f"   Model saved to: {args.output_dir}/best_model.pth")
        
        # Evaluate on test set
        if len(test_loader) > 0:
            print(f"\n📊 Evaluating on test set...")
            test_metrics = trainer.validate_epoch()
            print(f"   Test Loss: {test_metrics['loss']:.4f}")
            print(f"   Test Pattern Accuracy: {test_metrics['pattern_accuracy']:.3f}")
            print(f"   Test Root Cause Accuracy: {test_metrics['root_cause_accuracy']:.3f}")
        
        print(f"\n🎉 Training pipeline completed!")
        print(f"\n📝 Next steps:")
        print(f"   1. View training curves: tensorboard --logdir {args.log_dir}")
        print(f"   2. Evaluate model: python scripts/evaluate_model.py --model {args.output_dir}/best_model.pth")
        print(f"   3. Run inference: Use WaferInferenceEngine with the trained model")
        
    except KeyboardInterrupt:
        print(f"\n\n⚠️  Training interrupted by user")
        print(f"   Checkpoint saved to: {args.output_dir}")
    except Exception as e:
        print(f"\n\n❌ Training failed with error:")
        print(f"   {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main()
