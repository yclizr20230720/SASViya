"""
Command-line script for training wafer defect pattern recognition model

Usage:
    python scripts/train_model.py --data_dir data/processed --epochs 100
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import argparse
import torch
from pathlib import Path

from app.ml.model import WaferDefectModel
from app.ml.dataset import create_data_loaders
from app.ml.train import WaferTrainer


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description='Train wafer defect pattern recognition model'
    )
    
    # Data arguments
    parser.add_argument('--data_dir', type=str, default=None,
                       help='Directory containing train/val/test subdirectories')
    parser.add_argument('--train_metadata', type=str, default=None,
                       help='Path to training metadata JSON file')
    parser.add_argument('--val_metadata', type=str, default=None,
                       help='Path to validation metadata JSON file')
    parser.add_argument('--test_metadata', type=str, default=None,
                       help='Path to test metadata JSON file (optional)')
    
    # Model arguments
    parser.add_argument('--model', type=str, default='efficientnet-b3',
                       choices=['efficientnet-b3', 'efficientnet-b4'],
                       help='Model architecture')
    parser.add_argument('--pretrained', action='store_true', default=True,
                       help='Use pretrained weights')
    parser.add_argument('--dropout', type=float, default=0.3,
                       help='Dropout rate')
    
    # Training arguments
    parser.add_argument('--epochs', type=int, default=100,
                       help='Number of training epochs')
    parser.add_argument('--batch_size', type=int, default=32,
                       help='Batch size')
    parser.add_argument('--learning_rate', type=float, default=1e-4,
                       help='Initial learning rate')
    parser.add_argument('--weight_decay', type=float, default=1e-5,
                       help='Weight decay (L2 regularization)')
    parser.add_argument('--num_workers', type=int, default=4,
                       help='Number of data loading workers')
    
    # Loss arguments
    parser.add_argument('--use_focal_loss', action='store_true',
                       help='Use focal loss for class imbalance')
    parser.add_argument('--focal_alpha', type=float, default=0.25,
                       help='Focal loss alpha parameter')
    parser.add_argument('--focal_gamma', type=float, default=2.0,
                       help='Focal loss gamma parameter')
    
    # Augmentation arguments
    parser.add_argument('--augmentation', type=str, default='medium',
                       choices=['light', 'medium', 'strong'],
                       help='Data augmentation level')
    
    # Training control
    parser.add_argument('--early_stopping_patience', type=int, default=15,
                       help='Early stopping patience')
    parser.add_argument('--save_best_only', action='store_true', default=True,
                       help='Only save best model')
    
    # Output arguments
    parser.add_argument('--output_dir', type=str, default='checkpoints',
                       help='Directory for saving checkpoints')
    parser.add_argument('--log_dir', type=str, default='logs',
                       help='Directory for TensorBoard logs')
    
    # Device arguments
    parser.add_argument('--device', type=str, default='cuda',
                       choices=['cuda', 'cpu'],
                       help='Device to use for training')
    parser.add_argument('--gpu', type=int, default=0,
                       help='GPU device ID')
    
    # Resume training
    parser.add_argument('--resume', type=str, default=None,
                       help='Path to checkpoint to resume from')
    
    return parser.parse_args()


def main():
    """Main training function"""
    args = parse_args()
    
    # Set device
    if args.device == 'cuda' and torch.cuda.is_available():
        device = f'cuda:{args.gpu}'
        print(f"Using GPU: {torch.cuda.get_device_name(args.gpu)}")
    else:
        device = 'cpu'
        print("Using CPU")
    
    # Create data loaders
    print("\nLoading datasets...")
    
    # Determine metadata file paths
    if args.train_metadata and args.val_metadata:
        # Direct metadata file paths provided
        train_metadata = args.train_metadata
        val_metadata = args.val_metadata
        test_metadata = args.test_metadata
    elif args.data_dir:
        # Use data_dir with default filenames
        data_dir = Path(args.data_dir)
        train_metadata = str(data_dir / 'train.json')
        val_metadata = str(data_dir / 'val.json')
        test_metadata = str(data_dir / 'test.json')
    else:
        raise ValueError("Either --train_metadata and --val_metadata OR --data_dir must be provided")
    
    train_loader, val_loader, test_loader = create_data_loaders(
        train_metadata=train_metadata,
        val_metadata=val_metadata,
        test_metadata=test_metadata,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        augmentation_level=args.augmentation
    )
    
    print(f"  Train samples: {len(train_loader.dataset)}")
    print(f"  Val samples: {len(val_loader.dataset)}")
    print(f"  Test samples: {len(test_loader.dataset)}")
    
    # Create model
    print("\nCreating model...")
    model = WaferDefectModel(
        num_pattern_classes=10,
        num_root_cause_classes=8,
        dropout=args.dropout,
        pretrained=args.pretrained
    )
    
    # Create trainer
    trainer = WaferTrainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        device=device,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        use_focal_loss=args.use_focal_loss,
        focal_alpha=args.focal_alpha,
        focal_gamma=args.focal_gamma,
        output_dir=args.output_dir,
        log_dir=args.log_dir
    )
    
    # Resume from checkpoint if specified
    if args.resume:
        print(f"\nResuming from checkpoint: {args.resume}")
        trainer.load_checkpoint(args.resume)
    
    # Train model
    history = trainer.train(
        epochs=args.epochs,
        early_stopping_patience=args.early_stopping_patience,
        save_best_only=args.save_best_only
    )
    
    print("\nTraining completed!")
    print(f"Best validation accuracy: {trainer.best_val_acc:.3f}")
    print(f"Checkpoints saved to: {args.output_dir}")
    print(f"TensorBoard logs saved to: {args.log_dir}")
    print(f"\nTo view training progress:")
    print(f"  tensorboard --logdir {args.log_dir}")


if __name__ == '__main__':
    main()
