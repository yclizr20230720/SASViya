"""
GAN Training Script for Synthetic Wafer Map Generation

Usage:
    python scripts/train_gan.py --epochs 100 --batch-size 32
"""
import sys
import os
from pathlib import Path

# Add app directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import torch
from torch.utils.data import DataLoader
import argparse

from app.ml.gan import WaferGAN, train_gan
from app.ml.dataset import WaferDefectDataset
from app.ml.preprocessing import WaferPreprocessor


def main():
    parser = argparse.ArgumentParser(description='Train Conditional WGAN-GP for Wafer Maps')
    
    # Data arguments
    parser.add_argument('--data-dir', type=str, default='data/processed',
                        help='Directory containing processed training data')
    parser.add_argument('--split', type=str, default='train',
                        choices=['train', 'val', 'all'],
                        help='Dataset split to use')
    
    # Model arguments
    parser.add_argument('--noise-dim', type=int, default=100,
                        help='Dimension of noise vector')
    parser.add_argument('--img-size', type=int, default=224,
                        help='Image size (224x224)')
    
    # Training arguments
    parser.add_argument('--epochs', type=int, default=100,
                        help='Number of training epochs')
    parser.add_argument('--batch-size', type=int, default=32,
                        help='Batch size')
    parser.add_argument('--n-critic', type=int, default=5,
                        help='Number of critic iterations per generator iteration')
    parser.add_argument('--lambda-gp', type=float, default=10.0,
                        help='Gradient penalty weight')
    parser.add_argument('--lr', type=float, default=0.0001,
                        help='Learning rate')
    
    # Checkpoint arguments
    parser.add_argument('--checkpoint-dir', type=str, default='checkpoints/gan',
                        help='Directory to save checkpoints')
    parser.add_argument('--save-interval', type=int, default=10,
                        help='Save checkpoint every N epochs')
    parser.add_argument('--resume', type=str, default=None,
                        help='Path to checkpoint to resume from')
    
    # Device arguments
    parser.add_argument('--device', type=str, default='cuda',
                        choices=['cuda', 'cpu'],
                        help='Device to use for training')
    parser.add_argument('--num-workers', type=int, default=4,
                        help='Number of data loading workers')
    
    args = parser.parse_args()
    
    # Set device
    if args.device == 'cuda' and not torch.cuda.is_available():
        print("CUDA not available, using CPU")
        args.device = 'cpu'
    
    print("="*60)
    print("GAN TRAINING CONFIGURATION")
    print("="*60)
    for arg, value in vars(args).items():
        print(f"{arg}: {value}")
    print("="*60)
    
    # Load dataset
    print("\nLoading dataset...")
    
    data_dir = Path(args.data_dir)
    
    if args.split == 'all':
        # Combine train and val
        train_metadata = data_dir / 'splits' / 'train_metadata.json'
        val_metadata = data_dir / 'splits' / 'val_metadata.json'
        
        # Load both datasets
        train_dataset = WaferDefectDataset(
            metadata_file=str(train_metadata),
            transform=None  # No augmentation for GAN training
        )
        val_dataset = WaferDefectDataset(
            metadata_file=str(val_metadata),
            transform=None
        )
        
        # Combine datasets
        from torch.utils.data import ConcatDataset
        dataset = ConcatDataset([train_dataset, val_dataset])
    else:
        metadata_file = data_dir / 'splits' / f'{args.split}_metadata.json'
        dataset = WaferDefectDataset(
            metadata_file=str(metadata_file),
            transform=None  # No augmentation for GAN training
        )
    
    print(f"Dataset size: {len(dataset)}")
    
    # Create data loader
    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True if args.device == 'cuda' else False
    )
    
    # Initialize GAN
    print("\nInitializing GAN...")
    gan = WaferGAN(
        noise_dim=args.noise_dim,
        num_patterns=10,  # Number of pattern classes
        img_size=args.img_size,
        device=args.device
    )
    
    # Resume from checkpoint if specified
    if args.resume:
        print(f"\nResuming from checkpoint: {args.resume}")
        gan.load(args.resume)
    
    # Train GAN
    print("\nStarting training...")
    train_gan(
        gan=gan,
        dataloader=dataloader,
        num_epochs=args.epochs,
        n_critic=args.n_critic,
        lambda_gp=args.lambda_gp,
        save_interval=args.save_interval,
        checkpoint_dir=args.checkpoint_dir
    )
    
    print("\n✓ Training complete!")
    print(f"Final model saved to: {args.checkpoint_dir}/gan_final.pth")


if __name__ == '__main__':
    main()
