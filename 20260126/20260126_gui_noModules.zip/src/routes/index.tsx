import { createBrowserRouter, Navigate } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import { CircularProgress, Box } from '@mui/material';
import MainLayout from '../layouts/MainLayout';

// Lazy load all page components for code splitting
const Dashboard = lazy(() => import('../pages/Dashboard'));
const Search = lazy(() => import('../pages/Search'));
const Upload = lazy(() => import('../pages/Upload'));
const Analysis = lazy(() => import('../pages/Analysis'));
const Analytics = lazy(() => import('../pages/Analytics'));
const Metrics = lazy(() => import('../pages/Metrics'));
const History = lazy(() => import('../pages/History'));
const Feedback = lazy(() => import('../pages/Feedback'));
const Reports = lazy(() => import('../pages/Reports'));
const Settings = lazy(() => import('../pages/Settings'));
const Admin = lazy(() => import('../pages/Admin'));
const Alerts = lazy(() => import('../pages/Alerts'));

// Training pages
const TrainingDashboard = lazy(() => import('../pages/training/TrainingDashboard'));
const IngestWafers = lazy(() => import('../pages/training/IngestWafers'));
const PatternAnalysis = lazy(() => import('../pages/training/PatternAnalysis'));
const GANGenerator = lazy(() => import('../pages/training/GANGenerator'));
const GANManagement = lazy(() => import('../pages/training/GANManagement'));
const ImageLabeling = lazy(() => import('../pages/training/ImageLabeling'));
const ModelMetrics = lazy(() => import('../pages/training/ModelMetrics'));
const WaferLibrary = lazy(() => import('../pages/training/WaferLibrary'));
const TrainingJobQueueIntegrated = lazy(() => import('../pages/training/TrainingJobQueueIntegrated'));

// Loading fallback component
const PageLoader = () => (
  <Box
    sx={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '400px',
    }}
  >
    <CircularProgress />
  </Box>
);

// Wrapper component with Suspense
const LazyPage = ({ children }: { children: React.ReactNode }) => (
  <Suspense fallback={<PageLoader />}>{children}</Suspense>
);

export const router = createBrowserRouter([
  {
    path: '/',
    element: <MainLayout />,
    children: [
      {
        index: true,
        element: <Navigate to="/dashboard" replace />,
      },
      {
        path: 'dashboard',
        element: (
          <LazyPage>
            <Dashboard />
          </LazyPage>
        ),
      },
      {
        path: 'search',
        element: (
          <LazyPage>
            <Search />
          </LazyPage>
        ),
      },
      {
        path: 'upload',
        element: (
          <LazyPage>
            <Upload />
          </LazyPage>
        ),
      },
      {
        path: 'analysis/:waferId?',
        element: (
          <LazyPage>
            <Analysis />
          </LazyPage>
        ),
      },
      {
        path: 'analytics',
        element: (
          <LazyPage>
            <Analytics />
          </LazyPage>
        ),
      },
      {
        path: 'metrics',
        element: (
          <LazyPage>
            <Metrics />
          </LazyPage>
        ),
      },
      {
        path: 'history',
        element: (
          <LazyPage>
            <History />
          </LazyPage>
        ),
      },
      {
        path: 'feedback/:waferId?',
        element: (
          <LazyPage>
            <Feedback />
          </LazyPage>
        ),
      },
      {
        path: 'reports',
        element: (
          <LazyPage>
            <Reports />
          </LazyPage>
        ),
      },
      {
        path: 'alerts',
        element: (
          <LazyPage>
            <Alerts />
          </LazyPage>
        ),
      },
      {
        path: 'settings',
        element: (
          <LazyPage>
            <Settings />
          </LazyPage>
        ),
      },
      {
        path: 'admin',
        element: (
          <LazyPage>
            <Admin />
          </LazyPage>
        ),
      },
      // Training routes
      {
        path: 'training',
        children: [
          {
            path: 'dashboard',
            element: (
              <LazyPage>
                <TrainingDashboard />
              </LazyPage>
            ),
          },
          {
            path: 'queue',
            element: (
              <LazyPage>
                <TrainingJobQueueIntegrated />
              </LazyPage>
            ),
          },
          {
            path: 'ingest',
            element: (
              <LazyPage>
                <IngestWafers />
              </LazyPage>
            ),
          },
          {
            path: 'pattern-analysis',
            element: (
              <LazyPage>
                <PatternAnalysis />
              </LazyPage>
            ),
          },
          {
            path: 'gan-generator',
            element: (
              <LazyPage>
                <GANGenerator />
              </LazyPage>
            ),
          },
          {
            path: 'gan-management',
            element: (
              <LazyPage>
                <GANManagement />
              </LazyPage>
            ),
          },
          {
            path: 'image-labeling',
            element: (
              <LazyPage>
                <ImageLabeling />
              </LazyPage>
            ),
          },
          {
            path: 'model-metrics',
            element: (
              <LazyPage>
                <ModelMetrics />
              </LazyPage>
            ),
          },
          {
            path: 'wafer-library',
            element: (
              <LazyPage>
                <WaferLibrary />
              </LazyPage>
            ),
          },
        ],
      },
    ],
  },
]);
