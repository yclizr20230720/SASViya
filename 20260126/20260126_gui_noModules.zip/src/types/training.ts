/**
 * Training-related types for WaferVision AI integration
 * These types support model training, synthetic data generation, and pattern analysis
 */

/**
 * Defect pattern classifications used in wafer analysis
 */
export type DefectPattern = 
  | 'Edge'      // Defects concentrated at wafer edges
  | 'Center'    // Defects concentrated at wafer center
  | 'Scratch'   // Linear scratch patterns
  | 'Ring'      // Concentric ring patterns
  | 'Cluster'   // Localized defect clusters
  | 'Random'    // Random distribution
  | 'Unknown'   // Unclassified pattern
  | 'None';     // No defects detected

/**
 * Individual die on a wafer
 */
export interface Die {
  /** X coordinate in grid */
  x: number;
  /** Y coordinate in grid */
  y: number;
  /** Die status */
  status: 'Good' | 'Defect';
  /** Optional bin code for defective dies */
  binCode?: number;
}

/**
 * Annotation on a wafer map for collaborative review
 */
export interface Annotation {
  /** Unique annotation identifier */
  id: string;
  /** X coordinate on wafer */
  x: number;
  /** Y coordinate on wafer */
  y: number;
  /** Annotation text label */
  label: string;
  /** Annotation type/severity */
  type: 'Note' | 'Critical' | 'Investigation';
}

/**
 * Complete wafer data structure for training
 */
export interface WaferData {
  /** Unique wafer identifier */
  id: string;
  /** Lot identifier */
  lotId: string;
  /** Timestamp of wafer creation/analysis */
  timestamp: string;
  /** Array of all dies on the wafer */
  dies: Die[];
  /** Wafer diameter in millimeters */
  diameter: number;
  /** Grid size (NxN) */
  gridSize: number;
  /** Detected defect pattern (if analyzed) */
  detectedPattern?: DefectPattern;
  /** Confidence score for pattern detection (0-1) */
  confidence?: number;
  /** User annotations on the wafer map */
  annotations?: Annotation[];
}

/**
 * AI analysis result from pattern recognition
 */
export interface AnalysisResult {
  /** Detected defect pattern */
  pattern: DefectPattern;
  /** Confidence score (0-1) */
  confidence: number;
  /** Root cause analysis */
  rootCause: string;
  /** Detailed explanation of the analysis */
  explanation: string;
  /** Optional heatmap intensity for visualization */
  heatmapIntensity?: number;
  /** Feature importance scores for explainability */
  featureImportance?: { feature: string; score: number }[];
}

/**
 * Configuration for GAN-based synthetic wafer generation
 */
export interface GANConfig {
  /** Type of defect pattern to generate */
  patternType: DefectPattern;
  /** Defect density (0-1) */
  defectDensity: number;
  /** Noise level for realistic variation (0-1) */
  noiseLevel: number;
  /** Whether to apply symmetry constraints */
  symmetry: boolean;
}

/**
 * Activity log item for training system
 */
export interface ActivityItem {
  /** Unique activity identifier */
  id: string;
  /** Activity type */
  type: 'Analysis' | 'Upload' | 'System' | 'Training';
  /** Activity message/description */
  message: string;
  /** Timestamp of activity */
  timestamp: string;
  /** User who performed the activity */
  user: string;
  /** Activity severity level */
  severity: 'info' | 'warning' | 'error' | 'success';
}

/**
 * Training model metadata
 */
export interface TrainingModel {
  /** Model identifier */
  id: string;
  /** Model name */
  name: string;
  /** Model version */
  version: string;
  /** Model architecture (CNN, ResNet, etc.) */
  architecture: string;
  /** Training accuracy */
  accuracy: number;
  /** Training date */
  trainedAt: string;
  /** Model status */
  status: 'training' | 'ready' | 'deployed' | 'archived';
  /** Number of training epochs */
  epochs: number;
  /** Training dataset size */
  datasetSize: number;
}

/**
 * Training metrics for model performance tracking
 */
export interface TrainingMetrics {
  /** Current epoch */
  epoch: number;
  /** Training loss */
  trainLoss: number;
  /** Validation loss */
  valLoss: number;
  /** Training accuracy */
  trainAccuracy: number;
  /** Validation accuracy */
  valAccuracy: number;
  /** Learning rate */
  learningRate: number;
  /** Timestamp */
  timestamp: string;
}
