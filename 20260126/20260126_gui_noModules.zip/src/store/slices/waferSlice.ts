import { createSlice, type PayloadAction } from '@reduxjs/toolkit';

export interface WaferMap {
  id: string;
  waferId: string;
  lotId: string;
  processStep: string;
  equipmentId: string;
  timestamp: string;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  progress?: number;
  error?: string;
}

interface WaferState {
  wafers: WaferMap[];
  selectedWaferId: string | null;
  uploadProgress: Record<string, number>;
  loading: boolean;
  error: string | null;
}

const initialState: WaferState = {
  wafers: [],
  selectedWaferId: null,
  uploadProgress: {},
  loading: false,
  error: null,
};

const waferSlice = createSlice({
  name: 'wafer',
  initialState,
  reducers: {
    addWafer: (state, action: PayloadAction<WaferMap>) => {
      state.wafers.push(action.payload);
    },
    updateWafer: (state, action: PayloadAction<{ id: string; updates: Partial<WaferMap> }>) => {
      const index = state.wafers.findIndex(w => w.id === action.payload.id);
      if (index !== -1) {
        state.wafers[index] = { ...state.wafers[index], ...action.payload.updates };
      }
    },
    removeWafer: (state, action: PayloadAction<string>) => {
      state.wafers = state.wafers.filter(w => w.id !== action.payload);
    },
    selectWafer: (state, action: PayloadAction<string | null>) => {
      state.selectedWaferId = action.payload;
    },
    setUploadProgress: (state, action: PayloadAction<{ id: string; progress: number }>) => {
      state.uploadProgress[action.payload.id] = action.payload.progress;
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload;
    },
    clearWafers: (state) => {
      state.wafers = [];
      state.uploadProgress = {};
    },
  },
});

export const {
  addWafer,
  updateWafer,
  removeWafer,
  selectWafer,
  setUploadProgress,
  setLoading,
  setError,
  clearWafers,
} = waferSlice.actions;

export default waferSlice.reducer;
