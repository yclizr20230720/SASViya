import { useState, useCallback } from 'react';
import { useAppDispatch } from '../store/hooks';
import { addWafer } from '../store/slices/waferSlice';

export interface UploadFile {
  file: File;
  id: string;
  progress: number;
  status: 'pending' | 'uploading' | 'paused' | 'completed' | 'error';
  error?: string;
  cancelToken?: () => void;
}

interface UploadMetadata {
  lotId: string;
  processStep: string;
  equipmentId: string;
}

export const useFileUpload = () => {
  const [files, setFiles] = useState<UploadFile[]>([]);
  const dispatch = useAppDispatch();

  const addFiles = useCallback((newFiles: File[]) => {
    const uploadFiles = newFiles.map((file) => ({
      file,
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      progress: 0,
      status: 'pending' as const,
    }));
    setFiles((prev) => [...prev, ...uploadFiles]);
  }, []);

  const removeFile = useCallback((id: string) => {
    setFiles((prev) => {
      const file = prev.find((f) => f.id === id);
      if (file?.cancelToken) {
        file.cancelToken();
      }
      return prev.filter((f) => f.id !== id);
    });
  }, []);

  const uploadFile = useCallback(
    async (fileId: string, metadata: UploadMetadata) => {
      let cancelled = false;
      const cancelToken = () => {
        cancelled = true;
      };

      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileId ? { ...f, status: 'uploading' as const, cancelToken } : f
        )
      );

      // Simulate upload with progress
      for (let progress = 0; progress <= 100; progress += 10) {
        if (cancelled) {
          setFiles((prev) =>
            prev.map((f) => (f.id === fileId ? { ...f, status: 'paused' as const } : f))
          );
          return;
        }

        await new Promise((resolve) => setTimeout(resolve, 200));

        setFiles((prev) =>
          prev.map((f) => (f.id === fileId ? { ...f, progress } : f))
        );
      }

      // Simulate successful upload
      const waferId = `W2026-${Math.floor(Math.random() * 1000)
        .toString()
        .padStart(3, '0')}`;

      dispatch(
        addWafer({
          id: fileId,
          waferId,
          lotId: metadata.lotId || 'LOT-AUTO',
          processStep: metadata.processStep || 'Unknown',
          equipmentId: metadata.equipmentId || 'EQ-AUTO',
          timestamp: new Date().toISOString(),
          status: 'processing',
        })
      );

      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileId ? { ...f, status: 'completed' as const, progress: 100 } : f
        )
      );
    },
    [dispatch]
  );

  const pauseUpload = useCallback((id: string) => {
    setFiles((prev) =>
      prev.map((f) => {
        if (f.id === id && f.cancelToken) {
          f.cancelToken();
          return { ...f, status: 'paused' as const };
        }
        return f;
      })
    );
  }, []);

  const resumeUpload = useCallback(
    (id: string, metadata: UploadMetadata) => {
      uploadFile(id, metadata);
    },
    [uploadFile]
  );

  const retryUpload = useCallback(
    (id: string, metadata: UploadMetadata) => {
      setFiles((prev) =>
        prev.map((f) =>
          f.id === id ? { ...f, status: 'pending' as const, progress: 0, error: undefined } : f
        )
      );
      uploadFile(id, metadata);
    },
    [uploadFile]
  );

  const uploadAll = useCallback(
    async (metadata: UploadMetadata) => {
      const pendingFiles = files.filter((f) => f.status === 'pending');
      for (const file of pendingFiles) {
        await uploadFile(file.id, metadata);
      }
    },
    [files, uploadFile]
  );

  const clearCompleted = useCallback(() => {
    setFiles((prev) => prev.filter((f) => f.status !== 'completed'));
  }, []);

  const getOverallProgress = useCallback(() => {
    if (files.length === 0) return 0;
    const totalProgress = files.reduce((sum, file) => sum + file.progress, 0);
    return Math.round(totalProgress / files.length);
  }, [files]);

  return {
    files,
    addFiles,
    removeFile,
    uploadFile,
    pauseUpload,
    resumeUpload,
    retryUpload,
    uploadAll,
    clearCompleted,
    getOverallProgress,
  };
};
