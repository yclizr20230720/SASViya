import { useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  IconButton,
  Collapse,
  Chip,
  Divider,
  LinearProgress,
  Tooltip,
  List,
  ListItem,
  ListItemText,
} from '@mui/material';
import {
  Info,
  ExpandMore,
  ExpandLess,
  TrendingUp,
  TrendingDown,
  Calculate,
  Lightbulb,
} from '@mui/icons-material';
import type { MetricDefinition } from '../utils/metricDefinitions';
import { getMetricInterpretation, getRelatedMetrics } from '../utils/metricDefinitions';

interface InteractiveMetricCardProps {
  metric: MetricDefinition;
  currentValue: number;
  previousValue?: number;
  benchmark?: {
    value: number;
    label: string;
  };
  onRelatedMetricClick?: (metricId: string) => void;
}

export default function InteractiveMetricCard({
  metric,
  currentValue,
  previousValue,
  benchmark,
  onRelatedMetricClick,
}: InteractiveMetricCardProps) {
  const [expanded, setExpanded] = useState(false);
  const [showFormula, setShowFormula] = useState(false);

  const interpretation = getMetricInterpretation(metric.id, currentValue);
  const relatedMetrics = getRelatedMetrics(metric.id);
  
  const trend = previousValue !== undefined ? currentValue - previousValue : 0;
  const trendPercent = previousValue !== undefined && previousValue !== 0
    ? ((trend / previousValue) * 100).toFixed(1)
    : '0.0';

  const getStatusColor = (level: string) => {
    switch (level) {
      case 'good':
        return 'success';
      case 'warning':
        return 'warning';
      case 'critical':
        return 'error';
      default:
        return 'default';
    }
  };

  const getImportanceColor = (importance: string) => {
    switch (importance) {
      case 'critical':
        return 'error';
      case 'high':
        return 'warning';
      case 'medium':
        return 'info';
      case 'low':
        return 'default';
      default:
        return 'default';
    }
  };

  const calculateProgress = () => {
    if (!metric.industryStandard?.target) return 50;
    const target = metric.industryStandard.target;
    return Math.min(100, (currentValue / target) * 100);
  };

  return (
    <Card
      sx={{
        height: '100%',
        transition: 'all 0.3s',
        '&:hover': {
          boxShadow: 6,
          transform: 'translateY(-4px)',
        },
      }}
    >
      <CardContent>
        {/* Header */}
        <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', mb: 2 }}>
          <Box sx={{ flex: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                {metric.name}
              </Typography>
              <Chip
                label={metric.importance}
                size="small"
                color={getImportanceColor(metric.importance) as any}
                sx={{ textTransform: 'capitalize' }}
              />
            </Box>
            <Typography variant="caption" color="text.secondary">
              {metric.category.charAt(0).toUpperCase() + metric.category.slice(1)} Metric
            </Typography>
          </Box>
          <Tooltip title="What does this mean?">
            <IconButton
              size="small"
              onClick={() => setExpanded(!expanded)}
              sx={{ color: 'primary.main' }}
            >
              {expanded ? <ExpandLess /> : <Info />}
            </IconButton>
          </Tooltip>
        </Box>

        {/* Current Value */}
        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 1, mb: 1 }}>
            <Typography variant="h3" sx={{ fontWeight: 700, color: `${getStatusColor(interpretation.level)}.main` }}>
              {currentValue.toFixed(2)}
            </Typography>
            <Typography variant="h6" color="text.secondary">
              {metric.unit}
            </Typography>
          </Box>

          {/* Trend Indicator */}
          {previousValue !== undefined && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              {trend >= 0 ? (
                <TrendingUp fontSize="small" color={trend > 0 ? 'success' : 'disabled'} />
              ) : (
                <TrendingDown fontSize="small" color="error" />
              )}
              <Typography
                variant="body2"
                sx={{
                  color: trend >= 0 ? 'success.main' : 'error.main',
                  fontWeight: 600,
                }}
              >
                {trend >= 0 ? '+' : ''}
                {trendPercent}% vs previous
              </Typography>
            </Box>
          )}
        </Box>

        {/* Progress Bar */}
        {metric.industryStandard?.target && (
          <Box sx={{ mb: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
              <Typography variant="caption" color="text.secondary">
                Progress to Target
              </Typography>
              <Typography variant="caption" sx={{ fontWeight: 600 }}>
                {metric.industryStandard.target} {metric.unit}
              </Typography>
            </Box>
            <LinearProgress
              variant="determinate"
              value={calculateProgress()}
              color={getStatusColor(interpretation.level) as any}
              sx={{ height: 8, borderRadius: 4 }}
            />
          </Box>
        )}

        {/* Status Chip */}
        <Chip
          label={interpretation.level.toUpperCase()}
          color={getStatusColor(interpretation.level) as any}
          size="small"
          sx={{ fontWeight: 600 }}
        />

        {/* Benchmark Comparison */}
        {benchmark && (
          <Box sx={{ mt: 2, p: 1, bgcolor: 'background.default', borderRadius: 1 }}>
            <Typography variant="caption" color="text.secondary" display="block">
              {benchmark.label}
            </Typography>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              {benchmark.value} {metric.unit}
            </Typography>
          </Box>
        )}

        {/* Expanded Details */}
        <Collapse in={expanded}>
          <Divider sx={{ my: 2 }} />

          {/* Description */}
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              Description
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {metric.description}
            </Typography>
          </Box>

          {/* Interpretation */}
          <Box sx={{ mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
              <Lightbulb fontSize="small" color="primary" />
              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                Interpretation
              </Typography>
            </Box>
            <Typography variant="body2" color="text.secondary">
              {interpretation.text}
            </Typography>
          </Box>

          {/* Formula */}
          <Box sx={{ mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
              <Calculate fontSize="small" color="primary" />
              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                Calculation Formula
              </Typography>
              <IconButton size="small" onClick={() => setShowFormula(!showFormula)}>
                {showFormula ? <ExpandLess fontSize="small" /> : <ExpandMore fontSize="small" />}
              </IconButton>
            </Box>
            <Collapse in={showFormula}>
              <Box
                sx={{
                  p: 1.5,
                  bgcolor: 'grey.100',
                  borderRadius: 1,
                  fontFamily: 'monospace',
                  fontSize: '0.875rem',
                }}
              >
                {metric.formula}
              </Box>
              {metric.calculationExample && (
                <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 1 }}>
                  Example: {metric.calculationExample}
                </Typography>
              )}
            </Collapse>
          </Box>

          {/* Industry Standard */}
          {metric.industryStandard && (
            <Box sx={{ mb: 2, p: 1.5, bgcolor: 'info.light', borderRadius: 1 }}>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
                Industry Standard
              </Typography>
              {metric.industryStandard.target && (
                <Typography variant="body2">
                  Target: {metric.industryStandard.target} {metric.unit}
                </Typography>
              )}
              {metric.industryStandard.min && (
                <Typography variant="body2">
                  Minimum: {metric.industryStandard.min} {metric.unit}
                </Typography>
              )}
              {metric.industryStandard.max && (
                <Typography variant="body2">
                  Maximum: {metric.industryStandard.max} {metric.unit}
                </Typography>
              )}
              {metric.industryStandard.benchmark && (
                <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 0.5 }}>
                  {metric.industryStandard.benchmark}
                </Typography>
              )}
            </Box>
          )}

          {/* Related Metrics */}
          {relatedMetrics.length > 0 && (
            <Box>
              <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
                Related Metrics
              </Typography>
              <List dense>
                {relatedMetrics.map((relatedMetric) => (
                  <ListItem
                    key={relatedMetric.id}
                    sx={{
                      cursor: onRelatedMetricClick ? 'pointer' : 'default',
                      '&:hover': onRelatedMetricClick ? { bgcolor: 'action.hover' } : {},
                      borderRadius: 1,
                    }}
                    onClick={() => onRelatedMetricClick?.(relatedMetric.id)}
                  >
                    <ListItemText
                      primary={relatedMetric.name}
                      secondary={relatedMetric.category}
                      primaryTypographyProps={{ variant: 'body2', fontWeight: 600 }}
                      secondaryTypographyProps={{ variant: 'caption' }}
                    />
                  </ListItem>
                ))}
              </List>
            </Box>
          )}
        </Collapse>
      </CardContent>
    </Card>
  );
}
