import {
  Box,
  Card,
  CardContent,
  Typography,
  LinearProgress,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Chip,
  Divider,
} from '@mui/material';
import {
  CheckCircle,
  Warning,
  Error,
  Info,
  TrendingUp,
  TrendingDown,
} from '@mui/icons-material';

interface ConfidenceFactor {
  name: string;
  score: number;
  weight: number;
  description: string;
  status: 'excellent' | 'good' | 'fair' | 'poor';
}

interface ConfidenceFactorsBreakdownProps {
  overallConfidence: number;
  factors: ConfidenceFactor[];
}

export default function ConfidenceFactorsBreakdown({
  overallConfidence,
  factors,
}: ConfidenceFactorsBreakdownProps) {
  // Sort factors by importance (weight * score)
  const sortedFactors = [...factors].sort(
    (a, b) => b.weight * b.score - a.weight * a.score
  );

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'excellent':
        return <CheckCircle color="success" />;
      case 'good':
        return <CheckCircle color="info" />;
      case 'fair':
        return <Warning color="warning" />;
      case 'poor':
        return <Error color="error" />;
      default:
        return <Info color="action" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent':
        return 'success';
      case 'good':
        return 'info';
      case 'fair':
        return 'warning';
      case 'poor':
        return 'error';
      default:
        return 'default';
    }
  };

  const getConfidenceLevel = (confidence: number) => {
    if (confidence >= 0.9) return { label: 'Very High', color: 'success' };
    if (confidence >= 0.8) return { label: 'High', color: 'info' };
    if (confidence >= 0.7) return { label: 'Moderate', color: 'warning' };
    return { label: 'Low', color: 'error' };
  };

  const confidenceLevel = getConfidenceLevel(overallConfidence);

  return (
    <Card>
      <CardContent>
        <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
          Confidence Factors Breakdown
        </Typography>
        
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Detailed analysis of factors contributing to the prediction confidence
        </Typography>

        {/* Overall Confidence */}
        <Box sx={{ mb: 3, p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
            <Typography variant="subtitle2">Overall Confidence Score</Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Chip
                label={confidenceLevel.label}
                color={confidenceLevel.color as any}
                size="small"
              />
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                {(overallConfidence * 100).toFixed(1)}%
              </Typography>
            </Box>
          </Box>
          <LinearProgress
            variant="determinate"
            value={overallConfidence * 100}
            color={confidenceLevel.color as any}
            sx={{ height: 8, borderRadius: 4 }}
          />
        </Box>

        <Divider sx={{ my: 2 }} />

        {/* Individual Factors */}
        <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
          Contributing Factors (Ranked by Importance)
        </Typography>

        <List>
          {sortedFactors.map((factor) => {
            const contribution = factor.weight * factor.score;
            const isPositive = factor.score > 0.7;

            return (
              <ListItem
                key={factor.name}
                sx={{
                  border: 1,
                  borderColor: 'divider',
                  borderRadius: 1,
                  mb: 1,
                  bgcolor: 'background.paper',
                }}
              >
                <ListItemIcon>{getStatusIcon(factor.status)}</ListItemIcon>
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {factor.name}
                      </Typography>
                      <Chip
                        label={`Weight: ${(factor.weight * 100).toFixed(0)}%`}
                        size="small"
                        variant="outlined"
                      />
                    </Box>
                  }
                  secondary={
                    <Box sx={{ mt: 1 }}>
                      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1 }}>
                        {factor.description}
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Box sx={{ flex: 1 }}>
                          <LinearProgress
                            variant="determinate"
                            value={factor.score * 100}
                            color={getStatusColor(factor.status) as any}
                            sx={{ height: 6, borderRadius: 3 }}
                          />
                        </Box>
                        <Typography variant="caption" sx={{ minWidth: 45, textAlign: 'right' }}>
                          {(factor.score * 100).toFixed(0)}%
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 0.5 }}>
                        {isPositive ? (
                          <TrendingUp fontSize="small" color="success" />
                        ) : (
                          <TrendingDown fontSize="small" color="error" />
                        )}
                        <Typography variant="caption" color="text.secondary">
                          Contribution: {(contribution * 100).toFixed(1)}%
                        </Typography>
                      </Box>
                    </Box>
                  }
                />
              </ListItem>
            );
          })}
        </List>

        {/* Summary Statistics */}
        <Box sx={{ mt: 3, p: 2, bgcolor: 'primary.light', borderRadius: 1 }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
            Confidence Analysis Summary
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2, mt: 1 }}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Strong Factors
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {sortedFactors.filter((f) => f.score >= 0.8).length} / {sortedFactors.length}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Weak Factors
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {sortedFactors.filter((f) => f.score < 0.6).length} / {sortedFactors.length}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Avg Factor Score
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {(
                  sortedFactors.reduce((sum, f) => sum + f.score, 0) / sortedFactors.length
                ).toFixed(2)}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Reliability
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {overallConfidence >= 0.9
                  ? 'High'
                  : overallConfidence >= 0.7
                  ? 'Medium'
                  : 'Low'}
              </Typography>
            </Box>
          </Box>
        </Box>

        {/* Recommendations */}
        {overallConfidence < 0.8 && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="caption" color="warning.main" display="block" sx={{ fontWeight: 600 }}>
              ⚠️ Confidence Improvement Recommendations:
            </Typography>
            <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 0.5 }}>
              • Review factors with low scores for potential data quality issues
              <br />
              • Consider collecting additional wafer samples for better pattern recognition
              <br />• Manual verification recommended for this prediction
            </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
}
