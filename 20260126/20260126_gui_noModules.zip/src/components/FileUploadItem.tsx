import {
  Box,
  ListItem,
  ListItemText,
  IconButton,
  LinearProgress,
  Typography,
  Tooltip,
} from '@mui/material';
import {
  Delete,
  CheckCircle,
  Error as ErrorIcon,
  Pause,
  PlayArrow,
  Refresh,
} from '@mui/icons-material';
import { type UploadFile } from '../hooks/useFileUpload';

interface FileUploadItemProps {
  file: UploadFile;
  onRemove: (id: string) => void;
  onPause: (id: string) => void;
  onResume: (id: string) => void;
  onRetry: (id: string) => void;
}

export default function FileUploadItem({
  file,
  onRemove,
  onPause,
  onResume,
  onRetry,
}: FileUploadItemProps) {
  const getStatusColor = () => {
    switch (file.status) {
      case 'completed':
        return 'success.main';
      case 'error':
        return 'error.main';
      case 'uploading':
        return 'primary.main';
      case 'paused':
        return 'warning.main';
      default:
        return 'text.secondary';
    }
  };

  const getStatusText = () => {
    switch (file.status) {
      case 'completed':
        return 'Upload completed';
      case 'error':
        return file.error || 'Upload failed';
      case 'uploading':
        return `Uploading... ${file.progress}%`;
      case 'paused':
        return 'Paused';
      case 'pending':
        return 'Waiting to upload';
      default:
        return '';
    }
  };

  return (
    <ListItem
      sx={{
        border: 1,
        borderColor: 'divider',
        borderRadius: 1,
        mb: 1,
        flexDirection: 'column',
        alignItems: 'stretch',
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
        <Box sx={{ flex: 1 }}>
          <ListItemText
            primary={file.file.name}
            secondary={`${(file.file.size / 1024).toFixed(2)} KB`}
          />
        </Box>
        <Box sx={{ display: 'flex', gap: 0.5 }}>
          {file.status === 'uploading' && (
            <Tooltip title="Pause">
              <IconButton size="small" onClick={() => onPause(file.id)}>
                <Pause />
              </IconButton>
            </Tooltip>
          )}
          {file.status === 'paused' && (
            <Tooltip title="Resume">
              <IconButton size="small" onClick={() => onResume(file.id)}>
                <PlayArrow />
              </IconButton>
            </Tooltip>
          )}
          {file.status === 'error' && (
            <Tooltip title="Retry">
              <IconButton size="small" onClick={() => onRetry(file.id)}>
                <Refresh />
              </IconButton>
            </Tooltip>
          )}
          {(file.status === 'pending' || file.status === 'paused') && (
            <Tooltip title="Remove">
              <IconButton size="small" onClick={() => onRemove(file.id)}>
                <Delete />
              </IconButton>
            </Tooltip>
          )}
        </Box>
      </Box>

      {file.status === 'uploading' && (
        <LinearProgress
          variant="determinate"
          value={file.progress}
          sx={{ mt: 1, height: 6, borderRadius: 3 }}
        />
      )}

      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 1 }}>
        {file.status === 'completed' && <CheckCircle color="success" fontSize="small" />}
        {file.status === 'error' && <ErrorIcon color="error" fontSize="small" />}
        <Typography variant="caption" sx={{ color: getStatusColor() }}>
          {getStatusText()}
        </Typography>
      </Box>
    </ListItem>
  );
}
