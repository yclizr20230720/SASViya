import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  FormControlLabel,
  Switch,
  Chip,
} from '@mui/material';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  Area,
  ComposedChart,
} from 'recharts';
import { TrendingUp, CalendarToday, Warning } from '@mui/icons-material';

interface TemporalTrendAnalysisProps {
  data?: {
    time_series: {
      date: string;
      defect_rate: number;
      moving_average: number;
    }[];
    anomalies: {
      date: string;
      defect_rate: number;
      severity: string;
    }[];
    statistics: {
      avg_defect_rate: number;
      max_defect_rate: number;
      min_defect_rate: number;
      trend_direction: string;
      trend_percentage: number;
    };
  };
}

type TimeRange = 'day' | 'week' | 'month' | 'quarter';

export default function TemporalTrendAnalysis({
  data,
}: TemporalTrendAnalysisProps) {
  const [timeRange, setTimeRange] = useState<TimeRange>('month');
  const [showMovingAverage, setShowMovingAverage] = useState(true);
  const [highlightAnomalies, setHighlightAnomalies] = useState(true);

  if (!data || !data.time_series || data.time_series.length === 0) {
    return (
      <Card>
        <CardContent>
          <Typography variant="body2" color="text.secondary">
            No temporal trend data available
          </Typography>
        </CardContent>
      </Card>
    );
  }

  // Transform API data to chart format
  const anomalyDates = new Set(data.anomalies.map(a => a.date));
  const timeSeriesData = data.time_series.map(item => ({
    date: item.date,
    defectRate: item.defect_rate,
    movingAverage: item.moving_average,
    anomaly: anomalyDates.has(item.date),
  }));

  const filteredData = filterDataByTimeRange(timeSeriesData, timeRange);
  const anomalies = data.anomalies.filter(a => 
    filteredData.some(d => d.date === a.date)
  );

  const trend = data.statistics.trend_percentage;
  const avgDefectRate = data.statistics.avg_defect_rate;

  const CustomDot = (props: any) => {
    const { cx, cy, payload } = props;
    if (highlightAnomalies && payload.anomaly) {
      return (
        <g>
          <circle cx={cx} cy={cy} r={6} fill="#ff4444" stroke="#fff" strokeWidth={2} />
          <circle cx={cx} cy={cy} r={10} fill="none" stroke="#ff4444" strokeWidth={1} opacity={0.5} />
        </g>
      );
    }
    return null;
  };

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <TrendingUp color="primary" />
          <Typography variant="h6" sx={{ fontWeight: 600, flex: 1 }}>
            Temporal Trend Analysis
          </Typography>
          <Chip
            icon={trend >= 0 ? <TrendingUp /> : <TrendingUp style={{ transform: 'rotate(180deg)' }} />}
            label={`${trend >= 0 ? '+' : ''}${trend.toFixed(1)}%`}
            color={trend >= 0 ? 'error' : 'success'}
            size="small"
          />
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Defect rate trends over time with anomaly detection
        </Typography>

        {/* Time Range Selector */}
        <Box sx={{ mb: 2, display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <CalendarToday fontSize="small" color="action" />
            <Typography variant="body2">Time Range:</Typography>
          </Box>
          <ToggleButtonGroup
            value={timeRange}
            exclusive
            onChange={(_, value) => value && setTimeRange(value)}
            size="small"
          >
            <ToggleButton value="day">Day</ToggleButton>
            <ToggleButton value="week">Week</ToggleButton>
            <ToggleButton value="month">Month</ToggleButton>
            <ToggleButton value="quarter">Quarter</ToggleButton>
          </ToggleButtonGroup>
        </Box>

        {/* Chart Options */}
        <Box sx={{ mb: 2, display: 'flex', gap: 2 }}>
          <FormControlLabel
            control={
              <Switch
                checked={showMovingAverage}
                onChange={(e) => setShowMovingAverage(e.target.checked)}
                size="small"
              />
            }
            label={<Typography variant="caption">Moving Average</Typography>}
          />
          <FormControlLabel
            control={
              <Switch
                checked={highlightAnomalies}
                onChange={(e) => setHighlightAnomalies(e.target.checked)}
                size="small"
              />
            }
            label={<Typography variant="caption">Highlight Anomalies</Typography>}
          />
        </Box>

        {/* Trend Chart */}
        <ResponsiveContainer width="100%" height={400}>
          <ComposedChart data={filteredData}>
            <defs>
              <linearGradient id="colorDefectRate" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#0066CC" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#0066CC" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis label={{ value: 'Defect Rate (%)', angle: -90, position: 'insideLeft' }} />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <Box sx={{ bgcolor: 'background.paper', p: 1.5, border: 1, borderColor: 'divider', borderRadius: 1 }}>
                      <Typography variant="caption" display="block" sx={{ fontWeight: 600 }}>
                        {data.date}
                      </Typography>
                      <Typography variant="caption" display="block">
                        Defect Rate: {data.defectRate.toFixed(2)}%
                      </Typography>
                      {showMovingAverage && (
                        <Typography variant="caption" display="block">
                          Moving Avg: {data.movingAverage.toFixed(2)}%
                        </Typography>
                      )}
                      {data.anomaly && (
                        <Chip label="Anomaly Detected" color="error" size="small" sx={{ mt: 0.5 }} />
                      )}
                    </Box>
                  );
                }
                return null;
              }}
            />
            <Legend />
            
            {/* Area under the curve */}
            <Area
              type="monotone"
              dataKey="defectRate"
              fill="url(#colorDefectRate)"
              stroke="none"
            />
            
            {/* Main defect rate line */}
            <Line
              type="monotone"
              dataKey="defectRate"
              stroke="#0066CC"
              strokeWidth={2}
              dot={<CustomDot />}
              name="Defect Rate"
            />
            
            {/* Moving average line */}
            {showMovingAverage && (
              <Line
                type="monotone"
                dataKey="movingAverage"
                stroke="#FF8042"
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={false}
                name="Moving Average"
              />
            )}
            
            {/* Average reference line */}
            <ReferenceLine
              y={avgDefectRate}
              stroke="#666"
              strokeDasharray="3 3"
              label={{ value: `Avg: ${avgDefectRate.toFixed(2)}%`, position: 'right' }}
            />
          </ComposedChart>
        </ResponsiveContainer>

        {/* Statistics and Anomalies */}
        <Box sx={{ mt: 3, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
          {/* Statistics */}
          <Box sx={{ p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
            <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
              Statistics
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1 }}>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  Average Rate
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {avgDefectRate.toFixed(2)}%
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  Trend
                </Typography>
                <Typography
                  variant="body2"
                  sx={{ fontWeight: 600, color: trend >= 0 ? 'error.main' : 'success.main' }}
                >
                  {trend >= 0 ? '+' : ''}
                  {trend.toFixed(1)}%
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  Max Rate
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {data.statistics.max_defect_rate.toFixed(2)}%
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">
                  Min Rate
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {data.statistics.min_defect_rate.toFixed(2)}%
                </Typography>
              </Box>
            </Box>
          </Box>

          {/* Anomalies */}
          <Box sx={{ p: 2, bgcolor: 'error.light', borderRadius: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
              <Warning fontSize="small" />
              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                Anomalies Detected
              </Typography>
            </Box>
            {anomalies.length > 0 ? (
              <Box>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  {anomalies.length} anomal{anomalies.length === 1 ? 'y' : 'ies'} detected in this period
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {anomalies.slice(0, 5).map((anomaly, index) => (
                    <Chip
                      key={index}
                      label={anomaly.date}
                      size="small"
                      variant="outlined"
                    />
                  ))}
                  {anomalies.length > 5 && (
                    <Chip label={`+${anomalies.length - 5} more`} size="small" variant="outlined" />
                  )}
                </Box>
              </Box>
            ) : (
              <Typography variant="body2">No anomalies detected in this period</Typography>
            )}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
}

function filterDataByTimeRange(data: any[], range: TimeRange) {
  const rangeMap = {
    day: 7,
    week: 14,
    month: 30,
    quarter: 90,
  };
  
  const count = rangeMap[range];
  return data.slice(-count);
}
