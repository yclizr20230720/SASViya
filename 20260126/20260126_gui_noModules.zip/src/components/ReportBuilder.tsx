import { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Button,
  Drawer,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  IconButton,
  TextField,
  Grid,
  Card,
  CardContent,
} from '@mui/material';
import {
  BarChart as ChartIcon,
  TableChart as TableIcon,
  Image as ImageIcon,
  TextFields as TextIcon,
  Assessment as MetricIcon,
  Close as CloseIcon,
  Save as SaveIcon,
  Preview as PreviewIcon,
} from '@mui/icons-material';
import type { ReportTemplate, ReportWidget, ReportWidgetType } from '../types/report';

export interface ReportBuilderProps {
  template: ReportTemplate;
  onSave: (template: ReportTemplate) => void;
  onCancel: () => void;
}

const widgetTypes: Array<{ type: ReportWidgetType; label: string; icon: React.ReactNode }> = [
  { type: 'chart', label: 'Chart', icon: <ChartIcon /> },
  { type: 'table', label: 'Table', icon: <TableIcon /> },
  { type: 'wafer-map', label: 'Wafer Map', icon: <ImageIcon /> },
  { type: 'metric', label: 'Metric', icon: <MetricIcon /> },
  { type: 'text', label: 'Text', icon: <TextIcon /> },
  { type: 'image', label: 'Image', icon: <ImageIcon /> },
];

const ReportBuilder: React.FC<ReportBuilderProps> = ({ template, onSave, onCancel }) => {
  const [currentTemplate, setCurrentTemplate] = useState<ReportTemplate>(template);
  const [selectedWidget, setSelectedWidget] = useState<ReportWidget | null>(null);

  const handleAddWidget = (type: ReportWidgetType) => {
    const newWidget: ReportWidget = {
      id: `widget-${Date.now()}`,
      type,
      title: `New ${type}`,
      config: {},
      position: {
        x: 0,
        y: currentTemplate.widgets.length * 2,
        width: 6,
        height: 4,
      },
    };

    setCurrentTemplate({
      ...currentTemplate,
      widgets: [...currentTemplate.widgets, newWidget],
    });
  };

  const handleRemoveWidget = (widgetId: string) => {
    setCurrentTemplate({
      ...currentTemplate,
      widgets: currentTemplate.widgets.filter((w) => w.id !== widgetId),
    });
  };

  const handleUpdateWidget = (widgetId: string, updates: Partial<ReportWidget>) => {
    setCurrentTemplate({
      ...currentTemplate,
      widgets: currentTemplate.widgets.map((w) =>
        w.id === widgetId ? { ...w, ...updates } : w
      ),
    });
  };

  const handleSave = () => {
    onSave({
      ...currentTemplate,
      updatedAt: new Date().toISOString(),
    });
  };

  return (
    <Box display="flex" height="calc(100vh - 100px)">
      {/* Widget Library Drawer */}
      <Drawer
        variant="persistent"
        anchor="left"
        open={true}
        sx={{
          width: 240,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: 240,
            position: 'relative',
            height: '100%',
          },
        }}
      >
        <Box p={2}>
          <Typography variant="h6" gutterBottom>
            Widgets
          </Typography>
          <List>
            {widgetTypes.map((widgetType) => (
              <ListItemButton
                key={widgetType.type}
                onClick={() => handleAddWidget(widgetType.type)}
              >
                <ListItemIcon>{widgetType.icon}</ListItemIcon>
                <ListItemText primary={widgetType.label} />
              </ListItemButton>
            ))}
          </List>
        </Box>
      </Drawer>

      {/* Canvas Area */}
      <Box flex={1} p={3} overflow="auto" bgcolor="grey.100">
        <Paper sx={{ p: 3, minHeight: '100%' }}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
            <Box>
              <Typography variant="h5" gutterBottom>
                {currentTemplate.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {currentTemplate.description}
              </Typography>
            </Box>
            <Box display="flex" gap={1}>
              <Button startIcon={<PreviewIcon />} variant="outlined">
                Preview
              </Button>
              <Button startIcon={<SaveIcon />} variant="contained" onClick={handleSave}>
                Save
              </Button>
              <Button onClick={onCancel}>Cancel</Button>
            </Box>
          </Box>

          <Grid container spacing={2}>
            {currentTemplate.widgets.map((widget) => (
              <Grid
                size={{ xs: widget.position.width }}
                key={widget.id}
              >
                <Card
                  sx={{
                    minHeight: widget.position.height * 50,
                    cursor: 'pointer',
                    border: selectedWidget?.id === widget.id ? 2 : 0,
                    borderColor: 'primary.main',
                  }}
                  onClick={() => setSelectedWidget(widget)}
                >
                  <CardContent>
                    <Box display="flex" justifyContent="space-between" alignItems="center">
                      <Typography variant="h6">{widget.title}</Typography>
                      <IconButton
                        size="small"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRemoveWidget(widget.id);
                        }}
                      >
                        <CloseIcon fontSize="small" />
                      </IconButton>
                    </Box>
                    <Typography variant="caption" color="text.secondary">
                      {widget.type}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          {currentTemplate.widgets.length === 0 && (
            <Box
              display="flex"
              flexDirection="column"
              alignItems="center"
              justifyContent="center"
              minHeight={400}
            >
              <Typography variant="h6" color="text.secondary" gutterBottom>
                No widgets added yet
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Drag widgets from the left panel to start building your report
              </Typography>
            </Box>
          )}
        </Paper>
      </Box>

      {/* Widget Properties Panel */}
      {selectedWidget && (
        <Paper sx={{ width: 300, p: 2, overflow: 'auto' }}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">Properties</Typography>
            <IconButton size="small" onClick={() => setSelectedWidget(null)}>
              <CloseIcon />
            </IconButton>
          </Box>

          <TextField
            label="Title"
            fullWidth
            margin="normal"
            value={selectedWidget.title}
            onChange={(e) =>
              handleUpdateWidget(selectedWidget.id, { title: e.target.value })
            }
          />

          <TextField
            label="Width (columns)"
            fullWidth
            margin="normal"
            type="number"
            value={selectedWidget.position.width}
            onChange={(e) =>
              handleUpdateWidget(selectedWidget.id, {
                position: {
                  ...selectedWidget.position,
                  width: parseInt(e.target.value),
                },
              })
            }
            inputProps={{ min: 1, max: 12 }}
          />

          <TextField
            label="Height (units)"
            fullWidth
            margin="normal"
            type="number"
            value={selectedWidget.position.height}
            onChange={(e) =>
              handleUpdateWidget(selectedWidget.id, {
                position: {
                  ...selectedWidget.position,
                  height: parseInt(e.target.value),
                },
              })
            }
            inputProps={{ min: 1, max: 20 }}
          />
        </Paper>
      )}
    </Box>
  );
};

export default ReportBuilder;
