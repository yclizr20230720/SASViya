import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  Chip,
} from '@mui/material';
import {
  LineChart,
  Line,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  ZAxis,
} from 'recharts';
import { Assessment, TrendingUp, TrendingDown } from '@mui/icons-material';

interface YieldAnalysisChartsProps {
  data?: {
    yield_trends: {
      date: string;
      yield: number;
      target: number;
    }[];
    yield_vs_defects: {
      defect_density: number;
      yield: number;
      lot_id: string;
    }[];
    statistics: {
      current_yield: number;
      avg_yield: number;
      target_yield: number;
      yield_gap: number;
    };
  };
}

type ChartView = 'trend' | 'scatter' | 'prediction';

export default function YieldAnalysisCharts({
  data,
}: YieldAnalysisChartsProps) {
  const [chartView, setChartView] = useState<ChartView>('trend');

  if (!data || !data.yield_trends || data.yield_trends.length === 0) {
    return (
      <Card>
        <CardContent>
          <Typography variant="body2" color="text.secondary">
            No yield analysis data available
          </Typography>
        </CardContent>
      </Card>
    );
  }

  const currentYield = data.statistics.current_yield;
  const targetYield = data.statistics.target_yield;
  const yieldGap = data.statistics.yield_gap;
  const avgYield = data.statistics.avg_yield;

  // Transform API data to chart format
  const yieldTrendData = data.yield_trends.map(item => ({
    date: item.date,
    yield: item.yield,
    predicted: item.yield + (Math.random() - 0.5) * 0.5, // Simple prediction for now
    target: item.target,
  }));

  const yieldVsDefectData = data.yield_vs_defects.map(item => ({
    defectDensity: item.defect_density,
    yield: item.yield,
    lotId: item.lot_id,
  }));

  const renderYieldTrendChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <LineChart data={yieldTrendData}>
        <defs>
          <linearGradient id="colorYield" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#4caf50" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#4caf50" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="date" />
        <YAxis domain={[80, 100]} label={{ value: 'Yield (%)', angle: -90, position: 'insideLeft' }} />
        <Tooltip
          content={({ active, payload }) => {
            if (active && payload && payload.length) {
              const data = payload[0].payload;
              return (
                <Box sx={{ bgcolor: 'background.paper', p: 1.5, border: 1, borderColor: 'divider', borderRadius: 1 }}>
                  <Typography variant="caption" display="block" sx={{ fontWeight: 600 }}>
                    {data.date}
                  </Typography>
                  <Typography variant="caption" display="block" color="success.main">
                    Actual Yield: {data.yield.toFixed(2)}%
                  </Typography>
                  <Typography variant="caption" display="block" color="info.main">
                    Predicted: {data.predicted.toFixed(2)}%
                  </Typography>
                  <Typography variant="caption" display="block" color="text.secondary">
                    Target: {data.target.toFixed(2)}%
                  </Typography>
                </Box>
              );
            }
            return null;
          }}
        />
        <Legend />
        
        {/* Target line */}
        <ReferenceLine
          y={targetYield}
          stroke="#ff9800"
          strokeDasharray="5 5"
          strokeWidth={2}
          label={{ value: `Target: ${targetYield}%`, position: 'right' }}
        />
        
        {/* Actual yield line */}
        <Line
          type="monotone"
          dataKey="yield"
          stroke="#4caf50"
          strokeWidth={3}
          dot={{ r: 4 }}
          name="Actual Yield"
          fill="url(#colorYield)"
        />
        
        {/* Predicted yield line */}
        <Line
          type="monotone"
          dataKey="predicted"
          stroke="#2196f3"
          strokeWidth={2}
          strokeDasharray="5 5"
          dot={{ r: 3 }}
          name="Predicted Yield"
        />
      </LineChart>
    </ResponsiveContainer>
  );

  const renderScatterChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <ScatterChart>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis
          type="number"
          dataKey="defectDensity"
          name="Defect Density"
          label={{ value: 'Defect Density (%)', position: 'bottom' }}
        />
        <YAxis
          type="number"
          dataKey="yield"
          name="Yield"
          domain={[80, 100]}
          label={{ value: 'Yield (%)', angle: -90, position: 'insideLeft' }}
        />
        <ZAxis range={[100, 400]} />
        <Tooltip
          cursor={{ strokeDasharray: '3 3' }}
          content={({ active, payload }) => {
            if (active && payload && payload.length) {
              const data = payload[0].payload;
              return (
                <Box sx={{ bgcolor: 'background.paper', p: 1.5, border: 1, borderColor: 'divider', borderRadius: 1 }}>
                  <Typography variant="caption" display="block" sx={{ fontWeight: 600 }}>
                    {data.lotId}
                  </Typography>
                  <Typography variant="caption" display="block">
                    Defect Density: {data.defectDensity.toFixed(2)}%
                  </Typography>
                  <Typography variant="caption" display="block">
                    Yield: {data.yield.toFixed(2)}%
                  </Typography>
                </Box>
              );
            }
            return null;
          }}
        />
        <Legend />
        <Scatter
          name="Yield vs Defect Density"
          data={yieldVsDefectData}
          fill="#0066CC"
        />
      </ScatterChart>
    </ResponsiveContainer>
  );

  const renderPredictionChart = () => {
    const futureData = generateFuturePredictions(yieldTrendData);
    
    return (
      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={futureData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis domain={[80, 100]} label={{ value: 'Yield (%)', angle: -90, position: 'insideLeft' }} />
          <Tooltip />
          <Legend />
          
          {/* Target line */}
          <ReferenceLine
            y={targetYield}
            stroke="#ff9800"
            strokeDasharray="5 5"
            strokeWidth={2}
            label={{ value: `Target: ${targetYield}%`, position: 'right' }}
          />
          
          {/* Historical yield */}
          <Line
            type="monotone"
            dataKey="yield"
            stroke="#4caf50"
            strokeWidth={3}
            dot={{ r: 4 }}
            name="Historical Yield"
            connectNulls
          />
          
          {/* Predicted yield */}
          <Line
            type="monotone"
            dataKey="predicted"
            stroke="#2196f3"
            strokeWidth={2}
            strokeDasharray="5 5"
            dot={{ r: 3 }}
            name="Predicted Yield"
            connectNulls
          />
          
          {/* Confidence interval */}
          <Line
            type="monotone"
            dataKey="upperBound"
            stroke="#2196f3"
            strokeWidth={1}
            strokeDasharray="2 2"
            dot={false}
            name="Upper Bound"
            strokeOpacity={0.5}
          />
          <Line
            type="monotone"
            dataKey="lowerBound"
            stroke="#2196f3"
            strokeWidth={1}
            strokeDasharray="2 2"
            dot={false}
            name="Lower Bound"
            strokeOpacity={0.5}
          />
        </LineChart>
      </ResponsiveContainer>
    );
  };

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <Assessment color="primary" />
          <Typography variant="h6" sx={{ fontWeight: 600, flex: 1 }}>
            Yield Analysis
          </Typography>
          <Chip
            icon={yieldGap >= 0 ? <TrendingUp /> : <TrendingDown />}
            label={`${yieldGap >= 0 ? '+' : ''}${yieldGap.toFixed(2)}% vs Target`}
            color={yieldGap >= 0 ? 'success' : 'error'}
            size="small"
          />
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Comprehensive yield analysis with predictions and correlations
        </Typography>

        {/* Chart View Selector */}
        <Box sx={{ mb: 2 }}>
          <ToggleButtonGroup
            value={chartView}
            exclusive
            onChange={(_, value) => value && setChartView(value)}
            size="small"
            fullWidth
          >
            <ToggleButton value="trend">
              Yield Trend
            </ToggleButton>
            <ToggleButton value="scatter">
              Yield vs Defects
            </ToggleButton>
            <ToggleButton value="prediction">
              Yield Prediction
            </ToggleButton>
          </ToggleButtonGroup>
        </Box>

        {/* Render Selected Chart */}
        {chartView === 'trend' && renderYieldTrendChart()}
        {chartView === 'scatter' && renderScatterChart()}
        {chartView === 'prediction' && renderPredictionChart()}

        {/* Yield Statistics */}
        <Box sx={{ mt: 3, p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
            Yield Performance Metrics
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 2 }}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Current Yield
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600, color: 'success.main' }}>
                {currentYield.toFixed(2)}%
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Average Yield
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {avgYield.toFixed(2)}%
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Target Yield
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600, color: 'warning.main' }}>
                {targetYield.toFixed(2)}%
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Gap to Target
              </Typography>
              <Typography
                variant="body2"
                sx={{ fontWeight: 600, color: yieldGap >= 0 ? 'success.main' : 'error.main' }}
              >
                {yieldGap >= 0 ? '+' : ''}
                {yieldGap.toFixed(2)}%
              </Typography>
            </Box>
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
}

function generateFuturePredictions(historicalData: any[]) {
  const lastYield = historicalData[historicalData.length - 1].yield;
  const trend = (lastYield - historicalData[0].yield) / historicalData.length;

  const futureDates = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i + 1);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  });

  const futureData = futureDates.map((date, i) => {
    const predicted = lastYield + trend * (i + 1) + (Math.random() - 0.5) * 0.5;
    return {
      date,
      yield: null,
      predicted: Number(predicted.toFixed(2)),
      upperBound: Number((predicted + 1.5).toFixed(2)),
      lowerBound: Number((predicted - 1.5).toFixed(2)),
      target: 95,
    };
  });

  return [...historicalData.map(d => ({ ...d, upperBound: null, lowerBound: null })), ...futureData];
}
