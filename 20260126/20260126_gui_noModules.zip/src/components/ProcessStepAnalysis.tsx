import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  Chip,
} from '@mui/material';
import {
  FunnelChart,
  Funnel,
  LabelList,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { AccountTree, TrendingUp, TrendingDown } from '@mui/icons-material';

interface ProcessStepAnalysisProps {
  data?: {
    funnelData: {
      name: string;
      value: number;
      fill: string;
    }[];
    comparisonData: {
      step: string;
      defects: number;
      yield: number;
      avgTime: number;
    }[];
    flowData: {
      step: string;
      order: number;
      defectRate: number;
      status: 'good' | 'warning' | 'critical';
    }[];
  };
}

type ViewMode = 'funnel' | 'comparison' | 'flow';

const STEP_COLORS = ['#0066CC', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

export default function ProcessStepAnalysis({
  data = generateMockData(),
}: ProcessStepAnalysisProps) {
  const [viewMode, setViewMode] = useState<ViewMode>('funnel');

  const totalDefects = data.funnelData.reduce((sum, item) => sum + item.value, 0);
  const criticalSteps = data.flowData.filter((s) => s.status === 'critical').length;

  const renderFunnelChart = () => (
    <ResponsiveContainer width="100%" height={450}>
      <FunnelChart>
        <Tooltip
          content={({ active, payload }) => {
            if (active && payload && payload.length) {
              const data = payload[0].payload;
              const percentage = ((data.value / totalDefects) * 100).toFixed(1);
              return (
                <Box sx={{ bgcolor: 'background.paper', p: 1.5, border: 1, borderColor: 'divider', borderRadius: 1 }}>
                  <Typography variant="caption" display="block" sx={{ fontWeight: 600 }}>
                    {data.name}
                  </Typography>
                  <Typography variant="caption" display="block">
                    Defects: {data.value}
                  </Typography>
                  <Typography variant="caption" display="block">
                    Percentage: {percentage}%
                  </Typography>
                </Box>
              );
            }
            return null;
          }}
        />
        <Funnel dataKey="value" data={data.funnelData} isAnimationActive>
          <LabelList position="right" fill="#000" stroke="none" dataKey="name" />
          <LabelList position="center" fill="#fff" stroke="none" dataKey="value" />
        </Funnel>
      </FunnelChart>
    </ResponsiveContainer>
  );

  const renderComparisonChart = () => (
    <Box>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data.comparisonData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="step" />
          <YAxis yAxisId="left" orientation="left" stroke="#0066CC" />
          <YAxis yAxisId="right" orientation="right" stroke="#4caf50" />
          <Tooltip />
          <Legend />
          <Bar yAxisId="left" dataKey="defects" fill="#0066CC" name="Defect Count">
            {data.comparisonData.map((_, index) => (
              <Cell key={`cell-${index}`} fill={STEP_COLORS[index % STEP_COLORS.length]} />
            ))}
          </Bar>
          <Bar yAxisId="right" dataKey="yield" fill="#4caf50" name="Yield (%)" />
        </BarChart>
      </ResponsiveContainer>

      {/* Processing Time Chart */}
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={data.comparisonData} layout="vertical">
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis type="number" label={{ value: 'Avg Time (min)', position: 'bottom' }} />
          <YAxis dataKey="step" type="category" width={100} />
          <Tooltip />
          <Bar dataKey="avgTime" fill="#FF8042" name="Avg Processing Time (min)">
            {data.comparisonData.map((_, index) => (
              <Cell key={`cell-${index}`} fill={STEP_COLORS[index % STEP_COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </Box>
  );

  const renderFlowDiagram = () => {
    const sortedFlow = [...data.flowData].sort((a, b) => a.order - b.order);

    const getStatusColor = (status: string) => {
      switch (status) {
        case 'good':
          return '#4caf50';
        case 'warning':
          return '#ff9800';
        case 'critical':
          return '#f44336';
        default:
          return '#9e9e9e';
      }
    };

    const getStatusLabel = (status: string) => {
      switch (status) {
        case 'good':
          return 'Normal';
        case 'warning':
          return 'Elevated';
        case 'critical':
          return 'Critical';
        default:
          return 'Unknown';
      }
    };

    return (
      <Box>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {sortedFlow.map((step, index) => (
            <Box key={step.step}>
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 2,
                  p: 2,
                  border: 2,
                  borderColor: getStatusColor(step.status),
                  borderRadius: 2,
                  bgcolor: `${getStatusColor(step.status)}15`,
                }}
              >
                <Box
                  sx={{
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    bgcolor: getStatusColor(step.status),
                    color: 'white',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 600,
                  }}
                >
                  {step.order}
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                    {step.step}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Defect Rate: {step.defectRate.toFixed(2)}%
                  </Typography>
                </Box>
                <Chip
                  label={getStatusLabel(step.status)}
                  size="small"
                  sx={{
                    bgcolor: getStatusColor(step.status),
                    color: 'white',
                    fontWeight: 600,
                  }}
                />
                {step.status === 'critical' && (
                  <Chip
                    icon={<TrendingUp />}
                    label="Action Required"
                    size="small"
                    color="error"
                    variant="outlined"
                  />
                )}
              </Box>
              {index < sortedFlow.length - 1 && (
                <Box
                  sx={{
                    width: 2,
                    height: 30,
                    bgcolor: 'divider',
                    ml: 2.5,
                  }}
                />
              )}
            </Box>
          ))}
        </Box>

        {/* Flow Summary */}
        <Box sx={{ mt: 3, p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
            Process Flow Summary
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 2 }}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Total Steps
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {sortedFlow.length}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Critical Steps
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600, color: 'error.main' }}>
                {sortedFlow.filter((s) => s.status === 'critical').length}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Avg Defect Rate
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {(sortedFlow.reduce((sum, s) => sum + s.defectRate, 0) / sortedFlow.length).toFixed(2)}%
              </Typography>
            </Box>
          </Box>
        </Box>
      </Box>
    );
  };

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <AccountTree color="primary" />
          <Typography variant="h6" sx={{ fontWeight: 600, flex: 1 }}>
            Process Step Analysis
          </Typography>
          {criticalSteps > 0 && (
            <Chip
              icon={<TrendingDown />}
              label={`${criticalSteps} Critical Step${criticalSteps > 1 ? 's' : ''}`}
              color="error"
              size="small"
            />
          )}
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Defect analysis across manufacturing process steps
        </Typography>

        {/* View Mode Selector */}
        <Box sx={{ mb: 3 }}>
          <ToggleButtonGroup
            value={viewMode}
            exclusive
            onChange={(_, value) => value && setViewMode(value)}
            size="small"
            fullWidth
          >
            <ToggleButton value="funnel">
              Defect Funnel
            </ToggleButton>
            <ToggleButton value="comparison">
              Step Comparison
            </ToggleButton>
            <ToggleButton value="flow">
              Process Flow
            </ToggleButton>
          </ToggleButtonGroup>
        </Box>

        {/* Render Selected View */}
        {viewMode === 'funnel' && renderFunnelChart()}
        {viewMode === 'comparison' && renderComparisonChart()}
        {viewMode === 'flow' && renderFlowDiagram()}

        {/* Key Insights */}
        <Box sx={{ mt: 3, p: 2, bgcolor: 'info.light', borderRadius: 1 }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
            Key Insights
          </Typography>
          <Typography variant="body2">
            • {data.funnelData[0].name} contributes the most defects ({data.funnelData[0].value} defects)
          </Typography>
          <Typography variant="body2">
            • {data.comparisonData.reduce((max, item) => item.yield > max.yield ? item : max).step} has the highest yield
          </Typography>
          {criticalSteps > 0 && (
            <Typography variant="body2" color="error.main">
              • {criticalSteps} process step{criticalSteps > 1 ? 's require' : ' requires'} immediate attention
            </Typography>
          )}
        </Box>
      </CardContent>
    </Card>
  );
}

// Mock data generator
function generateMockData() {
  const processSteps = ['Lithography', 'Etching', 'Deposition', 'CMP', 'Implantation', 'Annealing'];

  const funnelData = processSteps.map((step, index) => ({
    name: step,
    value: Math.floor(Math.random() * 100) + 50 - index * 10,
    fill: STEP_COLORS[index],
  }));

  const comparisonData = processSteps.map((step) => ({
    step,
    defects: Math.floor(Math.random() * 80) + 20,
    yield: Number((Math.random() * 10 + 88).toFixed(1)),
    avgTime: Number((Math.random() * 30 + 10).toFixed(1)),
  }));

  const flowData = processSteps.map((step, index) => {
    const defectRate = Math.random() * 8 + 1;
    let status: 'good' | 'warning' | 'critical' = 'good';
    if (defectRate > 6) status = 'critical';
    else if (defectRate > 4) status = 'warning';

    return {
      step,
      order: index + 1,
      defectRate: Number(defectRate.toFixed(2)),
      status,
    };
  });

  return { funnelData, comparisonData, flowData };
}
