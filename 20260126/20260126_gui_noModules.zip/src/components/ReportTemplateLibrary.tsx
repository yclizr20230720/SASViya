import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  CardActions,
  Typography,
  Button,
  Grid,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  FileCopy as CopyIcon,
  Visibility as PreviewIcon,
} from '@mui/icons-material';
import type { ReportTemplate, ReportType } from '../types/report';
import ReportTemplatePreview from './ReportTemplatePreview';

export interface ReportTemplateLibraryProps {
  templates: ReportTemplate[];
  onCreateTemplate: (template: Omit<ReportTemplate, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onEditTemplate: (templateId: string) => void;
  onDeleteTemplate: (templateId: string) => void;
  onDuplicateTemplate: (templateId: string) => void;
  onUseTemplate: (templateId: string) => void;
}

const ReportTemplateLibrary: React.FC<ReportTemplateLibraryProps> = ({
  templates,
  onCreateTemplate,
  onEditTemplate,
  onDeleteTemplate,
  onDuplicateTemplate,
  onUseTemplate,
}) => {
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [previewTemplate, setPreviewTemplate] = useState<ReportTemplate | null>(null);
  const [newTemplate, setNewTemplate] = useState({
    name: '',
    description: '',
    type: 'custom' as ReportType,
  });

  const handleCreateTemplate = () => {
    onCreateTemplate({
      ...newTemplate,
      widgets: [],
      layout: 'grid',
      createdBy: 'current-user',
      isDefault: false,
    });
    setCreateDialogOpen(false);
    setNewTemplate({ name: '', description: '', type: 'custom' });
  };

  const getTypeColor = (type: ReportType) => {
    switch (type) {
      case 'daily-summary':
        return 'primary';
      case 'pattern-analysis':
        return 'secondary';
      case 'yield-report':
        return 'success';
      default:
        return 'default';
    }
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h5" fontWeight={600}>
          Report Templates
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setCreateDialogOpen(true)}
        >
          Create Template
        </Button>
      </Box>

      <Grid container spacing={3}>
        {templates.map((template) => (
          <Grid size={{ xs: 12, sm: 6, md: 4 }} key={template.id}>
            <Card>
              <CardContent>
                <Box display="flex" justifyContent="space-between" alignItems="start" mb={2}>
                  <Typography variant="h6" gutterBottom>
                    {template.name}
                  </Typography>
                  {template.isDefault && (
                    <Chip label="Default" size="small" color="primary" />
                  )}
                </Box>
                <Typography variant="body2" color="text.secondary" mb={2}>
                  {template.description}
                </Typography>
                <Chip
                  label={template.type.replace('-', ' ')}
                  size="small"
                  color={getTypeColor(template.type)}
                  sx={{ textTransform: 'capitalize' }}
                />
                <Typography variant="caption" display="block" mt={2} color="text.secondary">
                  {template.widgets.length} widgets • Updated{' '}
                  {new Date(template.updatedAt).toLocaleDateString()}
                </Typography>
              </CardContent>
              <CardActions>
                <IconButton size="small" onClick={() => setPreviewTemplate(template)}>
                  <PreviewIcon fontSize="small" />
                </IconButton>
                <IconButton size="small" onClick={() => onEditTemplate(template.id)}>
                  <EditIcon fontSize="small" />
                </IconButton>
                <IconButton size="small" onClick={() => onDuplicateTemplate(template.id)}>
                  <CopyIcon fontSize="small" />
                </IconButton>
                <IconButton
                  size="small"
                  onClick={() => onDeleteTemplate(template.id)}
                  disabled={template.isDefault}
                >
                  <DeleteIcon fontSize="small" />
                </IconButton>
                <Button
                  size="small"
                  variant="contained"
                  onClick={() => onUseTemplate(template.id)}
                  sx={{ ml: 'auto' }}
                >
                  Use Template
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Create Template Dialog */}
      <Dialog open={createDialogOpen} onClose={() => setCreateDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Create New Report Template</DialogTitle>
        <DialogContent>
          <TextField
            label="Template Name"
            fullWidth
            margin="normal"
            value={newTemplate.name}
            onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
          />
          <TextField
            label="Description"
            fullWidth
            margin="normal"
            multiline
            rows={3}
            value={newTemplate.description}
            onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
          />
          <TextField
            label="Template Type"
            fullWidth
            margin="normal"
            select
            value={newTemplate.type}
            onChange={(e) => setNewTemplate({ ...newTemplate, type: e.target.value as ReportType })}
          >
            <MenuItem value="daily-summary">Daily Summary</MenuItem>
            <MenuItem value="pattern-analysis">Pattern Analysis</MenuItem>
            <MenuItem value="yield-report">Yield Report</MenuItem>
            <MenuItem value="custom">Custom</MenuItem>
          </TextField>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCreateDialogOpen(false)}>Cancel</Button>
          <Button
            onClick={handleCreateTemplate}
            variant="contained"
            disabled={!newTemplate.name}
          >
            Create
          </Button>
        </DialogActions>
      </Dialog>

      {/* Template Preview Dialog */}
      <ReportTemplatePreview
        template={previewTemplate}
        open={!!previewTemplate}
        onClose={() => setPreviewTemplate(null)}
        onUse={() => {
          if (previewTemplate) {
            onUseTemplate(previewTemplate.id);
            setPreviewTemplate(null);
          }
        }}
      />
    </Box>
  );
};

export default ReportTemplateLibrary;
