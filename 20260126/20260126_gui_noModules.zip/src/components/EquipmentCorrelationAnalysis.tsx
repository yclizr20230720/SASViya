import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  Chip,
  Tooltip as MuiTooltip,
} from '@mui/material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { Engineering, Warning, CheckCircle } from '@mui/icons-material';

interface EquipmentCorrelationAnalysisProps {
  data?: {
    equipment_patterns: {
      equipment_id: string;
      patterns: { [key: string]: number };
      total_defects: number;
      defect_rate: number;
    }[];
    correlations: {
      equipment1: string;
      equipment2: string;
      similarity: number;
    }[];
    performance: {
      equipment_id: string;
      uptime: number;
      defect_rate: number;
    }[];
  };
}

type ViewMode = 'heatmap' | 'performance' | 'comparison';

const PATTERN_COLORS: Record<string, string> = {
  'Edge Defect': '#0066CC',
  'Center Defect': '#00C49F',
  'Scratch': '#FFBB28',
  'Ring': '#FF8042',
  'Random': '#8884D8',
};

export default function EquipmentCorrelationAnalysis({
  data,
}: EquipmentCorrelationAnalysisProps) {
  const [viewMode, setViewMode] = useState<ViewMode>('heatmap');
  const [selectedEquipment, setSelectedEquipment] = useState<string | null>(null);

  if (!data || !data.equipment_patterns || data.equipment_patterns.length === 0) {
    return (
      <Card>
        <CardContent>
          <Typography variant="body2" color="text.secondary">
            No equipment correlation data available
          </Typography>
        </CardContent>
      </Card>
    );
  }

  // Transform API data to component format
  const heatmapData = data.equipment_patterns.map(item => {
    let status: 'good' | 'warning' | 'critical' = 'good';
    if (item.defect_rate > 0.05) status = 'critical';
    else if (item.defect_rate > 0.03) status = 'warning';

    return {
      equipment: item.equipment_id,
      patterns: item.patterns,
      totalDefects: item.total_defects,
      status,
    };
  });

  const performanceData = data.performance.map(item => ({
    equipment: item.equipment_id,
    uptime: item.uptime * 100,
    defectRate: item.defect_rate * 100,
    efficiency: (1 - item.defect_rate) * 100,
  }));

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'good':
        return <CheckCircle fontSize="small" color="success" />;
      case 'warning':
        return <Warning fontSize="small" color="warning" />;
      case 'critical':
        return <Warning fontSize="small" color="error" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good':
        return '#4caf50';
      case 'warning':
        return '#ff9800';
      case 'critical':
        return '#f44336';
      default:
        return '#9e9e9e';
    }
  };

  const renderHeatmap = () => {
    const patterns = heatmapData.length > 0 ? Object.keys(heatmapData[0].patterns) : [];
    const maxValue = Math.max(
      ...heatmapData.flatMap((eq) => Object.values(eq.patterns))
    );

    return (
      <Box>
        <Box sx={{ display: 'flex', mb: 2, borderBottom: 1, borderColor: 'divider', pb: 1 }}>
          <Box sx={{ width: 150 }} />
          {patterns.map((pattern) => (
            <Box
              key={pattern}
              sx={{
                flex: 1,
                textAlign: 'center',
                px: 1,
              }}
            >
              <Typography variant="caption" sx={{ fontWeight: 600 }}>
                {pattern}
              </Typography>
            </Box>
          ))}
          <Box sx={{ width: 100, textAlign: 'center' }}>
            <Typography variant="caption" sx={{ fontWeight: 600 }}>
              Total
            </Typography>
          </Box>
        </Box>

        {heatmapData.map((equipment) => (
          <Box
            key={equipment.equipment}
            sx={{
              display: 'flex',
              mb: 1,
              alignItems: 'center',
              '&:hover': { bgcolor: 'action.hover' },
              borderRadius: 1,
              p: 0.5,
            }}
          >
            <Box sx={{ width: 150, display: 'flex', alignItems: 'center', gap: 1 }}>
              {getStatusIcon(equipment.status)}
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {equipment.equipment}
              </Typography>
            </Box>
            {patterns.map((pattern) => {
              const value = equipment.patterns[pattern] || 0;
              const intensity = maxValue > 0 ? value / maxValue : 0;
              const bgColor = `rgba(0, 102, 204, ${intensity})`;

              return (
                <MuiTooltip
                  key={pattern}
                  title={`${pattern}: ${value} defects`}
                  arrow
                >
                  <Box
                    sx={{
                      flex: 1,
                      height: 40,
                      bgcolor: bgColor,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      mx: 0.5,
                      borderRadius: 0.5,
                      cursor: 'pointer',
                      border: 1,
                      borderColor: 'divider',
                    }}
                    onClick={() => setSelectedEquipment(equipment.equipment)}
                  >
                    <Typography
                      variant="caption"
                      sx={{
                        fontWeight: 600,
                        color: intensity > 0.5 ? 'white' : 'text.primary',
                      }}
                    >
                      {value}
                    </Typography>
                  </Box>
                </MuiTooltip>
              );
            })}
            <Box
              sx={{
                width: 100,
                textAlign: 'center',
                px: 1,
              }}
            >
              <Chip
                label={equipment.totalDefects}
                size="small"
                sx={{
                  bgcolor: getStatusColor(equipment.status),
                  color: 'white',
                  fontWeight: 600,
                }}
              />
            </Box>
          </Box>
        ))}

        {/* Legend */}
        <Box sx={{ mt: 3, display: 'flex', alignItems: 'center', gap: 2 }}>
          <Typography variant="caption">Defect Intensity:</Typography>
          <Box
            sx={{
              width: 200,
              height: 20,
              background: 'linear-gradient(to right, rgba(0, 102, 204, 0), rgba(0, 102, 204, 1))',
              borderRadius: 0.5,
              border: 1,
              borderColor: 'divider',
            }}
          />
          <Typography variant="caption">Low → High</Typography>
        </Box>
      </Box>
    );
  };

  const renderPerformanceChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={performanceData} layout="vertical">
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis type="number" domain={[0, 100]} />
        <YAxis dataKey="equipment" type="category" width={100} />
        <Tooltip />
        <Legend />
        <Bar dataKey="uptime" fill="#4caf50" name="Uptime (%)" />
        <Bar dataKey="efficiency" fill="#2196f3" name="Efficiency (%)" />
      </BarChart>
    </ResponsiveContainer>
  );

  const renderComparisonChart = () => {
    const comparisonData = heatmapData.map((eq) => ({
      equipment: eq.equipment,
      ...eq.patterns,
    }));

    const patterns = heatmapData.length > 0 ? Object.keys(heatmapData[0].patterns) : [];

    return (
      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={comparisonData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="equipment" />
          <YAxis />
          <Tooltip />
          <Legend />
          {patterns.map((pattern) => (
            <Bar
              key={pattern}
              dataKey={pattern}
              fill={PATTERN_COLORS[pattern] || '#8884d8'}
              stackId="a"
            />
          ))}
        </BarChart>
      </ResponsiveContainer>
    );
  };

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <Engineering color="primary" />
          <Typography variant="h6" sx={{ fontWeight: 600, flex: 1 }}>
            Equipment Correlation Analysis
          </Typography>
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Defect pattern correlation by equipment with performance metrics
        </Typography>

        {/* View Mode Selector */}
        <Box sx={{ mb: 3 }}>
          <ToggleButtonGroup
            value={viewMode}
            exclusive
            onChange={(_, value) => value && setViewMode(value)}
            size="small"
            fullWidth
          >
            <ToggleButton value="heatmap">
              Correlation Heatmap
            </ToggleButton>
            <ToggleButton value="performance">
              Performance Metrics
            </ToggleButton>
            <ToggleButton value="comparison">
              Equipment Comparison
            </ToggleButton>
          </ToggleButtonGroup>
        </Box>

        {/* Render Selected View */}
        {viewMode === 'heatmap' && renderHeatmap()}
        {viewMode === 'performance' && renderPerformanceChart()}
        {viewMode === 'comparison' && renderComparisonChart()}

        {/* Equipment Status Summary */}
        <Box sx={{ mt: 3, p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
            Equipment Status Summary
          </Typography>
          <Box sx={{ display: 'flex', gap: 3, mt: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <CheckCircle fontSize="small" color="success" />
              <Typography variant="body2">
                <strong>{heatmapData.filter((e) => e.status === 'good').length}</strong> Good
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Warning fontSize="small" color="warning" />
              <Typography variant="body2">
                <strong>{heatmapData.filter((e) => e.status === 'warning').length}</strong> Warning
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Warning fontSize="small" color="error" />
              <Typography variant="body2">
                <strong>{heatmapData.filter((e) => e.status === 'critical').length}</strong> Critical
              </Typography>
            </Box>
          </Box>
        </Box>

        {/* Selected Equipment Details */}
        {selectedEquipment && (
          <Box sx={{ mt: 2, p: 2, bgcolor: 'info.light', borderRadius: 1 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
              Selected: {selectedEquipment}
            </Typography>
            <Typography variant="body2">
              Click on heatmap cells to view detailed equipment analysis
            </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
}

// No longer need mock data generator
