/**
 * Real-Time Training Monitor Component
 * 
 * Displays live training progress, console logs, and metrics
 */
import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  LinearProgress,
  Paper,
  Chip,
  IconButton,
  Tooltip,
  Divider,
  Alert,
  Button,
  Switch,
  FormControlLabel
} from '@mui/material';
import {
  PlayArrow,
  Pause,
  Stop,
  Refresh,
  Download,
  Timeline,
  Terminal,
  Assessment
} from '@mui/icons-material';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip as ChartTooltip,
  Legend,
  Filler
} from 'chart.js';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  ChartTooltip,
  Legend,
  Filler
);

interface TrainingMetrics {
  epoch: number;
  train_loss: number;
  train_pattern_acc: number;
  train_root_cause_acc: number;
  val_loss: number;
  val_pattern_acc: number;
  val_root_cause_acc: number;
  learning_rate: number;
}

interface TrainingProgress {
  current_epoch: number;
  total_epochs: number;
  percentage: number;
  estimated_time_remaining_minutes: number;
}

interface TrainingMonitorProps {
  jobId: string;
  onClose?: () => void;
}

const TrainingMonitor: React.FC<TrainingMonitorProps> = ({ jobId, onClose }) => {
  const [status, setStatus] = useState<string>('unknown');
  const [progress, setProgress] = useState<TrainingProgress>({
    current_epoch: 0,
    total_epochs: 0,
    percentage: 0,
    estimated_time_remaining_minutes: 0
  });
  const [currentMetrics, setCurrentMetrics] = useState<TrainingMetrics | null>(null);
  const [metricsHistory, setMetricsHistory] = useState<TrainingMetrics[]>([]);
  const [logs, setLogs] = useState<string[]>([]);
  const [autoScroll, setAutoScroll] = useState(true);
  const [showLogs, setShowLogs] = useState(true);
  const [showMetrics, setShowMetrics] = useState(true);
  
  const logsEndRef = useRef<HTMLDivElement>(null);
  const pollIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Auto-scroll logs to bottom
  useEffect(() => {
    if (autoScroll && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, autoScroll]);

  // Fetch training metrics
  const fetchMetrics = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/v1/training/metrics/${jobId}`);
      const data = await response.json();
      
      if (data.status === 'success') {
        setStatus(data.training_status);
        setProgress(data.progress);
        setCurrentMetrics(data.current_metrics);
        setMetricsHistory(data.metrics_history || []);
      }
    } catch (error) {
      console.error('Error fetching metrics:', error);
    }
  };

  // Fetch training logs
  const fetchLogs = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/v1/training/logs/${jobId}?lines=100`);
      const data = await response.json();
      
      if (data.status === 'success') {
        setLogs(data.logs || []);
      }
    } catch (error) {
      console.error('Error fetching logs:', error);
    }
  };

  // Poll for updates
  useEffect(() => {
    // Initial fetch
    fetchMetrics();
    fetchLogs();

    // Poll every 2 seconds if training is running
    if (status === 'running' || status === 'queued') {
      pollIntervalRef.current = setInterval(() => {
        fetchMetrics();
        fetchLogs();
      }, 2000);
    }

    return () => {
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
      }
    };
  }, [jobId, status]);

  // Stop training
  const handleStop = async () => {
    try {
      await fetch(`http://localhost:5000/api/v1/training/stop/${jobId}`, {
        method: 'POST'
      });
      fetchMetrics();
    } catch (error) {
      console.error('Error stopping training:', error);
    }
  };

  // Download logs
  const handleDownloadLogs = () => {
    const blob = new Blob([logs.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `training_${jobId}_logs.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Format time remaining
  const formatTimeRemaining = (minutes: number): string => {
    if (minutes < 1) return '< 1 minute';
    if (minutes < 60) return `${Math.round(minutes)} minutes`;
    const hours = Math.floor(minutes / 60);
    const mins = Math.round(minutes % 60);
    return `${hours}h ${mins}m`;
  };

  // Status color
  const getStatusColor = (status: string): 'success' | 'error' | 'warning' | 'info' | 'default' => {
    switch (status) {
      case 'completed': return 'success';
      case 'failed': return 'error';
      case 'running': return 'info';
      case 'queued': return 'warning';
      default: return 'default';
    }
  };

  // Prepare chart data
  const chartData = {
    labels: metricsHistory.map((m) => `Epoch ${m.epoch}`),
    datasets: [
      {
        label: 'Train Loss',
        data: metricsHistory.map((m) => m.train_loss),
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.1)',
        tension: 0.4,
        fill: true
      },
      {
        label: 'Val Loss',
        data: metricsHistory.map((m) => m.val_loss),
        borderColor: 'rgb(54, 162, 235)',
        backgroundColor: 'rgba(54, 162, 235, 0.1)',
        tension: 0.4,
        fill: true
      }
    ]
  };

  const accuracyChartData = {
    labels: metricsHistory.map((m) => `Epoch ${m.epoch}`),
    datasets: [
      {
        label: 'Train Pattern Acc',
        data: metricsHistory.map((m) => m.train_pattern_acc * 100),
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.1)',
        tension: 0.4,
        fill: true
      },
      {
        label: 'Val Pattern Acc',
        data: metricsHistory.map((m) => m.val_pattern_acc * 100),
        borderColor: 'rgb(153, 102, 255)',
        backgroundColor: 'rgba(153, 102, 255, 0.1)',
        tension: 0.4,
        fill: true
      },
      {
        label: 'Train Root Cause Acc',
        data: metricsHistory.map((m) => m.train_root_cause_acc * 100),
        borderColor: 'rgb(255, 159, 64)',
        backgroundColor: 'rgba(255, 159, 64, 0.1)',
        tension: 0.4,
        fill: true
      },
      {
        label: 'Val Root Cause Acc',
        data: metricsHistory.map((m) => m.val_root_cause_acc * 100),
        borderColor: 'rgb(255, 205, 86)',
        backgroundColor: 'rgba(255, 205, 86, 0.1)',
        tension: 0.4,
        fill: true
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const
      },
      title: {
        display: false
      }
    },
    scales: {
      y: {
        beginAtZero: true
      }
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h5" gutterBottom>
            Training Monitor
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Job ID: {jobId}
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Chip
            label={status.toUpperCase()}
            color={getStatusColor(status)}
            size="small"
          />
          {status === 'running' && (
            <Tooltip title="Stop Training">
              <IconButton onClick={handleStop} color="error" size="small">
                <Stop />
              </IconButton>
            </Tooltip>
          )}
          <Tooltip title="Refresh">
            <IconButton onClick={() => { fetchMetrics(); fetchLogs(); }} size="small">
              <Refresh />
            </IconButton>
          </Tooltip>
          <Tooltip title="Download Logs">
            <IconButton onClick={handleDownloadLogs} size="small">
              <Download />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>

      {/* Progress Bar */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
            <Typography variant="body2" color="text.secondary">
              Epoch {progress.current_epoch} / {progress.total_epochs}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {progress.percentage.toFixed(1)}%
            </Typography>
          </Box>
          <LinearProgress
            variant="determinate"
            value={progress.percentage}
            sx={{ height: 10, borderRadius: 5 }}
          />
          {progress.estimated_time_remaining_minutes > 0 && (
            <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
              Estimated time remaining: {formatTimeRemaining(progress.estimated_time_remaining_minutes)}
            </Typography>
          )}
        </CardContent>
      </Card>

      {/* Current Metrics */}
      {currentMetrics && (
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">
                  Train Loss
                </Typography>
                <Typography variant="h6">
                  {currentMetrics.train_loss.toFixed(4)}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">
                  Val Loss
                </Typography>
                <Typography variant="h6">
                  {currentMetrics.val_loss.toFixed(4)}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">
                  Pattern Accuracy
                </Typography>
                <Typography variant="h6">
                  {(currentMetrics.val_pattern_acc * 100).toFixed(1)}%
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">
                  Root Cause Accuracy
                </Typography>
                <Typography variant="h6">
                  {(currentMetrics.val_root_cause_acc * 100).toFixed(1)}%
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Toggle Buttons */}
      <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
        <Button
          variant={showMetrics ? 'contained' : 'outlined'}
          startIcon={<Assessment />}
          onClick={() => setShowMetrics(!showMetrics)}
          size="small"
        >
          Metrics Charts
        </Button>
        <Button
          variant={showLogs ? 'contained' : 'outlined'}
          startIcon={<Terminal />}
          onClick={() => setShowLogs(!showLogs)}
          size="small"
        >
          Console Logs
        </Button>
      </Box>

      {/* Metrics Charts */}
      {showMetrics && metricsHistory.length > 0 && (
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Loss Over Time
                </Typography>
                <Box sx={{ height: 300 }}>
                  <Line data={chartData} options={chartOptions} />
                </Box>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Accuracy Over Time
                </Typography>
                <Box sx={{ height: 300 }}>
                  <Line data={accuracyChartData} options={chartOptions} />
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Console Logs */}
      {showLogs && (
        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Console Output
              </Typography>
              <FormControlLabel
                control={
                  <Switch
                    checked={autoScroll}
                    onChange={(e) => setAutoScroll(e.target.checked)}
                    size="small"
                  />
                }
                label="Auto-scroll"
              />
            </Box>
            <Paper
              sx={{
                p: 2,
                bgcolor: '#1e1e1e',
                color: '#d4d4d4',
                fontFamily: 'monospace',
                fontSize: '0.875rem',
                maxHeight: 400,
                overflow: 'auto',
                '&::-webkit-scrollbar': {
                  width: '8px'
                },
                '&::-webkit-scrollbar-track': {
                  background: '#2d2d2d'
                },
                '&::-webkit-scrollbar-thumb': {
                  background: '#555',
                  borderRadius: '4px'
                }
              }}
            >
              {logs.length === 0 ? (
                <Typography variant="body2" color="text.secondary">
                  No logs available yet...
                </Typography>
              ) : (
                logs.map((log, index) => (
                  <Box key={index} sx={{ mb: 0.5 }}>
                    {log}
                  </Box>
                ))
              )}
              <div ref={logsEndRef} />
            </Paper>
          </CardContent>
        </Card>
      )}
    </Box>
  );
};

export default TrainingMonitor;
