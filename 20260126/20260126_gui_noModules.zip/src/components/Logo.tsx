import React from 'react';
import { Box, BoxProps } from '@mui/material';

interface LogoProps extends BoxProps {
  variant?: 'full' | 'icon' | 'horizontal';
  width?: number | string;
  height?: number | string;
}

/**
 * Logo component for AI Wafer Map application
 * 
 * Variants:
 * - full: Complete logo with VSMC branding (800x300)
 * - icon: Icon only for favicons and small spaces (200x200)
 * - horizontal: Compact horizontal layout (600x120)
 */
const Logo: React.FC<LogoProps> = ({ 
  variant = 'horizontal', 
  width, 
  height,
  sx,
  ...props 
}) => {
  const logoSrc = {
    full: '/logo.svg',
    icon: '/logo-icon.svg',
    horizontal: '/logo-horizontal.svg'
  }[variant];

  const defaultDimensions = {
    full: { width: 800, height: 300 },
    icon: { width: 200, height: 200 },
    horizontal: { width: 600, height: 120 }
  }[variant];

  return (
    <Box
      component="img"
      src={logoSrc}
      alt="VSMC AI Wafer Map"
      sx={{
        width: width || defaultDimensions.width,
        height: height || defaultDimensions.height,
        objectFit: 'contain',
        ...sx
      }}
      {...props}
    />
  );
};

export default Logo;
