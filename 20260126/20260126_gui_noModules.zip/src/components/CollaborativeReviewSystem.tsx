import { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Avatar,
  AvatarGroup,
  Chip,
  TextField,
  Button,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Divider,
  IconButton,
  Tooltip,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Badge,
  Stack,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import {
  Send,
  Reply,
  ThumbUp,
  CheckCircle,
  Assignment,
  FiberManualRecord,
  PersonAdd,
  Notifications,
} from '@mui/icons-material';

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  content: string;
  timestamp: string;
  replies?: Comment[];
  likes: number;
  likedByCurrentUser: boolean;
}

export interface ReviewAssignment {
  id: string;
  waferId: string;
  assignedTo: string;
  assignedBy: string;
  status: 'pending' | 'in_progress' | 'completed' | 'rejected';
  priority: 'low' | 'medium' | 'high' | 'critical';
  dueDate: string;
  createdAt: string;
}

export interface ActiveUser {
  userId: string;
  userName: string;
  userAvatar?: string;
  isOnline: boolean;
  currentAction?: string;
}

export interface CollaborativeReviewSystemProps {
  waferId: string;
  currentUserId: string;
  currentUserName: string;
  onCommentAdded?: (comment: Comment) => void;
  onAssignmentCreated?: (assignment: ReviewAssignment) => void;
}

const CollaborativeReviewSystem: React.FC<CollaborativeReviewSystemProps> = ({
  waferId,
  currentUserId,
  currentUserName,
  onCommentAdded,
  onAssignmentCreated,
}) => {
  // State management
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [activeUsers, setActiveUsers] = useState<ActiveUser[]>([]);
  const [assignments, setAssignments] = useState<ReviewAssignment[]>([]);
  const [showAssignDialog, setShowAssignDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState('');
  const [assignmentPriority, setAssignmentPriority] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');
  const [notifications, setNotifications] = useState<string[]>([]);

  // Mock data for demonstration
  useEffect(() => {
    // Simulate loading existing comments
    const mockComments: Comment[] = [
      {
        id: '1',
        userId: 'user1',
        userName: 'John Doe',
        userAvatar: undefined,
        content: 'I noticed a center pattern defect. This might be related to lithography focus issues.',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        likes: 3,
        likedByCurrentUser: false,
        replies: [
          {
            id: '1-1',
            userId: 'user2',
            userName: 'Jane Smith',
            content: 'Agreed. I checked the equipment logs and found focus offset anomalies.',
            timestamp: new Date(Date.now() - 1800000).toISOString(),
            likes: 1,
            likedByCurrentUser: false,
          },
        ],
      },
    ];
    setComments(mockComments);

    // Simulate active users
    const mockActiveUsers: ActiveUser[] = [
      {
        userId: currentUserId,
        userName: currentUserName,
        isOnline: true,
        currentAction: 'Viewing wafer',
      },
      {
        userId: 'user1',
        userName: 'John Doe',
        isOnline: true,
        currentAction: 'Adding annotation',
      },
      {
        userId: 'user2',
        userName: 'Jane Smith',
        isOnline: true,
      },
    ];
    setActiveUsers(mockActiveUsers);

    // Simulate assignments
    const mockAssignments: ReviewAssignment[] = [
      {
        id: 'assign1',
        waferId,
        assignedTo: 'user1',
        assignedBy: currentUserId,
        status: 'in_progress',
        priority: 'high',
        dueDate: new Date(Date.now() + 86400000).toISOString(),
        createdAt: new Date(Date.now() - 7200000).toISOString(),
      },
    ];
    setAssignments(mockAssignments);

    // Simulate real-time updates (WebSocket simulation)
    const interval = setInterval(() => {
      // Simulate user activity updates
      setActiveUsers((prev) =>
        prev.map((user) => ({
          ...user,
          currentAction: Math.random() > 0.5 ? 'Viewing wafer' : undefined,
        }))
      );
    }, 5000);

    return () => clearInterval(interval);
  }, [waferId, currentUserId, currentUserName]);

  // Handle comment submission
  const handleSubmitComment = () => {
    if (!newComment.trim()) return;

    const comment: Comment = {
      id: `comment-${Date.now()}`,
      userId: currentUserId,
      userName: currentUserName,
      content: newComment,
      timestamp: new Date().toISOString(),
      likes: 0,
      likedByCurrentUser: false,
      replies: [],
    };

    setComments([...comments, comment]);
    setNewComment('');
    onCommentAdded?.(comment);

    // Simulate notification to other users
    setNotifications([...notifications, `${currentUserName} added a new comment`]);
  };

  // Handle reply submission
  const handleSubmitReply = (parentId: string) => {
    if (!replyContent.trim()) return;

    const reply: Comment = {
      id: `reply-${Date.now()}`,
      userId: currentUserId,
      userName: currentUserName,
      content: replyContent,
      timestamp: new Date().toISOString(),
      likes: 0,
      likedByCurrentUser: false,
    };

    setComments(
      comments.map((comment) => {
        if (comment.id === parentId) {
          return {
            ...comment,
            replies: [...(comment.replies || []), reply],
          };
        }
        return comment;
      })
    );

    setReplyContent('');
    setReplyingTo(null);
  };

  // Handle like/unlike
  const handleLike = (commentId: string) => {
    setComments(
      comments.map((comment) => {
        if (comment.id === commentId) {
          return {
            ...comment,
            likes: comment.likedByCurrentUser ? comment.likes - 1 : comment.likes + 1,
            likedByCurrentUser: !comment.likedByCurrentUser,
          };
        }
        return comment;
      })
    );
  };

  // Handle assignment creation
  const handleCreateAssignment = () => {
    if (!selectedUser) return;

    const assignment: ReviewAssignment = {
      id: `assign-${Date.now()}`,
      waferId,
      assignedTo: selectedUser,
      assignedBy: currentUserId,
      status: 'pending',
      priority: assignmentPriority,
      dueDate: new Date(Date.now() + 86400000).toISOString(),
      createdAt: new Date().toISOString(),
    };

    setAssignments([...assignments, assignment]);
    setShowAssignDialog(false);
    setSelectedUser('');
    onAssignmentCreated?.(assignment);

    // Simulate notification
    const assignedUser = activeUsers.find((u) => u.userId === selectedUser);
    setNotifications([
      ...notifications,
      `Review assigned to ${assignedUser?.userName || selectedUser}`,
    ]);
  };

  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <Box sx={{ p: 2 }}>
      {/* Notifications */}
      {notifications.length > 0 && (
        <Alert
          severity="info"
          onClose={() => setNotifications([])}
          sx={{ mb: 2 }}
          icon={<Notifications />}
        >
          {notifications[notifications.length - 1]}
        </Alert>
      )}

      {/* Active Users */}
      <Card sx={{ mb: 2 }}>
        <CardContent>
          <Stack direction="row" alignItems="center" justifyContent="space-between" mb={2}>
            <Typography variant="h6">Active Reviewers</Typography>
            <Button
              startIcon={<PersonAdd />}
              variant="outlined"
              size="small"
              onClick={() => setShowAssignDialog(true)}
            >
              Assign Review
            </Button>
          </Stack>

          <Stack direction="row" spacing={2} alignItems="center">
            <AvatarGroup max={5}>
              {activeUsers.map((user) => (
                <Tooltip
                  key={user.userId}
                  title={`${user.userName}${user.currentAction ? ` - ${user.currentAction}` : ''}`}
                >
                  <Badge
                    overlap="circular"
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                    variant="dot"
                    sx={{
                      '& .MuiBadge-badge': {
                        backgroundColor: user.isOnline ? '#44b700' : '#gray',
                        color: user.isOnline ? '#44b700' : '#gray',
                      },
                    }}
                  >
                    <Avatar>{user.userName.charAt(0)}</Avatar>
                  </Badge>
                </Tooltip>
              ))}
            </AvatarGroup>
            <Typography variant="body2" color="text.secondary">
              {activeUsers.filter((u) => u.isOnline).length} online
            </Typography>
          </Stack>
        </CardContent>
      </Card>

      {/* Review Assignments */}
      {assignments.length > 0 && (
        <Card sx={{ mb: 2 }}>
          <CardContent>
            <Typography variant="h6" mb={2}>
              Review Assignments
            </Typography>
            <List>
              {assignments.map((assignment, index) => (
                <Box key={assignment.id}>
                  <ListItem>
                    <ListItemAvatar>
                      <Avatar>
                        <Assignment />
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      primary={`Assigned to ${activeUsers.find((u) => u.userId === assignment.assignedTo)?.userName || assignment.assignedTo}`}
                      secondary={
                        <Stack direction="row" spacing={1} alignItems="center">
                          <Chip
                            label={assignment.status.replace('_', ' ')}
                            size="small"
                            color={
                              assignment.status === 'completed'
                                ? 'success'
                                : assignment.status === 'in_progress'
                                  ? 'primary'
                                  : 'default'
                            }
                            icon={
                              assignment.status === 'completed' ? (
                                <CheckCircle />
                              ) : (
                                <FiberManualRecord />
                              )
                            }
                          />
                          <Chip
                            label={assignment.priority}
                            size="small"
                            color={
                              assignment.priority === 'critical'
                                ? 'error'
                                : assignment.priority === 'high'
                                  ? 'warning'
                                  : 'default'
                            }
                          />
                          <Typography variant="caption">
                            Due: {new Date(assignment.dueDate).toLocaleDateString()}
                          </Typography>
                        </Stack>
                      }
                    />
                  </ListItem>
                  {index < assignments.length - 1 && <Divider />}
                </Box>
              ))}
            </List>
          </CardContent>
        </Card>
      )}

      {/* Comments Section */}
      <Card>
        <CardContent>
          <Typography variant="h6" mb={2}>
            Discussion & Comments
          </Typography>

          {/* Comment List */}
          <List>
            {comments.map((comment, index) => (
              <Box key={comment.id}>
                <ListItem alignItems="flex-start">
                  <ListItemAvatar>
                    <Avatar>{comment.userName.charAt(0)}</Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Stack direction="row" alignItems="center" spacing={1}>
                        <Typography variant="subtitle2">{comment.userName}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          {formatTimestamp(comment.timestamp)}
                        </Typography>
                      </Stack>
                    }
                    secondary={
                      <Box>
                        <Typography variant="body2" sx={{ mt: 1 }}>
                          {comment.content}
                        </Typography>
                        <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                          <IconButton
                            size="small"
                            onClick={() => handleLike(comment.id)}
                            color={comment.likedByCurrentUser ? 'primary' : 'default'}
                          >
                            <ThumbUp fontSize="small" />
                          </IconButton>
                          <Typography variant="caption" sx={{ pt: 0.5 }}>
                            {comment.likes}
                          </Typography>
                          <IconButton
                            size="small"
                            onClick={() => setReplyingTo(comment.id)}
                          >
                            <Reply fontSize="small" />
                          </IconButton>
                        </Stack>

                        {/* Replies */}
                        {comment.replies && comment.replies.length > 0 && (
                          <Box sx={{ ml: 4, mt: 2 }}>
                            {comment.replies.map((reply) => (
                              <Box key={reply.id} sx={{ mb: 2 }}>
                                <Stack direction="row" spacing={1} alignItems="center">
                                  <Avatar sx={{ width: 24, height: 24 }}>
                                    {reply.userName.charAt(0)}
                                  </Avatar>
                                  <Typography variant="caption" fontWeight="bold">
                                    {reply.userName}
                                  </Typography>
                                  <Typography variant="caption" color="text.secondary">
                                    {formatTimestamp(reply.timestamp)}
                                  </Typography>
                                </Stack>
                                <Typography variant="body2" sx={{ ml: 4 }}>
                                  {reply.content}
                                </Typography>
                              </Box>
                            ))}
                          </Box>
                        )}

                        {/* Reply Input */}
                        {replyingTo === comment.id && (
                          <Box sx={{ ml: 4, mt: 2 }}>
                            <TextField
                              fullWidth
                              size="small"
                              placeholder="Write a reply..."
                              value={replyContent}
                              onChange={(e) => setReplyContent(e.target.value)}
                              multiline
                              rows={2}
                            />
                            <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                              <Button
                                size="small"
                                variant="contained"
                                onClick={() => handleSubmitReply(comment.id)}
                                disabled={!replyContent.trim()}
                              >
                                Reply
                              </Button>
                              <Button
                                size="small"
                                variant="outlined"
                                onClick={() => {
                                  setReplyingTo(null);
                                  setReplyContent('');
                                }}
                              >
                                Cancel
                              </Button>
                            </Stack>
                          </Box>
                        )}
                      </Box>
                    }
                  />
                </ListItem>
                {index < comments.length - 1 && <Divider />}
              </Box>
            ))}
          </List>

          {/* New Comment Input */}
          <Box sx={{ mt: 3 }}>
            <TextField
              fullWidth
              placeholder="Add a comment..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              multiline
              rows={3}
              variant="outlined"
            />
            <Button
              variant="contained"
              startIcon={<Send />}
              onClick={handleSubmitComment}
              disabled={!newComment.trim()}
              sx={{ mt: 1 }}
            >
              Post Comment
            </Button>
          </Box>
        </CardContent>
      </Card>

      {/* Assignment Dialog */}
      <Dialog open={showAssignDialog} onClose={() => setShowAssignDialog(false)}>
        <DialogTitle>Assign Review</DialogTitle>
        <DialogContent>
          <FormControl fullWidth sx={{ mt: 2 }}>
            <InputLabel>Assign To</InputLabel>
            <Select
              value={selectedUser}
              onChange={(e) => setSelectedUser(e.target.value)}
              label="Assign To"
            >
              {activeUsers
                .filter((u) => u.userId !== currentUserId)
                .map((user) => (
                  <MenuItem key={user.userId} value={user.userId}>
                    {user.userName}
                  </MenuItem>
                ))}
            </Select>
          </FormControl>

          <FormControl fullWidth sx={{ mt: 2 }}>
            <InputLabel>Priority</InputLabel>
            <Select
              value={assignmentPriority}
              onChange={(e) =>
                setAssignmentPriority(e.target.value as 'low' | 'medium' | 'high' | 'critical')
              }
              label="Priority"
            >
              <MenuItem value="low">Low</MenuItem>
              <MenuItem value="medium">Medium</MenuItem>
              <MenuItem value="high">High</MenuItem>
              <MenuItem value="critical">Critical</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowAssignDialog(false)}>Cancel</Button>
          <Button
            onClick={handleCreateAssignment}
            variant="contained"
            disabled={!selectedUser}
          >
            Assign
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default CollaborativeReviewSystem;
