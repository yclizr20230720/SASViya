/**
 * GAN Management Page
 * 
 * Comprehensive page for managing GAN training, synthetic generation, and quality validation
 */
import React, { useState } from 'react';
import {
  Box,
  Container,
  Typography,
  Tabs,
  Tab,
  Paper
} from '@mui/material';
import GANTraining from '../../components/training/GANTraining';
import SyntheticGeneration from '../../components/training/SyntheticGeneration';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`gan-tabpanel-${index}`}
      aria-labelledby={`gan-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
}

const GANManagement: React.FC = () => {
  const [currentTab, setCurrentTab] = useState(0);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setCurrentTab(newValue);
  };

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      {/* Page Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={600} gutterBottom>
          GAN Management
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Train GAN models and generate synthetic wafer maps for data augmentation
        </Typography>
      </Box>

      {/* Tabs */}
      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={currentTab}
          onChange={handleTabChange}
          aria-label="GAN management tabs"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label="GAN Training" />
          <Tab label="Synthetic Generation" />
        </Tabs>
      </Paper>

      {/* Tab Panels */}
      <TabPanel value={currentTab} index={0}>
        <GANTraining />
      </TabPanel>

      <TabPanel value={currentTab} index={1}>
        <SyntheticGeneration />
      </TabPanel>
    </Container>
  );
};

export default GANManagement;
