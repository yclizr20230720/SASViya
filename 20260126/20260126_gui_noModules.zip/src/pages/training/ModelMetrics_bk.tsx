import { useState } from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Button,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  List,
  ListItem,
  ListItemButton,
  IconButton,
  Menu,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tabs,
  Tab,
  Card,
  CardContent,
  Divider,
  Tooltip,
  Alert,
} from '@mui/material';
import {
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  CheckCircle as CheckCircleIcon,
  RadioButtonChecked as ActiveIcon,
  RadioButtonUnchecked as InactiveIcon,
  CompareArrows as CompareIcon,
  CloudUpload as DeployIcon,
  Archive as ArchiveIcon,
  Download as DownloadIcon,
  MoreVert as MoreIcon,
  Info as InfoIcon,
  Speed as SpeedIcon,
  Memory as MemoryIcon,
  Timer as TimerIcon,
  Code as CodeIcon,
  Assessment as MetricsIcon,
} from '@mui/icons-material';
import { XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

// Model version interface
interface ModelVersion {
  id: string;
  version: string;
  architecture: string;
  status: 'active' | 'staging' | 'development' | 'archived';
  accuracy: number;
  f1Score: number;
  precision: number;
  recall: number;
  trainedDate: string;
  trainedBy: string;
  trainingDuration: string;
  datasetSize: number;
  epochs: number;
  batchSize: number;
  learningRate: number;
  optimizer: string;
  tags: string[];
  deployments: {
    environment: string;
    deployedDate: string;
    status: string;
  }[];
  artifacts: {
    modelWeights: string;
    onnxExport: string;
    tensorrtExport: string;
  };
}

// Mock model versions data
const mockModelVersions: ModelVersion[] = [
  {
    id: 'model-v4.2',
    version: 'v4.2.0',
    architecture: 'ResNet50-WV',
    status: 'active',
    accuracy: 0.972,
    f1Score: 0.955,
    precision: 0.962,
    recall: 0.948,
    trainedDate: '2024-05-20 14:30',
    trainedBy: 'Dr. Sarah Chen',
    trainingDuration: '4h 23m',
    datasetSize: 14224,
    epochs: 50,
    batchSize: 32,
    learningRate: 0.001,
    optimizer: 'AdamW',
    tags: ['production', 'validated', 'high-accuracy'],
    deployments: [
      { environment: 'Production', deployedDate: '2024-05-20 16:00', status: 'active' },
      { environment: 'Staging', deployedDate: '2024-05-20 15:00', status: 'active' },
    ],
    artifacts: {
      modelWeights: 'resnet50-wv-v4.2.pth',
      onnxExport: 'resnet50-wv-v4.2.onnx',
      tensorrtExport: 'resnet50-wv-v4.2.trt',
    },
  },
  {
    id: 'model-v4.1',
    version: 'v4.1.0',
    architecture: 'ResNet50-WV',
    status: 'staging',
    accuracy: 0.968,
    f1Score: 0.951,
    precision: 0.958,
    recall: 0.944,
    trainedDate: '2024-05-18 10:15',
    trainedBy: 'Dr. Sarah Chen',
    trainingDuration: '4h 18m',
    datasetSize: 13890,
    epochs: 50,
    batchSize: 32,
    learningRate: 0.001,
    optimizer: 'AdamW',
    tags: ['staging', 'validated'],
    deployments: [{ environment: 'Staging', deployedDate: '2024-05-18 12:00', status: 'replaced' }],
    artifacts: {
      modelWeights: 'resnet50-wv-v4.1.pth',
      onnxExport: 'resnet50-wv-v4.1.onnx',
      tensorrtExport: 'resnet50-wv-v4.1.trt',
    },
  },
  {
    id: 'model-v4.0',
    version: 'v4.0.0',
    architecture: 'ResNet50-WV',
    status: 'development',
    accuracy: 0.964,
    f1Score: 0.947,
    precision: 0.954,
    recall: 0.940,
    trainedDate: '2024-05-15 09:00',
    trainedBy: 'Dr. Michael Zhang',
    trainingDuration: '4h 10m',
    datasetSize: 13200,
    epochs: 45,
    batchSize: 32,
    learningRate: 0.001,
    optimizer: 'Adam',
    tags: ['development', 'experimental'],
    deployments: [],
    artifacts: {
      modelWeights: 'resnet50-wv-v4.0.pth',
      onnxExport: 'resnet50-wv-v4.0.onnx',
      tensorrtExport: '',
    },
  },
  {
    id: 'model-v3.5',
    version: 'v3.5.2',
    architecture: 'EfficientNet-B3',
    status: 'archived',
    accuracy: 0.958,
    f1Score: 0.942,
    precision: 0.950,
    recall: 0.934,
    trainedDate: '2024-05-10 14:00',
    trainedBy: 'Dr. Sarah Chen',
    trainingDuration: '3h 45m',
    datasetSize: 12800,
    epochs: 40,
    batchSize: 24,
    learningRate: 0.0005,
    optimizer: 'SGD',
    tags: ['archived', 'legacy'],
    deployments: [{ environment: 'Production', deployedDate: '2024-05-10 16:00', status: 'decommissioned' }],
    artifacts: {
      modelWeights: 'efficientnet-b3-v3.5.pth',
      onnxExport: 'efficientnet-b3-v3.5.onnx',
      tensorrtExport: '',
    },
  },
];

// Training metrics data for selected model
const trainingMetricsData = [
  { epoch: 1, trainAcc: 0.62, valAcc: 0.60, trainLoss: 1.05, valLoss: 1.08 },
  { epoch: 10, trainAcc: 0.82, valAcc: 0.80, trainLoss: 0.52, valLoss: 0.56 },
  { epoch: 20, trainAcc: 0.91, valAcc: 0.89, trainLoss: 0.28, valLoss: 0.32 },
  { epoch: 30, trainAcc: 0.95, valAcc: 0.93, trainLoss: 0.15, valLoss: 0.19 },
  { epoch: 40, trainAcc: 0.97, valAcc: 0.95, trainLoss: 0.09, valLoss: 0.13 },
  { epoch: 50, trainAcc: 0.98, valAcc: 0.97, trainLoss: 0.06, valLoss: 0.10 },
];

// Confusion matrix data
const confusionMatrix = [
  { predicted: 'Edge', actual: 'Edge', value: 98 },
  { predicted: 'Edge', actual: 'Center', value: 1 },
  { predicted: 'Edge', actual: 'Scratch', value: 0 },
  { predicted: 'Center', actual: 'Edge', value: 2 },
  { predicted: 'Center', actual: 'Center', value: 95 },
  { predicted: 'Center', actual: 'Scratch', value: 1 },
  { predicted: 'Scratch', actual: 'Edge', value: 0 },
  { predicted: 'Scratch', actual: 'Center', value: 2 },
  { predicted: 'Scratch', actual: 'Scratch', value: 97 },
];

const patterns = ['Edge', 'Center', 'Scratch'];

export default function ModelMetrics() {
  const [selectedModel, setSelectedModel] = useState<ModelVersion>(mockModelVersions[0]);
  const [compareDialogOpen, setCompareDialogOpen] = useState(false);
  const [compareModel, setCompareModel] = useState<ModelVersion | null>(null);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [activeTab, setActiveTab] = useState(0);

  const getStatusColor = (status: string): 'success' | 'info' | 'warning' | 'default' => {
    switch (status) {
      case 'active':
        return 'success';
      case 'staging':
        return 'info';
      case 'development':
        return 'warning';
      default:
        return 'default';
    }
  };

  const getConfusionValue = (predicted: string, actual: string) => {
    const item = confusionMatrix.find((m) => m.predicted === predicted && m.actual === actual);
    return item?.value || 0;
  };

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleCompare = () => {
    setCompareModel(mockModelVersions[1]);
    setCompareDialogOpen(true);
    handleMenuClose();
  };

  const handleDeploy = () => {
    console.log('Deploying model:', selectedModel.version);
    handleMenuClose();
  };

  const handleArchive = () => {
    console.log('Archiving model:', selectedModel.version);
    handleMenuClose();
  };

  const handleDownload = (artifact: string) => {
    console.log('Downloading:', artifact);
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 600, mb: 0.5 }}>
            Model Registry & Performance
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Comprehensive model versioning, metrics tracking, and deployment management
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button variant="outlined" startIcon={<CompareIcon />} onClick={handleCompare} size="small">
            Compare
          </Button>
          <Button variant="outlined" startIcon={<DeployIcon />} onClick={handleDeploy} size="small">
            Deploy
          </Button>
          <Button variant="outlined" startIcon={<ArchiveIcon />} onClick={handleArchive} size="small">
            Archive
          </Button>
          <IconButton size="small" onClick={handleMenuOpen}>
            <MoreIcon />
          </IconButton>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {/* Left Sidebar - Model Versions List */}
        <Grid size={{ xs: 12, md: 3 }}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2, textTransform: 'uppercase', color: 'text.secondary' }}>
              Model Versions
            </Typography>
            <List disablePadding>
              {mockModelVersions.map((model) => (
                <ListItem key={model.id} disablePadding sx={{ mb: 1 }}>
                  <ListItemButton
                    selected={selectedModel.id === model.id}
                    onClick={() => setSelectedModel(model)}
                    sx={{
                      borderRadius: 1,
                      '&.Mui-selected': {
                        bgcolor: 'primary.lighter',
                        '&:hover': {
                          bgcolor: 'primary.light',
                        },
                      },
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', width: '100%', gap: 1 }}>
                      {model.status === 'active' ? (
                        <ActiveIcon color="success" fontSize="small" />
                      ) : (
                        <InactiveIcon color="disabled" fontSize="small" />
                      )}
                      <Box sx={{ flexGrow: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {model.version}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {model.architecture}
                        </Typography>
                      </Box>
                      <Chip label={model.status} size="small" color={getStatusColor(model.status)} sx={{ fontSize: '0.65rem' }} />
                    </Box>
                  </ListItemButton>
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>

        {/* Main Content - Model Details */}
        <Grid size={{ xs: 12, md: 9 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            {/* Model Metadata Card */}
            <Paper sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', mb: 3 }}>
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
                    <Typography variant="h5" sx={{ fontWeight: 600 }}>
                      {selectedModel.version}
                    </Typography>
                    <Chip label={selectedModel.status} color={getStatusColor(selectedModel.status)} />
                    {selectedModel.status === 'active' && <Chip label="PRODUCTION" color="success" variant="outlined" size="small" />}
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    {selectedModel.architecture} • Trained by {selectedModel.trainedBy} • {selectedModel.trainedDate}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 1 }}>
                  {selectedModel.tags.map((tag) => (
                    <Chip key={tag} label={tag} size="small" variant="outlined" />
                  ))}
                </Box>
              </Box>

              <Grid container spacing={2}>
                <Grid size={{ xs: 6, sm: 3 }}>
                  <Card variant="outlined">
                    <CardContent sx={{ textAlign: 'center', py: 2 }}>
                      <Typography variant="h4" sx={{ fontWeight: 700, color: 'success.main', mb: 0.5 }}>
                        {(selectedModel.accuracy * 100).toFixed(1)}%
                      </Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontWeight: 600 }}>
                        Accuracy
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid size={{ xs: 6, sm: 3 }}>
                  <Card variant="outlined">
                    <CardContent sx={{ textAlign: 'center', py: 2 }}>
                      <Typography variant="h4" sx={{ fontWeight: 700, color: 'info.main', mb: 0.5 }}>
                        {selectedModel.f1Score.toFixed(3)}
                      </Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontWeight: 600 }}>
                        F1 Score
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid size={{ xs: 6, sm: 3 }}>
                  <Card variant="outlined">
                    <CardContent sx={{ textAlign: 'center', py: 2 }}>
                      <Typography variant="h4" sx={{ fontWeight: 700, color: 'warning.main', mb: 0.5 }}>
                        {selectedModel.precision.toFixed(3)}
                      </Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontWeight: 600 }}>
                        Precision
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
                <Grid size={{ xs: 6, sm: 3 }}>
                  <Card variant="outlined">
                    <CardContent sx={{ textAlign: 'center', py: 2 }}>
                      <Typography variant="h4" sx={{ fontWeight: 700, color: 'error.main', mb: 0.5 }}>
                        {selectedModel.recall.toFixed(3)}
                      </Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontWeight: 600 }}>
                        Recall
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </Paper>

            {/* Tabs for different views */}
            <Paper>
              <Tabs value={activeTab} onChange={(_, value) => setActiveTab(value)} sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <Tab label="Performance Metrics" icon={<MetricsIcon />} iconPosition="start" />
                <Tab label="Training Details" icon={<InfoIcon />} iconPosition="start" />
                <Tab label="Deployments" icon={<DeployIcon />} iconPosition="start" />
                <Tab label="Artifacts" icon={<CodeIcon />} iconPosition="start" />
              </Tabs>

              <Box sx={{ p: 3 }}>
                {/* Tab 0: Performance Metrics */}
                {activeTab === 0 && (
                  <Grid container spacing={3}>
                    {/* Learning Curves */}
                    <Grid size={{ xs: 12, lg: 8 }}>
                      <Box>
                        <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                          Learning Curves
                        </Typography>
                        <ResponsiveContainer width="100%" height={300}>
                          <LineChart data={trainingMetricsData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="epoch" label={{ value: 'Epoch', position: 'insideBottom', offset: -5 }} />
                            <YAxis label={{ value: 'Accuracy', angle: -90, position: 'insideLeft' }} />
                            <RechartsTooltip />
                            <Line type="monotone" dataKey="trainAcc" stroke="#10b981" strokeWidth={2} name="Train Accuracy" />
                            <Line type="monotone" dataKey="valAcc" stroke="#3b82f6" strokeWidth={2} name="Val Accuracy" />
                          </LineChart>
                        </ResponsiveContainer>
                      </Box>
                    </Grid>

                    {/* Confusion Matrix */}
                    <Grid size={{ xs: 12, lg: 4 }}>
                      <Box>
                        <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                          Confusion Matrix
                        </Typography>
                        <TableContainer>
                          <Table size="small">
                            <TableHead>
                              <TableRow>
                                <TableCell sx={{ fontWeight: 600, fontSize: '0.7rem' }}>T \ P</TableCell>
                                {patterns.map((pattern) => (
                                  <TableCell key={pattern} align="center" sx={{ fontWeight: 600, fontSize: '0.7rem' }}>
                                    {pattern}
                                  </TableCell>
                                ))}
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {patterns.map((actual) => (
                                <TableRow key={actual}>
                                  <TableCell sx={{ fontWeight: 600, fontSize: '0.7rem' }}>{actual}</TableCell>
                                  {patterns.map((predicted) => {
                                    const value = getConfusionValue(predicted, actual);
                                    const isDiagonal = actual === predicted;
                                    return (
                                      <TableCell key={predicted} align="center" sx={{ p: 0.5 }}>
                                        <Box
                                          sx={{
                                            py: 1,
                                            borderRadius: 1,
                                            fontFamily: 'monospace',
                                            fontSize: '0.875rem',
                                            fontWeight: 600,
                                            bgcolor: isDiagonal ? 'success.lighter' : 'grey.100',
                                            color: isDiagonal ? 'success.dark' : 'text.secondary',
                                          }}
                                        >
                                          {value}%
                                        </Box>
                                      </TableCell>
                                    );
                                  })}
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </Box>
                    </Grid>
                  </Grid>
                )}

                {/* Tab 1: Training Details */}
                {activeTab === 1 && (
                  <Grid container spacing={3}>
                    <Grid size={{ xs: 12, md: 6 }}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2, textTransform: 'uppercase', color: 'text.secondary' }}>
                        Training Configuration
                      </Typography>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <TimerIcon fontSize="small" color="action" />
                            <Typography variant="body2" color="text.secondary">
                              Training Duration
                            </Typography>
                          </Box>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {selectedModel.trainingDuration}
                          </Typography>
                        </Box>
                        <Divider />
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <MemoryIcon fontSize="small" color="action" />
                            <Typography variant="body2" color="text.secondary">
                              Dataset Size
                            </Typography>
                          </Box>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {selectedModel.datasetSize.toLocaleString()} samples
                          </Typography>
                        </Box>
                        <Divider />
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Typography variant="body2" color="text.secondary">
                            Epochs
                          </Typography>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {selectedModel.epochs}
                          </Typography>
                        </Box>
                        <Divider />
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Typography variant="body2" color="text.secondary">
                            Batch Size
                          </Typography>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {selectedModel.batchSize}
                          </Typography>
                        </Box>
                        <Divider />
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Typography variant="body2" color="text.secondary">
                            Learning Rate
                          </Typography>
                          <Typography variant="body2" sx={{ fontWeight: 600, fontFamily: 'monospace' }}>
                            {selectedModel.learningRate}
                          </Typography>
                        </Box>
                        <Divider />
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Typography variant="body2" color="text.secondary">
                            Optimizer
                          </Typography>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {selectedModel.optimizer}
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>

                    <Grid size={{ xs: 12, md: 6 }}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2, textTransform: 'uppercase', color: 'text.secondary' }}>
                        Model Information
                      </Typography>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Typography variant="body2" color="text.secondary">
                            Architecture
                          </Typography>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {selectedModel.architecture}
                          </Typography>
                        </Box>
                        <Divider />
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Typography variant="body2" color="text.secondary">
                            Version
                          </Typography>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {selectedModel.version}
                          </Typography>
                        </Box>
                        <Divider />
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Typography variant="body2" color="text.secondary">
                            Trained By
                          </Typography>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {selectedModel.trainedBy}
                          </Typography>
                        </Box>
                        <Divider />
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Typography variant="body2" color="text.secondary">
                            Trained Date
                          </Typography>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {selectedModel.trainedDate}
                          </Typography>
                        </Box>
                        <Divider />
                        <Box>
                          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                            Tags
                          </Typography>
                          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                            {selectedModel.tags.map((tag) => (
                              <Chip key={tag} label={tag} size="small" />
                            ))}
                          </Box>
                        </Box>
                      </Box>
                    </Grid>

                    {/* Loss Curves */}
                    <Grid size={{ xs: 12 }}>
                      <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                        Loss Curves
                      </Typography>
                      <ResponsiveContainer width="100%" height={250}>
                        <LineChart data={trainingMetricsData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="epoch" label={{ value: 'Epoch', position: 'insideBottom', offset: -5 }} />
                          <YAxis label={{ value: 'Loss', angle: -90, position: 'insideLeft' }} />
                          <RechartsTooltip />
                          <Line type="monotone" dataKey="trainLoss" stroke="#ef4444" strokeWidth={2} name="Train Loss" />
                          <Line type="monotone" dataKey="valLoss" stroke="#f97316" strokeWidth={2} name="Val Loss" strokeDasharray="5 5" />
                        </LineChart>
                      </ResponsiveContainer>
                    </Grid>
                  </Grid>
                )}

                {/* Tab 2: Deployments */}
                {activeTab === 2 && (
                  <Box>
                    <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                      Deployment History
                    </Typography>
                    {selectedModel.deployments.length > 0 ? (
                      <TableContainer>
                        <Table>
                          <TableHead>
                            <TableRow>
                              <TableCell sx={{ fontWeight: 600 }}>Environment</TableCell>
                              <TableCell sx={{ fontWeight: 600 }}>Deployed Date</TableCell>
                              <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                              <TableCell sx={{ fontWeight: 600 }}>Metrics</TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {selectedModel.deployments.map((deployment, index) => (
                              <TableRow key={index}>
                                <TableCell>
                                  <Chip label={deployment.environment} size="small" color="primary" variant="outlined" />
                                </TableCell>
                                <TableCell>{deployment.deployedDate}</TableCell>
                                <TableCell>
                                  <Chip
                                    label={deployment.status}
                                    size="small"
                                    color={deployment.status === 'active' ? 'success' : 'default'}
                                    icon={deployment.status === 'active' ? <CheckCircleIcon /> : undefined}
                                  />
                                </TableCell>
                                <TableCell>
                                  <Box sx={{ display: 'flex', gap: 2 }}>
                                    <Tooltip title="Average Latency">
                                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                        <SpeedIcon fontSize="small" color="action" />
                                        <Typography variant="caption">42ms</Typography>
                                      </Box>
                                    </Tooltip>
                                    <Tooltip title="Throughput">
                                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                        <TrendingUpIcon fontSize="small" color="success" />
                                        <Typography variant="caption">1.2K/s</Typography>
                                      </Box>
                                    </Tooltip>
                                  </Box>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    ) : (
                      <Alert severity="info">This model has not been deployed to any environment yet.</Alert>
                    )}

                    {/* Deployment Actions */}
                    <Box sx={{ mt: 3 }}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                        Deploy to Environment
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 2 }}>
                        <Button variant="outlined" startIcon={<DeployIcon />} disabled={selectedModel.status === 'active'}>
                          Deploy to Production
                        </Button>
                        <Button variant="outlined" startIcon={<DeployIcon />}>
                          Deploy to Staging
                        </Button>
                        <Button variant="outlined" startIcon={<DeployIcon />}>
                          Deploy to Development
                        </Button>
                      </Box>
                    </Box>
                  </Box>
                )}

                {/* Tab 3: Artifacts */}
                {activeTab === 3 && (
                  <Box>
                    <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                      Model Artifacts
                    </Typography>
                    <Grid container spacing={2}>
                      <Grid size={{ xs: 12, md: 4 }}>
                        <Card variant="outlined">
                          <CardContent>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                              <CodeIcon color="primary" />
                              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                                Model Weights
                              </Typography>
                            </Box>
                            <Typography variant="body2" color="text.secondary" sx={{ mb: 2, fontFamily: 'monospace', fontSize: '0.75rem' }}>
                              {selectedModel.artifacts.modelWeights}
                            </Typography>
                            <Button
                              variant="outlined"
                              size="small"
                              startIcon={<DownloadIcon />}
                              fullWidth
                              onClick={() => handleDownload(selectedModel.artifacts.modelWeights)}
                            >
                              Download
                            </Button>
                          </CardContent>
                        </Card>
                      </Grid>
                      <Grid size={{ xs: 12, md: 4 }}>
                        <Card variant="outlined">
                          <CardContent>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                              <CodeIcon color="success" />
                              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                                ONNX Export
                              </Typography>
                            </Box>
                            <Typography variant="body2" color="text.secondary" sx={{ mb: 2, fontFamily: 'monospace', fontSize: '0.75rem' }}>
                              {selectedModel.artifacts.onnxExport}
                            </Typography>
                            <Button
                              variant="outlined"
                              size="small"
                              startIcon={<DownloadIcon />}
                              fullWidth
                              onClick={() => handleDownload(selectedModel.artifacts.onnxExport)}
                            >
                              Download
                            </Button>
                          </CardContent>
                        </Card>
                      </Grid>
                      <Grid size={{ xs: 12, md: 4 }}>
                        <Card variant="outlined">
                          <CardContent>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                              <CodeIcon color="warning" />
                              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                                TensorRT Export
                              </Typography>
                            </Box>
                            <Typography variant="body2" color="text.secondary" sx={{ mb: 2, fontFamily: 'monospace', fontSize: '0.75rem' }}>
                              {selectedModel.artifacts.tensorrtExport || 'Not available'}
                            </Typography>
                            <Button
                              variant="outlined"
                              size="small"
                              startIcon={<DownloadIcon />}
                              fullWidth
                              disabled={!selectedModel.artifacts.tensorrtExport}
                              onClick={() => handleDownload(selectedModel.artifacts.tensorrtExport)}
                            >
                              Download
                            </Button>
                          </CardContent>
                        </Card>
                      </Grid>
                    </Grid>

                    <Alert severity="info" sx={{ mt: 3 }}>
                      <Typography variant="body2">
                        <strong>Note:</strong> Model artifacts are stored in the artifact registry. ONNX and TensorRT exports are optimized for
                        production inference with reduced latency.
                      </Typography>
                    </Alert>
                  </Box>
                )}
              </Box>
            </Paper>
          </Box>
        </Grid>
      </Grid>

      {/* Action Menu */}
      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
        <MenuItem onClick={handleCompare}>
          <CompareIcon fontSize="small" sx={{ mr: 1 }} />
          Compare Models
        </MenuItem>
        <MenuItem onClick={handleDeploy}>
          <DeployIcon fontSize="small" sx={{ mr: 1 }} />
          Deploy Model
        </MenuItem>
        <MenuItem onClick={handleArchive}>
          <ArchiveIcon fontSize="small" sx={{ mr: 1 }} />
          Archive Model
        </MenuItem>
        <MenuItem onClick={handleMenuClose}>
          <DownloadIcon fontSize="small" sx={{ mr: 1 }} />
          Export Report
        </MenuItem>
      </Menu>

      {/* Compare Dialog */}
      <Dialog open={compareDialogOpen} onClose={() => setCompareDialogOpen(false)} maxWidth="lg" fullWidth>
        <DialogTitle>Model Comparison</DialogTitle>
        <DialogContent>
          {compareModel && (
            <Grid container spacing={3}>
              <Grid size={{ xs: 12, md: 6 }}>
                <Paper sx={{ p: 2, bgcolor: 'primary.lighter' }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    {selectedModel.version} (Selected)
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2">Accuracy:</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {(selectedModel.accuracy * 100).toFixed(2)}%
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2">F1 Score:</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.f1Score.toFixed(3)}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2">Precision:</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.precision.toFixed(3)}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Typography variant="body2">Recall:</Typography>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>
                        {selectedModel.recall.toFixed(3)}
                      </Typography>
                    </Box>
                  </Box>
                </Paper>
              </Grid>
              <Grid size={{ xs: 12, md: 6 }}>
                <Paper sx={{ p: 2, bgcolor: 'grey.100' }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2 }}>
                    {compareModel.version} (Comparison)
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2">Accuracy:</Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {(compareModel.accuracy * 100).toFixed(2)}%
                        </Typography>
                        {compareModel.accuracy < selectedModel.accuracy ? (
                          <TrendingDownIcon fontSize="small" color="error" />
                        ) : (
                          <TrendingUpIcon fontSize="small" color="success" />
                        )}
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2">F1 Score:</Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {compareModel.f1Score.toFixed(3)}
                        </Typography>
                        {compareModel.f1Score < selectedModel.f1Score ? (
                          <TrendingDownIcon fontSize="small" color="error" />
                        ) : (
                          <TrendingUpIcon fontSize="small" color="success" />
                        )}
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2">Precision:</Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {compareModel.precision.toFixed(3)}
                        </Typography>
                        {compareModel.precision < selectedModel.precision ? (
                          <TrendingDownIcon fontSize="small" color="error" />
                        ) : (
                          <TrendingUpIcon fontSize="small" color="success" />
                        )}
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2">Recall:</Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          {compareModel.recall.toFixed(3)}
                        </Typography>
                        {compareModel.recall < selectedModel.recall ? (
                          <TrendingDownIcon fontSize="small" color="error" />
                        ) : (
                          <TrendingUpIcon fontSize="small" color="success" />
                        )}
                      </Box>
                    </Box>
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCompareDialogOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
