/**
 * Training Job Monitor Page
 * 
 * Integrates TrainingMonitor component with job queue
 * Allows users to select and monitor training jobs
 */
import React, { useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Typography,
  Paper,
  Button,
  Chip,
  Card,
  CardContent,
  IconButton,
  Tooltip,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemButton,
  Alert
} from '@mui/material';
import {
  ArrowBack,
  Refresh,
  Timeline
} from '@mui/icons-material';
import TrainingMonitor from '@/components/training/TrainingMonitor';

interface TrainingJob {
  job_id: string;
  status: string;
  priority: string;
  current_epoch: number;
  total_epochs: number;
  queued_at: string;
  start_time?: string;
}

const TrainingJobMonitor: React.FC = () => {
  const [jobs, setJobs] = useState<TrainingJob[]>([]);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Fetch training jobs
  const fetchJobs = async () => {
    setLoading(true);
    try {
      const response = await fetch('http://localhost:5000/api/v1/training/queue');
      const data = await response.json();
      
      if (data.status === 'success') {
        setJobs(data.jobs || []);
        
        // Auto-select first running job if none selected
        if (!selectedJobId && data.jobs.length > 0) {
          const runningJob = data.jobs.find((j: TrainingJob) => j.status === 'running');
          if (runningJob) {
            setSelectedJobId(runningJob.job_id);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJobs();
    
    // Refresh job list every 10 seconds
    const interval = setInterval(fetchJobs, 10000);
    return () => clearInterval(interval);
  }, []);

  // Get status color
  const getStatusColor = (status: string): 'success' | 'error' | 'warning' | 'info' | 'default' => {
    switch (status) {
      case 'completed': return 'success';
      case 'failed': return 'error';
      case 'running': return 'info';
      case 'queued': return 'warning';
      default: return 'default';
    }
  };

  // Format date
  const formatDate = (dateString?: string): string => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  return (
    <Box sx={{ p: 3 }}>
      <Grid container spacing={3}>
        {/* Job List Sidebar */}
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">
                  Training Jobs
                </Typography>
                <Tooltip title="Refresh">
                  <IconButton onClick={fetchJobs} size="small">
                    <Refresh />
                  </IconButton>
                </Tooltip>
              </Box>
              
              <Divider sx={{ mb: 2 }} />
              
              {loading ? (
                <Typography variant="body2" color="text.secondary">
                  Loading...
                </Typography>
              ) : jobs.length === 0 ? (
                <Alert severity="info">
                  No training jobs found
                </Alert>
              ) : (
                <List sx={{ maxHeight: 600, overflow: 'auto' }}>
                  {jobs.map((job) => (
                    <ListItem
                      key={job.job_id}
                      disablePadding
                      sx={{
                        mb: 1,
                        border: selectedJobId === job.job_id ? 2 : 1,
                        borderColor: selectedJobId === job.job_id ? 'primary.main' : 'divider',
                        borderRadius: 1
                      }}
                    >
                      <ListItemButton
                        onClick={() => setSelectedJobId(job.job_id)}
                        selected={selectedJobId === job.job_id}
                      >
                        <ListItemText
                          primary={
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <Chip
                                label={job.status}
                                color={getStatusColor(job.status)}
                                size="small"
                              />
                              <Chip
                                label={job.priority}
                                size="small"
                                variant="outlined"
                              />
                            </Box>
                          }
                          secondary={
                            <Box sx={{ mt: 1 }}>
                              <Typography variant="caption" display="block">
                                Job ID: {job.job_id.substring(0, 8)}...
                              </Typography>
                              <Typography variant="caption" display="block">
                                Epoch: {job.current_epoch}/{job.total_epochs}
                              </Typography>
                              <Typography variant="caption" display="block">
                                Queued: {formatDate(job.queued_at)}
                              </Typography>
                            </Box>
                          }
                        />
                      </ListItemButton>
                    </ListItem>
                  ))}
                </List>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Training Monitor */}
        <Grid item xs={12} md={9}>
          {selectedJobId ? (
            <TrainingMonitor
              jobId={selectedJobId}
              onClose={() => setSelectedJobId(null)}
            />
          ) : (
            <Card>
              <CardContent>
                <Box
                  sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    minHeight: 400,
                    gap: 2
                  }}
                >
                  <Timeline sx={{ fontSize: 64, color: 'text.secondary' }} />
                  <Typography variant="h6" color="text.secondary">
                    Select a training job to monitor
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Choose a job from the list on the left to view real-time training progress
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default TrainingJobMonitor;
