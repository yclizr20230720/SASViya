/**
 * Integrated Training Job Queue with Real-Time Metrics
 * Shows training progress, metrics, and logs directly in the job table
 */
import React, { useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Typography,
  Paper,
  Button,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  LinearProgress,
  Collapse,
  Card,
  CardContent,
  Tooltip
} from '@mui/material';
import {
  Refresh,
  ExpandMore,
  ExpandLess,
  Stop,
  Delete,
  PlayArrow
} from '@mui/icons-material';

interface TrainingJob {
  job_id: string;
  status: string;
  priority: string;
  current_epoch: number;
  total_epochs: number;
  queued_at: string;
  start_time?: string;
}

interface JobMetrics {
  train_loss: number;
  train_pattern_acc: number;
  val_loss: number;
  val_pattern_acc: number;
  val_root_cause_acc: number;
  learning_rate: number;
}

const TrainingJobQueueIntegrated: React.FC = () => {
  const [jobs, setJobs] = useState<TrainingJob[]>([]);
  const [expandedJobId, setExpandedJobId] = useState<string | null>(null);
  const [jobMetrics, setJobMetrics] = useState<Record<string, JobMetrics>>({});
  const [jobLogs, setJobLogs] = useState<Record<string, string[]>>({});
  const [loading, setLoading] = useState(false);

  // Fetch training queue
  const fetchJobs = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/v1/training/queue');
      if (response.ok) {
        const data = await response.json();
        setJobs(data.jobs || []);
        
        // Fetch metrics for running/completed jobs
        for (const job of data.jobs || []) {
          if (job.status === 'running' || job.status === 'completed') {
            fetchJobMetrics(job.job_id);
          }
        }
      }
    } catch (error) {
      console.error('Failed to fetch jobs:', error);
    }
  };

  // Fetch metrics for a specific job
  const fetchJobMetrics = async (jobId: string) => {
    try {
      const response = await fetch(`http://localhost:5000/api/v1/training/metrics/${jobId}`);
      if (response.ok) {
        const data = await response.json();
        setJobMetrics(prev => ({
          ...prev,
          [jobId]: data.current_metrics
        }));
      }
    } catch (error) {
      console.error(`Failed to fetch metrics for ${jobId}:`, error);
    }
  };

  // Fetch logs for a specific job
  const fetchJobLogs = async (jobId: string) => {
    try {
      const response = await fetch(`http://localhost:5000/api/v1/training/logs/${jobId}`);
      if (response.ok) {
        const logText = await response.text(); // Get plain text, not JSON
        // Split into lines and filter empty lines
        const logLines = logText.split('\n').filter(line => line.trim() !== '');
        setJobLogs(prev => ({
          ...prev,
          [jobId]: logLines
        }));
      }
    } catch (error) {
      console.error(`Failed to fetch logs for ${jobId}:`, error);
    }
  };

  // Auto-refresh every 3 seconds
  useEffect(() => {
    fetchJobs();
    const interval = setInterval(fetchJobs, 3000);
    return () => clearInterval(interval);
  }, []);

  // Fetch logs when job is expanded
  useEffect(() => {
    if (expandedJobId) {
      fetchJobLogs(expandedJobId);
      const interval = setInterval(() => fetchJobLogs(expandedJobId), 3000);
      return () => clearInterval(interval);
    }
  }, [expandedJobId]);

  // Toggle job expansion
  const toggleExpand = (jobId: string) => {
    setExpandedJobId(expandedJobId === jobId ? null : jobId);
  };

  // Get status color
  const getStatusColor = (status: string): 'success' | 'error' | 'warning' | 'info' | 'default' => {
    switch (status) {
      case 'completed': return 'success';
      case 'failed': return 'error';
      case 'running': return 'info';
      case 'queued': return 'warning';
      default: return 'default';
    }
  };

  // Stop job
  const handleStopJob = async (jobId: string) => {
    try {
      await fetch(`http://localhost:5000/api/v1/training/stop/${jobId}`, { method: 'POST' });
      fetchJobs();
    } catch (error) {
      console.error('Failed to stop job:', error);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" fontWeight={600} gutterBottom>
            Training Job Queue
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Monitor training jobs with real-time metrics
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<Refresh />}
          onClick={fetchJobs}
        >
          Refresh
        </Button>
      </Box>

      {/* Jobs Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell width={50}></TableCell>
              <TableCell>Job ID</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Priority</TableCell>
              <TableCell>Progress</TableCell>
              <TableCell>Pattern Acc</TableCell>
              <TableCell>Root Cause Acc</TableCell>
              <TableCell>Loss</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {jobs.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} align="center">
                  <Typography variant="body2" color="text.secondary" sx={{ py: 4 }}>
                    No training jobs found
                  </Typography>
                </TableCell>
              </TableRow>
            ) : (
              jobs.map((job) => {
                const metrics = jobMetrics[job.job_id];
                const isExpanded = expandedJobId === job.job_id;
                const progress = (job.current_epoch / job.total_epochs) * 100;

                return (
                  <React.Fragment key={job.job_id}>
                    <TableRow hover>
                      <TableCell>
                        <IconButton
                          size="small"
                          onClick={() => toggleExpand(job.job_id)}
                        >
                          {isExpanded ? <ExpandLess /> : <ExpandMore />}
                        </IconButton>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" fontFamily="monospace">
                          {job.job_id.substring(0, 12)}...
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={job.status.toUpperCase()}
                          color={getStatusColor(job.status)}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={job.priority}
                          size="small"
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell>
                        <Box sx={{ width: 150 }}>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                            <Typography variant="caption">
                              {job.current_epoch}/{job.total_epochs}
                            </Typography>
                            <Typography variant="caption">
                              {progress.toFixed(0)}%
                            </Typography>
                          </Box>
                          <LinearProgress
                            variant="determinate"
                            value={progress}
                            sx={{ height: 6, borderRadius: 3 }}
                          />
                        </Box>
                      </TableCell>
                      <TableCell>
                        {metrics ? (
                          <Typography variant="body2" fontWeight={600} color="primary">
                            {(metrics.val_pattern_acc * 100).toFixed(1)}%
                          </Typography>
                        ) : (
                          <Typography variant="body2" color="text.secondary">
                            -
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        {metrics ? (
                          <Typography variant="body2" fontWeight={600} color="secondary">
                            {(metrics.val_root_cause_acc * 100).toFixed(1)}%
                          </Typography>
                        ) : (
                          <Typography variant="body2" color="text.secondary">
                            -
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        {metrics ? (
                          <Typography variant="body2">
                            {metrics.val_loss.toFixed(4)}
                          </Typography>
                        ) : (
                          <Typography variant="body2" color="text.secondary">
                            -
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        {job.status === 'running' && (
                          <Tooltip title="Stop Training">
                            <IconButton
                              size="small"
                              color="error"
                              onClick={() => handleStopJob(job.job_id)}
                            >
                              <Stop />
                            </IconButton>
                          </Tooltip>
                        )}
                      </TableCell>
                    </TableRow>

                    {/* Expanded Row - Detailed Metrics and Logs */}
                    <TableRow>
                      <TableCell colSpan={9} sx={{ py: 0, borderBottom: isExpanded ? 1 : 0 }}>
                        <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                          <Box sx={{ p: 3, bgcolor: 'background.default' }}>
                            <Grid container spacing={3}>
                              {/* Detailed Metrics */}
                              <Grid item xs={12} md={6}>
                                <Typography variant="h6" gutterBottom>
                                  Current Metrics
                                </Typography>
                                {metrics ? (
                                  <Grid container spacing={2}>
                                    <Grid item xs={6}>
                                      <Card variant="outlined">
                                        <CardContent>
                                          <Typography variant="caption" color="text.secondary">
                                            Train Loss
                                          </Typography>
                                          <Typography variant="h6">
                                            {metrics.train_loss.toFixed(4)}
                                          </Typography>
                                        </CardContent>
                                      </Card>
                                    </Grid>
                                    <Grid item xs={6}>
                                      <Card variant="outlined">
                                        <CardContent>
                                          <Typography variant="caption" color="text.secondary">
                                            Val Loss
                                          </Typography>
                                          <Typography variant="h6">
                                            {metrics.val_loss.toFixed(4)}
                                          </Typography>
                                        </CardContent>
                                      </Card>
                                    </Grid>
                                    <Grid item xs={6}>
                                      <Card variant="outlined">
                                        <CardContent>
                                          <Typography variant="caption" color="text.secondary">
                                            Train Pattern Acc
                                          </Typography>
                                          <Typography variant="h6">
                                            {(metrics.train_pattern_acc * 100).toFixed(1)}%
                                          </Typography>
                                        </CardContent>
                                      </Card>
                                    </Grid>
                                    <Grid item xs={6}>
                                      <Card variant="outlined">
                                        <CardContent>
                                          <Typography variant="caption" color="text.secondary">
                                            Learning Rate
                                          </Typography>
                                          <Typography variant="h6">
                                            {metrics.learning_rate.toExponential(2)}
                                          </Typography>
                                        </CardContent>
                                      </Card>
                                    </Grid>
                                  </Grid>
                                ) : (
                                  <Typography variant="body2" color="text.secondary">
                                    No metrics available
                                  </Typography>
                                )}
                              </Grid>

                              {/* Recent Logs */}
                              <Grid item xs={12} md={6}>
                                <Typography variant="h6" gutterBottom>
                                  Recent Logs
                                </Typography>
                                <Paper
                                  variant="outlined"
                                  sx={{
                                    p: 2,
                                    bgcolor: '#1e1e1e',
                                    color: '#d4d4d4',
                                    fontFamily: 'monospace',
                                    fontSize: '0.75rem',
                                    maxHeight: 200,
                                    overflow: 'auto'
                                  }}
                                >
                                  {jobLogs[job.job_id] && jobLogs[job.job_id].length > 0 ? (
                                    jobLogs[job.job_id].map((log, idx) => (
                                      <Box key={idx} sx={{ mb: 0.5 }}>
                                        {log}
                                      </Box>
                                    ))
                                  ) : (
                                    <Typography variant="body2" color="text.secondary">
                                      No logs available
                                    </Typography>
                                  )}
                                </Paper>
                              </Grid>
                            </Grid>
                          </Box>
                        </Collapse>
                      </TableCell>
                    </TableRow>
                  </React.Fragment>
                );
              })
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default TrainingJobQueueIntegrated;
