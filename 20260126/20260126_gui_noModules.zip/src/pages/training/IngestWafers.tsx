/**
 * Ingest Wafers Page
 * Upload and manage wafer map files for training data
 */

import React, { useState, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import {
  Box,
  Grid,
  Typography,
  Paper,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  LinearProgress,
  Chip,
  Alert,
  useTheme,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tooltip
} from '@mui/material';
import {
  CloudUpload,
  InsertDriveFile,
  Delete,
  CheckCircle,
  Storage,
  Add,
  Refresh,
  Cancel,
  Info,
  FilterList,
  QueuePlayNext
} from '@mui/icons-material';

interface UploadFile {
  name: string;
  size: string;
  progress: number;
  status: 'uploading' | 'complete';
  id: string;
  file: File; // Store actual File object
}

interface TrainingJob {
  id: string;
  job_id: string;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'stopped' | 'cancelled';
  priority: 'high' | 'normal' | 'low';
  config: {
    model_architecture: string;
    epochs: number;
    batch_size: number;
    learning_rate: number;
  };
  current_epoch: number;
  total_epochs: number;
  queued_at?: string;
  start_time?: string;
  estimated_duration_minutes: number;
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

/**
 * Ingest Wafers Component
 */
const IngestWafers: React.FC = () => {
  const theme = useTheme();
  const [tabValue, setTabValue] = useState(0);
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [metadata, setMetadata] = useState({
    lotId: '',
    equipmentId: '',
    processStep: 'Lithography'
  });
  
  // Training queue state
  const [jobs, setJobs] = useState<TrainingJob[]>([]);
  const [queueStats, setQueueStats] = useState<any>(null);
  const [selectedJob, setSelectedJob] = useState<TrainingJob | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Fetch training queue
  const fetchTrainingQueue = async () => {
    try {
      const url = filterStatus === 'all' 
        ? 'http://localhost:5000/api/v1/training/queue'
        : `http://localhost:5000/api/v1/training/queue?status=${filterStatus}`;
      
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setJobs(data.jobs || []);
        setQueueStats(data.statistics);
      }
    } catch (error) {
      console.error('Failed to fetch training queue:', error);
    }
  };

  // Auto-refresh queue when on queue tab
  useEffect(() => {
    if (tabValue === 1) {
      fetchTrainingQueue();
      const interval = setInterval(fetchTrainingQueue, 5000);
      return () => clearInterval(interval);
    }
  }, [tabValue, filterStatus]);

  // Dropzone configuration
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif'],
      'text/csv': ['.csv'],
      'application/xml': ['.xml'],
      'application/octet-stream': ['.bin'],
    },
    multiple: true, // Enable multiple file upload
    onDrop: (acceptedFiles) => {
      acceptedFiles.forEach((file) => {
        const mockFile: UploadFile = {
          name: file.name,
          size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
          progress: 0,
          status: 'uploading',
          id: Math.random().toString(36).substring(2, 11),
          file: file // Store actual File object
        };
        
        setFiles((prev) => [...prev, mockFile]);

        // Simulate upload progress
        let prog = 0;
        const interval = setInterval(() => {
          prog += 10;
          setFiles((prev) =>
            prev.map((f) =>
              f.id === mockFile.id
                ? { ...f, progress: prog, status: prog >= 100 ? 'complete' : 'uploading' }
                : f
            )
          );
          if (prog >= 100) {
            clearInterval(interval);
          }
        }, 200);
      });
    }
  });

  const handleRemoveFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const handleCommit = async () => {
    // Validate metadata
    if (!metadata.lotId) {
      alert('Please enter Lot ID');
      return;
    }

    if (files.length === 0) {
      alert('Please upload at least one file');
      return;
    }

    try {
      // Prepare form data
      const formData = new FormData();
      formData.append('lot_id', metadata.lotId);
      formData.append('process_step', metadata.processStep);
      formData.append('equipment_id', metadata.equipmentId);

      // Append all files
      files.forEach((uploadFile) => {
        formData.append('files', uploadFile.file);
      });

      console.log('Committing to backend:', {
        lot_id: metadata.lotId,
        process_step: metadata.processStep,
        equipment_id: metadata.equipmentId,
        file_count: files.length
      });

      // Call backend API
      const response = await fetch('http://localhost:5000/api/v1/training/ingest', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Upload failed');
      }

      const result = await response.json();
      console.log('Upload successful:', result);
      
      // Show success message with training job ID
      let successMessage = `Successfully uploaded ${result.uploaded_count} wafer(s)!`;
      if (result.training_job_id) {
        successMessage += `\n\nTraining job created: ${result.training_job_id.substring(0, 8)}...`;
        successMessage += `\nCheck the Training Queue tab to monitor progress.`;
      }
      alert(successMessage);
      
      // Clear files and reset form
      setFiles([]);
      setMetadata({
        lotId: '',
        equipmentId: '',
        processStep: 'Lithography'
      });
      
      // Switch to Training Queue tab to show the new job
      if (result.training_job_id) {
        setTabValue(1);
      }

    } catch (error) {
      console.error('Upload error:', error);
      alert(`Upload failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={600} gutterBottom>
          Ingest Wafer Data
        </Typography>
        <Typography variant="body1" color="text.secondary" gutterBottom>
          Upload wafer map image files for training and manage training jobs
        </Typography>
      </Box>

      {/* Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={(e, newValue) => setTabValue(newValue)}>
          <Tab icon={<CloudUpload />} label="Upload Files" iconPosition="start" />
          <Tab icon={<QueuePlayNext />} label="Training Queue" iconPosition="start" />
        </Tabs>
      </Box>

      {/* Tab Panel 0: Upload Files */}
      {tabValue === 0 && (
        <Box>
          <Box sx={{ mb: 3, display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
            <Chip 
              label="📁 Folder Upload Supported" 
              color="primary" 
              variant="outlined"
              size="small"
            />
            <Chip 
              label="📤 Multiple Files Upload" 
              color="success" 
              variant="outlined"
              size="small"
            />
            <Chip 
              label="🖼️ Image Formats: JPG, PNG, GIF" 
              color="info" 
              variant="outlined"
              size="small"
            />
          </Box>
      <Alert 
        severity="info" 
        sx={{ mb: 3, borderRadius: 2 }}
        icon={<CloudUpload />}
      >
        <Typography variant="subtitle2" fontWeight={600} gutterBottom>
          📋 Upload Instructions
        </Typography>
        <Box component="ul" sx={{ m: 0, pl: 2, '& li': { mb: 0.5 } }}>
          <li>
            <Typography variant="body2">
              <strong>Image Files:</strong> Supports JPG, JPEG, PNG, GIF formats for wafer map images
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>Folder Upload:</strong> You can select entire folders containing wafer map files
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>Multiple Files:</strong> Upload hundreds of files at once - batch processing is automatic
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>Large Files:</strong> Supports huge files up to 50MB per file
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>Data Formats:</strong> Also supports CSV, XML (KLARF), and binary formats
            </Typography>
          </li>
        </Box>
      </Alert>

      <Grid container spacing={3}>
        {/* Left Column - Upload Zone and Queue */}
        <Grid size={{ xs: 12, lg: 8 }}>
          {/* Drag and Drop Zone */}
          <Paper
            {...getRootProps()}
            sx={{
              p: 6,
              mb: 3,
              border: '2px dashed',
              borderColor: isDragActive ? 'primary.main' : 'divider',
              borderRadius: 3,
              textAlign: 'center',
              cursor: 'pointer',
              bgcolor: isDragActive ? 'action.hover' : 'background.paper',
              transition: 'all 0.3s',
              '&:hover': {
                borderColor: 'primary.main',
                bgcolor: 'action.hover',
                transform: 'translateY(-2px)',
                boxShadow: theme.shadows[4]
              }
            }}
          >
            <input {...getInputProps()} />
            <Box
              sx={{
                width: 64,
                height: 64,
                borderRadius: '50%',
                bgcolor: 'success.lighter',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mx: 'auto',
                mb: 3,
                transition: 'transform 0.3s',
                '&:hover': {
                  transform: 'scale(1.1)'
                }
              }}
            >
              <CloudUpload sx={{ fontSize: 32, color: 'success.main' }} />
            </Box>
            <Typography variant="h6" gutterBottom>
              Drag and drop wafer map files or folders
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              <strong>Image Files:</strong> JPG, JPEG, PNG, GIF
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              <strong>Data Files:</strong> CSV, XML, BIN, KLARF formats
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
              <Button
                variant="contained"
                sx={{
                  borderRadius: 2,
                  px: 4,
                  py: 1.5,
                  fontWeight: 600
                }}
              >
                Browse Files
              </Button>
              <Button
                variant="outlined"
                sx={{
                  borderRadius: 2,
                  px: 4,
                  py: 1.5,
                  fontWeight: 600
                }}
              >
                Select Folder
              </Button>
            </Box>
            <Typography variant="caption" color="text.secondary" sx={{ mt: 2, display: 'block' }}>
              💡 Tip: You can upload multiple files or entire folders at once
            </Typography>
          </Paper>

          {/* Queue Management */}
          <Paper sx={{ borderRadius: 3, overflow: 'hidden' }}>
            <Box
              sx={{
                p: 2,
                borderBottom: 1,
                borderColor: 'divider',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <Typography variant="h6" fontWeight={600}>
                Queue Management
              </Typography>
              <Chip
                label={`${files.length} Files Pending`}
                size="small"
                color="primary"
                variant="outlined"
              />
            </Box>

            {files.length === 0 ? (
              <Box sx={{ p: 6, textAlign: 'center' }}>
                <Typography variant="body2" color="text.secondary">
                  No files in queue
                </Typography>
              </Box>
            ) : (
              <List sx={{ p: 0 }}>
                {files.map((file) => (
                  <ListItem
                    key={file.id}
                    sx={{
                      borderBottom: 1,
                      borderColor: 'divider',
                      '&:last-child': {
                        borderBottom: 0
                      },
                      '&:hover': {
                        bgcolor: 'action.hover'
                      }
                    }}
                  >
                    <ListItemIcon>
                      <Box
                        sx={{
                          width: 40,
                          height: 40,
                          borderRadius: 1,
                          bgcolor: 'grey.100',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        <InsertDriveFile sx={{ color: 'text.secondary' }} />
                      </Box>
                    </ListItemIcon>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="body2" fontWeight={600}>
                            {file.name}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {file.size}
                          </Typography>
                        </Box>
                      }
                      secondary={
                        <LinearProgress
                          variant="determinate"
                          value={file.progress}
                          sx={{
                            height: 6,
                            borderRadius: 3,
                            bgcolor: 'grey.200',
                            '& .MuiLinearProgress-bar': {
                              borderRadius: 3,
                              bgcolor: file.status === 'complete' ? 'success.main' : 'primary.main'
                            }
                          }}
                        />
                      }
                    />
                    <ListItemSecondaryAction>
                      {file.status === 'complete' ? (
                        <CheckCircle sx={{ color: 'success.main' }} />
                      ) : (
                        <IconButton
                          edge="end"
                          onClick={() => handleRemoveFile(file.id)}
                          size="small"
                        >
                          <Delete sx={{ fontSize: 20 }} />
                        </IconButton>
                      )}
                    </ListItemSecondaryAction>
                  </ListItem>
                ))}
              </List>
            )}
          </Paper>
        </Grid>

        {/* Right Column - Metadata and Info */}
        <Grid size={{ xs: 12, lg: 4 }}>
          {/* Batch Metadata */}
          <Paper sx={{ p: 3, mb: 3, borderRadius: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
              <Add sx={{ color: 'text.secondary' }} />
              <Typography variant="h6" fontWeight={600}>
                Batch Metadata
              </Typography>
            </Box>

            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <TextField
                fullWidth
                label="Lot ID"
                placeholder="e.g. LOT-2024-X1"
                value={metadata.lotId}
                onChange={(e) => setMetadata({ ...metadata, lotId: e.target.value })}
                size="small"
              />

              <FormControl fullWidth size="small">
                <InputLabel>Process Step</InputLabel>
                <Select
                  value={metadata.processStep}
                  label="Process Step"
                  onChange={(e) => setMetadata({ ...metadata, processStep: e.target.value })}
                >
                  <MenuItem value="Lithography">Lithography</MenuItem>
                  <MenuItem value="Etch">Etch</MenuItem>
                  <MenuItem value="CMP">CMP</MenuItem>
                  <MenuItem value="CVD">CVD</MenuItem>
                  <MenuItem value="PVD">PVD</MenuItem>
                  <MenuItem value="Implant">Implant</MenuItem>
                </Select>
              </FormControl>

              <TextField
                fullWidth
                label="Equipment ID"
                placeholder="e.g. TOOL-ASML-04"
                value={metadata.equipmentId}
                onChange={(e) => setMetadata({ ...metadata, equipmentId: e.target.value })}
                size="small"
              />
            </Box>

            <Button
              fullWidth
              variant="contained"
              size="large"
              startIcon={<Storage />}
              onClick={handleCommit}
              disabled={files.length === 0}
              sx={{
                mt: 3,
                py: 1.5,
                borderRadius: 2,
                fontWeight: 600,
                boxShadow: theme.shadows[4]
              }}
            >
              Commit to Library
            </Button>
          </Paper>

          {/* Batch Processing Info */}
          <Alert
            severity="success"
            icon={<CheckCircle />}
            sx={{
              borderRadius: 3,
              '& .MuiAlert-message': {
                width: '100%'
              }
            }}
          >
            <Typography variant="subtitle2" fontWeight={600} gutterBottom>
              Batch Processing Active
            </Typography>
            <Typography variant="caption" sx={{ display: 'block', lineHeight: 1.6 }}>
              Multiple file uploads are processed in parallel using the distributed inference
              worker cluster.
            </Typography>
          </Alert>

          {/* Supported Formats */}
          <Paper sx={{ p: 3, mt: 3, borderRadius: 3 }}>
            <Typography variant="subtitle2" fontWeight={600} gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <InsertDriveFile sx={{ fontSize: 20 }} />
              Supported File Formats
            </Typography>
            <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
              <Box>
                <Typography variant="body2" fontWeight={600} color="primary.main" gutterBottom>
                  🖼️ Image Formats (Wafer Maps)
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • JPG / JPEG - Standard image format
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • PNG - High quality images
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • GIF - Animated or static images
                </Typography>
              </Box>
              
              <Box>
                <Typography variant="body2" fontWeight={600} color="success.main" gutterBottom>
                  📊 Data Formats
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • JSON - Structured wafer defect data
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • CSV - Comma-separated values
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', pl: 2 }}>
                  • XLSX - Excel spreadsheet format
                </Typography>
              </Box>

              <Box sx={{ mt: 1, p: 2, bgcolor: 'info.lighter', borderRadius: 1 }}>
                <Typography variant="caption" fontWeight={600} color="info.dark" sx={{ display: 'block', mb: 0.5 }}>
                  📁 Folder Upload
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Select entire folders containing wafer map files for batch processing
                </Typography>
              </Box>

              <Box sx={{ mt: 1, p: 2, bgcolor: 'success.lighter', borderRadius: 1 }}>
                <Typography variant="caption" fontWeight={600} color="success.dark" sx={{ display: 'block', mb: 0.5 }}>
                  📤 Multiple Files
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Upload hundreds of files simultaneously with automatic batch processing
                </Typography>
              </Box>

              <Box sx={{ mt: 1, p: 2, bgcolor: 'warning.lighter', borderRadius: 1 }}>
                <Typography variant="caption" fontWeight={600} color="warning.dark" sx={{ display: 'block', mb: 0.5 }}>
                  💾 File Size Limit
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Maximum 50MB per file • No limit on number of files
                </Typography>
              </Box>
            </Box>
          </Paper>
        </Grid>
      </Grid>
        </Box>
      )}

      {/* Tab Panel 1: Training Queue */}
      {tabValue === 1 && (
        <Box>
          {/* Queue Statistics */}
          {queueStats && (
            <Grid container spacing={2} sx={{ mb: 3 }}>
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="text.secondary" variant="body2">Total Jobs</Typography>
                    <Typography variant="h4" fontWeight={600}>{queueStats.total}</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="text.secondary" variant="body2">Running</Typography>
                    <Typography variant="h4" fontWeight={600} color="primary.main">{queueStats.running}</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="text.secondary" variant="body2">Queued</Typography>
                    <Typography variant="h4" fontWeight={600} color="info.main">{queueStats.queued}</Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="text.secondary" variant="body2">Completed</Typography>
                    <Typography variant="h4" fontWeight={600} color="success.main">{queueStats.completed}</Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          )}

          {/* Filter and Refresh */}
          <Paper sx={{ p: 2, mb: 2, display: 'flex', gap: 2, alignItems: 'center' }}>
            <FilterList />
            <FormControl size="small" sx={{ minWidth: 200 }}>
              <InputLabel>Filter by Status</InputLabel>
              <Select
                value={filterStatus}
                label="Filter by Status"
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <MenuItem value="all">All</MenuItem>
                <MenuItem value="queued">Queued</MenuItem>
                <MenuItem value="running">Running</MenuItem>
                <MenuItem value="completed">Completed</MenuItem>
                <MenuItem value="failed">Failed</MenuItem>
              </Select>
            </FormControl>
            <Button
              variant="outlined"
              startIcon={<Refresh />}
              onClick={fetchTrainingQueue}
            >
              Refresh
            </Button>
          </Paper>

          {/* Training Jobs Table */}
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Job ID</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Priority</TableCell>
                  <TableCell>Model</TableCell>
                  <TableCell>Progress</TableCell>
                  <TableCell>Queued At</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {jobs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      <Typography color="text.secondary">No training jobs found</Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  jobs.map((job) => (
                    <TableRow key={job.job_id} hover>
                      <TableCell>
                        <Tooltip title={job.job_id}>
                          <Typography variant="body2" sx={{ fontFamily: 'monospace' }}>
                            {job.job_id.substring(0, 8)}...
                          </Typography>
                        </Tooltip>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={job.status}
                          color={
                            job.status === 'completed' ? 'success' :
                            job.status === 'running' ? 'primary' :
                            job.status === 'failed' ? 'error' :
                            job.status === 'queued' ? 'info' : 'default'
                          }
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={job.priority}
                          color={
                            job.priority === 'high' ? 'error' :
                            job.priority === 'normal' ? 'primary' : 'default'
                          }
                          size="small"
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">{job.config.model_architecture}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          {job.total_epochs} epochs
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ width: 100 }}>
                          <LinearProgress
                            variant="determinate"
                            value={(job.current_epoch / job.total_epochs) * 100}
                          />
                          <Typography variant="caption" color="text.secondary">
                            {job.current_epoch}/{job.total_epochs}
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {job.queued_at ? new Date(job.queued_at).toLocaleString() : 'N/A'}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Tooltip title="View Details">
                          <IconButton
                            size="small"
                            onClick={() => {
                              setSelectedJob(job);
                              setDetailsOpen(true);
                            }}
                          >
                            <Info />
                          </IconButton>
                        </Tooltip>
                        {(job.status === 'queued' || job.status === 'running') && (
                          <Tooltip title="Cancel">
                            <IconButton
                              size="small"
                              color="warning"
                              onClick={async () => {
                                try {
                                  await fetch(`http://localhost:5000/api/v1/training/queue/${job.job_id}/cancel`, {
                                    method: 'POST'
                                  });
                                  fetchTrainingQueue();
                                } catch (error) {
                                  console.error('Failed to cancel job:', error);
                                }
                              }}
                            >
                              <Cancel />
                            </IconButton>
                          </Tooltip>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>

          {/* Job Details Dialog */}
          <Dialog open={detailsOpen} onClose={() => setDetailsOpen(false)} maxWidth="md" fullWidth>
            <DialogTitle>Training Job Details</DialogTitle>
            <DialogContent>
              {selectedJob && (
                <Box sx={{ pt: 2 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Typography variant="subtitle2" color="text.secondary">Job ID</Typography>
                      <Typography variant="body1" sx={{ fontFamily: 'monospace' }}>
                        {selectedJob.job_id}
                      </Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="subtitle2" color="text.secondary">Status</Typography>
                      <Chip label={selectedJob.status} size="small" />
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="subtitle2" color="text.secondary">Priority</Typography>
                      <Chip label={selectedJob.priority} size="small" />
                    </Grid>
                    <Grid item xs={12}>
                      <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                        Configuration
                      </Typography>
                      <Paper sx={{ p: 2, bgcolor: 'grey.50' }}>
                        <pre style={{ margin: 0, fontSize: '0.875rem' }}>
                          {JSON.stringify(selectedJob.config, null, 2)}
                        </pre>
                      </Paper>
                    </Grid>
                  </Grid>
                </Box>
              )}
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setDetailsOpen(false)}>Close</Button>
            </DialogActions>
          </Dialog>
        </Box>
      )}
    </Box>
  );
};

export default IngestWafers;
