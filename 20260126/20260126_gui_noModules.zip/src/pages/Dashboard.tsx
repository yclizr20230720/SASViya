import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Grid,
  CircularProgress,
  Alert,
} from '@mui/material';
import {
  Speed,
  CheckCircle,
  Warning,
  Info,
  Memory,
  Storage,
} from '@mui/icons-material';
import {
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import KPICard from '../components/KPICard';
import QuickActions from '../components/QuickActions';
import { TrendingUp } from '@mui/icons-material';
import { useState, useEffect } from 'react';
import { analyticsService } from '../services/analyticsService';
import type { DashboardAnalytics } from '../services/analyticsService';

const COLORS = ['#0066CC', '#00A3A3', '#F57C00', '#388E3C', '#D32F2F', '#9C27B0'];

export default function Dashboard() {
  const [dashboardData, setDashboardData] = useState<DashboardAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState(30);

  // Fetch dashboard analytics
  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await analyticsService.getDashboardAnalytics(dateRange);
        setDashboardData(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load dashboard data');
        console.error('Dashboard fetch error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboard();
    
    // Refresh every 30 seconds
    const interval = setInterval(fetchDashboard, 30000);
    return () => clearInterval(interval);
  }, [dateRange]);

  const getHealthColor = (status: string) => {
    switch (status) {
      case 'healthy':
      case 'active':
        return 'success';
      case 'warning':
        return 'warning';
      case 'error':
      case 'not_found':
        return 'error';
      default:
        return 'default';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'warning':
        return <Warning color="warning" />;
      case 'error':
        return <Warning color="error" />;
      case 'success':
        return <CheckCircle color="success" />;
      default:
        return <Info color="info" />;
    }
  };

  if (loading && !dashboardData) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '400px' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">
          {error}
        </Alert>
      </Box>
    );
  }

  if (!dashboardData) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="info">
          No dashboard data available
        </Alert>
      </Box>
    );
  }

  const { kpis, pattern_distribution, recent_activity, system_health } = dashboardData;

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 600 }}>
          Dashboard
        </Typography>
        <QuickActions variant="buttons" />
      </Box>

      {/* KPI Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Total Wafers"
            value={kpis.total_wafers}
            icon={<TrendingUp color="primary" fontSize="small" />}
            color="primary"
            subtitle={`${kpis.total_inferences} inferences`}
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Model Accuracy"
            value={(kpis.model_accuracy * 100).toFixed(1)}
            suffix="%"
            icon={<CheckCircle color="success" fontSize="small" />}
            showProgress
            progressValue={kpis.model_accuracy * 100}
            color="success"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Avg Confidence"
            value={(kpis.avg_confidence * 100).toFixed(1)}
            suffix="%"
            icon={<Speed color="info" fontSize="small" />}
            showProgress
            progressValue={kpis.avg_confidence * 100}
            color="info"
          />
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Defect Rate"
            value={(kpis.defect_rate * 100).toFixed(1)}
            suffix="%"
            icon={<Warning color="warning" fontSize="small" />}
            showProgress
            progressValue={kpis.defect_rate * 100}
            color="warning"
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        {/* Pattern Distribution */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Pattern Distribution
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pattern_distribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(item) => `${item.pattern} (${item.percentage}%)`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="count"
                  >
                    {pattern_distribution.map((_item, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* System Health */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                System Health
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2">API Status</Typography>
                  <Chip
                    label={system_health.api_status}
                    color={getHealthColor(system_health.api_status)}
                    size="small"
                    sx={{ textTransform: 'capitalize' }}
                  />
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2">Model Status</Typography>
                  <Chip
                    label={system_health.model_status}
                    color={getHealthColor(system_health.model_status)}
                    size="small"
                    sx={{ textTransform: 'capitalize' }}
                  />
                </Box>
                {system_health.gpu_available && (
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Memory fontSize="small" />
                      <Typography variant="body2">GPU Utilization</Typography>
                    </Box>
                    <Typography variant="body2" color="text.secondary">
                      {(system_health.gpu_utilization * 100).toFixed(1)}%
                    </Typography>
                  </Box>
                )}
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Speed fontSize="small" />
                    <Typography variant="body2">CPU Utilization</Typography>
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    {(system_health.cpu_utilization * 100).toFixed(1)}%
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Memory fontSize="small" />
                    <Typography variant="body2">Memory Utilization</Typography>
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    {(system_health.memory_utilization * 100).toFixed(1)}%
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Storage fontSize="small" />
                    <Typography variant="body2">Disk Utilization</Typography>
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    {(system_health.disk_utilization * 100).toFixed(1)}%
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Recent Activity */}
        <Grid size={{ xs: 12 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Recent Inferences
              </Typography>
              {recent_activity.length === 0 ? (
                <Alert severity="info">No recent activity</Alert>
              ) : (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
                  {recent_activity.map((activity, index) => (
                    <Box
                      key={index}
                      sx={{
                        display: 'flex',
                        gap: 2,
                        p: 1.5,
                        borderRadius: 1,
                        bgcolor: 'background.default',
                      }}
                    >
                      <CheckCircle color="success" />
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="body2">
                          <strong>{activity.wafer_id}</strong> - {activity.pattern} 
                          ({(activity.confidence * 100).toFixed(1)}% confidence)
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {new Date(activity.timestamp).toLocaleString()}
                        </Typography>
                      </Box>
                    </Box>
                  ))}
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
