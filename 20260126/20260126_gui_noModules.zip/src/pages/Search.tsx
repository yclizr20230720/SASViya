import { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  Stack,
  Chip,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  FilterList as FilterIcon,
  Bookmark as BookmarkIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
} from '@mui/icons-material';
import GlobalSearch from '../components/GlobalSearch';
import type { SearchResult } from '../components/GlobalSearch';
import AdvancedFilterPanel from '../components/AdvancedFilterPanel';
import type { FilterCriteria } from '../components/AdvancedFilterPanel';
import FacetedSearch from '../components/FacetedSearch';
import type { Facet } from '../components/FacetedSearch';
import SavedViewsManager from '../components/SavedViewsManager';
import type { SavedView } from '../components/SavedViewsManager';
import AdvancedDataTable from '../components/AdvancedDataTable';
import type { WaferData } from '../components/AdvancedDataTable';
import { generateMockWaferData, getFacetCounts } from '../utils/mockDataGenerator';
import { useNavigate } from 'react-router-dom';

export default function Search() {
  const navigate = useNavigate();
  const [showFilterPanel, setShowFilterPanel] = useState(false);
  const [showSavedViews, setShowSavedViews] = useState(false);
  const [showFilters, setShowFilters] = useState(true); // Toggle for filter sidebar
  const [allData] = useState<WaferData[]>(() => generateMockWaferData(100)); // Generate 100 wafers
  const [searchResults, setSearchResults] = useState<WaferData[]>([]);
  const [selectedFacets, setSelectedFacets] = useState<Record<string, string[]>>({});
  const [facets, setFacets] = useState<Facet[]>([]);

  // Initialize data and facets
  useEffect(() => {
    setSearchResults(allData);
    updateFacets(allData);
  }, [allData]);

  // Update facets based on current data
  const updateFacets = (data: WaferData[]) => {
    const counts = getFacetCounts(data);
    
    setFacets([
      {
        id: 'pattern',
        name: 'Pattern Type',
        options: counts.patterns,
      },
      {
        id: 'equipment',
        name: 'Equipment',
        options: counts.equipment,
      },
      {
        id: 'processStep',
        name: 'Process Step',
        options: counts.processSteps,
      },
    ]);
  };

  // Mock saved views
  const [savedViews, setSavedViews] = useState<SavedView[]>([
    {
      id: 'view1',
      name: 'High Confidence Wafers',
      description: 'Wafers with confidence > 90%',
      filters: { confidenceRange: [90, 100] },
      isShared: true,
      createdAt: '2024-01-15T10:00:00Z',
      updatedAt: '2024-01-15T10:00:00Z',
      createdBy: 'user1',
    },
  ]);

  // Handle search
  const handleSearch = (query: string) => {
    console.log('Searching for:', query);
    // Filter data based on search query
    const filtered = allData.filter((item) =>
      item.waferId.toLowerCase().includes(query.toLowerCase()) ||
      item.lotId.toLowerCase().includes(query.toLowerCase()) ||
      item.pattern.toLowerCase().includes(query.toLowerCase()) ||
      item.rootCause.toLowerCase().includes(query.toLowerCase())
    );
    setSearchResults(filtered);
    updateFacets(filtered);
  };

  // Handle result selection
  const handleResultSelect = (result: SearchResult) => {
    console.log('Selected result:', result);
    navigate(result.path);
  };

  // Handle filter apply
  const handleApplyFilters = (criteria: FilterCriteria) => {
    console.log('Applying filters:', criteria);
    // Apply filters to data
    let filtered = [...allData];
    
    // Apply pattern filter
    if (criteria.patternTypes && criteria.patternTypes.length > 0) {
      filtered = filtered.filter((item) =>
        criteria.patternTypes!.includes(item.pattern)
      );
    }
    
    // Apply confidence range filter
    if (criteria.confidenceRange) {
      const [min, max] = criteria.confidenceRange;
      filtered = filtered.filter((item) =>
        item.confidence >= min && item.confidence <= max
      );
    }
    
    // Apply equipment filter
    if (criteria.equipment && criteria.equipment.length > 0) {
      filtered = filtered.filter((item) =>
        criteria.equipment!.includes(item.equipment)
      );
    }
    
    // Apply process step filter
    if (criteria.processSteps && criteria.processSteps.length > 0) {
      filtered = filtered.filter((item) =>
        criteria.processSteps!.includes(item.processStep)
      );
    }
    
    setSearchResults(filtered);
    updateFacets(filtered);
  };

  // Handle facet change
  const handleFacetChange = (facetId: string, values: string[]) => {
    setSelectedFacets((prev) => ({
      ...prev,
      [facetId]: values,
    }));
    
    // Apply facet filters
    let filtered = [...allData];
    const newFacets = { ...selectedFacets, [facetId]: values };
    
    // Apply pattern facet
    if (newFacets.pattern && newFacets.pattern.length > 0) {
      filtered = filtered.filter((item) =>
        newFacets.pattern!.some((p) =>
          item.pattern.toLowerCase().replace(/-/g, '') === p
        )
      );
    }
    
    // Apply equipment facet
    if (newFacets.equipment && newFacets.equipment.length > 0) {
      filtered = filtered.filter((item) =>
        newFacets.equipment!.includes(item.equipment.toLowerCase())
      );
    }
    
    // Apply process step facet
    if (newFacets.processStep && newFacets.processStep.length > 0) {
      filtered = filtered.filter((item) =>
        newFacets.processStep!.some((p) =>
          item.processStep.toLowerCase().replace(/\s+/g, '') === p
        )
      );
    }
    
    setSearchResults(filtered);
    updateFacets(filtered);
  };

  // Handle clear all facets
  const handleClearAllFacets = () => {
    setSelectedFacets({});
    setSearchResults(allData);
    updateFacets(allData);
  };

  // Handle save view
  const handleSaveView = (view: Omit<SavedView, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newView: SavedView = {
      ...view,
      id: `view-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setSavedViews([...savedViews, newView]);
  };

  // Handle load view
  const handleLoadView = (view: SavedView) => {
    console.log('Loading view:', view);
  };

  // Handle delete view
  const handleDeleteView = (viewId: string) => {
    setSavedViews(savedViews.filter((v) => v.id !== viewId));
  };

  // Handle update view
  const handleUpdateView = (viewId: string, updates: Partial<SavedView>) => {
    setSavedViews(
      savedViews.map((v) => (v.id === viewId ? { ...v, ...updates } : v))
    );
  };

  // Handle view details
  const handleViewDetails = (row: WaferData) => {
    navigate(`/analysis/${row.waferId}`);
  };

  // Handle delete
  const handleDelete = (rows: WaferData[]) => {
    console.log('Deleting rows:', rows);
    const deletedIds = rows.map(r => r.id);
    setSearchResults(searchResults.filter(r => !deletedIds.includes(r.id)));
  };

  // Handle compare
  const handleCompare = (rows: WaferData[]) => {
    console.log('Comparing rows:', rows);
    // Navigate to comparison page or open comparison modal
  };

  // Handle export
  const handleExport = (rows: WaferData[], format: 'csv' | 'excel' | 'pdf') => {
    console.log(`Exporting ${rows.length} rows as ${format}`);
    // Implement actual export logic here
    alert(`Exporting ${rows.length} wafers as ${format.toUpperCase()}`);
  };

  // Get active filter count
  const getActiveFilterCount = () => {
    return Object.values(selectedFacets).reduce((sum, values) => sum + values.length, 0);
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 3, fontWeight: 600 }}>
        Search & Filter
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
        Search across all wafers, lots, and patterns. Use advanced filters and faceted search to find exactly what you need.
      </Typography>

      {/* Search Bar Section */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Stack direction="row" spacing={2} alignItems="center">
            <Box sx={{ flexGrow: 1 }}>
              <GlobalSearch onSearch={handleSearch} onResultSelect={handleResultSelect} />
            </Box>
            <Button
              variant="outlined"
              startIcon={<FilterIcon />}
              onClick={() => setShowFilterPanel(true)}
            >
              Advanced Filters
              {getActiveFilterCount() > 0 && (
                <Chip
                  label={getActiveFilterCount()}
                  size="small"
                  color="primary"
                  sx={{ ml: 1 }}
                />
              )}
            </Button>
            <Button
              variant="outlined"
              startIcon={<BookmarkIcon />}
              onClick={() => setShowSavedViews(true)}
            >
              Saved Views
            </Button>
          </Stack>
        </CardContent>
      </Card>

      {/* Main Content */}
      <Grid container spacing={3}>
        {/* Faceted Search Sidebar */}
        {showFilters && (
          <Grid size={{ xs: 12, md: 2.5 }}>
            <Box position="relative">
              <Tooltip title="Hide Filters">
                <IconButton
                  onClick={() => setShowFilters(false)}
                  sx={{
                    position: 'absolute',
                    right: -20,
                    top: '50%',
                    transform: 'translateY(-50%)',
                    zIndex: 1000,
                    backgroundColor: 'primary.main',
                    color: 'white',
                    border: '2px solid',
                    borderColor: 'primary.dark',
                    boxShadow: 2,
                    '&:hover': {
                      backgroundColor: 'primary.dark',
                      boxShadow: 4,
                    },
                  }}
                  size="small"
                >
                  <ChevronLeftIcon />
                </IconButton>
              </Tooltip>
              <FacetedSearch
                facets={facets}
                selectedFacets={selectedFacets}
                onFacetChange={handleFacetChange}
                onClearAll={handleClearAllFacets}
              />
            </Box>
          </Grid>
        )}

        {/* Search Results */}
        <Grid size={{ xs: 12, md: showFilters ? 9.5 : 12 }}>
          <Box position="relative">
            {!showFilters && (
              <Tooltip title="Show Filters">
                <IconButton
                  onClick={() => setShowFilters(true)}
                  sx={{
                    position: 'absolute',
                    left: -20,
                    top: '50%',
                    transform: 'translateY(-50%)',
                    zIndex: 1000,
                    backgroundColor: 'primary.main',
                    color: 'white',
                    border: '2px solid',
                    borderColor: 'primary.dark',
                    boxShadow: 2,
                    '&:hover': {
                      backgroundColor: 'primary.dark',
                      boxShadow: 4,
                    },
                  }}
                  size="small"
                >
                  <ChevronRightIcon />
                </IconButton>
              </Tooltip>
            )}
            <AdvancedDataTable
              data={searchResults}
              onViewDetails={handleViewDetails}
              onDelete={handleDelete}
              onCompare={handleCompare}
              onExport={handleExport}
            />
          </Box>
        </Grid>
      </Grid>

      {/* Advanced Filter Panel */}
      <AdvancedFilterPanel
        open={showFilterPanel}
        onClose={() => setShowFilterPanel(false)}
        onApplyFilters={handleApplyFilters}
        savedPresets={[]}
      />

      {/* Saved Views Manager */}
      <SavedViewsManager
        open={showSavedViews}
        onClose={() => setShowSavedViews(false)}
        onLoadView={handleLoadView}
        onSaveView={handleSaveView}
        onDeleteView={handleDeleteView}
        onUpdateView={handleUpdateView}
        savedViews={savedViews}
        currentUserId="current-user"
      />
    </Box>
  );
}
