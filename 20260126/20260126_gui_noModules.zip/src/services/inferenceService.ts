/**
 * Inference Service
 * 
 * Service for interacting with Inference API endpoints
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api/v1';

export interface InferenceResult {
  status: string;
  inference_id: string;
  wafer_id: string;
  pattern_class: string;
  pattern_confidence: number;
  root_cause: string;
  root_cause_confidence: number;
  processing_time_ms: number;
  timestamp: string;
  pattern_probabilities?: Record<string, number>;
  root_cause_probabilities?: Record<string, number>;
}

export interface BatchInferenceResult {
  status: string;
  processed_count: number;
  error_count: number;
  total_processing_time_ms: number;
  avg_processing_time_ms: number;
  results: Array<{
    inference_id: string;
    wafer_id: string;
    pattern_class: string;
    pattern_confidence: number;
    root_cause: string;
    root_cause_confidence: number;
  }>;
  errors?: string[];
}

export interface InferenceExplanation {
  status: string;
  wafer_id: string;
  inference_id: string;
  prediction: {
    pattern_class: string;
    pattern_confidence: number;
    root_cause: string;
    root_cause_confidence: number;
  };
  probabilities: {
    pattern: Record<string, number>;
    root_cause: Record<string, number>;
  };
  metadata: {
    lot_id: string | null;
    process_step: string | null;
    equipment_id: string | null;
    defect_count: number | null;
  };
  timestamp: string;
  note: string;
}

export interface InferenceHistory {
  status: string;
  total_count: number;
  returned_count: number;
  offset: number;
  limit: number;
  pattern_distribution: Record<string, number>;
  inferences: Array<{
    inference_id: string;
    wafer_id: string;
    pattern_class: string;
    pattern_confidence: number;
    root_cause: string;
    root_cause_confidence: number;
    processing_time_ms: number;
    timestamp: string;
    model_version: string;
  }>;
}

class InferenceService {
  /**
   * Predict for existing wafer
   */
  async predictWafer(waferId: string, explain: boolean = false): Promise<InferenceResult> {
    const response = await fetch(`${API_BASE_URL}/inference/predict`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        wafer_id: waferId,
        explain,
      }),
    });

    if (!response.ok) {
      throw new Error(`Failed to predict wafer: ${response.statusText}`);
    }
    return response.json();
  }

  /**
   * Predict with new image upload
   */
  async predictWithUpload(imageFile: File, explain: boolean = false): Promise<InferenceResult> {
    const formData = new FormData();
    formData.append('image_file', imageFile);
    formData.append('explain', explain.toString());

    const response = await fetch(`${API_BASE_URL}/inference/predict`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Failed to predict with upload: ${response.statusText}`);
    }
    return response.json();
  }

  /**
   * Batch predict for multiple wafers
   */
  async batchPredict(waferIds: string[], batchSize: number = 32): Promise<BatchInferenceResult> {
    const response = await fetch(`${API_BASE_URL}/inference/batch-predict`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        wafer_ids: waferIds,
        batch_size: batchSize,
      }),
    });

    if (!response.ok) {
      throw new Error(`Failed to batch predict: ${response.statusText}`);
    }
    return response.json();
  }

  /**
   * Get inference explanation
   */
  async getExplanation(waferId: string): Promise<InferenceExplanation> {
    const response = await fetch(`${API_BASE_URL}/inference/explain/${waferId}`);

    if (!response.ok) {
      throw new Error(`Failed to get explanation: ${response.statusText}`);
    }
    return response.json();
  }

  /**
   * Get inference history
   */
  async getHistory(params: {
    waferId?: string;
    pattern?: string;
    minConfidence?: number;
    startDate?: string;
    endDate?: string;
    limit?: number;
    offset?: number;
  } = {}): Promise<InferenceHistory> {
    const searchParams = new URLSearchParams();
    
    if (params.waferId) searchParams.append('wafer_id', params.waferId);
    if (params.pattern) searchParams.append('pattern', params.pattern);
    if (params.minConfidence !== undefined) searchParams.append('min_confidence', params.minConfidence.toString());
    if (params.startDate) searchParams.append('start_date', params.startDate);
    if (params.endDate) searchParams.append('end_date', params.endDate);
    if (params.limit) searchParams.append('limit', params.limit.toString());
    if (params.offset) searchParams.append('offset', params.offset.toString());

    const response = await fetch(`${API_BASE_URL}/inference/history?${searchParams}`);

    if (!response.ok) {
      throw new Error(`Failed to get inference history: ${response.statusText}`);
    }
    return response.json();
  }
}

export const inferenceService = new InferenceService();
