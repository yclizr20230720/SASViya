/**
 * Analytics Service
 * 
 * Service for interacting with Analytics API endpoints
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api/v1';

export interface DashboardAnalytics {
  status: string;
  date_range_days: number;
  kpis: {
    total_wafers: number;
    total_inferences: number;
    defect_rate: number;
    model_accuracy: number;
    avg_confidence: number;
  };
  pattern_distribution: Array<{
    pattern: string;
    count: number;
    percentage: number;
  }>;
  recent_activity: Array<{
    wafer_id: string;
    timestamp: string;
    pattern: string;
    confidence: number;
  }>;
  system_health: {
    api_status: string;
    model_status: string;
    gpu_available: boolean;
    gpu_utilization: number;
    cpu_utilization: number;
    memory_utilization: number;
    disk_utilization: number;
  };
}

export interface PatternAnalytics {
  status: string;
  date_range_days: number;
  granularity: string;
  total_inferences: number;
  pattern_distribution: Array<{
    pattern: string;
    count: number;
    percentage: number;
  }>;
  pattern_over_time: Array<{
    date: string;
    [key: string]: string | number;
  }>;
  pattern_by_equipment: Array<{
    equipment_id: string;
    patterns: Record<string, number>;
  }>;
}

export interface YieldAnalytics {
  status: string;
  date_range_days: number;
  overall_statistics: {
    total_wafers: number;
    good_wafers: number;
    defective_wafers: number;
    overall_yield_percentage: number;
  };
  yield_by_lot: Array<{
    lot_id: string;
    total_wafers: number;
    good_wafers: number;
    defective_wafers: number;
    yield_percentage: number;
  }>;
  yield_trends: Array<{
    date: string;
    total_wafers: number;
    good_wafers: number;
    yield_percentage: number;
  }>;
  defect_impact: Array<{
    pattern: string;
    count: number;
    percentage: number;
  }>;
}

export interface EquipmentAnalytics {
  status: string;
  date_range_days: number;
  equipment_performance: Array<{
    equipment_id: string;
    total_wafers: number;
    defective_wafers: number;
    defect_rate_percentage: number;
    avg_defect_count: number;
    most_common_pattern: string;
    pattern_distribution: Record<string, number>;
  }>;
  equipment_correlation: Array<{
    equipment_1: string;
    equipment_2: string;
    similarity_score: number;
    common_patterns: string[];
  }>;
}

export interface TemporalAnalytics {
  status: string;
  date_range_days: number;
  granularity: string;
  defect_trends: Array<{
    date: string;
    total_wafers: number;
    defective_wafers: number;
    defect_rate_percentage: number;
    avg_defect_count: number;
    total_defects: number;
  }>;
  statistics: {
    mean_defect_rate: number;
    std_deviation: number;
    anomaly_threshold: number;
  };
  anomalies: Array<{
    date: string;
    defect_rate: number;
    deviation: number;
    severity: string;
  }>;
  seasonal_patterns: Array<{
    day_of_week: string;
    total_wafers: number;
    defect_rate_percentage: number;
  }>;
}

class AnalyticsService {
  /**
   * Get dashboard analytics
   */
  async getDashboardAnalytics(dateRange: number = 30, lotId?: string): Promise<DashboardAnalytics> {
    const params = new URLSearchParams({ date_range: dateRange.toString() });
    if (lotId) params.append('lot_id', lotId);

    const response = await fetch(`${API_BASE_URL}/analytics/dashboard?${params}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch dashboard analytics: ${response.statusText}`);
    }
    return response.json();
  }

  /**
   * Get pattern analytics
   */
  async getPatternAnalytics(
    dateRange: number = 30,
    equipmentId?: string,
    granularity: string = 'day'
  ): Promise<PatternAnalytics> {
    const params = new URLSearchParams({
      date_range: dateRange.toString(),
      granularity,
    });
    if (equipmentId) params.append('equipment_id', equipmentId);

    const response = await fetch(`${API_BASE_URL}/analytics/patterns?${params}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch pattern analytics: ${response.statusText}`);
    }
    return response.json();
  }

  /**
   * Get yield analytics
   */
  async getYieldAnalytics(dateRange: number = 30, lotId?: string): Promise<YieldAnalytics> {
    const params = new URLSearchParams({ date_range: dateRange.toString() });
    if (lotId) params.append('lot_id', lotId);

    const response = await fetch(`${API_BASE_URL}/analytics/yield?${params}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch yield analytics: ${response.statusText}`);
    }
    return response.json();
  }

  /**
   * Get equipment analytics
   */
  async getEquipmentAnalytics(dateRange: number = 30): Promise<EquipmentAnalytics> {
    const params = new URLSearchParams({ date_range: dateRange.toString() });

    const response = await fetch(`${API_BASE_URL}/analytics/equipment?${params}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch equipment analytics: ${response.statusText}`);
    }
    return response.json();
  }

  /**
   * Get temporal analytics
   */
  async getTemporalAnalytics(
    dateRange: number = 90,
    granularity: string = 'day'
  ): Promise<TemporalAnalytics> {
    const params = new URLSearchParams({
      date_range: dateRange.toString(),
      granularity,
    });

    const response = await fetch(`${API_BASE_URL}/analytics/temporal?${params}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch temporal analytics: ${response.statusText}`);
    }
    return response.json();
  }
}

export const analyticsService = new AnalyticsService();
