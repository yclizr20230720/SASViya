/**
 * IndexedDB caching utilities for offline data storage
 * Provides persistent storage for wafer data, predictions, and analysis results
 */

const DB_NAME = 'WaferDefectDB';
const DB_VERSION = 1;

// Store names
export const STORES = {
  WAFERS: 'wafers',
  PREDICTIONS: 'predictions',
  REPORTS: 'reports',
  SETTINGS: 'settings',
} as const;

/**
 * Initialize IndexedDB database
 */
export function initDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Create object stores if they don't exist
      if (!db.objectStoreNames.contains(STORES.WAFERS)) {
        const waferStore = db.createObjectStore(STORES.WAFERS, {
          keyPath: 'id',
        });
        waferStore.createIndex('lotId', 'lotId', { unique: false });
        waferStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      if (!db.objectStoreNames.contains(STORES.PREDICTIONS)) {
        const predictionStore = db.createObjectStore(STORES.PREDICTIONS, {
          keyPath: 'id',
        });
        predictionStore.createIndex('waferId', 'waferId', { unique: false });
        predictionStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      if (!db.objectStoreNames.contains(STORES.REPORTS)) {
        const reportStore = db.createObjectStore(STORES.REPORTS, {
          keyPath: 'id',
        });
        reportStore.createIndex('type', 'type', { unique: false });
        reportStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      if (!db.objectStoreNames.contains(STORES.SETTINGS)) {
        db.createObjectStore(STORES.SETTINGS, { keyPath: 'key' });
      }
    };
  });
}

/**
 * Generic get operation
 */
export async function getItem<T>(
  storeName: string,
  key: string | number
): Promise<T | undefined> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.get(key);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Generic put operation
 */
export async function putItem<T>(
  storeName: string,
  item: T
): Promise<IDBValidKey> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.put(item);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Generic delete operation
 */
export async function deleteItem(
  storeName: string,
  key: string | number
): Promise<void> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.delete(key);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Get all items from a store
 */
export async function getAllItems<T>(storeName: string): Promise<T[]> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Get items by index
 */
export async function getItemsByIndex<T>(
  storeName: string,
  indexName: string,
  value: string | number
): Promise<T[]> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const store = transaction.objectStore(storeName);
    const index = store.index(indexName);
    const request = index.getAll(value);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Clear all items from a store
 */
export async function clearStore(storeName: string): Promise<void> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.clear();

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Count items in a store
 */
export async function countItems(storeName: string): Promise<number> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.count();

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Cache wafer data
 */
export async function cacheWafer(wafer: any): Promise<void> {
  await putItem(STORES.WAFERS, {
    ...wafer,
    cachedAt: Date.now(),
  });
}

/**
 * Get cached wafer
 */
export async function getCachedWafer(waferId: string): Promise<any> {
  return getItem(STORES.WAFERS, waferId);
}

/**
 * Cache prediction result
 */
export async function cachePrediction(prediction: any): Promise<void> {
  await putItem(STORES.PREDICTIONS, {
    ...prediction,
    cachedAt: Date.now(),
  });
}

/**
 * Get cached prediction
 */
export async function getCachedPrediction(predictionId: string): Promise<any> {
  return getItem(STORES.PREDICTIONS, predictionId);
}

/**
 * Clean up old cache entries (older than specified days)
 */
export async function cleanupOldCache(
  storeName: string,
  daysOld: number = 7
): Promise<void> {
  const db = await initDB();
  const cutoffTime = Date.now() - daysOld * 24 * 60 * 60 * 1000;

  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const index = store.index('timestamp');
    const request = index.openCursor();

    request.onsuccess = (event) => {
      const cursor = (event.target as IDBRequest).result;
      if (cursor) {
        if (cursor.value.timestamp < cutoffTime) {
          cursor.delete();
        }
        cursor.continue();
      } else {
        resolve();
      }
    };

    request.onerror = () => reject(request.error);
  });
}
