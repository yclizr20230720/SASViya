// Mock data for demonstration purposes

export interface MockWaferMap {
  id: string;
  waferId: string;
  lotId: string;
  processStep: string;
  equipmentId: string;
  timestamp: string;
  dieCountX: number;
  dieCountY: number;
  defectCount: number;
  defectDensity: number;
  patternType: string;
  status: 'completed' | 'processing' | 'error';
}

export interface MockPrediction {
  id: string;
  waferId: string;
  patternClass: string;
  patternConfidence: number;
  rootCauseClass: string;
  rootCauseConfidence: number;
  processingTimeMs: number;
  timestamp: string;
  defectHeatmap: number[][];
  shapValues: Record<string, number>;
  attentionLayers?: {
    layerName: string;
    attentionWeights: number[][];
  }[];
  confidenceFactors?: {
    name: string;
    score: number;
    weight: number;
    description: string;
    status: 'excellent' | 'good' | 'fair' | 'poor';
  }[];
}

export const mockWafers: MockWaferMap[] = [
  {
    id: '1',
    waferId: 'W2026-001-01',
    lotId: 'LOT-2026-A001',
    processStep: 'Lithography',
    equipmentId: 'LITHO-001',
    timestamp: '2026-01-17T08:30:00Z',
    dieCountX: 30,
    dieCountY: 30,
    defectCount: 45,
    defectDensity: 0.05,
    patternType: 'Edge Defect',
    status: 'completed',
  },
  {
    id: '2',
    waferId: 'W2026-001-02',
    lotId: 'LOT-2026-A001',
    processStep: 'Etching',
    equipmentId: 'ETCH-002',
    timestamp: '2026-01-17T09:15:00Z',
    dieCountX: 30,
    dieCountY: 30,
    defectCount: 23,
    defectDensity: 0.026,
    patternType: 'Center Defect',
    status: 'completed',
  },
  {
    id: '3',
    waferId: 'W2026-001-03',
    lotId: 'LOT-2026-A001',
    processStep: 'Deposition',
    equipmentId: 'DEP-003',
    timestamp: '2026-01-17T10:00:00Z',
    dieCountX: 30,
    dieCountY: 30,
    defectCount: 67,
    defectDensity: 0.074,
    patternType: 'Scratch Pattern',
    status: 'completed',
  },
  {
    id: '4',
    waferId: 'W2026-002-01',
    lotId: 'LOT-2026-B002',
    processStep: 'Lithography',
    equipmentId: 'LITHO-002',
    timestamp: '2026-01-17T11:20:00Z',
    dieCountX: 30,
    dieCountY: 30,
    defectCount: 12,
    defectDensity: 0.013,
    patternType: 'Random Defects',
    status: 'completed',
  },
  {
    id: '5',
    waferId: 'W2026-002-02',
    lotId: 'LOT-2026-B002',
    processStep: 'CMP',
    equipmentId: 'CMP-001',
    timestamp: '2026-01-17T12:45:00Z',
    dieCountX: 30,
    dieCountY: 30,
    defectCount: 89,
    defectDensity: 0.099,
    patternType: 'Ring Pattern',
    status: 'completed',
  },
];

export const mockPredictions: Record<string, MockPrediction> = {
  '1': {
    id: 'pred-1',
    waferId: 'W2026-001-01',
    patternClass: 'Edge Defect',
    patternConfidence: 0.96,
    rootCauseClass: 'Edge Exclusion Issue',
    rootCauseConfidence: 0.89,
    processingTimeMs: 3420,
    timestamp: '2026-01-17T08:30:15Z',
    defectHeatmap: generateEdgeDefectHeatmap(),
    shapValues: {
      'Defect Density': 0.32,
      'Spatial Distribution': 0.28,
      'Edge Distance': 0.45,
      'Cluster Size': 0.15,
      'Pattern Symmetry': 0.22,
    },
    attentionLayers: [
      {
        layerName: 'Layer 1',
        attentionWeights: generateAttentionWeights(0.3),
      },
      {
        layerName: 'Layer 2',
        attentionWeights: generateAttentionWeights(0.5),
      },
      {
        layerName: 'Layer 3',
        attentionWeights: generateAttentionWeights(0.7),
      },
    ],
    confidenceFactors: [
      {
        name: 'Pattern Clarity',
        score: 0.95,
        weight: 0.3,
        description: 'How clearly the pattern is defined in the wafer map',
        status: 'excellent',
      },
      {
        name: 'Historical Match',
        score: 0.88,
        weight: 0.25,
        description: 'Similarity to known historical patterns',
        status: 'excellent',
      },
      {
        name: 'Feature Consistency',
        score: 0.92,
        weight: 0.2,
        description: 'Consistency of extracted features',
        status: 'excellent',
      },
      {
        name: 'Data Quality',
        score: 0.85,
        weight: 0.15,
        description: 'Quality and completeness of input data',
        status: 'good',
      },
      {
        name: 'Model Certainty',
        score: 0.96,
        weight: 0.1,
        description: 'Model output probability distribution',
        status: 'excellent',
      },
    ],
  },
  '2': {
    id: 'pred-2',
    waferId: 'W2026-001-02',
    patternClass: 'Center Defect',
    patternConfidence: 0.93,
    rootCauseClass: 'Process Drift',
    rootCauseConfidence: 0.85,
    processingTimeMs: 2980,
    timestamp: '2026-01-17T09:15:12Z',
    defectHeatmap: generateCenterDefectHeatmap(),
    shapValues: {
      'Defect Density': 0.25,
      'Spatial Distribution': 0.38,
      'Edge Distance': 0.12,
      'Cluster Size': 0.29,
      'Pattern Symmetry': 0.35,
    },
  },
  '3': {
    id: 'pred-3',
    waferId: 'W2026-001-03',
    patternClass: 'Scratch Pattern',
    patternConfidence: 0.98,
    rootCauseClass: 'Mechanical Damage',
    rootCauseConfidence: 0.94,
    processingTimeMs: 3150,
    timestamp: '2026-01-17T10:00:18Z',
    defectHeatmap: generateScratchDefectHeatmap(),
    shapValues: {
      'Defect Density': 0.42,
      'Spatial Distribution': 0.48,
      'Edge Distance': 0.18,
      'Cluster Size': 0.38,
      'Pattern Symmetry': 0.15,
    },
  },
  '4': {
    id: 'pred-4',
    waferId: 'W2026-002-01',
    patternClass: 'Random Defects',
    patternConfidence: 0.87,
    rootCauseClass: 'Contamination',
    rootCauseConfidence: 0.78,
    processingTimeMs: 2750,
    timestamp: '2026-01-17T11:20:09Z',
    defectHeatmap: generateRandomDefectHeatmap(),
    shapValues: {
      'Defect Density': 0.18,
      'Spatial Distribution': 0.22,
      'Edge Distance': 0.15,
      'Cluster Size': 0.12,
      'Pattern Symmetry': 0.08,
    },
  },
  '5': {
    id: 'pred-5',
    waferId: 'W2026-002-02',
    patternClass: 'Ring Pattern',
    patternConfidence: 0.91,
    rootCauseClass: 'CMP Non-Uniformity',
    rootCauseConfidence: 0.86,
    processingTimeMs: 3890,
    timestamp: '2026-01-17T12:45:22Z',
    defectHeatmap: generateRingDefectHeatmap(),
    shapValues: {
      'Defect Density': 0.38,
      'Spatial Distribution': 0.45,
      'Edge Distance': 0.25,
      'Cluster Size': 0.32,
      'Pattern Symmetry': 0.42,
    },
  },
};

// Helper functions to generate heatmaps
function generateEdgeDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      const distFromCenter = Math.sqrt(
        Math.pow(i - size / 2, 2) + Math.pow(j - size / 2, 2)
      );
      const maxDist = size / 2;
      if (distFromCenter > maxDist * 0.8) {
        heatmap[i][j] = Math.random() * 0.8 + 0.2;
      } else {
        heatmap[i][j] = Math.random() * 0.1;
      }
    }
  }
  return heatmap;
}

function generateCenterDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      const distFromCenter = Math.sqrt(
        Math.pow(i - size / 2, 2) + Math.pow(j - size / 2, 2)
      );
      const maxDist = size / 2;
      if (distFromCenter < maxDist * 0.3) {
        heatmap[i][j] = Math.random() * 0.7 + 0.3;
      } else {
        heatmap[i][j] = Math.random() * 0.15;
      }
    }
  }
  return heatmap;
}

function generateScratchDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  // Create diagonal scratch
  for (let i = 0; i < size; i++) {
    const j = Math.floor((i * size) / size);
    for (let offset = -2; offset <= 2; offset++) {
      if (j + offset >= 0 && j + offset < size) {
        heatmap[i][j + offset] = Math.random() * 0.6 + 0.4;
      }
    }
  }
  return heatmap;
}

function generateRandomDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      heatmap[i][j] = Math.random() * 0.3;
    }
  }
  return heatmap;
}

function generateRingDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      const distFromCenter = Math.sqrt(
        Math.pow(i - size / 2, 2) + Math.pow(j - size / 2, 2)
      );
      const maxDist = size / 2;
      const ringDist = Math.abs(distFromCenter - maxDist * 0.6);
      if (ringDist < maxDist * 0.15) {
        heatmap[i][j] = Math.random() * 0.7 + 0.3;
      } else {
        heatmap[i][j] = Math.random() * 0.1;
      }
    }
  }
  return heatmap;
}

function generateAttentionWeights(intensity: number): number[][] {
  const size = 10; // Smaller grid for attention
  const weights: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      const distFromCenter = Math.sqrt(
        Math.pow(i - size / 2, 2) + Math.pow(j - size / 2, 2)
      );
      const maxDist = size / 2;
      const baseWeight = Math.max(0, 1 - distFromCenter / maxDist);
      weights[i][j] = baseWeight * intensity + Math.random() * 0.2;
    }
  }
  return weights;
}

export const patternTypes = [
  'Edge Defect',
  'Center Defect',
  'Scratch Pattern',
  'Ring Pattern',
  'Random Defects',
  'Local Cluster',
  'Systematic Pattern',
];

export const rootCauses = [
  'Edge Exclusion Issue',
  'Process Drift',
  'Mechanical Damage',
  'Contamination',
  'CMP Non-Uniformity',
  'Lithography Misalignment',
  'Equipment Malfunction',
  'Material Defect',
];

export const kpiData = {
  totalWafersProcessed: 1247,
  averageAccuracy: 94.2,
  averageProcessingTime: 3.2,
  defectDetectionRate: 98.7,
  todayProcessed: 45,
  weeklyTrend: 12.5,
  monthlyYield: 96.3,
};

export const systemHealth = {
  apiService: 'healthy',
  inferenceService: 'healthy',
  ganService: 'healthy',
  database: 'healthy',
  storage: 'warning',
};

export const recentActivity = [
  {
    id: '1',
    type: 'analysis',
    message: 'Wafer W2026-002-02 analyzed - Ring Pattern detected',
    timestamp: '2 minutes ago',
    severity: 'info',
  },
  {
    id: '2',
    type: 'alert',
    message: 'High defect density detected on LOT-2026-B002',
    timestamp: '15 minutes ago',
    severity: 'warning',
  },
  {
    id: '3',
    type: 'upload',
    message: 'Batch upload completed - 5 wafers processed',
    timestamp: '1 hour ago',
    severity: 'success',
  },
  {
    id: '4',
    type: 'model',
    message: 'Model v2.3 deployed to production',
    timestamp: '3 hours ago',
    severity: 'info',
  },
];
