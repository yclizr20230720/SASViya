/**
 * Mock Wafer Inference Data
 * Semiconductor industry standard format for defect bin map data
 */

export interface DefectBinData {
  waferID: string;
  lotID: string;
  toolID: string;
  scanTime: string;
  defects: {
    binCode: number;
    locationX: number;
    locationY: number;
    defectType?: string;
  }[];
  waferDiameter: number; // in mm
  dieSize: { x: number; y: number }; // in mm
  gridSize: { rows: number; cols: number };
}

/**
 * Generate semiconductor industry standard Wafer ID
 * Format: FAB-LOT-WAFER-SLOT
 * Example: F12-2401A-W15-S03
 */
export const generateWaferID = (lotNum: number, waferNum: number): string => {
  const fab = 'F12'; // Fab 12
  const year = '24';
  const month = '01';
  const lotLetter = String.fromCharCode(65 + (lotNum % 26)); // A-Z
  const wafer = waferNum.toString().padStart(2, '0');
  const slot = (waferNum % 25 + 1).toString().padStart(2, '0');
  
  return `${fab}-${year}${month}${lotLetter}-W${wafer}-S${slot}`;
};

/**
 * Generate Lot ID
 * Format: LOT-YYMM-XXXX
 * Example: LOT-2401-A001
 */
export const generateLotID = (lotNum: number): string => {
  const year = '24';
  const month = '01';
  const lotLetter = String.fromCharCode(65 + (lotNum % 26));
  const lotNumber = lotNum.toString().padStart(3, '0');
  
  return `LOT-${year}${month}-${lotLetter}${lotNumber}`;
};

/**
 * Generate Tool/Equipment ID
 * Format: TOOL-TYPE-NUMBER
 * Example: LITHO-ASML-04, ETCH-LAM-12
 */
export const generateToolID = (toolType: string, toolNum: number): string => {
  const vendors: Record<string, string> = {
    'LITHO': 'ASML',
    'ETCH': 'LAM',
    'CVD': 'AMAT',
    'CMP': 'EBARA',
    'IMPLANT': 'AMAT',
    'INSPECT': 'KLA'
  };
  
  const vendor = vendors[toolType] || 'TOOL';
  const number = toolNum.toString().padStart(2, '0');
  
  return `${toolType}-${vendor}-${number}`;
};

/**
 * Mock Wafer Data - Matching the provided wafer map images
 */
export const mockWaferData: DefectBinData[] = [
  // Wafer 1: Random defects pattern
  {
    waferID: generateWaferID(1, 1),
    lotID: generateLotID(1),
    toolID: generateToolID('LITHO', 4),
    scanTime: '2024-01-15T08:30:45Z',
    waferDiameter: 300,
    dieSize: { x: 10, y: 10 },
    gridSize: { rows: 26, cols: 26 },
    defects: [
      { binCode: 1, locationX: 5, locationY: 8, defectType: 'Particle' },
      { binCode: 1, locationX: 12, locationY: 15, defectType: 'Particle' },
      { binCode: 1, locationX: 18, locationY: 6, defectType: 'Particle' },
      { binCode: 2, locationX: 20, locationY: 10, defectType: 'Scratch' },
      { binCode: 1, locationX: 8, locationY: 20, defectType: 'Particle' },
      { binCode: 1, locationX: 15, locationY: 12, defectType: 'Particle' },
      { binCode: 1, locationX: 22, locationY: 18, defectType: 'Particle' },
      { binCode: 1, locationX: 10, locationY: 5, defectType: 'Particle' },
    ]
  },
  
  // Wafer 2: Center cluster pattern
  {
    waferID: generateWaferID(1, 2),
    lotID: generateLotID(1),
    toolID: generateToolID('CVD', 7),
    scanTime: '2024-01-15T09:15:22Z',
    waferDiameter: 300,
    dieSize: { x: 10, y: 10 },
    gridSize: { rows: 26, cols: 26 },
    defects: [
      { binCode: 3, locationX: 12, locationY: 12, defectType: 'Void' },
      { binCode: 3, locationX: 13, locationY: 12, defectType: 'Void' },
      { binCode: 3, locationX: 12, locationY: 13, defectType: 'Void' },
      { binCode: 3, locationX: 13, locationY: 13, defectType: 'Void' },
      { binCode: 3, locationX: 14, locationY: 12, defectType: 'Void' },
      { binCode: 3, locationX: 12, locationY: 14, defectType: 'Void' },
      { binCode: 3, locationX: 14, locationY: 13, defectType: 'Void' },
      { binCode: 3, locationX: 13, locationY: 14, defectType: 'Void' },
      { binCode: 3, locationX: 14, locationY: 14, defectType: 'Void' },
      { binCode: 1, locationX: 11, locationY: 11, defectType: 'Particle' },
      { binCode: 1, locationX: 15, locationY: 15, defectType: 'Particle' },
    ]
  },
  
  // Wafer 3: Edge ring pattern
  {
    waferID: generateWaferID(1, 3),
    lotID: generateLotID(1),
    toolID: generateToolID('ETCH', 12),
    scanTime: '2024-01-15T10:45:18Z',
    waferDiameter: 300,
    dieSize: { x: 10, y: 10 },
    gridSize: { rows: 26, cols: 26 },
    defects: [
      { binCode: 4, locationX: 2, locationY: 13, defectType: 'Edge-Defect' },
      { binCode: 4, locationX: 3, locationY: 13, defectType: 'Edge-Defect' },
      { binCode: 4, locationX: 23, locationY: 13, defectType: 'Edge-Defect' },
      { binCode: 4, locationX: 24, locationY: 13, defectType: 'Edge-Defect' },
      { binCode: 4, locationX: 13, locationY: 2, defectType: 'Edge-Defect' },
      { binCode: 4, locationX: 13, locationY: 3, defectType: 'Edge-Defect' },
      { binCode: 4, locationX: 13, locationY: 23, defectType: 'Edge-Defect' },
      { binCode: 4, locationX: 13, locationY: 24, defectType: 'Edge-Defect' },
      { binCode: 1, locationX: 5, locationY: 5, defectType: 'Particle' },
      { binCode: 1, locationX: 20, locationY: 20, defectType: 'Particle' },
    ]
  },
  
  // Wafer 4: Scratch pattern
  {
    waferID: generateWaferID(2, 1),
    lotID: generateLotID(2),
    toolID: generateToolID('CMP', 3),
    scanTime: '2024-01-15T11:20:55Z',
    waferDiameter: 300,
    dieSize: { x: 10, y: 10 },
    gridSize: { rows: 26, cols: 26 },
    defects: [
      { binCode: 2, locationX: 8, locationY: 10, defectType: 'Scratch' },
      { binCode: 2, locationX: 9, locationY: 11, defectType: 'Scratch' },
      { binCode: 2, locationX: 10, locationY: 12, defectType: 'Scratch' },
      { binCode: 2, locationX: 11, locationY: 13, defectType: 'Scratch' },
      { binCode: 2, locationX: 12, locationY: 14, defectType: 'Scratch' },
      { binCode: 2, locationX: 13, locationY: 15, defectType: 'Scratch' },
      { binCode: 2, locationX: 14, locationY: 16, defectType: 'Scratch' },
      { binCode: 2, locationX: 15, locationY: 17, defectType: 'Scratch' },
      { binCode: 1, locationX: 5, locationY: 8, defectType: 'Particle' },
      { binCode: 1, locationX: 20, locationY: 15, defectType: 'Particle' },
    ]
  },
  
  // Wafer 5: Zone pattern
  {
    waferID: generateWaferID(2, 2),
    lotID: generateLotID(2),
    toolID: generateToolID('LITHO', 8),
    scanTime: '2024-01-15T13:05:33Z',
    waferDiameter: 300,
    dieSize: { x: 10, y: 10 },
    gridSize: { rows: 26, cols: 26 },
    defects: [
      { binCode: 5, locationX: 8, locationY: 8, defectType: 'Process-Defect' },
      { binCode: 5, locationX: 9, locationY: 8, defectType: 'Process-Defect' },
      { binCode: 5, locationX: 10, locationY: 8, defectType: 'Process-Defect' },
      { binCode: 5, locationX: 8, locationY: 9, defectType: 'Process-Defect' },
      { binCode: 5, locationX: 9, locationY: 9, defectType: 'Process-Defect' },
      { binCode: 5, locationX: 10, locationY: 9, defectType: 'Process-Defect' },
      { binCode: 5, locationX: 8, locationY: 10, defectType: 'Process-Defect' },
      { binCode: 5, locationX: 9, locationY: 10, defectType: 'Process-Defect' },
      { binCode: 5, locationX: 10, locationY: 10, defectType: 'Process-Defect' },
      { binCode: 1, locationX: 15, locationY: 15, defectType: 'Particle' },
      { binCode: 1, locationX: 18, locationY: 12, defectType: 'Particle' },
    ]
  },
];

/**
 * Export mock data as CSV format
 */
export const generateCSVData = (waferData: DefectBinData): string => {
  let csv = 'WaferID,LotID,ToolID,ScanTime,BinCode,LocationX,LocationY,DefectType\n';
  
  waferData.defects.forEach(defect => {
    csv += `${waferData.waferID},${waferData.lotID},${waferData.toolID},${waferData.scanTime},${defect.binCode},${defect.locationX},${defect.locationY},${defect.defectType || 'Unknown'}\n`;
  });
  
  return csv;
};

/**
 * Export mock data as JSON format
 */
export const generateJSONData = (waferData: DefectBinData): string => {
  return JSON.stringify(waferData, null, 2);
};

/**
 * Generate sample CSV file for download
 */
export const downloadSampleCSV = () => {
  const csv = generateCSVData(mockWaferData[0]);
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `sample_wafer_data_${mockWaferData[0].waferID}.csv`;
  a.click();
  window.URL.revokeObjectURL(url);
};

/**
 * Generate sample JSON file for download
 */
export const downloadSampleJSON = () => {
  const json = generateJSONData(mockWaferData[0]);
  const blob = new Blob([json], { type: 'application/json' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `sample_wafer_data_${mockWaferData[0].waferID}.json`;
  a.click();
  window.URL.revokeObjectURL(url);
};
