import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import WizardSteps from "@/components/WizardSteps";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ChevronRight, BarChart3, CheckCircle2, Download, Loader2, Clock, Table2, Code2, FileText } from "lucide-react";
import { Link, useParams } from "wouter";
import { toast } from "sonner";
import { WIZARD_STEPS } from "./wizardConfig";

export default function DatasetExecute() {
  const { id } = useParams<{ id: string }>();
  const draftId = parseInt(id);
  const [isExecuting, setIsExecuting] = useState(false);

  const { data: draft, refetch } = trpc.datasets.getById.useQuery({ id: draftId });
  const def = (draft?.definitionJson || {}) as any;

  const executeMutation = trpc.fabDataset.executeData.useMutation({
    onMutate: () => setIsExecuting(true),
    onSuccess: () => { toast.success("Full query completed!"); refetch(); setIsExecuting(false); },
    onError: (e) => { toast.error(e.message); setIsExecuting(false); },
  });

  const completedSteps = draft ? getCompletedSteps(draft.status as string) : [];
  const executeResult = def.executeResult;
  const isCompleted = draft?.status === "completed";

  const handleDownloadCsv = () => {
    if (!executeResult) return;
    const header = executeResult.columns.join(",");
    const rows = executeResult.rows.map((r: any) =>
      executeResult.columns.map((c: string) => {
        const v = r[c] ?? ""; const s = String(v);
        return s.includes(",") || s.includes('"') || s.includes("\n") ? `"${s.replace(/"/g, '""')}"` : s;
      }).join(",")
    );
    const csv = [header, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${draft?.name ?? "dataset"}_full.csv`; a.click();
    URL.revokeObjectURL(url);
    toast.success(`Downloaded ${executeResult.rowCount} rows as CSV`);
  };

  const handleDownloadJson = () => {
    if (!executeResult) return;
    const json = JSON.stringify(executeResult.rows, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${draft?.name ?? "dataset"}_full.json`; a.click();
    URL.revokeObjectURL(url);
    toast.success("Downloaded as JSON");
  };

  return (
    <AppLayout>
      <div className="p-6 max-w-6xl mx-auto">
        <div className="mb-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
            <Link href="/datasets"><span className="hover:text-foreground cursor-pointer">Datasets</span></Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground font-medium">{draft?.name}</span>
          </div>
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold">Execute Full Query</h1>
            <div className="flex gap-2">
              <Link href={`/datasets/${draftId}/preview`}>
                <Button variant="outline" size="sm" className="gap-1"><ArrowLeft className="w-3 h-3" /> Back</Button>
              </Link>
              {isCompleted && executeResult ? (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleDownloadJson} className="gap-1">
                    <FileText className="w-3.5 h-3.5" />JSON
                  </Button>
                  <Button onClick={handleDownloadCsv} className="gap-2 bg-green-600 hover:bg-green-700">
                    <Download className="w-4 h-4" /> Download CSV ({executeResult.rowCount?.toLocaleString()} rows)
                  </Button>
                </div>
              ) : (
                <Button onClick={() => executeMutation.mutate({ id: draftId })} disabled={isExecuting} className="gap-2">
                  {isExecuting ? <Loader2 className="w-4 h-4 animate-spin" /> : <BarChart3 className="w-4 h-4" />}
                  {isExecuting ? "Executing Query..." : "Execute Full Query"}
                </Button>
              )}
            </div>
          </div>
        </div>
        <div className="mb-5 overflow-x-auto">
          <WizardSteps steps={WIZARD_STEPS} currentStep="execute" completedSteps={completedSteps} />
        </div>

        {isExecuting && (
          <Card className="mb-4 border-blue-200 bg-blue-50">
            <CardContent className="py-8 text-center">
              <Loader2 className="h-10 w-10 animate-spin text-blue-600 mx-auto mb-3" />
              <p className="font-medium text-blue-800">Executing query against fab database...</p>
              <p className="text-sm text-blue-600 mt-1">Fetching up to {(def.rowLimit ?? 10000).toLocaleString()} rows</p>
              <Progress value={undefined} className="mt-4 max-w-xs mx-auto" />
            </CardContent>
          </Card>
        )}

        {!isCompleted && !isExecuting && (
          <Card className="border-dashed mb-4">
            <CardContent className="py-12 text-center">
              <BarChart3 className="w-12 h-12 mx-auto mb-3 text-muted-foreground/30" />
              <p className="text-sm font-medium text-muted-foreground">Ready to execute full query</p>
              <p className="text-xs mt-1 text-muted-foreground">
                Will fetch up to <strong>{(def.rowLimit ?? 10000).toLocaleString()}</strong> rows · <strong>{def.timeoutSec ?? 60}s</strong> timeout
              </p>
              <Button className="mt-4 gap-2" onClick={() => executeMutation.mutate({ id: draftId })}>
                <BarChart3 className="w-4 h-4" /> Execute Full Query
              </Button>
            </CardContent>
          </Card>
        )}

        {isCompleted && executeResult && (
          <div className="space-y-4">
            <div className="grid grid-cols-4 gap-3">
              {[
                { label: "Rows Returned", value: executeResult.rowCount?.toLocaleString(), icon: Table2, color: "text-green-600" },
                { label: "Total Matched", value: executeResult.totalCount?.toLocaleString() ?? "—", icon: BarChart3, color: "text-blue-600" },
                { label: "Columns", value: executeResult.columns?.length, icon: Table2, color: "text-purple-600" },
                { label: "Query Time", value: `${executeResult.durationMs}ms`, icon: Clock, color: "text-orange-600" },
              ].map(stat => (
                <Card key={stat.label}>
                  <CardContent className="pt-4 pb-3">
                    <div className="flex items-center gap-2">
                      <stat.icon className={`h-5 w-5 ${stat.color}`} />
                      <div>
                        <p className="text-lg font-bold">{stat.value}</p>
                        <p className="text-xs text-muted-foreground">{stat.label}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            {def.generatedSql && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xs flex items-center gap-1.5 text-muted-foreground"><Code2 className="h-3.5 w-3.5" />Executed SQL</CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-[10px] font-mono bg-muted/50 p-3 rounded overflow-x-auto whitespace-pre-wrap">{def.generatedSql}</pre>
                </CardContent>
              </Card>
            )}
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    Full Results
                    <Badge className="text-[10px] bg-green-100 text-green-700 border-0">{executeResult.rowCount?.toLocaleString()} rows</Badge>
                  </CardTitle>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={handleDownloadJson}><FileText className="h-3 w-3" />JSON</Button>
                    <Button size="sm" className="h-7 text-xs gap-1 bg-green-600 hover:bg-green-700" onClick={handleDownloadCsv}><Download className="h-3 w-3" />CSV</Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-auto max-h-[500px]">
                  <table className="w-full text-xs border-collapse">
                    <thead className="sticky top-0 bg-muted/90 backdrop-blur-sm z-10">
                      <tr>
                        <th className="text-left px-3 py-2 font-medium text-muted-foreground border-b border-border w-10">#</th>
                        {executeResult.columns?.map((col: string) => (
                          <th key={col} className="text-left px-3 py-2 font-mono font-semibold border-b border-border whitespace-nowrap">{col}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {executeResult.rows?.map((row: any, i: number) => (
                        <tr key={i} className={`hover:bg-accent/30 border-b border-border/50 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                          <td className="px-3 py-1.5 text-muted-foreground">{i + 1}</td>
                          {executeResult.columns?.map((col: string) => (
                            <td key={col} className="px-3 py-1.5 font-mono whitespace-nowrap max-w-[200px] truncate">
                              {row[col] === null || row[col] === undefined ? <span className="text-muted-foreground italic">NULL</span> : String(row[col])}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

function getCompletedSteps(status: string): string[] {
  const order = ["columns", "requirement", "criteria", "review", "preview", "execute"];
  const statusMap: Record<string, string> = {
    draft: "", columns_selected: "columns", requirements_set: "requirement",
    criteria_set: "criteria", sql_generated: "review", preview_approved: "preview", completed: "execute",
  };
  const current = statusMap[status] ?? "";
  const idx = order.indexOf(current);
  return order.slice(0, idx);
}
