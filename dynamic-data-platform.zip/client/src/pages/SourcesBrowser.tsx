import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Database, ChevronRight, ChevronDown, Table2, Columns,
  RefreshCw, Search, Info, Key, Hash, Type, AlertCircle,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export default function SourcesBrowser() {
  const { user } = useAuth();
  const [selectedSource, setSelectedSource] = useState<number | null>(null);
  const [selectedSchema, setSelectedSchema] = useState<string | null>(null);
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [expandedSchemas, setExpandedSchemas] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");

  const { data: sources = [], isLoading: sourcesLoading } = trpc.sources.list.useQuery();
  const { data: schemas = [], isLoading: schemasLoading } = trpc.sources.listSchemas.useQuery(
    { sourceId: selectedSource! },
    { enabled: !!selectedSource }
  );
  const { data: tables = [], isLoading: tablesLoading } = trpc.sources.listTables.useQuery(
    { sourceId: selectedSource!, schemaName: selectedSchema! },
    { enabled: !!selectedSource && !!selectedSchema }
  );
  const { data: columns = [], isLoading: columnsLoading } = trpc.sources.listColumns.useQuery(
    { sourceId: selectedSource!, schemaName: selectedSchema!, tableName: selectedTable! },
    { enabled: !!selectedSource && !!selectedSchema && !!selectedTable }
  );

  const refreshMeta = trpc.sources.refreshMetadata.useMutation({
    onSuccess: (data) => toast.success(`Metadata refreshed: ${data.tablesRefreshed} tables updated`),
    onError: (e) => toast.error(e.message),
  });

  const filteredTables = tables.filter((t: any) =>
    !search || t.tableName.toLowerCase().includes(search.toLowerCase())
  );

  const currentSource = sources.find((s: any) => s.id === selectedSource);

  return (
    <AppLayout>
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-border bg-card">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground">Schema Browser</h1>
              <p className="text-sm text-muted-foreground">Browse registered databases, schemas, tables and columns</p>
            </div>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Left: Sources */}
          <div className="w-56 flex-shrink-0 border-r border-border bg-card overflow-y-auto">
            <div className="p-3">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">Data Sources</p>
              {sourcesLoading ? (
                <div className="space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-10 w-full" />)}</div>
              ) : sources.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-4">No sources available</p>
              ) : (
                sources.map((src: any) => (
                  <button
                    key={src.id}
                    onClick={() => { setSelectedSource(src.id); setSelectedSchema(null); setSelectedTable(null); }}
                    className={cn(
                      "w-full flex items-center gap-2 p-2 rounded-md text-left transition-colors mb-0.5",
                      selectedSource === src.id ? "bg-primary/10 text-primary" : "hover:bg-accent text-foreground"
                    )}
                  >
                    <Database className="w-4 h-4 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">{src.name}</p>
                      <p className="text-[10px] text-muted-foreground capitalize">{src.dialect}</p>
                    </div>
                    <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${src.isActive ? "bg-green-500" : "bg-gray-400"}`} />
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Middle: Schemas & Tables */}
          <div className="w-64 flex-shrink-0 border-r border-border overflow-y-auto">
            {!selectedSource ? (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <div className="text-center p-6">
                  <Database className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">Select a data source</p>
                </div>
              </div>
            ) : (
              <div className="p-3">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Schemas & Tables</p>
                  {user?.role === "admin" && (
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => {
                      if (selectedSchema) refreshMeta.mutate({ sourceId: selectedSource!, schemaName: selectedSchema });
                      else toast.info("Select a schema to refresh");
                    }}>
                      <RefreshCw className={cn("w-3 h-3", refreshMeta.isPending && "animate-spin")} />
                    </Button>
                  )}
                </div>
                {schemasLoading ? (
                  <div className="space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-8 w-full" />)}</div>
                ) : schemas.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">No schemas registered</p>
                ) : (
                  schemas.map((schema: any) => {
                    const isExpanded = expandedSchemas.has(schema.schemaName);
                    return (
                      <div key={schema.id}>
                        <button
                          onClick={() => {
                            setSelectedSchema(schema.schemaName);
                            setSelectedTable(null);
                            setExpandedSchemas(prev => {
                              const next = new Set(prev);
                              if (next.has(schema.schemaName)) next.delete(schema.schemaName);
                              else next.add(schema.schemaName);
                              return next;
                            });
                          }}
                          className={cn(
                            "w-full flex items-center gap-1.5 p-2 rounded-md text-left transition-colors mb-0.5",
                            selectedSchema === schema.schemaName ? "bg-primary/10 text-primary" : "hover:bg-accent text-foreground"
                          )}
                        >
                          {isExpanded ? <ChevronDown className="w-3 h-3 flex-shrink-0" /> : <ChevronRight className="w-3 h-3 flex-shrink-0" />}
                          <span className="text-xs font-medium truncate">{schema.schemaName}</span>
                        </button>
                        {isExpanded && selectedSchema === schema.schemaName && (
                          <div className="ml-4 space-y-0.5">
                            {tablesLoading ? (
                              <div className="space-y-1">{[1,2,3].map(i => <Skeleton key={i} className="h-6 w-full" />)}</div>
                            ) : (
                              filteredTables.map((table: any) => (
                                <button
                                  key={table.tableName}
                                  onClick={() => setSelectedTable(table.tableName)}
                                  className={cn(
                                    "w-full flex items-center gap-1.5 p-1.5 rounded text-left transition-colors",
                                    selectedTable === table.tableName ? "bg-primary/10 text-primary" : "hover:bg-accent text-foreground"
                                  )}
                                >
                                  <Table2 className="w-3 h-3 flex-shrink-0" />
                                  <span className="text-xs truncate">{table.tableName}</span>
                                </button>
                              ))
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>

          {/* Right: Columns */}
          <div className="flex-1 overflow-y-auto p-4">
            {!selectedTable ? (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <div className="text-center">
                  <Columns className="w-12 h-12 mx-auto mb-3 opacity-20" />
                  <p className="text-sm font-medium">Select a table to view columns</p>
                  <p className="text-xs mt-1">Choose a data source → schema → table</p>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-base font-semibold text-foreground">
                      {selectedSchema}.{selectedTable}
                    </h2>
                    <p className="text-xs text-muted-foreground">{currentSource?.name} · {columns.length} columns</p>
                  </div>
                  <div className="relative">
                    <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                    <Input
                      className="pl-7 h-7 text-xs w-48"
                      placeholder="Search columns..."
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                    />
                  </div>
                </div>
                {columnsLoading ? (
                  <div className="space-y-2">{[1,2,3,4,5].map(i => <Skeleton key={i} className="h-12 w-full" />)}</div>
                ) : (
                  <div className="border border-border rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/50">
                        <tr>
                          <th className="text-left px-3 py-2 text-xs font-semibold text-muted-foreground">Column Name</th>
                          <th className="text-left px-3 py-2 text-xs font-semibold text-muted-foreground">Data Type</th>
                          <th className="text-left px-3 py-2 text-xs font-semibold text-muted-foreground">Attributes</th>
                          <th className="text-left px-3 py-2 text-xs font-semibold text-muted-foreground">Description</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {columns
                          .filter((c: any) => !search || c.columnName.toLowerCase().includes(search.toLowerCase()))
                          .map((col: any) => (
                          <tr key={col.columnName} className="hover:bg-accent/30 transition-colors">
                            <td className="px-3 py-2">
                              <div className="flex items-center gap-1.5">
                                {col.isKey && <Key className="w-3 h-3 text-amber-500 flex-shrink-0" />}
                                <span className="font-mono text-xs font-medium">{col.columnName}</span>
                              </div>
                            </td>
                            <td className="px-3 py-2">
                              <Badge variant="outline" className="font-mono text-[10px]">{col.dataType}</Badge>
                            </td>
                            <td className="px-3 py-2">
                              <div className="flex gap-1">
                                {col.isKey && <Badge className="text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border-0">PK</Badge>}
                                {col.isIndexed && !col.isKey && <Badge className="text-[10px] bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border-0">IDX</Badge>}
                                {col.isNullable && <Badge variant="outline" className="text-[10px]">NULL</Badge>}
                              </div>
                            </td>
                            <td className="px-3 py-2 text-xs text-muted-foreground max-w-xs">
                              {col.description ? (
                                <span className="flex items-start gap-1">
                                  <Info className="w-3 h-3 mt-0.5 flex-shrink-0 text-primary" />
                                  {col.description}
                                </span>
                              ) : (
                                <span className="text-muted-foreground/50 italic">—</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
