import { useState, useEffect } from "react";
import AppLayout from "@/components/AppLayout";
import WizardSteps from "@/components/WizardSteps";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { ArrowRight, ArrowLeft, ChevronRight, Filter, Plus, Trash2, Info, Table2 } from "lucide-react";
import { Link, useLocation, useParams } from "wouter";
import { toast } from "sonner";
import { WIZARD_STEPS } from "./wizardConfig";

type FilterRow = { id: string; tableName: string; column: string; operator: string; value: string };

const OPERATORS = [
  { value: "eq", label: "= equals" }, { value: "neq", label: "≠ not equals" },
  { value: "gt", label: "> greater than" }, { value: "gte", label: "≥ greater or equal" },
  { value: "lt", label: "< less than" }, { value: "lte", label: "≤ less or equal" },
  { value: "like", label: "LIKE contains" }, { value: "in", label: "IN list (comma-sep)" },
  { value: "between", label: "BETWEEN range (a,b)" },
  { value: "is_null", label: "IS NULL" }, { value: "is_not_null", label: "IS NOT NULL" },
];

const FILTER_PRESETS: Record<string, Array<{ label: string; column: string; operator: string; value: string }>> = {
  LOT_HISTORY:       [
    { label: "Active lots",      column: "STATUS",          operator: "eq",   value: "ACTIVE" },
    { label: "Production type",  column: "LOT_TYPE",        operator: "eq",   value: "PRODUCTION" },
    { label: "HOT/URGENT",       column: "PRIORITY",        operator: "in",   value: "HOT,URGENT" },
    { label: "5NM node",         column: "TECHNOLOGY_NODE", operator: "eq",   value: "5NM" },
    { label: "No holds",         column: "HOLD_COUNT",      operator: "eq",   value: "0" },
  ],
  WAT_DATA:          [
    { label: "Failed tests",     column: "PASS_FAIL",       operator: "eq",   value: "FAIL" },
    { label: "Passed tests",     column: "PASS_FAIL",       operator: "eq",   value: "PASS" },
    { label: "5NM node",         column: "TECHNOLOGY_NODE", operator: "eq",   value: "5NM" },
    { label: "Center site",      column: "TEST_SITE",       operator: "eq",   value: "CENTER" },
  ],
  CP_DATA:           [
    { label: "Low yield <90%",   column: "YIELD_PCT",       operator: "lt",   value: "90" },
    { label: "High yield >95%",  column: "YIELD_PCT",       operator: "gt",   value: "95" },
  ],
  FDC_DATA:          [
    { label: "Alarm events",     column: "ALARM_FLAG",      operator: "eq",   value: "Y" },
    { label: "Critical alarms",  column: "ALARM_CLASS",     operator: "eq",   value: "CRITICAL" },
    { label: "ETCH step",        column: "PROCESS_STEP",    operator: "like", value: "ETCH%" },
  ],
  INLINE_THICKNESS:  [
    { label: "Failed meas.",     column: "PASS_FAIL",       operator: "eq",   value: "FAIL" },
    { label: "OXIDE film",       column: "FILM_LAYER",      operator: "eq",   value: "OXIDE" },
    { label: "Uniformity >5%",   column: "UNIFORMITY_PCT",  operator: "gt",   value: "5" },
  ],
  CD_MEASUREMENT:    [
    { label: "Failed CD",        column: "PASS_FAIL",       operator: "eq",   value: "FAIL" },
    { label: "GATE layer",       column: "CD_LAYER",        operator: "eq",   value: "GATE" },
  ],
  DEFECT_INSPECTION: [
    { label: "Failed insp.",     column: "PASS_FAIL",       operator: "eq",   value: "FAIL" },
    { label: "SEM review",       column: "REVIEW_FLAG",     operator: "eq",   value: "Y" },
  ],
  EQUIPMENT_TOOL:    [
    { label: "Equipment UP",     column: "CURRENT_STATUS",  operator: "eq",   value: "UP" },
    { label: "PHOTO area",       column: "FAB_AREA",        operator: "eq",   value: "PHOTO" },
    { label: "OEE > 85%",        column: "OEE_RATE",        operator: "gt",   value: "0.85" },
  ],
  EQUIPMENT_PM:      [
    { label: "Completed PM",     column: "PM_STATUS",       operator: "eq",   value: "COMPLETED" },
    { label: "Failed qual.",     column: "QUAL_RESULT",     operator: "eq",   value: "FAIL" },
  ],
};

export default function DatasetCriteria() {
  const { id } = useParams<{ id: string }>();
  const draftId = parseInt(id);
  const [, navigate] = useLocation();

  const { data: draft, refetch } = trpc.datasets.getById.useQuery({ id: draftId });
  const { data: fabTables = [] } = trpc.fabData.listTables.useQuery();

  const [filters, setFilters] = useState<FilterRow[]>([]);
  const [rowLimit, setRowLimit] = useState<number>(10000);
  const [timeoutSec, setTimeoutSec] = useState<number>(60);

  const def = (draft?.definitionJson || {}) as any;
  const fabSelections: Array<{ tableName: string; columns: string[] }> = def.fabSelections ?? [];

  useEffect(() => {
    if (def.fabFilters) setFilters(def.fabFilters);
    if (def.rowLimit) setRowLimit(def.rowLimit);
    if (def.timeoutSec) setTimeoutSec(def.timeoutSec);
  }, [draft]);

  const patchMutation = trpc.datasets.patch.useMutation({
    onSuccess: () => { toast.success("Criteria saved"); refetch(); navigate(`/datasets/${draftId}/review`); },
    onError: (e) => toast.error(e.message),
  });

  const addFilter = (tableName: string) => {
    const tableMeta = fabTables.find(t => t.tableName === tableName);
    const firstCol = tableMeta?.columns[0]?.columnName ?? "";
    setFilters(prev => [...prev, { id: crypto.randomUUID(), tableName, column: firstCol, operator: "eq", value: "" }]);
  };

  const applyPreset = (tableName: string, preset: { column: string; operator: string; value: string }) => {
    setFilters(prev => [...prev, { id: crypto.randomUUID(), tableName, column: preset.column, operator: preset.operator, value: preset.value }]);
    toast.success("Filter preset applied");
  };

  const removeFilter = (id: string) => setFilters(prev => prev.filter(f => f.id !== id));
  const updateFilter = (id: string, field: keyof FilterRow, value: string) =>
    setFilters(prev => prev.map(f => f.id === id ? { ...f, [field]: value } : f));

  const handleSave = () => {
    patchMutation.mutate({
      id: draftId, status: "criteria_set",
      definitionJson: { ...def, fabFilters: filters, rowLimit, timeoutSec },
    });
  };

  const completedSteps = draft ? getCompletedSteps(draft.status as string) : [];

  return (
    <AppLayout>
      <div className="p-6 max-w-5xl mx-auto">
        <div className="mb-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
            <Link href="/datasets"><span className="hover:text-foreground cursor-pointer">Datasets</span></Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground font-medium">{draft?.name}</span>
          </div>
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold">Set Filter Criteria</h1>
            <div className="flex gap-2">
              <Link href={`/datasets/${draftId}/requirement`}><Button variant="outline" size="sm" className="gap-1"><ArrowLeft className="w-3 h-3" /> Back</Button></Link>
              <Button onClick={handleSave} disabled={patchMutation.isPending} className="gap-2">
                Save & Continue <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
        <div className="mb-5 overflow-x-auto">
          <WizardSteps steps={WIZARD_STEPS} currentStep="criteria" completedSteps={completedSteps} />
        </div>

        {fabSelections.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-12 text-center">
              <Table2 className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-sm font-medium text-muted-foreground">No tables selected yet</p>
              <Link href={`/datasets/${draftId}/columns`}><Button variant="outline" size="sm" className="mt-3">← Back to Column Selection</Button></Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-3 gap-4">
            <div className="col-span-2 space-y-4">
              {fabSelections.map(sel => {
                const tableMeta = fabTables.find(t => t.tableName === sel.tableName);
                const tableFilters = filters.filter(f => f.tableName === sel.tableName);
                const presets = FILTER_PRESETS[sel.tableName] ?? [];
                return (
                  <Card key={sel.tableName}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm flex items-center gap-2">
                          <Table2 className="h-4 w-4 text-primary" />
                          {sel.tableName}
                          <Badge variant="secondary" className="text-xs">{sel.columns.length} cols</Badge>
                        </CardTitle>
                        <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => addFilter(sel.tableName)}>
                          <Plus className="h-3 w-3" />Add Filter
                        </Button>
                      </div>
                      {tableMeta?.comment && <CardDescription className="text-xs">{tableMeta.comment}</CardDescription>}
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {presets.length > 0 && (
                        <div>
                          <p className="text-[10px] text-muted-foreground mb-1.5 font-medium uppercase tracking-wider">Quick Presets</p>
                          <div className="flex flex-wrap gap-1.5">
                            {presets.map(preset => (
                              <button key={preset.label} onClick={() => applyPreset(sel.tableName, preset)}
                                className="text-[10px] px-2 py-1 bg-blue-50 border border-blue-200 text-blue-700 rounded-full hover:bg-blue-100 transition-colors">
                                + {preset.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                      {tableFilters.length === 0 ? (
                        <p className="text-xs text-muted-foreground italic py-2">No filters — returns all rows from this table</p>
                      ) : (
                        <div className="space-y-2">
                          {tableFilters.map(f => (
                            <div key={f.id} className="flex items-center gap-2 p-2 bg-muted/30 rounded-lg">
                              <Select value={f.column} onValueChange={v => updateFilter(f.id, "column", v)}>
                                <SelectTrigger className="h-7 text-xs w-44"><SelectValue placeholder="Column" /></SelectTrigger>
                                <SelectContent>
                                  {tableMeta?.columns.map(c => (
                                    <SelectItem key={c.columnName} value={c.columnName} className="text-xs font-mono">{c.columnName}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <Select value={f.operator} onValueChange={v => updateFilter(f.id, "operator", v)}>
                                <SelectTrigger className="h-7 text-xs w-36"><SelectValue placeholder="Operator" /></SelectTrigger>
                                <SelectContent>
                                  {OPERATORS.map(op => <SelectItem key={op.value} value={op.value} className="text-xs">{op.label}</SelectItem>)}
                                </SelectContent>
                              </Select>
                              {!["is_null", "is_not_null"].includes(f.operator) && (
                                <Input value={f.value} onChange={e => updateFilter(f.id, "value", e.target.value)}
                                  placeholder={f.operator === "between" ? "val1, val2" : f.operator === "in" ? "v1, v2, v3" : "value..."}
                                  className="h-7 text-xs flex-1" />
                              )}
                              <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive" onClick={() => removeFilter(f.id)}>
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2"><Info className="h-4 w-4 text-blue-500" />Safety Constraints</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <label className="text-xs font-medium mb-1 block">Max Rows Returned</label>
                    <Select value={String(rowLimit)} onValueChange={v => setRowLimit(Number(v))}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {[["100","100 rows (test)"],["1000","1,000 rows"],["5000","5,000 rows"],["10000","10,000 rows"]].map(([v,l]) => (
                          <SelectItem key={v} value={v} className="text-xs">{l}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs font-medium mb-1 block">Query Timeout (seconds)</label>
                    <Select value={String(timeoutSec)} onValueChange={v => setTimeoutSec(Number(v))}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {[["30","30 seconds"],["60","60 seconds"],["120","120 seconds"],["300","300 seconds"]].map(([v,l]) => (
                          <SelectItem key={v} value={v} className="text-xs">{l}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm">Filter Summary</CardTitle></CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    {fabSelections.map(sel => {
                      const cnt = filters.filter(f => f.tableName === sel.tableName).length;
                      return (
                        <div key={sel.tableName} className="flex items-center justify-between text-xs">
                          <span className="font-mono text-muted-foreground truncate">{sel.tableName}</span>
                          <Badge variant={cnt > 0 ? "default" : "outline"} className="text-[10px] h-4 px-1">
                            {cnt > 0 ? `${cnt} filter${cnt > 1 ? "s" : ""}` : "no filter"}
                          </Badge>
                        </div>
                      );
                    })}
                  </div>
                  <Separator className="my-2" />
                  <div className="text-xs text-muted-foreground space-y-0.5">
                    <p>Total filters: <strong>{filters.length}</strong></p>
                    <p>Row limit: <strong>{rowLimit.toLocaleString()}</strong></p>
                    <p>Timeout: <strong>{timeoutSec}s</strong></p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

function getCompletedSteps(status: string): string[] {
  const order = ["columns", "requirement", "criteria", "review", "preview", "execute"];
  const statusMap: Record<string, string> = {
    draft: "", columns_selected: "columns", requirements_set: "requirement",
    criteria_set: "criteria", sql_generated: "review", preview_approved: "preview", completed: "execute",
  };
  const current = statusMap[status] ?? "";
  const idx = order.indexOf(current);
  return order.slice(0, idx);
}
