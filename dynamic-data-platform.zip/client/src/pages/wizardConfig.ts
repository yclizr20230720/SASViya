import type { WizardStep } from "@/components/WizardSteps";

export const WIZARD_STEPS: WizardStep[] = [
  { id: "columns", label: "Columns" },
  { id: "requirement", label: "Requirements" },
  { id: "criteria", label: "Criteria" },
  { id: "review", label: "SQL Review" },
  { id: "preview", label: "Preview" },
  { id: "execute", label: "Execute" },
];

export function getCompletedSteps(status: string): string[] {
  const order = ["columns", "requirement", "criteria", "review", "preview", "execute"];
  const statusMap: Record<string, string> = {
    draft: "",
    columns_selected: "columns",
    requirements_set: "requirement",
    criteria_set: "criteria",
    sql_generated: "review",
    preview_approved: "preview",
    completed: "execute",
  };
  const current = statusMap[status] ?? "";
  const idx = order.indexOf(current);
  return order.slice(0, idx);
}
