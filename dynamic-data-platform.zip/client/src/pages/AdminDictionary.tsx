import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Upload, Plus, BookOpen, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function AdminDictionary() {
  const [selectedSourceId, setSelectedSourceId] = useState<number | null>(null);
  const [selectedSchema, setSelectedSchema] = useState("");
  const [manualEntry, setManualEntry] = useState({ tableName: "", columnName: "", description: "" });
  const [importText, setImportText] = useState("");
  const [importPreview, setImportPreview] = useState<any[]>([]);

  const { data: sources = [] } = trpc.sources.list.useQuery();
  const { data: schemas = [] } = trpc.sources.listSchemas.useQuery({ sourceId: selectedSourceId! }, { enabled: !!selectedSourceId });
  const { data: entries = [], refetch } = trpc.dictionary.list.useQuery(
    { sourceId: selectedSourceId!, schemaName: selectedSchema },
    { enabled: !!selectedSourceId && !!selectedSchema }
  );

  const upsertMutation = trpc.dictionary.upsert.useMutation({
    onSuccess: () => { toast.success("Entry saved"); refetch(); setManualEntry({ tableName: "", columnName: "", description: "" }); },
    onError: (e) => toast.error(e.message),
  });

  const bulkMutation = trpc.dictionary.bulkImport.useMutation({
    onSuccess: (r) => { toast.success(`Imported ${r.imported} entries`); refetch(); setImportPreview([]); setImportText(""); },
    onError: (e) => toast.error(e.message),
  });

  const parseImport = () => {
    try {
      const lines = importText.trim().split("\n").filter(Boolean);
      const parsed = lines.map(line => {
        const parts = line.split("\t");
        return { sourceId: selectedSourceId!, schemaName: selectedSchema, tableName: parts[0]?.trim() ?? "", columnName: parts[1]?.trim() || null, description: parts[2]?.trim() ?? "" };
      }).filter(e => e.tableName && e.description);
      setImportPreview(parsed);
      toast.info(`Parsed ${parsed.length} entries — review and confirm`);
    } catch (e) { toast.error("Failed to parse input"); }
  };

  return (
    <AppLayout>
      <div className="p-6 max-w-5xl mx-auto">
        <div className="mb-6">
          <h1 className="text-xl font-bold">Data Dictionary</h1>
          <p className="text-sm text-muted-foreground">Manage business descriptions for tables and columns</p>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6">
          <Select value={String(selectedSourceId ?? "")} onValueChange={v => { setSelectedSourceId(Number(v)); setSelectedSchema(""); }}>
            <SelectTrigger><SelectValue placeholder="Select data source..." /></SelectTrigger>
            <SelectContent>{(sources as any[]).map((s: any) => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={selectedSchema} onValueChange={setSelectedSchema} disabled={!selectedSourceId}>
            <SelectTrigger><SelectValue placeholder="Select schema..." /></SelectTrigger>
            <SelectContent>{(schemas as any[]).map((s: any) => <SelectItem key={s.id} value={s.schemaName}>{s.schemaName}</SelectItem>)}</SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-6">
          {/* Manual entry */}
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-sm">Add/Update Entry</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1"><Label className="text-xs">Table Name *</Label><Input className="h-8 text-xs" placeholder="WAFER_RUN" value={manualEntry.tableName} onChange={e => setManualEntry(p => ({ ...p, tableName: e.target.value }))} /></div>
              <div className="space-y-1"><Label className="text-xs">Column Name (leave blank for table-level)</Label><Input className="h-8 text-xs" placeholder="WAFER_ID (optional)" value={manualEntry.columnName} onChange={e => setManualEntry(p => ({ ...p, columnName: e.target.value }))} /></div>
              <div className="space-y-1"><Label className="text-xs">Description *</Label><Textarea className="text-xs" rows={3} placeholder="Business description..." value={manualEntry.description} onChange={e => setManualEntry(p => ({ ...p, description: e.target.value }))} /></div>
              <Button size="sm" className="gap-1 w-full" onClick={() => upsertMutation.mutate({ sourceId: selectedSourceId!, schemaName: selectedSchema, ...manualEntry, columnName: manualEntry.columnName || null })} disabled={!selectedSourceId || !selectedSchema || !manualEntry.tableName || !manualEntry.description || upsertMutation.isPending}>
                <Plus className="w-3 h-3" /> Save Entry
              </Button>
            </CardContent>
          </Card>

          {/* Bulk import */}
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-sm">Bulk Import (Tab-separated)</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <p className="text-xs text-muted-foreground">Format: TABLE_NAME [TAB] COLUMN_NAME [TAB] DESCRIPTION (one per line, column optional)</p>
              <Textarea className="text-xs font-mono" rows={6} placeholder={"WAFER_RUN\t\tWafer run tracking table\nWAFER_RUN\tWAFER_ID\tUnique wafer identifier"} value={importText} onChange={e => setImportText(e.target.value)} />
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="gap-1 flex-1" onClick={parseImport} disabled={!importText.trim() || !selectedSourceId || !selectedSchema}>
                  <Upload className="w-3 h-3" /> Parse & Preview
                </Button>
                {importPreview.length > 0 && (
                  <Button size="sm" className="gap-1 flex-1" onClick={() => bulkMutation.mutate({ entries: importPreview })} disabled={bulkMutation.isPending}>
                    <CheckCircle className="w-3 h-3" /> Import {importPreview.length} entries
                  </Button>
                )}
              </div>
              {importPreview.length > 0 && (
                <div className="max-h-32 overflow-y-auto space-y-1">
                  {importPreview.map((e, i) => (
                    <div key={i} className="text-[10px] p-1.5 bg-accent/50 rounded flex gap-2">
                      <span className="font-mono font-medium">{e.tableName}{e.columnName ? `.${e.columnName}` : ""}</span>
                      <span className="text-muted-foreground truncate">{e.description}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Existing entries */}
        {selectedSourceId && selectedSchema && (
          <Card className="mt-6">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <BookOpen className="w-4 h-4" /> Existing Entries
                <Badge variant="outline">{(entries as any[]).length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {(entries as any[]).length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">No dictionary entries yet</p>
              ) : (
                <div className="border border-border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left px-3 py-2 font-semibold text-muted-foreground">Table</th>
                        <th className="text-left px-3 py-2 font-semibold text-muted-foreground">Column</th>
                        <th className="text-left px-3 py-2 font-semibold text-muted-foreground">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {(entries as any[]).map((e: any) => (
                        <tr key={e.id} className="hover:bg-accent/30">
                          <td className="px-3 py-2 font-mono font-medium">{e.tableName}</td>
                          <td className="px-3 py-2 font-mono text-muted-foreground">{e.columnName ?? <span className="italic text-muted-foreground/50">table-level</span>}</td>
                          <td className="px-3 py-2 text-muted-foreground">{e.description}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}
