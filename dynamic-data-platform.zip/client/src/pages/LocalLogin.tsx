import { trpc } from "@/lib/trpc";
import { Database, Eye, EyeOff, LockKeyhole, ShieldCheck, UserRound } from "lucide-react";
import { FormEvent, useState } from "react";

type Mode = "signin" | "register";

export default function LocalLogin() {
  const utils = trpc.useUtils();
  const [mode, setMode] = useState<Mode>("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const refreshSession = async () => {
    await utils.auth.me.invalidate();
  };

  const login = trpc.auth.login.useMutation({ onSuccess: refreshSession });
  const register = trpc.auth.register.useMutation({
    onSuccess: async result => {
      setNotice(result.firstLocalAdmin ? "Your account is the first local DDOP account and has been assigned the Administrator role." : "Account created. You are now signed in.");
      await refreshSession();
    },
  });

  const pending = login.isPending || register.isPending;

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setNotice(null);
    try {
      if (mode === "signin") {
        await login.mutateAsync({ email, password });
      } else {
        await register.mutateAsync({ name, email, password });
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Unable to complete authentication. Please try again.");
    }
  };

  const switchMode = (nextMode: Mode) => {
    setMode(nextMode);
    setError(null);
    setNotice(null);
  };

  return (
    <main className="min-h-screen bg-[#eef3f8] p-5 text-slate-900 lg:p-10">
      <div className="mx-auto grid min-h-[calc(100vh-2.5rem)] max-w-6xl overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-[0_24px_70px_rgba(15,23,42,0.12)] lg:grid-cols-[1.04fr_0.96fr]">
        <section className="relative overflow-hidden bg-[#06162a] p-8 text-white sm:p-12">
          <div className="absolute -left-24 top-12 h-72 w-72 rounded-full bg-blue-500/20 blur-3xl" />
          <div className="absolute -bottom-24 right-0 h-80 w-80 rounded-full bg-cyan-400/10 blur-3xl" />
          <div className="relative flex h-full flex-col">
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-blue-600 shadow-lg shadow-blue-950/40"><Database className="h-6 w-6" /></div>
              <div><p className="text-lg font-bold tracking-tight">DDOP</p><p className="text-xs text-slate-400">Data Object Platform</p></div>
            </div>
            <div className="my-auto py-12">
              <span className="inline-flex items-center gap-2 rounded-full border border-blue-300/20 bg-blue-500/10 px-3 py-1 text-xs font-medium text-blue-200"><ShieldCheck className="h-3.5 w-3.5" /> Local JWT Authorization</span>
              <h1 className="mt-6 max-w-md text-4xl font-bold leading-tight tracking-tight sm:text-5xl">Govern fab data access with confidence.</h1>
              <p className="mt-5 max-w-lg text-base leading-7 text-slate-300">DDOP now uses self-contained, server-issued JWT sessions. No Manus account or external sign-in is required.</p>
              <div className="mt-10 grid gap-3 sm:grid-cols-3">
                {[['JWT session','HTTP-only cookie'],['RBAC','Admin and user roles'],['Audit trail','All query activity logged']].map(([title, detail]) => <div key={title} className="rounded-xl border border-white/10 bg-white/[0.045] p-3"><p className="text-xs font-semibold text-white">{title}</p><p className="mt-1 text-[11px] leading-4 text-slate-400">{detail}</p></div>)}
              </div>
            </div>
            <p className="text-xs text-slate-500">Authorized personnel only. All access is logged and audited.</p>
          </div>
        </section>

        <section className="flex items-center p-6 sm:p-12">
          <div className="mx-auto w-full max-w-md">
            <p className="text-sm font-semibold text-blue-700">SECURE ACCESS</p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight">{mode === "signin" ? "Sign in to DDOP" : "Create a DDOP account"}</h2>
            <p className="mt-2 text-sm leading-6 text-slate-500">{mode === "signin" ? "Use your local DDOP credentials to continue." : "The first local account is automatically assigned the Administrator role."}</p>

            <div className="mt-8 grid grid-cols-2 rounded-xl bg-slate-100 p-1">
              {(["signin", "register"] as Mode[]).map(item => <button key={item} type="button" onClick={() => switchMode(item)} className={`rounded-lg px-3 py-2 text-sm font-semibold transition ${mode === item ? "bg-white text-slate-950 shadow-sm" : "text-slate-500 hover:text-slate-800"}`}>{item === "signin" ? "Sign in" : "Register"}</button>)}
            </div>

            <form className="mt-7 space-y-4" onSubmit={submit}>
              {mode === "register" && <label className="block"><span className="mb-1.5 block text-sm font-medium text-slate-700">Display name</span><div className="relative"><UserRound className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-slate-400" /><input required minLength={2} maxLength={120} value={name} onChange={event => setName(event.target.value)} placeholder="Jane Engineer" className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-10 pr-3 text-sm outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-4 focus:ring-blue-100" /></div></label>}
              <label className="block"><span className="mb-1.5 block text-sm font-medium text-slate-700">Email address</span><input required type="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="name@company.com" autoComplete="email" className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-4 focus:ring-blue-100" /></label>
              <label className="block"><span className="mb-1.5 block text-sm font-medium text-slate-700">Password</span><div className="relative"><LockKeyhole className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-slate-400" /><input required type={showPassword ? "text" : "password"} value={password} onChange={event => setPassword(event.target.value)} placeholder={mode === "register" ? "At least 12 characters, letter and number" : "Your password"} autoComplete={mode === "signin" ? "current-password" : "new-password"} className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-10 pr-11 text-sm outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-4 focus:ring-blue-100" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-700" aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button></div>{mode === "register" && <p className="mt-1.5 text-xs text-slate-500">Use 12–128 characters, with at least one letter and one number.</p>}</label>
              {error && <p role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
              {notice && <p className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{notice}</p>}
              <button disabled={pending} className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:cursor-wait disabled:opacity-70">{pending ? "Please wait…" : mode === "signin" ? "Sign in securely" : "Create account and sign in"}</button>
            </form>
          </div>
        </section>
      </div>
    </main>
  );
}
