import { useState, useEffect } from "react";
import AppLayout from "@/components/AppLayout";
import WizardSteps from "@/components/WizardSteps";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, ArrowLeft, Plus, Trash2, ChevronRight, Upload, CheckCircle } from "lucide-react";
import { Link, useLocation, useParams } from "wouter";
import { toast } from "sonner";
import { WIZARD_STEPS, getCompletedSteps } from "./wizardConfig";
import type { DatasetDefinition, RequirementItem } from "../../../drizzle/schema";
import { nanoid } from "nanoid";

export default function DatasetRequirement() {
  const { id } = useParams<{ id: string }>();
  const draftId = parseInt(id);
  const [, navigate] = useLocation();

  const { data: draft, refetch } = trpc.datasets.getById.useQuery({ id: draftId });
  const [items, setItems] = useState<RequirementItem[]>([]);
  const [newField, setNewField] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newHint, setNewHint] = useState("");

  const patchMutation = trpc.datasets.patch.useMutation({
    onSuccess: () => { toast.success("Requirements saved"); navigate(`/datasets/${draftId}/criteria`); },
    onError: (e) => toast.error(e.message),
  });

  useEffect(() => {
    if (draft?.definitionJson) {
      const def = draft.definitionJson as DatasetDefinition;
      setItems(def.requirementItems || []);
    }
  }, [draft]);

  const addItem = () => {
    if (!newField.trim()) return;
    setItems(prev => [...prev, { id: nanoid(), fieldName: newField, description: newDesc, sourceHint: newHint }]);
    setNewField(""); setNewDesc(""); setNewHint("");
  };

  const removeItem = (id: string) => setItems(prev => prev.filter(i => i.id !== id));

  const handleSave = () => {
    const def = (draft?.definitionJson || {}) as DatasetDefinition;
    patchMutation.mutate({
      id: draftId,
      status: "requirements_set",
      definitionJson: { ...def, requirementItems: items },
    });
  };

  const completedSteps = draft ? getCompletedSteps(draft.status as string) : [];

  return (
    <AppLayout>
      <div className="p-6 max-w-4xl mx-auto">
        <div className="mb-6">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <Link href="/datasets"><span className="hover:text-foreground cursor-pointer">Datasets</span></Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground font-medium">{draft?.name}</span>
          </div>
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold">Describe Requirements</h1>
            <div className="flex gap-2">
              <Link href={`/datasets/${draftId}/columns`}><Button variant="outline" size="sm" className="gap-1"><ArrowLeft className="w-3 h-3" /> Back</Button></Link>
              <Button onClick={handleSave} disabled={patchMutation.isPending} className="gap-2">
                Save & Continue <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="mb-6 overflow-x-auto">
          <WizardSteps steps={WIZARD_STEPS} currentStep="requirement" completedSteps={completedSteps} />
        </div>

        <div className="grid grid-cols-1 gap-4">
          {/* Add item form */}
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-sm">Add Requirement Item</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-3 mb-3">
                <div className="space-y-1">
                  <Label className="text-xs">Field Name *</Label>
                  <Input className="h-8 text-xs" placeholder="e.g. wafer_id" value={newField} onChange={e => setNewField(e.target.value)} onKeyDown={e => e.key === "Enter" && addItem()} />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Description</Label>
                  <Input className="h-8 text-xs" placeholder="What this field represents" value={newDesc} onChange={e => setNewDesc(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Source Hint</Label>
                  <Input className="h-8 text-xs" placeholder="e.g. WAFER_RUN table" value={newHint} onChange={e => setNewHint(e.target.value)} />
                </div>
              </div>
              <Button size="sm" className="gap-1" onClick={addItem} disabled={!newField.trim()}>
                <Plus className="w-3 h-3" /> Add Item
              </Button>
            </CardContent>
          </Card>

          {/* Items list */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center justify-between">
                Requirement Items
                <Badge variant="outline">{items.length} items</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {items.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Upload className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No requirements added yet</p>
                  <p className="text-xs mt-1">Add items above, or skip this step if you've already selected columns</p>
                </div>
              ) : (
                <div className="border border-border rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left px-3 py-2 text-xs font-semibold text-muted-foreground">Field Name</th>
                        <th className="text-left px-3 py-2 text-xs font-semibold text-muted-foreground">Description</th>
                        <th className="text-left px-3 py-2 text-xs font-semibold text-muted-foreground">Source Hint</th>
                        <th className="text-left px-3 py-2 text-xs font-semibold text-muted-foreground">Match</th>
                        <th className="w-8" />
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {items.map(item => (
                        <tr key={item.id} className="hover:bg-accent/30">
                          <td className="px-3 py-2 font-mono text-xs font-medium">{item.fieldName}</td>
                          <td className="px-3 py-2 text-xs text-muted-foreground">{item.description || "—"}</td>
                          <td className="px-3 py-2 text-xs text-muted-foreground">{item.sourceHint || "—"}</td>
                          <td className="px-3 py-2">
                            {item.matchedColumn ? (
                              <Badge className="text-[10px] bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300 border-0">
                                <CheckCircle className="w-2.5 h-2.5 mr-1" />
                                {item.matchedColumn.tableName}.{item.matchedColumn.columnName}
                              </Badge>
                            ) : (
                              <span className="text-[10px] text-muted-foreground">Unmatched</span>
                            )}
                          </td>
                          <td className="px-3 py-2">
                            <button onClick={() => removeItem(item.id)} className="text-destructive hover:text-destructive/80">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
