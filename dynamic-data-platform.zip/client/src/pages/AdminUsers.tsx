import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Shield, Plus, ChevronDown, ChevronRight } from "lucide-react";
import { toast } from "sonner";

// ─── Sub-component to safely use hooks per user ────────────────────────────────
function UserRow({ user, sources }: { user: any; sources: any[] }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [newPerm, setNewPerm] = useState({ sourceId: 0, schemaName: "", canBrowse: true, canExecute: false });

  const { data: perms = [], refetch: refetchPerms } = trpc.permissions.getUserPermissions.useQuery(
    { userId: user.id },
    { enabled: isExpanded }
  );

  const updateRoleMutation = trpc.permissions.updateRole.useMutation({
    onSuccess: () => toast.success("Role updated"),
    onError: (e) => toast.error(e.message),
  });

  const upsertPermMutation = trpc.permissions.upsert.useMutation({
    onSuccess: () => { toast.success("Permission saved"); refetchPerms(); },
    onError: (e) => toast.error(e.message),
  });

  const deletePermMutation = trpc.permissions.delete.useMutation({
    onSuccess: () => { toast.success("Permission removed"); refetchPerms(); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <button onClick={() => setIsExpanded(!isExpanded)} className="flex items-center gap-3 flex-1 text-left">
            {isExpanded ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
            <Avatar className="w-8 h-8">
              <AvatarFallback className="text-xs bg-primary text-primary-foreground">{user.name?.charAt(0)?.toUpperCase() ?? "U"}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-sm">{user.name ?? "Unknown"}</p>
              <p className="text-xs text-muted-foreground">{user.email ?? user.openId}</p>
            </div>
          </button>
          <Badge className={user.role === "admin" ? "bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300 border-0" : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400 border-0"}>
            {user.role === "admin" ? <><Shield className="w-3 h-3 mr-1" />Admin</> : "User"}
          </Badge>
          <Select value={user.role} onValueChange={v => updateRoleMutation.mutate({ userId: user.id, role: v as any })}>
            <SelectTrigger className="h-7 w-24 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="user">User</SelectItem>
              <SelectItem value="admin">Admin</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {isExpanded && (
          <div className="mt-4 pt-4 border-t border-border">
            <p className="text-xs font-semibold mb-3">Source Permissions</p>
            <div className="space-y-2 mb-3">
              {(perms as any[]).length === 0 ? (
                <p className="text-xs text-muted-foreground">No permissions assigned</p>
              ) : (
                (perms as any[]).map((perm: any) => {
                  const src = sources.find((s: any) => s.id === perm.sourceId);
                  return (
                    <div key={perm.id} className="flex items-center gap-2 p-2 bg-accent/50 rounded-md text-xs">
                      <span className="font-medium">{src?.name ?? `Source ${perm.sourceId}`}</span>
                      {perm.schemaName && <Badge variant="outline" className="text-[10px]">{perm.schemaName}</Badge>}
                      <Badge className={`text-[10px] ${perm.canBrowse ? "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300" : "bg-gray-100 text-gray-500"} border-0`}>Browse: {perm.canBrowse ? "✓" : "✗"}</Badge>
                      <Badge className={`text-[10px] ${perm.canExecute ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300" : "bg-gray-100 text-gray-500"} border-0`}>Execute: {perm.canExecute ? "✓" : "✗"}</Badge>
                      <button onClick={() => deletePermMutation.mutate({ id: perm.id })} className="ml-auto text-destructive text-xs">Remove</button>
                    </div>
                  );
                })
              )}
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Select value={String(newPerm.sourceId)} onValueChange={v => setNewPerm(p => ({ ...p, sourceId: Number(v) }))}>
                <SelectTrigger className="h-7 text-xs w-32"><SelectValue placeholder="Source..." /></SelectTrigger>
                <SelectContent>{sources.map((s: any) => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
              <div className="flex items-center gap-1">
                <Switch checked={newPerm.canBrowse} onCheckedChange={v => setNewPerm(p => ({ ...p, canBrowse: v }))} className="scale-75" />
                <Label className="text-xs">Browse</Label>
              </div>
              <div className="flex items-center gap-1">
                <Switch checked={newPerm.canExecute} onCheckedChange={v => setNewPerm(p => ({ ...p, canExecute: v }))} className="scale-75" />
                <Label className="text-xs">Execute</Label>
              </div>
              <Button size="sm" className="h-7 text-xs gap-1"
                onClick={() => upsertPermMutation.mutate({ userId: user.id, ...newPerm, schemaName: newPerm.schemaName || null })}
                disabled={!newPerm.sourceId || upsertPermMutation.isPending}>
                <Plus className="w-3 h-3" /> Add Permission
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function AdminUsers() {
  const { data: users = [] } = trpc.permissions.listUsers.useQuery();
  const { data: sources = [] } = trpc.sources.list.useQuery();

  return (
    <AppLayout>
      <div className="p-6 max-w-5xl mx-auto">
        <div className="mb-6">
          <h1 className="text-xl font-bold">Users & Permissions</h1>
          <p className="text-sm text-muted-foreground">Manage user roles and data source access permissions</p>
        </div>
        <div className="space-y-3">
          {(users as any[]).length === 0 ? (
            <Card><CardContent className="py-12 text-center text-muted-foreground"><p className="text-sm">No users registered yet</p></CardContent></Card>
          ) : (
            (users as any[]).map((user: any) => (
              <UserRow key={user.id} user={user} sources={sources as any[]} />
            ))
          )}
        </div>
      </div>
    </AppLayout>
  );
}

