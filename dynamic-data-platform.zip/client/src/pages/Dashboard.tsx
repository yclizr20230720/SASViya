import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Database, Table2, FileText, Activity, ArrowRight, Clock, CheckCircle, AlertTriangle } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: sources = [] } = trpc.sources.list.useQuery();
  const { data: drafts = [] } = trpc.datasets.list.useQuery();
  const { data: auditLogs = [] } = trpc.datasets.auditLog.useQuery({ limit: 5 });

  const totalSchemas = sources.length;
  const activeDrafts = drafts.filter((d: any) => !["completed", "failed"].includes(d.status)).length;
  const completedDatasets = drafts.filter((d: any) => d.status === "completed").length;

  return (
    <AppLayout>
      <div className="p-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">
            Welcome back, {user?.name?.split(" ")[0] ?? "User"}
          </h1>
          <p className="text-muted-foreground mt-1">
            Dynamic Data Object Platform — Enterprise Data Query System
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard icon={Database} label="Data Sources" value={sources.length} color="blue" />
          <StatCard icon={Table2} label="Active Drafts" value={activeDrafts} color="amber" />
          <StatCard icon={CheckCircle} label="Completed Datasets" value={completedDatasets} color="green" />
          <StatCard icon={Activity} label="Recent Queries" value={auditLogs.length} color="purple" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Quick Actions */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <QuickAction href="/datasets" icon={Table2} label="New Dataset" desc="Start building a dataset" />
                <QuickAction href="/sources" icon={Database} label="Browse Sources" desc="Explore schema & tables" />
                {user?.role === "admin" && (
                  <>
                    <QuickAction href="/admin/sources" icon={Database} label="Manage Sources" desc="Configure data sources" />
                    <QuickAction href="/admin/dictionary" icon={FileText} label="Import Dictionary" desc="Upload data descriptions" />
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Data Sources */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold flex items-center justify-between">
                  Registered Data Sources
                  <Link href="/sources"><span className="text-xs text-primary hover:underline cursor-pointer">View all</span></Link>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {sources.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-4 text-center">No sources registered</p>
                ) : (
                  sources.slice(0, 5).map((src: any) => (
                    <div key={src.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-accent/50 transition-colors">
                      <div className={`w-2 h-2 rounded-full flex-shrink-0 ${src.isActive ? "bg-green-500" : "bg-gray-400"}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{src.name}</p>
                        <p className="text-xs text-muted-foreground truncate capitalize">{src.dialect} · {src.host}</p>
                      </div>
                      <Badge variant="outline" className="text-[10px] capitalize">{src.dialect}</Badge>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {auditLogs.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-4 text-center">No recent activity</p>
                ) : (
                  auditLogs.slice(0, 5).map((log: any) => (
                    <div key={log.id} className="flex items-start gap-2 p-2 rounded-md">
                      <div className={`mt-0.5 w-2 h-2 rounded-full flex-shrink-0 ${
                        log.evaluationVerdict === "block" ? "bg-destructive" :
                        log.evaluationVerdict === "warn" ? "bg-amber-500" : "bg-green-500"
                      }`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium capitalize">{log.action?.replace(/_/g, " ")}</p>
                        <p className="text-[10px] text-muted-foreground">
                          {new Date(log.executedAt).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* My Datasets */}
        {drafts.length > 0 && (
          <div className="mt-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold flex items-center justify-between">
                  My Recent Datasets
                  <Link href="/datasets"><span className="text-xs text-primary hover:underline cursor-pointer">View all</span></Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="divide-y divide-border">
                  {drafts.slice(0, 5).map((draft: any) => (
                    <div key={draft.id} className="flex items-center gap-3 py-2.5">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{draft.name}</p>
                        <p className="text-xs text-muted-foreground">{new Date(draft.updatedAt).toLocaleDateString()}</p>
                      </div>
                      <StatusBadge status={draft.status} />
                      <Link href={`/datasets/${draft.id}/columns`}>
                        <Button variant="ghost" size="sm" className="h-7 text-xs">Continue <ArrowRight className="w-3 h-3 ml-1" /></Button>
                      </Link>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: React.ElementType; label: string; value: number; color: string }) {
  const colors: Record<string, string> = {
    blue: "bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400",
    amber: "bg-amber-50 text-amber-600 dark:bg-amber-950 dark:text-amber-400",
    green: "bg-green-50 text-green-600 dark:bg-green-950 dark:text-green-400",
    purple: "bg-purple-50 text-purple-600 dark:bg-purple-950 dark:text-purple-400",
  };
  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${colors[color]}`}>
          <Icon className="w-5 h-5" />
        </div>
        <div>
          <p className="text-2xl font-bold text-foreground">{value}</p>
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function QuickAction({ href, icon: Icon, label, desc }: { href: string; icon: React.ElementType; label: string; desc: string }) {
  return (
    <Link href={href}>
      <div className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-accent transition-colors cursor-pointer group">
        <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
          <Icon className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground">{label}</p>
          <p className="text-xs text-muted-foreground">{desc}</p>
        </div>
        <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
    </Link>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    draft: { label: "Draft", variant: "secondary" },
    columns_selected: { label: "Columns Set", variant: "outline" },
    requirements_set: { label: "Requirements Set", variant: "outline" },
    criteria_set: { label: "Criteria Set", variant: "outline" },
    sql_generated: { label: "SQL Ready", variant: "default" },
    preview_approved: { label: "Preview OK", variant: "default" },
    executing: { label: "Running", variant: "default" },
    completed: { label: "Completed", variant: "default" },
    failed: { label: "Failed", variant: "destructive" },
  };
  const s = map[status] ?? { label: status, variant: "secondary" as const };
  return <Badge variant={s.variant} className="text-[10px]">{s.label}</Badge>;
}
