import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, AlertTriangle, XCircle } from "lucide-react";

export default function AdminAudit() {
  const [sourceFilter, setSourceFilter] = useState<number | undefined>(undefined);
  const [limit, setLimit] = useState(50);

  const { data: logs = [] } = trpc.datasets.auditLog.useQuery({ sourceId: sourceFilter, limit });
  const { data: sources = [] } = trpc.sources.list.useQuery();

  return (
    <AppLayout>
      <div className="p-6 max-w-6xl mx-auto">
        <div className="mb-6">
          <h1 className="text-xl font-bold">Audit Log</h1>
          <p className="text-sm text-muted-foreground">All query evaluations and executions for compliance review</p>
        </div>

        <div className="flex gap-3 mb-4">
          <Select
            value={sourceFilter ? String(sourceFilter) : "all"}
            onValueChange={v => setSourceFilter(v === "all" ? undefined : Number(v))}
          >
            <SelectTrigger className="w-48"><SelectValue placeholder="All sources" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sources</SelectItem>
              {(sources as any[]).map((s: any) => (
                <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={String(limit)} onValueChange={v => setLimit(Number(v))}>
            <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
            <SelectContent>
              {[25, 50, 100, 200].map(n => <SelectItem key={n} value={String(n)}>Last {n}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Time</th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Action</th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Source</th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Verdict</th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Rows</th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Duration</th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground">SQL</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {(logs as any[]).length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">
                        No audit records found
                      </td>
                    </tr>
                  ) : (
                    (logs as any[]).map((log: any) => (
                      <tr key={log.id} className="hover:bg-accent/30">
                        <td className="px-4 py-2 whitespace-nowrap text-muted-foreground">
                          {new Date(log.executedAt).toLocaleString()}
                        </td>
                        <td className="px-4 py-2">
                          <Badge variant="outline" className="capitalize text-[10px]">
                            {log.action?.replace(/_/g, " ")}
                          </Badge>
                        </td>
                        <td className="px-4 py-2">
                          {log.sourceId
                            ? (sources as any[]).find((s: any) => s.id === log.sourceId)?.name ?? `#${log.sourceId}`
                            : "—"}
                        </td>
                        <td className="px-4 py-2">
                          {log.evaluationVerdict ? (
                            <span className={`flex items-center gap-1 font-medium ${
                              log.evaluationVerdict === "pass" ? "text-green-600" :
                              log.evaluationVerdict === "warn" ? "text-amber-600" : "text-red-600"
                            }`}>
                              {log.evaluationVerdict === "pass" ? <CheckCircle className="w-3 h-3" /> :
                               log.evaluationVerdict === "warn" ? <AlertTriangle className="w-3 h-3" /> :
                               <XCircle className="w-3 h-3" />}
                              {log.evaluationVerdict}
                            </span>
                          ) : "—"}
                        </td>
                        <td className="px-4 py-2">{log.rowCount?.toLocaleString() ?? "—"}</td>
                        <td className="px-4 py-2">{log.durationMs ? `${log.durationMs}ms` : "—"}</td>
                        <td className="px-4 py-2 max-w-xs">
                          {log.sqlText ? (
                            <span className="font-mono text-[10px] text-muted-foreground truncate block max-w-xs" title={log.sqlText}>
                              {log.sqlText.slice(0, 80)}{log.sqlText.length > 80 ? "..." : ""}
                            </span>
                          ) : "—"}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
