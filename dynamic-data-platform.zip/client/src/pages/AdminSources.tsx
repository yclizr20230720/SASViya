import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Trash2, Database, ChevronDown, ChevronRight, Loader2 } from "lucide-react";
import { toast } from "sonner";

// ─── Sub-component to safely use hooks per source ─────────────────────────────
function SourceRow({ src, onDelete }: { src: any; onDelete: (id: number) => void }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [schemaName, setSchemaName] = useState("");

  const { data: schemas = [], refetch: refetchSchemas } = trpc.sources.listSchemas.useQuery(
    { sourceId: src.id },
    { enabled: isExpanded }
  );
  const addSchemaMutation = trpc.sources.addSchema.useMutation({
    onSuccess: () => { toast.success("Schema added"); refetchSchemas(); setSchemaName(""); },
    onError: (e) => toast.error(e.message),
  });
  const removeSchemaMutation = trpc.sources.removeSchema.useMutation({
    onSuccess: () => { toast.success("Schema removed"); refetchSchemas(); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <button onClick={() => setIsExpanded(!isExpanded)} className="flex items-center gap-2 flex-1 text-left">
            {isExpanded ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
            <Database className="w-4 h-4 text-primary" />
            <div>
              <p className="font-semibold text-sm">{src.name}</p>
              <p className="text-xs text-muted-foreground">{src.host}:{src.port} · {src.database}</p>
            </div>
          </button>
          <Badge variant="outline" className="capitalize text-xs">{src.dialect}</Badge>
          <div className={`w-2 h-2 rounded-full ${src.isActive ? "bg-green-500" : "bg-gray-400"}`} />
          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive"
            onClick={() => { if (confirm("Delete this source?")) onDelete(src.id); }}>
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
        {isExpanded && (
          <div className="mt-4 pt-4 border-t border-border">
            <div className="grid grid-cols-3 gap-3 text-xs mb-4">
              <div><span className="text-muted-foreground">Timeout:</span> <span className="font-medium">{src.queryTimeoutSec}s</span></div>
              <div><span className="text-muted-foreground">Max Rows:</span> <span className="font-medium">{src.maxRows?.toLocaleString()}</span></div>
              <div><span className="text-muted-foreground">Max Concurrent:</span> <span className="font-medium">{src.maxConcurrentQueries}</span></div>
              <div><span className="text-muted-foreground">Scan Threshold:</span> <span className="font-medium">{src.fullScanThreshold?.toLocaleString()}</span></div>
              <div className="col-span-2"><span className="text-muted-foreground">Credential Ref:</span> <span className="font-mono font-medium">{src.readonlyCredentialRef}</span></div>
            </div>
            <div>
              <p className="text-xs font-semibold mb-2">Registered Schemas ({(schemas as any[]).length})</p>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {(schemas as any[]).map((s: any) => (
                  <Badge key={s.id} variant="secondary" className="gap-1 text-xs">
                    {s.schemaName}
                    <button onClick={() => removeSchemaMutation.mutate({ id: s.id })} className="ml-1 text-muted-foreground hover:text-destructive">×</button>
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Input className="h-7 text-xs w-40" placeholder="Schema name..." value={schemaName} onChange={e => setSchemaName(e.target.value)} />
                <Button size="sm" className="h-7 text-xs gap-1"
                  onClick={() => addSchemaMutation.mutate({ sourceId: src.id, schemaName })}
                  disabled={!schemaName.trim() || addSchemaMutation.isPending}>
                  <Plus className="w-3 h-3" /> Add
                </Button>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function AdminSources() {
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({
    name: "", dialect: "oracle" as any, host: "", port: 1521, database: "",
    readonlyCredentialRef: "", queryTimeoutSec: 30, maxRows: 100000,
    maxConcurrentQueries: 3, fullScanThreshold: 100000, description: "",
  });

  const { data: sources = [], refetch, isLoading } = trpc.sources.list.useQuery();
  const createMutation = trpc.sources.create.useMutation({
    onSuccess: () => { toast.success("Source created"); refetch(); setShowCreate(false); },
    onError: (e) => toast.error(e.message),
  });
  const deleteMutation = trpc.sources.delete.useMutation({
    onSuccess: () => { toast.success("Source deleted"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <AppLayout>
      <div className="p-6 max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl font-bold">Data Sources</h1>
            <p className="text-sm text-muted-foreground">Manage registered database connections and schemas</p>
          </div>
          <Button onClick={() => setShowCreate(true)} className="gap-2"><Plus className="w-4 h-4" /> Add Source</Button>
        </div>

        <div className="space-y-3">
          {isLoading ? (
            <div className="flex items-center justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
          ) : (sources as any[]).filter((s: any) => !!s?.id).map((src: any) => (
            <SourceRow key={`source-${src.id}`} src={src} onDelete={(id) => deleteMutation.mutate({ id })} />
          ))}
          {!isLoading && sources.length === 0 && (
            <Card><CardContent className="py-12 text-center text-muted-foreground"><Database className="w-10 h-10 mx-auto mb-2 opacity-20" /><p className="text-sm">No data sources registered</p></CardContent></Card>
          )}
        </div>

        <Dialog open={showCreate} onOpenChange={setShowCreate}>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Add Data Source</DialogTitle></DialogHeader>
            <div className="grid grid-cols-2 gap-3 py-2">
              <div className="col-span-2 space-y-1"><Label className="text-xs">Source Name *</Label><Input className="h-8 text-xs" placeholder="e.g. F12PEDA" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div>
              <div className="space-y-1"><Label className="text-xs">Dialect *</Label>
                <Select value={form.dialect} onValueChange={v => setForm(p => ({ ...p, dialect: v as any }))}>
                  <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{["oracle","postgresql","mysql","mssql","sqlite"].map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1"><Label className="text-xs">Host *</Label><Input className="h-8 text-xs" placeholder="hostname" value={form.host} onChange={e => setForm(p => ({ ...p, host: e.target.value }))} /></div>
              <div className="space-y-1"><Label className="text-xs">Port *</Label><Input className="h-8 text-xs" type="number" value={form.port} onChange={e => setForm(p => ({ ...p, port: Number(e.target.value) }))} /></div>
              <div className="space-y-1"><Label className="text-xs">Database/Service *</Label><Input className="h-8 text-xs" placeholder="database name" value={form.database} onChange={e => setForm(p => ({ ...p, database: e.target.value }))} /></div>
              <div className="col-span-2 space-y-1"><Label className="text-xs">Credential Env Var Ref *</Label><Input className="h-8 text-xs font-mono" placeholder="e.g. DB_CRED_F12PEDA" value={form.readonlyCredentialRef} onChange={e => setForm(p => ({ ...p, readonlyCredentialRef: e.target.value }))} /></div>
              <div className="space-y-1"><Label className="text-xs">Query Timeout (sec)</Label><Input className="h-8 text-xs" type="number" value={form.queryTimeoutSec} onChange={e => setForm(p => ({ ...p, queryTimeoutSec: Number(e.target.value) }))} /></div>
              <div className="space-y-1"><Label className="text-xs">Max Rows</Label><Input className="h-8 text-xs" type="number" value={form.maxRows} onChange={e => setForm(p => ({ ...p, maxRows: Number(e.target.value) }))} /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
              <Button onClick={() => createMutation.mutate(form)} disabled={!form.name || !form.host || !form.database || createMutation.isPending}>
                {createMutation.isPending ? "Creating..." : "Create Source"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}
