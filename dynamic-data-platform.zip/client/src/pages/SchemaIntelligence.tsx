import { useState } from "react";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  Database, RefreshCw, GitBranch, Table2, Key, Link2,
  CheckCircle2, AlertTriangle, Info, ChevronDown, ChevronRight,
  Layers, Cpu, Search, BarChart3,
} from "lucide-react";

export default function SchemaIntelligence() {
  const [selectedSource, setSelectedSource] = useState<number | null>(null);
  const [expandedTables, setExpandedTables] = useState<Set<string>>(new Set());
  const [scanningSourceId, setScanningSourceId] = useState<number | null>(null);

  const { data: sources } = trpc.sources.list.useQuery();
  const { data: mockScenarios } = trpc.schema.getMockScenarios.useQuery();
  const { data: relationships } = trpc.schema.getRelationships.useQuery({});

  const selectedSourceData = sources?.find(s => s.id === selectedSource);
  const { data: schemas } = trpc.sources.listSchemas.useQuery(
    { sourceId: selectedSource! },
    { enabled: !!selectedSource }
  );

  const scanAll = trpc.schema.scanAllSchemas.useMutation({
    onSuccess: (data) => {
      toast.success(`Scan complete: ${data.totalTables} tables, ${data.totalColumns} columns, ${data.totalIndexes} indexes, ${data.totalForeignKeys} foreign keys`);
      setScanningSourceId(null);
    },
    onError: (err) => {
      toast.error(`Scan failed: ${err.message}`);
      setScanningSourceId(null);
    },
  });

  const scanSchema = trpc.schema.scanSchema.useMutation({
    onSuccess: (data) => {
      toast.success(`Schema scanned: ${data.tablesScanned} tables, ${data.columnsScanned} columns`);
    },
    onError: (err) => toast.error(`Scan failed: ${err.message}`),
  });

  const handleScanAll = (sourceId: number) => {
    setScanningSourceId(sourceId);
    scanAll.mutate({ sourceId });
  };

  const toggleTable = (key: string) => {
    setExpandedTables(prev => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  };

  const getDialectColor = (dialect: string) => {
    if (dialect === "oracle") return "bg-red-100 text-red-700 border-red-200";
    if (dialect === "postgresql") return "bg-blue-100 text-blue-700 border-blue-200";
    return "bg-gray-100 text-gray-700 border-gray-200";
  };

  const getRelTypeColor = (type: string) => {
    if (type === "foreign_key") return "text-green-600 bg-green-50";
    if (type === "logical") return "text-blue-600 bg-blue-50";
    return "text-purple-600 bg-purple-50";
  };

  return (
    <AppLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Cpu className="h-6 w-6 text-primary" />
              Schema Intelligence
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Scan database schemas, discover relationships, and power AI-driven SQL generation
            </p>
          </div>
        </div>

        <Tabs defaultValue="scanner">
          <TabsList className="grid w-full grid-cols-3 max-w-lg">
            <TabsTrigger value="scanner"><Database className="h-4 w-4 mr-1" />Schema Scanner</TabsTrigger>
            <TabsTrigger value="relationships"><GitBranch className="h-4 w-4 mr-1" />Relationships</TabsTrigger>
            <TabsTrigger value="scenarios"><Layers className="h-4 w-4 mr-1" />Mock Scenarios</TabsTrigger>
          </TabsList>

          {/* ── Schema Scanner Tab ── */}
          <TabsContent value="scanner" className="space-y-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {sources?.map(source => (
                <Card
                  key={source.id}
                  className={`cursor-pointer transition-all border-2 ${selectedSource === source.id ? "border-primary shadow-md" : "border-border hover:border-primary/40"}`}
                  onClick={() => setSelectedSource(source.id)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">{source.name}</CardTitle>
                      <Badge variant="outline" className={`text-xs ${getDialectColor(source.dialect)}`}>
                        {source.dialect.toUpperCase()}
                      </Badge>
                    </div>
                    <CardDescription className="text-xs">{source.host}:{source.port}/{source.database}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center justify-between">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${source.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                        {source.isActive ? "Active" : "Inactive"}
                      </span>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs"
                        disabled={scanningSourceId === source.id}
                        onClick={(e) => { e.stopPropagation(); handleScanAll(source.id); }}
                      >
                        {scanningSourceId === source.id ? (
                          <><RefreshCw className="h-3 w-3 mr-1 animate-spin" />Scanning...</>
                        ) : (
                          <><RefreshCw className="h-3 w-3 mr-1" />Scan All</>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {selectedSource && schemas && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-foreground">Schemas in {selectedSourceData?.name}</h3>
                  <Badge variant="secondary">{schemas.length} schemas</Badge>
                </div>
                {schemas.map(schema => (
                  <SchemaPanel
                    key={schema.id}
                    sourceId={selectedSource}
                    schemaName={schema.schemaName}
                    description={schema.description}
                    expandedTables={expandedTables}
                    onToggleTable={toggleTable}
                    onScanSchema={(schemaName) => scanSchema.mutate({ sourceId: selectedSource, schemaName })}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          {/* ── Relationships Tab ── */}
          <TabsContent value="relationships" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <GitBranch className="h-4 w-4 text-primary" />
                  Cross-Table Relationship Graph
                </CardTitle>
                <CardDescription>
                  {relationships?.length ?? 0} relationships discovered across all data sources
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[500px]">
                  <div className="space-y-2">
                    {relationships?.map((rel, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted/30 transition-colors">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">
                              {rel.fromSource}.{rel.fromSchema}.{rel.fromTable}.{rel.fromColumn}
                            </code>
                            <Link2 className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                            <code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">
                              {rel.toSource}.{rel.toSchema}.{rel.toTable}.{rel.toColumn}
                            </code>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{rel.description}</p>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${getRelTypeColor(rel.relationshipType)}`}>
                            {rel.relationshipType.replace("_", " ")}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {Math.round(rel.confidence * 100)}%
                          </span>
                        </div>
                      </div>
                    ))}
                    {(!relationships || relationships.length === 0) && (
                      <div className="text-center py-12 text-muted-foreground">
                        <GitBranch className="h-8 w-8 mx-auto mb-2 opacity-40" />
                        <p className="text-sm">No relationships found. Scan schemas first to discover relationships.</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ── Mock Scenarios Tab ── */}
          <TabsContent value="scenarios" className="mt-4">
            <div className="space-y-4">
              <div className="flex items-center gap-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <Info className="h-4 w-4 text-blue-600 flex-shrink-0" />
                <p className="text-sm text-blue-700">
                  Mock scenarios simulate real semiconductor manufacturing databases (F12PEDA Oracle, F12PMES Oracle, f12edagp GreenPlum).
                  Click "Scan All" on any source to populate the schema cache from these scenarios.
                </p>
              </div>
              {mockScenarios?.map(scenario => (
                <Card key={scenario.sourceName}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Database className="h-4 w-4 text-primary" />
                        {scenario.sourceName}
                      </CardTitle>
                      <Badge variant="outline" className={`text-xs ${getDialectColor(scenario.dialect)}`}>
                        {scenario.dialect.toUpperCase()}
                      </Badge>
                    </div>
                    <CardDescription>{scenario.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {scenario.schemas.map(schema => (
                        <div key={schema.schemaName} className="border border-border rounded-lg p-3">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-sm">{schema.schemaName}</span>
                            <Badge variant="secondary" className="text-xs">{schema.tableCount} tables</Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mb-2">{schema.description}</p>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {schema.tables.map(table => (
                              <div key={table.tableName} className="flex items-center justify-between p-2 bg-muted/30 rounded text-xs">
                                <div className="flex items-center gap-1.5">
                                  <Table2 className="h-3 w-3 text-muted-foreground" />
                                  <span className="font-mono font-medium">{table.tableName}</span>
                                </div>
                                <div className="flex items-center gap-2 text-muted-foreground">
                                  <span>{table.columnCount}c</span>
                                  <span>{table.indexCount}i</span>
                                  <span>{table.fkCount}fk</span>
                                  <span className="text-primary font-medium">{(table.approxRowCount / 1000000).toFixed(1)}M</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}

// ── Schema Panel Component ──────────────────────────────────────────────────────
function SchemaPanel({
  sourceId, schemaName, description, expandedTables, onToggleTable, onScanSchema,
}: {
  sourceId: number; schemaName: string; description?: string | null;
  expandedTables: Set<string>; onToggleTable: (key: string) => void;
  onScanSchema: (schemaName: string) => void;
}) {
  const { data: tables, refetch } = trpc.sources.listTables.useQuery({ sourceId, schemaName });

  const handleScan = () => {
    onScanSchema(schemaName);
    setTimeout(() => refetch(), 2000);
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-sm font-semibold flex items-center gap-1.5">
              <Layers className="h-4 w-4 text-primary" />
              {schemaName}
            </CardTitle>
            {description && <CardDescription className="text-xs mt-0.5">{description}</CardDescription>}
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">{tables?.length ?? 0} tables</Badge>
            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={handleScan}>
              <RefreshCw className="h-3 w-3 mr-1" />Scan
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {tables && tables.length > 0 ? (
          <div className="space-y-1">
            {tables.map(table => {
              const key = `${schemaName}.${table.tableName}`;
              const isExpanded = expandedTables.has(key);
              return (
                <TableRow
                  key={key}
                  sourceId={sourceId}
                  schemaName={schemaName}
                  table={table}
                  isExpanded={isExpanded}
                  onToggle={() => onToggleTable(key)}
                />
              );
            })}
          </div>
        ) : (
          <div className="text-center py-6 text-muted-foreground">
            <Table2 className="h-6 w-6 mx-auto mb-1 opacity-40" />
            <p className="text-xs">No tables cached. Click "Scan" to introspect this schema.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ── Table Row Component ─────────────────────────────────────────────────────────
function TableRow({
  sourceId, schemaName, table, isExpanded, onToggle,
}: {
  sourceId: number; schemaName: string;
  table: any; isExpanded: boolean; onToggle: () => void;
}) {
  const { data: detail } = trpc.schema.getTableDetail.useQuery(
    { sourceId, schemaName, tableName: table.tableName },
    { enabled: isExpanded }
  );

  const rowCountLabel = table.approxRowCount
    ? table.approxRowCount >= 1000000
      ? `${(table.approxRowCount / 1000000).toFixed(1)}M rows`
      : `${(table.approxRowCount / 1000).toFixed(0)}K rows`
    : "unknown";

  const isLargeTable = (table.approxRowCount ?? 0) > 1000000;

  return (
    <div className="border border-border rounded-md overflow-hidden">
      <button
        className="w-full flex items-center gap-2 p-2.5 hover:bg-muted/40 transition-colors text-left"
        onClick={onToggle}
      >
        {isExpanded ? <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" /> : <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />}
        <Table2 className="h-3.5 w-3.5 text-primary" />
        <span className="font-mono text-sm font-medium flex-1">{table.tableName}</span>
        {table.businessDomain && (
          <span className="text-xs px-1.5 py-0.5 bg-purple-50 text-purple-600 rounded">{table.businessDomain}</span>
        )}
        {table.partitionKey && (
          <span className="text-xs px-1.5 py-0.5 bg-orange-50 text-orange-600 rounded">PART:{table.partitionKey}</span>
        )}
        <span className={`text-xs px-1.5 py-0.5 rounded ${isLargeTable ? "bg-red-50 text-red-600" : "bg-muted text-muted-foreground"}`}>
          {rowCountLabel}
        </span>
        {table.description && <Info className="h-3 w-3 text-muted-foreground" />}
      </button>
      {isExpanded && detail && (
        <div className="border-t border-border bg-muted/10 p-3 space-y-3">
          {detail.tableComment && (
            <p className="text-xs text-muted-foreground italic">{detail.tableComment}</p>
          )}
          {/* Columns */}
          <div>
            <div className="text-xs font-semibold text-foreground mb-1.5 flex items-center gap-1">
              <BarChart3 className="h-3 w-3" />Columns ({detail.columns.length})
            </div>
            <div className="space-y-0.5">
              {detail.columns.map((col: any) => (
                <div key={col.columnName} className="flex items-center gap-2 text-xs py-0.5 px-1 rounded hover:bg-muted/50">
                  {col.isKey ? <Key className="h-3 w-3 text-yellow-500 flex-shrink-0" /> : <span className="w-3 h-3 flex-shrink-0" />}
                  <span className="font-mono font-medium w-40 truncate">{col.columnName}</span>
                  <span className="text-muted-foreground w-32 truncate">{col.dataType}</span>
                  <div className="flex gap-1">
                    {col.isKey && <Badge variant="outline" className="text-[10px] h-4 px-1 border-yellow-300 text-yellow-600">PK</Badge>}
                    {col.isIndexed && !col.isKey && <Badge variant="outline" className="text-[10px] h-4 px-1 border-blue-300 text-blue-600">IDX</Badge>}
                    {col.isNullable && <Badge variant="outline" className="text-[10px] h-4 px-1">NULL</Badge>}
                  </div>
                  {col.description && <span className="text-muted-foreground truncate flex-1">{col.description}</span>}
                </div>
              ))}
            </div>
          </div>
          {/* Indexes */}
          {detail.indexesJson && detail.indexesJson.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-foreground mb-1.5 flex items-center gap-1">
                <Search className="h-3 w-3" />Indexes ({detail.indexesJson.length})
              </div>
              <div className="space-y-0.5">
                {detail.indexesJson.map((idx: any) => (
                  <div key={idx.indexName} className="flex items-center gap-2 text-xs py-0.5 px-1">
                    <span className="font-mono text-muted-foreground w-40 truncate">{idx.indexName}</span>
                    <span className="text-foreground">{idx.columns.join(", ")}</span>
                    {idx.isUnique && <Badge variant="outline" className="text-[10px] h-4 px-1 border-green-300 text-green-600">UNIQUE</Badge>}
                    <span className="text-muted-foreground">{idx.indexType}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          {/* Foreign Keys */}
          {detail.foreignKeysJson && detail.foreignKeysJson.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-foreground mb-1.5 flex items-center gap-1">
                <Link2 className="h-3 w-3" />Foreign Keys ({detail.foreignKeysJson.length})
              </div>
              <div className="space-y-0.5">
                {detail.foreignKeysJson.map((fk: any) => (
                  <div key={fk.constraintName} className="flex items-center gap-2 text-xs py-0.5 px-1">
                    <span className="font-mono text-muted-foreground w-40 truncate">{fk.constraintName}</span>
                    <span className="text-foreground">{fk.columns.join(", ")}</span>
                    <span className="text-muted-foreground">→</span>
                    <span className="font-mono text-primary">{fk.referencedSchema}.{fk.referencedTable}({fk.referencedColumns.join(", ")})</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
