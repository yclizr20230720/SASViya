/**
 * Fab Data Explorer
 * Full-featured interactive explorer for the 10 semiconductor fab tables.
 * Supports:
 *  - Table browsing with column metadata
 *  - Dynamic column selection (checkboxes)
 *  - Filter criteria builder (type-aware operators)
 *  - Sort configuration
 *  - Preview (100 rows) and full execution
 *  - Cross-table join (2 tables via shared key)
 *  - Generated SQL display
 *  - Results table with pagination
 */
import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import {
  Table2, Play, Filter, Code2, Download, ChevronRight, ChevronDown,
  Key, Search, BarChart3, GitBranch, Loader2, CheckSquare, Square,
  RefreshCw, Database, AlertTriangle, CheckCircle2, Info, X,
} from "lucide-react";

type FilterRow = { id: string; column: string; operator: string; value: string };
type JoinConfig = { rightTable: string; joinColumn: string; joinType: "INNER" | "LEFT" | "RIGHT"; rightColumns: string[] };

const OPERATORS = [
  { value: "eq", label: "= equals" },
  { value: "neq", label: "≠ not equals" },
  { value: "gt", label: "> greater than" },
  { value: "gte", label: "≥ greater or equal" },
  { value: "lt", label: "< less than" },
  { value: "lte", label: "≤ less or equal" },
  { value: "like", label: "LIKE contains" },
  { value: "in", label: "IN list (comma-sep)" },
  { value: "between", label: "BETWEEN range (a,b)" },
  { value: "is_null", label: "IS NULL" },
  { value: "is_not_null", label: "IS NOT NULL" },
];

const DOMAIN_COLORS: Record<string, string> = {
  lot_tracking:   "bg-blue-100 text-blue-700",
  wafer_tracking: "bg-indigo-100 text-indigo-700",
  equipment:      "bg-orange-100 text-orange-700",
  yield:          "bg-green-100 text-green-700",
  fault_detection:"bg-red-100 text-red-700",
  metrology:      "bg-purple-100 text-purple-700",
  defect:         "bg-yellow-100 text-yellow-700",
};

export default function FabDataExplorer() {
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [selectedColumns, setSelectedColumns] = useState<Set<string>>(new Set());
  const [filters, setFilters] = useState<FilterRow[]>([]);
  const [orderBy, setOrderBy] = useState<string>("");
  const [orderDir, setOrderDir] = useState<"ASC" | "DESC">("ASC");
  const [activeTab, setActiveTab] = useState<"browse" | "query" | "join" | "results">("browse");
  const [queryResult, setQueryResult] = useState<{ columns: string[]; rows: any[]; rowCount: number; sql: string; durationMs: number; totalCount?: number } | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [joinConfig, setJoinConfig] = useState<JoinConfig>({ rightTable: "", joinColumn: "LOT_ID", joinType: "INNER", rightColumns: [] });
  const [searchTerm, setSearchTerm] = useState("");

  const { data: tables, isLoading: tablesLoading } = trpc.fabData.listTables.useQuery();
  const { data: rowCount } = trpc.fabData.getRowCount.useQuery(
    { tableName: selectedTable! },
    { enabled: !!selectedTable }
  );

  const previewQuery = trpc.fabData.previewQuery.useMutation({
    onSuccess: (data) => {
      setQueryResult(data);
      setActiveTab("results");
      setIsExecuting(false);
      toast.success(`Preview complete: ${data.rowCount} rows in ${data.durationMs}ms`);
    },
    onError: (err) => { toast.error(err.message); setIsExecuting(false); },
  });

  const executeQuery = trpc.fabData.executeQuery.useMutation({
    onSuccess: (data) => {
      setQueryResult({ ...data, totalCount: data.totalCount });
      setActiveTab("results");
      setIsExecuting(false);
      toast.success(`Query complete: ${data.rowCount} of ${data.totalCount} rows in ${data.durationMs}ms`);
    },
    onError: (err) => { toast.error(err.message); setIsExecuting(false); },
  });

  const joinQuery = trpc.fabData.joinQuery.useMutation({
    onSuccess: (data) => {
      setQueryResult(data);
      setActiveTab("results");
      setIsExecuting(false);
      toast.success(`Join complete: ${data.rowCount} rows in ${data.durationMs}ms`);
    },
    onError: (err) => { toast.error(err.message); setIsExecuting(false); },
  });

  const selectedTableMeta = useMemo(() => tables?.find(t => t.tableName === selectedTable), [tables, selectedTable]);
  const filteredTables = useMemo(() =>
    tables?.filter(t => t.tableName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (t.comment ?? "").toLowerCase().includes(searchTerm.toLowerCase())),
    [tables, searchTerm]
  );

  const handleSelectTable = (tableName: string) => {
    setSelectedTable(tableName);
    setSelectedColumns(new Set());
    setFilters([]);
    setOrderBy("");
    setQueryResult(null);
    setActiveTab("query");
  };

  const toggleColumn = (col: string) => {
    setSelectedColumns(prev => {
      const next = new Set(prev);
      next.has(col) ? next.delete(col) : next.add(col);
      return next;
    });
  };

  const selectAllColumns = () => {
    if (!selectedTableMeta) return;
    setSelectedColumns(new Set(selectedTableMeta.columns.map(c => c.columnName)));
  };

  const clearAllColumns = () => setSelectedColumns(new Set());

  const addFilter = () => {
    if (!selectedTableMeta) return;
    const firstCol = selectedTableMeta.columns[0]?.columnName ?? "";
    setFilters(prev => [...prev, { id: crypto.randomUUID(), column: firstCol, operator: "eq", value: "" }]);
  };

  const removeFilter = (id: string) => setFilters(prev => prev.filter(f => f.id !== id));

  const updateFilter = (id: string, field: keyof FilterRow, value: string) => {
    setFilters(prev => prev.map(f => f.id === id ? { ...f, [field]: value } : f));
  };

  const buildFilterInput = () => filters
    .filter(f => f.column && f.operator)
    .map(f => {
      const op = f.operator as any;
      let value: any = f.value;
      if (op === "in") value = f.value.split(",").map(v => v.trim()).filter(Boolean);
      if (op === "between") { const parts = f.value.split(","); value = [parts[0]?.trim(), parts[1]?.trim()]; }
      if (op === "is_null" || op === "is_not_null") value = undefined;
      return { column: f.column, operator: op, value };
    });

  const handlePreview = () => {
    if (!selectedTable || selectedColumns.size === 0) { toast.error("Select a table and at least one column"); return; }
    setIsExecuting(true);
    previewQuery.mutate({
      tableName: selectedTable,
      columns: Array.from(selectedColumns),
      filters: buildFilterInput(),
      orderBy: orderBy || undefined,
      orderDir,
    });
  };

  const handleExecute = () => {
    if (!selectedTable || selectedColumns.size === 0) { toast.error("Select a table and at least one column"); return; }
    setIsExecuting(true);
    executeQuery.mutate({
      tableName: selectedTable,
      columns: Array.from(selectedColumns),
      filters: buildFilterInput(),
      orderBy: orderBy || undefined,
      orderDir,
      limit: 1000,
      offset: 0,
    });
  };

  const handleJoin = () => {
    if (!selectedTable || selectedColumns.size === 0 || !joinConfig.rightTable || joinConfig.rightColumns.length === 0) {
      toast.error("Configure both tables and select columns for join"); return;
    }
    setIsExecuting(true);
    joinQuery.mutate({
      leftTable: selectedTable,
      leftColumns: Array.from(selectedColumns),
      rightTable: joinConfig.rightTable,
      rightColumns: joinConfig.rightColumns,
      joinColumn: joinConfig.joinColumn,
      joinType: joinConfig.joinType,
      filters: buildFilterInput(),
      limit: 100,
    });
  };

  const handleDownloadCsv = () => {
    if (!queryResult) return;
    const header = queryResult.columns.join(",");
    const rows = queryResult.rows.map(r => queryResult.columns.map(c => {
      const v = r[c] ?? "";
      return typeof v === "string" && v.includes(",") ? `"${v}"` : v;
    }).join(","));
    const csv = [header, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${selectedTable ?? "fab_data"}_export.csv`; a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV downloaded");
  };

  return (
    <AppLayout>
      <div className="flex h-[calc(100vh-56px)] overflow-hidden">
        {/* ── Left Panel: Table Browser ─────────────────────────────────────── */}
        <aside className="w-72 flex-shrink-0 border-r border-border flex flex-col bg-muted/20">
          <div className="p-3 border-b border-border">
            <h2 className="font-semibold text-sm flex items-center gap-2 mb-2">
              <Database className="h-4 w-4 text-primary" />
              Fab Data Tables
              <Badge variant="secondary" className="ml-auto text-xs">{tables?.length ?? 0}</Badge>
            </h2>
            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                placeholder="Search tables..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="pl-7 h-7 text-xs"
              />
            </div>
          </div>
          <ScrollArea className="flex-1">
            {tablesLoading ? (
              <div className="p-4 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></div>
            ) : (
              <div className="p-2 space-y-1">
                {filteredTables?.map(table => (
                  <button
                    key={table.tableName}
                    onClick={() => handleSelectTable(table.tableName)}
                    className={`w-full text-left p-2.5 rounded-lg transition-all text-xs ${selectedTable === table.tableName ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      <Table2 className="h-3 w-3 flex-shrink-0" />
                      <span className="font-mono font-semibold truncate">{table.tableName}</span>
                    </div>
                    <div className="flex items-center gap-1 flex-wrap">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${selectedTable === table.tableName ? "bg-primary-foreground/20 text-primary-foreground" : DOMAIN_COLORS[table.businessDomain ?? ""] ?? "bg-gray-100 text-gray-600"}`}>
                        {table.businessDomain?.replace("_", " ")}
                      </span>
                      <span className={`text-[10px] ${selectedTable === table.tableName ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                        {table.columnCount}c · {table.indexCount}i
                      </span>
                    </div>
                    <p className={`text-[10px] mt-1 truncate ${selectedTable === table.tableName ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                      {table.comment}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </ScrollArea>
        </aside>

        {/* ── Main Content ──────────────────────────────────────────────────── */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {!selectedTable ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <Database className="h-12 w-12 text-muted-foreground/40 mx-auto mb-3" />
                <p className="font-medium text-foreground">Select a table to start exploring</p>
                <p className="text-sm text-muted-foreground mt-1">10 semiconductor fab tables with 2,100+ rows of real data</p>
              </div>
            </div>
          ) : (
            <>
              {/* Header */}
              <div className="border-b border-border p-4 flex items-center justify-between flex-shrink-0">
                <div>
                  <h1 className="font-bold text-lg flex items-center gap-2">
                    <Table2 className="h-5 w-5 text-primary" />
                    {selectedTable}
                    <Badge variant="secondary" className="text-xs">{rowCount?.count?.toLocaleString() ?? "..."} rows</Badge>
                  </h1>
                  <p className="text-xs text-muted-foreground mt-0.5">{selectedTableMeta?.comment}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{selectedColumns.size} columns selected</span>
                  <Button size="sm" variant="outline" onClick={handlePreview} disabled={isExecuting || selectedColumns.size === 0} className="h-8">
                    {isExecuting ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Play className="h-3.5 w-3.5 mr-1" />}
                    Preview 100
                  </Button>
                  <Button size="sm" onClick={handleExecute} disabled={isExecuting || selectedColumns.size === 0} className="h-8">
                    {isExecuting ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <BarChart3 className="h-3.5 w-3.5 mr-1" />}
                    Execute Full
                  </Button>
                </div>
              </div>

              <div className="flex-1 overflow-hidden">
                <Tabs value={activeTab} onValueChange={v => setActiveTab(v as any)} className="h-full flex flex-col">
                  <TabsList className="mx-4 mt-3 w-fit">
                    <TabsTrigger value="browse"><Table2 className="h-3.5 w-3.5 mr-1" />Schema</TabsTrigger>
                    <TabsTrigger value="query"><Filter className="h-3.5 w-3.5 mr-1" />Query Builder</TabsTrigger>
                    <TabsTrigger value="join"><GitBranch className="h-3.5 w-3.5 mr-1" />Join</TabsTrigger>
                    <TabsTrigger value="results" disabled={!queryResult}>
                      <BarChart3 className="h-3.5 w-3.5 mr-1" />Results
                      {queryResult && <Badge variant="secondary" className="ml-1 text-[10px] h-4 px-1">{queryResult.rowCount}</Badge>}
                    </TabsTrigger>
                  </TabsList>

                  {/* ── Schema Tab ── */}
                  <TabsContent value="browse" className="flex-1 overflow-hidden mt-0 p-4">
                    <ScrollArea className="h-full">
                      <div className="space-y-4">
                        {/* Columns */}
                        <Card>
                          <CardHeader className="pb-2">
                            <div className="flex items-center justify-between">
                              <CardTitle className="text-sm">Columns ({selectedTableMeta?.columnCount})</CardTitle>
                              <div className="flex gap-1">
                                <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={selectAllColumns}>Select All</Button>
                                <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={clearAllColumns}>Clear</Button>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-0.5">
                              {selectedTableMeta?.columns.map(col => (
                                <div
                                  key={col.columnName}
                                  className={`flex items-center gap-2 p-1.5 rounded cursor-pointer hover:bg-muted/50 transition-colors ${selectedColumns.has(col.columnName) ? "bg-primary/5" : ""}`}
                                  onClick={() => toggleColumn(col.columnName)}
                                >
                                  <Checkbox checked={selectedColumns.has(col.columnName)} onCheckedChange={() => toggleColumn(col.columnName)} className="h-3.5 w-3.5" />
                                  {col.isKey ? <Key className="h-3 w-3 text-yellow-500 flex-shrink-0" /> : <span className="w-3 h-3 flex-shrink-0" />}
                                  <span className="font-mono text-xs font-medium w-44 truncate">{col.columnName}</span>
                                  <span className="text-xs text-muted-foreground w-32 truncate">{col.dataType}</span>
                                  <div className="flex gap-1">
                                    {col.isKey && <Badge variant="outline" className="text-[10px] h-4 px-1 border-yellow-300 text-yellow-600">PK</Badge>}
                                    {col.isIndexed && !col.isKey && <Badge variant="outline" className="text-[10px] h-4 px-1 border-blue-300 text-blue-600">IDX</Badge>}
                                    {col.isNullable && <Badge variant="outline" className="text-[10px] h-4 px-1">NULL</Badge>}
                                  </div>
                                  {col.comment && <span className="text-xs text-muted-foreground truncate flex-1">{col.comment}</span>}
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                        {/* Indexes */}
                        {selectedTableMeta && selectedTableMeta.indexes.length > 0 && (
                          <Card>
                            <CardHeader className="pb-2"><CardTitle className="text-sm">Indexes ({selectedTableMeta.indexes.length})</CardTitle></CardHeader>
                            <CardContent>
                              <div className="space-y-1">
                                {selectedTableMeta.indexes.map((idx: any) => (
                                  <div key={idx.indexName} className="flex items-center gap-2 text-xs py-1">
                                    <span className="font-mono text-muted-foreground w-48 truncate">{idx.indexName}</span>
                                    <span className="text-foreground">{idx.columns.join(", ")}</span>
                                    {idx.isUnique && <Badge variant="outline" className="text-[10px] h-4 px-1 border-green-300 text-green-600">UNIQUE</Badge>}
                                    <span className="text-muted-foreground">{idx.indexType}</span>
                                  </div>
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                        )}
                        {/* Foreign Keys */}
                        {selectedTableMeta && selectedTableMeta.foreignKeys.length > 0 && (
                          <Card>
                            <CardHeader className="pb-2"><CardTitle className="text-sm">Foreign Keys ({selectedTableMeta.foreignKeys.length})</CardTitle></CardHeader>
                            <CardContent>
                              <div className="space-y-1">
                                {selectedTableMeta.foreignKeys.map((fk: any) => (
                                  <div key={fk.constraintName} className="flex items-center gap-2 text-xs py-1">
                                    <span className="font-mono text-muted-foreground w-32 truncate">{fk.constraintName}</span>
                                    <span>{fk.columns.join(", ")}</span>
                                    <span className="text-muted-foreground">→</span>
                                    <span className="font-mono text-primary">{fk.referencedTable}({fk.referencedColumns.join(", ")})</span>
                                  </div>
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                        )}
                      </div>
                    </ScrollArea>
                  </TabsContent>

                  {/* ── Query Builder Tab ── */}
                  <TabsContent value="query" className="flex-1 overflow-hidden mt-0 p-4">
                    <ScrollArea className="h-full">
                      <div className="space-y-4">
                        {/* Column Selection */}
                        <Card>
                          <CardHeader className="pb-2">
                            <div className="flex items-center justify-between">
                              <CardTitle className="text-sm">Select Columns</CardTitle>
                              <div className="flex gap-1">
                                <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={selectAllColumns}>All</Button>
                                <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={clearAllColumns}>None</Button>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-2 gap-0.5">
                              {selectedTableMeta?.columns.map(col => (
                                <div
                                  key={col.columnName}
                                  className={`flex items-center gap-1.5 p-1.5 rounded cursor-pointer hover:bg-muted/50 transition-colors ${selectedColumns.has(col.columnName) ? "bg-primary/5 border border-primary/20" : ""}`}
                                  onClick={() => toggleColumn(col.columnName)}
                                >
                                  <Checkbox checked={selectedColumns.has(col.columnName)} className="h-3 w-3 flex-shrink-0" />
                                  {col.isKey && <Key className="h-2.5 w-2.5 text-yellow-500 flex-shrink-0" />}
                                  <span className="font-mono text-xs truncate">{col.columnName}</span>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>

                        {/* Filters */}
                        <Card>
                          <CardHeader className="pb-2">
                            <div className="flex items-center justify-between">
                              <CardTitle className="text-sm flex items-center gap-1"><Filter className="h-3.5 w-3.5" />Filter Conditions</CardTitle>
                              <Button size="sm" variant="outline" className="h-6 text-xs" onClick={addFilter}>+ Add Filter</Button>
                            </div>
                          </CardHeader>
                          <CardContent>
                            {filters.length === 0 ? (
                              <p className="text-xs text-muted-foreground text-center py-3">No filters — returns all rows</p>
                            ) : (
                              <div className="space-y-2">
                                {filters.map(f => (
                                  <div key={f.id} className="flex items-center gap-2">
                                    <Select value={f.column} onValueChange={v => updateFilter(f.id, "column", v)}>
                                      <SelectTrigger className="h-7 text-xs w-40">
                                        <SelectValue placeholder="Column" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {selectedTableMeta?.columns.map(c => (
                                          <SelectItem key={c.columnName} value={c.columnName} className="text-xs font-mono">{c.columnName}</SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                    <Select value={f.operator} onValueChange={v => updateFilter(f.id, "operator", v)}>
                                      <SelectTrigger className="h-7 text-xs w-36">
                                        <SelectValue placeholder="Operator" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {OPERATORS.map(op => (
                                          <SelectItem key={op.value} value={op.value} className="text-xs">{op.label}</SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                    {!["is_null", "is_not_null"].includes(f.operator) && (
                                      <Input
                                        value={f.value}
                                        onChange={e => updateFilter(f.id, "value", e.target.value)}
                                        placeholder={f.operator === "between" ? "val1, val2" : f.operator === "in" ? "v1, v2, v3" : "value"}
                                        className="h-7 text-xs flex-1"
                                      />
                                    )}
                                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => removeFilter(f.id)}>
                                      <X className="h-3.5 w-3.5" />
                                    </Button>
                                  </div>
                                ))}
                              </div>
                            )}
                          </CardContent>
                        </Card>

                        {/* Sort */}
                        <Card>
                          <CardHeader className="pb-2"><CardTitle className="text-sm">Sort Order</CardTitle></CardHeader>
                          <CardContent>
                            <div className="flex items-center gap-2">
                              <Select value={orderBy} onValueChange={setOrderBy}>
                                <SelectTrigger className="h-7 text-xs flex-1">
                                  <SelectValue placeholder="Sort by column (optional)" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="" className="text-xs">No sort</SelectItem>
                                  {selectedTableMeta?.columns.map(c => (
                                    <SelectItem key={c.columnName} value={c.columnName} className="text-xs font-mono">{c.columnName}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <Select value={orderDir} onValueChange={v => setOrderDir(v as "ASC" | "DESC")}>
                                <SelectTrigger className="h-7 text-xs w-24">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="ASC" className="text-xs">ASC ↑</SelectItem>
                                  <SelectItem value="DESC" className="text-xs">DESC ↓</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Action Buttons */}
                        <div className="flex gap-2">
                          <Button className="flex-1" onClick={handlePreview} disabled={isExecuting || selectedColumns.size === 0}>
                            {isExecuting ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Play className="h-4 w-4 mr-1" />}
                            Preview 100 Rows
                          </Button>
                          <Button variant="outline" className="flex-1" onClick={handleExecute} disabled={isExecuting || selectedColumns.size === 0}>
                            {isExecuting ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <BarChart3 className="h-4 w-4 mr-1" />}
                            Execute Full Query
                          </Button>
                        </div>
                      </div>
                    </ScrollArea>
                  </TabsContent>

                  {/* ── Join Tab ── */}
                  <TabsContent value="join" className="flex-1 overflow-hidden mt-0 p-4">
                    <ScrollArea className="h-full">
                      <div className="space-y-4">
                        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-start gap-2">
                          <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                          <p className="text-xs text-blue-700">
                            Cross-table join: select columns from <strong>{selectedTable}</strong> (left) and another table (right).
                            Tables are joined via a shared key column (e.g. LOT_ID, WAFER_ID, EQUIPMENT_ID).
                          </p>
                        </div>

                        {/* Left table columns */}
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm">Left Table: {selectedTable}</CardTitle>
                            <CardDescription className="text-xs">Select columns to include from left table</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-2 gap-0.5">
                              {selectedTableMeta?.columns.map(col => (
                                <div key={col.columnName} className={`flex items-center gap-1.5 p-1.5 rounded cursor-pointer hover:bg-muted/50 ${selectedColumns.has(col.columnName) ? "bg-primary/5 border border-primary/20" : ""}`} onClick={() => toggleColumn(col.columnName)}>
                                  <Checkbox checked={selectedColumns.has(col.columnName)} className="h-3 w-3" />
                                  <span className="font-mono text-xs truncate">{col.columnName}</span>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>

                        {/* Join config */}
                        <Card>
                          <CardHeader className="pb-2"><CardTitle className="text-sm">Join Configuration</CardTitle></CardHeader>
                          <CardContent className="space-y-3">
                            <div className="grid grid-cols-3 gap-2">
                              <div>
                                <label className="text-xs font-medium mb-1 block">Right Table</label>
                                <Select value={joinConfig.rightTable} onValueChange={v => setJoinConfig(prev => ({ ...prev, rightTable: v, rightColumns: [] }))}>
                                  <SelectTrigger className="h-7 text-xs">
                                    <SelectValue placeholder="Select table" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {tables?.filter(t => t.tableName !== selectedTable).map(t => (
                                      <SelectItem key={t.tableName} value={t.tableName} className="text-xs font-mono">{t.tableName}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <label className="text-xs font-medium mb-1 block">Join Key Column</label>
                                <Select value={joinConfig.joinColumn} onValueChange={v => setJoinConfig(prev => ({ ...prev, joinColumn: v }))}>
                                  <SelectTrigger className="h-7 text-xs">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {["LOT_ID", "WAFER_ID", "EQUIPMENT_ID"].map(k => (
                                      <SelectItem key={k} value={k} className="text-xs font-mono">{k}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <label className="text-xs font-medium mb-1 block">Join Type</label>
                                <Select value={joinConfig.joinType} onValueChange={v => setJoinConfig(prev => ({ ...prev, joinType: v as any }))}>
                                  <SelectTrigger className="h-7 text-xs">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="INNER" className="text-xs">INNER JOIN</SelectItem>
                                    <SelectItem value="LEFT" className="text-xs">LEFT JOIN</SelectItem>
                                    <SelectItem value="RIGHT" className="text-xs">RIGHT JOIN</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Right table columns */}
                        {joinConfig.rightTable && (
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-sm">Right Table: {joinConfig.rightTable}</CardTitle>
                              <CardDescription className="text-xs">Select columns to include from right table</CardDescription>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-2 gap-0.5">
                                {tables?.find(t => t.tableName === joinConfig.rightTable)?.columns.map(col => (
                                  <div
                                    key={col.columnName}
                                    className={`flex items-center gap-1.5 p-1.5 rounded cursor-pointer hover:bg-muted/50 ${joinConfig.rightColumns.includes(col.columnName) ? "bg-primary/5 border border-primary/20" : ""}`}
                                    onClick={() => setJoinConfig(prev => ({
                                      ...prev,
                                      rightColumns: prev.rightColumns.includes(col.columnName)
                                        ? prev.rightColumns.filter(c => c !== col.columnName)
                                        : [...prev.rightColumns, col.columnName],
                                    }))}
                                  >
                                    <Checkbox checked={joinConfig.rightColumns.includes(col.columnName)} className="h-3 w-3" />
                                    <span className="font-mono text-xs truncate">{col.columnName}</span>
                                  </div>
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                        )}

                        <Button className="w-full" onClick={handleJoin} disabled={isExecuting || !joinConfig.rightTable || joinConfig.rightColumns.length === 0 || selectedColumns.size === 0}>
                          {isExecuting ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <GitBranch className="h-4 w-4 mr-1" />}
                          Execute Join Query (100 rows preview)
                        </Button>
                      </div>
                    </ScrollArea>
                  </TabsContent>

                  {/* ── Results Tab ── */}
                  <TabsContent value="results" className="flex-1 overflow-hidden mt-0 flex flex-col">
                    {queryResult && (
                      <>
                        <div className="px-4 py-2 border-b border-border flex items-center gap-3 flex-shrink-0 bg-muted/20">
                          <CheckCircle2 className="h-4 w-4 text-green-600" />
                          <span className="text-sm font-medium">{queryResult.rowCount} rows returned</span>
                          {queryResult.totalCount && queryResult.totalCount > queryResult.rowCount && (
                            <span className="text-xs text-muted-foreground">of {queryResult.totalCount.toLocaleString()} total</span>
                          )}
                          <span className="text-xs text-muted-foreground">{queryResult.durationMs}ms</span>
                          <div className="ml-auto flex gap-2">
                            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setActiveTab("query")}>
                              <RefreshCw className="h-3 w-3 mr-1" />Modify Query
                            </Button>
                            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={handleDownloadCsv}>
                              <Download className="h-3 w-3 mr-1" />Download CSV
                            </Button>
                          </div>
                        </div>
                        {/* SQL display */}
                        <div className="px-4 py-2 border-b border-border bg-muted/10 flex-shrink-0">
                          <div className="flex items-center gap-1.5 mb-1">
                            <Code2 className="h-3 w-3 text-muted-foreground" />
                            <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Generated SQL</span>
                          </div>
                          <pre className="text-[10px] font-mono text-foreground bg-muted/50 p-2 rounded overflow-x-auto whitespace-pre-wrap">{queryResult.sql}</pre>
                        </div>
                        {/* Data table */}
                        <div className="flex-1 overflow-auto">
                          <table className="w-full text-xs border-collapse">
                            <thead className="sticky top-0 bg-muted/80 backdrop-blur-sm z-10">
                              <tr>
                                <th className="text-left p-2 border-b border-border text-muted-foreground font-medium w-10">#</th>
                                {queryResult.columns.map(col => (
                                  <th key={col} className="text-left p-2 border-b border-border font-mono font-medium whitespace-nowrap">{col}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {queryResult.rows.map((row, i) => (
                                <tr key={i} className={`border-b border-border/50 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                                  <td className="p-2 text-muted-foreground">{i + 1}</td>
                                  {queryResult.columns.map(col => (
                                    <td key={col} className="p-2 font-mono whitespace-nowrap max-w-[200px] truncate">
                                      {row[col] === null || row[col] === undefined ? (
                                        <span className="text-muted-foreground italic">NULL</span>
                                      ) : row[col] instanceof Date ? (
                                        new Date(row[col]).toLocaleString()
                                      ) : (
                                        String(row[col])
                                      )}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
            </>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
