import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Search, ArrowRight, Trash2, Table2, Clock } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

export default function DatasetList() {
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");

  const { data: drafts = [], refetch } = trpc.datasets.list.useQuery();
  const createMutation = trpc.datasets.create.useMutation({
    onSuccess: (draft: any) => {
      toast.success("Dataset created");
      setShowCreate(false);
      setNewName("");
      setNewDesc("");
      navigate(`/datasets/${draft.id}/columns`);
    },
    onError: (e) => toast.error(e.message),
  });
  const deleteMutation = trpc.datasets.delete.useMutation({
    onSuccess: () => { toast.success("Dataset deleted"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const filtered = (drafts as any[]).filter(d =>
    !search || d.name.toLowerCase().includes(search.toLowerCase())
  );

  const statusStepMap: Record<string, string> = {
    draft: "columns",
    columns_selected: "requirement",
    requirements_set: "criteria",
    criteria_set: "review",
    sql_generated: "review",
    preview_approved: "preview",
    executing: "execute",
    completed: "execute",
    failed: "review",
  };

  return (
    <AppLayout>
      <div className="p-6 max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl font-bold text-foreground">My Datasets</h1>
            <p className="text-sm text-muted-foreground">Create and manage your data query definitions</p>
          </div>
          <Button onClick={() => setShowCreate(true)} className="gap-2">
            <Plus className="w-4 h-4" /> New Dataset
          </Button>
        </div>

        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search datasets..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        {filtered.length === 0 ? (
          <Card>
            <CardContent className="py-16 text-center">
              <Table2 className="w-12 h-12 mx-auto mb-3 text-muted-foreground/30" />
              <p className="text-sm font-medium text-muted-foreground">No datasets yet</p>
              <p className="text-xs text-muted-foreground mt-1">Create your first dataset to get started</p>
              <Button className="mt-4 gap-2" onClick={() => setShowCreate(true)}>
                <Plus className="w-4 h-4" /> Create Dataset
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {filtered.map((draft: any) => {
              const step = statusStepMap[draft.status] ?? "columns";
              return (
                <Card key={draft.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Table2 className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-foreground truncate">{draft.name}</p>
                        <StatusBadge status={draft.status} />
                      </div>
                      {draft.description && <p className="text-xs text-muted-foreground truncate mt-0.5">{draft.description}</p>}
                      <div className="flex items-center gap-1 mt-1">
                        <Clock className="w-3 h-3 text-muted-foreground" />
                        <span className="text-[10px] text-muted-foreground">{new Date(draft.updatedAt).toLocaleString()}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => { if (confirm("Delete this dataset?")) deleteMutation.mutate({ id: draft.id }); }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      <Link href={`/datasets/${draft.id}/${step}`}>
                        <Button size="sm" className="gap-1">
                          {draft.status === "completed" ? "View" : "Continue"} <ArrowRight className="w-3 h-3" />
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Create Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Dataset</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label>Dataset Name *</Label>
              <Input placeholder="e.g. Wafer Yield Analysis Q3" value={newName} onChange={e => setNewName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Description</Label>
              <Textarea placeholder="Describe what data you need..." value={newDesc} onChange={e => setNewDesc(e.target.value)} rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button
              onClick={() => createMutation.mutate({ name: newName, description: newDesc })}
              disabled={!newName.trim() || createMutation.isPending}
            >
              {createMutation.isPending ? "Creating..." : "Create & Start"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; className: string }> = {
    draft: { label: "Draft", className: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400" },
    columns_selected: { label: "Columns Set", className: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300" },
    requirements_set: { label: "Requirements", className: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300" },
    criteria_set: { label: "Criteria Set", className: "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300" },
    sql_generated: { label: "SQL Ready", className: "bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300" },
    preview_approved: { label: "Preview OK", className: "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300" },
    executing: { label: "Running", className: "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300" },
    completed: { label: "Completed", className: "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300" },
    failed: { label: "Failed", className: "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300" },
  };
  const s = map[status] ?? { label: status, className: "bg-gray-100 text-gray-600" };
  return <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${s.className}`}>{s.label}</span>;
}

