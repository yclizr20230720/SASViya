import { useState, useEffect } from "react";
import AppLayout from "@/components/AppLayout";
import WizardSteps from "@/components/WizardSteps";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { ArrowRight, Database, Key, Plus, Trash2, ChevronRight, Table2, GitBranch, Info, CheckSquare, Search } from "lucide-react";
import { Link, useLocation, useParams } from "wouter";
import { toast } from "sonner";
import { WIZARD_STEPS } from "./wizardConfig";
import type { DatasetDefinition } from "../../../drizzle/schema";
import { Input } from "@/components/ui/input";

// ── Types ──────────────────────────────────────────────────────────────────────
type FabColumnSel = { tableName: string; columns: string[] };
type FabJoin = { leftTable: string; leftColumn: string; rightTable: string; rightColumn: string; joinType: "INNER" | "LEFT" | "RIGHT" };

const DOMAIN_COLORS: Record<string, string> = {
  lot_tracking:    "bg-blue-100 text-blue-700 border-blue-200",
  wafer_tracking:  "bg-indigo-100 text-indigo-700 border-indigo-200",
  equipment:       "bg-orange-100 text-orange-700 border-orange-200",
  yield:           "bg-green-100 text-green-700 border-green-200",
  fault_detection: "bg-red-100 text-red-700 border-red-200",
  metrology:       "bg-purple-100 text-purple-700 border-purple-200",
  defect:          "bg-yellow-100 text-yellow-700 border-yellow-200",
};

// Shared join keys between tables
const JOIN_KEY_SUGGESTIONS: Record<string, string[]> = {
  LOT_HISTORY:       ["LOT_ID"],
  WAFER_HISTORY:     ["LOT_ID", "WAFER_ID", "EQUIPMENT_ID"],
  EQUIPMENT_TOOL:    ["EQUIPMENT_ID"],
  WAT_DATA:          ["LOT_ID", "WAFER_ID"],
  CP_DATA:           ["LOT_ID", "WAFER_ID"],
  FDC_DATA:          ["LOT_ID", "WAFER_ID", "EQUIPMENT_ID"],
  INLINE_THICKNESS:  ["LOT_ID", "WAFER_ID", "EQUIPMENT_ID"],
  CD_MEASUREMENT:    ["LOT_ID", "WAFER_ID", "EQUIPMENT_ID"],
  DEFECT_INSPECTION: ["LOT_ID", "WAFER_ID", "EQUIPMENT_ID"],
  EQUIPMENT_PM:      ["EQUIPMENT_ID"],
};

export default function DatasetColumns() {
  const { id } = useParams<{ id: string }>();
  const draftId = parseInt(id);
  const [, navigate] = useLocation();

  const { data: draft, refetch } = trpc.datasets.getById.useQuery({ id: draftId });
  const { data: fabTables = [], isLoading: tablesLoading } = trpc.fabData.listTables.useQuery();

  const [activeTable, setActiveTable] = useState<string | null>(null);
  const [selections, setSelections] = useState<FabColumnSel[]>([]);
  const [joins, setJoins] = useState<FabJoin[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showJoinPanel, setShowJoinPanel] = useState(false);

  // Restore from draft
  useEffect(() => {
    if (draft?.definitionJson) {
      const def = draft.definitionJson as any;
      if (def.fabSelections) setSelections(def.fabSelections);
      if (def.fabJoins) setJoins(def.fabJoins);
    }
  }, [draft]);

  const patchMutation = trpc.datasets.patch.useMutation({
    onSuccess: () => {
      toast.success("Column selections saved");
      refetch();
      navigate(`/datasets/${draftId}/requirement`);
    },
    onError: (e) => toast.error(e.message),
  });

  const activeTableMeta = fabTables.find(t => t.tableName === activeTable);
  const filteredTables = fabTables.filter(t =>
    t.tableName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (t.comment ?? "").toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTableSelection = (tableName: string) => selections.find(s => s.tableName === tableName);
  const isColumnSelected = (tableName: string, col: string) => getTableSelection(tableName)?.columns.includes(col) ?? false;

  const toggleColumn = (col: string) => {
    if (!activeTable) return;
    setSelections(prev => {
      const existing = prev.find(s => s.tableName === activeTable);
      if (existing) {
        const newCols = existing.columns.includes(col)
          ? existing.columns.filter(c => c !== col)
          : [...existing.columns, col];
        if (newCols.length === 0) return prev.filter(s => s.tableName !== activeTable);
        return prev.map(s => s.tableName === activeTable ? { ...s, columns: newCols } : s);
      }
      return [...prev, { tableName: activeTable, columns: [col] }];
    });
  };

  const selectAllColumns = () => {
    if (!activeTable || !activeTableMeta) return;
    const allCols = activeTableMeta.columns.map(c => c.columnName);
    setSelections(prev => {
      const filtered = prev.filter(s => s.tableName !== activeTable);
      return [...filtered, { tableName: activeTable, columns: allCols }];
    });
    toast.success(`All ${allCols.length} columns selected for ${activeTable}`);
  };

  const clearTableSelection = (tableName: string) => {
    setSelections(prev => prev.filter(s => s.tableName !== tableName));
    setJoins(prev => prev.filter(j => j.leftTable !== tableName && j.rightTable !== tableName));
  };

  const addAutoJoin = (leftTable: string, rightTable: string) => {
    const leftKeys = JOIN_KEY_SUGGESTIONS[leftTable] ?? [];
    const rightKeys = JOIN_KEY_SUGGESTIONS[rightTable] ?? [];
    const sharedKey = leftKeys.find(k => rightKeys.includes(k));
    if (!sharedKey) { toast.error(`No common join key found between ${leftTable} and ${rightTable}`); return; }
    const alreadyExists = joins.some(j => j.leftTable === leftTable && j.rightTable === rightTable);
    if (alreadyExists) { toast.info("Join already defined"); return; }
    setJoins(prev => [...prev, { leftTable, leftColumn: sharedKey, rightTable, rightColumn: sharedKey, joinType: "INNER" }]);
    toast.success(`Auto-join added: ${leftTable}.${sharedKey} = ${rightTable}.${sharedKey}`);
  };

  const handleSave = () => {
    if (selections.length === 0) { toast.error("Select at least one column"); return; }
    const def = (draft?.definitionJson || {}) as DatasetDefinition;
    const totalCols = selections.reduce((a, s) => a + s.columns.length, 0);
    patchMutation.mutate({
      id: draftId,
      status: "columns_selected",
      definitionJson: {
        ...def,
        fabSelections: selections,
        fabJoins: joins,
        // Legacy compat
        selections: selections.map(s => ({ sourceId: 1, schemaName: "VEDA", tableName: s.tableName, columns: s.columns })),
        joins: joins.map(j => ({ leftSourceId: 1, leftSchema: "VEDA", leftTable: j.leftTable, leftColumn: j.leftColumn, rightSourceId: 1, rightSchema: "VEDA", rightTable: j.rightTable, rightColumn: j.rightColumn, joinType: j.joinType })),
      },
    });
  };

  const totalColumns = selections.reduce((a, s) => a + s.columns.length, 0);
  const completedSteps = draft ? getCompletedSteps(draft.status as string) : [];

  return (
    <AppLayout>
      <div className="flex flex-col h-[calc(100vh-56px)] overflow-hidden">
        {/* ── Header ── */}
        <div className="px-6 py-4 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
            <Link href="/datasets"><span className="hover:text-foreground cursor-pointer">Datasets</span></Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground font-medium">{draft?.name}</span>
          </div>
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold">Select Columns</h1>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="text-sm px-3 py-1">
                {totalColumns} columns · {selections.length} tables
              </Badge>
              <Button onClick={handleSave} disabled={patchMutation.isPending || totalColumns === 0} className="gap-2">
                Save & Continue <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* ── Wizard Steps ── */}
        <div className="px-6 py-3 border-b border-border flex-shrink-0 overflow-x-auto">
          <WizardSteps steps={WIZARD_STEPS} currentStep="columns" completedSteps={completedSteps} />
        </div>

        {/* ── Main 3-panel layout ── */}
        <div className="flex flex-1 overflow-hidden">

          {/* Panel 1: Table List */}
          <div className="w-64 flex-shrink-0 border-r border-border flex flex-col bg-muted/10">
            <div className="p-3 border-b border-border">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Fab Tables</p>
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                <Input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Search..." className="pl-6 h-7 text-xs" />
              </div>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-2 space-y-0.5">
                {filteredTables.map(table => {
                  const sel = getTableSelection(table.tableName);
                  const isActive = activeTable === table.tableName;
                  return (
                    <button
                      key={table.tableName}
                      onClick={() => setActiveTable(table.tableName)}
                      className={`w-full text-left p-2 rounded-lg transition-all text-xs ${isActive ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
                    >
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <Table2 className="h-3 w-3 flex-shrink-0" />
                        <span className="font-mono font-semibold truncate flex-1">{table.tableName}</span>
                        {sel && (
                          <Badge className={`text-[9px] h-4 px-1 ${isActive ? "bg-primary-foreground/20 text-primary-foreground" : "bg-primary text-primary-foreground"}`}>
                            {sel.columns.length}
                          </Badge>
                        )}
                      </div>
                      <span className={`text-[10px] ${isActive ? "text-primary-foreground/70" : DOMAIN_COLORS[table.businessDomain ?? ""] ? "" : "text-muted-foreground"}`}>
                        <span className={`px-1 py-0.5 rounded-sm text-[9px] ${isActive ? "bg-primary-foreground/20" : DOMAIN_COLORS[table.businessDomain ?? ""] ?? "bg-muted"}`}>
                          {table.businessDomain?.replace("_", " ")}
                        </span>
                        {" "}{table.columnCount}c
                      </span>
                    </button>
                  );
                })}
              </div>
            </ScrollArea>
          </div>

          {/* Panel 2: Column Picker */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {!activeTable ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <Table2 className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                  <p className="text-sm font-medium text-muted-foreground">Select a table to view columns</p>
                  <p className="text-xs text-muted-foreground mt-1">10 fab tables available · 2,100+ rows of real data</p>
                </div>
              </div>
            ) : (
              <>
                <div className="px-4 py-3 border-b border-border flex items-center justify-between flex-shrink-0">
                  <div>
                    <h2 className="font-semibold text-sm flex items-center gap-2">
                      <Table2 className="h-4 w-4 text-primary" />
                      {activeTable}
                    </h2>
                    <p className="text-xs text-muted-foreground mt-0.5">{activeTableMeta?.comment}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">
                      {getTableSelection(activeTable)?.columns.length ?? 0} / {activeTableMeta?.columnCount} selected
                    </span>
                    <Button size="sm" variant="outline" className="h-7 text-xs" onClick={selectAllColumns}>
                      <CheckSquare className="h-3 w-3 mr-1" />Select All
                    </Button>
                    {getTableSelection(activeTable) && (
                      <Button size="sm" variant="ghost" className="h-7 text-xs text-destructive hover:text-destructive" onClick={() => clearTableSelection(activeTable)}>
                        <Trash2 className="h-3 w-3 mr-1" />Clear
                      </Button>
                    )}
                  </div>
                </div>
                <ScrollArea className="flex-1 p-4">
                  <div className="grid grid-cols-2 gap-1">
                    {activeTableMeta?.columns.map(col => {
                      const selected = isColumnSelected(activeTable, col.columnName);
                      return (
                        <label
                          key={col.columnName}
                          className={`flex items-start gap-2 p-2 rounded-lg cursor-pointer transition-all hover:bg-muted/50 ${selected ? "bg-primary/5 border border-primary/20" : "border border-transparent"}`}
                        >
                          <Checkbox
                            checked={selected}
                            onCheckedChange={() => toggleColumn(col.columnName)}
                            className="mt-0.5 h-3.5 w-3.5 flex-shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1">
                              {col.isKey && <Key className="h-2.5 w-2.5 text-yellow-500 flex-shrink-0" />}
                              <span className="text-xs font-mono font-medium truncate">{col.columnName}</span>
                            </div>
                            <div className="flex items-center gap-1 mt-0.5">
                              <span className="text-[10px] text-muted-foreground">{col.dataType}</span>
                              {col.isIndexed && !col.isKey && <span className="text-[9px] px-1 bg-blue-50 text-blue-600 rounded">IDX</span>}
                            </div>
                            {col.comment && <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{col.comment}</p>}
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </ScrollArea>
              </>
            )}
          </div>

          {/* Panel 3: Selection Summary + Join Config */}
          <div className="w-72 flex-shrink-0 border-l border-border flex flex-col bg-muted/10">
            <div className="p-3 border-b border-border">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Selected Tables</p>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-3 space-y-2">
                {selections.length === 0 ? (
                  <div className="text-center py-8">
                    <Database className="h-8 w-8 text-muted-foreground/30 mx-auto mb-2" />
                    <p className="text-xs text-muted-foreground">No columns selected yet</p>
                    <p className="text-[10px] text-muted-foreground mt-1">Click a table on the left, then check columns</p>
                  </div>
                ) : (
                  selections.map(sel => {
                    const meta = fabTables.find(t => t.tableName === sel.tableName);
                    return (
                      <div key={sel.tableName} className={`p-2.5 rounded-lg border ${activeTable === sel.tableName ? "border-primary bg-primary/5" : "border-border bg-card"}`}>
                        <div className="flex items-center justify-between mb-1.5">
                          <button className="font-mono text-xs font-semibold hover:text-primary" onClick={() => setActiveTable(sel.tableName)}>
                            {sel.tableName}
                          </button>
                          <button onClick={() => clearTableSelection(sel.tableName)} className="text-muted-foreground hover:text-destructive transition-colors">
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {sel.columns.slice(0, 6).map(c => (
                            <span key={c} className="text-[9px] font-mono px-1 py-0.5 bg-muted rounded">{c}</span>
                          ))}
                          {sel.columns.length > 6 && (
                            <span className="text-[9px] text-muted-foreground">+{sel.columns.length - 6} more</span>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}

                {/* Auto-Join Suggestions */}
                {selections.length >= 2 && (
                  <>
                    <Separator className="my-2" />
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                          <GitBranch className="h-3 w-3" />Joins ({joins.length})
                        </p>
                        <Button size="sm" variant="ghost" className="h-6 text-[10px]" onClick={() => setShowJoinPanel(!showJoinPanel)}>
                          {showJoinPanel ? "Hide" : "Configure"}
                        </Button>
                      </div>

                      {/* Existing joins */}
                      {joins.map((j, i) => (
                        <div key={i} className="flex items-center gap-1 p-1.5 bg-green-50 border border-green-200 rounded text-[10px] mb-1">
                          <span className="font-mono text-green-700 truncate flex-1">{j.leftTable}.{j.leftColumn} = {j.rightTable}.{j.rightColumn}</span>
                          <button onClick={() => setJoins(prev => prev.filter((_, idx) => idx !== i))} className="text-destructive flex-shrink-0">
                            <Trash2 className="h-2.5 w-2.5" />
                          </button>
                        </div>
                      ))}

                      {/* Auto-join suggestions */}
                      {showJoinPanel && (
                        <div className="space-y-1 mt-2">
                          <p className="text-[10px] text-muted-foreground mb-1">Suggested joins:</p>
                          {selections.flatMap((left, li) =>
                            selections.slice(li + 1).map(right => {
                              const leftKeys = JOIN_KEY_SUGGESTIONS[left.tableName] ?? [];
                              const rightKeys = JOIN_KEY_SUGGESTIONS[right.tableName] ?? [];
                              const sharedKey = leftKeys.find(k => rightKeys.includes(k));
                              if (!sharedKey) return null;
                              const alreadyAdded = joins.some(j => j.leftTable === left.tableName && j.rightTable === right.tableName);
                              return (
                                <button
                                  key={`${left.tableName}-${right.tableName}`}
                                  onClick={() => addAutoJoin(left.tableName, right.tableName)}
                                  disabled={alreadyAdded}
                                  className={`w-full text-left p-1.5 rounded border text-[10px] transition-colors ${alreadyAdded ? "bg-green-50 border-green-200 text-green-700" : "bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"}`}
                                >
                                  {alreadyAdded ? "✓ " : "+ "}
                                  {left.tableName} ↔ {right.tableName} via {sharedKey}
                                </button>
                              );
                            }).filter(Boolean)
                          )}
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            </ScrollArea>

            {/* Bottom action */}
            <div className="p-3 border-t border-border">
              <Button
                className="w-full gap-2"
                onClick={handleSave}
                disabled={patchMutation.isPending || totalColumns === 0}
              >
                {patchMutation.isPending ? "Saving..." : <>Save & Continue <ArrowRight className="h-4 w-4" /></>}
              </Button>
              {totalColumns > 0 && (
                <p className="text-[10px] text-muted-foreground text-center mt-1.5">
                  {totalColumns} columns from {selections.length} table{selections.length > 1 ? "s" : ""}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function getCompletedSteps(status: string): string[] {
  const order = ["columns", "requirement", "criteria", "review", "preview", "execute"];
  const statusMap: Record<string, string> = {
    draft: "", columns_selected: "columns", requirements_set: "requirement",
    criteria_set: "criteria", sql_generated: "review", preview_approved: "preview", completed: "execute",
  };
  const current = statusMap[status] ?? "";
  const idx = order.indexOf(current);
  return order.slice(0, idx);
}
