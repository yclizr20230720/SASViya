import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import WizardSteps from "@/components/WizardSteps";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ArrowRight, ArrowLeft, ChevronRight, Play, CheckCircle2, Table2, Loader2, Code2, Clock, Download } from "lucide-react";
import { Link, useLocation, useParams } from "wouter";
import { toast } from "sonner";
import { WIZARD_STEPS } from "./wizardConfig";

export default function DatasetPreview() {
  const { id } = useParams<{ id: string }>();
  const draftId = parseInt(id);
  const [, navigate] = useLocation();

  const { data: draft, refetch } = trpc.datasets.getById.useQuery({ id: draftId });
  const def = (draft?.definitionJson || {}) as any;

  const previewMutation = trpc.fabDataset.previewData.useMutation({
    onSuccess: () => { toast.success("Preview loaded — 100 rows"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const completedSteps = draft ? getCompletedSteps(draft.status as string) : [];
  const previewResult = def.previewResult;

  const handleDownloadPreviewCsv = () => {
    if (!previewResult) return;
    const header = previewResult.columns.join(",");
    const rows = previewResult.rows.map((r: any) =>
      previewResult.columns.map((c: string) => {
        const v = r[c] ?? "";
        return typeof v === "string" && v.includes(",") ? `"${v}"` : v;
      }).join(",")
    );
    const csv = [header, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${draft?.name ?? "preview"}_preview.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <AppLayout>
      <div className="p-6 max-w-6xl mx-auto">
        <div className="mb-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
            <Link href="/datasets"><span className="hover:text-foreground cursor-pointer">Datasets</span></Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground font-medium">{draft?.name}</span>
          </div>
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold">Data Preview</h1>
            <div className="flex gap-2">
              <Link href={`/datasets/${draftId}/review`}>
                <Button variant="outline" size="sm" className="gap-1"><ArrowLeft className="w-3 h-3" /> Back</Button>
              </Link>
              {!previewResult ? (
                <Button onClick={() => previewMutation.mutate({ id: draftId })} disabled={previewMutation.isPending} className="gap-2">
                  {previewMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                  {previewMutation.isPending ? "Running Query..." : "Run Preview (100 rows)"}
                </Button>
              ) : (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleDownloadPreviewCsv} className="gap-1">
                    <Download className="w-3.5 h-3.5" />CSV
                  </Button>
                  <Button onClick={() => navigate(`/datasets/${draftId}/execute`)} className="gap-2 bg-green-600 hover:bg-green-700">
                    <CheckCircle2 className="w-4 h-4" /> Approve & Execute Full Query
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mb-5 overflow-x-auto">
          <WizardSteps steps={WIZARD_STEPS} currentStep="preview" completedSteps={completedSteps} />
        </div>

        {!previewResult ? (
          <Card className="border-dashed">
            <CardContent className="py-16 text-center">
              <Table2 className="w-12 h-12 mx-auto mb-3 text-muted-foreground/30" />
              <p className="text-sm font-medium text-muted-foreground">No preview data yet</p>
              <p className="text-xs mt-1 text-muted-foreground">Click "Run Preview" to execute a 100-row sample query against the real fab database</p>
              <Button className="mt-4 gap-2" onClick={() => previewMutation.mutate({ id: draftId })} disabled={previewMutation.isPending}>
                {previewMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                {previewMutation.isPending ? "Querying database..." : "Run Preview"}
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {/* Stats bar */}
            <div className="flex items-center gap-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0" />
              <div className="flex items-center gap-6 text-sm">
                <span><strong className="text-green-800">{previewResult.rowCountShown}</strong> <span className="text-green-700">rows returned</span></span>
                <span><strong className="text-green-800">{previewResult.columns?.length}</strong> <span className="text-green-700">columns</span></span>
                <span className="flex items-center gap-1 text-green-700"><Clock className="h-3.5 w-3.5" />{previewResult.durationMs}ms</span>
              </div>
              <div className="ml-auto text-xs text-green-700">
                This is a 100-row sample. Click "Approve" to run the full query.
              </div>
            </div>

            {/* SQL used */}
            {def.generatedSql && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xs flex items-center gap-1.5 text-muted-foreground">
                    <Code2 className="h-3.5 w-3.5" />SQL Executed
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-[10px] font-mono bg-muted/50 p-3 rounded overflow-x-auto whitespace-pre-wrap">{def.generatedSql}</pre>
                </CardContent>
              </Card>
            )}

            {/* Results table */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  Preview Results
                  <Badge variant="outline" className="text-[10px]">{previewResult.rowCountShown} rows</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-auto max-h-[480px]">
                  <table className="w-full text-xs border-collapse">
                    <thead className="sticky top-0 bg-muted/90 backdrop-blur-sm z-10">
                      <tr>
                        <th className="text-left px-3 py-2 font-medium text-muted-foreground border-b border-border w-10">#</th>
                        {previewResult.columns?.map((col: string) => (
                          <th key={col} className="text-left px-3 py-2 font-mono font-semibold border-b border-border whitespace-nowrap">{col}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {previewResult.rows?.map((row: any, i: number) => (
                        <tr key={i} className={`hover:bg-accent/30 border-b border-border/50 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                          <td className="px-3 py-1.5 text-muted-foreground">{i + 1}</td>
                          {previewResult.columns?.map((col: string) => (
                            <td key={col} className="px-3 py-1.5 font-mono whitespace-nowrap max-w-[200px] truncate">
                              {row[col] === null || row[col] === undefined ? (
                                <span className="text-muted-foreground italic">NULL</span>
                              ) : (
                                String(row[col])
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

function getCompletedSteps(status: string): string[] {
  const order = ["columns", "requirement", "criteria", "review", "preview", "execute"];
  const statusMap: Record<string, string> = {
    draft: "", columns_selected: "columns", requirements_set: "requirement",
    criteria_set: "criteria", sql_generated: "review", preview_approved: "preview", completed: "execute",
  };
  const current = statusMap[status] ?? "";
  const idx = order.indexOf(current);
  return order.slice(0, idx);
}
