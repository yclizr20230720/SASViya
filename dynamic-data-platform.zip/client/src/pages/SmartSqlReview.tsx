/**
 * Smart SQL Review Page
 * Shows AI-generated SQL with:
 * - Join path visualization
 * - AI analysis results (business context, strategy, warnings)
 * - Performance evaluation findings
 * - SQL editor with syntax highlighting
 * - Approve/reject flow
 */
import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  Cpu, GitBranch, AlertTriangle, CheckCircle2, XCircle,
  Info, ArrowRight, ChevronRight, Loader2, Code2,
  Lightbulb, Shield, BarChart3, Play,
} from "lucide-react";

export default function SmartSqlReview() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const draftId = parseInt(id ?? "0");
  const [isGenerating, setIsGenerating] = useState(false);

  const { data: draft, refetch } = trpc.datasets.getById.useQuery({ id: draftId });

  const generateSql = trpc.schema.generateSmartSql.useMutation({
    onSuccess: () => {
      toast.success("AI analysis complete — SQL generated successfully");
      setIsGenerating(false);
      refetch();
    },
    onError: (err) => {
      toast.error(`Generation failed: ${err.message}`);
      setIsGenerating(false);
    },
  });

  const acknowledgeWarning = trpc.datasets.acknowledgeWarning.useMutation({
    onSuccess: () => { toast.success("Warning acknowledged"); refetch(); },
  });

  const handleGenerate = () => {
    setIsGenerating(true);
    generateSql.mutate({ draftId });
  };

  const def = draft?.definitionJson as any;
  const evaluation = def?.evaluation;
  const aiAnalysis = def?.aiAnalysis;
  const joinPath = def?.joinPath ?? [];
  const generatedSql = def?.generatedSql;

  const verdictConfig = {
    pass: { icon: CheckCircle2, color: "text-green-600", bg: "bg-green-50 border-green-200", label: "Ready to Execute" },
    warn: { icon: AlertTriangle, color: "text-yellow-600", bg: "bg-yellow-50 border-yellow-200", label: "Warnings Found" },
    block: { icon: XCircle, color: "text-red-600", bg: "bg-red-50 border-red-200", label: "Execution Blocked" },
  };

  const complexityConfig: Record<string, { color: string; label: string }> = {
    simple: { color: "text-green-600 bg-green-50", label: "Simple" },
    moderate: { color: "text-blue-600 bg-blue-50", label: "Moderate" },
    complex: { color: "text-orange-600 bg-orange-50", label: "Complex" },
    very_complex: { color: "text-red-600 bg-red-50", label: "Very Complex" },
  };

  return (
    <AppLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <span className="hover:text-foreground cursor-pointer" onClick={() => navigate("/datasets")}>My Datasets</span>
              <ChevronRight className="h-3 w-3" />
              <span>{draft?.name ?? "Loading..."}</span>
              <ChevronRight className="h-3 w-3" />
              <span className="text-foreground">AI SQL Review</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Cpu className="h-6 w-6 text-primary" />
              AI-Powered SQL Generation
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              LLM analyzes your column selections, infers join conditions, and generates optimized SQL
            </p>
          </div>
          <Button
            onClick={handleGenerate}
            disabled={isGenerating || !draft}
            className="gap-2"
          >
            {isGenerating ? (
              <><Loader2 className="h-4 w-4 animate-spin" />Analyzing with AI...</>
            ) : (
              <><Cpu className="h-4 w-4" />{generatedSql ? "Re-Generate SQL" : "Generate SQL with AI"}</>
            )}
          </Button>
        </div>

        {/* Selected Columns Summary */}
        {def?.selections && def.selections.length > 0 && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-primary" />
                Selected Columns ({def.selections.reduce((a: number, s: any) => a + s.columns.length, 0)} columns across {def.selections.length} tables)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {def.selections.map((sel: any) =>
                  sel.columns.map((col: string) => (
                    <Badge key={`${sel.tableName}.${col}`} variant="secondary" className="font-mono text-xs">
                      {sel.tableName}.{col}
                    </Badge>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {isGenerating && (
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="py-8">
              <div className="flex flex-col items-center gap-3">
                <Cpu className="h-8 w-8 text-primary animate-pulse" />
                <p className="font-medium text-foreground">AI is analyzing your schema...</p>
                <div className="text-sm text-muted-foreground text-center space-y-1">
                  <p>• Examining table structures, indexes, and foreign keys</p>
                  <p>• Inferring join conditions from business context</p>
                  <p>• Evaluating performance risks</p>
                  <p>• Generating optimized SQL</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {generatedSql && !isGenerating && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left: AI Analysis */}
            <div className="space-y-4">
              {/* Business Context */}
              {aiAnalysis?.businessContext && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Lightbulb className="h-4 w-4 text-yellow-500" />
                      Business Context
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-foreground">{aiAnalysis.businessContext}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs text-muted-foreground">Complexity:</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${complexityConfig[aiAnalysis.estimatedComplexity]?.color ?? "text-gray-600 bg-gray-50"}`}>
                        {complexityConfig[aiAnalysis.estimatedComplexity]?.label ?? aiAnalysis.estimatedComplexity}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Join Path */}
              {joinPath.length > 0 && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <GitBranch className="h-4 w-4 text-primary" />
                      Join Path ({joinPath.length} joins)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {joinPath.map((join: any, i: number) => (
                        <div key={i} className="p-2.5 border border-border rounded-lg">
                          <div className="flex items-center gap-2 flex-wrap text-xs">
                            <code className="bg-muted px-1.5 py-0.5 rounded font-mono">{join.leftTable}.{join.leftColumn}</code>
                            <ArrowRight className="h-3 w-3 text-muted-foreground" />
                            <Badge variant="outline" className="text-[10px] h-4 px-1">{join.joinType}</Badge>
                            <ArrowRight className="h-3 w-3 text-muted-foreground" />
                            <code className="bg-muted px-1.5 py-0.5 rounded font-mono">{join.rightTable}.{join.rightColumn}</code>
                          </div>
                          <div className="flex items-center gap-2 mt-1.5">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                              join.source === "foreign_key" ? "bg-green-50 text-green-600" :
                              join.source === "ai_inferred" ? "bg-purple-50 text-purple-600" :
                              "bg-blue-50 text-blue-600"
                            }`}>
                              {join.source === "foreign_key" ? "FK" : join.source === "ai_inferred" ? "AI" : "Named"}
                            </span>
                            <span className="text-[10px] text-muted-foreground">{Math.round(join.confidence * 100)}% confidence</span>
                            <span className="text-[10px] text-muted-foreground flex-1 truncate">{join.reasoning}</span>
                          </div>
                          {join.performanceNote && (
                            <p className="text-[10px] text-orange-600 mt-1 flex items-center gap-1">
                              <AlertTriangle className="h-2.5 w-2.5" />{join.performanceNote}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Performance Evaluation */}
              {evaluation && (
                <Card className={`border ${verdictConfig[evaluation.verdict as keyof typeof verdictConfig]?.bg}`}>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      {(() => {
                        const V = verdictConfig[evaluation.verdict as keyof typeof verdictConfig];
                        return V ? <V.icon className={`h-4 w-4 ${V.color}`} /> : <Shield className="h-4 w-4" />;
                      })()}
                      Performance Evaluation: {verdictConfig[evaluation.verdict as keyof typeof verdictConfig]?.label}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {evaluation.findings.length === 0 ? (
                      <p className="text-sm text-green-600">No performance issues detected.</p>
                    ) : (
                      <div className="space-y-2">
                        {evaluation.findings.map((f: any, i: number) => (
                          <div key={i} className={`p-2 rounded border text-xs ${f.severity === "block" ? "bg-red-50 border-red-200" : "bg-yellow-50 border-yellow-200"}`}>
                            <div className="flex items-start gap-1.5">
                              {f.severity === "block" ? <XCircle className="h-3 w-3 text-red-500 mt-0.5 flex-shrink-0" /> : <AlertTriangle className="h-3 w-3 text-yellow-500 mt-0.5 flex-shrink-0" />}
                              <div>
                                <p className="font-medium">{f.message}</p>
                                {f.details && <p className="text-muted-foreground mt-0.5">{f.details}</p>}
                              </div>
                            </div>
                          </div>
                        ))}
                        {evaluation.verdict === "warn" && !evaluation.userAcknowledged && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="w-full mt-2 border-yellow-300 text-yellow-700 hover:bg-yellow-50"
                            onClick={() => acknowledgeWarning.mutate({ id: draftId })}
                          >
                            <CheckCircle2 className="h-3.5 w-3.5 mr-1" />
                            Acknowledge Warnings & Proceed
                          </Button>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* AI Optimization Tips */}
              {aiAnalysis?.optimizationTips?.length > 0 && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Lightbulb className="h-4 w-4 text-blue-500" />
                      Optimization Tips
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-1">
                      {aiAnalysis.optimizationTips.map((tip: string, i: number) => (
                        <li key={i} className="text-xs text-foreground flex items-start gap-1.5">
                          <span className="text-blue-500 mt-0.5">•</span>{tip}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Right: Generated SQL */}
            <div className="space-y-4">
              <Card className="h-full">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Code2 className="h-4 w-4 text-primary" />
                    Generated SQL
                  </CardTitle>
                  {aiAnalysis?.queryStrategy && (
                    <CardDescription className="text-xs">{aiAnalysis.queryStrategy}</CardDescription>
                  )}
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    <pre className="text-xs font-mono bg-muted/50 p-4 rounded-lg whitespace-pre-wrap break-all leading-relaxed">
                      {generatedSql}
                    </pre>
                  </ScrollArea>
                  <div className="flex gap-2 mt-4">
                    <Button
                      className="flex-1"
                      disabled={evaluation?.verdict === "block" || (evaluation?.verdict === "warn" && !evaluation?.userAcknowledged)}
                      onClick={() => navigate(`/datasets/${draftId}/preview`)}
                    >
                      <Play className="h-4 w-4 mr-1" />
                      Preview 100 Rows
                    </Button>
                  </div>
                  {evaluation?.verdict === "block" && (
                    <p className="text-xs text-red-600 mt-2 text-center">
                      Execution blocked due to critical performance issues. Please revise your query.
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {!generatedSql && !isGenerating && (
          <Card className="border-dashed">
            <CardContent className="py-12">
              <div className="flex flex-col items-center gap-3 text-center">
                <Cpu className="h-10 w-10 text-muted-foreground opacity-40" />
                <p className="font-medium text-foreground">No SQL generated yet</p>
                <p className="text-sm text-muted-foreground max-w-md">
                  Click "Generate SQL with AI" to let the AI analyze your selected columns,
                  infer join conditions from schema relationships, and produce optimized SQL.
                </p>
                <Button onClick={handleGenerate} className="mt-2 gap-2">
                  <Cpu className="h-4 w-4" />Generate SQL with AI
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}

