import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import WizardSteps from "@/components/WizardSteps";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ArrowRight, ArrowLeft, ChevronRight, Zap, AlertTriangle, XCircle, CheckCircle2, Code2, Table2, GitBranch, Filter, Loader2 } from "lucide-react";
import { Link, useLocation, useParams } from "wouter";
import { toast } from "sonner";
import { WIZARD_STEPS } from "./wizardConfig";

export default function DatasetReview() {
  const { id } = useParams<{ id: string }>();
  const draftId = parseInt(id);
  const [, navigate] = useLocation();
  const [acknowledged, setAcknowledged] = useState(false);

  const { data: draft, refetch } = trpc.datasets.getById.useQuery({ id: draftId });
  const def = (draft?.definitionJson || {}) as any;

  const generateMutation = trpc.fabDataset.generateSql.useMutation({
    onSuccess: () => { toast.success("SQL generated successfully"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const completedSteps = draft ? getCompletedSteps(draft.status as string) : [];
  const evaluation = def.evaluation;
  const verdict = evaluation?.verdict as string | undefined;
  const findings = evaluation?.findings ?? [];
  const canProceed = verdict === "pass" || (verdict === "warn" && acknowledged);

  const fabSelections: Array<{ tableName: string; columns: string[] }> = def.fabSelections ?? [];
  const fabJoins: Array<{ leftTable: string; leftColumn: string; rightTable: string; rightColumn: string; joinType: string }> = def.fabJoins ?? [];
  const fabFilters: Array<{ tableName: string; column: string; operator: string; value: string }> = def.fabFilters ?? [];

  return (
    <AppLayout>
      <div className="p-6 max-w-5xl mx-auto">
        <div className="mb-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
            <Link href="/datasets"><span className="hover:text-foreground cursor-pointer">Datasets</span></Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground font-medium">{draft?.name}</span>
          </div>
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold">SQL Review</h1>
            <div className="flex gap-2">
              <Link href={`/datasets/${draftId}/criteria`}>
                <Button variant="outline" size="sm" className="gap-1"><ArrowLeft className="w-3 h-3" /> Back</Button>
              </Link>
              {!def.generatedSql ? (
                <Button onClick={() => generateMutation.mutate({ id: draftId })} disabled={generateMutation.isPending} className="gap-2">
                  {generateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                  {generateMutation.isPending ? "Generating..." : "Generate SQL"}
                </Button>
              ) : (
                <Button
                  onClick={() => navigate(`/datasets/${draftId}/preview`)}
                  disabled={!canProceed}
                  className="gap-2"
                >
                  <ArrowRight className="w-4 h-4" /> Proceed to Preview
                </Button>
              )}
            </div>
          </div>
        </div>

        <div className="mb-5 overflow-x-auto">
          <WizardSteps steps={WIZARD_STEPS} currentStep="review" completedSteps={completedSteps} />
        </div>

        {/* Dataset summary before generation */}
        {!def.generatedSql && (
          <div className="grid grid-cols-3 gap-4 mb-4">
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Table2 className="h-4 w-4 text-primary" />Selected Tables</CardTitle></CardHeader>
              <CardContent>
                {fabSelections.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No tables selected</p>
                ) : (
                  <div className="space-y-1">
                    {fabSelections.map(sel => (
                      <div key={sel.tableName} className="flex items-center justify-between text-xs">
                        <span className="font-mono font-medium">{sel.tableName}</span>
                        <Badge variant="secondary" className="text-[10px]">{sel.columns.length} cols</Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><GitBranch className="h-4 w-4 text-primary" />Joins</CardTitle></CardHeader>
              <CardContent>
                {fabJoins.length === 0 ? (
                  <p className="text-xs text-muted-foreground">{fabSelections.length > 1 ? "Auto-detect join keys" : "Single table query"}</p>
                ) : (
                  <div className="space-y-1">
                    {fabJoins.map((j, i) => (
                      <div key={i} className="text-[10px] font-mono text-muted-foreground">
                        {j.leftTable}.{j.leftColumn} = {j.rightTable}.{j.rightColumn}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Filter className="h-4 w-4 text-primary" />Filters</CardTitle></CardHeader>
              <CardContent>
                {fabFilters.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No filters (full table scan)</p>
                ) : (
                  <div className="space-y-1">
                    {fabFilters.map((f, i) => (
                      <div key={i} className="text-[10px] font-mono text-muted-foreground">
                        {f.tableName}.{f.column} {f.operator} {f.value}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* SQL and evaluation */}
        {def.generatedSql && (
          <div className="space-y-4">
            {/* Performance evaluation */}
            {evaluation && (
              <Alert className={verdict === "pass" ? "border-green-300 bg-green-50" : verdict === "warn" ? "border-yellow-300 bg-yellow-50" : "border-red-300 bg-red-50"}>
                {verdict === "pass" && <CheckCircle2 className="h-4 w-4 text-green-600" />}
                {verdict === "warn" && <AlertTriangle className="h-4 w-4 text-yellow-600" />}
                {verdict === "block" && <XCircle className="h-4 w-4 text-red-600" />}
                <AlertTitle className={verdict === "pass" ? "text-green-800" : verdict === "warn" ? "text-yellow-800" : "text-red-800"}>
                  Performance Evaluation: {verdict?.toUpperCase()}
                </AlertTitle>
                <AlertDescription>
                  {findings.length === 0 ? (
                    <p className="text-sm text-green-700">All checks passed. Query is safe to execute.</p>
                  ) : (
                    <div className="space-y-2 mt-2">
                      {findings.map((f: any, i: number) => (
                        <div key={i} className="text-sm">
                          <p className="font-medium">{f.message}</p>
                          <p className="text-xs opacity-80">{f.details}</p>
                        </div>
                      ))}
                    </div>
                  )}
                  {verdict === "warn" && (
                    <div className="flex items-center gap-2 mt-3 p-2 bg-yellow-100 rounded">
                      <Checkbox id="ack" checked={acknowledged} onCheckedChange={v => setAcknowledged(!!v)} />
                      <label htmlFor="ack" className="text-sm font-medium cursor-pointer">I acknowledge the performance warning and wish to proceed</label>
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            )}

            {/* Generated SQL */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Code2 className="h-4 w-4 text-primary" />Generated SQL
                  <Badge variant="outline" className="text-[10px]">{def.sqlColumns?.length ?? 0} columns</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <pre className="text-xs font-mono bg-muted/50 p-4 rounded-lg whitespace-pre-wrap leading-relaxed">{def.generatedSql}</pre>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Column list */}
            {def.sqlColumns && def.sqlColumns.length > 0 && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Output Columns ({def.sqlColumns.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-1.5">
                    {def.sqlColumns.map((col: string) => (
                      <span key={col} className="text-[10px] font-mono px-2 py-1 bg-muted rounded border">{col}</span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Regenerate button */}
        {def.generatedSql && (
          <div className="mt-4 flex justify-between items-center">
            <Button variant="ghost" size="sm" onClick={() => generateMutation.mutate({ id: draftId })} disabled={generateMutation.isPending} className="text-xs gap-1">
              {generateMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <Zap className="h-3 w-3" />}
              Regenerate SQL
            </Button>
            <Button onClick={() => navigate(`/datasets/${draftId}/preview`)} disabled={!canProceed} className="gap-2">
              <ArrowRight className="w-4 h-4" /> Proceed to Preview
            </Button>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

function getCompletedSteps(status: string): string[] {
  const order = ["columns", "requirement", "criteria", "review", "preview", "execute"];
  const statusMap: Record<string, string> = {
    draft: "", columns_selected: "columns", requirements_set: "requirement",
    criteria_set: "criteria", sql_generated: "review", preview_approved: "preview", completed: "execute",
  };
  const current = statusMap[status] ?? "";
  const idx = order.indexOf(current);
  return order.slice(0, idx);
}
