import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

export interface WizardStep {
  id: string;
  label: string;
  description?: string;
}

interface WizardStepsProps {
  steps: WizardStep[];
  currentStep: string;
  completedSteps: string[];
}

export default function WizardSteps({ steps, currentStep, completedSteps }: WizardStepsProps) {
  return (
    <div className="flex items-center gap-0">
      {steps.map((step, idx) => {
        const isCompleted = completedSteps.includes(step.id);
        const isCurrent = step.id === currentStep;
        const isUpcoming = !isCompleted && !isCurrent;
        return (
          <div key={step.id} className="flex items-center">
            <div className="flex flex-col items-center">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold border-2 transition-all",
                isCompleted && "bg-primary border-primary text-primary-foreground",
                isCurrent && "bg-background border-primary text-primary",
                isUpcoming && "bg-background border-border text-muted-foreground",
              )}>
                {isCompleted ? <Check className="w-4 h-4" /> : <span>{idx + 1}</span>}
              </div>
              <span className={cn(
                "text-[10px] mt-1 font-medium whitespace-nowrap",
                isCurrent && "text-primary",
                isCompleted && "text-primary/70",
                isUpcoming && "text-muted-foreground",
              )}>{step.label}</span>
            </div>
            {idx < steps.length - 1 && (
              <div className={cn(
                "h-0.5 w-12 mx-1 mb-4 transition-all",
                isCompleted ? "bg-primary" : "bg-border"
              )} />
            )}
          </div>
        );
      })}
    </div>
  );
}
