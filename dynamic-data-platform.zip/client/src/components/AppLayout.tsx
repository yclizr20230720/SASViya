import { useAuth } from "@/_core/hooks/useAuth";
import { useTheme } from "@/contexts/ThemeContext";
import { trpc } from "@/lib/trpc";
import {
  Database, LayoutDashboard, Table2, Settings, Users, BookOpen,
  FileText, Moon, Sun, LogOut, ChevronRight, Shield, ClipboardList, Cpu, FlaskConical,
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const navItems = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/sources", icon: Database, label: "Schema Browser" },
  { href: "/datasets", icon: Table2, label: "My Datasets" },
  { href: "/fab-explorer", icon: FlaskConical, label: "Fab Data Explorer" },
];

const adminItems = [
  { href: "/admin/sources", icon: Settings, label: "Data Sources" },
  { href: "/admin/dictionary", icon: BookOpen, label: "Dictionary" },
  { href: "/admin/users", icon: Users, label: "Users & Permissions" },
  { href: "/admin/audit", icon: ClipboardList, label: "Audit Log" },
  { href: "/admin/schema-intelligence", icon: Cpu, label: "Schema Intelligence" },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [location] = useLocation();
  const isAdmin = user?.role === "admin";

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Sidebar */}
      <aside className="w-60 flex-shrink-0 flex flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border">
        {/* Logo */}
        <div className="h-14 flex items-center gap-2.5 px-4 border-b border-sidebar-border">
          <div className="w-7 h-7 rounded-md bg-primary flex items-center justify-center flex-shrink-0">
            <Database className="w-4 h-4 text-primary-foreground" />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-bold text-sidebar-foreground leading-tight truncate">DDOP</p>
            <p className="text-[10px] text-sidebar-foreground/50 leading-tight truncate">Data Object Platform</p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
          <p className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-sidebar-foreground/40 mb-1">Main</p>
          {navItems.map(item => (
            <NavItem key={item.href} {...item} active={location === item.href} />
          ))}

          {isAdmin && (
            <>
              <Separator className="my-3 bg-sidebar-border" />
              <p className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-sidebar-foreground/40 mb-1 flex items-center gap-1">
                <Shield className="w-3 h-3" /> Admin
              </p>
              {adminItems.map(item => (
                <NavItem key={item.href} {...item} active={location === item.href} />
              ))}
            </>
          )}
        </nav>

        {/* Footer */}
        <div className="border-t border-sidebar-border p-3 space-y-2">
          <div className="flex items-center gap-2 px-1">
            <Avatar className="w-7 h-7">
              <AvatarFallback className="text-xs bg-primary text-primary-foreground">
                {user?.name?.charAt(0)?.toUpperCase() ?? "U"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-sidebar-foreground truncate">{user?.name ?? "User"}</p>
              <p className="text-[10px] text-sidebar-foreground/50 truncate capitalize">{user?.role ?? "user"}</p>
            </div>
          </div>
          <div className="flex gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent" onClick={toggleTheme}>
                  {theme === "dark" ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">Toggle theme</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent" onClick={() => logout()}>
                  <LogOut className="w-3.5 h-3.5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">Sign out</TooltipContent>
            </Tooltip>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}

function NavItem({ href, icon: Icon, label, active }: { href: string; icon: React.ElementType; label: string; active: boolean }) {
  return (
    <Link href={href}>
      <div className={cn(
        "flex items-center gap-2.5 px-2.5 py-2 rounded-md text-sm cursor-pointer transition-colors",
        active
          ? "bg-sidebar-accent text-sidebar-foreground font-medium"
          : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"
      )}>
        <Icon className="w-4 h-4 flex-shrink-0" />
        <span className="truncate">{label}</span>
        {active && <ChevronRight className="w-3 h-3 ml-auto opacity-60" />}
      </div>
    </Link>
  );
}
