import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useAuth } from "./_core/hooks/useAuth";
import { Loader2 } from "lucide-react";

// Pages
import Dashboard from "./pages/Dashboard";
import SourcesBrowser from "./pages/SourcesBrowser";
import DatasetList from "./pages/DatasetList";
import DatasetColumns from "./pages/DatasetColumns";
import DatasetRequirement from "./pages/DatasetRequirement";
import DatasetCriteria from "./pages/DatasetCriteria";
import DatasetReview from "./pages/DatasetReview";
import DatasetPreview from "./pages/DatasetPreview";
import DatasetExecute from "./pages/DatasetExecute";
import AdminSources from "./pages/AdminSources";
import AdminDictionary from "./pages/AdminDictionary";
import AdminUsers from "./pages/AdminUsers";
import AdminAudit from "./pages/AdminAudit";
import SchemaIntelligence from "./pages/SchemaIntelligence";
import SmartSqlReview from "./pages/SmartSqlReview";
import FabDataExplorer from "./pages/FabDataExplorer";
import LocalLogin from "./pages/LocalLogin";

function AuthGate({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }
  if (!isAuthenticated) {
    return <LocalLogin />;
  }
  return <>{children}</>;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/sources" component={SourcesBrowser} />
      <Route path="/datasets" component={DatasetList} />
      <Route path="/datasets/:id/columns" component={DatasetColumns} />
      <Route path="/datasets/:id/requirement" component={DatasetRequirement} />
      <Route path="/datasets/:id/criteria" component={DatasetCriteria} />
      <Route path="/datasets/:id/review" component={DatasetReview} />
      <Route path="/datasets/:id/preview" component={DatasetPreview} />
      <Route path="/datasets/:id/execute" component={DatasetExecute} />
      <Route path="/datasets/:id/smart-sql" component={SmartSqlReview} />
      <Route path="/fab-explorer" component={FabDataExplorer} />
      <Route path="/admin/sources" component={AdminSources} />
      <Route path="/admin/dictionary" component={AdminDictionary} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/audit" component={AdminAudit} />
      <Route path="/admin/schema-intelligence" component={SchemaIntelligence} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <Toaster />
          <AuthGate>
            <Router />
          </AuthGate>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
