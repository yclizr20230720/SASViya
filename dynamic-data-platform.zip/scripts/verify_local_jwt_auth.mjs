import mysql from "mysql2/promise";
import { randomUUID } from "node:crypto";

const baseUrl = process.env.DDOP_BASE_URL ?? "http://localhost:3000";
const password = "E2ePassword2026";
const adminEmail = `e2e-admin-${randomUUID()}@ddop.local`;
const memberEmail = `e2e-member-${randomUUID()}@ddop.local`;
const userIds = [];

function batchInput(input) {
  return JSON.stringify({ 0: { json: input } });
}

async function trpcMutation(path, input, cookie) {
  const response = await fetch(`${baseUrl}/api/trpc/${path}?batch=1`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(cookie ? { cookie } : {}),
    },
    body: batchInput(input),
  });
  const payload = await response.json();
  if (!response.ok || payload[0]?.error) {
    throw new Error(`${path} failed: ${JSON.stringify(payload)}`);
  }
  return { payload: payload[0].result.data.json, response };
}

async function trpcQuery(path, input, cookie) {
  const { payload, response } = await trpcQueryRaw(path, input, cookie);
  if (!response.ok || payload[0]?.error) {
    throw new Error(`${path} failed: ${JSON.stringify(payload)}`);
  }
  return payload[0].result.data.json;
}

async function trpcQueryRaw(path, input, cookie) {
  const query = new URLSearchParams({ batch: "1", input: batchInput(input) });
  const response = await fetch(`${baseUrl}/api/trpc/${path}?${query}`, {
    headers: cookie ? { cookie } : {},
  });
  const payload = await response.json();
  return { payload, response };
}

async function expectForbidden(path, input, cookie) {
  const { payload } = await trpcQueryRaw(path, input, cookie);
  const code = payload[0]?.error?.json?.data?.code;
  if (code !== "FORBIDDEN") {
    throw new Error(`${path} should be FORBIDDEN before source permission is granted: ${JSON.stringify(payload)}`);
  }
}

function getCookie(response) {
  const cookies = typeof response.headers.getSetCookie === "function"
    ? response.headers.getSetCookie()
    : [response.headers.get("set-cookie")];
  const session = cookies.find(value => value?.startsWith("app_session_id="));
  if (!session) throw new Error("Register response did not return a local JWT session cookie");
  return session.split(";")[0];
}

async function createDbConnection() {
  const url = new URL(process.env.DATABASE_URL);
  return mysql.createConnection({
    host: url.hostname,
    port: Number(url.port || 3306),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: url.pathname.slice(1),
    ssl: { rejectUnauthorized: true },
  });
}

try {
  const registration = await trpcMutation("auth.register", {
    name: "DDOP E2E Administrator",
    email: adminEmail,
    password,
  });
  const adminId = registration.payload.user.id;
  userIds.push(adminId);
  const adminCookie = getCookie(registration.response);

  const me = await trpcQuery("auth.me", null, adminCookie);
  if (me.email !== adminEmail || me.passwordHash !== undefined || me.role !== "admin") {
    throw new Error("auth.me did not return the expected safe local account payload");
  }

  const datasets = await trpcQuery("datasets.list", null, adminCookie);
  if (!Array.isArray(datasets)) {
    throw new Error("Protected Dataset Wizard API did not return a list");
  }

  const users = await trpcQuery("permissions.listUsers", null, adminCookie);
  if (!Array.isArray(users)) {
    throw new Error("Administrator JWT could not access the protected user management API");
  }

  const sources = await trpcQuery("sources.list", null, adminCookie);
  const source = sources[0];
  if (!source) throw new Error("No data source available for source-permission verification");
  const schemas = await trpcQuery("sources.listSchemas", { sourceId: source.id }, adminCookie);
  const schema = schemas[0];
  if (!schema) throw new Error("No schema available for source-permission verification");

  const memberRegistration = await trpcMutation("auth.register", {
    name: "DDOP E2E Member",
    email: memberEmail,
    password,
  });
  const memberId = memberRegistration.payload.user.id;
  userIds.push(memberId);
  const memberCookie = getCookie(memberRegistration.response);

  const deniedSources = await trpcQuery("sources.list", null, memberCookie);
  if (deniedSources.length !== 0) throw new Error("New local user should have no browseable sources by default");
  await expectForbidden("sources.listTables", { sourceId: source.id, schemaName: schema.schemaName }, memberCookie);

  await trpcMutation("permissions.upsert", {
    userId: memberId,
    sourceId: source.id,
    schemaName: schema.schemaName,
    canBrowse: true,
    canExecute: false,
  }, adminCookie);

  const allowedSources = await trpcQuery("sources.list", null, memberCookie);
  if (!allowedSources.some(item => item.id === source.id)) {
    throw new Error("Browse-authorized local user could not see the permitted source");
  }
  const allowedTables = await trpcQuery("sources.listTables", { sourceId: source.id, schemaName: schema.schemaName }, memberCookie);
  if (!Array.isArray(allowedTables)) throw new Error("Browse-authorized local user could not list permitted tables");

  const verified = [
    "auth.register and auth.me",
    "datasets.list (protected Dataset Wizard)",
    "permissions.listUsers (admin RBAC)",
    "sources.listTables denied without canBrowse",
    "sources.listTables allowed after canBrowse grant",
  ];

  console.log(JSON.stringify({
    success: true,
    registeredAdminId: adminId,
    registeredMemberId: memberId,
    verified,
  }, null, 2));
} finally {
  if (userIds.length > 0) {
    const connection = await createDbConnection();
    const placeholders = userIds.map(() => "?").join(", ");
    await connection.execute(`DELETE FROM source_permissions WHERE userId IN (${placeholders})`, userIds);
    await connection.execute(`DELETE FROM dataset_drafts WHERE ownerId IN (${placeholders})`, userIds);
    await connection.execute(`DELETE FROM query_audit_log WHERE userId IN (${placeholders})`, userIds);
    await connection.execute(`DELETE FROM execution_jobs WHERE userId IN (${placeholders})`, userIds);
    await connection.execute(`DELETE FROM users WHERE id IN (${placeholders})`, userIds);
    connection.destroy();
  }
}
