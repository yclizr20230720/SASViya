#!/usr/bin/env python3
"""
Semiconductor Fab Data Seeder
Generates realistic mock data for 10 fab tables:
  - 50 lots (LOT_HISTORY)
  - 80 equipment tools (EQUIPMENT_TOOL)
  - ~500 wafer history records (WAFER_HISTORY)
  - ~200 WAT records (WAT_DATA)
  - ~200 CP records (CP_DATA)
  - ~300 FDC records (FDC_DATA)
  - ~200 inline thickness records (INLINE_THICKNESS)
  - ~200 CD measurement records (CD_MEASUREMENT)
  - ~200 defect inspection records (DEFECT_INSPECTION)
  - ~80 PM records (EQUIPMENT_PM)
Total: ~2000+ rows across all tables
"""
import os, sys, random, math
from datetime import datetime, timedelta
import mysql.connector

# ── DB Connection ──────────────────────────────────────────────────────────────
DB_URL = os.environ.get("DATABASE_URL", "")

def parse_db_url(url):
    """Parse mysql://user:pass@host:port/db"""
    import re
    m = re.match(r'mysql://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)', url)
    if not m:
        raise ValueError(f"Cannot parse DATABASE_URL: {url}")
    return dict(user=m.group(1), password=m.group(2), host=m.group(3),
                port=int(m.group(4)), database=m.group(5))

conn_params = parse_db_url(DB_URL)
conn = mysql.connector.connect(**conn_params)
cur = conn.cursor()

# ── Helpers ────────────────────────────────────────────────────────────────────
rng = random.Random(42)  # deterministic seed for reproducibility

def rdate(base, days_back=180, days_fwd=0):
    offset = rng.randint(-days_back * 24 * 3600, days_fwd * 24 * 3600)
    return base + timedelta(seconds=offset)

def rnorm(mean, sigma, lo=None, hi=None, dp=4):
    v = rng.gauss(mean, sigma)
    if lo is not None: v = max(v, lo)
    if hi is not None: v = min(v, hi)
    return round(v, dp)

def rchoice(lst): return rng.choice(lst)
def rrange(a, b, dp=2): return round(rng.uniform(a, b), dp)

NOW = datetime(2024, 8, 1, 12, 0, 0)

# ── Reference data ─────────────────────────────────────────────────────────────
PRODUCTS = ["PROD-5NM-A", "PROD-5NM-B", "PROD-7NM-A", "PROD-7NM-B", "PROD-12NM-A", "PROD-28NM-A"]
TECH_NODES = {"PROD-5NM-A": "5NM", "PROD-5NM-B": "5NM", "PROD-7NM-A": "7NM",
              "PROD-7NM-B": "7NM", "PROD-12NM-A": "12NM", "PROD-28NM-A": "28NM"}
CUSTOMERS = ["CUST-APPLE", "CUST-NVIDIA", "CUST-AMD", "CUST-QUALCOMM", "CUST-MEDIATEK", None]
PRIORITIES = ["HOT", "URGENT", "NORMAL", "NORMAL", "NORMAL", "LOW"]
LOT_TYPES = ["PRODUCTION", "PRODUCTION", "PRODUCTION", "ENGINEERING", "QUALIFICATION", "MONITOR"]
STATUSES = ["ACTIVE", "ACTIVE", "COMPLETED", "COMPLETED", "HOLD", "SHIPPED"]
PROCESS_STEPS = [
    ("CLEAN_01", 10), ("PHOTO_01", 20), ("ETCH_01", 30), ("CVD_01", 40),
    ("PHOTO_02", 50), ("ETCH_02", 60), ("IMP_01", 70), ("ANNEAL_01", 80),
    ("CVD_02", 90), ("CMP_01", 100), ("PHOTO_03", 110), ("METAL_01", 120),
    ("MEASURE_01", 130), ("INSPECT_01", 140), ("WAT_FINAL", 150),
]
EQP_TYPES = {
    "STEPPER": ["ASML", "NIKON"], "ETCHER": ["LAM", "AMAT"], "CVD": ["AMAT", "TEL"],
    "CMP": ["AMAT", "EBARA"], "INSPECT": ["KLA", "HITACHI"], "MEASURE": ["KLA", "NOVA"],
    "IMPLANT": ["VARIAN", "AXCELIS"], "ANNEAL": ["TEL", "MATTSON"],
}
FAB_AREAS = {"STEPPER": "PHOTO", "ETCHER": "ETCH", "CVD": "DIFF", "CMP": "CMP",
             "INSPECT": "INSPECT", "MEASURE": "INSPECT", "IMPLANT": "DIFF", "ANNEAL": "DIFF"}
EQP_MODELS = {
    "ASML": "TWINSCAN NXE:3600D", "NIKON": "NSR-S635E", "LAM": "KIYO 45",
    "AMAT": "Centura Sculpta", "TEL": "Trias SPA", "KLA": "Surfscan SP7",
    "HITACHI": "CG6300", "NOVA": "VeraFlex", "VARIAN": "VIISta 900",
    "AXCELIS": "Purion H", "EBARA": "FREX300", "MATTSON": "Helios",
}
FDC_PARAMS = {
    "ETCH": [("PRESSURE_MTORR", 5.0, 0.3, "mTorr"), ("RF_POWER_W", 800.0, 20.0, "W"),
             ("GAS_FLOW_SCCM", 100.0, 5.0, "sccm"), ("TEMP_DEGC", 60.0, 2.0, "degC")],
    "CVD":  [("PRESSURE_MTORR", 2.5, 0.2, "mTorr"), ("TEMP_DEGC", 400.0, 5.0, "degC"),
             ("GAS_FLOW_SCCM", 200.0, 10.0, "sccm"), ("DEPO_RATE_A_MIN", 50.0, 3.0, "A/min")],
    "CMP":  [("PRESSURE_PSI", 3.0, 0.2, "psi"), ("PLATEN_RPM", 93.0, 3.0, "rpm"),
             ("SLURRY_FLOW_ML", 150.0, 10.0, "ml/min"), ("REMOVAL_RATE_A", 2000.0, 100.0, "A/min")],
}
FILM_LAYERS = ["OXIDE", "NITRIDE", "POLY", "METAL1", "METAL2", "ILD", "BARRIER"]
FILM_TARGETS = {"OXIDE": 150.0, "NITRIDE": 300.0, "POLY": 800.0,
                "METAL1": 1200.0, "METAL2": 1200.0, "ILD": 5000.0, "BARRIER": 50.0}
CD_LAYERS = ["GATE", "CONTACT", "METAL1", "VIA", "METAL2", "ACTIVE"]
CD_TARGETS = {"GATE": 7.0, "CONTACT": 12.0, "METAL1": 10.0,
              "VIA": 12.0, "METAL2": 10.0, "ACTIVE": 20.0}

print("=== Semiconductor Fab Data Seeder ===")

# ── 1. EQUIPMENT_TOOL (80 tools) ───────────────────────────────────────────────
print("Seeding fab_equipment_tool...")
equipment_ids = []
eqp_rows = []
eqp_counter = {"STEPPER": 0, "ETCHER": 0, "CVD": 0, "CMP": 0,
               "INSPECT": 0, "MEASURE": 0, "IMPLANT": 0, "ANNEAL": 0}
eqp_counts = {"STEPPER": 8, "ETCHER": 12, "CVD": 10, "CMP": 8,
              "INSPECT": 10, "MEASURE": 8, "IMPLANT": 6, "ANNEAL": 6}

for etype, count in eqp_counts.items():
    for i in range(1, count + 1):
        eqp_counter[etype] += 1
        eid = f"{etype[:4]}-{i:02d}"
        vendor = rchoice(EQP_TYPES[etype])
        model = EQP_MODELS.get(vendor, "UNKNOWN")
        area = FAB_AREAS[etype]
        bay = f"BAY-{rchoice(['A','B','C','D'])}{rng.randint(1,5)}"
        status = rchoice(["UP","UP","UP","UP","DOWN","PM","IDLE","ENGINEERING"])
        install = rdate(NOW, days_back=1800, days_fwd=0)
        last_pm = rdate(NOW, days_back=90)
        next_pm = last_pm + timedelta(days=rng.randint(60, 120))
        cap_wph = rnorm({"STEPPER": 80, "ETCHER": 120, "CVD": 60, "CMP": 90,
                         "INSPECT": 150, "MEASURE": 200, "IMPLANT": 80, "ANNEAL": 100}[etype], 10, 20, 250)
        oee = rnorm(0.82, 0.08, 0.50, 0.98, 4)
        mtbf = rnorm(500, 100, 100, 2000, 2)
        mttr = rnorm(4, 1.5, 0.5, 24, 2)
        total_wfr = rng.randint(50000, 500000)
        equipment_ids.append(eid)
        eqp_rows.append((eid, f"{vendor} {model} #{i:02d}", etype, vendor, model,
                         f"SN{rng.randint(100000,999999)}", area, bay, status,
                         install, last_pm, next_pm, cap_wph, oee, mtbf, mttr, total_wfr))

cur.executemany("""
INSERT INTO fab_equipment_tool
  (EQUIPMENT_ID,EQUIPMENT_NAME,EQUIPMENT_TYPE,VENDOR,MODEL,SERIAL_NO,
   FAB_AREA,BAY_NO,CURRENT_STATUS,INSTALL_DATE,LAST_PM_DATE,NEXT_PM_DATE,
   CAPACITY_WPH,OEE_RATE,MTBF_HOURS,MTTR_HOURS,TOTAL_WAFERS_RUN)
VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
ON DUPLICATE KEY UPDATE EQUIPMENT_NAME=VALUES(EQUIPMENT_NAME)
""", eqp_rows)
conn.commit()
print(f"  -> {len(eqp_rows)} equipment tools inserted")

# ── 2. LOT_HISTORY (50 lots) ───────────────────────────────────────────────────
print("Seeding fab_lot_history...")
lot_ids = [f"N24A{i:06d}" for i in range(1, 51)]
lot_rows = []
for lot_id in lot_ids:
    prod = rchoice(PRODUCTS)
    tech = TECH_NODES[prod]
    cust = rchoice(CUSTOMERS)
    wfr_qty = rchoice([12, 24, 25, 25, 25])
    priority = rchoice(PRIORITIES)
    lot_type = rchoice(LOT_TYPES)
    start = rdate(NOW, days_back=120, days_fwd=0)
    status = rchoice(STATUSES)
    ct_days = None
    complete = None
    ship = None
    if status in ("COMPLETED", "SHIPPED"):
        ct_days = rnorm(35, 8, 15, 90, 2)
        complete = start + timedelta(days=ct_days)
        if status == "SHIPPED":
            ship = complete + timedelta(days=rng.randint(3, 14))
    hold_cnt = rng.randint(0, 3) if status == "HOLD" else rng.randint(0, 1)
    hold_rsn = rchoice(["DEFECT_REVIEW", "SPEC_OOC", "EQUIPMENT_DOWN", None]) if hold_cnt > 0 else None
    scrap = rng.randint(0, 2) if rng.random() < 0.1 else 0
    final_yield = rnorm(92.5, 5.0, 60.0, 99.9, 4) if status in ("COMPLETED", "SHIPPED") else None
    lot_rows.append((lot_id, prod, cust, tech, wfr_qty, priority, lot_type,
                     start, complete, ship, ct_days, status, hold_cnt, hold_rsn, scrap, final_yield))

cur.executemany("""
INSERT INTO fab_lot_history
  (LOT_ID,PRODUCT_ID,CUSTOMER_ID,TECHNOLOGY_NODE,WAFER_QTY,PRIORITY,LOT_TYPE,
   START_DATE,COMPLETE_DATE,SHIP_DATE,CYCLE_TIME_DAYS,STATUS,HOLD_COUNT,HOLD_REASON,SCRAP_QTY,FINAL_YIELD)
VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
ON DUPLICATE KEY UPDATE STATUS=VALUES(STATUS)
""", lot_rows)
conn.commit()
print(f"  -> {len(lot_rows)} lots inserted")

# ── 3. WAFER_HISTORY (~500 records) ───────────────────────────────────────────
print("Seeding fab_wafer_history...")
wh_rows = []
wafer_ids_by_lot = {}
operators = [f"OP{i:03d}" for i in range(1, 21)]

for lot_id, prod, cust, tech, wfr_qty, priority, lot_type, start, complete, ship, ct_days, status, *_ in lot_rows:
    # Each lot: 10 wafers, 5 process steps each = 50 records per lot (10 lots = 500)
    n_wafers = min(wfr_qty, 10)
    wafer_ids = [f"{lot_id}-{s:02d}" for s in range(1, n_wafers + 1)]
    wafer_ids_by_lot[lot_id] = wafer_ids
    steps_to_do = PROCESS_STEPS[:5]  # first 5 steps per wafer for brevity
    for wafer_id in wafer_ids[:2]:   # 2 wafers per lot to keep total ~100 rows
        slot = int(wafer_id.split("-")[-1])
        t = start
        for step_name, seq in steps_to_do:
            eqp = rchoice([e for e in equipment_ids if e[:4] in ("STEP","ETCH","CVD_","CMP_","INSP","MEAS")] or equipment_ids)
            recipe = f"RCP-{step_name}-{tech}"
            move_in = t + timedelta(hours=rng.uniform(0.5, 4))
            proc_min = rnorm(45, 15, 5, 180, 2)
            move_out = move_in + timedelta(minutes=proc_min)
            queue_hrs = rnorm(2.5, 1.5, 0.1, 24, 2)
            step_status = rchoice(["COMPLETED","COMPLETED","COMPLETED","ABORTED","REWORKED"])
            rework = "Y" if step_status == "REWORKED" else "N"
            rework_rsn = "SPEC_OOC" if rework == "Y" else None
            wh_rows.append((wafer_id, lot_id, slot, step_name, seq,
                            eqp, recipe, move_in, move_out, proc_min, queue_hrs,
                            step_status, rchoice(operators), rework, rework_rsn))
            t = move_out

cur.executemany("""
INSERT INTO fab_wafer_history
  (WAFER_ID,LOT_ID,SLOT_NO,PROCESS_STEP,OPERATION_SEQ,EQUIPMENT_ID,RECIPE_ID,
   MOVE_IN_TIME,MOVE_OUT_TIME,PROCESS_TIME_MIN,QUEUE_TIME_HRS,STEP_STATUS,OPERATOR_ID,REWORK_FLAG,REWORK_REASON)
VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
""", wh_rows)
conn.commit()
print(f"  -> {len(wh_rows)} wafer history records inserted")

# ── 4. WAT_DATA (~200 records) ────────────────────────────────────────────────
print("Seeding fab_wat_data...")
wat_rows = []
test_sites = ["CENTER", "EDGE", "TOP", "BOTTOM", "LEFT", "RIGHT"]
for lot_id, prod, cust, tech, wfr_qty, *_ in lot_rows:
    wafers = wafer_ids_by_lot.get(lot_id, [f"{lot_id}-01"])
    for wafer_id in wafers[:2]:
        slot = int(wafer_id.split("-")[-1])
        meas_at = rdate(NOW, days_back=60)
        for site in rng.sample(test_sites, 3):
            nmos_vth = rnorm({"5NM": 220, "7NM": 250, "12NM": 300, "28NM": 400}[tech], 15, 150, 500, 4)
            pmos_vth = rnorm(-nmos_vth * 1.05, 15, -600, -100, 4)
            nmos_idsat = rnorm({"5NM": 1350, "7NM": 1200, "12NM": 1000, "28NM": 800}[tech], 50, 500, 2000, 4)
            pmos_idsat = rnorm(nmos_idsat * 0.7, 30, 300, 1500, 4)
            nmos_ioff = rnorm(0.5, 0.2, 0.01, 5.0, 6)
            poly_cd = rnorm({"5NM": 7, "7NM": 10, "12NM": 16, "28NM": 30}[tech], 0.5, 3, 50, 4)
            contact_r = rnorm(15.0, 2.0, 5.0, 50.0, 4)
            metal1_r = rnorm(0.08, 0.005, 0.03, 0.2, 4)
            # Determine pass/fail
            fail_items = []
            if abs(nmos_vth - {"5NM": 220, "7NM": 250, "12NM": 300, "28NM": 400}[tech]) > 40: fail_items.append("NMOS_VTH")
            pf = "FAIL" if fail_items else "PASS"
            wat_rows.append((lot_id, wafer_id, slot, prod, tech, site, meas_at,
                             nmos_vth, pmos_vth, nmos_idsat, pmos_idsat, nmos_ioff,
                             poly_cd, contact_r, metal1_r, pf, ",".join(fail_items) or None))

cur.executemany("""
INSERT INTO fab_wat_data
  (LOT_ID,WAFER_ID,WAFER_NO,PRODUCT_ID,TECHNOLOGY_NODE,TEST_SITE,MEASURED_AT,
   NMOS_VTH_MV,PMOS_VTH_MV,NMOS_IDSAT_UA,PMOS_IDSAT_UA,NMOS_IOFF_PA,
   POLY_CD_NM,CONTACT_R_OHM,METAL1_R_OHM_SQ,PASS_FAIL,FAIL_ITEMS)
VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
""", wat_rows)
conn.commit()
print(f"  -> {len(wat_rows)} WAT records inserted")

# ── 5. CP_DATA (~200 records) ─────────────────────────────────────────────────
print("Seeding fab_cp_data...")
cp_rows = []
prober_ids = [f"PROB-{i:02d}" for i in range(1, 6)]
for lot_id, prod, cust, tech, wfr_qty, *_ in lot_rows:
    wafers = wafer_ids_by_lot.get(lot_id, [f"{lot_id}-01"])
    for wafer_id in wafers[:4]:
        slot = int(wafer_id.split("-")[-1])
        test_prog = f"CP_{prod.replace('-','_')}_V2"
        prober = rchoice(prober_ids)
        test_date = rdate(NOW, days_back=60)
        total_die = rng.randint(800, 1200)
        edge_die = rng.randint(50, 100)
        base_yield = rnorm({"5NM": 88, "7NM": 91, "12NM": 94, "28NM": 97}[tech], 4, 60, 99.9, 4)
        good_die = int(total_die * base_yield / 100)
        fail_die = total_die - good_die
        bin2 = int(fail_die * 0.4)
        bin3 = int(fail_die * 0.35)
        bin4 = fail_die - bin2 - bin3
        defect_dens = round(fail_die / (total_die * 0.01), 6)
        cp_rows.append((lot_id, wafer_id, slot, prod, test_prog, prober, test_date,
                        total_die, good_die, fail_die, base_yield, good_die, bin2, bin3, bin4, edge_die, defect_dens))

cur.executemany("""
INSERT INTO fab_cp_data
  (LOT_ID,WAFER_ID,WAFER_NO,PRODUCT_ID,TEST_PROGRAM,PROBER_ID,TEST_DATE,
   TOTAL_DIE,GOOD_DIE,FAIL_DIE,YIELD_PCT,BIN1_CNT,BIN2_CNT,BIN3_CNT,BIN4_CNT,EDGE_DIE_CNT,DEFECT_DENSITY)
VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
""", cp_rows)
conn.commit()
print(f"  -> {len(cp_rows)} CP records inserted")

# ── 6. FDC_DATA (~300 records) ────────────────────────────────────────────────
print("Seeding fab_fdc_data...")
fdc_rows = []
etch_eqps = [e for e in equipment_ids if e.startswith("ETCH")]
cvd_eqps  = [e for e in equipment_ids if e.startswith("CVD_")]
cmp_eqps  = [e for e in equipment_ids if e.startswith("CMP_")]

for lot_id, prod, cust, tech, wfr_qty, *_ in lot_rows:
    wafers = wafer_ids_by_lot.get(lot_id, [f"{lot_id}-01"])
    for wafer_id in wafers[:1]:
        # ETCH FDC
        for pname, target, sigma, unit in FDC_PARAMS["ETCH"]:
            eqp = rchoice(etch_eqps) if etch_eqps else rchoice(equipment_ids)
            val = rnorm(target, sigma, dp=6)
            ucl, lcl = target + 3*sigma, target - 3*sigma
            dev = round((val - target) / target * 100, 4)
            alarm = "Y" if abs(val - target) > 2.5 * sigma else "N"
            alarm_cls = "MAJOR" if alarm == "Y" and abs(val - target) > 3*sigma else ("MINOR" if alarm == "Y" else None)
            fdc_rows.append((wafer_id, lot_id, eqp, "ETCH_02", f"RCP-ETCH-{tech}",
                             pname, val, unit, ucl, lcl, target, dev, alarm, alarm_cls,
                             rdate(NOW, days_back=60), "XBAR"))
        # CVD FDC
        for pname, target, sigma, unit in FDC_PARAMS["CVD"]:
            eqp = rchoice(cvd_eqps) if cvd_eqps else rchoice(equipment_ids)
            val = rnorm(target, sigma, dp=6)
            ucl, lcl = target + 3*sigma, target - 3*sigma
            dev = round((val - target) / target * 100, 4)
            alarm = "Y" if abs(val - target) > 2.5 * sigma else "N"
            alarm_cls = "MAJOR" if alarm == "Y" and abs(val - target) > 3*sigma else ("MINOR" if alarm == "Y" else None)
            fdc_rows.append((wafer_id, lot_id, eqp, "CVD_01", f"RCP-CVD-{tech}",
                             pname, val, unit, ucl, lcl, target, dev, alarm, alarm_cls,
                             rdate(NOW, days_back=60), "EWMA"))

cur.executemany("""
INSERT INTO fab_fdc_data
  (WAFER_ID,LOT_ID,EQUIPMENT_ID,PROCESS_STEP,RECIPE_ID,PARAMETER_NAME,
   MEASURED_VALUE,UNIT,UCL,LCL,TARGET,DEVIATION_PCT,ALARM_FLAG,ALARM_CLASS,MEASURED_AT,CHART_TYPE)
VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
""", fdc_rows)
conn.commit()
print(f"  -> {len(fdc_rows)} FDC records inserted")

# ── 7. INLINE_THICKNESS (~200 records) ────────────────────────────────────────
print("Seeding fab_inline_thickness...")
it_rows = []
meas_eqps = [e for e in equipment_ids if e.startswith("MEAS")]
for lot_id, prod, cust, tech, wfr_qty, *_ in lot_rows:
    wafers = wafer_ids_by_lot.get(lot_id, [f"{lot_id}-01"])
    for wafer_id in wafers[:2]:
        slot = int(wafer_id.split("-")[-1])
        for film in rng.sample(FILM_LAYERS, 2):
            target = FILM_TARGETS[film]
            tol = target * 0.05
            avg = rnorm(target, tol * 0.3, target - tol, target + tol, 4)
            rng_val = rnorm(tol * 0.2, tol * 0.05, 0, tol, 4)
            tmax = avg + rng_val / 2
            tmin = avg - rng_val / 2
            unif = round(rng_val / avg * 100, 4)
            usl, lsl = target + tol, target - tol
            pf = "FAIL" if avg > usl or avg < lsl else "PASS"
            eqp = rchoice(meas_eqps) if meas_eqps else rchoice(equipment_ids)
            it_rows.append((lot_id, wafer_id, slot, "MEASURE_01", film, eqp,
                            "ELLIPSOMETRY", 9, avg, tmax, tmin, rng_val, unif,
                            target, usl, lsl, pf, rdate(NOW, days_back=60)))

cur.executemany("""
INSERT INTO fab_inline_thickness
  (LOT_ID,WAFER_ID,WAFER_NO,PROCESS_STEP,FILM_LAYER,EQUIPMENT_ID,MEAS_METHOD,
   SITE_COUNT,THICKNESS_AVG_A,THICKNESS_MAX_A,THICKNESS_MIN_A,THICKNESS_RANGE,
   UNIFORMITY_PCT,TARGET_A,USL_A,LSL_A,PASS_FAIL,MEASURED_AT)
VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
""", it_rows)
conn.commit()
print(f"  -> {len(it_rows)} inline thickness records inserted")

# ── 8. CD_MEASUREMENT (~200 records) ──────────────────────────────────────────
print("Seeding fab_cd_measurement...")
cd_rows = []
for lot_id, prod, cust, tech, wfr_qty, *_ in lot_rows:
    wafers = wafer_ids_by_lot.get(lot_id, [f"{lot_id}-01"])
    for wafer_id in wafers[:2]:
        slot = int(wafer_id.split("-")[-1])
        for layer in rng.sample(CD_LAYERS, 2):
            target = CD_TARGETS[layer]
            sigma_cd = target * 0.03
            mean_cd = rnorm(target, sigma_cd, target * 0.85, target * 1.15, 4)
            three_sig = rnorm(sigma_cd * 3, sigma_cd * 0.5, 0.1, target * 0.2, 4)
            cd_max = mean_cd + three_sig / 2
            cd_min = mean_cd - three_sig / 2
            cd_range = cd_max - cd_min
            lwr = rnorm(0.8, 0.2, 0.1, 3.0, 4)
            ler = rnorm(0.5, 0.15, 0.1, 2.0, 4)
            usl = target * 1.10
            lsl = target * 0.90
            pf = "FAIL" if mean_cd > usl or mean_cd < lsl else "PASS"
            eqp = rchoice(meas_eqps) if meas_eqps else rchoice(equipment_ids)
            cd_rows.append((lot_id, wafer_id, slot, "PHOTO_01", layer, eqp,
                            "CD-SEM", 9, mean_cd, three_sig, cd_max, cd_min, round(cd_range, 4),
                            lwr, ler, target, usl, lsl, pf, rdate(NOW, days_back=60)))

cur.executemany("""
INSERT INTO fab_cd_measurement
  (LOT_ID,WAFER_ID,WAFER_NO,PROCESS_STEP,CD_LAYER,EQUIPMENT_ID,MEAS_METHOD,
   SITE_COUNT,CD_MEAN_NM,CD_3SIGMA_NM,CD_MAX_NM,CD_MIN_NM,CD_RANGE_NM,
   LWR_NM,LER_NM,TARGET_NM,USL_NM,LSL_NM,PASS_FAIL,MEASURED_AT)
VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
""", cd_rows)
conn.commit()
print(f"  -> {len(cd_rows)} CD measurement records inserted")

# ── 9. DEFECT_INSPECTION (~200 records) ───────────────────────────────────────
print("Seeding fab_defect_inspection...")
di_rows = []
insp_eqps = [e for e in equipment_ids if e.startswith("INSP")]
for lot_id, prod, cust, tech, wfr_qty, *_ in lot_rows:
    wafers = wafer_ids_by_lot.get(lot_id, [f"{lot_id}-01"])
    for wafer_id in wafers[:2]:
        slot = int(wafer_id.split("-")[-1])
        eqp = rchoice(insp_eqps) if insp_eqps else rchoice(equipment_ids)
        recipe = f"INSP-{tech}-STD"
        total_def = rng.randint(0, 150)
        nuisance = int(total_def * rng.uniform(0.3, 0.7))
        real_def = total_def - nuisance
        particle = int(real_def * rng.uniform(0.4, 0.7))
        scratch = int(real_def * rng.uniform(0.1, 0.3))
        pattern = real_def - particle - scratch
        haze = rnorm(0.3, 0.1, 0.0, 2.0, 4)
        defect_dens = round(total_def / 706.86, 6)  # 300mm wafer area ~706.86 cm²
        threshold = {"5NM": 30, "7NM": 40, "12NM": 60, "28NM": 100}[tech]
        pf = "FAIL" if real_def > threshold else "PASS"
        review = "Y" if pf == "FAIL" and rng.random() > 0.5 else "N"
        di_rows.append((lot_id, wafer_id, slot, "INSPECT_01", eqp, recipe,
                        rdate(NOW, days_back=60), total_def, defect_dens, nuisance,
                        real_def, particle, scratch, pattern, haze, pf, review))

cur.executemany("""
INSERT INTO fab_defect_inspection
  (LOT_ID,WAFER_ID,WAFER_NO,PROCESS_STEP,EQUIPMENT_ID,INSP_RECIPE,INSP_DATE,
   TOTAL_DEFECTS,DEFECT_DENSITY,NUISANCE_CNT,REAL_DEFECT_CNT,PARTICLE_CNT,
   SCRATCH_CNT,PATTERN_CNT,HAZE_VALUE,PASS_FAIL,REVIEW_FLAG)
VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
""", di_rows)
conn.commit()
print(f"  -> {len(di_rows)} defect inspection records inserted")

# ── 10. EQUIPMENT_PM (~80 records) ────────────────────────────────────────────
print("Seeding fab_equipment_pm...")
pm_rows = []
engineers = [f"ENG{i:03d}" for i in range(1, 11)]
pm_parts = {
    "MINOR": "FILTER,O-RING",
    "MAJOR": "FILTER,O-RING,PUMP,VALVE",
    "FULL":  "FILTER,O-RING,PUMP,VALVE,CHAMBER_LINER,RF_MATCH",
}
for eqp_id in equipment_ids[:40]:  # PM for first 40 tools
    n_pm = rng.randint(1, 3)
    for _ in range(n_pm):
        pm_type = rchoice(["SCHEDULED", "SCHEDULED", "UNSCHEDULED", "EMERGENCY"])
        pm_level = rchoice(["MINOR", "MINOR", "MAJOR", "FULL"])
        start = rdate(NOW, days_back=180)
        dur = rnorm({"MINOR": 4, "MAJOR": 12, "FULL": 24}[pm_level],
                    {"MINOR": 1, "MAJOR": 3, "FULL": 6}[pm_level], 0.5, 72, 2)
        end = start + timedelta(hours=dur)
        eng = rchoice(engineers)
        vendor = "Y" if pm_level == "FULL" and rng.random() > 0.5 else "N"
        parts = pm_parts[pm_level]
        pre_oee = rnorm(0.75, 0.1, 0.4, 0.95, 4)
        post_oee = rnorm(0.88, 0.05, 0.6, 0.98, 4)
        wafers_since = rng.randint(500, 5000)
        pm_status = "COMPLETED"
        qual = rchoice(["PASS", "PASS", "PASS", "FAIL"])
        remarks = f"PM completed by {eng}. All checks nominal." if qual == "PASS" else f"Qualification failed - recheck required."
        pm_rows.append((eqp_id, pm_type, pm_level, start, end, dur, eng, vendor,
                        parts, pre_oee, post_oee, wafers_since, pm_status, qual, remarks))

cur.executemany("""
INSERT INTO fab_equipment_pm
  (EQUIPMENT_ID,PM_TYPE,PM_LEVEL,START_TIME,END_TIME,DURATION_HRS,ENGINEER_ID,
   VENDOR_SUPPORT,PARTS_REPLACED,PRE_OEE,POST_OEE,WAFERS_SINCE_PM,PM_STATUS,QUAL_RESULT,REMARKS)
VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
""", pm_rows)
conn.commit()
print(f"  -> {len(pm_rows)} PM records inserted")

# ── Summary ────────────────────────────────────────────────────────────────────
cur.close()
conn.close()
print("\n=== Seeding Complete ===")
tables = ["fab_lot_history","fab_equipment_tool","fab_wafer_history","fab_wat_data",
          "fab_cp_data","fab_fdc_data","fab_inline_thickness","fab_cd_measurement",
          "fab_defect_inspection","fab_equipment_pm"]
total = sum([len(lot_rows), len(eqp_rows), len(wh_rows), len(wat_rows),
             len(cp_rows), len(fdc_rows), len(it_rows), len(cd_rows),
             len(di_rows), len(pm_rows)])
print(f"Total rows inserted: {total}")
for t in tables:
    print(f"  {t}")
