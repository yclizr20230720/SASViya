import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  json,
  bigint,
} from "drizzle-orm/mysql-core";

// ─── Core user table ───────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  /** Password-derived scrypt hash for self-contained local JWT authentication. */
  passwordHash: varchar("passwordHash", { length: 255 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Data Sources ──────────────────────────────────────────────────────────────
export const dataSources = mysqlTable("data_sources", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull().unique(),
  dialect: mysqlEnum("dialect", ["oracle", "postgresql", "mysql", "mssql", "sqlite"]).notNull(),
  host: varchar("host", { length: 256 }).notNull(),
  port: int("port").notNull(),
  database: varchar("database", { length: 128 }).notNull(),
  readonlyCredentialRef: varchar("readonlyCredentialRef", { length: 128 }).notNull(),
  queryTimeoutSec: int("queryTimeoutSec").default(30).notNull(),
  maxRows: int("maxRows").default(100000).notNull(),
  maxConcurrentQueries: int("maxConcurrentQueries").default(3).notNull(),
  fullScanThreshold: int("fullScanThreshold").default(100000).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DataSource = typeof dataSources.$inferSelect;
export type InsertDataSource = typeof dataSources.$inferInsert;

// ─── Data Source Schemas ───────────────────────────────────────────────────────
export const dataSourceSchemas = mysqlTable("data_source_schemas", {
  id: int("id").autoincrement().primaryKey(),
  sourceId: int("sourceId").notNull(),
  schemaName: varchar("schemaName", { length: 128 }).notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DataSourceSchema = typeof dataSourceSchemas.$inferSelect;
export type InsertDataSourceSchema = typeof dataSourceSchemas.$inferInsert;

// ─── Source Permissions ────────────────────────────────────────────────────────
export const sourcePermissions = mysqlTable("source_permissions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sourceId: int("sourceId").notNull(),
  schemaName: varchar("schemaName", { length: 128 }),
  canBrowse: boolean("canBrowse").default(false).notNull(),
  canExecute: boolean("canExecute").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SourcePermission = typeof sourcePermissions.$inferSelect;
export type InsertSourcePermission = typeof sourcePermissions.$inferInsert;

// ─── Schema Cache: Tables ──────────────────────────────────────────────────────
export const schemaCacheTables = mysqlTable("schema_cache_tables", {
  id: int("id").autoincrement().primaryKey(),
  sourceId: int("sourceId").notNull(),
  schemaName: varchar("schemaName", { length: 128 }).notNull(),
  tableName: varchar("tableName", { length: 256 }).notNull(),
  approxRowCount: bigint("approxRowCount", { mode: "number" }).default(0),
  tableComment: text("tableComment"),
  partitionKey: varchar("partitionKey", { length: 128 }),
  businessDomain: varchar("businessDomain", { length: 64 }),
  indexesJson: json("indexesJson").$type<any[]>(),
  foreignKeysJson: json("foreignKeysJson").$type<any[]>(),
  lastRefreshedAt: timestamp("lastRefreshedAt").defaultNow().notNull(),
});

export type SchemaCacheTable = typeof schemaCacheTables.$inferSelect;

// ─── Schema Cache: Columns ─────────────────────────────────────────────────────
export const schemaCacheColumns = mysqlTable("schema_cache_columns", {
  id: int("id").autoincrement().primaryKey(),
  sourceId: int("sourceId").notNull(),
  schemaName: varchar("schemaName", { length: 128 }).notNull(),
  tableName: varchar("tableName", { length: 256 }).notNull(),
  columnName: varchar("columnName", { length: 256 }).notNull(),
  dataType: varchar("dataType", { length: 128 }).notNull(),
  isNullable: boolean("isNullable").default(true),
  isIndexed: boolean("isIndexed").default(false),
  isKey: boolean("isKey").default(false),
  ordinalPosition: int("ordinalPosition").default(0),
  defaultValue: varchar("defaultValue", { length: 256 }),
  columnComment: text("columnComment"),
  lastRefreshedAt: timestamp("lastRefreshedAt").defaultNow().notNull(),
});

export type SchemaCacheColumn = typeof schemaCacheColumns.$inferSelect;

// ─── Schema Relationships (FK + AI-inferred) ──────────────────────────────────
export const schemaRelationships = mysqlTable("schema_relationships", {
  id: int("id").autoincrement().primaryKey(),
  fromSourceName: varchar("from_source_name", { length: 128 }).notNull(),
  fromSchema: varchar("from_schema", { length: 128 }).notNull(),
  fromTable: varchar("from_table", { length: 256 }).notNull(),
  fromColumn: varchar("from_column", { length: 256 }).notNull(),
  toSourceName: varchar("to_source_name", { length: 128 }).notNull(),
  toSchema: varchar("to_schema", { length: 128 }).notNull(),
  toTable: varchar("to_table", { length: 256 }).notNull(),
  toColumn: varchar("to_column", { length: 256 }).notNull(),
  relationshipType: varchar("relationship_type", { length: 32 }).notNull(),
  confidence: varchar("confidence", { length: 8 }).notNull(),
  description: text("description"),
  aiAnalysisJson: json("ai_analysis_json").$type<any>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type SchemaRelationship = typeof schemaRelationships.$inferSelect;

// ─── Data Dictionary Entries ───────────────────────────────────────────────────
export const dictionaryEntries = mysqlTable("dictionary_entries", {
  id: int("id").autoincrement().primaryKey(),
  sourceId: int("sourceId").notNull(),
  schemaName: varchar("schemaName", { length: 128 }).notNull(),
  tableName: varchar("tableName", { length: 256 }).notNull(),
  columnName: varchar("columnName", { length: 256 }),
  description: text("description").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DictionaryEntry = typeof dictionaryEntries.$inferSelect;
export type InsertDictionaryEntry = typeof dictionaryEntries.$inferInsert;

// ─── Dataset Drafts ────────────────────────────────────────────────────────────
export const datasetDrafts = mysqlTable("dataset_drafts", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  name: varchar("name", { length: 256 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", [
    "draft",
    "columns_selected",
    "requirements_set",
    "criteria_set",
    "sql_generated",
    "preview_approved",
    "executing",
    "completed",
    "failed",
  ]).default("draft").notNull(),
  definitionJson: json("definitionJson").$type<DatasetDefinition>().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DatasetDraft = typeof datasetDrafts.$inferSelect;
export type InsertDatasetDraft = typeof datasetDrafts.$inferInsert;

// ─── Execution Jobs ────────────────────────────────────────────────────────────
export const executionJobs = mysqlTable("execution_jobs", {
  id: int("id").autoincrement().primaryKey(),
  draftId: int("draftId").notNull(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["queued", "running", "succeeded", "failed", "cancelled"]).default("queued").notNull(),
  rowCount: int("rowCount"),
  durationMs: int("durationMs"),
  failureReason: varchar("failureReason", { length: 64 }),
  failureMessage: text("failureMessage"),
  downloadUrl: text("downloadUrl"),
  downloadUrlExcel: text("downloadUrlExcel"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ExecutionJob = typeof executionJobs.$inferSelect;
export type InsertExecutionJob = typeof executionJobs.$inferInsert;

// ─── Query Audit Log ───────────────────────────────────────────────────────────
export const queryAuditLog = mysqlTable("query_audit_log", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sourceId: int("sourceId"),
  draftId: int("draftId"),
  sqlText: text("sqlText"),
  evaluationVerdict: mysqlEnum("evaluationVerdict", ["pass", "warn", "block"]),
  evaluationFindingsJson: json("evaluationFindingsJson").$type<EvaluationFinding[]>(),
  executedAt: timestamp("executedAt").defaultNow().notNull(),
  rowCount: int("rowCount"),
  durationMs: int("durationMs"),
  action: varchar("action", { length: 64 }).notNull(),
});

export type QueryAuditLog = typeof queryAuditLog.$inferSelect;
export type InsertQueryAuditLog = typeof queryAuditLog.$inferInsert;

// ─── Shared Domain Types ───────────────────────────────────────────────────────
export interface ColumnSelection {
  sourceId: number;
  schemaName: string;
  tableName: string;
  columns: string[];
  alias?: string;
}

export interface JoinDefinition {
  leftSourceId: number;
  leftSchema: string;
  leftTable: string;
  leftColumn: string;
  rightSourceId: number;
  rightSchema: string;
  rightTable: string;
  rightColumn: string;
  joinType: "INNER" | "LEFT" | "RIGHT" | "FULL";
}

export interface RequirementItem {
  id: string;
  fieldName: string;
  description: string;
  sourceHint?: string;
  matchedColumn?: {
    sourceId: number;
    schemaName: string;
    tableName: string;
    columnName: string;
    score: number;
  };
}

export interface FilterCriteria {
  id: string;
  sourceId: number;
  schemaName: string;
  tableName: string;
  columnName: string;
  operator: "eq" | "neq" | "in" | "nin" | "between" | "gt" | "gte" | "lt" | "lte" | "like" | "ilike" | "is_null" | "is_not_null";
  value: string | string[] | null;
  scope?: string;
}

export interface EvaluationFinding {
  type: "missing_index" | "full_table_scan" | "large_table" | "explain_cost" | "cross_db_join" | "partition_scan" | "no_indexed_filter";
  severity: "warn" | "block";
  table: string;
  column?: string;
  message: string;
  details?: string;
}

export interface DatasetDefinition {
  selections: ColumnSelection[];
  joins: JoinDefinition[];
  requirementItems: RequirementItem[];
  criteria: FilterCriteria[];
  generatedSql?: string;
  sqlParams?: Record<string, unknown>;
  aiAnalysis?: any;
  joinPath?: any[];
  evaluation?: {
    verdict: "pass" | "warn" | "block";
    findings: EvaluationFinding[];
    evaluatedAt: string;
    userAcknowledged?: boolean;
  };
  previewResult?: {
    columns: string[];
    rows: Record<string, unknown>[];
    rowCountShown: number;
    approvedAt?: string;
  };
}
