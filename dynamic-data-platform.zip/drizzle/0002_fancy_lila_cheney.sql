CREATE TABLE `schema_relationships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`from_source_name` varchar(128) NOT NULL,
	`from_schema` varchar(128) NOT NULL,
	`from_table` varchar(256) NOT NULL,
	`from_column` varchar(256) NOT NULL,
	`to_source_name` varchar(128) NOT NULL,
	`to_schema` varchar(128) NOT NULL,
	`to_table` varchar(256) NOT NULL,
	`to_column` varchar(256) NOT NULL,
	`relationship_type` varchar(32) NOT NULL,
	`confidence` varchar(8) NOT NULL,
	`description` text,
	`ai_analysis_json` json,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `schema_relationships_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `schema_cache_columns` ADD `defaultValue` varchar(256);--> statement-breakpoint
ALTER TABLE `schema_cache_columns` ADD `columnComment` text;--> statement-breakpoint
ALTER TABLE `schema_cache_tables` ADD `tableComment` text;--> statement-breakpoint
ALTER TABLE `schema_cache_tables` ADD `partitionKey` varchar(128);--> statement-breakpoint
ALTER TABLE `schema_cache_tables` ADD `businessDomain` varchar(64);--> statement-breakpoint
ALTER TABLE `schema_cache_tables` ADD `indexesJson` json;--> statement-breakpoint
ALTER TABLE `schema_cache_tables` ADD `foreignKeysJson` json;