CREATE TABLE `data_source_schemas` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceId` int NOT NULL,
	`schemaName` varchar(128) NOT NULL,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `data_source_schemas_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `data_sources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(128) NOT NULL,
	`dialect` enum('oracle','postgresql','mysql','mssql','sqlite') NOT NULL,
	`host` varchar(256) NOT NULL,
	`port` int NOT NULL,
	`database` varchar(128) NOT NULL,
	`readonlyCredentialRef` varchar(128) NOT NULL,
	`queryTimeoutSec` int NOT NULL DEFAULT 30,
	`maxRows` int NOT NULL DEFAULT 100000,
	`maxConcurrentQueries` int NOT NULL DEFAULT 3,
	`fullScanThreshold` int NOT NULL DEFAULT 100000,
	`isActive` boolean NOT NULL DEFAULT true,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `data_sources_id` PRIMARY KEY(`id`),
	CONSTRAINT `data_sources_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `dataset_drafts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`name` varchar(256) NOT NULL,
	`description` text,
	`status` enum('draft','columns_selected','requirements_set','criteria_set','sql_generated','preview_approved','executing','completed','failed') NOT NULL DEFAULT 'draft',
	`definitionJson` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dataset_drafts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `dictionary_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceId` int NOT NULL,
	`schemaName` varchar(128) NOT NULL,
	`tableName` varchar(256) NOT NULL,
	`columnName` varchar(256),
	`description` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dictionary_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `execution_jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`draftId` int NOT NULL,
	`userId` int NOT NULL,
	`status` enum('queued','running','succeeded','failed','cancelled') NOT NULL DEFAULT 'queued',
	`rowCount` int,
	`durationMs` int,
	`failureReason` varchar(64),
	`failureMessage` text,
	`downloadUrl` text,
	`downloadUrlExcel` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `execution_jobs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `query_audit_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`sourceId` int,
	`draftId` int,
	`sqlText` text,
	`evaluationVerdict` enum('pass','warn','block'),
	`evaluationFindingsJson` json,
	`executedAt` timestamp NOT NULL DEFAULT (now()),
	`rowCount` int,
	`durationMs` int,
	`action` varchar(64) NOT NULL,
	CONSTRAINT `query_audit_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `schema_cache_columns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceId` int NOT NULL,
	`schemaName` varchar(128) NOT NULL,
	`tableName` varchar(256) NOT NULL,
	`columnName` varchar(256) NOT NULL,
	`dataType` varchar(128) NOT NULL,
	`isNullable` boolean DEFAULT true,
	`isIndexed` boolean DEFAULT false,
	`isKey` boolean DEFAULT false,
	`ordinalPosition` int DEFAULT 0,
	`lastRefreshedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `schema_cache_columns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `schema_cache_tables` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceId` int NOT NULL,
	`schemaName` varchar(128) NOT NULL,
	`tableName` varchar(256) NOT NULL,
	`approxRowCount` bigint DEFAULT 0,
	`lastRefreshedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `schema_cache_tables_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `source_permissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`sourceId` int NOT NULL,
	`schemaName` varchar(128),
	`canBrowse` boolean NOT NULL DEFAULT false,
	`canExecute` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `source_permissions_id` PRIMARY KEY(`id`)
);
