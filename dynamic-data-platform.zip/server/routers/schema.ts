/**
 * Schema Intelligence Router
 * Provides APIs for:
 * - Schema scanning (trigger full introspection from Mock DB scenarios)
 * - Relationship graph retrieval
 * - AI-powered join analysis
 * - Smart SQL generation (AI-driven, user only selects columns)
 */
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "../_core/trpc";
import { scanSchema, scanAllSchemas } from "../schemaScanner";
import { generateSmartSql, getRelationshipsBetween } from "../aiEngine";
import { buildRelationshipGraph } from "../mockDb/scenarios";
import {
  getDataSourceById, getAllDataSources, getSchemasBySourceId,
  getTablesForSchema, getColumnsForTable, getDictionaryEntries,
  getDatasetDraftById, updateDatasetDraft, insertAuditLog,
} from "../db";
import { eq, and } from "drizzle-orm";
import { getDb } from "../db";
import { schemaRelationships } from "../../drizzle/schema";
import type { DatasetDefinition } from "../../drizzle/schema";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  return next({ ctx });
});

export const schemaRouter = router({

  // ── Scan a specific schema (admin only) ──────────────────────────────────────
  scanSchema: adminProcedure.input(z.object({
    sourceId: z.number(),
    schemaName: z.string(),
  })).mutation(async ({ ctx, input }) => {
    const result = await scanSchema(input.sourceId, input.schemaName, ctx.user.id);
    return result;
  }),

  // ── Scan all schemas for a source (admin only) ───────────────────────────────
  scanAllSchemas: adminProcedure.input(z.object({
    sourceId: z.number(),
  })).mutation(async ({ ctx, input }) => {
    const results = await scanAllSchemas(input.sourceId, ctx.user.id);
    return {
      totalTables: results.reduce((a, r) => a + r.tablesScanned, 0),
      totalColumns: results.reduce((a, r) => a + r.columnsScanned, 0),
      totalIndexes: results.reduce((a, r) => a + r.indexesFound, 0),
      totalForeignKeys: results.reduce((a, r) => a + r.foreignKeysFound, 0),
      schemas: results,
    };
  }),

  // ── Get full table detail (columns + indexes + FKs) ──────────────────────────
  getTableDetail: protectedProcedure.input(z.object({
    sourceId: z.number(),
    schemaName: z.string(),
    tableName: z.string(),
  })).query(async ({ input }) => {
    const tables = await getTablesForSchema(input.sourceId, input.schemaName);
    const tableInfo = tables.find(t => t.tableName === input.tableName);
    if (!tableInfo) throw new TRPCError({ code: "NOT_FOUND" });
    const columns = await getColumnsForTable(input.sourceId, input.schemaName, input.tableName);
    const dictEntries = await getDictionaryEntries(input.sourceId, input.schemaName);
    return {
      ...tableInfo,
      columns: columns.map(c => ({
        ...c,
        description: dictEntries.find(d => d.tableName === c.tableName && d.columnName === c.columnName)?.description ?? c.columnComment ?? null,
      })),
    };
  }),

  // ── Get relationship graph for a source ──────────────────────────────────────
  getRelationships: protectedProcedure.input(z.object({
    sourceName: z.string().optional(),
    schemaName: z.string().optional(),
  })).query(async ({ input }) => {
    const allEdges = buildRelationshipGraph();
    const filtered = allEdges.filter(e => {
      if (input.sourceName && e.fromSource !== input.sourceName && e.toSource !== input.sourceName) return false;
      if (input.schemaName && e.fromSchema !== input.schemaName && e.toSchema !== input.schemaName) return false;
      return true;
    });
    return filtered;
  }),

  // ── Get stored relationships from DB ─────────────────────────────────────────
  getStoredRelationships: protectedProcedure.input(z.object({
    fromSourceName: z.string().optional(),
    fromSchema: z.string().optional(),
  })).query(async ({ input }) => {
    const db = await getDb();
    if (!db) return [];
    const conditions = [];
    if (input.fromSourceName) conditions.push(eq(schemaRelationships.fromSourceName, input.fromSourceName));
    if (input.fromSchema) conditions.push(eq(schemaRelationships.fromSchema, input.fromSchema));
    return conditions.length > 0
      ? db.select().from(schemaRelationships).where(and(...conditions))
      : db.select().from(schemaRelationships);
  }),

  // ── Get relationships between two specific tables ─────────────────────────────
  getTableRelationships: protectedProcedure.input(z.object({
    sourceNameA: z.string(), schemaA: z.string(), tableA: z.string(),
    sourceNameB: z.string(), schemaB: z.string(), tableB: z.string(),
  })).query(async ({ input }) => {
    return getRelationshipsBetween(
      input.sourceNameA, input.schemaA, input.tableA,
      input.sourceNameB, input.schemaB, input.tableB
    );
  }),

  // ── AI-powered smart SQL generation ──────────────────────────────────────────
  generateSmartSql: protectedProcedure.input(z.object({
    draftId: z.number(),
  })).mutation(async ({ ctx, input }) => {
    const draft = await getDatasetDraftById(input.draftId);
    if (!draft) throw new TRPCError({ code: "NOT_FOUND" });
    if (draft.ownerId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });

    const def = draft.definitionJson as DatasetDefinition;
    if (!def.selections || def.selections.length === 0) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "No columns selected. Please select columns first." });
    }

    // Build source metadata maps
    const sourceIds = Array.from(new Set(def.selections.map(s => s.sourceId)));
    const sourceNames: Record<number, string> = {};
    const sourceDialects: Record<number, string> = {};
    const fullScanThresholds: Record<number, number> = {};

    for (const sourceId of sourceIds) {
      const source = await getDataSourceById(sourceId);
      if (source) {
        sourceNames[sourceId] = source.name;
        sourceDialects[sourceId] = source.dialect;
        fullScanThresholds[sourceId] = source.fullScanThreshold ?? 100000;
      }
    }

    // Generate smart SQL with AI analysis
    const result = await generateSmartSql(def, sourceNames, sourceDialects, fullScanThresholds);

    // Evaluate performance
    const { evaluatePerformanceAdvanced } = await import("../performanceEvaluator");
    const evaluation = await evaluatePerformanceAdvanced(def, sourceIds[0], fullScanThresholds[sourceIds[0]] ?? 100000);

    // Update draft
    const updatedDef: DatasetDefinition = {
      ...def,
      generatedSql: result.sql,
      sqlParams: result.params,
      aiAnalysis: result.aiAnalysis,
      joinPath: result.joinPath,
      evaluation: {
        ...evaluation,
        evaluatedAt: new Date().toISOString(),
        userAcknowledged: false,
      },
    };
    await updateDatasetDraft(input.draftId, { status: "sql_generated", definitionJson: updatedDef });

    // Audit log
    await insertAuditLog({
      userId: ctx.user.id,
      sourceId: sourceIds[0],
      draftId: input.draftId,
      sqlText: result.sql,
      evaluationVerdict: evaluation.verdict,
      evaluationFindingsJson: evaluation.findings,
      action: "ai_generate_sql",
      executedAt: new Date(),
    });

    return {
      sql: result.sql,
      params: result.params,
      joinPath: result.joinPath,
      aiAnalysis: result.aiAnalysis,
      evaluation,
      issues: result.issues,
    };
  }),

  // ── Analyze columns for join suggestions (without saving) ────────────────────
  analyzeColumns: protectedProcedure.input(z.object({
    selections: z.array(z.object({
      sourceId: z.number(),
      schemaName: z.string(),
      tableName: z.string(),
      columns: z.array(z.string()),
    })),
    criteria: z.array(z.any()).optional(),
  })).mutation(async ({ input }) => {
    const sourceIds = Array.from(new Set(input.selections.map(s => s.sourceId)));
    const sourceNames: Record<number, string> = {};
    const sourceDialects: Record<number, string> = {};
    const fullScanThresholds: Record<number, number> = {};

    for (const sourceId of sourceIds) {
      const source = await getDataSourceById(sourceId);
      if (source) {
        sourceNames[sourceId] = source.name;
        sourceDialects[sourceId] = source.dialect;
        fullScanThresholds[sourceId] = source.fullScanThreshold ?? 100000;
      }
    }

    const def: DatasetDefinition = {
      selections: input.selections,
      joins: [],
      criteria: input.criteria ?? [],
      requirementItems: [],
    };

    const result = await generateSmartSql(def, sourceNames, sourceDialects, fullScanThresholds);
    return {
      joinSuggestions: result.joinPath,
      aiAnalysis: result.aiAnalysis,
      previewSql: result.sql,
    };
  }),

  // ── Get all available mock scenarios (for testing/demo) ──────────────────────
  getMockScenarios: adminProcedure.query(async () => {
    const { MOCK_DB_REGISTRY } = await import("../mockDb/scenarios");
    return Object.entries(MOCK_DB_REGISTRY).map(([name, src]) => ({
      sourceName: name,
      dialect: src.dialect,
      description: src.description,
      schemas: src.schemas.map(s => ({
        schemaName: s.schemaName,
        description: s.description,
        tableCount: s.tables.length,
        tables: s.tables.map(t => ({
          tableName: t.tableName,
          approxRowCount: t.approxRowCount,
          columnCount: t.columns.length,
          indexCount: t.indexes.length,
          fkCount: t.foreignKeys.length,
          businessDomain: t.businessDomain,
          comment: t.comment,
        })),
      })),
    }));
  }),
});
