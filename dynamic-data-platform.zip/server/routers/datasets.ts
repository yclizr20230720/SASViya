import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createDatasetDraft, getDatasetDraftById, getDraftsByOwner,
  updateDatasetDraft, deleteDatasetDraft, insertAuditLog,
  getDataSourceById, getTablesForSchema, getColumnsForTable,
  getDictionaryEntries, createExecutionJob, getExecutionJobById,
  updateExecutionJob, countRunningJobsForUser,
} from "../db";
import type {
  DatasetDefinition, ColumnSelection, JoinDefinition,
  RequirementItem, FilterCriteria, EvaluationFinding,
} from "../../drizzle/schema";

// ─── Helper: fuzzy match score (simple token overlap, rapidfuzz-like) ──────────
function tokenOverlapScore(a: string, b: string): number {
  const tokA = a.toLowerCase().split(/[\s_\-\.]+/).filter(Boolean);
  const tokB = new Set(b.toLowerCase().split(/[\s_\-\.]+/).filter(Boolean));
  if (tokA.length === 0 || tokB.size === 0) return 0;
  let overlap = 0;
  for (let i = 0; i < tokA.length; i++) { if (tokB.has(tokA[i])) overlap++; }
  return (overlap * 2) / (tokA.length + tokB.size);
}

// ─── Helper: build SQL from dataset definition ─────────────────────────────────
function buildSql(def: DatasetDefinition, dialect: string): { sql: string; params: Record<string, unknown>; issues: string[] } {
  const issues: string[] = [];
  if (!def.selections || def.selections.length === 0) {
    return { sql: "", params: {}, issues: ["No columns selected"] };
  }

  const params: Record<string, unknown> = {};
  let paramIdx = 0;
  const nextParam = (val: unknown) => { const k = `p${++paramIdx}`; params[k] = val; return `:${k}`; };

  // Build SELECT clause
  const selectParts: string[] = [];
  for (const sel of def.selections) {
    const prefix = `${sel.schemaName}.${sel.tableName}`;
    for (const col of sel.columns) {
      selectParts.push(`${prefix}.${col}`);
    }
  }

  // Build FROM clause (first table)
  const firstSel = def.selections[0];
  let fromClause = `${firstSel.schemaName}.${firstSel.tableName}`;

  // Build JOIN clauses
  const joinParts: string[] = [];
  for (const join of (def.joins || [])) {
    const jType = join.joinType || "INNER";
    joinParts.push(
      `${jType} JOIN ${join.rightSchema}.${join.rightTable} ON ${join.leftSchema}.${join.leftTable}.${join.leftColumn} = ${join.rightSchema}.${join.rightTable}.${join.rightColumn}`
    );
  }
  // Add additional tables not covered by joins
  for (let i = 1; i < def.selections.length; i++) {
    const sel = def.selections[i];
    const alreadyJoined = (def.joins || []).some(j =>
      (j.rightSchema === sel.schemaName && j.rightTable === sel.tableName) ||
      (j.leftSchema === sel.schemaName && j.leftTable === sel.tableName)
    );
    if (!alreadyJoined) {
      joinParts.push(`, ${sel.schemaName}.${sel.tableName}`);
      issues.push(`Table ${sel.schemaName}.${sel.tableName} added without explicit join — consider specifying join conditions.`);
    }
  }

  // Build WHERE clause
  const whereParts: string[] = [];
  for (const crit of (def.criteria || [])) {
    const col = `${crit.schemaName}.${crit.tableName}.${crit.columnName}`;
    switch (crit.operator) {
      case "eq":    whereParts.push(`${col} = ${nextParam(crit.value)}`); break;
      case "neq":   whereParts.push(`${col} != ${nextParam(crit.value)}`); break;
      case "gt":    whereParts.push(`${col} > ${nextParam(crit.value)}`); break;
      case "gte":   whereParts.push(`${col} >= ${nextParam(crit.value)}`); break;
      case "lt":    whereParts.push(`${col} < ${nextParam(crit.value)}`); break;
      case "lte":   whereParts.push(`${col} <= ${nextParam(crit.value)}`); break;
      case "like":  whereParts.push(`${col} LIKE ${nextParam(crit.value)}`); break;
      case "ilike": whereParts.push(`UPPER(${col}) LIKE UPPER(${nextParam(crit.value)})`); break;
      case "is_null":     whereParts.push(`${col} IS NULL`); break;
      case "is_not_null": whereParts.push(`${col} IS NOT NULL`); break;
      case "in": {
        const vals = Array.isArray(crit.value) ? crit.value : [crit.value];
        const pKeys = vals.map(v => nextParam(v));
        whereParts.push(`${col} IN (${pKeys.join(", ")})`);
        break;
      }
      case "nin": {
        const vals = Array.isArray(crit.value) ? crit.value : [crit.value];
        const pKeys = vals.map(v => nextParam(v));
        whereParts.push(`${col} NOT IN (${pKeys.join(", ")})`);
        break;
      }
      case "between": {
        const vals = Array.isArray(crit.value) ? crit.value : [crit.value, crit.value];
        whereParts.push(`${col} BETWEEN ${nextParam(vals[0])} AND ${nextParam(vals[1])}`);
        break;
      }
    }
  }

  let sqlStr = `SELECT ${selectParts.join(",\n       ")}\nFROM   ${fromClause}`;
  if (joinParts.length > 0) sqlStr += `\n${joinParts.join("\n")}`;
  if (whereParts.length > 0) sqlStr += `\nWHERE  ${whereParts.join("\n  AND  ")}`;

  return { sql: sqlStr, params, issues };
}

// ─── Helper: performance evaluation ───────────────────────────────────────────
async function evaluatePerformance(
  def: DatasetDefinition,
  sourceId: number,
  fullScanThreshold: number
): Promise<{ verdict: "pass" | "warn" | "block"; findings: EvaluationFinding[] }> {
  const findings: EvaluationFinding[] = [];

  for (const sel of def.selections) {
    // Get table metadata
    const tables = await getTablesForSchema(sourceId, sel.schemaName);
    const tableInfo = tables.find(t => t.tableName === sel.tableName);
    const rowCount = tableInfo?.approxRowCount ?? 0;

    // Get column metadata
    const columns = await getColumnsForTable(sourceId, sel.schemaName, sel.tableName);

    // Check if any filter/join uses this table
    const tableCriteria = (def.criteria || []).filter(c => c.tableName === sel.tableName && c.schemaName === sel.schemaName);
    const tableJoins = (def.joins || []).filter(j =>
      (j.leftTable === sel.tableName && j.leftSchema === sel.schemaName) ||
      (j.rightTable === sel.tableName && j.rightSchema === sel.schemaName)
    );

    // Large table with no filter → full scan risk
    if (rowCount > fullScanThreshold && tableCriteria.length === 0 && tableJoins.length === 0) {
      findings.push({
        type: "full_table_scan",
        severity: "block",
        table: `${sel.schemaName}.${sel.tableName}`,
        message: `Table ${sel.schemaName}.${sel.tableName} has ~${rowCount.toLocaleString()} rows and no filter criteria — this will cause a full table scan.`,
        details: `Configure the fullScanThreshold (currently ${fullScanThreshold.toLocaleString()}) or add WHERE conditions.`,
      });
    }

    // Check filter columns for index coverage
    for (const crit of tableCriteria) {
      const colMeta = columns.find(c => c.columnName === crit.columnName);
      if (colMeta && !colMeta.isIndexed && !colMeta.isKey) {
        const severity = rowCount > fullScanThreshold ? "block" : "warn";
        findings.push({
          type: "missing_index",
          severity,
          table: `${sel.schemaName}.${sel.tableName}`,
          column: crit.columnName,
          message: `Column ${crit.columnName} on ${sel.schemaName}.${sel.tableName} is not indexed. Filtering on it may cause a full table scan.`,
        });
      }
    }

    // Check join columns for index coverage
    for (const join of tableJoins) {
      const joinCol = join.leftTable === sel.tableName ? join.leftColumn : join.rightColumn;
      const colMeta = columns.find(c => c.columnName === joinCol);
      if (colMeta && !colMeta.isIndexed && !colMeta.isKey) {
        findings.push({
          type: "missing_index",
          severity: "warn",
          table: `${sel.schemaName}.${sel.tableName}`,
          column: joinCol,
          message: `Join column ${joinCol} on ${sel.schemaName}.${sel.tableName} is not indexed — join performance may be poor.`,
        });
      }
    }
  }

  const hasBlock = findings.some(f => f.severity === "block");
  const hasWarn = findings.some(f => f.severity === "warn");
  const verdict = hasBlock ? "block" : hasWarn ? "warn" : "pass";
  return { verdict, findings };
}

// ─── Helper: generate preview SQL (limit 100) ──────────────────────────────────
function wrapPreviewSql(sql: string, dialect: string): string {
  const d = dialect.toLowerCase();
  if (d === "oracle") return `SELECT * FROM (${sql}) WHERE ROWNUM <= 100`;
  if (d === "mssql")  return sql.replace(/^SELECT/i, "SELECT TOP 100");
  return `${sql} LIMIT 100`;
}

// ─── Router ────────────────────────────────────────────────────────────────────
export const datasetsRouter = router({
  // ── List my drafts ───────────────────────────────────────────────────────────
  list: protectedProcedure.query(async ({ ctx }) => {
    return getDraftsByOwner(ctx.user.id);
  }),

  // ── Create new draft ─────────────────────────────────────────────────────────
  create: protectedProcedure.input(z.object({
    name: z.string().min(1).max(256),
    description: z.string().optional(),
  })).mutation(async ({ ctx, input }) => {
    const emptyDef: DatasetDefinition = {
      selections: [], joins: [], requirementItems: [], criteria: [],
    };
    await createDatasetDraft({
      ownerId: ctx.user.id,
      name: input.name,
      description: input.description,
      status: "draft",
      definitionJson: emptyDef,
    });
    const drafts = await getDraftsByOwner(ctx.user.id);
    return drafts[0]; // most recent
  }),

  // ── Get draft by id ──────────────────────────────────────────────────────────
  getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ ctx, input }) => {
    const draft = await getDatasetDraftById(input.id);
    if (!draft) throw new TRPCError({ code: "NOT_FOUND" });
    if (draft.ownerId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
    return draft;
  }),

  // ── Update draft (patch) ─────────────────────────────────────────────────────
  patch: protectedProcedure.input(z.object({
    id: z.number(),
    name: z.string().optional(),
    description: z.string().optional(),
    status: z.string().optional(),
    definitionJson: z.any().optional(),
  })).mutation(async ({ ctx, input }) => {
    const draft = await getDatasetDraftById(input.id);
    if (!draft) throw new TRPCError({ code: "NOT_FOUND" });
    if (draft.ownerId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
    const { id, ...data } = input;
    await updateDatasetDraft(id, data);
    return getDatasetDraftById(id);
  }),

  // ── Delete draft ─────────────────────────────────────────────────────────────
  delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    const draft = await getDatasetDraftById(input.id);
    if (!draft) throw new TRPCError({ code: "NOT_FOUND" });
    if (draft.ownerId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
    await deleteDatasetDraft(input.id);
    return { success: true };
  }),

  // ── Source Matcher: match requirement items to columns ───────────────────────
  matchRequirements: protectedProcedure.input(z.object({
    draftId: z.number(),
    items: z.array(z.object({
      id: z.string(),
      fieldName: z.string(),
      description: z.string(),
      sourceHint: z.string().optional(),
    })),
    sourceId: z.number(),
    schemaName: z.string(),
  })).mutation(async ({ ctx, input }) => {
    const columns = await getColumnsForTable(input.sourceId, input.schemaName, "");
    const allColumns = await getTablesForSchema(input.sourceId, input.schemaName);
    const dictEntries = await getDictionaryEntries(input.sourceId, input.schemaName);

    // Get all columns across all tables in the schema
    const allCols: Array<{ sourceId: number; schemaName: string; tableName: string; columnName: string; description?: string }> = [];
    for (const table of allColumns) {
      const cols = await getColumnsForTable(input.sourceId, input.schemaName, table.tableName);
      for (const col of cols) {
        const desc = dictEntries.find(d => d.tableName === col.tableName && d.columnName === col.columnName)?.description;
        allCols.push({ sourceId: input.sourceId, schemaName: input.schemaName, tableName: col.tableName, columnName: col.columnName, description: desc });
      }
    }

    const results = input.items.map(item => {
      const scored = allCols.map(col => {
        const nameScore = tokenOverlapScore(item.fieldName, col.columnName);
        const descScore = item.description && col.description ? tokenOverlapScore(item.description, col.description) : 0;
        const hintScore = item.sourceHint ? tokenOverlapScore(item.sourceHint, col.tableName) : 0;
        const score = nameScore * 0.5 + descScore * 0.3 + hintScore * 0.2;
        return { ...col, score };
      }).filter(c => c.score > 0).sort((a, b) => b.score - a.score).slice(0, 5);
      return { ...item, candidates: scored };
    });
    return results;
  }),

  // ── Generate SQL + performance evaluation ────────────────────────────────────
  generateSql: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    const draft = await getDatasetDraftById(input.id);
    if (!draft) throw new TRPCError({ code: "NOT_FOUND" });
    if (draft.ownerId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });

    const def = draft.definitionJson as DatasetDefinition;
    if (!def.selections || def.selections.length === 0) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "No columns selected. Please select columns first." });
    }

    // Get source info for dialect
    const sourceId = def.selections[0].sourceId;
    const source = await getDataSourceById(sourceId);
    if (!source) throw new TRPCError({ code: "NOT_FOUND", message: "Data source not found" });

    // Build SQL
    const { sql, params, issues } = buildSql(def, source.dialect);

    // Evaluate performance
    const evaluation = await evaluatePerformance(def, sourceId, source.fullScanThreshold);

    // Update draft with generated SQL and evaluation
    const updatedDef: DatasetDefinition = {
      ...def,
      generatedSql: sql,
      sqlParams: params,
      evaluation: {
        ...evaluation,
        evaluatedAt: new Date().toISOString(),
        userAcknowledged: false,
      },
    };
    await updateDatasetDraft(input.id, { status: "sql_generated", definitionJson: updatedDef });

    // Write audit log
    await insertAuditLog({
      userId: ctx.user.id,
      sourceId,
      draftId: input.id,
      sqlText: sql,
      evaluationVerdict: evaluation.verdict,
      evaluationFindingsJson: evaluation.findings,
      action: "generate_sql",
      executedAt: new Date(),
    });

    return { sql, params, evaluation, issues };
  }),

  // ── Acknowledge performance warning ──────────────────────────────────────────
  acknowledgeWarning: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    const draft = await getDatasetDraftById(input.id);
    if (!draft) throw new TRPCError({ code: "NOT_FOUND" });
    if (draft.ownerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
    const def = draft.definitionJson as DatasetDefinition;
    if (!def.evaluation) throw new TRPCError({ code: "BAD_REQUEST", message: "No evaluation found" });
    if (def.evaluation.verdict === "block") throw new TRPCError({ code: "BAD_REQUEST", message: "Cannot acknowledge a blocked query" });
    const updatedDef = { ...def, evaluation: { ...def.evaluation, userAcknowledged: true } };
    await updateDatasetDraft(input.id, { definitionJson: updatedDef });
    return { success: true };
  }),

  // ── Preview execution (100 rows) ─────────────────────────────────────────────
  preview: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    const draft = await getDatasetDraftById(input.id);
    if (!draft) throw new TRPCError({ code: "NOT_FOUND" });
    if (draft.ownerId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });

    const def = draft.definitionJson as DatasetDefinition;
    if (!def.generatedSql) throw new TRPCError({ code: "BAD_REQUEST", message: "Generate SQL first" });
    if (!def.evaluation) throw new TRPCError({ code: "BAD_REQUEST", message: "No evaluation found" });
    if (def.evaluation.verdict === "block") throw new TRPCError({ code: "BAD_REQUEST", message: "Query is blocked by performance evaluator" });
    if (def.evaluation.verdict === "warn" && !def.evaluation.userAcknowledged) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Please acknowledge the performance warning first" });
    }

    const sourceId = def.selections[0].sourceId;
    const source = await getDataSourceById(sourceId);
    if (!source) throw new TRPCError({ code: "NOT_FOUND" });

    // In a real system, this would execute against the actual DB.
    // Here we return realistic mock preview data.
    const previewData = generateMockPreviewData(def, 100);

    const updatedDef: DatasetDefinition = {
      ...def,
      previewResult: {
        columns: previewData.columns,
        rows: previewData.rows,
        rowCountShown: previewData.rows.length,
      },
    };
    await updateDatasetDraft(input.id, { status: "sql_generated", definitionJson: updatedDef });

    await insertAuditLog({
      userId: ctx.user.id, sourceId, draftId: input.id,
      sqlText: def.generatedSql, action: "preview",
      rowCount: previewData.rows.length, durationMs: 234, executedAt: new Date(),
    });

    return previewData;
  }),

  // ── Approve preview ───────────────────────────────────────────────────────────
  approvePreview: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    const draft = await getDatasetDraftById(input.id);
    if (!draft) throw new TRPCError({ code: "NOT_FOUND" });
    if (draft.ownerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
    const def = draft.definitionJson as DatasetDefinition;
    if (!def.previewResult) throw new TRPCError({ code: "BAD_REQUEST", message: "Run preview first" });
    const updatedDef = { ...def, previewResult: { ...def.previewResult, approvedAt: new Date().toISOString() } };
    await updateDatasetDraft(input.id, { status: "preview_approved", definitionJson: updatedDef });
    return { success: true };
  }),

  // ── Full execution (async job) ────────────────────────────────────────────────
  execute: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    const draft = await getDatasetDraftById(input.id);
    if (!draft) throw new TRPCError({ code: "NOT_FOUND" });
    if (draft.ownerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });

    const def = draft.definitionJson as DatasetDefinition;
    if (!def.previewResult?.approvedAt) throw new TRPCError({ code: "BAD_REQUEST", message: "Preview must be approved before executing" });

    const sourceId = def.selections[0].sourceId;
    const source = await getDataSourceById(sourceId);
    if (!source) throw new TRPCError({ code: "NOT_FOUND" });

    // Concurrency check
    const runningJobs = await countRunningJobsForUser(ctx.user.id);
    if (runningJobs >= 2) {
      throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "CONCURRENCY_LIMIT: You already have running queries. Please wait for them to complete." });
    }

    // Create job
    await createExecutionJob({ draftId: input.id, userId: ctx.user.id, status: "queued" });
    const jobs = await getDraftsByOwner(ctx.user.id);

    // Simulate async execution (in production, this would be a background worker)
    const jobResult = await runMockExecution(def, source);

    await insertAuditLog({
      userId: ctx.user.id, sourceId, draftId: input.id,
      sqlText: def.generatedSql, action: "full_execute",
      rowCount: jobResult.rowCount, durationMs: jobResult.durationMs, executedAt: new Date(),
    });

    await updateDatasetDraft(input.id, { status: "completed" });

    return jobResult;
  }),

  // ── Get audit log (admin) ─────────────────────────────────────────────────────
  auditLog: protectedProcedure.input(z.object({
    userId: z.number().optional(),
    sourceId: z.number().optional(),
    limit: z.number().optional(),
  })).query(async ({ ctx, input }) => {
    if (ctx.user.role !== "admin") {
      // Regular users can only see their own logs
      const { getAuditLogs } = await import("../db");
      return getAuditLogs({ userId: ctx.user.id, limit: input.limit });
    }
    const { getAuditLogs } = await import("../db");
    return getAuditLogs(input);
  }),
});

// ─── Mock data helpers ─────────────────────────────────────────────────────────
function generateMockPreviewData(def: DatasetDefinition, limit: number) {
  const columns: string[] = [];
  for (const sel of def.selections) {
    for (const col of sel.columns) {
      columns.push(`${sel.tableName}.${col}`);
    }
  }
  if (columns.length === 0) return { columns: [], rows: [] };

  const rows = Array.from({ length: Math.min(limit, 20) }, (_, i) => {
    const row: Record<string, unknown> = {};
    for (const col of columns) {
      const colName = col.split(".")[1] ?? col;
      if (/id$/i.test(colName)) row[col] = `DEMO-${String(i + 1).padStart(6, "0")}`;
      else if (/date|time/i.test(colName)) row[col] = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      else if (/count|num|qty|rate|yield/i.test(colName)) row[col] = +(Math.random() * 100).toFixed(4);
      else row[col] = `VALUE_${i + 1}`;
    }
    return row;
  });
  return { columns, rows };
}

async function runMockExecution(def: DatasetDefinition, source: any) {
  const rowCount = Math.floor(Math.random() * 50000) + 1000;
  const durationMs = Math.floor(Math.random() * 8000) + 500;
  // In production: write CSV/Excel to S3 and return signed URL
  const downloadUrl = `/api/download/mock-${Date.now()}.csv`;
  const downloadUrlExcel = `/api/download/mock-${Date.now()}.xlsx`;
  return { status: "succeeded", rowCount, durationMs, downloadUrl, downloadUrlExcel };
}
