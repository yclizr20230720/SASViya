/**
 * Fab Dataset Router
 * Bridges the Dataset Wizard with the real fab tables.
 * Handles SQL generation, performance evaluation, preview, and full execution
 * for datasets defined via the wizard (fabSelections + fabJoins + fabFilters).
 */
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "../_core/trpc";
import { insertAuditLog } from "../db";
import { SEMI_FAB_TABLES } from "../mockDb/semiFabScenarios";
import mysql2 from "mysql2/promise";

// ── Raw MySQL pool ─────────────────────────────────────────────────────────────
let _pool: mysql2.Pool | null = null;
function getPool(): mysql2.Pool {
  if (!_pool && process.env.DATABASE_URL) {
    const rawUrl = process.env.DATABASE_URL;
    // TiDB Serverless requires SSL; pass ssl option explicitly
    _pool = mysql2.createPool({
      uri: rawUrl,
      ssl: { rejectUnauthorized: true },
      connectTimeout: 30000,
      connectionLimit: 5,
    });
  }
  if (!_pool) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB not available" });
  return _pool;
}
async function rawQuery(sql: string, params: any[] = []): Promise<any[]> {
  const [rows] = await getPool().query(sql, params);
  return Array.isArray(rows) ? rows as any[] : [];
}

// ── Table map ─────────────────────────────────────────────────────────────────
const FAB_TABLE_MAP: Record<string, string> = {
  LOT_HISTORY: "fab_lot_history", WAFER_HISTORY: "fab_wafer_history",
  EQUIPMENT_TOOL: "fab_equipment_tool", WAT_DATA: "fab_wat_data",
  CP_DATA: "fab_cp_data", FDC_DATA: "fab_fdc_data",
  INLINE_THICKNESS: "fab_inline_thickness", CD_MEASUREMENT: "fab_cd_measurement",
  DEFECT_INSPECTION: "fab_defect_inspection", EQUIPMENT_PM: "fab_equipment_pm",
};

type FilterOp = "eq"|"neq"|"gt"|"gte"|"lt"|"lte"|"like"|"in"|"between"|"is_null"|"is_not_null";

function buildWhereClause(
  filters: Array<{ tableName: string; column: string; operator: string; value: string }>,
  tableAlias: string,
  tableName: string,
  params: any[]
): string {
  const tableFilters = filters.filter(f => f.tableName === tableName);
  if (tableFilters.length === 0) return "";
  const parts: string[] = [];
  for (const f of tableFilters) {
    const col = `${tableAlias}.\`${f.column}\``;
    const op = f.operator as FilterOp;
    switch (op) {
      case "eq":          parts.push(`${col} = ?`); params.push(f.value); break;
      case "neq":         parts.push(`${col} != ?`); params.push(f.value); break;
      case "gt":          parts.push(`${col} > ?`); params.push(f.value); break;
      case "gte":         parts.push(`${col} >= ?`); params.push(f.value); break;
      case "lt":          parts.push(`${col} < ?`); params.push(f.value); break;
      case "lte":         parts.push(`${col} <= ?`); params.push(f.value); break;
      case "like":        parts.push(`${col} LIKE ?`); params.push(f.value); break;
      case "is_null":     parts.push(`${col} IS NULL`); break;
      case "is_not_null": parts.push(`${col} IS NOT NULL`); break;
      case "in": {
        const vals = f.value.split(",").map(v => v.trim()).filter(Boolean);
        parts.push(`${col} IN (${vals.map(() => "?").join(",")})`);
        params.push(...vals);
        break;
      }
      case "between": {
        const vals = f.value.split(",").map(v => v.trim());
        parts.push(`${col} BETWEEN ? AND ?`);
        params.push(vals[0] ?? "", vals[1] ?? "");
        break;
      }
    }
  }
  return parts.join(" AND ");
}

/**
 * Build SQL from fabSelections + fabJoins + fabFilters
 */
function buildFabSql(
  fabSelections: Array<{ tableName: string; columns: string[] }>,
  fabJoins: Array<{ leftTable: string; leftColumn: string; rightTable: string; rightColumn: string; joinType: string }>,
  fabFilters: Array<{ tableName: string; column: string; operator: string; value: string }>,
  rowLimit: number,
  previewMode: boolean
): { sql: string; params: any[]; columns: string[]; tables: string[] } {
  if (fabSelections.length === 0) throw new TRPCError({ code: "BAD_REQUEST", message: "No tables selected" });

  const params: any[] = [];
  const limit = previewMode ? 100 : rowLimit;

  // Single table query
  if (fabSelections.length === 1) {
    const sel = fabSelections[0];
    const physTable = FAB_TABLE_MAP[sel.tableName];
    if (!physTable) throw new TRPCError({ code: "BAD_REQUEST", message: `Unknown table: ${sel.tableName}` });
    const colList = sel.columns.map(c => `t.\`${c}\``).join(", ");
    const whereParts: string[] = [];
    const whereStr = buildWhereClause(fabFilters, "t", sel.tableName, params);
    if (whereStr) whereParts.push(whereStr);
    const whereClause = whereParts.length > 0 ? `WHERE ${whereParts.join(" AND ")}` : "";
    const sql = `SELECT ${colList}\nFROM \`${physTable}\` t\n${whereClause}\nLIMIT ?`.trim();
    params.push(limit);
    const columns = sel.columns;
    return { sql, params, columns, tables: [sel.tableName] };
  }

  // Multi-table JOIN query
  const aliases: Record<string, string> = {};
  fabSelections.forEach((sel, i) => { aliases[sel.tableName] = `t${i}`; });

  const colParts: string[] = [];
  const allColumns: string[] = [];
  for (const sel of fabSelections) {
    const alias = aliases[sel.tableName];
    for (const col of sel.columns) {
      colParts.push(`${alias}.\`${col}\` AS \`${sel.tableName}_${col}\``);
      allColumns.push(`${sel.tableName}_${col}`);
    }
  }

  const baseTable = fabSelections[0];
  const baseAlias = aliases[baseTable.tableName];
  const basePhys = FAB_TABLE_MAP[baseTable.tableName];
  if (!basePhys) throw new TRPCError({ code: "BAD_REQUEST", message: `Unknown table: ${baseTable.tableName}` });

  let fromClause = `FROM \`${basePhys}\` ${baseAlias}`;

  // Determine joins
  const usedJoins = fabJoins.length > 0 ? fabJoins : [];
  const joinedTables = new Set([baseTable.tableName]);

  for (const sel of fabSelections.slice(1)) {
    const alias = aliases[sel.tableName];
    const physTable = FAB_TABLE_MAP[sel.tableName];
    if (!physTable) continue;
    // Find join definition
    const joinDef = usedJoins.find(j =>
      (j.leftTable === baseTable.tableName && j.rightTable === sel.tableName) ||
      (j.rightTable === baseTable.tableName && j.leftTable === sel.tableName)
    ) ?? usedJoins.find(j => j.rightTable === sel.tableName || j.leftTable === sel.tableName);

    if (joinDef) {
      const leftAlias = aliases[joinDef.leftTable] ?? baseAlias;
      const rightAlias = alias;
      const jt = joinDef.joinType ?? "INNER";
      fromClause += `\n${jt} JOIN \`${physTable}\` ${alias} ON ${leftAlias}.\`${joinDef.leftColumn}\` = ${rightAlias}.\`${joinDef.rightColumn}\``;
    } else {
      // Auto-detect common key (LOT_ID > WAFER_ID > EQUIPMENT_ID)
      const commonKeys = ["LOT_ID", "WAFER_ID", "EQUIPMENT_ID"];
      const baseCols = new Set(fabSelections[0].columns);
      const thisCols = new Set(sel.columns);
      const sharedKey = commonKeys.find(k => baseCols.has(k) && thisCols.has(k));
      if (sharedKey) {
        fromClause += `\nINNER JOIN \`${physTable}\` ${alias} ON ${baseAlias}.\`${sharedKey}\` = ${alias}.\`${sharedKey}\``;
      } else {
        // Cross join as fallback
        fromClause += `\nCROSS JOIN \`${physTable}\` ${alias}`;
      }
    }
    joinedTables.add(sel.tableName);
  }

  // WHERE clause combining all table filters
  const whereParts: string[] = [];
  for (const sel of fabSelections) {
    const alias = aliases[sel.tableName];
    const w = buildWhereClause(fabFilters, alias, sel.tableName, params);
    if (w) whereParts.push(w);
  }
  const whereClause = whereParts.length > 0 ? `WHERE ${whereParts.join(" AND ")}` : "";

  const sql = `SELECT ${colParts.join(",\n       ")}\n${fromClause}\n${whereClause}\nLIMIT ?`.trim();
  params.push(limit);

  return { sql, params, columns: allColumns, tables: fabSelections.map(s => s.tableName) };
}

/**
 * Performance evaluation for the generated SQL
 */
function evaluateSqlPerformance(
  fabSelections: Array<{ tableName: string; columns: string[] }>,
  fabFilters: Array<{ tableName: string; column: string; operator: string; value: string }>,
  fabJoins: Array<{ leftTable: string; leftColumn: string; rightTable: string; rightColumn: string; joinType: string }>
): { verdict: "pass" | "warn" | "block"; findings: Array<{ severity: string; message: string; details: string }> } {
  const findings: Array<{ severity: string; message: string; details: string }> = [];

  for (const sel of fabSelections) {
    const tableMeta = SEMI_FAB_TABLES.find(t => t.tableName === sel.tableName);
    if (!tableMeta) continue;
    const tableFilters = fabFilters.filter(f => f.tableName === sel.tableName);
    const indexedCols = new Set(tableMeta.indexes.flatMap(i => i.columns));
    const hasIndexedFilter = tableFilters.some(f => indexedCols.has(f.column));
    const rowCount = tableMeta.approxRowCount ?? 0;

    if (rowCount > 500000 && tableFilters.length === 0) {
      findings.push({ severity: "block", message: `Full table scan on ${sel.tableName}`, details: `Table has ~${(rowCount/1000).toFixed(0)}K rows with no filter. Add a WHERE condition on an indexed column.` });
    } else if (rowCount > 100000 && !hasIndexedFilter) {
      findings.push({ severity: "warn", message: `No indexed filter on ${sel.tableName}`, details: `Table has ~${(rowCount/1000).toFixed(0)}K rows but no filter uses an indexed column. Consider filtering on: ${Array.from(indexedCols).slice(0,3).join(", ")}` });
    }
  }

  if (fabSelections.length > 3) {
    findings.push({ severity: "warn", message: "Complex multi-table join", details: `Joining ${fabSelections.length} tables may be slow. Consider reducing scope or adding indexed filters.` });
  }

  const hasBlock = findings.some(f => f.severity === "block");
  const hasWarn = findings.some(f => f.severity === "warn");
  return { verdict: hasBlock ? "block" : hasWarn ? "warn" : "pass", findings };
}

export const fabDatasetRouter = router({

  // ── Generate SQL from dataset definition ──────────────────────────────────────
  generateSql: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    const { getDb, insertAuditLog: audit } = await import("../db");
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB not available" });

    // Load draft
    const { datasetDrafts } = await import("../../drizzle/schema");
    const { eq } = await import("drizzle-orm");
    const rows = await db.select().from(datasetDrafts).where(eq(datasetDrafts.id, input.id)).limit(1);
    if (!rows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Draft not found" });
    const draft = rows[0];
    const def = (draft.definitionJson || {}) as any;

    const fabSelections = def.fabSelections ?? [];
    const fabJoins = def.fabJoins ?? [];
    const fabFilters = def.fabFilters ?? [];
    const rowLimit = def.rowLimit ?? 10000;

    if (fabSelections.length === 0) throw new TRPCError({ code: "BAD_REQUEST", message: "No columns selected. Go back to Column Selection." });

    const { sql, params, columns } = buildFabSql(fabSelections, fabJoins, fabFilters, rowLimit, false);
    const evaluation = evaluateSqlPerformance(fabSelections, fabFilters, fabJoins);

    await db.update(datasetDrafts).set({
      status: "sql_generated",
      definitionJson: { ...def, generatedSql: sql, sqlParams: params, sqlColumns: columns, evaluation },
      updatedAt: new Date(),
    }).where(eq(datasetDrafts.id, input.id));

    await insertAuditLog({ userId: ctx.user.id, action: "generate_sql", sqlText: sql, rowCount: 0, durationMs: 0, executedAt: new Date() });

    return { sql, columns, evaluation };
  }),

  // ── Preview (100 rows) ────────────────────────────────────────────────────────
  previewData: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    const { getDb } = await import("../db");
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB not available" });

    const { datasetDrafts } = await import("../../drizzle/schema");
    const { eq } = await import("drizzle-orm");
    const rows = await db.select().from(datasetDrafts).where(eq(datasetDrafts.id, input.id)).limit(1);
    if (!rows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Draft not found" });
    const def = (rows[0].definitionJson || {}) as any;

    const fabSelections = def.fabSelections ?? [];
    const fabJoins = def.fabJoins ?? [];
    const fabFilters = def.fabFilters ?? [];

    const { sql, params, columns } = buildFabSql(fabSelections, fabJoins, fabFilters, 100, true);

    const startMs = Date.now();
    const data = await rawQuery(sql, params);
    const durationMs = Date.now() - startMs;

    const previewResult = { columns, rows: data, rowCountShown: data.length, durationMs, executedAt: new Date().toISOString() };

    await db.update(datasetDrafts).set({
      status: "preview_approved",
      definitionJson: { ...def, previewResult },
      updatedAt: new Date(),
    }).where(eq(datasetDrafts.id, input.id));

    await insertAuditLog({ userId: ctx.user.id, action: "preview", sqlText: sql, rowCount: data.length, durationMs, executedAt: new Date() });

    return previewResult;
  }),

  // ── Full Execute ──────────────────────────────────────────────────────────────
  executeData: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    const { getDb } = await import("../db");
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB not available" });

    const { datasetDrafts } = await import("../../drizzle/schema");
    const { eq } = await import("drizzle-orm");
    const rows = await db.select().from(datasetDrafts).where(eq(datasetDrafts.id, input.id)).limit(1);
    if (!rows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Draft not found" });
    const def = (rows[0].definitionJson || {}) as any;

    const fabSelections = def.fabSelections ?? [];
    const fabJoins = def.fabJoins ?? [];
    const fabFilters = def.fabFilters ?? [];
    const rowLimit = def.rowLimit ?? 10000;

    const { sql, params, columns } = buildFabSql(fabSelections, fabJoins, fabFilters, rowLimit, false);

    const startMs = Date.now();
    const data = await rawQuery(sql, params);
    const durationMs = Date.now() - startMs;

    // Get total count
    // Build count SQL by extracting FROM clause
    const fromIdx = sql.indexOf("\nFROM");
    const limitIdx = sql.lastIndexOf("\nLIMIT ?");
    const countSql = fromIdx > 0
      ? "SELECT COUNT(*) as cnt" + sql.substring(fromIdx, limitIdx > 0 ? limitIdx : undefined)
      : sql;
    const countParams = params.slice(0, -1);
    let totalCount = data.length;
    try {
      const countRows = await rawQuery(countSql, countParams);
      totalCount = Number(countRows[0]?.cnt ?? data.length);
    } catch { /* ignore count error */ }

    const executeResult = { columns, rows: data, rowCount: data.length, totalCount, durationMs, executedAt: new Date().toISOString() };

    await db.update(datasetDrafts).set({
      status: "completed",
      definitionJson: { ...def, executeResult },
      updatedAt: new Date(),
    }).where(eq(datasetDrafts.id, input.id));

    await insertAuditLog({ userId: ctx.user.id, action: "execute", sqlText: sql, rowCount: data.length, durationMs, executedAt: new Date() });

    return executeResult;
  }),
});
