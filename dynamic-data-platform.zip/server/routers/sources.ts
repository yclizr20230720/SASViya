import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "../_core/trpc";
import {
  getAllDataSources, getDataSourceById, createDataSource, updateDataSource, deleteDataSource,
  getSchemasBySourceId, createDataSourceSchema, deleteDataSourceSchema,
  getTablesForSchema, getColumnsForTable, getDictionaryEntries,
  upsertCacheTable, upsertCacheColumn, clearSchemaCache,
  checkUserCanBrowse, insertAuditLog,
} from "../db";

// ─── Admin-only guard ──────────────────────────────────────────────────────────
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  return next({ ctx });
});

export const sourcesRouter = router({
  // ── List all sources (admin sees all, users see permitted ones) ──────────────
  list: protectedProcedure.query(async ({ ctx }) => {
    const sources = await getAllDataSources();
    if (ctx.user.role === "admin") return sources;
    // For regular users, filter by permission
    const { getPermissionsForUser } = await import("../db");
    const perms = await getPermissionsForUser(ctx.user.id);
    const permittedSourceIds = new Set(perms.filter(p => p.canBrowse).map(p => p.sourceId));
    return sources.filter(s => permittedSourceIds.has(s.id));
  }),

  // ── Get single source ────────────────────────────────────────────────────────
  getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
    const source = await getDataSourceById(input.id);
    if (!source) throw new TRPCError({ code: "NOT_FOUND" });
    return source;
  }),

  // ── Admin: Create source ─────────────────────────────────────────────────────
  create: adminProcedure.input(z.object({
    name: z.string().min(1).max(128),
    dialect: z.enum(["oracle", "postgresql", "mysql", "mssql", "sqlite"]),
    host: z.string().min(1),
    port: z.number().int().min(1).max(65535),
    database: z.string().min(1),
    readonlyCredentialRef: z.string().min(1),
    queryTimeoutSec: z.number().int().min(5).max(3600).default(30),
    maxRows: z.number().int().min(100).max(10000000).default(100000),
    maxConcurrentQueries: z.number().int().min(1).max(20).default(3),
    fullScanThreshold: z.number().int().min(1000).default(100000),
    description: z.string().optional(),
  })).mutation(async ({ input }) => {
    await createDataSource(input as any);
    return { success: true };
  }),

  // ── Admin: Update source ─────────────────────────────────────────────────────
  update: adminProcedure.input(z.object({
    id: z.number(),
    name: z.string().min(1).max(128).optional(),
    dialect: z.enum(["oracle", "postgresql", "mysql", "mssql", "sqlite"]).optional(),
    host: z.string().optional(),
    port: z.number().int().optional(),
    database: z.string().optional(),
    readonlyCredentialRef: z.string().optional(),
    queryTimeoutSec: z.number().int().optional(),
    maxRows: z.number().int().optional(),
    maxConcurrentQueries: z.number().int().optional(),
    fullScanThreshold: z.number().int().optional(),
    isActive: z.boolean().optional(),
    description: z.string().optional(),
  })).mutation(async ({ input }) => {
    const { id, ...data } = input;
    await updateDataSource(id, data as any);
    return { success: true };
  }),

  // ── Admin: Delete source ─────────────────────────────────────────────────────
  delete: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    await deleteDataSource(input.id);
    return { success: true };
  }),

  // ── List schemas for a source ────────────────────────────────────────────────
  listSchemas: protectedProcedure.input(z.object({ sourceId: z.number() })).query(async ({ ctx, input }) => {
    const schemas = await getSchemasBySourceId(input.sourceId);
    if (ctx.user.role === "admin") return schemas;
    // Filter by user browse permission
    const filtered = [];
    for (const s of schemas) {
      const canBrowse = await checkUserCanBrowse(ctx.user.id, input.sourceId, s.schemaName);
      if (canBrowse) filtered.push(s);
    }
    return filtered;
  }),

  // ── Admin: Add schema to source ──────────────────────────────────────────────
  addSchema: adminProcedure.input(z.object({
    sourceId: z.number(),
    schemaName: z.string().min(1),
    description: z.string().optional(),
  })).mutation(async ({ input }) => {
    await createDataSourceSchema(input);
    return { success: true };
  }),

  // ── Admin: Remove schema ─────────────────────────────────────────────────────
  removeSchema: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    await deleteDataSourceSchema(input.id);
    return { success: true };
  }),

  // ── List tables for a schema (from cache) ────────────────────────────────────
  listTables: protectedProcedure.input(z.object({
    sourceId: z.number(),
    schemaName: z.string(),
  })).query(async ({ ctx, input }) => {
    if (ctx.user.role !== "admin") {
      const canBrowse = await checkUserCanBrowse(ctx.user.id, input.sourceId, input.schemaName);
      if (!canBrowse) throw new TRPCError({ code: "FORBIDDEN" });
    }
    const tables = await getTablesForSchema(input.sourceId, input.schemaName);
    const dictEntries = await getDictionaryEntries(input.sourceId, input.schemaName);
    return tables.map(t => ({
      ...t,
      description: dictEntries.find(d => d.tableName === t.tableName && !d.columnName)?.description ?? null,
    }));
  }),

  // ── List columns for a table (from cache + dictionary) ───────────────────────
  listColumns: protectedProcedure.input(z.object({
    sourceId: z.number(),
    schemaName: z.string(),
    tableName: z.string(),
  })).query(async ({ ctx, input }) => {
    if (ctx.user.role !== "admin") {
      const canBrowse = await checkUserCanBrowse(ctx.user.id, input.sourceId, input.schemaName);
      if (!canBrowse) throw new TRPCError({ code: "FORBIDDEN" });
    }
    const columns = await getColumnsForTable(input.sourceId, input.schemaName, input.tableName);
    const dictEntries = await getDictionaryEntries(input.sourceId, input.schemaName);
    return columns.map(c => ({
      ...c,
      description: dictEntries.find(d => d.tableName === c.tableName && d.columnName === c.columnName)?.description ?? null,
    }));
  }),

  // ── Admin: Refresh metadata (simulate introspection by seeding demo data) ────
  refreshMetadata: adminProcedure.input(z.object({
    sourceId: z.number(),
    schemaName: z.string(),
  })).mutation(async ({ ctx, input }) => {
    const source = await getDataSourceById(input.sourceId);
    if (!source) throw new TRPCError({ code: "NOT_FOUND", message: "Source not found" });

    // In a real implementation, this would connect to the actual DB and introspect.
    // Here we seed representative demo tables/columns for the known sources.
    await clearSchemaCache(input.sourceId, input.schemaName);

    const demoTables = getDemoTablesForSchema(source.name, input.schemaName);
    for (const table of demoTables) {
      await upsertCacheTable({ sourceId: input.sourceId, schemaName: input.schemaName, tableName: table.name, approxRowCount: table.rowCount });
      for (const col of table.columns) {
        await upsertCacheColumn({ sourceId: input.sourceId, schemaName: input.schemaName, tableName: table.name, ...col });
      }
    }

    await insertAuditLog({
      userId: ctx.user.id, sourceId: input.sourceId,
      action: "refresh_metadata",
      executedAt: new Date(),
    });

    return { success: true, tablesRefreshed: demoTables.length };
  }),
});

// ─── Demo metadata for known sources ──────────────────────────────────────────
function getDemoTablesForSchema(sourceName: string, schemaName: string) {
  const upper = schemaName.toUpperCase();
  if (sourceName === "F12PEDA" && upper === "VEDA") {
    return [
      { name: "WAFER_RUN", rowCount: 5000000, columns: [
        { columnName: "WAFER_ID", dataType: "VARCHAR2(64)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
        { columnName: "LOT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
        { columnName: "PROCESS_STEP", dataType: "VARCHAR2(64)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 3 },
        { columnName: "START_TIME", dataType: "DATE", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 4 },
        { columnName: "END_TIME", dataType: "DATE", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 5 },
        { columnName: "EQUIPMENT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 6 },
        { columnName: "YIELD", dataType: "NUMBER(10,4)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 7 },
      ]},
      { name: "LOT_MASTER", rowCount: 200000, columns: [
        { columnName: "LOT_ID", dataType: "VARCHAR2(32)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
        { columnName: "PRODUCT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
        { columnName: "CUSTOMER", dataType: "VARCHAR2(64)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 3 },
        { columnName: "CREATE_DATE", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4 },
        { columnName: "STATUS", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 5 },
      ]},
      { name: "EQUIPMENT_STATUS", rowCount: 50000, columns: [
        { columnName: "EQP_ID", dataType: "VARCHAR2(32)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
        { columnName: "STATUS", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
        { columnName: "LAST_UPDATE", dataType: "DATE", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 3 },
        { columnName: "AREA", dataType: "VARCHAR2(32)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 4 },
      ]},
    ];
  }
  if (sourceName === "F12PEDA" && upper === "FDC") {
    return [
      { name: "FDC_ALARM", rowCount: 10000000, columns: [
        { columnName: "ALARM_ID", dataType: "NUMBER(18)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
        { columnName: "WAFER_ID", dataType: "VARCHAR2(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
        { columnName: "EQP_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
        { columnName: "ALARM_CODE", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4 },
        { columnName: "ALARM_TIME", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 5 },
        { columnName: "SEVERITY", dataType: "VARCHAR2(8)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 6 },
      ]},
    ];
  }
  if (sourceName === "f12edagp" && schemaName.toLowerCase() === "veda") {
    return [
      { name: "wafer_summary", rowCount: 50000000, columns: [
        { columnName: "wafer_id", dataType: "varchar(64)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
        { columnName: "lot_id", dataType: "varchar(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
        { columnName: "product", dataType: "varchar(32)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 3 },
        { columnName: "process_step", dataType: "varchar(64)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 4 },
        { columnName: "run_date", dataType: "date", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 5 },
        { columnName: "yield_rate", dataType: "numeric(10,4)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 6 },
        { columnName: "die_count", dataType: "integer", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 7 },
      ]},
      { name: "spc_chart", rowCount: 20000000, columns: [
        { columnName: "chart_id", dataType: "bigint", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
        { columnName: "wafer_id", dataType: "varchar(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
        { columnName: "parameter", dataType: "varchar(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
        { columnName: "value", dataType: "numeric(18,6)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 4 },
        { columnName: "ucl", dataType: "numeric(18,6)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 5 },
        { columnName: "lcl", dataType: "numeric(18,6)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 6 },
        { columnName: "measured_at", dataType: "timestamp", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 7 },
      ]},
    ];
  }
  // Default: return a few generic demo tables
  return [
    { name: `${upper}_MASTER`, rowCount: 10000, columns: [
      { columnName: "ID", dataType: "NUMBER(18)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
      { columnName: "NAME", dataType: "VARCHAR2(128)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 2 },
      { columnName: "CREATED_AT", dataType: "DATE", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 3 },
    ]},
  ];
}
