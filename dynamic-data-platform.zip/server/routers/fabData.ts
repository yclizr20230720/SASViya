/**
 * Fab Data Router
 * Provides direct query access to the 10 real semiconductor fab tables.
 * Uses mysql2 raw pool for parameterized queries (bypasses drizzle ORM).
 */
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "../_core/trpc";
import { insertAuditLog } from "../db";
import { SEMI_FAB_TABLES } from "../mockDb/semiFabScenarios";
import mysql2 from "mysql2/promise";

// ── Raw MySQL pool ─────────────────────────────────────────────────────────────
let _rawPool: mysql2.Pool | null = null;
function getRawPool(): mysql2.Pool {
  if (!_rawPool && process.env.DATABASE_URL) {
    // TiDB Serverless requires SSL — pass ssl option explicitly
    _rawPool = mysql2.createPool({
      uri: process.env.DATABASE_URL,
      ssl: { rejectUnauthorized: true },
      connectTimeout: 30000,
      connectionLimit: 5,
    });
  }
  if (!_rawPool) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB not available" });
  return _rawPool;
}
async function rawQuery(sql: string, params: any[] = []): Promise<any[]> {
  const pool = getRawPool();
  const [rows] = await pool.query(sql, params);
  return Array.isArray(rows) ? rows as any[] : [];
}

// ── Table name whitelist ───────────────────────────────────────────────────────
const FAB_TABLE_MAP: Record<string, string> = {
  LOT_HISTORY:       "fab_lot_history",
  WAFER_HISTORY:     "fab_wafer_history",
  EQUIPMENT_TOOL:    "fab_equipment_tool",
  WAT_DATA:          "fab_wat_data",
  CP_DATA:           "fab_cp_data",
  FDC_DATA:          "fab_fdc_data",
  INLINE_THICKNESS:  "fab_inline_thickness",
  CD_MEASUREMENT:    "fab_cd_measurement",
  DEFECT_INSPECTION: "fab_defect_inspection",
  EQUIPMENT_PM:      "fab_equipment_pm",
};

const FAB_COLUMNS: Record<string, Set<string>> = {};
for (const t of SEMI_FAB_TABLES) {
  FAB_COLUMNS[t.tableName] = new Set(t.columns.map(c => c.columnName.toUpperCase()));
}

function validateTableName(name: string): string {
  const mapped = FAB_TABLE_MAP[name.toUpperCase()];
  if (!mapped) throw new TRPCError({ code: "BAD_REQUEST", message: `Unknown table: ${name}` });
  return mapped;
}

function validateColumns(tableName: string, columns: string[]): string[] {
  const allowed = FAB_COLUMNS[tableName.toUpperCase()];
  if (!allowed) return columns;
  const invalid = columns.filter(c => !allowed.has(c.toUpperCase()));
  if (invalid.length > 0) throw new TRPCError({ code: "BAD_REQUEST", message: `Invalid columns: ${invalid.join(", ")}` });
  return columns;
}

type FilterOp = "eq"|"neq"|"gt"|"gte"|"lt"|"lte"|"like"|"in"|"between"|"is_null"|"is_not_null";

function buildWhereClause(
  filters: Array<{ column: string; operator: FilterOp; value?: any }>,
  params: any[]
): string {
  if (!filters || filters.length === 0) return "";
  const parts: string[] = [];
  for (const f of filters) {
    const col = `\`${f.column}\``;
    switch (f.operator) {
      case "eq":          parts.push(`${col} = ?`); params.push(f.value); break;
      case "neq":         parts.push(`${col} != ?`); params.push(f.value); break;
      case "gt":          parts.push(`${col} > ?`); params.push(f.value); break;
      case "gte":         parts.push(`${col} >= ?`); params.push(f.value); break;
      case "lt":          parts.push(`${col} < ?`); params.push(f.value); break;
      case "lte":         parts.push(`${col} <= ?`); params.push(f.value); break;
      case "like":        parts.push(`${col} LIKE ?`); params.push(f.value); break;
      case "is_null":     parts.push(`${col} IS NULL`); break;
      case "is_not_null": parts.push(`${col} IS NOT NULL`); break;
      case "in": {
        const vals = Array.isArray(f.value) ? f.value : [f.value];
        parts.push(`${col} IN (${vals.map(() => "?").join(",")})`);
        params.push(...vals);
        break;
      }
      case "between": {
        const vals = Array.isArray(f.value) ? f.value : [f.value, f.value];
        parts.push(`${col} BETWEEN ? AND ?`);
        params.push(vals[0], vals[1]);
        break;
      }
    }
  }
  return parts.length > 0 ? `WHERE ${parts.join(" AND ")}` : "";
}

const filterSchema = z.object({
  column: z.string(),
  operator: z.enum(["eq","neq","gt","gte","lt","lte","like","in","between","is_null","is_not_null"]),
  value: z.any().optional(),
});

export const fabDataRouter = router({

  // ── List all fab tables with metadata ─────────────────────────────────────────
  listTables: protectedProcedure.query(async () => {
    return SEMI_FAB_TABLES.map(t => ({
      tableName: t.tableName,
      physicalName: FAB_TABLE_MAP[t.tableName] ?? t.tableName.toLowerCase(),
      approxRowCount: t.approxRowCount,
      comment: t.comment ?? null,
      businessDomain: t.businessDomain ?? null,
      columnCount: t.columns.length,
      indexCount: t.indexes.length,
      fkCount: t.foreignKeys.length,
      columns: t.columns.map(c => ({
        columnName: c.columnName,
        dataType: c.dataType,
        isKey: c.isKey,
        isIndexed: c.isIndexed,
        isNullable: c.isNullable,
        comment: c.comment ?? null,
      })),
      indexes: t.indexes,
      foreignKeys: t.foreignKeys,
    }));
  }),

  // ── Get actual row count ───────────────────────────────────────────────────────
  getRowCount: protectedProcedure.input(z.object({
    tableName: z.string(),
    filters: z.array(filterSchema).optional(),
  })).query(async ({ input }) => {
    const physTable = validateTableName(input.tableName);
    const params: any[] = [];
    const where = buildWhereClause(input.filters ?? [], params);
    const rows = await rawQuery(`SELECT COUNT(*) as cnt FROM \`${physTable}\` ${where}`, params);
    return { count: Number(rows[0]?.cnt ?? 0) };
  }),

  // ── Preview query (100 rows) ──────────────────────────────────────────────────
  previewQuery: protectedProcedure.input(z.object({
    tableName: z.string(),
    columns: z.array(z.string()).min(1),
    filters: z.array(filterSchema).optional(),
    orderBy: z.string().optional(),
    orderDir: z.enum(["ASC", "DESC"]).optional(),
  })).mutation(async ({ ctx, input }) => {
    const physTable = validateTableName(input.tableName);
    validateColumns(input.tableName, input.columns);
    const params: any[] = [];
    const where = buildWhereClause(input.filters ?? [], params);
    const colList = input.columns.map(c => `\`${c}\``).join(", ");
    const orderClause = input.orderBy ? `ORDER BY \`${input.orderBy}\` ${input.orderDir ?? "ASC"}` : "";
    const querySql = `SELECT ${colList} FROM \`${physTable}\` ${where} ${orderClause} LIMIT 100`;
    const startMs = Date.now();
    const data = await rawQuery(querySql, params);
    const durationMs = Date.now() - startMs;
    await insertAuditLog({ userId: ctx.user.id, action: "fab_preview", sqlText: querySql, rowCount: data.length, durationMs, executedAt: new Date() });
    return { columns: input.columns, rows: data, rowCount: data.length, durationMs, sql: querySql };
  }),

  // ── Full query with pagination ────────────────────────────────────────────────
  executeQuery: protectedProcedure.input(z.object({
    tableName: z.string(),
    columns: z.array(z.string()).min(1),
    filters: z.array(filterSchema).optional(),
    orderBy: z.string().optional(),
    orderDir: z.enum(["ASC", "DESC"]).optional(),
    limit: z.number().int().min(1).max(10000).default(1000),
    offset: z.number().int().min(0).default(0),
  })).mutation(async ({ ctx, input }) => {
    const physTable = validateTableName(input.tableName);
    validateColumns(input.tableName, input.columns);
    const params: any[] = [];
    const where = buildWhereClause(input.filters ?? [], params);
    const colList = input.columns.map(c => `\`${c}\``).join(", ");
    const orderClause = input.orderBy ? `ORDER BY \`${input.orderBy}\` ${input.orderDir ?? "ASC"}` : "";
    const querySql = `SELECT ${colList} FROM \`${physTable}\` ${where} ${orderClause} LIMIT ? OFFSET ?`;
    params.push(input.limit, input.offset);
    const startMs = Date.now();
    const data = await rawQuery(querySql, params);
    const durationMs = Date.now() - startMs;
    const countParams: any[] = [];
    const countRows = await rawQuery(`SELECT COUNT(*) as cnt FROM \`${physTable}\` ${buildWhereClause(input.filters ?? [], countParams)}`, countParams);
    const totalCount = Number(countRows[0]?.cnt ?? 0);
    await insertAuditLog({ userId: ctx.user.id, action: "fab_execute", sqlText: querySql, rowCount: data.length, durationMs, executedAt: new Date() });
    return { columns: input.columns, rows: data, rowCount: data.length, totalCount, durationMs, sql: querySql, hasMore: input.offset + data.length < totalCount };
  }),

  // ── Cross-table join query ────────────────────────────────────────────────────
  joinQuery: protectedProcedure.input(z.object({
    leftTable: z.string(),
    leftColumns: z.array(z.string()).min(1),
    rightTable: z.string(),
    rightColumns: z.array(z.string()).min(1),
    joinColumn: z.string(),
    joinType: z.enum(["INNER", "LEFT", "RIGHT"]).default("INNER"),
    filters: z.array(filterSchema).optional(),
    limit: z.number().int().min(1).max(1000).default(100),
  })).mutation(async ({ ctx, input }) => {
    const leftPhys = validateTableName(input.leftTable);
    const rightPhys = validateTableName(input.rightTable);
    validateColumns(input.leftTable, input.leftColumns);
    validateColumns(input.rightTable, input.rightColumns);
    const leftCols = input.leftColumns.map(c => `l.\`${c}\` AS \`${input.leftTable}_${c}\``).join(", ");
    const rightCols = input.rightColumns.map(c => `r.\`${c}\` AS \`${input.rightTable}_${c}\``).join(", ");
    const params: any[] = [];
    const where = buildWhereClause(input.filters ?? [], params);
    const joinSql = `SELECT ${leftCols}, ${rightCols} FROM \`${leftPhys}\` l ${input.joinType} JOIN \`${rightPhys}\` r ON l.\`${input.joinColumn}\` = r.\`${input.joinColumn}\` ${where} LIMIT ?`;
    params.push(input.limit);
    const startMs = Date.now();
    const data = await rawQuery(joinSql, params);
    const durationMs = Date.now() - startMs;
    const allColumns = [...input.leftColumns.map(c => `${input.leftTable}_${c}`), ...input.rightColumns.map(c => `${input.rightTable}_${c}`)];
    await insertAuditLog({ userId: ctx.user.id, action: "fab_join_query", sqlText: joinSql, rowCount: data.length, durationMs, executedAt: new Date() });
    return { columns: allColumns, rows: data, rowCount: data.length, durationMs, sql: joinSql };
  }),

  // ── Get distinct values for filter dropdowns ──────────────────────────────────
  getDistinctValues: protectedProcedure.input(z.object({
    tableName: z.string(),
    column: z.string(),
    limit: z.number().int().min(1).max(200).default(50),
  })).query(async ({ input }) => {
    const physTable = validateTableName(input.tableName);
    const rows = await rawQuery(`SELECT DISTINCT \`${input.column}\` as val FROM \`${physTable}\` WHERE \`${input.column}\` IS NOT NULL ORDER BY \`${input.column}\` LIMIT ?`, [input.limit]);
    return rows.map(r => r.val);
  }),
});
