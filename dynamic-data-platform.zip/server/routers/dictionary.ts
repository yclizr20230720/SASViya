import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "../_core/trpc";
import { getDictionaryEntries, upsertDictionaryEntry, insertAuditLog } from "../db";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  return next({ ctx });
});

export const dictionaryRouter = router({
  // ── List entries for a source/schema ────────────────────────────────────────
  list: protectedProcedure.input(z.object({
    sourceId: z.number(),
    schemaName: z.string(),
  })).query(async ({ input }) => {
    return getDictionaryEntries(input.sourceId, input.schemaName);
  }),

  // ── Admin: Bulk import (parsed from file on frontend) ────────────────────────
  bulkImport: adminProcedure.input(z.object({
    entries: z.array(z.object({
      sourceId: z.number(),
      schemaName: z.string(),
      tableName: z.string(),
      columnName: z.string().nullable().optional(),
      description: z.string(),
    })),
  })).mutation(async ({ ctx, input }) => {
    let imported = 0;
    for (const entry of input.entries) {
      await upsertDictionaryEntry({
        sourceId: entry.sourceId,
        schemaName: entry.schemaName,
        tableName: entry.tableName,
        columnName: entry.columnName ?? undefined,
        description: entry.description,
      });
      imported++;
    }
    await insertAuditLog({
      userId: ctx.user.id,
      action: "dictionary_import",
      executedAt: new Date(),
    });
    return { success: true, imported };
  }),

  // ── Admin: Upsert single entry ───────────────────────────────────────────────
  upsert: adminProcedure.input(z.object({
    sourceId: z.number(),
    schemaName: z.string(),
    tableName: z.string(),
    columnName: z.string().nullable().optional(),
    description: z.string(),
  })).mutation(async ({ input }) => {
    await upsertDictionaryEntry({
      sourceId: input.sourceId,
      schemaName: input.schemaName,
      tableName: input.tableName,
      columnName: input.columnName ?? undefined,
      description: input.description,
    });
    return { success: true };
  }),
});
