import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "../_core/trpc";
import {
  getAllUsers, getPermissionsForUser, getPermissionsForSource,
  upsertSourcePermission, deleteSourcePermission, toPublicUser, updateUserRole,
} from "../db";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  return next({ ctx });
});

export const permissionsRouter = router({
  // ── List all users (admin) ───────────────────────────────────────────────────
  listUsers: adminProcedure.query(async () => {
    return (await getAllUsers()).map(toPublicUser);
  }),

  // ── Get permissions for a user ───────────────────────────────────────────────
  getUserPermissions: adminProcedure.input(z.object({ userId: z.number() })).query(async ({ input }) => {
    return getPermissionsForUser(input.userId);
  }),

  // ── Get permissions for a source ─────────────────────────────────────────────
  getSourcePermissions: adminProcedure.input(z.object({ sourceId: z.number() })).query(async ({ input }) => {
    return getPermissionsForSource(input.sourceId);
  }),

  // ── Upsert permission ────────────────────────────────────────────────────────
  upsert: adminProcedure.input(z.object({
    userId: z.number(),
    sourceId: z.number(),
    schemaName: z.string().nullable().optional(),
    canBrowse: z.boolean(),
    canExecute: z.boolean(),
  })).mutation(async ({ input }) => {
    await upsertSourcePermission({
      userId: input.userId,
      sourceId: input.sourceId,
      schemaName: input.schemaName ?? undefined,
      canBrowse: input.canBrowse,
      canExecute: input.canExecute,
    });
    return { success: true };
  }),

  // ── Delete permission ────────────────────────────────────────────────────────
  delete: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    await deleteSourcePermission(input.id);
    return { success: true };
  }),

  // ── Update user role ─────────────────────────────────────────────────────────
  updateRole: adminProcedure.input(z.object({
    userId: z.number(),
    role: z.enum(["user", "admin"]),
  })).mutation(async ({ input }) => {
    await updateUserRole(input.userId, input.role);
    return { success: true };
  }),

  // ── Get my own permissions ───────────────────────────────────────────────────
  myPermissions: protectedProcedure.query(async ({ ctx }) => {
    return getPermissionsForUser(ctx.user.id);
  }),
});
