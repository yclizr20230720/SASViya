import { describe, expect, it } from "vitest";

// ─── Inline helpers (mirrors server/routers/datasets.ts logic) ────────────────
function tokenOverlapScore(a: string, b: string): number {
  const tokA = a.toLowerCase().split(/[\s_\-\.]+/).filter(Boolean);
  const tokB = new Set(b.toLowerCase().split(/[\s_\-\.]+/).filter(Boolean));
  if (tokA.length === 0 || tokB.size === 0) return 0;
  let overlap = 0;
  for (let i = 0; i < tokA.length; i++) { if (tokB.has(tokA[i])) overlap++; }
  return (overlap * 2) / (tokA.length + tokB.size);
}

type FilterCriteria = {
  id: string; sourceId: number; schemaName: string; tableName: string;
  columnName: string; operator: string; value: string | string[] | null; scope?: string;
};
type ColumnSelection = { sourceId: number; schemaName: string; tableName: string; columns: string[]; };
type JoinDefinition = { leftSourceId: number; leftSchema: string; leftTable: string; leftColumn: string; rightSourceId: number; rightSchema: string; rightTable: string; rightColumn: string; joinType: string; };
type DatasetDefinition = { selections: ColumnSelection[]; joins: JoinDefinition[]; criteria: FilterCriteria[]; requirementItems: any[]; };

function buildSql(def: DatasetDefinition): { sql: string; params: Record<string, unknown>; issues: string[] } {
  const issues: string[] = [];
  if (!def.selections || def.selections.length === 0) return { sql: "", params: {}, issues: ["No columns selected"] };
  const params: Record<string, unknown> = {};
  let paramIdx = 0;
  const nextParam = (val: unknown) => { const k = `p${++paramIdx}`; params[k] = val; return `:${k}`; };
  const selectParts: string[] = [];
  for (const sel of def.selections) {
    for (const col of sel.columns) selectParts.push(`${sel.schemaName}.${sel.tableName}.${col}`);
  }
  const firstSel = def.selections[0];
  let fromClause = `${firstSel.schemaName}.${firstSel.tableName}`;
  const joinParts: string[] = [];
  for (const join of (def.joins || [])) {
    joinParts.push(`${join.joinType} JOIN ${join.rightSchema}.${join.rightTable} ON ${join.leftSchema}.${join.leftTable}.${join.leftColumn} = ${join.rightSchema}.${join.rightTable}.${join.rightColumn}`);
  }
  for (let i = 1; i < def.selections.length; i++) {
    const sel = def.selections[i];
    const alreadyJoined = (def.joins || []).some(j => (j.rightSchema === sel.schemaName && j.rightTable === sel.tableName) || (j.leftSchema === sel.schemaName && j.leftTable === sel.tableName));
    if (!alreadyJoined) { joinParts.push(`, ${sel.schemaName}.${sel.tableName}`); issues.push(`Table ${sel.schemaName}.${sel.tableName} added without explicit join`); }
  }
  const whereParts: string[] = [];
  for (const crit of (def.criteria || [])) {
    const col = `${crit.schemaName}.${crit.tableName}.${crit.columnName}`;
    switch (crit.operator) {
      case "eq":    whereParts.push(`${col} = ${nextParam(crit.value)}`); break;
      case "gt":    whereParts.push(`${col} > ${nextParam(crit.value)}`); break;
      case "like":  whereParts.push(`${col} LIKE ${nextParam(crit.value)}`); break;
      case "in": {
        const vals = Array.isArray(crit.value) ? crit.value : [crit.value];
        whereParts.push(`${col} IN (${vals.map(v => nextParam(v)).join(", ")})`); break;
      }
      case "between": {
        const vals = Array.isArray(crit.value) ? crit.value : [crit.value, crit.value];
        whereParts.push(`${col} BETWEEN ${nextParam(vals[0])} AND ${nextParam(vals[1])}`); break;
      }
      case "is_null": whereParts.push(`${col} IS NULL`); break;
    }
  }
  let sqlStr = `SELECT ${selectParts.join(",\n       ")}\nFROM   ${fromClause}`;
  if (joinParts.length > 0) sqlStr += `\n${joinParts.join("\n")}`;
  if (whereParts.length > 0) sqlStr += `\nWHERE  ${whereParts.join("\n  AND  ")}`;
  return { sql: sqlStr, params, issues };
}

type EvaluationFinding = { type: string; severity: "warn" | "block"; table: string; column?: string; message: string; };

function evaluatePerformanceSync(
  def: DatasetDefinition,
  tableMetadata: Array<{ schemaName: string; tableName: string; rowCount: number; columns: Array<{ columnName: string; isIndexed: boolean; isKey: boolean }> }>,
  fullScanThreshold: number
): { verdict: "pass" | "warn" | "block"; findings: EvaluationFinding[] } {
  const findings: EvaluationFinding[] = [];
  for (const sel of def.selections) {
    const tableMeta = tableMetadata.find(t => t.schemaName === sel.schemaName && t.tableName === sel.tableName);
    const rowCount = tableMeta?.rowCount ?? 0;
    const columns = tableMeta?.columns ?? [];
    const tableCriteria = (def.criteria || []).filter(c => c.tableName === sel.tableName && c.schemaName === sel.schemaName);
    const tableJoins = (def.joins || []).filter(j => (j.leftTable === sel.tableName && j.leftSchema === sel.schemaName) || (j.rightTable === sel.tableName && j.rightSchema === sel.schemaName));
    if (rowCount > fullScanThreshold && tableCriteria.length === 0 && tableJoins.length === 0) {
      findings.push({ type: "full_table_scan", severity: "block", table: `${sel.schemaName}.${sel.tableName}`, message: `Full table scan on large table (${rowCount} rows)` });
    }
    for (const crit of tableCriteria) {
      const colMeta = columns.find(c => c.columnName === crit.columnName);
      if (colMeta && !colMeta.isIndexed && !colMeta.isKey) {
        findings.push({ type: "missing_index", severity: rowCount > fullScanThreshold ? "block" : "warn", table: `${sel.schemaName}.${sel.tableName}`, column: crit.columnName, message: `Column ${crit.columnName} is not indexed` });
      }
    }
  }
  const hasBlock = findings.some(f => f.severity === "block");
  const hasWarn = findings.some(f => f.severity === "warn");
  return { verdict: hasBlock ? "block" : hasWarn ? "warn" : "pass", findings };
}

// ─── Tests ────────────────────────────────────────────────────────────────────
describe("Source Matcher - tokenOverlapScore", () => {
  it("returns 1.0 for identical strings", () => {
    expect(tokenOverlapScore("wafer_id", "wafer_id")).toBe(1);
  });
  it("returns 0 for completely different strings", () => {
    expect(tokenOverlapScore("wafer_id", "customer_name")).toBe(0);
  });
  it("returns partial score for partial overlap", () => {
    const score = tokenOverlapScore("wafer run date", "run date timestamp");
    expect(score).toBeGreaterThan(0);
    expect(score).toBeLessThan(1);
  });
  it("handles empty strings", () => {
    expect(tokenOverlapScore("", "wafer_id")).toBe(0);
    expect(tokenOverlapScore("wafer_id", "")).toBe(0);
  });
  it("is case-insensitive", () => {
    expect(tokenOverlapScore("WAFER_ID", "wafer_id")).toBe(1);
  });
});

describe("Query Builder - buildSql", () => {
  it("generates correct single-table SELECT", () => {
    const def: DatasetDefinition = {
      selections: [{ sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columns: ["WAFER_ID", "LOT_ID"] }],
      joins: [], criteria: [], requirementItems: [],
    };
    const { sql, params, issues } = buildSql(def);
    expect(sql).toContain("SELECT");
    expect(sql).toContain("VEDA.WAFER_RUN.WAFER_ID");
    expect(sql).toContain("VEDA.WAFER_RUN.LOT_ID");
    expect(sql).toContain("FROM   VEDA.WAFER_RUN");
    expect(issues).toHaveLength(0);
  });

  it("adds WHERE clause with bound parameters for eq filter", () => {
    const def: DatasetDefinition = {
      selections: [{ sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columns: ["WAFER_ID"] }],
      joins: [], requirementItems: [],
      criteria: [{ id: "1", sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columnName: "LOT_ID", operator: "eq", value: "LOT001" }],
    };
    const { sql, params } = buildSql(def);
    expect(sql).toContain("WHERE");
    expect(sql).toContain(":p1");
    expect(params["p1"]).toBe("LOT001");
    // Ensure user value is NOT directly in SQL (parameterized)
    expect(sql).not.toContain("LOT001");
  });

  it("handles IN operator with multiple values", () => {
    const def: DatasetDefinition = {
      selections: [{ sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columns: ["WAFER_ID"] }],
      joins: [], requirementItems: [],
      criteria: [{ id: "1", sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columnName: "STATUS", operator: "in", value: ["PASS", "FAIL"] }],
    };
    const { sql, params } = buildSql(def);
    expect(sql).toContain("IN (:p1, :p2)");
    expect(params["p1"]).toBe("PASS");
    expect(params["p2"]).toBe("FAIL");
  });

  it("generates JOIN clause for multi-table query", () => {
    const def: DatasetDefinition = {
      selections: [
        { sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columns: ["WAFER_ID"] },
        { sourceId: 1, schemaName: "VEDA", tableName: "LOT_MASTER", columns: ["PRODUCT_ID"] },
      ],
      joins: [{ leftSourceId: 1, leftSchema: "VEDA", leftTable: "WAFER_RUN", leftColumn: "LOT_ID", rightSourceId: 1, rightSchema: "VEDA", rightTable: "LOT_MASTER", rightColumn: "LOT_ID", joinType: "INNER" }],
      criteria: [], requirementItems: [],
    };
    const { sql, issues } = buildSql(def);
    expect(sql).toContain("INNER JOIN VEDA.LOT_MASTER");
    expect(issues).toHaveLength(0);
  });

  it("returns empty sql and issue when no selections", () => {
    const def: DatasetDefinition = { selections: [], joins: [], criteria: [], requirementItems: [] };
    const { sql, issues } = buildSql(def);
    expect(sql).toBe("");
    expect(issues[0]).toContain("No columns selected");
  });
});

describe("Performance Evaluator", () => {
  const tableMetadata = [
    {
      schemaName: "VEDA", tableName: "WAFER_RUN", rowCount: 5000000,
      columns: [
        { columnName: "WAFER_ID", isIndexed: true, isKey: true },
        { columnName: "LOT_ID", isIndexed: true, isKey: false },
        { columnName: "YIELD", isIndexed: false, isKey: false },
      ],
    },
    {
      schemaName: "VEDA", tableName: "LOT_MASTER", rowCount: 50000,
      columns: [
        { columnName: "LOT_ID", isIndexed: true, isKey: true },
        { columnName: "CUSTOMER", isIndexed: false, isKey: false },
      ],
    },
  ];
  const threshold = 100000;

  it("returns pass when indexed filter on large table", () => {
    const def: DatasetDefinition = {
      selections: [{ sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columns: ["WAFER_ID"] }],
      joins: [], requirementItems: [],
      criteria: [{ id: "1", sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columnName: "LOT_ID", operator: "eq", value: "LOT001" }],
    };
    const { verdict, findings } = evaluatePerformanceSync(def, tableMetadata, threshold);
    expect(verdict).toBe("pass");
    expect(findings).toHaveLength(0);
  });

  it("returns block when large table has no filter", () => {
    const def: DatasetDefinition = {
      selections: [{ sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columns: ["WAFER_ID"] }],
      joins: [], criteria: [], requirementItems: [],
    };
    const { verdict, findings } = evaluatePerformanceSync(def, tableMetadata, threshold);
    expect(verdict).toBe("block");
    expect(findings.some(f => f.type === "full_table_scan")).toBe(true);
  });

  it("returns warn when non-indexed filter on small table", () => {
    const def: DatasetDefinition = {
      selections: [{ sourceId: 1, schemaName: "VEDA", tableName: "LOT_MASTER", columns: ["LOT_ID"] }],
      joins: [], requirementItems: [],
      criteria: [{ id: "1", sourceId: 1, schemaName: "VEDA", tableName: "LOT_MASTER", columnName: "CUSTOMER", operator: "eq", value: "TSMC" }],
    };
    const { verdict, findings } = evaluatePerformanceSync(def, tableMetadata, threshold);
    expect(verdict).toBe("warn");
    expect(findings.some(f => f.type === "missing_index" && f.severity === "warn")).toBe(true);
  });

  it("returns block when non-indexed filter on large table", () => {
    const def: DatasetDefinition = {
      selections: [{ sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columns: ["WAFER_ID"] }],
      joins: [], requirementItems: [],
      criteria: [{ id: "1", sourceId: 1, schemaName: "VEDA", tableName: "WAFER_RUN", columnName: "YIELD", operator: "gt", value: "0.9" }],
    };
    const { verdict, findings } = evaluatePerformanceSync(def, tableMetadata, threshold);
    expect(verdict).toBe("block");
    expect(findings.some(f => f.severity === "block")).toBe(true);
  });

  it("passes for small table with no filter", () => {
    const def: DatasetDefinition = {
      selections: [{ sourceId: 1, schemaName: "VEDA", tableName: "LOT_MASTER", columns: ["LOT_ID"] }],
      joins: [], criteria: [], requirementItems: [],
    };
    const { verdict } = evaluatePerformanceSync(def, tableMetadata, threshold);
    expect(verdict).toBe("pass");
  });
});
