import { eq, and, or, isNull, isNotNull, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  dataSources,
  dataSourceSchemas,
  sourcePermissions,
  schemaCacheTables,
  schemaCacheColumns,
  dictionaryEntries,
  datasetDrafts,
  executionJobs,
  queryAuditLog,
  InsertDataSource,
  InsertDataSourceSchema,
  InsertSourcePermission,
  InsertDictionaryEntry,
  InsertDatasetDraft,
  InsertExecutionJob,
  InsertQueryAuditLog,
  DatasetDefinition,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ─────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod", "passwordHash"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

function localUserOpenId(email: string) {
  return `local:${email.trim().toLowerCase()}`;
}

export async function getLocalUserByEmail(email: string) {
  return getUserByOpenId(localUserOpenId(email));
}

/** Creates a self-contained DDOP account. The first local account is the bootstrap admin. */
export async function createLocalUser(input: {
  email: string;
  name: string;
  passwordHash: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");

  const normalizedEmail = input.email.trim().toLowerCase();
  const existing = await getLocalUserByEmail(normalizedEmail);
  if (existing) throw new Error("LOCAL_USER_EXISTS");

  const localAccountCount = await db
    .select({ count: sql<number>`count(*)` })
    .from(users)
    .where(isNotNull(users.passwordHash));
  const role = (localAccountCount[0]?.count ?? 0) === 0 ? "admin" : "user";

  await db.insert(users).values({
    openId: localUserOpenId(normalizedEmail),
    email: normalizedEmail,
    name: input.name.trim(),
    loginMethod: "local_jwt",
    passwordHash: input.passwordHash,
    role,
    lastSignedIn: new Date(),
  });

  const user = await getLocalUserByEmail(normalizedEmail);
  if (!user) throw new Error("LOCAL_USER_CREATE_FAILED");
  return user;
}

export async function updateLocalUserLastSignedIn(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, userId));
}

export function toPublicUser<T extends typeof users.$inferSelect>(user: T) {
  const { passwordHash: _passwordHash, ...publicUser } = user;
  return publicUser;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt));
}

export async function updateUserRole(userId: number, role: "user" | "admin") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

// ─── Data Sources ──────────────────────────────────────────────────────────────
export async function getAllDataSources() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(dataSources).orderBy(dataSources.name);
}

export async function getDataSourceById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(dataSources).where(eq(dataSources.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDataSource(data: InsertDataSource) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(dataSources).values(data);
  return result;
}

export async function updateDataSource(id: number, data: Partial<InsertDataSource>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(dataSources).set(data).where(eq(dataSources.id, id));
}

export async function deleteDataSource(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(dataSources).where(eq(dataSources.id, id));
}

// ─── Data Source Schemas ───────────────────────────────────────────────────────
export async function getSchemasBySourceId(sourceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(dataSourceSchemas).where(eq(dataSourceSchemas.sourceId, sourceId));
}

export async function createDataSourceSchema(data: InsertDataSourceSchema) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(dataSourceSchemas).values(data);
}

export async function deleteDataSourceSchema(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(dataSourceSchemas).where(eq(dataSourceSchemas.id, id));
}

// ─── Source Permissions ────────────────────────────────────────────────────────
export async function getPermissionsForUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(sourcePermissions).where(eq(sourcePermissions.userId, userId));
}

export async function getPermissionsForSource(sourceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(sourcePermissions).where(eq(sourcePermissions.sourceId, sourceId));
}

export async function checkUserCanBrowse(userId: number, sourceId: number, schemaName?: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  const perms = await db.select().from(sourcePermissions).where(
    and(
      eq(sourcePermissions.userId, userId),
      eq(sourcePermissions.sourceId, sourceId),
    )
  );
  if (perms.length === 0) return false;
  // Check schema-specific or wildcard permission
  const schemaPerm = schemaName ? perms.find(p => p.schemaName === schemaName && p.canBrowse) : null;
  const wildcardPerm = perms.find(p => p.schemaName === null && p.canBrowse);
  return !!(schemaPerm || wildcardPerm);
}

export async function checkUserCanExecute(userId: number, sourceId: number, schemaName?: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  const perms = await db.select().from(sourcePermissions).where(
    and(
      eq(sourcePermissions.userId, userId),
      eq(sourcePermissions.sourceId, sourceId),
    )
  );
  if (perms.length === 0) return false;
  const schemaPerm = schemaName ? perms.find(p => p.schemaName === schemaName && p.canExecute) : null;
  const wildcardPerm = perms.find(p => p.schemaName === null && p.canExecute);
  return !!(schemaPerm || wildcardPerm);
}

export async function upsertSourcePermission(data: InsertSourcePermission) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // Check if exists
  const existing = await db.select().from(sourcePermissions).where(
    and(
      eq(sourcePermissions.userId, data.userId),
      eq(sourcePermissions.sourceId, data.sourceId),
      data.schemaName ? eq(sourcePermissions.schemaName, data.schemaName) : isNull(sourcePermissions.schemaName),
    )
  ).limit(1);
  if (existing.length > 0) {
    await db.update(sourcePermissions)
      .set({ canBrowse: data.canBrowse, canExecute: data.canExecute })
      .where(eq(sourcePermissions.id, existing[0].id));
  } else {
    await db.insert(sourcePermissions).values(data);
  }
}

export async function deleteSourcePermission(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(sourcePermissions).where(eq(sourcePermissions.id, id));
}

// ─── Schema Cache ──────────────────────────────────────────────────────────────
export async function getTablesForSchema(sourceId: number, schemaName: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(schemaCacheTables).where(
    and(eq(schemaCacheTables.sourceId, sourceId), eq(schemaCacheTables.schemaName, schemaName))
  ).orderBy(schemaCacheTables.tableName);
}

export async function getColumnsForTable(sourceId: number, schemaName: string, tableName: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(schemaCacheColumns).where(
    and(
      eq(schemaCacheColumns.sourceId, sourceId),
      eq(schemaCacheColumns.schemaName, schemaName),
      eq(schemaCacheColumns.tableName, tableName)
    )
  ).orderBy(schemaCacheColumns.ordinalPosition);
}

export async function upsertCacheTable(data: {
  sourceId: number; schemaName: string; tableName: string; approxRowCount?: number;
  tableComment?: string; partitionKey?: string; businessDomain?: string;
  indexesJson?: any[]; foreignKeysJson?: any[];
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const existing = await db.select().from(schemaCacheTables).where(
    and(
      eq(schemaCacheTables.sourceId, data.sourceId),
      eq(schemaCacheTables.schemaName, data.schemaName),
      eq(schemaCacheTables.tableName, data.tableName)
    )
  ).limit(1);
  if (existing.length > 0) {
    await db.update(schemaCacheTables)
      .set({
        approxRowCount: data.approxRowCount ?? 0,
        tableComment: data.tableComment ?? null,
        partitionKey: data.partitionKey ?? null,
        businessDomain: data.businessDomain ?? null,
        indexesJson: data.indexesJson ?? null,
        foreignKeysJson: data.foreignKeysJson ?? null,
        lastRefreshedAt: new Date(),
      })
      .where(eq(schemaCacheTables.id, existing[0].id));
  } else {
    await db.insert(schemaCacheTables).values({
      sourceId: data.sourceId, schemaName: data.schemaName, tableName: data.tableName,
      approxRowCount: data.approxRowCount ?? 0,
      tableComment: data.tableComment ?? null,
      partitionKey: data.partitionKey ?? null,
      businessDomain: data.businessDomain ?? null,
      indexesJson: data.indexesJson ?? null,
      foreignKeysJson: data.foreignKeysJson ?? null,
      lastRefreshedAt: new Date(),
    });
  }
}

export async function upsertCacheColumn(data: {
  sourceId: number; schemaName: string; tableName: string; columnName: string;
  dataType: string; isNullable?: boolean; isIndexed?: boolean; isKey?: boolean;
  ordinalPosition?: number; defaultValue?: string; columnComment?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const existing = await db.select().from(schemaCacheColumns).where(
    and(
      eq(schemaCacheColumns.sourceId, data.sourceId),
      eq(schemaCacheColumns.schemaName, data.schemaName),
      eq(schemaCacheColumns.tableName, data.tableName),
      eq(schemaCacheColumns.columnName, data.columnName)
    )
  ).limit(1);
  const payload = {
    dataType: data.dataType, isNullable: data.isNullable ?? true,
    isIndexed: data.isIndexed ?? false, isKey: data.isKey ?? false,
    ordinalPosition: data.ordinalPosition ?? 0,
    defaultValue: data.defaultValue ?? null,
    columnComment: data.columnComment ?? null,
    lastRefreshedAt: new Date(),
  };
  if (existing.length > 0) {
    await db.update(schemaCacheColumns).set(payload).where(eq(schemaCacheColumns.id, existing[0].id));
  } else {
    await db.insert(schemaCacheColumns).values({ ...data, ...payload });
  }
}

export async function clearSchemaCache(sourceId: number, schemaName: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(schemaCacheTables).where(
    and(eq(schemaCacheTables.sourceId, sourceId), eq(schemaCacheTables.schemaName, schemaName))
  );
  await db.delete(schemaCacheColumns).where(
    and(eq(schemaCacheColumns.sourceId, sourceId), eq(schemaCacheColumns.schemaName, schemaName))
  );
}

// ─── Dictionary Entries ────────────────────────────────────────────────────────
export async function getDictionaryEntries(sourceId: number, schemaName: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(dictionaryEntries).where(
    and(eq(dictionaryEntries.sourceId, sourceId), eq(dictionaryEntries.schemaName, schemaName))
  );
}

export async function upsertDictionaryEntry(data: InsertDictionaryEntry) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const existing = await db.select().from(dictionaryEntries).where(
    and(
      eq(dictionaryEntries.sourceId, data.sourceId),
      eq(dictionaryEntries.schemaName, data.schemaName),
      eq(dictionaryEntries.tableName, data.tableName),
      data.columnName ? eq(dictionaryEntries.columnName, data.columnName) : isNull(dictionaryEntries.columnName),
    )
  ).limit(1);
  if (existing.length > 0) {
    await db.update(dictionaryEntries).set({ description: data.description }).where(eq(dictionaryEntries.id, existing[0].id));
  } else {
    await db.insert(dictionaryEntries).values(data);
  }
}

export async function deleteDictionaryEntriesForSource(sourceId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(dictionaryEntries).where(eq(dictionaryEntries.sourceId, sourceId));
}

// ─── Dataset Drafts ────────────────────────────────────────────────────────────
export async function createDatasetDraft(data: InsertDatasetDraft) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(datasetDrafts).values(data);
  return result;
}

export async function getDatasetDraftById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(datasetDrafts).where(eq(datasetDrafts.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getDraftsByOwner(ownerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(datasetDrafts).where(eq(datasetDrafts.ownerId, ownerId)).orderBy(desc(datasetDrafts.updatedAt));
}

export async function updateDatasetDraft(id: number, data: {
  name?: string; description?: string; status?: string; definitionJson?: DatasetDefinition;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(datasetDrafts).set(data as any).where(eq(datasetDrafts.id, id));
}

export async function deleteDatasetDraft(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(datasetDrafts).where(eq(datasetDrafts.id, id));
}

// ─── Execution Jobs ────────────────────────────────────────────────────────────
export async function createExecutionJob(data: InsertExecutionJob) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(executionJobs).values(data);
  return result;
}

export async function getExecutionJobById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(executionJobs).where(eq(executionJobs.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateExecutionJob(id: number, data: Partial<InsertExecutionJob>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(executionJobs).set(data as any).where(eq(executionJobs.id, id));
}

export async function countRunningJobsForUser(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(executionJobs).where(
    and(eq(executionJobs.userId, userId), eq(executionJobs.status, "running"))
  );
  return result[0]?.count ?? 0;
}

export async function countRunningJobsForSource(sourceId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  // Join with drafts to get sourceId
  const result = await db.select({ count: sql<number>`count(*)` }).from(executionJobs).where(
    eq(executionJobs.status, "running")
  );
  return result[0]?.count ?? 0;
}

// ─── Audit Log ─────────────────────────────────────────────────────────────────
export async function insertAuditLog(data: InsertQueryAuditLog) {
  const db = await getDb();
  if (!db) return;
  await db.insert(queryAuditLog).values(data);
}

export async function getAuditLogs(filters?: { userId?: number; sourceId?: number; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(queryAuditLog);
  const conditions = [];
  if (filters?.userId) conditions.push(eq(queryAuditLog.userId, filters.userId));
  if (filters?.sourceId) conditions.push(eq(queryAuditLog.sourceId, filters.sourceId));
  if (conditions.length > 0) {
    return db.select().from(queryAuditLog).where(and(...conditions)).orderBy(desc(queryAuditLog.executedAt)).limit(filters?.limit ?? 200);
  }
  return db.select().from(queryAuditLog).orderBy(desc(queryAuditLog.executedAt)).limit(filters?.limit ?? 200);
}
