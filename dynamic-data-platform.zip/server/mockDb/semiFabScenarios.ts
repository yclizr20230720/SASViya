/**
 * Semiconductor Fab Mock DB Scenarios
 * 10 professional tables covering the full semiconductor manufacturing data domain:
 *
 * 1.  lot_history          - Lot lifecycle tracking (start → complete → ship)
 * 2.  wafer_history        - Wafer-level process step events
 * 3.  equipment_tool       - Equipment master + real-time status
 * 4.  wat_data             - Wafer Acceptance Test (electrical parametric)
 * 5.  cp_data              - Circuit Probe (die-level yield map)
 * 6.  fdc_data             - Fault Detection & Classification sensor data
 * 7.  inline_thickness     - Inline film thickness measurement (ellipsometry/reflectometry)
 * 8.  cd_measurement       - Critical Dimension measurement (SEM/OCD)
 * 9.  defect_inspection    - Inline defect inspection (KLA/Hitachi)
 * 10. equipment_pm         - Equipment Preventive Maintenance records
 *
 * All tables use F12PEDA.VEDA schema and are cross-linked via LOT_ID / WAFER_ID / EQUIPMENT_ID.
 */

import type { MockTable, MockSchema } from "./scenarios";

export const SEMI_FAB_TABLES: MockTable[] = [

  // ── 1. LOT_HISTORY ────────────────────────────────────────────────────────────
  {
    tableName: "LOT_HISTORY",
    approxRowCount: 1000,
    comment: "Complete lot lifecycle history from start to shipment",
    businessDomain: "lot_tracking",
    columns: [
      { columnName: "LOT_ID",          dataType: "VARCHAR2(32)",   isKey: true,  isIndexed: true,  isNullable: false, ordinalPosition: 1,  comment: "Unique lot identifier (e.g. N24A001234)" },
      { columnName: "PRODUCT_ID",      dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 2,  comment: "Product code (e.g. PROD-5NM-A)" },
      { columnName: "CUSTOMER_ID",     dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 3,  comment: "Customer identifier" },
      { columnName: "TECHNOLOGY_NODE", dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 4,  comment: "Process node (5NM/7NM/12NM/28NM)" },
      { columnName: "WAFER_QTY",       dataType: "NUMBER(4)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 5,  comment: "Number of wafers in lot (1-25)" },
      { columnName: "PRIORITY",        dataType: "VARCHAR2(8)",    isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 6,  comment: "HOT/URGENT/NORMAL/LOW" },
      { columnName: "LOT_TYPE",        dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 7,  comment: "PRODUCTION/ENGINEERING/QUALIFICATION/MONITOR" },
      { columnName: "START_DATE",      dataType: "DATE",           isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 8,  comment: "Lot start date" },
      { columnName: "COMPLETE_DATE",   dataType: "DATE",           isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 9,  comment: "Fab-out completion date" },
      { columnName: "SHIP_DATE",       dataType: "DATE",           isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 10, comment: "Customer shipment date" },
      { columnName: "CYCLE_TIME_DAYS", dataType: "NUMBER(8,2)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 11, comment: "Total cycle time in days" },
      { columnName: "STATUS",          dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 12, comment: "ACTIVE/HOLD/COMPLETED/SCRAPPED/SHIPPED" },
      { columnName: "HOLD_COUNT",      dataType: "NUMBER(4)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 13, comment: "Number of hold events", defaultValue: "0" },
      { columnName: "HOLD_REASON",     dataType: "VARCHAR2(256)",  isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 14, comment: "Latest hold reason code" },
      { columnName: "SCRAP_QTY",       dataType: "NUMBER(4)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 15, comment: "Number of scrapped wafers", defaultValue: "0" },
      { columnName: "FINAL_YIELD",     dataType: "NUMBER(8,4)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 16, comment: "Final lot yield percentage (0-100)" },
      { columnName: "CREATED_AT",      dataType: "DATE",           isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 17, defaultValue: "SYSDATE" },
      { columnName: "UPDATED_AT",      dataType: "DATE",           isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 18, defaultValue: "SYSDATE" },
    ],
    indexes: [
      { indexName: "PK_LOT_HISTORY",       columns: ["LOT_ID"],                       isUnique: true,  indexType: "BTREE" },
      { indexName: "IDX_LH_PRODUCT_NODE",  columns: ["PRODUCT_ID","TECHNOLOGY_NODE"], isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_LH_STATUS_DATE",   columns: ["STATUS","START_DATE"],          isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_LH_CUSTOMER",      columns: ["CUSTOMER_ID"],                  isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_LH_PRIORITY",      columns: ["PRIORITY","STATUS"],            isUnique: false, indexType: "BITMAP" },
    ],
    foreignKeys: [],
  },

  // ── 2. WAFER_HISTORY ──────────────────────────────────────────────────────────
  {
    tableName: "WAFER_HISTORY",
    approxRowCount: 1000,
    comment: "Wafer-level process step history with equipment and recipe tracking",
    businessDomain: "wafer_tracking",
    columns: [
      { columnName: "WAFER_HIST_ID",   dataType: "NUMBER(18)",     isKey: true,  isIndexed: true,  isNullable: false, ordinalPosition: 1,  comment: "Surrogate primary key" },
      { columnName: "WAFER_ID",        dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 2,  comment: "Wafer identifier (LOT_ID + slot, e.g. N24A001234-01)" },
      { columnName: "LOT_ID",          dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 3,  comment: "Parent lot identifier" },
      { columnName: "SLOT_NO",         dataType: "NUMBER(2)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 4,  comment: "Wafer slot number (1-25)" },
      { columnName: "PROCESS_STEP",    dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 5,  comment: "Process step code (e.g. PHOTO_01, ETCH_02, CVD_03)" },
      { columnName: "OPERATION_SEQ",   dataType: "NUMBER(6)",      isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 6,  comment: "Operation sequence number in route" },
      { columnName: "EQUIPMENT_ID",    dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 7,  comment: "Equipment used for this step" },
      { columnName: "RECIPE_ID",       dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 8,  comment: "Process recipe identifier" },
      { columnName: "MOVE_IN_TIME",    dataType: "DATE",           isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 9,  comment: "Step start (move-in) timestamp" },
      { columnName: "MOVE_OUT_TIME",   dataType: "DATE",           isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 10, comment: "Step end (move-out) timestamp" },
      { columnName: "PROCESS_TIME_MIN",dataType: "NUMBER(10,2)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 11, comment: "Actual process time in minutes" },
      { columnName: "QUEUE_TIME_HRS",  dataType: "NUMBER(10,2)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 12, comment: "Queue waiting time in hours" },
      { columnName: "STEP_STATUS",     dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 13, comment: "COMPLETED/ABORTED/REWORKED/SCRAPPED" },
      { columnName: "OPERATOR_ID",     dataType: "VARCHAR2(32)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 14, comment: "Operator who processed the step" },
      { columnName: "REWORK_FLAG",     dataType: "VARCHAR2(1)",    isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 15, comment: "Y/N rework indicator", defaultValue: "'N'" },
      { columnName: "REWORK_REASON",   dataType: "VARCHAR2(256)",  isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 16, comment: "Rework reason if applicable" },
    ],
    indexes: [
      { indexName: "PK_WAFER_HISTORY",      columns: ["WAFER_HIST_ID"],              isUnique: true,  indexType: "BTREE" },
      { indexName: "IDX_WH_WAFER_ID",       columns: ["WAFER_ID"],                   isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_WH_LOT_STEP",       columns: ["LOT_ID","PROCESS_STEP"],      isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_WH_EQP_TIME",       columns: ["EQUIPMENT_ID","MOVE_IN_TIME"],isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_WH_STEP_SEQ",       columns: ["PROCESS_STEP","OPERATION_SEQ"],isUnique: false,indexType: "BTREE" },
    ],
    foreignKeys: [
      { constraintName: "FK_WH_LOT", columns: ["LOT_ID"], referencedSchema: "VEDA", referencedTable: "LOT_HISTORY", referencedColumns: ["LOT_ID"] },
    ],
  },

  // ── 3. EQUIPMENT_TOOL ─────────────────────────────────────────────────────────
  {
    tableName: "EQUIPMENT_TOOL",
    approxRowCount: 80,
    comment: "Equipment master data with real-time status and performance metrics",
    businessDomain: "equipment",
    columns: [
      { columnName: "EQUIPMENT_ID",    dataType: "VARCHAR2(32)",   isKey: true,  isIndexed: true,  isNullable: false, ordinalPosition: 1,  comment: "Unique equipment identifier (e.g. STEP-01, ETCH-03)" },
      { columnName: "EQUIPMENT_NAME",  dataType: "VARCHAR2(128)",  isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 2,  comment: "Full equipment name" },
      { columnName: "EQUIPMENT_TYPE",  dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 3,  comment: "STEPPER/DUV/EUV/ETCHER/CVD/PVD/CMP/INSPECT/MEASURE" },
      { columnName: "VENDOR",          dataType: "VARCHAR2(64)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 4,  comment: "Equipment vendor (ASML/LAM/AMAT/KLA/TEL)" },
      { columnName: "MODEL",           dataType: "VARCHAR2(64)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 5,  comment: "Equipment model number" },
      { columnName: "SERIAL_NO",       dataType: "VARCHAR2(64)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 6,  comment: "Equipment serial number" },
      { columnName: "FAB_AREA",        dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 7,  comment: "Fab area: PHOTO/ETCH/DIFF/METAL/CMP/INSPECT" },
      { columnName: "BAY_NO",          dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 8,  comment: "Bay location identifier" },
      { columnName: "CURRENT_STATUS",  dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 9,  comment: "UP/DOWN/PM/IDLE/ENGINEERING" },
      { columnName: "INSTALL_DATE",    dataType: "DATE",           isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 10, comment: "Equipment installation date" },
      { columnName: "LAST_PM_DATE",    dataType: "DATE",           isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 11, comment: "Last preventive maintenance date" },
      { columnName: "NEXT_PM_DATE",    dataType: "DATE",           isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 12, comment: "Next scheduled PM date" },
      { columnName: "CAPACITY_WPH",    dataType: "NUMBER(8,2)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 13, comment: "Rated capacity in wafers per hour" },
      { columnName: "OEE_RATE",        dataType: "NUMBER(6,4)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 14, comment: "Overall Equipment Effectiveness (0-1)" },
      { columnName: "MTBF_HOURS",      dataType: "NUMBER(10,2)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 15, comment: "Mean Time Between Failures in hours" },
      { columnName: "MTTR_HOURS",      dataType: "NUMBER(8,2)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 16, comment: "Mean Time To Repair in hours" },
      { columnName: "TOTAL_WAFERS_RUN",dataType: "NUMBER(12)",     isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 17, comment: "Lifetime wafer count", defaultValue: "0" },
      { columnName: "UPDATED_AT",      dataType: "DATE",           isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 18, defaultValue: "SYSDATE" },
    ],
    indexes: [
      { indexName: "PK_EQUIPMENT_TOOL",     columns: ["EQUIPMENT_ID"],               isUnique: true,  indexType: "BTREE" },
      { indexName: "IDX_ET_TYPE_AREA",      columns: ["EQUIPMENT_TYPE","FAB_AREA"],  isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_ET_STATUS",         columns: ["CURRENT_STATUS"],             isUnique: false, indexType: "BITMAP" },
    ],
    foreignKeys: [],
  },

  // ── 4. WAT_DATA (Wafer Acceptance Test) ───────────────────────────────────────
  {
    tableName: "WAT_DATA",
    approxRowCount: 1000,
    comment: "Wafer Acceptance Test - electrical parametric measurements at test structures",
    businessDomain: "yield",
    columns: [
      { columnName: "WAT_ID",          dataType: "NUMBER(18)",     isKey: true,  isIndexed: true,  isNullable: false, ordinalPosition: 1,  comment: "Surrogate primary key" },
      { columnName: "LOT_ID",          dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 2,  comment: "Lot identifier" },
      { columnName: "WAFER_ID",        dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 3,  comment: "Wafer identifier" },
      { columnName: "WAFER_NO",        dataType: "NUMBER(2)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 4,  comment: "Wafer slot number" },
      { columnName: "PRODUCT_ID",      dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 5,  comment: "Product code" },
      { columnName: "TECHNOLOGY_NODE", dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 6,  comment: "Process node" },
      { columnName: "TEST_SITE",       dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 7,  comment: "Test site location (CENTER/EDGE/TOP/BOTTOM/LEFT/RIGHT)" },
      { columnName: "MEASURED_AT",     dataType: "DATE",           isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 8,  comment: "Measurement timestamp" },
      { columnName: "NMOS_VTH_MV",     dataType: "NUMBER(10,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 9,  comment: "NMOS threshold voltage (mV)" },
      { columnName: "PMOS_VTH_MV",     dataType: "NUMBER(10,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 10, comment: "PMOS threshold voltage (mV)" },
      { columnName: "NMOS_IDSAT_UA",   dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 11, comment: "NMOS saturation current (uA/um)" },
      { columnName: "PMOS_IDSAT_UA",   dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 12, comment: "PMOS saturation current (uA/um)" },
      { columnName: "NMOS_IOFF_PA",    dataType: "NUMBER(12,6)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 13, comment: "NMOS off-state leakage (pA/um)" },
      { columnName: "POLY_CD_NM",      dataType: "NUMBER(10,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 14, comment: "Poly gate CD (nm)" },
      { columnName: "CONTACT_R_OHM",   dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 15, comment: "Contact resistance (ohm)" },
      { columnName: "METAL1_R_OHM_SQ", dataType: "NUMBER(10,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 16, comment: "Metal-1 sheet resistance (ohm/sq)" },
      { columnName: "PASS_FAIL",       dataType: "VARCHAR2(4)",    isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 17, comment: "PASS/FAIL/SKIP" },
      { columnName: "FAIL_ITEMS",      dataType: "VARCHAR2(512)",  isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 18, comment: "Comma-separated list of failed parameter names" },
    ],
    indexes: [
      { indexName: "PK_WAT_DATA",          columns: ["WAT_ID"],                      isUnique: true,  indexType: "BTREE" },
      { indexName: "IDX_WAT_LOT_WAFER",    columns: ["LOT_ID","WAFER_ID"],           isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_WAT_PRODUCT_DATE", columns: ["PRODUCT_ID","MEASURED_AT"],    isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_WAT_PASS_FAIL",    columns: ["PASS_FAIL"],                   isUnique: false, indexType: "BITMAP" },
    ],
    foreignKeys: [
      { constraintName: "FK_WAT_LOT", columns: ["LOT_ID"], referencedSchema: "VEDA", referencedTable: "LOT_HISTORY", referencedColumns: ["LOT_ID"] },
    ],
  },

  // ── 5. CP_DATA (Circuit Probe) ────────────────────────────────────────────────
  {
    tableName: "CP_DATA",
    approxRowCount: 1000,
    comment: "Circuit Probe test results - die-level electrical test on wafer",
    businessDomain: "yield",
    columns: [
      { columnName: "CP_ID",           dataType: "NUMBER(18)",     isKey: true,  isIndexed: true,  isNullable: false, ordinalPosition: 1,  comment: "Surrogate primary key" },
      { columnName: "LOT_ID",          dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 2,  comment: "Lot identifier" },
      { columnName: "WAFER_ID",        dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 3,  comment: "Wafer identifier" },
      { columnName: "WAFER_NO",        dataType: "NUMBER(2)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 4,  comment: "Wafer slot number" },
      { columnName: "PRODUCT_ID",      dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 5,  comment: "Product code" },
      { columnName: "TEST_PROGRAM",    dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 6,  comment: "CP test program name/version" },
      { columnName: "PROBER_ID",       dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 7,  comment: "Prober equipment ID" },
      { columnName: "TEST_DATE",       dataType: "DATE",           isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 8,  comment: "CP test date" },
      { columnName: "TOTAL_DIE",       dataType: "NUMBER(8)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 9,  comment: "Total die count on wafer" },
      { columnName: "GOOD_DIE",        dataType: "NUMBER(8)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 10, comment: "Number of passing die" },
      { columnName: "FAIL_DIE",        dataType: "NUMBER(8)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 11, comment: "Number of failing die" },
      { columnName: "YIELD_PCT",       dataType: "NUMBER(8,4)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 12, comment: "Die yield percentage (0-100)" },
      { columnName: "BIN1_CNT",        dataType: "NUMBER(8)",      isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 13, comment: "Bin 1 (pass) count" },
      { columnName: "BIN2_CNT",        dataType: "NUMBER(8)",      isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 14, comment: "Bin 2 (functional fail) count" },
      { columnName: "BIN3_CNT",        dataType: "NUMBER(8)",      isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 15, comment: "Bin 3 (parametric fail) count" },
      { columnName: "BIN4_CNT",        dataType: "NUMBER(8)",      isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 16, comment: "Bin 4 (leakage fail) count" },
      { columnName: "EDGE_DIE_CNT",    dataType: "NUMBER(8)",      isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 17, comment: "Edge die count (excluded from yield)" },
      { columnName: "DEFECT_DENSITY",  dataType: "NUMBER(12,6)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 18, comment: "Calculated defect density (defects/cm²)" },
    ],
    indexes: [
      { indexName: "PK_CP_DATA",           columns: ["CP_ID"],                       isUnique: true,  indexType: "BTREE" },
      { indexName: "IDX_CP_LOT_WAFER",     columns: ["LOT_ID","WAFER_ID"],           isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_CP_PRODUCT_DATE",  columns: ["PRODUCT_ID","TEST_DATE"],      isUnique: false, indexType: "BTREE" },
    ],
    foreignKeys: [
      { constraintName: "FK_CP_LOT", columns: ["LOT_ID"], referencedSchema: "VEDA", referencedTable: "LOT_HISTORY", referencedColumns: ["LOT_ID"] },
    ],
  },

  // ── 6. FDC_DATA (Fault Detection & Classification) ────────────────────────────
  {
    tableName: "FDC_DATA",
    approxRowCount: 1000,
    comment: "Equipment sensor FDC data - real-time process parameter monitoring",
    businessDomain: "fault_detection",
    columns: [
      { columnName: "FDC_ID",          dataType: "NUMBER(18)",     isKey: true,  isIndexed: true,  isNullable: false, ordinalPosition: 1,  comment: "Surrogate primary key" },
      { columnName: "WAFER_ID",        dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 2,  comment: "Wafer identifier" },
      { columnName: "LOT_ID",          dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 3,  comment: "Lot identifier" },
      { columnName: "EQUIPMENT_ID",    dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 4,  comment: "Equipment identifier" },
      { columnName: "PROCESS_STEP",    dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 5,  comment: "Process step code" },
      { columnName: "RECIPE_ID",       dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 6,  comment: "Process recipe" },
      { columnName: "PARAMETER_NAME",  dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 7,  comment: "Sensor/parameter name (e.g. PRESSURE, RF_POWER, TEMP)" },
      { columnName: "MEASURED_VALUE",  dataType: "NUMBER(18,6)",   isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 8,  comment: "Measured sensor value" },
      { columnName: "UNIT",            dataType: "VARCHAR2(16)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 9,  comment: "Measurement unit (mTorr/W/degC/sccm)" },
      { columnName: "UCL",             dataType: "NUMBER(18,6)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 10, comment: "Upper control limit" },
      { columnName: "LCL",             dataType: "NUMBER(18,6)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 11, comment: "Lower control limit" },
      { columnName: "TARGET",          dataType: "NUMBER(18,6)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 12, comment: "Target/setpoint value" },
      { columnName: "DEVIATION_PCT",   dataType: "NUMBER(10,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 13, comment: "Deviation from target (%)" },
      { columnName: "ALARM_FLAG",      dataType: "VARCHAR2(1)",    isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 14, comment: "Y/N alarm triggered", defaultValue: "'N'" },
      { columnName: "ALARM_CLASS",     dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 15, comment: "CRITICAL/MAJOR/MINOR/WARNING" },
      { columnName: "MEASURED_AT",     dataType: "DATE",           isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 16, comment: "Measurement timestamp" },
      { columnName: "CHART_TYPE",      dataType: "VARCHAR2(8)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 17, comment: "SPC chart type: XBAR/R/S/EWMA" },
    ],
    indexes: [
      { indexName: "PK_FDC_DATA",          columns: ["FDC_ID"],                          isUnique: true,  indexType: "BTREE" },
      { indexName: "IDX_FDC_WAFER_PARAM",  columns: ["WAFER_ID","PARAMETER_NAME"],       isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_FDC_EQP_STEP",     columns: ["EQUIPMENT_ID","PROCESS_STEP"],     isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_FDC_ALARM",        columns: ["ALARM_FLAG","ALARM_CLASS"],        isUnique: false, indexType: "BITMAP" },
      { indexName: "IDX_FDC_TIME",         columns: ["MEASURED_AT"],                     isUnique: false, indexType: "BTREE" },
    ],
    foreignKeys: [
      { constraintName: "FK_FDC_LOT", columns: ["LOT_ID"], referencedSchema: "VEDA", referencedTable: "LOT_HISTORY", referencedColumns: ["LOT_ID"] },
      { constraintName: "FK_FDC_EQP", columns: ["EQUIPMENT_ID"], referencedSchema: "VEDA", referencedTable: "EQUIPMENT_TOOL", referencedColumns: ["EQUIPMENT_ID"] },
    ],
  },

  // ── 7. INLINE_THICKNESS ───────────────────────────────────────────────────────
  {
    tableName: "INLINE_THICKNESS",
    approxRowCount: 1000,
    comment: "Inline film thickness measurement by ellipsometry or reflectometry",
    businessDomain: "metrology",
    columns: [
      { columnName: "MEAS_ID",         dataType: "NUMBER(18)",     isKey: true,  isIndexed: true,  isNullable: false, ordinalPosition: 1,  comment: "Surrogate primary key" },
      { columnName: "LOT_ID",          dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 2,  comment: "Lot identifier" },
      { columnName: "WAFER_ID",        dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 3,  comment: "Wafer identifier" },
      { columnName: "WAFER_NO",        dataType: "NUMBER(2)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 4,  comment: "Wafer slot number" },
      { columnName: "PROCESS_STEP",    dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 5,  comment: "After-step measurement point" },
      { columnName: "FILM_LAYER",      dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 6,  comment: "Film layer name (OXIDE/NITRIDE/POLY/METAL1/ILD)" },
      { columnName: "EQUIPMENT_ID",    dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 7,  comment: "Measurement tool ID" },
      { columnName: "MEAS_METHOD",     dataType: "VARCHAR2(16)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 8,  comment: "ELLIPSOMETRY/REFLECTOMETRY/XRF" },
      { columnName: "SITE_COUNT",      dataType: "NUMBER(4)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 9,  comment: "Number of measurement sites" },
      { columnName: "THICKNESS_AVG_A", dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 10, comment: "Average thickness in Angstroms" },
      { columnName: "THICKNESS_MAX_A", dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 11, comment: "Maximum thickness (Angstroms)" },
      { columnName: "THICKNESS_MIN_A", dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 12, comment: "Minimum thickness (Angstroms)" },
      { columnName: "THICKNESS_RANGE", dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 13, comment: "Range = Max - Min (Angstroms)" },
      { columnName: "UNIFORMITY_PCT",  dataType: "NUMBER(8,4)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 14, comment: "Thickness uniformity % (1-sigma/mean*100)" },
      { columnName: "TARGET_A",        dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 15, comment: "Target thickness (Angstroms)" },
      { columnName: "USL_A",           dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 16, comment: "Upper spec limit (Angstroms)" },
      { columnName: "LSL_A",           dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 17, comment: "Lower spec limit (Angstroms)" },
      { columnName: "PASS_FAIL",       dataType: "VARCHAR2(4)",    isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 18, comment: "PASS/FAIL/SKIP" },
      { columnName: "MEASURED_AT",     dataType: "DATE",           isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 19, comment: "Measurement timestamp" },
    ],
    indexes: [
      { indexName: "PK_INLINE_THICKNESS",  columns: ["MEAS_ID"],                     isUnique: true,  indexType: "BTREE" },
      { indexName: "IDX_IT_LOT_STEP",      columns: ["LOT_ID","PROCESS_STEP"],       isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_IT_FILM_DATE",     columns: ["FILM_LAYER","MEASURED_AT"],    isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_IT_PASS_FAIL",     columns: ["PASS_FAIL"],                   isUnique: false, indexType: "BITMAP" },
    ],
    foreignKeys: [
      { constraintName: "FK_IT_LOT", columns: ["LOT_ID"], referencedSchema: "VEDA", referencedTable: "LOT_HISTORY", referencedColumns: ["LOT_ID"] },
    ],
  },

  // ── 8. CD_MEASUREMENT ─────────────────────────────────────────────────────────
  {
    tableName: "CD_MEASUREMENT",
    approxRowCount: 1000,
    comment: "Critical Dimension measurement by SEM or OCD scatterometry",
    businessDomain: "metrology",
    columns: [
      { columnName: "CD_ID",           dataType: "NUMBER(18)",     isKey: true,  isIndexed: true,  isNullable: false, ordinalPosition: 1,  comment: "Surrogate primary key" },
      { columnName: "LOT_ID",          dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 2,  comment: "Lot identifier" },
      { columnName: "WAFER_ID",        dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 3,  comment: "Wafer identifier" },
      { columnName: "WAFER_NO",        dataType: "NUMBER(2)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 4,  comment: "Wafer slot number" },
      { columnName: "PROCESS_STEP",    dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 5,  comment: "Measurement after this process step" },
      { columnName: "CD_LAYER",        dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 6,  comment: "Layer being measured (GATE/CONTACT/METAL1/VIA)" },
      { columnName: "EQUIPMENT_ID",    dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 7,  comment: "CD-SEM or OCD tool ID" },
      { columnName: "MEAS_METHOD",     dataType: "VARCHAR2(16)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 8,  comment: "CD-SEM/OCD/AFM" },
      { columnName: "SITE_COUNT",      dataType: "NUMBER(4)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 9,  comment: "Number of measurement sites" },
      { columnName: "CD_MEAN_NM",      dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 10, comment: "Mean CD value (nm)" },
      { columnName: "CD_3SIGMA_NM",    dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 11, comment: "3-sigma CD variation (nm)" },
      { columnName: "CD_MAX_NM",       dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 12, comment: "Maximum CD (nm)" },
      { columnName: "CD_MIN_NM",       dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 13, comment: "Minimum CD (nm)" },
      { columnName: "CD_RANGE_NM",     dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 14, comment: "CD range (nm)" },
      { columnName: "LWR_NM",          dataType: "NUMBER(10,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 15, comment: "Line Width Roughness (nm)" },
      { columnName: "LER_NM",          dataType: "NUMBER(10,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 16, comment: "Line Edge Roughness (nm)" },
      { columnName: "TARGET_NM",       dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 17, comment: "Target CD (nm)" },
      { columnName: "USL_NM",          dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 18, comment: "Upper spec limit (nm)" },
      { columnName: "LSL_NM",          dataType: "NUMBER(12,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 19, comment: "Lower spec limit (nm)" },
      { columnName: "PASS_FAIL",       dataType: "VARCHAR2(4)",    isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 20, comment: "PASS/FAIL/SKIP" },
      { columnName: "MEASURED_AT",     dataType: "DATE",           isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 21, comment: "Measurement timestamp" },
    ],
    indexes: [
      { indexName: "PK_CD_MEASUREMENT",    columns: ["CD_ID"],                       isUnique: true,  indexType: "BTREE" },
      { indexName: "IDX_CD_LOT_STEP",      columns: ["LOT_ID","PROCESS_STEP"],       isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_CD_LAYER_DATE",    columns: ["CD_LAYER","MEASURED_AT"],      isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_CD_PASS_FAIL",     columns: ["PASS_FAIL"],                   isUnique: false, indexType: "BITMAP" },
    ],
    foreignKeys: [
      { constraintName: "FK_CD_LOT", columns: ["LOT_ID"], referencedSchema: "VEDA", referencedTable: "LOT_HISTORY", referencedColumns: ["LOT_ID"] },
    ],
  },

  // ── 9. DEFECT_INSPECTION ──────────────────────────────────────────────────────
  {
    tableName: "DEFECT_INSPECTION",
    approxRowCount: 1000,
    comment: "Inline defect inspection results from KLA/Hitachi/Camtek tools",
    businessDomain: "defect",
    columns: [
      { columnName: "INSP_ID",         dataType: "NUMBER(18)",     isKey: true,  isIndexed: true,  isNullable: false, ordinalPosition: 1,  comment: "Surrogate primary key" },
      { columnName: "LOT_ID",          dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 2,  comment: "Lot identifier" },
      { columnName: "WAFER_ID",        dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 3,  comment: "Wafer identifier" },
      { columnName: "WAFER_NO",        dataType: "NUMBER(2)",      isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 4,  comment: "Wafer slot number" },
      { columnName: "PROCESS_STEP",    dataType: "VARCHAR2(64)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 5,  comment: "Inspection after this process step" },
      { columnName: "EQUIPMENT_ID",    dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 6,  comment: "Inspection tool ID" },
      { columnName: "INSP_RECIPE",     dataType: "VARCHAR2(64)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 7,  comment: "Inspection recipe name" },
      { columnName: "INSP_DATE",       dataType: "DATE",           isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 8,  comment: "Inspection date" },
      { columnName: "TOTAL_DEFECTS",   dataType: "NUMBER(10)",     isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 9,  comment: "Total defect count" },
      { columnName: "DEFECT_DENSITY",  dataType: "NUMBER(12,6)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 10, comment: "Defect density (defects/cm²)" },
      { columnName: "NUISANCE_CNT",    dataType: "NUMBER(10)",     isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 11, comment: "Nuisance/false alarm count" },
      { columnName: "REAL_DEFECT_CNT", dataType: "NUMBER(10)",     isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 12, comment: "Real defect count after classification" },
      { columnName: "PARTICLE_CNT",    dataType: "NUMBER(10)",     isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 13, comment: "Particle defect count" },
      { columnName: "SCRATCH_CNT",     dataType: "NUMBER(10)",     isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 14, comment: "Scratch defect count" },
      { columnName: "PATTERN_CNT",     dataType: "NUMBER(10)",     isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 15, comment: "Pattern defect count" },
      { columnName: "HAZE_VALUE",      dataType: "NUMBER(10,4)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 16, comment: "Wafer surface haze value (ppm)" },
      { columnName: "PASS_FAIL",       dataType: "VARCHAR2(4)",    isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 17, comment: "PASS/FAIL/SKIP" },
      { columnName: "REVIEW_FLAG",     dataType: "VARCHAR2(1)",    isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 18, comment: "Y/N sent for SEM review", defaultValue: "'N'" },
    ],
    indexes: [
      { indexName: "PK_DEFECT_INSPECTION", columns: ["INSP_ID"],                     isUnique: true,  indexType: "BTREE" },
      { indexName: "IDX_DI_LOT_STEP",      columns: ["LOT_ID","PROCESS_STEP"],       isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_DI_EQP_DATE",      columns: ["EQUIPMENT_ID","INSP_DATE"],    isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_DI_PASS_FAIL",     columns: ["PASS_FAIL"],                   isUnique: false, indexType: "BITMAP" },
    ],
    foreignKeys: [
      { constraintName: "FK_DI_LOT", columns: ["LOT_ID"], referencedSchema: "VEDA", referencedTable: "LOT_HISTORY", referencedColumns: ["LOT_ID"] },
    ],
  },

  // ── 10. EQUIPMENT_PM ──────────────────────────────────────────────────────────
  {
    tableName: "EQUIPMENT_PM",
    approxRowCount: 300,
    comment: "Equipment Preventive Maintenance records and performance tracking",
    businessDomain: "equipment",
    columns: [
      { columnName: "PM_ID",           dataType: "NUMBER(18)",     isKey: true,  isIndexed: true,  isNullable: false, ordinalPosition: 1,  comment: "Surrogate primary key" },
      { columnName: "EQUIPMENT_ID",    dataType: "VARCHAR2(32)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 2,  comment: "Equipment identifier" },
      { columnName: "PM_TYPE",         dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 3,  comment: "SCHEDULED/UNSCHEDULED/EMERGENCY/QUALIFICATION" },
      { columnName: "PM_LEVEL",        dataType: "VARCHAR2(8)",    isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 4,  comment: "PM level: MINOR/MAJOR/FULL" },
      { columnName: "START_TIME",      dataType: "DATE",           isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 5,  comment: "PM start timestamp" },
      { columnName: "END_TIME",        dataType: "DATE",           isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 6,  comment: "PM completion timestamp" },
      { columnName: "DURATION_HRS",    dataType: "NUMBER(8,2)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 7,  comment: "PM duration in hours" },
      { columnName: "ENGINEER_ID",     dataType: "VARCHAR2(32)",   isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 8,  comment: "Responsible engineer ID" },
      { columnName: "VENDOR_SUPPORT",  dataType: "VARCHAR2(1)",    isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 9,  comment: "Y/N vendor field service involved", defaultValue: "'N'" },
      { columnName: "PARTS_REPLACED",  dataType: "VARCHAR2(512)",  isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 10, comment: "Comma-separated list of replaced parts" },
      { columnName: "PRE_OEE",         dataType: "NUMBER(6,4)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 11, comment: "OEE before PM" },
      { columnName: "POST_OEE",        dataType: "NUMBER(6,4)",    isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 12, comment: "OEE after PM" },
      { columnName: "WAFERS_SINCE_PM", dataType: "NUMBER(10)",     isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 13, comment: "Wafer count since last PM" },
      { columnName: "PM_STATUS",       dataType: "VARCHAR2(16)",   isKey: false, isIndexed: true,  isNullable: false, ordinalPosition: 14, comment: "COMPLETED/IN_PROGRESS/CANCELLED" },
      { columnName: "QUAL_RESULT",     dataType: "VARCHAR2(8)",    isKey: false, isIndexed: true,  isNullable: true,  ordinalPosition: 15, comment: "Post-PM qualification: PASS/FAIL/SKIP" },
      { columnName: "REMARKS",         dataType: "VARCHAR2(1024)", isKey: false, isIndexed: false, isNullable: true,  ordinalPosition: 16, comment: "Free-text PM remarks" },
    ],
    indexes: [
      { indexName: "PK_EQUIPMENT_PM",      columns: ["PM_ID"],                       isUnique: true,  indexType: "BTREE" },
      { indexName: "IDX_EPM_EQP_TIME",     columns: ["EQUIPMENT_ID","START_TIME"],   isUnique: false, indexType: "BTREE" },
      { indexName: "IDX_EPM_TYPE_LEVEL",   columns: ["PM_TYPE","PM_LEVEL"],          isUnique: false, indexType: "BITMAP" },
      { indexName: "IDX_EPM_STATUS",       columns: ["PM_STATUS"],                   isUnique: false, indexType: "BITMAP" },
    ],
    foreignKeys: [
      { constraintName: "FK_EPM_EQP", columns: ["EQUIPMENT_ID"], referencedSchema: "VEDA", referencedTable: "EQUIPMENT_TOOL", referencedColumns: ["EQUIPMENT_ID"] },
    ],
  },
];

/**
 * Cross-table relationships for the 10 fab tables.
 */
export const SEMI_FAB_RELATIONSHIPS = [
  // LOT_HISTORY is the root anchor
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "WAFER_HISTORY",     fromColumn: "LOT_ID",       toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_HISTORY",       toColumn: "LOT_ID",       relationshipType: "foreign_key" as const, confidence: 1.0, description: "Wafer history belongs to a lot" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "WAT_DATA",          fromColumn: "LOT_ID",       toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_HISTORY",       toColumn: "LOT_ID",       relationshipType: "foreign_key" as const, confidence: 1.0, description: "WAT data belongs to a lot" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "CP_DATA",           fromColumn: "LOT_ID",       toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_HISTORY",       toColumn: "LOT_ID",       relationshipType: "foreign_key" as const, confidence: 1.0, description: "CP data belongs to a lot" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "FDC_DATA",          fromColumn: "LOT_ID",       toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_HISTORY",       toColumn: "LOT_ID",       relationshipType: "foreign_key" as const, confidence: 1.0, description: "FDC data belongs to a lot" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "INLINE_THICKNESS",  fromColumn: "LOT_ID",       toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_HISTORY",       toColumn: "LOT_ID",       relationshipType: "foreign_key" as const, confidence: 1.0, description: "Thickness measurement belongs to a lot" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "CD_MEASUREMENT",    fromColumn: "LOT_ID",       toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_HISTORY",       toColumn: "LOT_ID",       relationshipType: "foreign_key" as const, confidence: 1.0, description: "CD measurement belongs to a lot" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "DEFECT_INSPECTION", fromColumn: "LOT_ID",       toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_HISTORY",       toColumn: "LOT_ID",       relationshipType: "foreign_key" as const, confidence: 1.0, description: "Defect inspection belongs to a lot" },
  // WAFER_ID cross-table links
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "WAT_DATA",          fromColumn: "WAFER_ID",     toSource: "F12PEDA", toSchema: "VEDA", toTable: "WAFER_HISTORY",     toColumn: "WAFER_ID",     relationshipType: "logical" as const, confidence: 0.95, description: "WAT data for a specific wafer" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "CP_DATA",           fromColumn: "WAFER_ID",     toSource: "F12PEDA", toSchema: "VEDA", toTable: "WAFER_HISTORY",     toColumn: "WAFER_ID",     relationshipType: "logical" as const, confidence: 0.95, description: "CP data for a specific wafer" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "FDC_DATA",          fromColumn: "WAFER_ID",     toSource: "F12PEDA", toSchema: "VEDA", toTable: "WAFER_HISTORY",     toColumn: "WAFER_ID",     relationshipType: "logical" as const, confidence: 0.95, description: "FDC data for a specific wafer" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "INLINE_THICKNESS",  fromColumn: "WAFER_ID",     toSource: "F12PEDA", toSchema: "VEDA", toTable: "WAFER_HISTORY",     toColumn: "WAFER_ID",     relationshipType: "logical" as const, confidence: 0.95, description: "Thickness measurement for a specific wafer" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "CD_MEASUREMENT",    fromColumn: "WAFER_ID",     toSource: "F12PEDA", toSchema: "VEDA", toTable: "WAFER_HISTORY",     toColumn: "WAFER_ID",     relationshipType: "logical" as const, confidence: 0.95, description: "CD measurement for a specific wafer" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "DEFECT_INSPECTION", fromColumn: "WAFER_ID",     toSource: "F12PEDA", toSchema: "VEDA", toTable: "WAFER_HISTORY",     toColumn: "WAFER_ID",     relationshipType: "logical" as const, confidence: 0.95, description: "Defect inspection for a specific wafer" },
  // EQUIPMENT_ID links
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "WAFER_HISTORY",     fromColumn: "EQUIPMENT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "EQUIPMENT_TOOL",    toColumn: "EQUIPMENT_ID", relationshipType: "foreign_key" as const, confidence: 1.0, description: "Wafer processed on equipment" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "FDC_DATA",          fromColumn: "EQUIPMENT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "EQUIPMENT_TOOL",    toColumn: "EQUIPMENT_ID", relationshipType: "foreign_key" as const, confidence: 1.0, description: "FDC data from equipment sensors" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "EQUIPMENT_PM",      fromColumn: "EQUIPMENT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "EQUIPMENT_TOOL",    toColumn: "EQUIPMENT_ID", relationshipType: "foreign_key" as const, confidence: 1.0, description: "PM record for equipment" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "INLINE_THICKNESS",  fromColumn: "EQUIPMENT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "EQUIPMENT_TOOL",    toColumn: "EQUIPMENT_ID", relationshipType: "logical" as const, confidence: 0.9, description: "Thickness measured by equipment" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "CD_MEASUREMENT",    fromColumn: "EQUIPMENT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "EQUIPMENT_TOOL",    toColumn: "EQUIPMENT_ID", relationshipType: "logical" as const, confidence: 0.9, description: "CD measured by equipment" },
  { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "DEFECT_INSPECTION", fromColumn: "EQUIPMENT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "EQUIPMENT_TOOL",    toColumn: "EQUIPMENT_ID", relationshipType: "logical" as const, confidence: 0.9, description: "Defect inspection by equipment" },
];
