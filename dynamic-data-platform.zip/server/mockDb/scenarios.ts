/**
 * Mock Database Scenarios
 * Simulates real-world semiconductor manufacturing databases:
 * - F12PEDA (Oracle): Process Engineering Data Acquisition
 * - F12PMES (Oracle): Manufacturing Execution System
 * - f12edagp (GreenPlum/PostgreSQL): Enterprise Data Analytics
 *
 * Each scenario includes: tables, columns, indexes, foreign keys, row counts,
 * and business domain context for AI-driven join inference.
 */

export interface MockColumn {
  columnName: string;
  dataType: string;
  isKey: boolean;
  isIndexed: boolean;
  isNullable: boolean;
  ordinalPosition: number;
  defaultValue?: string;
  comment?: string;
}

export interface MockIndex {
  indexName: string;
  columns: string[];
  isUnique: boolean;
  indexType: "BTREE" | "BITMAP" | "HASH" | "FULLTEXT";
}

export interface MockForeignKey {
  constraintName: string;
  columns: string[];
  referencedSchema: string;
  referencedTable: string;
  referencedColumns: string[];
  onDelete?: "CASCADE" | "SET NULL" | "RESTRICT" | "NO ACTION";
}

export interface MockTable {
  tableName: string;
  approxRowCount: number;
  comment?: string;
  columns: MockColumn[];
  indexes: MockIndex[];
  foreignKeys: MockForeignKey[];
  partitionKey?: string;
  businessDomain?: string;
}

export interface MockSchema {
  schemaName: string;
  description: string;
  tables: MockTable[];
}

export interface MockDataSource {
  sourceName: string;
  dialect: "oracle" | "postgresql";
  description: string;
  schemas: MockSchema[];
}

// ─── F12PEDA: Oracle - Process Engineering Data Acquisition ───────────────────
const F12PEDA: MockDataSource = {
  sourceName: "F12PEDA",
  dialect: "oracle",
  description: "Oracle database for Process Engineering Data Acquisition - stores wafer processing, equipment, and yield data",
  schemas: [
    {
      schemaName: "VEDA",
      description: "Virtual Engineering Data Acquisition - core wafer and lot tracking",
      tables: [
        {
          tableName: "WAFER_RUN",
          approxRowCount: 8500000,
          comment: "Master record for each wafer run through the fab process",
          businessDomain: "wafer_tracking",
          columns: [
            { columnName: "WAFER_RUN_ID", dataType: "NUMBER(18)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1, comment: "Unique wafer run identifier (surrogate key)" },
            { columnName: "WAFER_ID", dataType: "VARCHAR2(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2, comment: "Physical wafer identifier (e.g. W12345-001)" },
            { columnName: "LOT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3, comment: "Lot/batch identifier" },
            { columnName: "PROCESS_STEP", dataType: "VARCHAR2(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4, comment: "Process step code (e.g. PHOTO_01, ETCH_02)" },
            { columnName: "EQUIPMENT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 5, comment: "Equipment used for this run" },
            { columnName: "RECIPE_ID", dataType: "VARCHAR2(64)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 6, comment: "Process recipe identifier" },
            { columnName: "START_TIME", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 7, comment: "Run start timestamp" },
            { columnName: "END_TIME", dataType: "DATE", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 8, comment: "Run end timestamp" },
            { columnName: "DURATION_MIN", dataType: "NUMBER(10,2)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 9, comment: "Run duration in minutes" },
            { columnName: "STATUS", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 10, defaultValue: "'COMPLETED'", comment: "Run status: RUNNING/COMPLETED/ABORTED/HOLD" },
            { columnName: "OPERATOR_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 11, comment: "Operator who executed the run" },
            { columnName: "CREATED_AT", dataType: "DATE", isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 12, defaultValue: "SYSDATE" },
          ],
          indexes: [
            { indexName: "PK_WAFER_RUN", columns: ["WAFER_RUN_ID"], isUnique: true, indexType: "BTREE" },
            { indexName: "IDX_WR_WAFER_ID", columns: ["WAFER_ID"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_WR_LOT_ID", columns: ["LOT_ID"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_WR_STEP_TIME", columns: ["PROCESS_STEP", "START_TIME"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_WR_EQP_TIME", columns: ["EQUIPMENT_ID", "START_TIME"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_WR_STATUS", columns: ["STATUS"], isUnique: false, indexType: "BITMAP" },
          ],
          foreignKeys: [
            { constraintName: "FK_WR_LOT", columns: ["LOT_ID"], referencedSchema: "VEDA", referencedTable: "LOT_MASTER", referencedColumns: ["LOT_ID"] },
            { constraintName: "FK_WR_EQP", columns: ["EQUIPMENT_ID"], referencedSchema: "VEDA", referencedTable: "EQUIPMENT", referencedColumns: ["EQUIPMENT_ID"] },
          ],
        },
        {
          tableName: "LOT_MASTER",
          approxRowCount: 450000,
          comment: "Master record for each production lot",
          businessDomain: "lot_tracking",
          columns: [
            { columnName: "LOT_ID", dataType: "VARCHAR2(32)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1, comment: "Unique lot identifier" },
            { columnName: "PRODUCT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2, comment: "Product code" },
            { columnName: "CUSTOMER_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 3, comment: "Customer identifier" },
            { columnName: "WAFER_QTY", dataType: "NUMBER(4)", isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 4, comment: "Number of wafers in lot" },
            { columnName: "PRIORITY", dataType: "VARCHAR2(8)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 5, defaultValue: "'NORMAL'", comment: "Lot priority: HOT/URGENT/NORMAL/LOW" },
            { columnName: "TECHNOLOGY_NODE", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 6, comment: "Technology node (e.g. 5NM, 7NM, 12NM)" },
            { columnName: "START_DATE", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 7, comment: "Lot start date" },
            { columnName: "DUE_DATE", dataType: "DATE", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 8, comment: "Committed delivery date" },
            { columnName: "STATUS", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 9, comment: "Lot status: ACTIVE/HOLD/COMPLETED/SCRAPPED" },
            { columnName: "HOLD_REASON", dataType: "VARCHAR2(256)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 10, comment: "Reason for hold if applicable" },
          ],
          indexes: [
            { indexName: "PK_LOT_MASTER", columns: ["LOT_ID"], isUnique: true, indexType: "BTREE" },
            { indexName: "IDX_LM_PRODUCT", columns: ["PRODUCT_ID"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_LM_CUSTOMER", columns: ["CUSTOMER_ID"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_LM_STATUS_DATE", columns: ["STATUS", "START_DATE"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_LM_TECH", columns: ["TECHNOLOGY_NODE"], isUnique: false, indexType: "BITMAP" },
          ],
          foreignKeys: [
            { constraintName: "FK_LM_PRODUCT", columns: ["PRODUCT_ID"], referencedSchema: "VEDA", referencedTable: "PRODUCT_MASTER", referencedColumns: ["PRODUCT_ID"] },
          ],
        },
        {
          tableName: "EQUIPMENT",
          approxRowCount: 1200,
          comment: "Equipment master data",
          businessDomain: "equipment",
          columns: [
            { columnName: "EQUIPMENT_ID", dataType: "VARCHAR2(32)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1, comment: "Unique equipment identifier" },
            { columnName: "EQUIPMENT_TYPE", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2, comment: "Equipment type (STEPPER/ETCHER/CVD/PVD/CMP)" },
            { columnName: "VENDOR", dataType: "VARCHAR2(64)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 3, comment: "Equipment vendor name" },
            { columnName: "MODEL", dataType: "VARCHAR2(64)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 4, comment: "Equipment model number" },
            { columnName: "AREA", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 5, comment: "Fab area (PHOTO/ETCH/DIFF/METAL)" },
            { columnName: "STATUS", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 6, comment: "Equipment status: UP/DOWN/PM/IDLE" },
            { columnName: "INSTALL_DATE", dataType: "DATE", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 7 },
            { columnName: "CAPACITY_WPH", dataType: "NUMBER(6,2)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 8, comment: "Capacity in wafers per hour" },
          ],
          indexes: [
            { indexName: "PK_EQUIPMENT", columns: ["EQUIPMENT_ID"], isUnique: true, indexType: "BTREE" },
            { indexName: "IDX_EQP_TYPE_AREA", columns: ["EQUIPMENT_TYPE", "AREA"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_EQP_STATUS", columns: ["STATUS"], isUnique: false, indexType: "BITMAP" },
          ],
          foreignKeys: [],
        },
        {
          tableName: "PRODUCT_MASTER",
          approxRowCount: 3500,
          comment: "Product definition and specification",
          businessDomain: "product",
          columns: [
            { columnName: "PRODUCT_ID", dataType: "VARCHAR2(32)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1, comment: "Unique product identifier" },
            { columnName: "PRODUCT_NAME", dataType: "VARCHAR2(128)", isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 2 },
            { columnName: "TECHNOLOGY_NODE", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
            { columnName: "DIE_SIZE_MM2", dataType: "NUMBER(10,4)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 4, comment: "Die size in mm²" },
            { columnName: "CUSTOMER_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 5 },
            { columnName: "STATUS", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 6 },
          ],
          indexes: [
            { indexName: "PK_PRODUCT_MASTER", columns: ["PRODUCT_ID"], isUnique: true, indexType: "BTREE" },
            { indexName: "IDX_PM_TECH_CUST", columns: ["TECHNOLOGY_NODE", "CUSTOMER_ID"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [],
        },
        {
          tableName: "WAFER_YIELD",
          approxRowCount: 6200000,
          comment: "Wafer-level yield measurement results",
          businessDomain: "yield",
          columns: [
            { columnName: "YIELD_ID", dataType: "NUMBER(18)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
            { columnName: "WAFER_ID", dataType: "VARCHAR2(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2, comment: "Links to WAFER_RUN.WAFER_ID" },
            { columnName: "LOT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
            { columnName: "MEASUREMENT_STEP", dataType: "VARCHAR2(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4 },
            { columnName: "TOTAL_DIE", dataType: "NUMBER(8)", isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 5 },
            { columnName: "GOOD_DIE", dataType: "NUMBER(8)", isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 6 },
            { columnName: "YIELD_RATE", dataType: "NUMBER(8,4)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 7, comment: "Yield percentage (0-100)" },
            { columnName: "DEFECT_DENSITY", dataType: "NUMBER(12,6)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 8, comment: "Defects per cm²" },
            { columnName: "MEASURED_AT", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 9 },
          ],
          indexes: [
            { indexName: "PK_WAFER_YIELD", columns: ["YIELD_ID"], isUnique: true, indexType: "BTREE" },
            { indexName: "IDX_WY_WAFER_STEP", columns: ["WAFER_ID", "MEASUREMENT_STEP"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_WY_LOT_DATE", columns: ["LOT_ID", "MEASURED_AT"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [
            { constraintName: "FK_WY_LOT", columns: ["LOT_ID"], referencedSchema: "VEDA", referencedTable: "LOT_MASTER", referencedColumns: ["LOT_ID"] },
          ],
        },
      ],
    },
    {
      schemaName: "FDC",
      description: "Fault Detection and Classification - equipment sensor data",
      tables: [
        {
          tableName: "FDC_ALARM",
          approxRowCount: 25000000,
          comment: "Equipment fault detection alarms",
          businessDomain: "fault_detection",
          columns: [
            { columnName: "ALARM_ID", dataType: "NUMBER(18)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
            { columnName: "WAFER_RUN_ID", dataType: "NUMBER(18)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 2, comment: "Links to VEDA.WAFER_RUN.WAFER_RUN_ID" },
            { columnName: "EQUIPMENT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
            { columnName: "ALARM_CODE", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4 },
            { columnName: "ALARM_CLASS", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 5, comment: "Alarm class: CRITICAL/MAJOR/MINOR/WARNING" },
            { columnName: "PARAMETER_NAME", dataType: "VARCHAR2(64)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 6 },
            { columnName: "MEASURED_VALUE", dataType: "NUMBER(18,6)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 7 },
            { columnName: "UCL", dataType: "NUMBER(18,6)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 8, comment: "Upper control limit" },
            { columnName: "LCL", dataType: "NUMBER(18,6)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 9, comment: "Lower control limit" },
            { columnName: "ALARM_TIME", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 10 },
            { columnName: "CLEARED_TIME", dataType: "DATE", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 11 },
          ],
          indexes: [
            { indexName: "PK_FDC_ALARM", columns: ["ALARM_ID"], isUnique: true, indexType: "BTREE" },
            { indexName: "IDX_FA_RUN_ID", columns: ["WAFER_RUN_ID"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_FA_EQP_TIME", columns: ["EQUIPMENT_ID", "ALARM_TIME"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_FA_CODE_CLASS", columns: ["ALARM_CODE", "ALARM_CLASS"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [
            { constraintName: "FK_FA_RUN", columns: ["WAFER_RUN_ID"], referencedSchema: "VEDA", referencedTable: "WAFER_RUN", referencedColumns: ["WAFER_RUN_ID"] },
            { constraintName: "FK_FA_EQP", columns: ["EQUIPMENT_ID"], referencedSchema: "VEDA", referencedTable: "EQUIPMENT", referencedColumns: ["EQUIPMENT_ID"] },
          ],
        },
        {
          tableName: "SPC_CHART",
          approxRowCount: 180000000,
          comment: "Statistical Process Control measurement data",
          businessDomain: "spc",
          partitionKey: "MEASURED_AT",
          columns: [
            { columnName: "SPC_ID", dataType: "NUMBER(18)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
            { columnName: "WAFER_RUN_ID", dataType: "NUMBER(18)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 2 },
            { columnName: "EQUIPMENT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
            { columnName: "PARAMETER_NAME", dataType: "VARCHAR2(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4 },
            { columnName: "MEASURED_VALUE", dataType: "NUMBER(18,6)", isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 5 },
            { columnName: "UCL", dataType: "NUMBER(18,6)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 6 },
            { columnName: "LCL", dataType: "NUMBER(18,6)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 7 },
            { columnName: "TARGET", dataType: "NUMBER(18,6)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 8 },
            { columnName: "MEASURED_AT", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 9 },
            { columnName: "CHART_TYPE", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 10, comment: "XBAR/R/S/P/NP/C/U" },
          ],
          indexes: [
            { indexName: "PK_SPC_CHART", columns: ["SPC_ID"], isUnique: true, indexType: "BTREE" },
            { indexName: "IDX_SC_RUN_PARAM", columns: ["WAFER_RUN_ID", "PARAMETER_NAME"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_SC_EQP_PARAM_TIME", columns: ["EQUIPMENT_ID", "PARAMETER_NAME", "MEASURED_AT"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [
            { constraintName: "FK_SC_RUN", columns: ["WAFER_RUN_ID"], referencedSchema: "VEDA", referencedTable: "WAFER_RUN", referencedColumns: ["WAFER_RUN_ID"] },
          ],
        },
      ],
    },
  ],
};

// ─── F12PMES: Oracle - Manufacturing Execution System ─────────────────────────
const F12PMES: MockDataSource = {
  sourceName: "F12PMES",
  dialect: "oracle",
  description: "Oracle MES database - work orders, dispatching, WIP tracking, and production scheduling",
  schemas: [
    {
      schemaName: "MES",
      description: "Manufacturing Execution System core schema",
      tables: [
        {
          tableName: "WORK_ORDER",
          approxRowCount: 1200000,
          comment: "Production work orders",
          businessDomain: "production",
          columns: [
            { columnName: "WO_ID", dataType: "VARCHAR2(32)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1, comment: "Work order identifier" },
            { columnName: "LOT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2, comment: "Links to VEDA.LOT_MASTER.LOT_ID (cross-DB)" },
            { columnName: "OPERATION_CODE", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
            { columnName: "EQUIPMENT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 4 },
            { columnName: "PLANNED_START", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 5 },
            { columnName: "ACTUAL_START", dataType: "DATE", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 6 },
            { columnName: "ACTUAL_END", dataType: "DATE", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 7 },
            { columnName: "STATUS", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 8 },
            { columnName: "PRIORITY", dataType: "NUMBER(3)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 9, defaultValue: "5" },
            { columnName: "OPERATOR_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 10 },
          ],
          indexes: [
            { indexName: "PK_WORK_ORDER", columns: ["WO_ID"], isUnique: true, indexType: "BTREE" },
            { indexName: "IDX_WO_LOT", columns: ["LOT_ID"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_WO_EQP_STATUS", columns: ["EQUIPMENT_ID", "STATUS"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_WO_PLANNED", columns: ["PLANNED_START", "STATUS"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [],
        },
        {
          tableName: "WIP_TRACKING",
          approxRowCount: 3500000,
          comment: "Work-in-process tracking events",
          businessDomain: "wip",
          columns: [
            { columnName: "TRACK_ID", dataType: "NUMBER(18)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
            { columnName: "LOT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
            { columnName: "WAFER_ID", dataType: "VARCHAR2(64)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 3 },
            { columnName: "OPERATION_CODE", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4 },
            { columnName: "EVENT_TYPE", dataType: "VARCHAR2(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 5, comment: "MOVE_IN/MOVE_OUT/HOLD/RELEASE/SCRAP" },
            { columnName: "EQUIPMENT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 6 },
            { columnName: "EVENT_TIME", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 7 },
            { columnName: "QUANTITY", dataType: "NUMBER(6)", isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 8 },
            { columnName: "OPERATOR_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 9 },
            { columnName: "REASON_CODE", dataType: "VARCHAR2(32)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 10 },
          ],
          indexes: [
            { indexName: "PK_WIP_TRACKING", columns: ["TRACK_ID"], isUnique: true, indexType: "BTREE" },
            { indexName: "IDX_WT_LOT_TIME", columns: ["LOT_ID", "EVENT_TIME"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_WT_WAFER_OP", columns: ["WAFER_ID", "OPERATION_CODE"], isUnique: false, indexType: "BTREE" },
            { indexName: "IDX_WT_EQP_TIME", columns: ["EQUIPMENT_ID", "EVENT_TIME"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [],
        },
        {
          tableName: "DISPATCH_QUEUE",
          approxRowCount: 85000,
          comment: "Current dispatch queue for equipment assignment",
          businessDomain: "dispatching",
          columns: [
            { columnName: "QUEUE_ID", dataType: "NUMBER(18)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
            { columnName: "LOT_ID", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
            { columnName: "OPERATION_CODE", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
            { columnName: "EQUIPMENT_GROUP", dataType: "VARCHAR2(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4 },
            { columnName: "QUEUE_TIME", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 5 },
            { columnName: "PRIORITY_SCORE", dataType: "NUMBER(10,4)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 6 },
            { columnName: "HOLD_FLAG", dataType: "VARCHAR2(1)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 7, defaultValue: "'N'" },
          ],
          indexes: [
            { indexName: "PK_DISPATCH_QUEUE", columns: ["QUEUE_ID"], isUnique: true, indexType: "BTREE" },
            { indexName: "IDX_DQ_OP_PRIORITY", columns: ["OPERATION_CODE", "PRIORITY_SCORE"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [],
        },
      ],
    },
  ],
};

// ─── f12edagp: GreenPlum/PostgreSQL - Enterprise Data Analytics ───────────────
const F12EDAGP: MockDataSource = {
  sourceName: "f12edagp",
  dialect: "postgresql",
  description: "GreenPlum MPP database for enterprise analytics - aggregated views, KPI summaries, and cross-system data",
  schemas: [
    {
      schemaName: "analytics",
      description: "Pre-aggregated analytics tables for reporting and BI",
      tables: [
        {
          tableName: "daily_yield_summary",
          approxRowCount: 2500000,
          comment: "Daily aggregated yield by product/technology/equipment",
          businessDomain: "yield_analytics",
          partitionKey: "summary_date",
          columns: [
            { columnName: "summary_id", dataType: "bigint", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
            { columnName: "summary_date", dataType: "date", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
            { columnName: "product_id", dataType: "varchar(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
            { columnName: "technology_node", dataType: "varchar(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4 },
            { columnName: "process_step", dataType: "varchar(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 5 },
            { columnName: "equipment_id", dataType: "varchar(32)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 6 },
            { columnName: "total_wafers", dataType: "integer", isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 7 },
            { columnName: "avg_yield_rate", dataType: "numeric(8,4)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 8 },
            { columnName: "min_yield_rate", dataType: "numeric(8,4)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 9 },
            { columnName: "max_yield_rate", dataType: "numeric(8,4)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 10 },
            { columnName: "std_dev_yield", dataType: "numeric(8,4)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 11 },
            { columnName: "total_defects", dataType: "bigint", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 12 },
          ],
          indexes: [
            { indexName: "pk_daily_yield_summary", columns: ["summary_id"], isUnique: true, indexType: "BTREE" },
            { indexName: "idx_dys_date_product", columns: ["summary_date", "product_id"], isUnique: false, indexType: "BTREE" },
            { indexName: "idx_dys_tech_step", columns: ["technology_node", "process_step"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [],
        },
        {
          tableName: "equipment_utilization",
          approxRowCount: 850000,
          comment: "Equipment utilization and OEE metrics",
          businessDomain: "equipment_analytics",
          columns: [
            { columnName: "util_id", dataType: "bigint", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
            { columnName: "equipment_id", dataType: "varchar(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
            { columnName: "report_date", dataType: "date", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
            { columnName: "uptime_hours", dataType: "numeric(8,2)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 4 },
            { columnName: "productive_hours", dataType: "numeric(8,2)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 5 },
            { columnName: "pm_hours", dataType: "numeric(8,2)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 6, comment: "Preventive maintenance hours" },
            { columnName: "down_hours", dataType: "numeric(8,2)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 7 },
            { columnName: "oee_rate", dataType: "numeric(6,4)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 8, comment: "Overall Equipment Effectiveness (0-1)" },
            { columnName: "wafers_processed", dataType: "integer", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 9 },
          ],
          indexes: [
            { indexName: "pk_equipment_utilization", columns: ["util_id"], isUnique: true, indexType: "BTREE" },
            { indexName: "idx_eu_eqp_date", columns: ["equipment_id", "report_date"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [],
        },
        {
          tableName: "lot_cycle_time",
          approxRowCount: 450000,
          comment: "Lot cycle time analysis by operation",
          businessDomain: "cycle_time",
          columns: [
            { columnName: "ct_id", dataType: "bigint", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
            { columnName: "lot_id", dataType: "varchar(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
            { columnName: "product_id", dataType: "varchar(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
            { columnName: "operation_code", dataType: "varchar(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4 },
            { columnName: "queue_time_hrs", dataType: "numeric(10,2)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 5 },
            { columnName: "process_time_hrs", dataType: "numeric(10,2)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 6 },
            { columnName: "total_ct_hrs", dataType: "numeric(10,2)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 7 },
            { columnName: "move_in_time", dataType: "timestamp", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 8 },
            { columnName: "move_out_time", dataType: "timestamp", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 9 },
          ],
          indexes: [
            { indexName: "pk_lot_cycle_time", columns: ["ct_id"], isUnique: true, indexType: "BTREE" },
            { indexName: "idx_lct_lot_op", columns: ["lot_id", "operation_code"], isUnique: false, indexType: "BTREE" },
            { indexName: "idx_lct_product_op", columns: ["product_id", "operation_code"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [],
        },
      ],
    },
    {
      schemaName: "staging",
      description: "Staging area for ETL from Oracle sources",
      tables: [
        {
          tableName: "stg_wafer_run",
          approxRowCount: 8500000,
          comment: "Staging copy of F12PEDA.VEDA.WAFER_RUN for analytics",
          businessDomain: "staging",
          columns: [
            { columnName: "wafer_run_id", dataType: "bigint", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 },
            { columnName: "wafer_id", dataType: "varchar(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 2 },
            { columnName: "lot_id", dataType: "varchar(32)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 },
            { columnName: "process_step", dataType: "varchar(64)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 4 },
            { columnName: "equipment_id", dataType: "varchar(32)", isKey: false, isIndexed: true, isNullable: true, ordinalPosition: 5 },
            { columnName: "start_time", dataType: "timestamp", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 6 },
            { columnName: "end_time", dataType: "timestamp", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 7 },
            { columnName: "status", dataType: "varchar(16)", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 8 },
            { columnName: "etl_loaded_at", dataType: "timestamp", isKey: false, isIndexed: false, isNullable: false, ordinalPosition: 9 },
          ],
          indexes: [
            { indexName: "pk_stg_wafer_run", columns: ["wafer_run_id"], isUnique: true, indexType: "BTREE" },
            { indexName: "idx_swr_lot_step", columns: ["lot_id", "process_step"], isUnique: false, indexType: "BTREE" },
          ],
          foreignKeys: [],
        },
      ],
    },
  ],
};

// ─── Export registry ──────────────────────────────────────────────────────────
export const MOCK_DB_REGISTRY: Record<string, MockDataSource> = {
  F12PEDA,
  F12PMES,
  f12edagp: F12EDAGP,
};

// ─── Register fab tables into F12PEDA VEDA schema ─────────────────────────────
// Import and inject the 10 semiconductor fab tables into the existing VEDA schema
import { SEMI_FAB_TABLES, SEMI_FAB_RELATIONSHIPS } from "./semiFabScenarios";

// Inject fab tables into F12PEDA VEDA schema (avoid duplicates)
const vedaSchema = F12PEDA.schemas.find(s => s.schemaName === "VEDA");
if (vedaSchema) {
  const existingNames = new Set(vedaSchema.tables.map(t => t.tableName));
  for (const t of SEMI_FAB_TABLES) {
    if (!existingNames.has(t.tableName)) {
      vedaSchema.tables.push(t);
    }
  }
}

export function getMockDataSource(sourceName: string): MockDataSource | undefined {
  return MOCK_DB_REGISTRY[sourceName];
}

export function getMockSchema(sourceName: string, schemaName: string): MockSchema | undefined {
  return getMockDataSource(sourceName)?.schemas.find(s => s.schemaName === schemaName);
}

export function getMockTable(sourceName: string, schemaName: string, tableName: string): MockTable | undefined {
  return getMockSchema(sourceName, schemaName)?.tables.find(t => t.tableName === tableName);
}

/**
 * Build a cross-schema relationship map for join inference.
 * Returns all known FK-like relationships including cross-DB logical links.
 */
export function buildRelationshipGraph(): Array<{
  fromSource: string; fromSchema: string; fromTable: string; fromColumn: string;
  toSource: string; toSchema: string; toTable: string; toColumn: string;
  relationshipType: "foreign_key" | "logical" | "naming_convention";
  confidence: number;
  description: string;
}> {
  const edges = [];

  // Explicit FK relationships within F12PEDA
  edges.push(
    { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "WAFER_RUN", fromColumn: "LOT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_MASTER", toColumn: "LOT_ID", relationshipType: "foreign_key" as const, confidence: 1.0, description: "Wafer runs belong to a lot" },
    { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "WAFER_RUN", fromColumn: "EQUIPMENT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "EQUIPMENT", toColumn: "EQUIPMENT_ID", relationshipType: "foreign_key" as const, confidence: 1.0, description: "Wafer run uses equipment" },
    { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "LOT_MASTER", fromColumn: "PRODUCT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "PRODUCT_MASTER", toColumn: "PRODUCT_ID", relationshipType: "foreign_key" as const, confidence: 1.0, description: "Lot belongs to a product" },
    { fromSource: "F12PEDA", fromSchema: "VEDA", fromTable: "WAFER_YIELD", fromColumn: "LOT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_MASTER", toColumn: "LOT_ID", relationshipType: "foreign_key" as const, confidence: 1.0, description: "Yield data for a lot" },
    { fromSource: "F12PEDA", fromSchema: "FDC", fromTable: "FDC_ALARM", fromColumn: "WAFER_RUN_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "WAFER_RUN", toColumn: "WAFER_RUN_ID", relationshipType: "foreign_key" as const, confidence: 1.0, description: "FDC alarm triggered during wafer run" },
    { fromSource: "F12PEDA", fromSchema: "FDC", fromTable: "FDC_ALARM", fromColumn: "EQUIPMENT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "EQUIPMENT", toColumn: "EQUIPMENT_ID", relationshipType: "foreign_key" as const, confidence: 1.0, description: "FDC alarm on equipment" },
    { fromSource: "F12PEDA", fromSchema: "FDC", fromTable: "SPC_CHART", fromColumn: "WAFER_RUN_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "WAFER_RUN", toColumn: "WAFER_RUN_ID", relationshipType: "foreign_key" as const, confidence: 1.0, description: "SPC measurement for wafer run" },
    // Cross-DB logical links (F12PEDA <-> F12PMES via LOT_ID)
    { fromSource: "F12PMES", fromSchema: "MES", fromTable: "WORK_ORDER", fromColumn: "LOT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_MASTER", toColumn: "LOT_ID", relationshipType: "logical" as const, confidence: 0.95, description: "MES work order references PEDA lot (cross-DB)" },
    { fromSource: "F12PMES", fromSchema: "MES", fromTable: "WIP_TRACKING", fromColumn: "LOT_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_MASTER", toColumn: "LOT_ID", relationshipType: "logical" as const, confidence: 0.95, description: "WIP event references PEDA lot (cross-DB)" },
    { fromSource: "F12PMES", fromSchema: "MES", fromTable: "WIP_TRACKING", fromColumn: "WAFER_ID", toSource: "F12PEDA", toSchema: "VEDA", toTable: "WAFER_RUN", toColumn: "WAFER_ID", relationshipType: "logical" as const, confidence: 0.90, description: "WIP event references PEDA wafer (cross-DB)" },
    // GreenPlum staging mirrors
    { fromSource: "f12edagp", fromSchema: "staging", fromTable: "stg_wafer_run", fromColumn: "wafer_id", toSource: "F12PEDA", toSchema: "VEDA", toTable: "WAFER_RUN", toColumn: "WAFER_ID", relationshipType: "logical" as const, confidence: 0.98, description: "GreenPlum staging mirrors Oracle WAFER_RUN" },
    { fromSource: "f12edagp", fromSchema: "analytics", fromTable: "lot_cycle_time", fromColumn: "lot_id", toSource: "F12PEDA", toSchema: "VEDA", toTable: "LOT_MASTER", toColumn: "LOT_ID", relationshipType: "logical" as const, confidence: 0.95, description: "Analytics lot cycle time references PEDA lot" },
    { fromSource: "f12edagp", fromSchema: "analytics", fromTable: "daily_yield_summary", fromColumn: "equipment_id", toSource: "F12PEDA", toSchema: "VEDA", toTable: "EQUIPMENT", toColumn: "EQUIPMENT_ID", relationshipType: "logical" as const, confidence: 0.90, description: "Analytics yield summary references PEDA equipment" },
  );

  // Add fab table relationships
  edges.push(...SEMI_FAB_RELATIONSHIPS);

  return edges;
}
