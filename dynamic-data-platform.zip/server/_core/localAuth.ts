import { createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { parse as parseCookieHeader } from "cookie";
import { SignJWT, jwtVerify } from "jose";
import type { Request } from "express";
import type { User } from "../../drizzle/schema";
import { COOKIE_NAME } from "@shared/const";
import * as db from "../db";

const scrypt = promisify(scryptCallback);
const SESSION_DURATION_SECONDS = 8 * 60 * 60;
const SESSION_ISSUER = "ddop-local-auth";
const SESSION_AUDIENCE = "ddop-web";

export type LocalSessionPayload = {
  userId: number;
  email: string;
  role: "user" | "admin";
};

function sessionSecret() {
  const secret = process.env.JWT_SECRET ?? "";
  if (!secret) {
    throw new Error("JWT_SECRET must be configured for local DDOP authentication");
  }
  // The platform injects a high-entropy built-in JWT_SECRET that is shorter than
  // 32 text characters. Derive a fixed 256-bit HMAC key rather than weakening
  // signing or requiring the secret value to be exposed in application code.
  return createHash("sha256").update(secret, "utf8").digest();
}

export function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

export function assertStrongPassword(password: string) {
  if (password.length < 12 || password.length > 128) {
    throw new Error("Password must contain 12 to 128 characters");
  }
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    throw new Error("Password must include at least one letter and one number");
  }
}

export async function hashPassword(password: string) {
  assertStrongPassword(password);
  const salt = randomBytes(16).toString("hex");
  const derivedKey = (await scrypt(password, salt, 64)) as Buffer;
  return `scrypt$${salt}$${derivedKey.toString("hex")}`;
}

export async function verifyPassword(password: string, storedHash: string | null) {
  if (!storedHash) return false;
  const [algorithm, salt, expectedHex] = storedHash.split("$");
  if (algorithm !== "scrypt" || !salt || !expectedHex) return false;

  const expected = Buffer.from(expectedHex, "hex");
  const actual = (await scrypt(password, salt, 64)) as Buffer;
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

function getRequestToken(req: Request) {
  const cookies = parseCookieHeader(req.headers.cookie ?? "");
  const cookieToken = cookies[COOKIE_NAME];
  if (cookieToken) return cookieToken;

  const authorization = req.headers.authorization;
  return typeof authorization === "string" && authorization.startsWith("Bearer ")
    ? authorization.slice(7)
    : undefined;
}

export async function createSessionToken(user: User) {
  return new SignJWT({
    email: user.email ?? "",
    role: user.role,
  })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuer(SESSION_ISSUER)
    .setAudience(SESSION_AUDIENCE)
    .setSubject(String(user.id))
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DURATION_SECONDS}s`)
    .sign(sessionSecret());
}

export async function verifySessionToken(token: string | undefined): Promise<LocalSessionPayload | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, sessionSecret(), {
      algorithms: ["HS256"],
      issuer: SESSION_ISSUER,
      audience: SESSION_AUDIENCE,
    });
    const userId = Number(payload.sub);
    const email = typeof payload.email === "string" ? payload.email : "";
    const role = payload.role === "admin" ? "admin" : "user";
    if (!Number.isInteger(userId) || userId < 1 || !email) return null;
    return { userId, email, role };
  } catch {
    return null;
  }
}

export async function authenticateRequest(req: Request) {
  const payload = await verifySessionToken(getRequestToken(req));
  if (!payload) throw new Error("Invalid or expired local JWT");
  const user = await db.getUserById(payload.userId);
  if (!user || !user.passwordHash) throw new Error("Local user not found");
  return user;
}
