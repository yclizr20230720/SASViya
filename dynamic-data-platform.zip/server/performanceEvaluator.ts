/**
 * Advanced Performance Evaluator
 * Evaluates query performance risks using:
 * - Table row count analysis
 * - Index coverage checking
 * - Join column index verification
 * - Cross-schema join detection
 * - Partition pruning opportunities
 */
import { getTablesForSchema, getColumnsForTable } from "./db";
import type { DatasetDefinition, EvaluationFinding } from "../drizzle/schema";

export async function evaluatePerformanceAdvanced(
  def: DatasetDefinition,
  primarySourceId: number,
  fullScanThreshold: number
): Promise<{ verdict: "pass" | "warn" | "block"; findings: EvaluationFinding[] }> {
  const findings: EvaluationFinding[] = [];

  // Track unique sources for cross-DB join detection
  const uniqueSources = new Set(def.selections.map(s => s.sourceId));
  if (uniqueSources.size > 1) {
    findings.push({
      type: "cross_db_join",
      severity: "warn",
      table: "multiple",
      message: `Query spans ${uniqueSources.size} different data sources. Cross-database joins require application-level joining and may have significant performance implications.`,
      details: "Consider using the GreenPlum analytics schema which pre-joins data from multiple sources.",
    });
  }

  for (const sel of def.selections) {
    const tables = await getTablesForSchema(sel.sourceId, sel.schemaName);
    const tableInfo = tables.find(t => t.tableName === sel.tableName);
    const rowCount = tableInfo?.approxRowCount ?? 0;
    const columns = await getColumnsForTable(sel.sourceId, sel.schemaName, sel.tableName);
    const tableCriteria = (def.criteria || []).filter(c => c.tableName === sel.tableName && c.schemaName === sel.schemaName);
    const tableJoins = (def.joins || []).filter(j =>
      (j.leftTable === sel.tableName && j.leftSchema === sel.schemaName) ||
      (j.rightTable === sel.tableName && j.rightSchema === sel.schemaName)
    );

    // Check partition key usage
    const partitionKey = tableInfo?.partitionKey;
    if (partitionKey && rowCount > 10000000) {
      const partitionFiltered = tableCriteria.some(c => c.columnName === partitionKey);
      if (!partitionFiltered) {
        findings.push({
          type: "partition_scan",
          severity: "warn",
          table: `${sel.schemaName}.${sel.tableName}`,
          message: `Table ${sel.tableName} is partitioned by ${partitionKey} (${rowCount.toLocaleString()} rows). Adding a filter on ${partitionKey} would enable partition pruning and dramatically improve performance.`,
        });
      }
    }

    // Full table scan check
    if (rowCount > fullScanThreshold && tableCriteria.length === 0 && tableJoins.length === 0) {
      findings.push({
        type: "full_table_scan",
        severity: rowCount > 10000000 ? "block" : "warn",
        table: `${sel.schemaName}.${sel.tableName}`,
        message: `Full table scan on ${sel.schemaName}.${sel.tableName} (~${rowCount.toLocaleString()} rows) — no filter or join condition defined.`,
        details: `Add WHERE conditions on indexed columns (e.g., ${columns.filter(c => c.isIndexed || c.isKey).slice(0, 3).map(c => c.columnName).join(", ")}) to avoid full scan.`,
      });
    }

    // Index coverage for filter columns
    for (const crit of tableCriteria) {
      const colMeta = columns.find(c => c.columnName === crit.columnName);
      if (colMeta && !colMeta.isIndexed && !colMeta.isKey) {
        const severity = rowCount > fullScanThreshold ? "block" : "warn";
        findings.push({
          type: "missing_index",
          severity,
          table: `${sel.schemaName}.${sel.tableName}`,
          column: crit.columnName,
          message: `Filter column ${crit.columnName} on ${sel.schemaName}.${sel.tableName} is not indexed.`,
          details: rowCount > fullScanThreshold
            ? `CRITICAL: This will cause a full table scan on ${rowCount.toLocaleString()} rows. Use an indexed column instead.`
            : `Consider adding an index on ${crit.columnName} for better performance.`,
        });
      }
    }

    // Index coverage for join columns
    for (const join of tableJoins) {
      const joinCol = join.leftTable === sel.tableName ? join.leftColumn : join.rightColumn;
      const colMeta = columns.find(c => c.columnName === joinCol);
      if (colMeta && !colMeta.isIndexed && !colMeta.isKey) {
        findings.push({
          type: "missing_index",
          severity: "warn",
          table: `${sel.schemaName}.${sel.tableName}`,
          column: joinCol,
          message: `Join column ${joinCol} on ${sel.schemaName}.${sel.tableName} is not indexed — nested loop join will be slow.`,
        });
      }
    }

    // Large result set warning
    if (rowCount > 1000000 && tableCriteria.length > 0) {
      const indexedCriteria = tableCriteria.filter(c => {
        const col = columns.find(cc => cc.columnName === c.columnName);
        return col?.isIndexed || col?.isKey;
      });
      if (indexedCriteria.length === 0) {
        findings.push({
          type: "no_indexed_filter",
          severity: "warn",
          table: `${sel.schemaName}.${sel.tableName}`,
          message: `Table ${sel.tableName} has ${rowCount.toLocaleString()} rows but none of the filter conditions use indexed columns.`,
        });
      }
    }
  }

  const hasBlock = findings.some(f => f.severity === "block");
  const hasWarn = findings.some(f => f.severity === "warn");
  return { verdict: hasBlock ? "block" : hasWarn ? "warn" : "pass", findings };
}
