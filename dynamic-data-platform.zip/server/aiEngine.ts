/**
 * AI Analysis Engine
 * Uses LLM to analyze schema metadata and infer:
 * 1. Join conditions between selected tables
 * 2. Business relationship descriptions
 * 3. Query optimization recommendations
 * 4. Performance risk assessment
 */
import { invokeLLM } from "./_core/llm";
import { buildRelationshipGraph } from "./mockDb/scenarios";
import { getTablesForSchema, getColumnsForTable, getDictionaryEntries } from "./db";
import type { ColumnSelection, JoinDefinition, DatasetDefinition } from "../drizzle/schema";

export interface JoinSuggestion {
  leftSchema: string;
  leftTable: string;
  leftColumn: string;
  rightSchema: string;
  rightTable: string;
  rightColumn: string;
  joinType: "INNER" | "LEFT" | "RIGHT";
  confidence: number;
  reasoning: string;
  source: "foreign_key" | "naming_convention" | "ai_inferred";
  performanceNote?: string;
}

export interface AIAnalysisResult {
  joinSuggestions: JoinSuggestion[];
  queryStrategy: string;
  performanceWarnings: string[];
  optimizationTips: string[];
  businessContext: string;
  estimatedComplexity: "simple" | "moderate" | "complex" | "very_complex";
  recommendedApproach: string;
}

export interface SmartSqlResult {
  sql: string;
  params: Record<string, unknown>;
  joinPath: JoinSuggestion[];
  aiAnalysis: AIAnalysisResult;
  issues: string[];
  dialect: string;
}

/**
 * Main entry point: analyze selected columns and generate smart SQL with AI.
 */
export async function generateSmartSql(
  def: DatasetDefinition,
  sourceNames: Record<number, string>,  // sourceId -> sourceName
  sourceDialects: Record<number, string>,
  fullScanThresholds: Record<number, number>
): Promise<SmartSqlResult> {
  const issues: string[] = [];

  // Step 1: Gather full schema context for selected tables
  const schemaContext = await buildSchemaContext(def.selections, sourceNames);

  // Step 2: Find known relationships from FK graph
  const knownRelationships = findKnownRelationships(def.selections, sourceNames);

  // Step 3: Call LLM to infer join conditions and analyze query
  const aiAnalysis = await callLLMForAnalysis(schemaContext, knownRelationships, def);

  // Step 4: Build join path (FK-first, then AI suggestions)
  const joinPath = buildJoinPath(def.selections, knownRelationships, aiAnalysis.joinSuggestions);

  // Step 5: Generate parameterized SQL
  const primaryDialect = Object.values(sourceDialects)[0] ?? "oracle";
  const { sql, params } = buildSmartSql(def, joinPath, primaryDialect);

  return { sql, params, joinPath, aiAnalysis, issues, dialect: primaryDialect };
}

/**
 * Build schema context string for LLM prompt.
 */
async function buildSchemaContext(
  selections: ColumnSelection[],
  sourceNames: Record<number, string>
): Promise<string> {
  const parts: string[] = [];

  for (const sel of selections) {
    const sourceName = sourceNames[sel.sourceId] ?? `Source#${sel.sourceId}`;
    const tables = await getTablesForSchema(sel.sourceId, sel.schemaName);
    const tableInfo = tables.find(t => t.tableName === sel.tableName);
    const columns = await getColumnsForTable(sel.sourceId, sel.schemaName, sel.tableName);
    const dictEntries = await getDictionaryEntries(sel.sourceId, sel.schemaName);

    const selectedCols = columns.filter(c => sel.columns.includes(c.columnName));
    const allCols = columns;

    const tableDesc = dictEntries.find(d => d.tableName === sel.tableName && !d.columnName)?.description ?? tableInfo?.tableComment ?? "";

    parts.push(`
TABLE: ${sourceName}.${sel.schemaName}.${sel.tableName}
Description: ${tableDesc || "(no description)"}
Approx Rows: ${tableInfo?.approxRowCount?.toLocaleString() ?? "unknown"}
Business Domain: ${tableInfo?.businessDomain ?? "unknown"}
Partition Key: ${tableInfo?.partitionKey ?? "none"}

ALL COLUMNS (with types, key/index info):
${allCols.map(c => {
  const dict = dictEntries.find(d => d.tableName === c.tableName && d.columnName === c.columnName);
  const flags = [c.isKey ? "PK" : "", c.isIndexed ? "IDX" : "", c.isNullable ? "NULL" : "NOT NULL"].filter(Boolean).join("|");
  return `  ${c.columnName} ${c.dataType} [${flags}]${dict ? ` -- ${dict.description}` : c.columnComment ? ` -- ${c.columnComment}` : ""}`;
}).join("\n")}

INDEXES: ${JSON.stringify(tableInfo?.indexesJson ?? [])}
FOREIGN KEYS: ${JSON.stringify(tableInfo?.foreignKeysJson ?? [])}

SELECTED COLUMNS: ${sel.columns.join(", ")}
`);
  }

  return parts.join("\n---\n");
}

/**
 * Find known relationships from FK graph for selected tables.
 */
function findKnownRelationships(
  selections: ColumnSelection[],
  sourceNames: Record<number, string>
): Array<{ from: string; to: string; edge: ReturnType<typeof buildRelationshipGraph>[0] }> {
  const allEdges = buildRelationshipGraph();
  const selectedTables = new Set(
    selections.map(s => `${sourceNames[s.sourceId]}.${s.schemaName}.${s.tableName}`)
  );

  return allEdges
    .filter(e => {
      const fromKey = `${e.fromSource}.${e.fromSchema}.${e.fromTable}`;
      const toKey = `${e.toSource}.${e.toSchema}.${e.toTable}`;
      return selectedTables.has(fromKey) && selectedTables.has(toKey);
    })
    .map(e => ({
      from: `${e.fromSource}.${e.fromSchema}.${e.fromTable}`,
      to: `${e.toSource}.${e.toSchema}.${e.toTable}`,
      edge: e,
    }));
}

/**
 * Call LLM to analyze schema and infer join conditions.
 */
async function callLLMForAnalysis(
  schemaContext: string,
  knownRelationships: ReturnType<typeof findKnownRelationships>,
  def: DatasetDefinition
): Promise<AIAnalysisResult> {
  const knownRelsText = knownRelationships.length > 0
    ? knownRelationships.map(r => `${r.from}.${r.edge.fromColumn} → ${r.to}.${r.edge.toColumn} (${r.edge.relationshipType}, confidence: ${r.edge.confidence})`).join("\n")
    : "None found in FK registry";

  const criteriaText = def.criteria?.length > 0
    ? def.criteria.map(c => `${c.schemaName}.${c.tableName}.${c.columnName} ${c.operator} ${JSON.stringify(c.value)}`).join("\n")
    : "No filter criteria defined";

  const prompt = `You are a senior database architect specializing in semiconductor manufacturing data systems.

Analyze the following database schema context and provide intelligent query design recommendations.

## Selected Tables and Schema Context:
${schemaContext}

## Known Relationships (from FK registry):
${knownRelsText}

## User-Defined Filter Criteria:
${criteriaText}

## Task:
The user wants to query data from the selected tables. Your job is to:
1. Identify the optimal JOIN conditions between tables (use FK relationships first, then infer from column names/types/business context)
2. Determine the best JOIN type (INNER/LEFT/RIGHT) based on business semantics
3. Identify performance risks (large tables, missing indexes, cross-DB joins)
4. Provide optimization recommendations
5. Describe the business context of this query

Return a JSON object with this exact schema:
{
  "joinSuggestions": [
    {
      "leftSchema": "string",
      "leftTable": "string", 
      "leftColumn": "string",
      "rightSchema": "string",
      "rightTable": "string",
      "rightColumn": "string",
      "joinType": "INNER" | "LEFT" | "RIGHT",
      "confidence": 0.0-1.0,
      "reasoning": "string explaining why this join is appropriate",
      "source": "foreign_key" | "naming_convention" | "ai_inferred",
      "performanceNote": "string or null"
    }
  ],
  "queryStrategy": "string describing overall query approach",
  "performanceWarnings": ["array of performance warning strings"],
  "optimizationTips": ["array of optimization tip strings"],
  "businessContext": "string describing what business question this query answers",
  "estimatedComplexity": "simple" | "moderate" | "complex" | "very_complex",
  "recommendedApproach": "string with recommended SQL approach"
}

Focus on:
- Using indexed columns for joins whenever possible
- Preferring INNER JOIN unless business logic requires LEFT JOIN
- Flagging large table joins (>1M rows) without proper filter predicates
- Identifying cross-schema or cross-database joins that require special handling
- Semiconductor manufacturing domain knowledge (wafer, lot, equipment relationships)`;

  try {
    const response = await invokeLLM({
      model: "gpt-5-mini",
      messages: [
        { role: "system", content: "You are a database architect expert. Always respond with valid JSON only." },
        { role: "user", content: prompt },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "ai_analysis_result",
          strict: true,
          schema: {
            type: "object",
            properties: {
              joinSuggestions: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    leftSchema: { type: "string" },
                    leftTable: { type: "string" },
                    leftColumn: { type: "string" },
                    rightSchema: { type: "string" },
                    rightTable: { type: "string" },
                    rightColumn: { type: "string" },
                    joinType: { type: "string" },
                    confidence: { type: "number" },
                    reasoning: { type: "string" },
                    source: { type: "string" },
                    performanceNote: { type: ["string", "null"] },
                  },
                  required: ["leftSchema","leftTable","leftColumn","rightSchema","rightTable","rightColumn","joinType","confidence","reasoning","source","performanceNote"],
                  additionalProperties: false,
                },
              },
              queryStrategy: { type: "string" },
              performanceWarnings: { type: "array", items: { type: "string" } },
              optimizationTips: { type: "array", items: { type: "string" } },
              businessContext: { type: "string" },
              estimatedComplexity: { type: "string" },
              recommendedApproach: { type: "string" },
            },
            required: ["joinSuggestions","queryStrategy","performanceWarnings","optimizationTips","businessContext","estimatedComplexity","recommendedApproach"],
            additionalProperties: false,
          },
        },
      } as any,
    });

    const content = response.choices[0]?.message?.content;
    const rawContent = content;
    const contentStr = typeof rawContent === "string" ? rawContent : JSON.stringify(rawContent);
    if (!content) throw new Error("Empty LLM response");
    return JSON.parse(contentStr) as AIAnalysisResult;
  } catch (err) {
    // Fallback: use FK-based analysis only
    console.error("[AI Engine] LLM call failed, using fallback:", err);
    return buildFallbackAnalysis(def);
  }
}

/**
 * Fallback analysis when LLM is unavailable.
 */
function buildFallbackAnalysis(def: DatasetDefinition): AIAnalysisResult {
  return {
    joinSuggestions: [],
    queryStrategy: "Using foreign key relationships only (AI analysis unavailable)",
    performanceWarnings: ["AI analysis unavailable — manual review recommended"],
    optimizationTips: ["Add filter criteria on indexed columns to improve performance"],
    businessContext: "Query across selected tables",
    estimatedComplexity: def.selections.length > 2 ? "complex" : "moderate",
    recommendedApproach: "Review join conditions manually before execution",
  };
}

/**
 * Build the final join path combining FK relationships and AI suggestions.
 * FK relationships take priority over AI inferred ones.
 */
function buildJoinPath(
  selections: ColumnSelection[],
  knownRelationships: ReturnType<typeof findKnownRelationships>,
  aiSuggestions: JoinSuggestion[]
): JoinSuggestion[] {
  const joins: JoinSuggestion[] = [];
  const covered = new Set<string>();

  // Priority 1: Use FK relationships
  for (const rel of knownRelationships) {
    const key = `${rel.edge.fromSchema}.${rel.edge.fromTable}→${rel.edge.toSchema}.${rel.edge.toTable}`;
    if (!covered.has(key)) {
      joins.push({
        leftSchema: rel.edge.fromSchema,
        leftTable: rel.edge.fromTable,
        leftColumn: rel.edge.fromColumn,
        rightSchema: rel.edge.toSchema,
        rightTable: rel.edge.toTable,
        rightColumn: rel.edge.toColumn,
        joinType: "INNER",
        confidence: rel.edge.confidence,
        reasoning: rel.edge.description,
        source: rel.edge.relationshipType === "foreign_key" ? "foreign_key" : "naming_convention",
      });
      covered.add(key);
    }
  }

  // Priority 2: Add AI suggestions for uncovered pairs
  for (const suggestion of aiSuggestions) {
    const key = `${suggestion.leftSchema}.${suggestion.leftTable}→${suggestion.rightSchema}.${suggestion.rightTable}`;
    const reverseKey = `${suggestion.rightSchema}.${suggestion.rightTable}→${suggestion.leftSchema}.${suggestion.leftTable}`;
    if (!covered.has(key) && !covered.has(reverseKey) && suggestion.confidence >= 0.6) {
      joins.push({ ...suggestion, source: "ai_inferred" });
      covered.add(key);
    }
  }

  return joins;
}

/**
 * Build the final parameterized SQL from selections, join path, and criteria.
 */
function buildSmartSql(
  def: DatasetDefinition,
  joinPath: JoinSuggestion[],
  dialect: string
): { sql: string; params: Record<string, unknown> } {
  const params: Record<string, unknown> = {};
  let paramIdx = 0;
  const nextParam = (val: unknown) => { const k = `p${++paramIdx}`; params[k] = val; return `:${k}`; };

  // SELECT clause
  const selectParts: string[] = [];
  for (const sel of def.selections) {
    for (const col of sel.columns) {
      selectParts.push(`${sel.schemaName}.${sel.tableName}.${col}`);
    }
  }

  // FROM clause (first table)
  const first = def.selections[0];
  let sql = `SELECT ${selectParts.join(",\n       ")}\nFROM   ${first.schemaName}.${first.tableName}`;

  // JOIN clauses from join path
  const usedTables = new Set([`${first.schemaName}.${first.tableName}`]);
  for (const join of joinPath) {
    const rightKey = `${join.rightSchema}.${join.rightTable}`;
    const leftKey = `${join.leftSchema}.${join.leftTable}`;
    // Determine which table is new (not yet in FROM)
    if (!usedTables.has(rightKey) && usedTables.has(leftKey)) {
      sql += `\n${join.joinType} JOIN ${rightKey}\n    ON ${leftKey}.${join.leftColumn} = ${rightKey}.${join.rightColumn}`;
      usedTables.add(rightKey);
    } else if (!usedTables.has(leftKey) && usedTables.has(rightKey)) {
      sql += `\n${join.joinType} JOIN ${leftKey}\n    ON ${rightKey}.${join.rightColumn} = ${leftKey}.${join.leftColumn}`;
      usedTables.add(leftKey);
    }
  }

  // Add any remaining selected tables not yet joined (cross join warning)
  for (const sel of def.selections) {
    const key = `${sel.schemaName}.${sel.tableName}`;
    if (!usedTables.has(key)) {
      sql += `\n-- WARNING: No join condition found for ${key}, adding as cross join\nCROSS JOIN ${key}`;
      usedTables.add(key);
    }
  }

  // WHERE clause
  const whereParts: string[] = [];
  for (const crit of (def.criteria || [])) {
    const col = `${crit.schemaName}.${crit.tableName}.${crit.columnName}`;
    switch (crit.operator) {
      case "eq":          whereParts.push(`${col} = ${nextParam(crit.value)}`); break;
      case "neq":         whereParts.push(`${col} != ${nextParam(crit.value)}`); break;
      case "gt":          whereParts.push(`${col} > ${nextParam(crit.value)}`); break;
      case "gte":         whereParts.push(`${col} >= ${nextParam(crit.value)}`); break;
      case "lt":          whereParts.push(`${col} < ${nextParam(crit.value)}`); break;
      case "lte":         whereParts.push(`${col} <= ${nextParam(crit.value)}`); break;
      case "like":        whereParts.push(`${col} LIKE ${nextParam(crit.value)}`); break;
      case "is_null":     whereParts.push(`${col} IS NULL`); break;
      case "is_not_null": whereParts.push(`${col} IS NOT NULL`); break;
      case "in": {
        const vals = Array.isArray(crit.value) ? crit.value : [crit.value];
        whereParts.push(`${col} IN (${vals.map(v => nextParam(v)).join(", ")})`);
        break;
      }
      case "between": {
        const vals = Array.isArray(crit.value) ? crit.value : [crit.value, crit.value];
        whereParts.push(`${col} BETWEEN ${nextParam(vals[0])} AND ${nextParam(vals[1])}`);
        break;
      }
    }
  }
  if (whereParts.length > 0) sql += `\nWHERE  ${whereParts.join("\n  AND  ")}`;

  // Add dialect-specific hints
  if (dialect === "oracle" && def.selections.some(s => s.columns.length > 10)) {
    sql = `/* Oracle hint: use parallel query for large result sets */\n${sql}`;
  }

  return { sql, params };
}

/**
 * Quick relationship lookup for a pair of tables (used by UI).
 */
export function getRelationshipsBetween(
  sourceNameA: string, schemaA: string, tableA: string,
  sourceNameB: string, schemaB: string, tableB: string
) {
  return buildRelationshipGraph().filter(e =>
    (e.fromSource === sourceNameA && e.fromSchema === schemaA && e.fromTable === tableA &&
     e.toSource === sourceNameB && e.toSchema === schemaB && e.toTable === tableB) ||
    (e.fromSource === sourceNameB && e.fromSchema === schemaB && e.fromTable === tableB &&
     e.toSource === sourceNameA && e.toSchema === schemaA && e.toTable === tableA)
  );
}
