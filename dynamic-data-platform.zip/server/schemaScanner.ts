/**
 * Schema Scanner Service
 * Scans Mock DB scenarios (simulating real DB introspection) and populates
 * the schema cache with full metadata: tables, columns, indexes, foreign keys.
 * In production, replace getMockDataSource() calls with actual DB driver queries.
 */
import {
  getMockDataSource, getMockSchema, buildRelationshipGraph,
  type MockTable, type MockColumn, type MockIndex, type MockForeignKey,
} from "./mockDb/scenarios";
import {
  clearSchemaCache, upsertCacheTable, upsertCacheColumn,
  getDataSourceById, getSchemasBySourceId, insertAuditLog,
} from "./db";
import { getDb } from "./db";
import { schemaRelationships } from "../drizzle/schema";

export interface ScanResult {
  sourceName: string;
  schemaName: string;
  tablesScanned: number;
  columnsScanned: number;
  indexesFound: number;
  foreignKeysFound: number;
  durationMs: number;
  errors: string[];
}

/**
 * Scan a specific schema and populate the cache.
 * Simulates: INFORMATION_SCHEMA queries, ALL_TABLES/ALL_COLUMNS (Oracle),
 * pg_catalog queries (PostgreSQL/GreenPlum).
 */
export async function scanSchema(
  sourceId: number,
  schemaName: string,
  userId: number
): Promise<ScanResult> {
  const startTime = Date.now();
  const errors: string[] = [];

  const source = await getDataSourceById(sourceId);
  if (!source) throw new Error(`Source ${sourceId} not found`);

  const mockSource = getMockDataSource(source.name);
  if (!mockSource) {
    // Fallback: generate generic schema for unknown sources
    errors.push(`No mock scenario for source '${source.name}' — using generic schema`);
    return generateGenericSchema(sourceId, schemaName, source.name, userId, startTime, errors);
  }

  const mockSchema = mockSource.schemas.find(s => s.schemaName === schemaName);
  if (!mockSchema) {
    errors.push(`Schema '${schemaName}' not found in mock source '${source.name}'`);
    return { sourceName: source.name, schemaName, tablesScanned: 0, columnsScanned: 0, indexesFound: 0, foreignKeysFound: 0, durationMs: Date.now() - startTime, errors };
  }

  // Clear existing cache for this schema
  await clearSchemaCache(sourceId, schemaName);

  let tablesScanned = 0;
  let columnsScanned = 0;
  let indexesFound = 0;
  let foreignKeysFound = 0;

  for (const table of mockSchema.tables) {
    // Upsert table metadata
    await upsertCacheTable({
      sourceId,
      schemaName,
      tableName: table.tableName,
      approxRowCount: table.approxRowCount,
      tableComment: table.comment,
      partitionKey: table.partitionKey,
      businessDomain: table.businessDomain,
      indexesJson: table.indexes,
      foreignKeysJson: table.foreignKeys,
    });
    tablesScanned++;
    indexesFound += table.indexes.length;
    foreignKeysFound += table.foreignKeys.length;

    // Upsert column metadata
    for (const col of table.columns) {
      await upsertCacheColumn({
        sourceId,
        schemaName,
        tableName: table.tableName,
        columnName: col.columnName,
        dataType: col.dataType,
        isKey: col.isKey,
        isIndexed: col.isIndexed,
        isNullable: col.isNullable,
        ordinalPosition: col.ordinalPosition,
        defaultValue: col.defaultValue,
        columnComment: col.comment,
      });
      columnsScanned++;
    }
  }

  // Store cross-table relationship edges
  await syncRelationships(sourceId, schemaName, source.name);

  await insertAuditLog({
    userId,
    sourceId,
    action: "schema_scan",
    executedAt: new Date(),
  });

  return {
    sourceName: source.name,
    schemaName,
    tablesScanned,
    columnsScanned,
    indexesFound,
    foreignKeysFound,
    durationMs: Date.now() - startTime,
    errors,
  };
}

/**
 * Scan all schemas registered for a source.
 */
export async function scanAllSchemas(sourceId: number, userId: number): Promise<ScanResult[]> {
  const schemas = await getSchemasBySourceId(sourceId);
  const results: ScanResult[] = [];
  for (const schema of schemas) {
    const result = await scanSchema(sourceId, schema.schemaName, userId);
    results.push(result);
  }
  return results;
}

/**
 * Sync relationship graph for a source/schema into DB.
 */
async function syncRelationships(sourceId: number, schemaName: string, sourceName: string) {
  const db = await getDb();
  if (!db) return;

  const allEdges = buildRelationshipGraph();
  const relevantEdges = allEdges.filter(e =>
    (e.fromSource === sourceName && e.fromSchema === schemaName) ||
    (e.toSource === sourceName && e.toSchema === schemaName)
  );

  for (const edge of relevantEdges) {
    try {
      await db.insert(schemaRelationships).values({
        fromSourceName: edge.fromSource,
        fromSchema: edge.fromSchema,
        fromTable: edge.fromTable,
        fromColumn: edge.fromColumn,
        toSourceName: edge.toSource,
        toSchema: edge.toSchema,
        toTable: edge.toTable,
        toColumn: edge.toColumn,
        relationshipType: edge.relationshipType,
        confidence: String(edge.confidence),
        description: edge.description,
      }).onDuplicateKeyUpdate({
        set: { confidence: String(edge.confidence), description: edge.description },
      });
    } catch {
      // Ignore duplicate key errors
    }
  }
}

async function generateGenericSchema(
  sourceId: number, schemaName: string, sourceName: string,
  userId: number, startTime: number, errors: string[]
): Promise<ScanResult> {
  await clearSchemaCache(sourceId, schemaName);
  const genericTables = [
    { name: `${schemaName}_MASTER`, rowCount: 10000 },
    { name: `${schemaName}_DETAIL`, rowCount: 100000 },
    { name: `${schemaName}_LOG`, rowCount: 500000 },
  ];
  for (const t of genericTables) {
    await upsertCacheTable({ sourceId, schemaName, tableName: t.name, approxRowCount: t.rowCount });
    await upsertCacheColumn({ sourceId, schemaName, tableName: t.name, columnName: "ID", dataType: "NUMBER(18)", isKey: true, isIndexed: true, isNullable: false, ordinalPosition: 1 });
    await upsertCacheColumn({ sourceId, schemaName, tableName: t.name, columnName: "NAME", dataType: "VARCHAR2(128)", isKey: false, isIndexed: false, isNullable: true, ordinalPosition: 2 });
    await upsertCacheColumn({ sourceId, schemaName, tableName: t.name, columnName: "CREATED_AT", dataType: "DATE", isKey: false, isIndexed: true, isNullable: false, ordinalPosition: 3 });
  }
  return { sourceName, schemaName, tablesScanned: genericTables.length, columnsScanned: genericTables.length * 3, indexesFound: 0, foreignKeysFound: 0, durationMs: Date.now() - startTime, errors };
}
