import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { createSessionToken, hashPassword, normalizeEmail, verifyPassword } from "./_core/localAuth";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { createLocalUser, getLocalUserByEmail, toPublicUser, updateLocalUserLastSignedIn } from "./db";
import { sourcesRouter } from "./routers/sources";
import { dictionaryRouter } from "./routers/dictionary";
import { permissionsRouter } from "./routers/permissions";
import { datasetsRouter } from "./routers/datasets";
import { schemaRouter } from "./routers/schema";
import { fabDataRouter } from "./routers/fabData";
import { fabDatasetRouter } from "./routers/fabDataset";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(({ ctx }) => (ctx.user ? toPublicUser(ctx.user) : null)),
    register: publicProcedure.input(z.object({
      name: z.string().trim().min(2).max(120),
      email: z.string().trim().email().max(320),
      password: z.string().min(12).max(128),
    })).mutation(async ({ input, ctx }) => {
      const email = normalizeEmail(input.email);
      if (await getLocalUserByEmail(email)) {
        throw new TRPCError({ code: "CONFLICT", message: "An account already exists for this email address" });
      }
      try {
        const user = await createLocalUser({
          name: input.name,
          email,
          passwordHash: await hashPassword(input.password),
        });
        const token = await createSessionToken(user);
        ctx.res.cookie(COOKIE_NAME, token, {
          ...getSessionCookieOptions(ctx.req),
          maxAge: 8 * 60 * 60 * 1000,
        });
        return { user: toPublicUser(user), firstLocalAdmin: user.role === "admin" };
      } catch (error) {
        if (error instanceof Error && error.message === "LOCAL_USER_EXISTS") {
          throw new TRPCError({ code: "CONFLICT", message: "An account already exists for this email address" });
        }
        if (error instanceof Error && error.message.startsWith("Password")) {
          throw new TRPCError({ code: "BAD_REQUEST", message: error.message });
        }
        throw error;
      }
    }),
    login: publicProcedure.input(z.object({
      email: z.string().trim().email().max(320),
      password: z.string().min(1).max(128),
    })).mutation(async ({ input, ctx }) => {
      const user = await getLocalUserByEmail(normalizeEmail(input.email));
      const valid = await verifyPassword(input.password, user?.passwordHash ?? null);
      if (!user || !valid) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid email address or password" });
      }
      await updateLocalUserLastSignedIn(user.id);
      const token = await createSessionToken(user);
      ctx.res.cookie(COOKIE_NAME, token, {
        ...getSessionCookieOptions(ctx.req),
        maxAge: 8 * 60 * 60 * 1000,
      });
      return { user: toPublicUser(user) };
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  sources: sourcesRouter,
  dictionary: dictionaryRouter,
  permissions: permissionsRouter,
  datasets: datasetsRouter,
  schema: schemaRouter,
  fabData: fabDataRouter,
  fabDataset: fabDatasetRouter,
});

export type AppRouter = typeof appRouter;
