import { afterAll, afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { TRPCError } from "@trpc/server";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import { authenticateRequest, assertStrongPassword, createSessionToken, hashPassword, normalizeEmail, verifyPassword, verifySessionToken } from "./_core/localAuth";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

describe("local JWT credential primitives", () => {
  it("normalizes local account email addresses", () => {
    expect(normalizeEmail("  Engineer@Example.COM ")).toBe("engineer@example.com");
  });

  it("stores a non-reversible scrypt password hash and verifies the correct password", async () => {
    const password = "StrongPassword2026";
    const hash = await hashPassword(password);

    expect(hash).toMatch(/^scrypt\$[a-f0-9]+\$[a-f0-9]+$/);
    expect(hash).not.toContain(password);
    await expect(verifyPassword(password, hash)).resolves.toBe(true);
    await expect(verifyPassword("WrongPassword2026", hash)).resolves.toBe(false);
  });

  it("rejects weak local account passwords", () => {
    expect(() => assertStrongPassword("short1")).toThrow("12 to 128");
    expect(() => assertStrongPassword("abcdefghijkl")).toThrow("letter and one number");
    expect(() => assertStrongPassword("123456789012")).toThrow("letter and one number");
  });
});

const jwtUser = {
  id: 42,
  openId: "local:jwt@example.com",
  email: "jwt@example.com",
  name: "JWT Engineer",
  loginMethod: "local_jwt",
  passwordHash: "scrypt$test$hash",
  role: "admin" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

const originalJwtSecret = process.env.JWT_SECRET;

beforeAll(() => {
  process.env.JWT_SECRET = "ddop-platform-secret-22";
});

afterAll(() => {
  if (originalJwtSecret === undefined) delete process.env.JWT_SECRET;
  else process.env.JWT_SECRET = originalJwtSecret;
});

describe("local JWT session lifecycle", () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("issues and validates an HTTP-only-cookie-compatible JWT payload", async () => {
    const token = await createSessionToken(jwtUser);
    const payload = await verifySessionToken(token);

    expect(token.split(".")).toHaveLength(3);
    expect(payload).toEqual({ userId: 42, email: "jwt@example.com", role: "admin" });
  });

  it("rejects malformed and tampered JWT values", async () => {
    expect(await verifySessionToken("not-a-jwt")).toBeNull();
    const token = await createSessionToken(jwtUser);
    expect(await verifySessionToken(`${token}tampered`)).toBeNull();
  });

  it("resolves the local account from a validated request cookie", async () => {
    const token = await createSessionToken(jwtUser);
    vi.spyOn(db, "getUserById").mockResolvedValue(jwtUser);
    const request = { headers: { cookie: `${COOKIE_NAME}=${token}` } } as any;

    await expect(authenticateRequest(request)).resolves.toEqual(jwtUser);
    expect(db.getUserById).toHaveBeenCalledWith(42);
  });
});

function createUserContext(role: "user" | "admin"): TrpcContext {
  const now = new Date();
  return {
    user: {
      id: 77,
      openId: "local:test@example.com",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "local_jwt",
      passwordHash: "scrypt$test$hash",
      role,
      createdAt: now,
      updatedAt: now,
      lastSignedIn: now,
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("local JWT RBAC", () => {
  it("rejects an ordinary local user from the administration router", async () => {
    const caller = appRouter.createCaller(createUserContext("user"));
    await expect(caller.permissions.listUsers()).rejects.toMatchObject<Partial<TRPCError>>({
      code: "FORBIDDEN",
    });
  });
});
