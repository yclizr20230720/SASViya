# Dynamic Data Object Platform - TODO

## Phase 1: Database Schema & Infrastructure
- [x] Extend drizzle schema: dataSources, dataSourceSchemas, schemaCacheTables, schemaCacheColumns
- [x] Extend drizzle schema: dictionaryEntries, datasetDrafts, queryAuditLog, sourcePermissions
- [x] Run migration and apply SQL
- [x] Seed initial data sources (F12PEDA, F12PMES, f12edagp) with schemas

## Phase 2: Backend tRPC Routes - Auth & Sources
- [x] Auth routes: login, logout, me (with role-based access via Manus OAuth)
- [x] Admin: data source CRUD (sources router)
- [x] Admin: schema registration per source (addSchema, removeSchema)
- [x] Admin: user permission management (permissions router)
- [x] Schema service: list sources, schemas, tables, columns (from cache)
- [x] Schema service: refresh-metadata endpoint (demo introspection with representative data)
- [x] Data Dictionary: import entries (bulk and single upsert)
- [x] Data Dictionary: merge descriptions into schema responses

## Phase 3: Backend tRPC Routes - Dataset & SQL Engine
- [x] Dataset draft CRUD (create, read, patch, delete)
- [x] Requirement items management within draft
- [x] Source Matcher: token-overlap-based column candidate matching
- [x] Query Builder: parameterized SQL generation from draft selections/joins/criteria
- [x] Performance Evaluator: static index check, row-count threshold check
- [x] Execution Engine: preview (100 rows, mock execution)
- [x] Execution Engine: full async execution with mock result
- [x] Concurrency limit check (per user)
- [x] Audit log: write evaluation results and execution records

## Phase 4: Frontend - Layout & Schema Browser
- [x] App layout with dark sidebar + light main content
- [x] Login/auth gate page (Sign In button)
- [x] Home/Dashboard page with real-time stats
- [x] Schema Browser page (/sources): 3-panel source/schema/column tree
- [x] Refresh metadata button (admin only)
- [x] Data Dictionary display integrated in column list

## Phase 5: Frontend - Dataset Wizard
- [x] Dataset list page with create dialog
- [x] Column Selection page (/datasets/:id/columns) with multi-table support
- [x] Join specification UI for multi-table selections
- [x] Requirement Description page (/datasets/:id/requirement)
- [x] Filter Criteria page (/datasets/:id/criteria) with type-aware operators
- [x] WizardSteps progress indicator component

## Phase 6: Frontend - SQL Review & Execution
- [x] SQL Review page (/datasets/:id/review): SQL display, verdict banner (pass/warn/block)
- [x] Performance block/warn UI with acknowledgment checkbox
- [x] Preview page (/datasets/:id/preview): 100-row results table
- [x] Execute page (/datasets/:id/execute): job execution, summary, download buttons
- [x] Admin: Sources management page (/admin/sources) with schema management
- [x] Admin: Dictionary import page (/admin/dictionary) with bulk import
- [x] Admin: User permissions page (/admin/users) with per-source RBAC
- [x] Admin: Audit log page (/admin/audit) with filtering

## Phase 7: Testing & Polish
  - [x] Dark/Light theme toggle (sidebar footer button)
  - [x] TypeScript errors resolved (0 errors)
  - [x] React hooks rules compliance (no conditional hooks)
  - [x] Vitest unit tests for query builder logic (15 tests passing)
  - [x] Vitest tests for performance evaluator (pass/warn/block scenarios)
  - [x] Vitest tests for source matcher (tokenOverlapScore)
  - [x] Responsive design verification on mobile

## Phase 8: AI Intelligence Engine
- [x] Mock DB scenarios engine (F12PEDA Oracle, F12PMES Oracle, f12edagp GreenPlum) with full schema, indexes, FK
- [x] Schema Scanner API (scan all tables/columns/indexes/FK into cache with rich metadata)
- [x] LLM AI Analysis Engine (join inference, business context, optimization tips via gpt-5-mini)
- [x] Smart SQL Generation Engine (auto join path, FK-first + AI-inferred fallback)
- [x] Advanced Performance Evaluator (cross-DB join, partition scan, no-indexed-filter checks)
- [x] schemaRelationships DB table migration applied
- [x] EvaluationFinding type extended (cross_db_join, partition_scan, no_indexed_filter)
- [x] DatasetDefinition extended (aiAnalysis, joinPath fields)
- [x] Schema Intelligence admin page (scanner, relationships, mock scenarios)
- [x] Smart SQL Review page (/datasets/:id/smart-sql) with AI analysis display
- [x] Join path visualization (FK/AI/naming source badges, confidence scores)
- [x] Admin sidebar: Schema Intelligence nav item added

## Phase 9: Self-Contained JWT Authorization
- [x] Replace Manus OAuth session handling with local JWT login, logout, and current-user endpoints
- [x] Add account registration and secure password-hash persistence for local DDOP users
- [x] Preserve admin/user RBAC and source-permission checks under JWT authentication
- [x] Replace the Manus login experience with a responsive local DDOP sign-in and registration interface
- [x] Add Vitest coverage for authentication, token validation, and role enforcement
- [x] Verify the protected Dataset Wizard and admin routes after removing Manus OAuth dependency
- [x] Add JWT issuance, validation, invalid-token, and request-authentication tests
- [x] Verify local JWT sessions against protected Dataset Wizard, admin RBAC, and source-permission routes
- [x] Add local JWT integration coverage for source-permission allow and deny behavior
