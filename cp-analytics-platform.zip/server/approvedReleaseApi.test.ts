import { describe, expect, it } from "vitest";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";

type WaferPayload = {
  release: { key: string; status: string; snapshotHash: string };
  wafers: Array<{ lotId: string; waferId: string; yield: number; scenario: string }>;
};

describe("approved-release wafer API", () => {
  it("returns only the reconciled CP development release and excludes quarantined source data", async () => {
    const response = await fetch(`${baseUrl}/api/v1/releases/approved/wafers?releaseKey=CPDEV-20260823-R1`);
    const payload = (await response.json()) as WaferPayload;

    expect(response.status).toBe(200);
    expect(payload.release.key).toBe("CPDEV-20260823-R1");
    expect(["approved", "analytics_ready"]).toContain(payload.release.status);
    expect(payload.release.snapshotHash).toHaveLength(64);
    expect(payload.wafers).toHaveLength(9);
    expect(payload.wafers.every((wafer) => wafer.lotId !== "CPDEV999")).toBe(true);
    expect(payload.wafers.some((wafer) => wafer.scenario === "parameter_shift" && wafer.yield === 0.8)).toBe(true);
  }, 15_000);

  it("rejects a real rejected release from the development database", async () => {
    const response = await fetch(`${baseUrl}/api/v1/releases/approved/wafers?releaseKey=CPDEV-20260823-R0`);
    const payload = (await response.json()) as { error: string };

    expect(response.status).toBe(404);
    expect(payload.error).toBe("approved_release_not_found");
  }, 15_000);
});
