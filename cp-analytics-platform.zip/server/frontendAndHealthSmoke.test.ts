import { describe, expect, it } from "vitest";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";

describe("Flask-served CP application smoke test", () => {
  it("serves the React shell and reports an enabled approved-release health gate", async () => {
    const [homeResponse, healthResponse] = await Promise.all([
      fetch(`${baseUrl}/`),
      fetch(`${baseUrl}/api/v1/health/ready`),
    ]);
    const health = (await healthResponse.json()) as { status: string; checks: { approved_release_gate: string; database_target: string } };
    const homeHtml = await homeResponse.text();

    expect(homeResponse.status).toBe(200);
    expect(homeHtml).toContain("VEDA CP Analytics");
    expect(healthResponse.status).toBe(200);
    expect(health.status).toBe("ready");
    expect(health.checks.approved_release_gate).toBe("enabled");
    expect(health.checks.database_target).toBe("builtin_mysql");
  }, 15_000);
});
