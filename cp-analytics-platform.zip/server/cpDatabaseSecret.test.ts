import { describe, expect, it } from "vitest";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";

describe("configured CP development database", () => {
  it("passes the Flask database-backed readiness endpoint without revealing credentials", async () => {
    const response = await fetch(`${baseUrl}/api/v1/health/ready`);
    const body = (await response.json()) as {
      status: string;
      checks: { postgresql: string; approved_release_gate: string };
    };

    expect(response.status).toBe(200);
    expect(body.status).toBe("ready");
    expect(body.checks.postgresql).toBe("mysql_compatible_reachable");
    expect(body.checks.database_target).toBe("builtin_mysql");
    expect(body.checks.approved_release_gate).toBe("enabled");
    expect(JSON.stringify(body)).not.toContain("postgresql+");
  });
});
