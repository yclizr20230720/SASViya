import { chromium } from "@playwright/test";
import { describe, expect, it } from "vitest";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";
const releaseKey = "CPSYNCSV-EE48DB6DF97E-R1";

describe("CSV-profiled CP database workspace", () => {
  it("selects the explicitly synthetic release and renders database-backed evidence across the analysis workspaces", async () => {
    const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
    try {
      const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
      await page.goto(`${baseUrl}/query`, { waitUntil: "domcontentloaded" });
      await page.getByRole("heading", { name: "Define analysis dataset" }).waitFor();
      await page.getByLabel("Query source release").selectOption(releaseKey);
      await page.getByRole("button", { name: "Execute query" }).click();
      await page.getByText(/Showing 20 of 20 matching wafer-level records/).waitFor({ timeout: 25_000 });
      await page.getByRole("button", { name: "Approved Wafers" }).click();
      await page.getByRole("heading", { name: "CP analysis console" }).waitFor();

      await page.getByText("Applied-cohort engineering signal", { exact: true }).waitFor();
      await page.getByText("Observed release yield by measured date", { exact: true }).waitFor();
      await page.getByText("Wafers with the largest observed die loss", { exact: true }).waitFor();
      await page.locator(".product-wafer-preview").first().waitFor({ timeout: 25_000 });
      expect(await page.locator(".product-wafer-preview").count()).toBeGreaterThan(0);
      await page.getByRole("button", { name: /inspect representative/ }).first().click();
      await page.getByText("300 MM DIE GRID", { exact: true }).waitFor({ timeout: 25_000 });
      await page.getByRole("button", { name: "CP row review" }).click();

      await page.getByText("Screen approved wafer records", { exact: true }).waitFor();
      await page.getByText("20 wafers in active cohort", { exact: true }).waitFor();
      await page.getByRole("button", { name: "Yield & bin summary" }).click();
      await page.getByText("Ranked wafer yield · select an outlier to inspect its map", { exact: true }).waitFor();
      await page.getByText("Release bin distribution", { exact: true }).waitFor();

      await page.getByRole("button", { name: "Parameter statistics" }).click();
      await page.getByText("Approved distribution and limits", { exact: true }).waitFor({ timeout: 25_000 });
      await page.getByLabel("Parameter selector").selectOption("CSVPROF_VTH");
      expect(await page.getByLabel("Parameter selector").inputValue()).toBe("CSVPROF_VTH");
      await page.getByRole("button", { name: "Spatial wafer maps" }).click();
      await page.getByText("300 MM DIE GRID", { exact: true }).waitFor({ timeout: 25_000 });
      await page.getByLabel("Wafer map view").selectOption("parameter");
      await page.getByLabel("Wafer map parameter").selectOption("CSVPROF_VTH");
      await page.getByText(/88 measured dies/).waitFor({ timeout: 25_000 });
      expect(await page.getByText("CSVPROF_VTH", { exact: true }).count()).toBeGreaterThan(0);
      await page.getByRole("button", { name: "Set reference" }).first().click();
      await page.getByText("WAFER COMPARISON", { exact: true }).waitFor();
      await page.getByText("Approved bin-map mosaic and wafer loss review", { exact: true }).waitFor({ timeout: 25_000 });
      await page.getByLabel("Mosaic lot selector").selectOption({ index: 1 });
      await page.locator(".lot-mosaic-wafer").first().waitFor({ timeout: 25_000 });
      expect(await page.locator(".lot-mosaic-wafer").count()).toBeGreaterThan(0);
      await page.getByRole("button", { name: /Inspect mosaic wafer/ }).first().click();
      await page.getByText("300 MM DIE GRID", { exact: true }).waitFor({ timeout: 25_000 });

      await page.getByRole("button", { name: "Lot & trend monitoring" }).click();
      await page.getByText("Weighted yield by measured date", { exact: true }).waitFor();
      await page.getByText("Trend evidence available", { exact: true }).waitFor();
      await page.getByRole("button", { name: "Tester / probe health" }).click();
      await page.getByText("Yield by tester", { exact: true }).waitFor();
      await page.getByText("Yield by probe card", { exact: true }).waitFor();
    } finally {
      await browser.close();
    }
  }, 90_000);
});
