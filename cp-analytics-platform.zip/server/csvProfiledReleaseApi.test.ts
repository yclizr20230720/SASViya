import { describe, expect, it } from "vitest";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";
const releaseKey = "CPSYNCSV-EE48DB6DF97E-R1";

describe("CSV-profiled CP database release", () => {
  it("serves traceable database-backed cohort, statistics, filters, and parameter map evidence", async () => {
    const [catalogResponse, overviewResponse, filteredResponse, engineeringResponse, filtersResponse, mapReadyResponse, mosaicResponse] = await Promise.all([
      fetch(`${baseUrl}/api/v1/releases/approved/catalog`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/overview?releaseKey=${releaseKey}`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/overview?releaseKey=${releaseKey}&part=TM1234`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/engineering?releaseKey=${releaseKey}`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/filters?releaseKey=${releaseKey}`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/map-ready?releaseKey=${releaseKey}`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/lot-mosaic?releaseKey=${releaseKey}&limit=12`),
    ]);
    const catalog = (await catalogResponse.json()) as { releases: Array<{ key: string; provenance: string; label: string; waferCount: number }> };
    const overview = (await overviewResponse.json()) as { release: { key: string; status: string }; summary: { waferCount: number; testedDie: number; goodDie: number }; selection: { lotCount: number }; yieldByWafer: Array<{ waferId: string; waferKey: number; yield: number }>; binDistribution: Array<{ softBin: number; dieCount: number }> };
    const filtered = (await filteredResponse.json()) as { summary: { waferCount: number }; selection: { filters: Record<string, string[]> } };
    const engineering = (await engineeringResponse.json()) as { parameters: Array<{ code: string; sampleCount: number; lowerLimit: number | null; upperLimit: number | null }>; parameterScatter: Array<{ xCode: string; yCode: string; sampleCount: number }>; trend: Array<{ period: string; yield: number; adjacentYieldDelta: number | null; representativeWaferKey: number | null }>; yieldDimensions: { byTester: Array<{ value: string; waferCount: number }>; byProbeCard: Array<{ value: string; waferCount: number }> }; availability: { parameterStatistics: boolean; specificationLimits: boolean } };
    const filters = (await filtersResponse.json()) as { fields: { part: Array<{ value: string }>; testEqpid: Array<{ value: string }>; cpProbecard: Array<{ value: string }> } };
    const mapReady = (await mapReadyResponse.json()) as { coverage: { scopedWaferCount: number }; mapReadyWafers: Array<{ waferKey: number }> };
    const mosaic = (await mosaicResponse.json()) as { coverage: { scopedWaferCount: number; mapReadyWaferCount: number; totalMosaicCandidates: number; returnedWaferCount: number }; pagination: { limit: number; hasMore: boolean }; lots: Array<{ lotId: string; mapReadyWaferCount: number }>; wafers: Array<{ waferKey: number; lotId: string; yield: number; testedDie: number; goodDie: number; lossDie: number; previewDies: Array<{ x: number; y: number }> }> };

    expect(catalogResponse.status).toBe(200);
    expect(catalog.releases).toContainEqual(expect.objectContaining({ key: releaseKey, provenance: "simulated_csv_profiled", waferCount: 20 }));
    expect(overviewResponse.status).toBe(200);
    expect(overview.release).toMatchObject({ key: releaseKey, status: "analytics_ready" });
    expect(overview.summary).toMatchObject({ waferCount: 20, testedDie: 1760 });
    expect(overview.selection.lotCount).toBe(5);
    expect(overview.binDistribution.some((bin) => bin.softBin === 1 && bin.dieCount > 0)).toBe(true);
    expect(filtered.summary.waferCount).toBe(4);
    expect(filtered.selection.filters).toMatchObject({ part: ["TM1234"] });
    expect(engineering.availability).toMatchObject({ parameterStatistics: true, specificationLimits: true });
    expect(engineering.parameters).toEqual(expect.arrayContaining([expect.objectContaining({ code: "CSVPROF_VTH", sampleCount: 1760, lowerLimit: 4, upperLimit: 6 }), expect.objectContaining({ code: "CSVPROF_IDDQ" }), expect.objectContaining({ code: "CSVPROF_RON" })]));
    expect(engineering.parameterScatter.some((pair) => pair.xCode === "CSVPROF_IDDQ" && pair.yCode === "CSVPROF_VTH" && pair.sampleCount === 1760)).toBe(true);
    expect(engineering.yieldDimensions.byTester.length).toBeGreaterThan(1);
    expect(engineering.yieldDimensions.byProbeCard.length).toBeGreaterThan(1);
    expect(engineering.trend.map((point) => point.period)).toEqual([...engineering.trend.map((point) => point.period)].sort());
    expect(engineering.trend.every((point) => point.representativeWaferKey !== null && overview.yieldByWafer.some((wafer) => wafer.waferKey === point.representativeWaferKey))).toBe(true);
    expect(engineering.trend[0]?.adjacentYieldDelta).toBeNull();
    engineering.trend.slice(1).forEach((point, index) => expect(point.adjacentYieldDelta).toBeCloseTo(point.yield - engineering.trend[index].yield, 12));
    expect([...overview.yieldByWafer].sort((left, right) => left.yield - right.yield)[0].yield).toBe(Math.min(...overview.yieldByWafer.map((wafer) => wafer.yield)));
    expect(mapReady.coverage.scopedWaferCount).toBe(overview.summary.waferCount);
    expect(mapReady.mapReadyWafers.every((wafer) => overview.yieldByWafer.some((candidate) => candidate.waferKey === wafer.waferKey))).toBe(true);
    expect(mosaic.coverage.scopedWaferCount).toBe(overview.summary.waferCount);
    expect(mosaic.coverage.mapReadyWaferCount).toBe(mapReady.mapReadyWafers.length);
    expect(mosaic.pagination.limit).toBe(12);
    expect(mosaic.coverage.returnedWaferCount).toBe(mosaic.wafers.length);
    expect(mosaic.lots.map((lot) => lot.lotId)).toEqual([...mosaic.lots.map((lot) => lot.lotId)].sort());
    expect(mosaic.wafers.every((wafer) => overview.yieldByWafer.some((candidate) => candidate.waferKey === wafer.waferKey) && wafer.lossDie === wafer.testedDie - wafer.goodDie && wafer.previewDies.length > 0)).toBe(true);
    expect(filters.fields.part.map((field) => field.value)).toEqual(expect.arrayContaining(["TM1234", "TMUW83", "TMVB24"]));
    expect(filters.fields.testEqpid.length).toBeGreaterThan(1);
    expect(filters.fields.cpProbecard.length).toBeGreaterThan(1);

    const selectedWafer = overview.yieldByWafer[0];
    const mapResponse = await fetch(`${baseUrl}/api/v1/releases/approved/analysis/wafer-map/${encodeURIComponent(selectedWafer.waferId)}?releaseKey=${releaseKey}&waferKey=${selectedWafer.waferKey}&parameterCode=CSVPROF_VTH`);
    const map = (await mapResponse.json()) as { mapAvailable: boolean; parameter: { code: string; measuredDieCount: number } | null; geometry: { grossDie: number; coverage: number }; dies: Array<{ measuredValue: number | null }> };
    expect(mapResponse.status).toBe(200);
    expect(map.mapAvailable).toBe(true);
    expect(map.parameter).toMatchObject({ code: "CSVPROF_VTH", measuredDieCount: 88 });
    expect(map.geometry).toMatchObject({ grossDie: 88, coverage: 1 });
    expect(map.dies).toHaveLength(88);
    expect(map.dies.every((die) => typeof die.measuredValue === "number")).toBe(true);
  }, 30_000);
});
