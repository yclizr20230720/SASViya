import { describe, expect, it } from "vitest";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";

describe("approved CP analysis APIs", () => {
  it("returns a bounded approved query review and a matching downloadable CSV export", async () => {
    const queryUrl = `${baseUrl}/api/v1/releases/approved/analysis/query-rows?releaseKey=CPSYNCSV-EE48DB6DF97E-R1&part6=TMUW83&limit=100`;
    const [reviewResponse, csvResponse] = await Promise.all([
      fetch(queryUrl),
      fetch(`${queryUrl}&format=csv&limit=10000`),
    ]);
    const review = (await reviewResponse.json()) as { release: { key: string; status: string }; selection: { filters: Record<string, string[]>; totalRowCount: number; returnedRowCount: number; reviewLimit: number; semantics: { scope: string } }; rows: Array<{ waferKey: number; lotId: string; waferId: string; testedDie: number; yield: number; materializationHash: string }> };

    expect(reviewResponse.status).toBe(200);
    expect(review.release).toMatchObject({ key: "CPSYNCSV-EE48DB6DF97E-R1", status: "analytics_ready" });
    expect(review.selection).toMatchObject({ filters: { part6: ["TMUW83"] }, reviewLimit: 100, semantics: { scope: "approved_release_only" } });
    expect(review.selection.returnedRowCount).toBeLessThanOrEqual(100);
    expect(review.selection.returnedRowCount).toBe(review.rows.length);
    expect(review.rows.every((row) => Number.isInteger(row.waferKey) && row.testedDie > 0 && row.yield >= 0 && row.yield <= 1 && row.materializationHash.length === 64)).toBe(true);
    expect(csvResponse.status).toBe(200);
    expect(csvResponse.headers.get("content-type")).toContain("text/csv");
    expect(csvResponse.headers.get("content-disposition")).toContain("attachment;");
    expect(csvResponse.headers.get("x-cp-query-scope")).toBe("approved_release_only");
    expect(await csvResponse.text()).toContain("part6");
  }, 15_000);

  it("returns approved yield/bin analytics and bounded die-level map evidence", async () => {
    const [overviewResponse, engineeringResponse, engineeringFilteredResponse, fixtureEngineeringResponse, mapResponse, rawGridResponse, mapReadyResponse, rejectedResponse] = await Promise.all([
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/overview?releaseKey=CPDEV-20260823-R1`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/engineering?releaseKey=CPREAL-EE48DB6DF97E-R5`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/engineering?releaseKey=CPREAL-EE48DB6DF97E-R5&part6=TMUW83`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/engineering?releaseKey=CPDEV-20260823-R1`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/wafer-map/CPDEV204-01?releaseKey=CPDEV-20260823-R1&parameterCode=CP_PARAM_001`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/wafer-map/FFR123.06?releaseKey=CPREAL-EE48DB6DF97E-R5`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/map-ready?releaseKey=CPREAL-EE48DB6DF97E-R5`),
      fetch(`${baseUrl}/api/v1/releases/approved/analysis/overview?releaseKey=CPDEV-20260823-R0`),
    ]);
    const overview = (await overviewResponse.json()) as { release: { key: string }; summary: { waferCount: number; belowTargetCount: number }; binDistribution: unknown[] };
    const engineering = (await engineeringResponse.json()) as { release: { key: string; status: string }; yieldDimensions: { byTester: Array<{ value: string; waferCount: number; testedDie: number; yield: number }>; byProbeCard: Array<{ value: string; waferCount: number; testedDie: number; yield: number }> }; topFailBins: Array<{ softBin: number; hardBin: number; dieCount: number }>; parameters: unknown[]; retest: { available: boolean }; availability: { parameterStatistics: boolean; retestAnalysis: boolean; processDefectCorrelation: boolean } };
    const engineeringFiltered = (await engineeringFilteredResponse.json()) as { release: { key: string }; selection: { filters: Record<string, string[]>; scope: string } };
    const fixtureEngineering = (await fixtureEngineeringResponse.json()) as { parameters: Array<{ code: string; lowerLimit: number | null; upperLimit: number | null; outOfSpecCount: number }>; parameterDistributions: Record<string, Array<{ lower: number; upper: number; count: number }>>; parameterWaferComparison: Record<string, Array<{ waferKey: number; mean: number; outOfSpecCount: number }>>; parameterDescriptive: Record<string, { median: number; sigma3: number; sigma6: number; shape: string }>; parameterBoxPlots: Record<string, Record<string, Array<{ group: string; q1: number; median: number; q3: number }>>>; parameterScatter: Array<{ xCode: string; yCode: string; sampleCount: number; correlation: number | null; points: Array<{ x: number; y: number }> }>; spatialPatterns: Array<{ waferKey: number; pattern: string; confidence: number; dieCount: number; failDie: number; source: string }> };
    const map = (await mapResponse.json()) as { wafer: { waferId: string }; parameter: { code: string; measuredDieCount: number } | null; geometry: { diameterMm: number; grossDie: number; coordinateSource: string; bounds: { xMin: number; xMax: number; yMin: number; yMax: number } }; dies: Array<{ pass: boolean; softBin: number; measuredValue: number | null }> };
    const rawGrid = (await rawGridResponse.json()) as { mapAvailable: boolean; geometry: { diameterMm: number; coordinateSource: string; bounds: { yMin: number; yMax: number } }; dies: Array<{ source: string; x: number; y: number }> };
    const mapReady = (await mapReadyResponse.json()) as { coverage: { mapReadyWaferCount: number; scopedWaferCount: number }; mapReadyWafers: Array<{ waferKey: number; waferId: string; lotId: string; rawRowCount: number; observedDieCount: number }> };

    expect(overviewResponse.status).toBe(200);
    expect(overview.release.key).toBe("CPDEV-20260823-R1");
    expect(overview.summary.waferCount).toBe(9);
    expect(overview.summary.belowTargetCount).toBeGreaterThan(0);
    expect(overview.binDistribution.length).toBeGreaterThan(1);
    expect(overview.binDistribution.reduce((total, bin: { share: number }) => total + bin.share, 0)).toBeCloseTo(1, 3);
    expect(engineeringResponse.status).toBe(200);
    expect(engineering.release).toMatchObject({ key: "CPREAL-EE48DB6DF97E-R5", status: "analytics_ready" });
    expect(engineering.yieldDimensions.byTester.length).toBeGreaterThan(0);
    expect(engineering.yieldDimensions.byProbeCard.length).toBeGreaterThan(0);
    expect(engineering.yieldDimensions.byTester.every((row) => row.waferCount > 0 && row.testedDie > 0 && row.yield >= 0 && row.yield <= 1)).toBe(true);
    expect(engineering.topFailBins.every((bin) => Number.isInteger(bin.hardBin) && bin.hardBin >= 0 && bin.dieCount > 0)).toBe(true);
    expect(engineering.parameters).toEqual([]);
    expect(engineering.retest.available).toBe(false);
    expect(engineering.availability).toMatchObject({ parameterStatistics: false, retestAnalysis: false, processDefectCorrelation: false });
    expect(engineeringFilteredResponse.status).toBe(200);
    expect(engineeringFiltered.release.key).toBe("CPREAL-EE48DB6DF97E-R5");
    expect(engineeringFiltered.selection.filters).toMatchObject({ part6: ["TMUW83"] });
    expect(engineeringFiltered.selection.scope).toBe("approved_release_only");
    expect(fixtureEngineeringResponse.status).toBe(200);
    expect(fixtureEngineering.parameters[0]).toMatchObject({ code: "CP_PARAM_001", lowerLimit: 0, upperLimit: 10 });
    expect(fixtureEngineering.parameters[0].outOfSpecCount).toBeGreaterThan(0);
    expect(fixtureEngineering.parameterDistributions.CP_PARAM_001).toHaveLength(12);
    expect(fixtureEngineering.parameterDistributions.CP_PARAM_001.every((bin) => bin.count > 0 && bin.upper >= bin.lower)).toBe(true);
    expect(fixtureEngineering.parameterWaferComparison.CP_PARAM_001).toHaveLength(9);
    expect(fixtureEngineering.parameterWaferComparison.CP_PARAM_001.every((wafer) => Number.isInteger(wafer.waferKey) && Number.isFinite(wafer.mean) && wafer.outOfSpecCount >= 0)).toBe(true);
    expect(fixtureEngineering.parameters.map((parameter) => parameter.code)).toEqual(expect.arrayContaining(["CP_PARAM_001", "CP_PARAM_002"]));
    expect(fixtureEngineering.parameterDescriptive.CP_PARAM_001).toMatchObject({ median: 5, sigma3: expect.any(Number), sigma6: expect.any(Number) });
    expect(fixtureEngineering.parameterBoxPlots.CP_PARAM_001.wafer).toHaveLength(9);
    expect(fixtureEngineering.parameterBoxPlots.CP_PARAM_001.wafer.every((row) => row.q1 <= row.median && row.median <= row.q3)).toBe(true);
    expect(fixtureEngineering.parameterScatter.some((pair) => pair.xCode === "CP_PARAM_001" && pair.yCode === "CP_PARAM_002" && pair.sampleCount === 900 && pair.correlation !== null && pair.points.length > 0)).toBe(true);
    expect(fixtureEngineering.spatialPatterns.some((pattern) => pattern.pattern === "ring_like_edge_loss" && pattern.confidence >= 0.8 && pattern.source === "canonical_die_coordinates")).toBe(true);
    expect(fixtureEngineering.spatialPatterns.every((pattern) => pattern.dieCount > 0 && pattern.failDie >= 0)).toBe(true);
    expect(mapResponse.status).toBe(200);
    expect(map.wafer.waferId).toBe("CPDEV204-01");
    expect(map.geometry.diameterMm).toBe(300);
    expect(map.geometry.grossDie).toBeGreaterThanOrEqual(map.dies.length);
    expect(map.geometry.coordinateSource).toBe("canonical_die");
    expect(map.geometry.bounds.xMax).toBeGreaterThanOrEqual(map.geometry.bounds.xMin);
    expect(map.dies).toHaveLength(100);
    expect(map.parameter).toMatchObject({ code: "CP_PARAM_001", measuredDieCount: 100 });
    expect(map.dies.some((die) => !die.pass && die.softBin === 40 && die.measuredValue === 10.4)).toBe(true);
    expect(rawGridResponse.status).toBe(200);
    expect(rawGrid.mapAvailable).toBe(true);
    expect(rawGrid.geometry.diameterMm).toBe(300);
    expect(rawGrid.geometry.coordinateSource).toBe("VEDA_TBL_CP_RAW");
    expect(rawGrid.dies.length).toBeGreaterThanOrEqual(50);
    expect(rawGrid.dies.every((die) => die.source === "veda_raw" && Number.isInteger(die.x) && Number.isInteger(die.y))).toBe(true);
    expect(mapReadyResponse.status).toBe(200);
    expect(mapReady.coverage).toMatchObject({ mapReadyWaferCount: 5, scopedWaferCount: 71 });
    expect(mapReady.mapReadyWafers.some((wafer) => wafer.waferId === "FFR123.06" && wafer.lotId === "FFR123.1" && wafer.rawRowCount > 0 && wafer.observedDieCount >= 50)).toBe(true);
    expect(rejectedResponse.status).toBe(404);
  }, 15_000);
});
