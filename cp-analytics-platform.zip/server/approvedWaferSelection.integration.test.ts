import { describe, expect, it } from "vitest";
import { selectApprovedWafer } from "../client/src/lib/approvedWaferSelection";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";

type ApiWafer = { waferId: string; scenario: string; yield: number };

describe("approved wafer workspace integration", () => {
  it("uses the live approved-release list and resolves a selected wafer for evidence display", async () => {
    const response = await fetch(`${baseUrl}/api/v1/releases/approved/wafers?releaseKey=CPDEV-20260823-R1`);
    const payload = (await response.json()) as { wafers: ApiWafer[] };
    const selected = selectApprovedWafer(payload.wafers, "CPDEV204-01");

    expect(response.status).toBe(200);
    expect(payload.wafers).toHaveLength(9);
    expect(selected).toMatchObject({ waferId: "CPDEV204-01", scenario: "parameter_shift", yield: 0.8 });
  }, 15_000);
});
