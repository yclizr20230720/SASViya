import { chromium } from "@playwright/test";
import { describe, expect, it } from "vitest";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";

describe("supported parameter and spatial engineering workflows", () => {
  it("renders approved parameter capability statistics and canonical multi-wafer spatial controls", async () => {
    const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
    try {
      const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
      await page.goto(`${baseUrl}/query`, { waitUntil: "domcontentloaded" });
      await page.getByRole("heading", { name: "Define analysis dataset" }).waitFor();
      await page.getByLabel("Query source release").selectOption("CPDEV-20260823-R1");
      await page.getByRole("button", { name: "Execute query" }).click();
      await page.getByText(/Showing 9 of 9 matching wafer-level records/).waitFor({ timeout: 20_000 });
      const fixtureOverview = page.waitForResponse((response) => response.url().includes("/analysis/overview?releaseKey=CPDEV-20260823-R1") && response.status() === 200);
      const fixtureEngineering = page.waitForResponse((response) => response.url().includes("/analysis/engineering?releaseKey=CPDEV-20260823-R1") && response.status() === 200);
      await page.getByRole("button", { name: "Parameter statistics" }).click();
      await page.getByRole("heading", { name: "CP analysis console" }).waitFor();
      await fixtureOverview;
      await fixtureEngineering;

      await page.getByText("Approved distribution and limits", { exact: true }).waitFor({ timeout: 20_000 });
      await page.getByText("Cp", { exact: true }).waitFor();
      await page.getByText("Cpk", { exact: true }).waitFor();
      await page.getByText("Median", { exact: true }).waitFor();
      await page.getByText("Distribution shift and outlier screen", { exact: true }).waitFor();
      await page.getByText("Correlation and multivariable screen", { exact: true }).waitFor();
      expect(await page.getByText("Parameter mean and out-of-spec by wafer", { exact: true }).count()).toBe(1);

      await page.getByRole("button", { name: "Spatial wafer maps" }).click();
      await page.getByText("Coordinate-derived pattern queue", { exact: true }).waitFor({ timeout: 20_000 });
      await page.getByLabel("Wafer map view").selectOption("parameter");
      expect(await page.getByLabel("Wafer map parameter").locator('option[value="CP_PARAM_002"]').count()).toBe(1);
      await page.getByLabel("Wafer map parameter").selectOption("CP_PARAM_002");
      await page.getByText(/100 measured dies/).waitFor({ timeout: 20_000 });
      expect(await page.getByText("ring like edge loss", { exact: true }).count()).toBeGreaterThan(0);
      await page.getByRole("button", { name: "Set reference" }).first().click();
      await page.getByText("WAFER COMPARISON", { exact: true }).waitFor();
      expect(await page.getByText("Spatial pattern", { exact: true }).count()).toBe(1);
    } finally {
      await browser.close();
    }
  }, 60_000);
});
