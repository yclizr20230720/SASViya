import { describe, expect, it } from "vitest";
import { selectApprovedWafer } from "../client/src/lib/approvedWaferSelection";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";

type ApprovedPayload = {
  release: { key: string; status: string };
  wafers: Array<{ waferId: string; scenario: string; yield: number }>;
};

describe("CP approved-release end-to-end flow", () => {
  it("serves the workspace, passes readiness, returns approved data, selects evidence, and rejects an unapproved release", async () => {
    const [homeResponse, readinessResponse, approvedResponse, rejectedResponse] = await Promise.all([
      fetch(`${baseUrl}/`),
      fetch(`${baseUrl}/api/v1/health/ready`),
      fetch(`${baseUrl}/api/v1/releases/approved/wafers?releaseKey=CPDEV-20260823-R1`),
      fetch(`${baseUrl}/api/v1/releases/approved/wafers?releaseKey=CPDEV-20260823-R0`),
    ]);
    const homeHtml = await homeResponse.text();
    const readiness = (await readinessResponse.json()) as { status: string; checks: { approved_release_gate: string } };
    const approved = (await approvedResponse.json()) as ApprovedPayload;
    const rejected = (await rejectedResponse.json()) as { error: string };
    const selected = selectApprovedWafer(approved.wafers, "CPDEV204-01");

    expect(homeResponse.status).toBe(200);
    expect(homeHtml).toContain("VEDA CP Analytics");
    expect(readiness).toMatchObject({ status: "ready", checks: { approved_release_gate: "enabled" } });
    expect(approvedResponse.status).toBe(200);
    expect(approved.release).toMatchObject({ key: "CPDEV-20260823-R1", status: "analytics_ready" });
    expect(approved.wafers).toHaveLength(9);
    expect(selected).toMatchObject({ waferId: "CPDEV204-01", scenario: "parameter_shift", yield: 0.8 });
    expect(rejectedResponse.status).toBe(404);
    expect(rejected.error).toBe("approved_release_not_found");
  }, 15_000);
});
