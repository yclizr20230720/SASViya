# CSV-Profiled CP Database Dataset

## Purpose and provenance

`CPSYNCSV-EE48DB6DF97E-R1` is an **approved synthetic CP analytics release** created to provide a richer, database-backed analysis cohort without altering the imported CP exports. Its generator reads the supplied `cp2.csv`, `cp3.csv`, `cp4.csv`, `cp5.csv`, and `test.csv` files at materialization time, records their SHA-256 manifest in the release lineage, and derives the source vocabulary from the observed VEDA sections.

> This dataset is synthetic and is visibly labelled as **CSV-profiled synthetic** in the application. It must not be interpreted as additional measured production data.

| Source-profile observation | Result used by the generator |
|---|---|
| 1,166 logical records across 13 VEDA CP sections | The source manifest and table list are stored in release validation evidence. |
| 9 observed `PART` values, 7 lots, 17 bin definitions | Five observed part families provide a varied multi-lot cohort. |
| 5 tester values and 5 probe-card values | Tester and probe-card dimensions are selected from the observed export vocabulary. |
| 69 observed measurement timestamps | Deterministic dated sessions create filterable month/week and trend dimensions. |
| One invalid-width `VEDA_TBL_CP_ZONE` row | The profile records the quality limit; it is not converted into synthetic canonical evidence. |

## Materialized database evidence

The generator `backend/scripts/seed_csv_profiled_release.py` creates **five lots, twenty wafers, 1,760 canonical dies, and 5,280 die measurements**. Each wafer has 88 die positions inside a deterministic circular grid and is assigned one of seven screening scenarios: baseline, edge ring, center cluster, scratch, contact, parametric shift, or radial gradient.

| Database family | Materialized evidence |
|---|---|
| VEDA source mirrors | Lot, wafer, raw map rows, wafer summaries, wafer bins, bin definitions, gross-die records, and coordinate axes. |
| Canonical records | Products, lots, wafers, test sessions, coordinate transforms, bin revisions, dies, and three parameter versions. |
| Analytics records | Wafer summaries, bin summaries, release lot-filter rows, parameter statistics, scatter inputs, and parameter-value maps. |
| Governance records | Ingestion run, release, snapshot, source manifest, and blocking reconciliation evidence. |

The three parameter streams are `CSVPROF_VTH`, `CSVPROF_IDDQ`, and `CSVPROF_RON`. They have materialized lower/upper limits and die-aligned values, allowing database-backed histograms, box plots, scatter correlation, Cp/Cpk screening, and parameter-value wafer maps.

## Blocking reconciliation

The release is marked `analytics_ready` only when the following checks pass in one transaction:

| Blocking rule | Validation |
|---|---|
| Source profile manifest | Records the supplied-file hashes and VEDA table coverage. |
| Expanded wafer coverage | Requires the expected five lots and twenty wafers. |
| RAW-to-canonical reconciliation | Requires exact expected canonical die counts for the release. |
| Parameter measurement coverage | Requires all three parameter values for every canonical die. |
| Wafer-bin reconciliation | Requires the materialized bin total to equal the tested-die total on every wafer. |
| Synthetic provenance | Stores the generator version and declares that the release is not imported production data. |

All application analytics query the approved release tables through the existing approved-release APIs. No chart, statistic, map, or comparison receives values from frontend constants.
