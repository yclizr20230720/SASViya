# Approved-Release Wafer API

`GET /api/v1/releases/approved/wafers` is the first CP read API. It queries only `analytics_wafer_summary` records whose `governance_data_release.status` is `approved` or `analytics_ready`. It never reads source-mirror tables as a fallback.

The optional `releaseKey` parameter selects one approved release. Invalid identifiers return `400`, missing or unapproved releases return `404`, and unavailable storage returns `503`. A successful response includes release key, release status, approval timestamp, snapshot hash, lot and wafer identities, deterministic scenario label, die-count summary, yield, map bounds, and materialization hash.
