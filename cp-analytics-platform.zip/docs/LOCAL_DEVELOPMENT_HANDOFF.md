# Local Development Handoff

## Purpose

This guide accompanies the source handoff ZIP. It describes how to restore the project into a local Windows, macOS, or Linux development environment without depending on hosted application state.

## Recommended directory structure

Extract the archive into a writable workspace such as `C:\AITools_Design\CP_Analysis_Platform\cp-analytics-platform` on Windows. Keep the source tree intact because the frontend build, Flask static serving, migration notes, and CP scripts use repository-relative paths.

```text
cp-analytics-platform/
├── backend/                 Flask API, repositories, scripts, and Python tests
├── client/                  React + Vite application
├── database/                CP schema migrations and deterministic fixture references
├── docs/                    Operational, verification, and cutover documentation
├── server/                  Node integration and browser/API tests
├── shared/                  Shared TypeScript application types
├── config/                  Non-secret local configuration reference
├── package.json             Frontend and validation commands
└── pnpm-lock.yaml           Locked Node dependency graph
```

## Windows PowerShell bootstrap

```powershell
Set-Location C:\AITools_Design\CP_Analysis_Platform\cp-analytics-platform
pnpm install --frozen-lockfile
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r backend\requirements.txt

$env:CP_DATABASE_TARGET = 'builtin_mysql' # Use config/local_environment.template as reference.
$env:DATABASE_URL = 'mysql://cp_user:change_me@127.0.0.1:3306/cp_analytics'
pnpm dev
```

Set database credentials using your local secret manager or a non-versioned environment loader. Do not add `.env.local`, credentials, or database dumps to source control.

## Database restoration order

First create an empty target database. Apply the logical schema migrations in numeric order, restore the data export using its supplied restoration guide, then run the reconciliation utility. If you choose to generate development data instead, use one of the scripts under `backend/scripts/` and preserve each generated release's provenance.

| Step | Required result |
|---|---|
| Schema migration | Core, source mirror, analytics, governance, ingest, and authorization tables are available. |
| Data restore or seed | Data carries release, snapshot, and provenance fields. |
| Reconciliation | Blocking row-count, yield, bin, coordinate, and provenance checks pass before release approval. |
| Application startup | `/api/v1/health/ready` responds successfully. |
| Regression validation | TypeScript, browser/API, and backend tests pass for the local target. |

## Development safeguards

The Data Query page is the single source of an applied cohort. Analytics pages consume that persisted approved release and governed filters. The backend rejects unapproved releases at the route/repository boundary. Synthetic data is explicitly labelled and must not be represented as imported production evidence.

## Handoff archive contents

The source ZIP includes application code, migrations, deterministic scripts, test suites, documentation, package lockfiles, and a non-secret configuration reference. It excludes build output, dependencies, local logs, machine metadata, environment files, hosted service settings, and the separate data-export archive. A manifest inside the handoff ZIP lists file paths and SHA-256 checksums.
