# PostgreSQL Production Cutover

The current development milestone uses the managed MySQL-compatible database by explicit project decision so that schema work, deterministic CP fixtures, reconciliation, and the approved-release UI can be validated immediately. PostgreSQL remains the production target defined in the architecture.

The Flask configuration preserves a PostgreSQL database-target path and accepts `CP_DATABASE_URL`. Actual PostgreSQL execution is intentionally deferred until a reachable production or staging endpoint, its TLS policy, and access rules are provided. The supplied CP schema conversion notes and the source-compatible MySQL migration establish the conversion baseline; the cutover should be executed as a separate, environment-backed milestone rather than simulated locally.

The production cutover acceptance gate is: provide the reachable `CP_DATABASE_URL`, apply the PostgreSQL-specific migrations, execute the deterministic fixture/reconciliation suite against PostgreSQL, and pass the PostgreSQL readiness check so that the health endpoint reports the PostgreSQL target before switching the API environment.
