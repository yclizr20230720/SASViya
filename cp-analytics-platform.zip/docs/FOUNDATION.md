# CP Analytics Foundation

The project intentionally separates the React engineering experience, the Flask CP API, and the CP data store. The managed MySQL-compatible database is the current development target, enabling immediate schema creation and mock-data validation. The model and migration conventions remain documented for a later PostgreSQL production target.

The Flask application exposes two health endpoints. `GET /api/v1/health/live` verifies that the process is reachable. `GET /api/v1/health/ready` verifies that the PostgreSQL connection has been configured and always reports whether the approved-release protection is active. Readiness does not claim that data is valid or queryable until the data-release and reconciliation milestone has succeeded.

The first CP data endpoint is reserved at `GET /api/v1/releases/approved/wafers`. Until its PostgreSQL repository and approved-release schema exist, it returns a structured `503` rather than returning source data, unapproved fixtures, or guessed values. This protects the requirement that only approved data releases are visible through the application.

## Reproducible local commands

Install the Python service dependencies with `sudo pip3 install -r backend/requirements.txt`. Run `pnpm test:backend` for Flask unit tests, `pnpm test` for the existing TypeScript suite, and `pnpm check` for TypeScript checking. The development command first builds the Vite application and then serves the resulting static bundle through Flask on the managed runtime port.

Production uses the project `Dockerfile` because the platform requires Python at runtime. The image builds the React bundle and starts Flask through Gunicorn. In the present development deployment it reads the managed MySQL-compatible `DATABASE_URL`. A future PostgreSQL deployment changes the database target and reads `CP_DATABASE_URL`; no connection string is stored in the repository.
