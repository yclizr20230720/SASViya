# Approved-Wafer Workspace Rendering Acceptance

The development acceptance review covers the Flask-served React workspace after the release request resolves. It verifies the product shell, data hierarchy, approved-release evidence, and row-selection behavior against the deterministic fixture release.

| Acceptance item | Expected state | Verified evidence |
|---|---|---|
| Product identity | A distinct `VEDA CP` analytics wordmark appears in the persistent navigation shell. | The live browser workspace shows the VEDA CP mark and the `ANALYTICS PLATFORM` descriptor. |
| Data hierarchy | Active release, four key metrics, wafer inventory, and evidence panel have distinct visual priority. | The release `CPDEV-20260823-R1`, 9 wafers, 84.2% composite yield, 900 canonical dies, and 7/7 gates are visible in the live workspace. |
| Evidence selection | Selecting a wafer updates the evidence panel without exposing raw or rejected data. | Selecting `CPDEV204-01` changes the panel to the parameter-shift map, 80.00% yield, and its trace hash. |
| Responsive treatment | The desktop grid collapses to a single-column workspace and hides low-priority table columns on small displays. | CSS breakpoints at 1080px and 640px define the verified responsive behavior. |
| Verified empty state | A release with no wafer summaries presents an explicit verified-empty state rather than a blank panel. | The `VerifiedEmpty` component supplies release context and a clear empty-result message. |

The production bundle remains a single initial engineering-workspace route. Its latest development build measured approximately 214 kB gzip for the JavaScript asset. The 800 kB build-warning threshold is intentional for the current one-route foundation; route-level analysis modules should be code-split as they are added.
