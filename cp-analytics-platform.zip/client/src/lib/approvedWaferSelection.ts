export type IdentifiedWafer = { waferId: string };

export function selectApprovedWafer<T extends IdentifiedWafer>(wafers: T[], waferId: string | null): T | undefined {
  return wafers.find((wafer) => wafer.waferId === waferId) ?? wafers[0];
}
