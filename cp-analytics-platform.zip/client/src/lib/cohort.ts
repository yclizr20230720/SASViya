export type FilterName = "part" | "part6" | "lotId" | "testProgram" | "binDefName" | "testEqpid" | "cpProbecard" | "testVendor" | "month" | "week";
export type CohortFilters = Partial<Record<FilterName, string[]>>;
export type AppliedCohort = { releaseKey: string; filters: CohortFilters; appliedAt: string | null };

export const COHORT_STORAGE_KEY = "veda-cp-applied-cohort-v1";
export const cohortEventName = "cp-cohort-applied";

export function buildCohortQuery(releaseKey: string, filters: CohortFilters): string {
  const query = new URLSearchParams();
  if (releaseKey) query.set("releaseKey", releaseKey);
  Object.entries(filters).forEach(([field, values]) => values?.forEach((value) => query.append(field, value)));
  return query.toString();
}

export function readAppliedCohort(): AppliedCohort {
  try {
    const raw = window.localStorage.getItem(COHORT_STORAGE_KEY);
    if (!raw) return { releaseKey: "", filters: {}, appliedAt: null };
    const parsed = JSON.parse(raw) as Partial<AppliedCohort>;
    return {
      releaseKey: typeof parsed.releaseKey === "string" ? parsed.releaseKey : "",
      filters: parsed.filters && typeof parsed.filters === "object" ? parsed.filters : {},
      appliedAt: typeof parsed.appliedAt === "string" ? parsed.appliedAt : null,
    };
  } catch {
    return { releaseKey: "", filters: {}, appliedAt: null };
  }
}

export function saveAppliedCohort(cohort: AppliedCohort): void {
  const normalized: AppliedCohort = { releaseKey: cohort.releaseKey, filters: cohort.filters, appliedAt: cohort.appliedAt ?? new Date().toISOString() };
  window.localStorage.setItem(COHORT_STORAGE_KEY, JSON.stringify(normalized));
  window.dispatchEvent(new CustomEvent<AppliedCohort>(cohortEventName, { detail: normalized }));
}

export function cohortFilterCount(filters: CohortFilters): number {
  return Object.values(filters).reduce((total, values) => total + (values?.length ?? 0), 0);
}
