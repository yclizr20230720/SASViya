import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("@/components/DashboardLayout", () => ({
  default: ({ children }: { children: React.ReactNode }) => <div data-testid="query-shell">{children}</div>,
}));

import DataQuery from "./DataQuery";

const catalog = { releases: [{ key: "CPDEV-QUERY-R1", status: "analytics_ready", waferCount: 2, partNumber: "VEDA-Q", provenance: "imported_or_fixture", label: "Approved query fixture" }], scope: "approved_release_only" };
const metadata = { release: { key: "CPDEV-QUERY-R1", status: "analytics_ready", snapshotHash: "a".repeat(64) }, fields: { part: [], part6: [{ value: "TMUW83", lotCount: 2 }], lotId: [], testProgram: [], binDefName: [], testEqpid: [], cpProbecard: [], testVendor: [], month: [], week: [] }, semantics: { withinField: "OR", acrossFields: "AND", scope: "approved_release_only" } };
const preview = { release: { key: "CPDEV-QUERY-R1", status: "analytics_ready" }, pendingFilters: { part6: ["TMUW83"] }, lotCount: 2, waferCount: 2 };
const queryRows = { release: { key: "CPDEV-QUERY-R1", status: "analytics_ready", snapshotHash: "a".repeat(64) }, selection: { filters: { part6: ["TMUW83"] }, totalRowCount: 2, returnedRowCount: 2, reviewLimit: 100, semantics: { withinField: "OR", acrossFields: "AND", scope: "approved_release_only" } }, rows: [{ waferKey: 1, part: "TMUW83A", part6: "TMUW83", lotId: "LOT-Q1", waferNo: 1, waferId: "Q1-01", testProgram: "CP-Q", binDefName: "BIN-Q", testEqpid: "ATE-Q", cpProbecard: "PC-Q", testVendor: "TEST-Q", month: "202608", week: "202634", measuredAt: "2026-08-23T00:00:00", passIndex: 1, grossDie: 100, testedDie: 100, goodDie: 95, yield: .95, scenario: "baseline_good", materializationHash: "b".repeat(64) }, { waferKey: 2, part: "TMUW83A", part6: "TMUW83", lotId: "LOT-Q2", waferNo: 1, waferId: "Q2-01", testProgram: "CP-Q", binDefName: "BIN-Q", testEqpid: "ATE-Q", cpProbecard: "PC-Q", testVendor: "TEST-Q", month: "202608", week: "202634", measuredAt: "2026-08-23T00:00:00", passIndex: 1, grossDie: 100, testedDie: 100, goodDie: 80, yield: .8, scenario: "edge_ring", materializationHash: "c".repeat(64) }] };

afterEach(() => { cleanup(); window.localStorage.clear(); vi.restoreAllMocks(); });

describe("Data Query", () => {
  it("executes a governed query, persists the applied cohort, and shows a bounded wafer review", async () => {
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? catalog : url.includes("analysis/filters") ? metadata : url.includes("analysis/preview") ? preview : queryRows;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<DataQuery />);
    await screen.findByRole("heading", { name: "Define analysis dataset" });
    const part6 = (await screen.findByRole("option", { name: /TMUW83/ })).parentElement as HTMLSelectElement;
    part6.options[0].selected = true;
    fireEvent.change(part6);
    await screen.findByText("2 wafers match");
    fireEvent.click(screen.getByRole("button", { name: "Execute query" }));
    await screen.findByText("Showing 2 of 2 matching wafer-level records. The review view is capped at 100 rows.");
    expect(screen.getByText(/LOT-Q1/)).toBeTruthy();
    expect(screen.getByText(/LOT-Q2/)).toBeTruthy();
    await waitFor(() => expect(JSON.parse(window.localStorage.getItem("veda-cp-applied-cohort-v1") ?? "{}")).toMatchObject({ releaseKey: "CPDEV-QUERY-R1", filters: { part6: ["TMUW83"] } }));
  });
});
