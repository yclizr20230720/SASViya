import { ChevronLeft, ChevronRight, Map as MapIcon } from "lucide-react";
import "./lot-mosaic.css";

type MosaicDie = { x: number; y: number; softBin: number; hardBin: number; pass: boolean };
type MosaicBounds = { xMin: number | null; xMax: number | null; yMin: number | null; yMax: number | null };
type MosaicWafer = { waferKey: number; lotId: string; waferId: string; waferNo: number | null; yield: number; testedDie: number; goodDie: number; lossDie: number; scenario: string | null; observedDieCount: number; previewSampled: boolean; dominantFailBin: { softBin: number; hardBin: number; dieCount: number } | null; geometry?: { bounds: MosaicBounds }; previewDies: MosaicDie[] };
type LotMosaic = { coverage: { mapReadyWaferCount: number; scopedWaferCount: number; mapReadyShare: number; totalMosaicCandidates: number; returnedWaferCount: number }; pagination: { offset: number; limit: number; hasMore: boolean }; lots: Array<{ lotId: string; mapReadyWaferCount: number; avgYield: number; minYield: number }>; wafers: MosaicWafer[] };

const percent = (value: number) => `${(value * 100).toFixed(1)}%`;
const fillFor = (die: MosaicDie) => die.pass ? "#45d7a2" : die.softBin === 40 ? "#f06572" : die.softBin === 11 ? "#f4b654" : die.softBin === 15 ? "#9d7cf9" : "#43a3ff";

export function LotMosaicModule({ mosaic, loading, lotId, onLotChange, onPrevious, onNext, onInspect, onCompare }: { mosaic: LotMosaic | null; loading: boolean; lotId: string; onLotChange: (value: string) => void; onPrevious: () => void; onNext: () => void; onInspect: (waferKey: number) => void; onCompare: (waferKey: number) => void }) {
  const wafers = mosaic?.wafers ?? [];
  const lots = mosaic?.lots ?? [];
  const coverage = mosaic?.coverage;
  const pagination = mosaic?.pagination;
  return <section className="analysis-card lot-mosaic-shell">
    <header className="lot-mosaic-head"><div><p className="analysis-eyebrow">MULTIPLE WAFER MAP BY LOT</p><h2>Approved bin-map mosaic and wafer loss review</h2><span>Every table row and preview is derived from the active Data Query cohort; previews are bounded to 12 map-ready wafers.</span></div><label>Lot<select aria-label="Mosaic lot selector" value={lotId} onChange={(event) => onLotChange(event.target.value)}><option value="">All map-ready lots</option>{lots.map((lot) => <option key={lot.lotId} value={lot.lotId}>{lot.lotId} · {lot.mapReadyWaferCount} wafers</option>)}</select></label></header>
    <div className="lot-mosaic-kpis"><span><b>{coverage?.scopedWaferCount ?? 0}</b> cohort wafers</span><span><b>{coverage?.mapReadyWaferCount ?? 0}</b> map-ready</span><span><b>{percent(coverage?.mapReadyShare ?? 0)}</b> spatial coverage</span><span><b>{coverage?.totalMosaicCandidates ?? 0}</b> selected candidates</span></div>
    {loading ? <div className="mosaic-loading"><MapIcon size={20} /> Loading approved wafer mosaic…</div> : !wafers.length ? <div className="empty-inline">No approved RAW-map wafers are available for the selected lot inside this Data Query cohort.</div> : <div className="lot-mosaic-layout"><div className="lot-mosaic-table-wrap"><table><thead><tr><th>Lot / wafer</th><th>Yield</th><th>Loss dies</th><th>Dominant fail bin</th><th>Inspect</th></tr></thead><tbody>{wafers.map((wafer) => <tr key={wafer.waferKey}><td><b>{wafer.lotId}</b><small>{wafer.waferId}</small></td><td>{percent(wafer.yield)}</td><td>{wafer.lossDie.toLocaleString()}</td><td>{wafer.dominantFailBin ? `SB ${wafer.dominantFailBin.softBin} / HB ${wafer.dominantFailBin.hardBin}` : "No observed fail bin"}</td><td><button onClick={() => onInspect(wafer.waferKey)}>Map<ChevronRight size={13} /></button></td></tr>)}</tbody></table></div><div className="lot-mosaic-grid" aria-label="Approved multi-wafer bin map mosaic">{wafers.map((wafer) => <MosaicWaferTile key={wafer.waferKey} wafer={wafer} onInspect={() => onInspect(wafer.waferKey)} onCompare={() => onCompare(wafer.waferKey)} />)}</div></div>}
    <footer className="lot-mosaic-footer"><span>{coverage?.returnedWaferCount ?? 0} of {coverage?.totalMosaicCandidates ?? 0} selected map-ready wafers · map colors show approved bin outcomes.</span><div><button aria-label="Previous mosaic wafers" onClick={onPrevious} disabled={!pagination?.offset}><ChevronLeft size={14} /> Previous</button><button aria-label="Next mosaic wafers" onClick={onNext} disabled={!pagination?.hasMore}>Next <ChevronRight size={14} /></button></div></footer>
  </section>;
}

function MosaicWaferTile({ wafer, onInspect, onCompare }: { wafer: MosaicWafer; onInspect: () => void; onCompare: () => void }) {
  const dies = wafer.previewDies;
  const bounds = wafer.geometry?.bounds;
  const xMin = bounds?.xMin ?? Math.min(...dies.map((die) => die.x), 0);
  const xMax = bounds?.xMax ?? Math.max(...dies.map((die) => die.x), 1);
  const yMin = bounds?.yMin ?? Math.min(...dies.map((die) => die.y), 0);
  const yMax = bounds?.yMax ?? Math.max(...dies.map((die) => die.y), 1);
  const xSpan = Math.max(1, xMax - xMin + 1);
  const ySpan = Math.max(1, yMax - yMin + 1);
  const cell = Math.min(3.1, 78 / Math.max(xSpan, ySpan));
  const originX = 50 - xSpan * cell / 2;
  const originY = 50 - ySpan * cell / 2;
  return <article className="lot-mosaic-wafer"><header><b>{wafer.waferId}</b><span>{percent(wafer.yield)}</span></header><button className="lot-mosaic-map" aria-label={`Inspect mosaic wafer ${wafer.waferId}`} onClick={onInspect}><svg viewBox="0 0 100 100" role="img" aria-label={`${wafer.waferId} bin map`}><defs><clipPath id={`lot-mosaic-${wafer.waferKey}`}><circle cx="50" cy="50" r="42" /></clipPath></defs><circle className="mini-wafer-body" cx="50" cy="50" r="42" /><g clipPath={`url(#lot-mosaic-${wafer.waferKey})`}>{dies.map((die) => <rect key={`${die.x}-${die.y}-${die.softBin}-${die.hardBin}`} x={originX + (die.x - xMin) * cell} y={100 - originY - (die.y - yMin + 1) * cell} width={Math.max(.45, cell * .9)} height={Math.max(.45, cell * .9)} fill={fillFor(die)} />)}</g><circle className="mini-wafer-rim" cx="50" cy="50" r="42" /></svg></button><footer><span>{wafer.observedDieCount.toLocaleString()} observed{wafer.previewSampled ? " · sampled" : ""}</span><button onClick={onCompare}>Set reference</button></footer></article>;
}
