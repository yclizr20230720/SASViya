import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { MapReadyControls, type MapReadyCoverage } from "@/components/MapReadyControls";
import { buildCohortQuery, cohortEventName, cohortFilterCount, readAppliedCohort, type CohortFilters, type FilterName } from "@/lib/cohort";
import { AlertTriangle, BarChart3, CheckCircle2, ChevronRight, CircleDot, ClipboardCheck, Crosshair, DatabaseZap, GitCompareArrows, Grid2X2, Layers3, LineChart, Loader2, Map as MapIcon, RefreshCw, RotateCcw, ShieldCheck, SlidersHorizontal, Sparkles, Target, TriangleAlert, Wrench } from "lucide-react";
import React, { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import "./product-engineering.css";
import { LotMosaicModule } from "./LotMosaic";

type WaferSummary = { waferKey: number; lotId: string; waferId: string; waferNo: number; scenario: string | null; yield: number; testedDie: number; goodDie: number };
type BinSummary = { softBin: number; hardBin: number; dieCount: number; share: number };
type Overview = {
  release: { key: string; status: string; approvedAt: string | null; snapshotHash: string | null };
  summary: { waferCount: number; testedDie: number; goodDie: number; meanYield: number; medianYield: number; minYield: number; belowTargetCount: number };
  selection?: { filters: Record<string, string[]>; waferCount: number; lotCount: number; semantics: { withinField: string; acrossFields: string } };
  yieldByWafer: WaferSummary[];
  binDistribution: BinSummary[];
  lotSummaries: Array<{ lotId: string; waferCount: number; avgYield: number; minYield: number }>;
};
type Die = { x: number; y: number; softBin: number; hardBin: number; pass: boolean; measuredValue: number | null; failDirection: string | null; source?: string };
type WaferGeometry = { diameterMm: number; notchPosition: string; grossDie: number; testedDie: number; source: string; coordinateSource: string; bounds: { xMin: number | null; xMax: number | null; yMin: number | null; yMax: number | null }; coverage: number | null; isPartial: boolean };
type WaferMap = { releaseKey: string; wafer: { waferId: string; lotId: string }; parameter: { code: string; name: string; unit: string | null; lowerLimit: number | null; upperLimit: number | null; measuredDieCount: number } | null; mapAvailable: boolean; availabilityReason: string | null; geometry?: WaferGeometry; dies: Die[] };
type ProductSpatialPreview = { wafer: WaferSummary; map: WaferMap | null };
type LotMosaicWafer = { waferKey: number; lotId: string; waferId: string; waferNo: number | null; yield: number; testedDie: number; goodDie: number; lossDie: number; scenario: string | null; observedDieCount: number; previewSampled: boolean; dominantFailBin: { softBin: number; hardBin: number; dieCount: number } | null; geometry?: WaferGeometry; previewDies: Die[] };
type LotMosaic = { release: { key: string; status: string; snapshotHash: string | null }; selection: { filters: Record<string, string[]>; scope: string; mosaicLotId: string | null }; coverage: { mapReadyWaferCount: number; scopedWaferCount: number; mapReadyShare: number; totalMosaicCandidates: number; returnedWaferCount: number }; pagination: { offset: number; limit: number; hasMore: boolean }; lots: Array<{ lotId: string; mapReadyWaferCount: number; avgYield: number; minYield: number }>; wafers: LotMosaicWafer[] };
type WorkspaceTab = "overview" | "rows" | "yield" | "bins" | "parameters" | "map" | "compare" | "trends" | "equipment" | "retest" | "process";
type FilterMetadata = { release: { key: string; status: string; snapshotHash: string | null }; fields: Record<FilterName, Array<{ value: string; lotCount: number }>>; semantics: { withinField: string; acrossFields: string; scope: string } };
type SelectionPreview = { release: { key: string; status: string }; pendingFilters: Partial<Record<FilterName, string[]>>; lotCount: number; waferCount: number };
type ReleaseCatalog = { releases: Array<{ key: string; status: string; waferCount: number; partNumber: string; provenance: "simulated_complete_300mm" | "simulated_csv_profiled" | "imported_or_fixture"; label: string }>; scope: string };
type EngineeringDimension = { value: string; waferCount: number; goodDie: number; testedDie: number; yield: number };
type ParameterDistributionBin = { lower: number; upper: number; count: number };
type ParameterWaferComparison = { waferKey: number; lotId: string; waferId: string; sampleCount: number; mean: number; stddev: number; outOfSpecCount: number };
type ParameterDescriptive = { count: number; mean: number; median: number; stddev: number; sigma3: number; sigma6: number; min: number; max: number; q1: number; q3: number; iqr: number; outlierCount: number; skewness: number; shape: string };
type ParameterBoxPlot = ParameterDescriptive & { group: string };
type ParameterScatter = { xCode: string; yCode: string; sampleCount: number; correlation: number | null; points: Array<{ x: number; y: number; waferKey: number; lotId: string; waferId: string; xCoord: number; yCoord: number }> };
type SpatialPattern = { waferKey: number; lotId: string; waferId: string; pattern: string; confidence: number; dieCount: number; failDie: number; source: string };
type EngineeringInsights = {
  release: { key: string; status: string; snapshotHash: string | null };
  yieldDimensions: { byTester: EngineeringDimension[]; byProbeCard: EngineeringDimension[]; byPart: EngineeringDimension[]; byLot: EngineeringDimension[] };
  trend: Array<{ period: string; waferCount: number; yield: number; adjacentYieldDelta?: number | null; representativeWaferKey?: number | null }>;
  topFailBins: Array<{ softBin: number; hardBin: number; dieCount: number }>;
  parameters: Array<{ code: string; name: string; unit: string | null; sampleCount: number; mean: number; stddev: number; min: number; max: number; lowerLimit: number | null; upperLimit: number | null; outOfSpecCount: number }>;
  parameterDistributions: Record<string, ParameterDistributionBin[]>;
  parameterWaferComparison: Record<string, ParameterWaferComparison[]>;
  parameterDescriptive: Record<string, ParameterDescriptive>;
  parameterBoxPlots: Record<string, Record<string, ParameterBoxPlot[]>>;
  parameterScatter: ParameterScatter[];
  parameterSampleReason: string | null;
  retest: { sessionCount: number; retestSessionCount: number; maxPassIndex: number; available: boolean };
  spatialPatternEvidence: Array<{ pattern: string; waferCount: number }>;
  spatialPatterns: SpatialPattern[];
  spatialPatternReason: string | null;
  availability: { parameterStatistics: boolean; specificationLimits: boolean; processDefectCorrelation: boolean; processDefectReason: string; retestAnalysis: boolean };
};

const DEFAULT_RELEASE_KEY = "";
const filterDefinitions: Array<{ key: FilterName; label: string; help: string }> = [
  { key: "part", label: "PART", help: "Device part number" },
  { key: "part6", label: "PART6", help: "Six-character product family" },
  { key: "lotId", label: "LOTID", help: "Manufacturing lot" },
  { key: "testProgram", label: "TEST_PROGRAM", help: "CP program revision" },
  { key: "binDefName", label: "BIN_DEF_NAME", help: "Bin definition set" },
  { key: "testEqpid", label: "TEST_EQPID", help: "Test equipment" },
  { key: "cpProbecard", label: "CPPROBECARD", help: "Probe-card identifier" },
  { key: "testVendor", label: "TEST_VENDOR", help: "Test house or vendor" },
  { key: "month", label: "MONTH", help: "YYYYMM production month" },
  { key: "week", label: "WEEK", help: "YYYYWW production week" },
];
const moduleDetails: Record<WorkspaceTab, { label: string; hint: string; icon: React.ReactNode }> = {
  overview: { label: "Analysis overview", hint: "Release health at a glance", icon: <Grid2X2 size={16} /> },
  rows: { label: "CP row review", hint: "Screen release-scoped lot, wafer, bin, and yield evidence", icon: <ClipboardCheck size={16} /> },
  yield: { label: "Yield & bin summary", hint: "Rank yield loss and top failing bins", icon: <BarChart3 size={16} /> },
  bins: { label: "Bin intelligence", hint: "Trace failing-bin contribution", icon: <Layers3 size={16} /> },
  parameters: { label: "Parameter statistics", hint: "Distribution, limits, and capability evidence", icon: <SlidersHorizontal size={16} /> },
  map: { label: "Spatial wafer maps", hint: "Inspect single-wafer die grids and patterns", icon: <MapIcon size={16} /> },
  compare: { label: "Multi-wafer compare", hint: "Contrast wafer signatures", icon: <GitCompareArrows size={16} /> },
  trends: { label: "Lot & trend monitoring", hint: "Yield time trend and release cohorts", icon: <LineChart size={16} /> },
  equipment: { label: "Tester / probe health", hint: "Yield by tester and probe card", icon: <Wrench size={16} /> },
  retest: { label: "Retest analysis", hint: "First-pass and retest availability", icon: <RotateCcw size={16} /> },
  process: { label: "Process / defect link", hint: "Approved process and inspection correlation coverage", icon: <DatabaseZap size={16} /> },
};

const scenarioLabel: Record<string, string> = { baseline_good: "Baseline", edge_ring: "Edge ring", center_cluster: "Center cluster", scratch: "Scratch", site_anomaly: "Site anomaly", parameter_shift: "Parameter shift", retest_fail_flip: "Retest flip" };
const scenarioClass: Record<string, string> = { baseline_good: "tone-pass", edge_ring: "tone-amber", center_cluster: "tone-violet", scratch: "tone-rose", site_anomaly: "tone-sky", parameter_shift: "tone-orange", retest_fail_flip: "tone-magenta" };

const percent = (value: number) => `${(value * 100).toFixed(1)}%`;

export default function Home() {
  const initialCohort = useMemo(() => readAppliedCohort(), []);
  const [, setLocation] = useLocation();
  const [overview, setOverview] = useState<Overview | null>(null);
  const [waferMap, setWaferMap] = useState<WaferMap | null>(null);
  const [mapCoverage, setMapCoverage] = useState<MapReadyCoverage | null>(null);
  const [productSpatialPreviews, setProductSpatialPreviews] = useState<ProductSpatialPreview[]>([]);
  const [lotMosaic, setLotMosaic] = useState<LotMosaic | null>(null);
  const [mosaicLotId, setMosaicLotId] = useState("");
  const [mosaicOffset, setMosaicOffset] = useState(0);
  const [mosaicLoading, setMosaicLoading] = useState(false);
  const [engineeringInsights, setEngineeringInsights] = useState<EngineeringInsights | null>(null);
  const [releaseCatalog, setReleaseCatalog] = useState<ReleaseCatalog | null>(null);
  const [releaseKey, setReleaseKey] = useState(initialCohort.releaseKey);
  const [mapCoverageLoading, setMapCoverageLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<WorkspaceTab>("overview");
  const [selectedWaferId, setSelectedWaferId] = useState<string>("");
  const [mapParameterCode, setMapParameterCode] = useState("");
  const [referenceWaferId, setReferenceWaferId] = useState<string>("");
  const [selectedDie, setSelectedDie] = useState<Die | null>(null);
  const [filterMetadata, setFilterMetadata] = useState<FilterMetadata | null>(null);
  const [selectedFilters, setSelectedFilters] = useState<CohortFilters>(initialCohort.filters);
  const [appliedFilters, setAppliedFilters] = useState<CohortFilters>(initialCohort.filters);
  const [filterPanelOpen, setFilterPanelOpen] = useState(true);
  const [filterLoading, setFilterLoading] = useState(true);
  const [selectionPreview, setSelectionPreview] = useState<SelectionPreview | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [mapUnavailable, setMapUnavailable] = useState(false);
  const [loading, setLoading] = useState(true);
  const [mapLoading, setMapLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const queryFor = buildCohortQuery;
  const loadReleaseCatalog = async () => {
    try {
      const response = await fetch("/api/v1/releases/approved/catalog");
      if (!response.ok) throw new Error(`Release catalog request failed (${response.status}).`);
      const payload = (await response.json()) as ReleaseCatalog;
      setReleaseCatalog(payload);
      setReleaseKey((current) => current || payload.releases[0]?.key || DEFAULT_RELEASE_KEY);
    } catch (requestError) { setError(requestError instanceof Error ? requestError.message : "Release catalog request failed."); }
  };
  const loadFilterMetadata = async (releaseKey = DEFAULT_RELEASE_KEY) => {
    setFilterLoading(true);
    try {
      const response = await fetch(`/api/v1/releases/approved/analysis/filters?${queryFor(releaseKey, {})}`);
      if (!response.ok) throw new Error(`Filter metadata request failed (${response.status}).`);
      setFilterMetadata((await response.json()) as FilterMetadata);
    } catch (requestError) { setError(requestError instanceof Error ? requestError.message : "Filter metadata request failed."); }
    finally { setFilterLoading(false); }
  };
  const loadOverview = async (filters = appliedFilters, activeReleaseKey = releaseKey || overview?.release.key || DEFAULT_RELEASE_KEY) => {
    setLoading(true); setError(null);
    try {
      const response = await fetch(`/api/v1/releases/approved/analysis/overview?${queryFor(activeReleaseKey, filters)}`);
      if (!response.ok) throw new Error(`Analysis request failed (${response.status}).`);
      const payload = (await response.json()) as Overview;
      setOverview(payload);
      setSelectedWaferId((current) => payload.yieldByWafer.some((wafer) => String(wafer.waferKey) === current) ? current : String(payload.yieldByWafer[0]?.waferKey || ""));
      setReferenceWaferId((current) => payload.yieldByWafer.some((wafer) => String(wafer.waferKey) === current) ? current : String(payload.yieldByWafer[0]?.waferKey || ""));
    } catch (requestError) { setError(requestError instanceof Error ? requestError.message : "Analysis request failed."); }
    finally { setLoading(false); }
  };
  const loadEngineeringInsights = async (activeReleaseKey: string, filters = appliedFilters) => {
    try {
      const response = await fetch(`/api/v1/releases/approved/analysis/engineering?${queryFor(activeReleaseKey, filters)}`);
      if (!response.ok) throw new Error(`Engineering insights request failed (${response.status}).`);
      setEngineeringInsights((await response.json()) as EngineeringInsights);
    } catch (requestError) { setError(requestError instanceof Error ? requestError.message : "Engineering insights request failed."); }
  };

  useEffect(() => { void loadReleaseCatalog(); }, []);
  useEffect(() => {
    if (!releaseKey) return;
    setSelectedDie(null); setWaferMap(null); setMapParameterCode("");
    void loadOverview(appliedFilters, releaseKey);
  }, [releaseKey, JSON.stringify(appliedFilters)]);
  useEffect(() => {
    if (!selectedWaferId) return;
    let active = true;
    setMapLoading(true); setSelectedDie(null); setMapUnavailable(false);
    const activeWafer = overview?.yieldByWafer.find((wafer) => String(wafer.waferKey) === selectedWaferId);
    if (!activeWafer) { setMapLoading(false); return; }
    fetch(`/api/v1/releases/approved/analysis/wafer-map/${encodeURIComponent(activeWafer.waferId)}?releaseKey=${overview?.release.key ?? DEFAULT_RELEASE_KEY}&waferKey=${activeWafer.waferKey}${mapParameterCode ? `&parameterCode=${encodeURIComponent(mapParameterCode)}` : ""}`)
      .then(async (response) => { if (!response.ok) throw new Error(`Map request failed (${response.status}).`); return response.json() as Promise<WaferMap>; })
      .then((payload) => { if (active) { setWaferMap(payload); setMapUnavailable(!payload.mapAvailable); } })
      .catch(() => { if (active) { setWaferMap(null); setMapUnavailable(true); } })
      .finally(() => { if (active) setMapLoading(false); });
    return () => { active = false; };
  }, [selectedWaferId, overview?.release.key, mapParameterCode]);
  useEffect(() => {
    if (!overview) return;
    let active = true;
    setMapCoverageLoading(true);
    fetch(`/api/v1/releases/approved/analysis/map-ready?${queryFor(overview.release.key, appliedFilters)}`)
      .then(async (response) => { if (!response.ok) throw new Error(`Map coverage request failed (${response.status}).`); return response.json() as Promise<MapReadyCoverage>; })
      .then((payload) => { if (active) setMapCoverage(payload); })
      .catch(() => { if (active) setMapCoverage(null); })
      .finally(() => { if (active) setMapCoverageLoading(false); });
    return () => { active = false; };
  }, [overview?.release.key, JSON.stringify(appliedFilters)]);
  useEffect(() => {
    if (activeTab !== "overview" || !overview || !mapCoverage) return;
    const candidates = (mapCoverage.mapReadyWafers ?? []).slice(0, 3).map((candidate) => overview.yieldByWafer.find((wafer) => wafer.waferKey === candidate.waferKey)).filter((wafer): wafer is WaferSummary => Boolean(wafer));
    if (!candidates.length) { setProductSpatialPreviews([]); return; }
    let active = true;
    Promise.all(candidates.map(async (wafer) => {
      try {
        const response = await fetch(`/api/v1/releases/approved/analysis/wafer-map/${encodeURIComponent(wafer.waferId)}?releaseKey=${overview.release.key}&waferKey=${wafer.waferKey}`);
        return { wafer, map: response.ok ? await response.json() as WaferMap : null };
      } catch { return { wafer, map: null }; }
    })).then((previews) => { if (active) setProductSpatialPreviews(previews); });
    return () => { active = false; };
  }, [activeTab, overview?.release.key, mapCoverage?.mapReadyWafers?.map((wafer) => wafer.waferKey).join(",")]);
  useEffect(() => {
    if (activeTab !== "compare" || !overview) return;
    let active = true;
    setMosaicLoading(true);
    const params = new URLSearchParams(queryFor(overview.release.key, appliedFilters));
    if (mosaicLotId) params.set("mosaicLotId", mosaicLotId);
    params.set("offset", String(mosaicOffset));
    params.set("limit", "12");
    fetch(`/api/v1/releases/approved/analysis/lot-mosaic?${params.toString()}`)
      .then(async (response) => { if (!response.ok) throw new Error(`Lot mosaic request failed (${response.status}).`); return response.json() as Promise<LotMosaic>; })
      .then((payload) => { if (active) setLotMosaic(payload); })
      .catch(() => { if (active) setLotMosaic(null); })
      .finally(() => { if (active) setMosaicLoading(false); });
    return () => { active = false; };
  }, [activeTab, overview?.release.key, JSON.stringify(appliedFilters), mosaicLotId, mosaicOffset]);
  useEffect(() => {
    if (overview?.release.key) void loadEngineeringInsights(overview.release.key, appliedFilters);
  }, [overview?.release.key, JSON.stringify(appliedFilters)]);
  useEffect(() => {
    const navigate = (event: Event) => {
      const module = (event as CustomEvent<string>).detail as WorkspaceTab;
      if (module in moduleDetails) setActiveTab(module);
    };
    window.addEventListener("cp-analysis-navigate", navigate);
    return () => window.removeEventListener("cp-analysis-navigate", navigate);
  }, []);
  useEffect(() => {
    const applyCohort = (event: Event) => {
      const cohort = (event as CustomEvent<{ releaseKey: string; filters: CohortFilters }>).detail;
      if (!cohort?.releaseKey) return;
      setReleaseKey(cohort.releaseKey);
      setAppliedFilters(cohort.filters ?? {});
      setSelectedFilters(cohort.filters ?? {});
      setActiveTab("overview");
    };
    window.addEventListener(cohortEventName, applyCohort);
    return () => window.removeEventListener(cohortEventName, applyCohort);
  }, []);

  const selectedWafer = overview?.yieldByWafer.find((wafer) => String(wafer.waferKey) === selectedWaferId) ?? overview?.yieldByWafer[0];
  const referenceWafer = overview?.yieldByWafer.find((wafer) => String(wafer.waferKey) === referenceWaferId) ?? overview?.yieldByWafer[0];
  const criticalBins = useMemo(() => overview?.binDistribution.filter((bin) => bin.softBin !== 1) ?? [], [overview]);
  const isApprovedEmpty = !!overview && overview.summary.waferCount === 0;
  return <DashboardLayout requireAuth={false}>
    <div className="analysis-console">
          <header className="analysis-header">
        <div className="analysis-heading"><div className="analysis-mark"><Crosshair size={20} /></div><div><p className="analysis-eyebrow">VEDA CP / APPROVED ANALYSIS</p><h1>CP analysis console</h1><p>Start with a wafer, then navigate from yield signal to bin and spatial evidence.</p></div></div>
        <div className="analysis-header-actions"><div className="applied-cohort-status"><span>APPLIED DATA QUERY</span><b>{overview?.release.key ?? (releaseKey || "Loading release")}</b><small>{cohortFilterCount(appliedFilters)} criteria · {overview?.selection?.lotCount ?? 0} lots / {overview?.selection?.waferCount ?? 0} wafers</small></div><div className="release-status"><span className="status-dot" />{overview?.release.status ?? "loading"}<b>approved cohort</b></div><Button onClick={() => setLocation("/query")} variant="outline" className="analysis-refresh">Edit data query</Button><Button onClick={() => void loadOverview(appliedFilters)} variant="outline" className="analysis-refresh" disabled={loading}>{loading ? <Loader2 size={15} className="animate-spin" /> : <RefreshCw size={15} />} Refresh</Button></div>
      </header>

      <section className="analysis-guide"><ClipboardCheck size={18} /><div><strong>Guided workflow</strong><span>1. Review the release signal · 2. Select a yield outlier · 3. Inspect bin contribution · 4. Verify the die-level pattern.</span></div><ShieldCheck size={18} className="guide-shield" /></section>

      <section className="active-analysis-module" aria-label="Current CP analysis module"><span>{moduleDetails[activeTab].icon}</span><div><p className="analysis-eyebrow">ACTIVE ANALYSIS</p><h2>{moduleDetails[activeTab].label}</h2><small>{moduleDetails[activeTab].hint}</small></div></section>

      {error ? <section className="analysis-error"><AlertTriangle size={20} /><div><strong>Analysis data is unavailable.</strong><span>{error}</span></div><Button variant="outline" onClick={() => void loadOverview()}>Retry</Button></section> : null}
      {error ? null : loading || !overview ? <LoadingConsole /> : overview ? isApprovedEmpty ? <ApprovedEmpty releaseKey={overview.release.key} /> : <>
        <section className="analysis-kpis">
          <Kpi icon={<CheckCircle2 size={19} />} label="Release yield" value={percent(overview.summary.meanYield)} meta={`${overview.summary.goodDie.toLocaleString()} good / ${overview.summary.testedDie.toLocaleString()} tested`} tone="mint" />
          <Kpi icon={<TriangleAlert size={19} />} label="Below screening target" value={`${overview.summary.belowTargetCount} wafers`} meta={`Lowest observed ${percent(overview.summary.minYield)}`} tone="orange" />
          <Kpi icon={<Layers3 size={19} />} label="Critical bin share" value={percent(criticalBins.reduce((total, bin) => total + bin.share, 0))} meta={`${criticalBins.length} failing bin groups`} tone="violet" />
          <Kpi icon={<Sparkles size={19} />} label="Release confidence" value="Verified" meta="Lineage, bins and coordinate gates passed" tone="blue" />
        </section>

        <section className="analysis-toolbar"><div><p className="analysis-eyebrow">ACTIVE CONTEXT</p><strong>{selectedWafer?.lotId ?? "—"} · {selectedWafer?.waferId ?? "—"}</strong></div><label>Inspect wafer<select value={selectedWaferId} onChange={(event) => setSelectedWaferId(event.target.value)}>{overview.yieldByWafer.map((wafer) => <option key={wafer.waferKey} value={String(wafer.waferKey)}>{wafer.lotId} · {wafer.waferId} · {percent(wafer.yield)}</option>)}</select></label><div className="toolbar-context"><Target size={16} /><span>{Object.keys(appliedFilters).length ? `Applied cohort · ${overview.selection?.lotCount ?? 0} lots / ${overview.selection?.waferCount ?? 0} wafers` : "Full approved release"}</span></div></section>

        {activeTab === "overview" ? <ProductEngineeringDashboard overview={overview} insights={engineeringInsights} selectedWafer={selectedWafer} spatialPreviews={productSpatialPreviews} setSelectedWaferId={setSelectedWaferId} setReferenceWaferId={setReferenceWaferId} setActiveTab={setActiveTab} criticalBins={criticalBins} /> : null}
        {activeTab === "rows" ? <RowReviewModule wafers={overview.yieldByWafer} bins={overview.binDistribution} onSelect={(value) => { setSelectedWaferId(value); setActiveTab("map"); }} /> : null}
        {activeTab === "yield" ? <><YieldModule wafers={overview.yieldByWafer} selectedWaferId={selectedWaferId} onSelect={setSelectedWaferId} /><BinModule bins={overview.binDistribution} activeWafer={selectedWafer} onMap={() => setActiveTab("map")} /><section className="analysis-grid equipment-grid yield-dimension-grid"><DimensionCard eyebrow="PRODUCT BREAKDOWN" title="Yield by product" rows={engineeringInsights?.yieldDimensions.byPart ?? []} /><DimensionCard eyebrow="LOT BREAKDOWN" title="Yield by lot" rows={engineeringInsights?.yieldDimensions.byLot ?? []} /></section></> : null}
        {activeTab === "bins" ? <BinModule bins={overview.binDistribution} activeWafer={selectedWafer} onMap={() => setActiveTab("map")} /> : null}
        {activeTab === "parameters" ? <ParameterModule insights={engineeringInsights} /> : null}
        {activeTab === "map" ? <><MapReadyControls coverage={mapCoverage} loading={mapCoverageLoading} selectedWafer={selectedWafer} currentMapUnavailable={mapUnavailable} onSelect={(waferKey) => { setSelectedDie(null); setSelectedWaferId(String(waferKey)); }} /><MapModule wafer={selectedWafer} waferMap={waferMap} loading={mapLoading} unavailable={mapUnavailable} selectedDie={selectedDie} onSelectDie={setSelectedDie} parameterOptions={engineeringInsights?.parameters ?? []} parameterCode={mapParameterCode} onParameterChange={setMapParameterCode} /><SpatialPatternModule patterns={engineeringInsights?.spatialPatterns ?? []} reason={engineeringInsights?.spatialPatternReason ?? null} selectedWaferKey={selectedWafer?.waferKey} onInspect={(waferKey: number) => { setSelectedDie(null); setSelectedWaferId(String(waferKey)); }} onCompare={(waferKey: number) => { setReferenceWaferId(String(waferKey)); setActiveTab("compare"); }} /></> : null}
        {activeTab === "compare" ? <><LotMosaicModule mosaic={lotMosaic} loading={mosaicLoading} lotId={mosaicLotId} onLotChange={(value) => { setMosaicLotId(value); setMosaicOffset(0); }} onPrevious={() => setMosaicOffset((value) => Math.max(0, value - 12))} onNext={() => setMosaicOffset((value) => value + 12)} onInspect={(waferKey) => { setSelectedDie(null); setSelectedWaferId(String(waferKey)); setActiveTab("map"); }} onCompare={(waferKey) => { setSelectedWaferId(String(waferKey)); setReferenceWaferId(String(waferKey)); }} /><CompareModule wafers={overview.yieldByWafer} selected={selectedWafer} reference={referenceWafer} referenceWaferId={referenceWaferId} onReferenceChange={setReferenceWaferId} spatialPatterns={engineeringInsights?.spatialPatterns ?? []} /></> : null}
        {activeTab === "trends" ? <TrendModule insights={engineeringInsights} /> : null}
        {activeTab === "equipment" ? <EquipmentModule insights={engineeringInsights} /> : null}
        {activeTab === "retest" ? <RetestModule insights={engineeringInsights} /> : null}
        {activeTab === "process" ? <ProcessModule insights={engineeringInsights} /> : null}
      </> : null}
    </div>
  </DashboardLayout>;
}

function Kpi({ icon, label, value, meta, tone }: { icon: React.ReactNode; label: string; value: string; meta: string; tone: string }) { return <article className={`analysis-kpi ${tone}`}><div className="kpi-icon">{icon}</div><div><p>{label}</p><strong>{value}</strong><span>{meta}</span></div></article>; }

function FilterPanel({ metadata, loading, preview, previewLoading, isOpen, selected, applied, appliedLotCount, appliedWaferCount, onToggle, onChange, onClear, onApply }: { metadata: FilterMetadata | null; loading: boolean; preview: SelectionPreview | null; previewLoading: boolean; isOpen: boolean; selected: Partial<Record<FilterName, string[]>>; applied: Partial<Record<FilterName, string[]>>; appliedLotCount?: number; appliedWaferCount?: number; onToggle: () => void; onChange: (filters: Partial<Record<FilterName, string[]>>) => void; onClear: () => void; onApply: () => void }) {
  const selectedCount = Object.values(selected).reduce((total, values) => total + (values?.length ?? 0), 0);
  const appliedCount = Object.values(applied).reduce((total, values) => total + (values?.length ?? 0), 0);
  const selectionIsApplied = JSON.stringify(selected) === JSON.stringify(applied);
  const previewLabel = selectionIsApplied ? `${appliedCount ? "Applied cohort" : "Full release"} · ${appliedLotCount ?? preview?.lotCount ?? 0} lots · ${appliedWaferCount ?? preview?.waferCount ?? 0} wafers` : previewLoading ? "Calculating approved cohort preview…" : preview ? `Pending preview · ${preview.lotCount} lots · ${preview.waferCount} wafers` : "Preview unavailable · apply to resolve analysis";
  return <section className={`selection-panel ${isOpen ? "open" : "collapsed"}`}>
    <button className="selection-panel-head" onClick={onToggle} aria-expanded={isOpen}><div><p className="analysis-eyebrow">DATASET SELECTION</p><strong>Define the approved CP population</strong><span>{selectedCount ? `${selectedCount} ${selectionIsApplied ? "applied" : "draft"} criteria · ${previewLabel}` : previewLabel}</span></div><ChevronRight size={18} /></button>
    {isOpen ? <div className="selection-panel-body"><div className="selection-intro"><SlidersHorizontal size={18} /><p>Choose one or more values within a field to broaden the cohort; combine fields to narrow it. Data stays constrained to the approved release shown above.</p></div><div className="filter-grid">{filterDefinitions.map((definition) => { const values = metadata?.fields?.[definition.key] ?? []; return <label key={definition.key} className="filter-field"><span><b>{definition.label}</b><small>{definition.help}</small></span><select multiple value={selected[definition.key] ?? []} disabled={loading || !values.length} onChange={(event) => onChange({ ...selected, [definition.key]: Array.from(event.currentTarget.selectedOptions).map((option) => option.value) })}>{values.map((option) => <option key={option.value} value={option.value}>{option.value} · {option.lotCount} lot{option.lotCount === 1 ? "" : "s"}</option>)}</select></label>; })}</div><div className="selection-actions"><div><ShieldCheck size={16} /><span>AND across fields · OR within a field · approved-release-only</span></div><div><Button variant="outline" onClick={onClear} disabled={loading || !selectedCount}>Clear</Button><Button onClick={onApply} disabled={loading || !metadata}>{loading ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />} Apply dataset</Button></div></div></div> : null}
  </section>;
}

function OverviewModule({ overview, selectedWafer, setSelectedWaferId, setActiveTab, criticalBins }: { overview: Overview; selectedWafer?: WaferSummary; setSelectedWaferId: (value: string) => void; setActiveTab: (value: WorkspaceTab) => void; criticalBins: BinSummary[] }) {
  const worst = overview.yieldByWafer.slice(0, 4);
  return <div className="analysis-grid overview-grid">
    <article className="analysis-card yield-signal"><CardTitle eyebrow="YIELD SIGNAL" title="Wafer distribution" action="Open yield explorer" onAction={() => setActiveTab("yield")} /><div className="yield-bars">{overview.yieldByWafer.map((wafer) => <button key={wafer.waferKey} className={selectedWafer?.waferKey === wafer.waferKey ? "selected" : ""} onClick={() => setSelectedWaferId(String(wafer.waferKey))} title={`${wafer.waferId}: ${percent(wafer.yield)}`}><i style={{ height: `${Math.max(8, wafer.yield * 100)}%` }} /><span>{wafer.waferId.slice(-2)}</span></button>)}</div><div className="yield-axis"><span>0%</span><span>85% target</span><span>100%</span></div><div className="signal-summary"><span><b>{percent(overview.summary.medianYield)}</b> median</span><span><b>{percent(overview.summary.minYield)}</b> worst wafer</span><span><b>{overview.summary.belowTargetCount}</b> require review</span></div></article>
    <article className="analysis-card bin-contribution"><CardTitle eyebrow="BIN CONTRIBUTION" title="Loss concentration" action="Inspect bins" onAction={() => setActiveTab("bins")} /><div className="bin-stack">{overview.binDistribution.map((bin) => <div key={`${bin.softBin}-${bin.hardBin}`} className={bin.softBin === 1 ? "pass" : "fail"} style={{ width: `${Math.max(3, bin.share * 100)}%` }} />)}</div><div className="bin-list">{criticalBins.slice(0, 3).map((bin) => <div key={`${bin.softBin}-${bin.hardBin}`}><span className="bin-chip">SB {bin.softBin}</span><span>HB {bin.hardBin}</span><b>{percent(bin.share)}</b><small>{bin.dieCount} dies</small></div>)}</div></article>
    <article className="analysis-card outlier-queue"><CardTitle eyebrow="REVIEW QUEUE" title="Prioritize these signatures" /><div className="outlier-list">{worst.map((wafer, index) => <button key={wafer.waferKey} onClick={() => { setSelectedWaferId(String(wafer.waferKey)); setActiveTab("map"); }}><span className="outlier-rank">0{index + 1}</span><span className={`scenario-pill ${scenarioClass[wafer.scenario ?? ""] ?? ""}`}>{scenarioLabel[wafer.scenario ?? ""] ?? "Unknown"}</span><div><b>{wafer.waferId}</b><small>{wafer.lotId} · {wafer.goodDie}/{wafer.testedDie} good</small></div><strong>{percent(wafer.yield)}</strong><ChevronRight size={16} /></button>)}</div></article>
  </div>;
}

function ProductEngineeringDashboard({ overview, insights, selectedWafer, spatialPreviews, setSelectedWaferId, setReferenceWaferId, setActiveTab, criticalBins }: { overview: Overview; insights: EngineeringInsights | null; selectedWafer?: WaferSummary; spatialPreviews: ProductSpatialPreview[]; setSelectedWaferId: (value: string) => void; setReferenceWaferId: (value: string) => void; setActiveTab: (value: WorkspaceTab) => void; criticalBins: BinSummary[] }) {
  const trend = insights?.trend ?? [];
  const rankedLoss = [...overview.yieldByWafer].sort((left, right) => left.yield - right.yield).slice(0, 6);
  const lossDieTotal = rankedLoss.reduce((total, wafer) => total + wafer.testedDie - wafer.goodDie, 0);
  const worstTrend = trend.reduce<{ period: string; yield: number } | null>((current, point) => !current || point.yield < current.yield ? point : current, null);
  const largestShift = trend.reduce<{ period: string; delta: number } | null>((current, point, index) => { const delta = point.adjacentYieldDelta ?? (index > 0 ? point.yield - trend[index - 1].yield : null); return delta === null ? current : !current || Math.abs(delta) > Math.abs(current.delta) ? { period: point.period, delta } : current; }, null);
  return <div className="product-engineering-dashboard">
    <section className="product-engineering-header"><div><p className="analysis-eyebrow">PRODUCT CP / SPATIAL ENGINEERING</p><h2>Applied-cohort engineering signal</h2><span>Trend, ranked loss, and spatial previews are calculated from the same approved Data Query cohort.</span></div><div className="product-engineering-summary"><span><b>{overview.summary.waferCount}</b> wafers</span><span><b>{criticalBins.length}</b> critical bins</span><span><b>{spatialPreviews.length}</b> map previews</span></div></section>
    <section className="product-engineering-grid">
      <article className="analysis-card product-trend-card"><CardTitle eyebrow="YIELD TREND SIGNAL" title="Observed release yield by measured date" action="Open trend monitoring" onAction={() => setActiveTab("trends")} />{trend.length > 1 ? <ProductTrendChart points={trend} /> : <EmptyInline text="At least two approved measurement dates are required for a product trend signal." />}<div className="trend-drilldown-list" aria-label="Trend point drill-down">{trend.map((point) => <button key={point.period} disabled={!point.representativeWaferKey} onClick={() => { if (point.representativeWaferKey) { setSelectedWaferId(String(point.representativeWaferKey)); setActiveTab("map"); } }}><span>{point.period}</span><b>{percent(point.yield)}</b><small>{point.waferCount} wafers · inspect representative</small><ChevronRight size={13} /></button>)}</div><div className="product-signal-readout"><span><b>{worstTrend ? percent(worstTrend.yield) : "—"}</b> lowest observed {worstTrend?.period ?? "period"}</span><span><b>{largestShift ? `${largestShift.delta >= 0 ? "+" : ""}${(largestShift.delta * 100).toFixed(1)} pts` : "—"}</b> largest adjacent movement</span><small>Descriptive signal only; no SPC-control limits are inferred without an approved baseline.</small></div></article>
      <article className="analysis-card product-loss-card"><CardTitle eyebrow="RANKED LOSS CONTRIBUTORS" title="Wafers with the largest observed die loss" action="Open yield & bins" onAction={() => setActiveTab("yield")} /><div className="product-loss-list">{rankedLoss.map((wafer, index) => <button key={wafer.waferKey} onClick={() => { setSelectedWaferId(String(wafer.waferKey)); setActiveTab("map"); }}><span className="loss-rank">{String(index + 1).padStart(2, "0")}</span><div><b>{wafer.lotId} · {wafer.waferId}</b><small>{scenarioLabel[wafer.scenario ?? ""] ?? "Observed yield loss"} · {wafer.testedDie - wafer.goodDie} loss dies</small></div><i><em style={{ width: `${Math.max(4, (1 - wafer.yield) * 100)}%` }} /></i><strong>{percent(wafer.yield)}</strong><ChevronRight size={15} /></button>)}</div><div className="product-loss-footer"><span><b>{lossDieTotal.toLocaleString()}</b> loss dies across the displayed review queue</span><span>Click a wafer to inspect its map</span></div></article>
      <article className="analysis-card product-spatial-card"><CardTitle eyebrow="LINKED MULTI-WAFER SPATIAL VIEW" title="Approved map-ready wafer previews" action="Open spatial maps" onAction={() => setActiveTab("map")} /><div className="product-spatial-preview-grid">{spatialPreviews.length ? spatialPreviews.map((preview) => <ProductWaferPreview key={preview.wafer.waferKey} preview={preview} selected={selectedWafer?.waferKey === preview.wafer.waferKey} onInspect={() => { setSelectedWaferId(String(preview.wafer.waferKey)); setActiveTab("map"); }} onCompare={() => { setSelectedWaferId(String(preview.wafer.waferKey)); setReferenceWaferId(String(preview.wafer.waferKey)); setActiveTab("compare"); }} />) : <EmptyInline text="Loading approved map-ready wafer previews for this applied cohort." />}</div><p className="product-spatial-note">Overview previews use approved observed die coordinates and may be visually sampled for performance. Open Spatial wafer maps for full-resolution die inspection.</p></article>
    </section>
  </div>;
}

function ProductTrendChart({ points }: { points: EngineeringInsights["trend"] }) { const min = Math.min(...points.map((point) => point.yield)); const max = Math.max(...points.map((point) => point.yield)); const span = max - min || 1; const coordinates = points.map((point, index) => `${26 + index / Math.max(1, points.length - 1) * 308},${162 - ((point.yield - min) / span) * 118}`).join(" "); return <div className="product-trend-chart" role="img" aria-label="Applied cohort yield trend"><svg viewBox="0 0 360 190"><path className="trend-grid-line" d="M26 44H334M26 103H334M26 162H334" /><path className="trend-axis" d="M26 18V162H334" /><polyline points={coordinates} /><path className="trend-fill" d={`M26 162 L${coordinates.replaceAll(" ", " L")} L334 162 Z`} />{points.map((point, index) => { const x = 26 + index / Math.max(1, points.length - 1) * 308; const y = 162 - ((point.yield - min) / span) * 118; return <g key={point.period}><circle cx={x} cy={y} r="4"><title>{`${point.period}: ${percent(point.yield)} across ${point.waferCount} wafers`}</title></circle><text x={x} y="181" textAnchor="middle">{point.period.slice(5)}</text></g>; })}<text x="3" y="24">{percent(max)}</text><text x="3" y="164">{percent(min)}</text></svg></div>; }

function ProductWaferPreview({ preview, selected, onInspect, onCompare }: { preview: ProductSpatialPreview; selected: boolean; onInspect: () => void; onCompare: () => void }) { const dies = preview.map?.dies ?? []; const bounds = preview.map?.geometry?.bounds; const xMin = bounds?.xMin ?? Math.min(...dies.map((die) => die.x), 0); const xMax = bounds?.xMax ?? Math.max(...dies.map((die) => die.x), 1); const yMin = bounds?.yMin ?? Math.min(...dies.map((die) => die.y), 0); const yMax = bounds?.yMax ?? Math.max(...dies.map((die) => die.y), 1); const xSpan = Math.max(1, xMax - xMin + 1); const ySpan = Math.max(1, yMax - yMin + 1); const step = Math.max(1, Math.ceil(dies.length / 700)); const drawnDies = dies.filter((_, index) => index % step === 0); const cell = Math.min(3.2, 82 / Math.max(xSpan, ySpan)); const originX = 50 - xSpan * cell / 2; const originY = 50 - ySpan * cell / 2; return <section className={`product-wafer-preview ${selected ? "selected" : ""}`}><header><div><b>{preview.wafer.waferId}</b><small>{preview.wafer.lotId} · {percent(preview.wafer.yield)}</small></div><span className={`scenario-pill ${scenarioClass[preview.wafer.scenario ?? ""] ?? ""}`}>{scenarioLabel[preview.wafer.scenario ?? ""] ?? "Map ready"}</span></header>{preview.map?.mapAvailable && drawnDies.length ? <svg className="product-mini-wafer" viewBox="0 0 100 100" role="img" aria-label={`${preview.wafer.waferId} spatial preview`}><defs><clipPath id={`mini-edge-${preview.wafer.waferKey}`}><circle cx="50" cy="50" r="42" /></clipPath></defs><circle className="mini-wafer-body" cx="50" cy="50" r="42" /><g clipPath={`url(#mini-edge-${preview.wafer.waferKey})`}>{drawnDies.map((die) => <rect key={`${die.x}-${die.y}-${die.softBin}`} x={originX + (die.x - xMin) * cell} y={100 - originY - (die.y - yMin + 1) * cell} width={Math.max(.45, cell * .9)} height={Math.max(.45, cell * .9)} fill={die.pass ? "#45d7a2" : die.softBin === 40 ? "#f06572" : "#f4b654"} />)}</g><circle className="mini-wafer-rim" cx="50" cy="50" r="42" /></svg> : <div className="product-mini-map-empty"><MapIcon size={18} /><span>No approved map cells</span></div>}<footer><span>{preview.map?.dies.length.toLocaleString() ?? 0} observed dies{step > 1 ? " · sampled preview" : ""}</span><div><button onClick={onInspect}>Inspect</button><button onClick={onCompare}>Compare</button></div></footer></section>; }

function YieldModule({ wafers, selectedWaferId, onSelect }: { wafers: WaferSummary[]; selectedWaferId: string; onSelect: (id: string) => void }) { return <section className="analysis-card yield-explorer"><CardTitle eyebrow="YIELD EXPLORER" title="Ranked wafer yield · select an outlier to inspect its map" /><div className="ranked-yield">{wafers.map((wafer) => <button key={wafer.waferKey} onClick={() => onSelect(String(wafer.waferKey))} className={String(wafer.waferKey) === selectedWaferId ? "selected" : ""}><div><span className={`scenario-pill ${scenarioClass[wafer.scenario ?? ""] ?? ""}`}>{scenarioLabel[wafer.scenario ?? ""] ?? "Unknown"}</span><b>{wafer.waferId}</b><small>{wafer.lotId}</small></div><div className="yield-track"><i style={{ width: `${wafer.yield * 100}%` }} /></div><strong>{percent(wafer.yield)}</strong><span className={wafer.yield < .85 ? "review" : "within"}>{wafer.yield < .85 ? "Review" : "Within target"}</span></button>)}</div></section>; }

function BinModule({ bins, activeWafer, onMap }: { bins: BinSummary[]; activeWafer?: WaferSummary; onMap: () => void }) { return <div className="analysis-grid bin-grid"><article className="analysis-card bin-detail"><CardTitle eyebrow="BIN INTELLIGENCE" title="Release bin distribution" /><div className="bin-bars">{bins.map((bin) => <div key={`${bin.softBin}-${bin.hardBin}`}><div><span className={`bin-dot ${bin.softBin === 1 ? "pass" : "fail"}`} /><b>Soft bin {bin.softBin}</b><small>Hard bin {bin.hardBin}</small><strong>{percent(bin.share)}</strong></div><div className="wide-track"><i className={bin.softBin === 1 ? "pass" : "fail"} style={{ width: `${bin.share * 100}%` }} /></div><span>{bin.dieCount} dies</span></div>)}</div></article><article className="analysis-card action-card"><p className="analysis-eyebrow">NEXT ANALYSIS STEP</p><h2>Locate the dominant loss bin on the active wafer.</h2><p>Use the map to validate whether the loss pattern is edge-related, clustered, site-aligned, or parameter-driven.</p><div className="action-wafer"><CircleDot size={17} /><span>{activeWafer?.waferId ?? "Select a wafer"}</span><b>{activeWafer ? percent(activeWafer.yield) : "—"}</b></div><Button onClick={onMap}>Open wafer map <MapIcon size={16} /></Button></article></div>; }

function RowReviewModule({ wafers, bins, onSelect }: { wafers: WaferSummary[]; bins: BinSummary[]; onSelect: (waferKey: string) => void }) { return <div className="analysis-grid row-review-grid"><article className="analysis-card row-review-table"><CardTitle eyebrow="CP ROW REVIEW" title="Screen approved wafer records" /><div className="screening-summary"><span>{wafers.length} wafers in active cohort</span><span>{bins.filter((bin) => bin.softBin !== 1).length} failing bin groups</span><span>Click a wafer to inspect its die grid</span></div><div className="review-table-wrap"><table><thead><tr><th>Lot / wafer</th><th>Scenario</th><th>Yield</th><th>Good / tested</th><th>Screen</th></tr></thead><tbody>{wafers.map((wafer) => <tr key={wafer.waferKey}><td><b>{wafer.lotId}</b><small>{wafer.waferId}</small></td><td><span className={`scenario-pill ${scenarioClass[wafer.scenario ?? ""] ?? ""}`}>{scenarioLabel[wafer.scenario ?? ""] ?? "Unclassified"}</span></td><td>{percent(wafer.yield)}</td><td>{wafer.goodDie.toLocaleString()} / {wafer.testedDie.toLocaleString()}</td><td><button onClick={() => onSelect(String(wafer.waferKey))}>{wafer.yield < .85 ? "Investigate" : "Inspect"}<ChevronRight size={14} /></button></td></tr>)}</tbody></table></div></article><article className="analysis-card row-screening-card"><p className="analysis-eyebrow">SCREENING RULE</p><h2>Yield threshold and bin evidence</h2><p>Wafer rows are sorted by release-scoped yield. Values below 85% are flagged for map and bin review; the threshold is a UI screening rule and does not modify source results.</p><div className="screening-stat"><TriangleAlert size={18} /><span>{wafers.filter((wafer) => wafer.yield < .85).length} wafers below target</span></div></article></div>; }

function ParameterModule({ insights }: { insights: EngineeringInsights | null }) { const [selectedCode, setSelectedCode] = useState(""); const [boxDimension, setBoxDimension] = useState("wafer"); if (!insights?.availability.parameterStatistics) return <UnavailableAnalysis title="Parameter distributions are not available for this cohort" detail="No approved die-level parameter measurements are linked to the selected release and filters. CP yield, bins, maps, and equipment evidence remain available." icon={<SlidersHorizontal size={26} />} />; const selected = insights.parameters.find((parameter) => parameter.code === selectedCode) ?? insights.parameters[0]; if (!selected) return <UnavailableAnalysis title="No approved parameter rows are available" detail="The active release contains no materialized parameter records after the governed filters were applied." icon={<SlidersHorizontal size={26} />} />; const distribution = insights.parameterDistributions?.[selected.code] ?? []; const waferComparison = insights.parameterWaferComparison?.[selected.code] ?? []; const descriptive = insights.parameterDescriptive?.[selected.code]; const boxes = insights.parameterBoxPlots?.[selected.code]?.[boxDimension] ?? []; const scatter = insights.parameterScatter?.find((item) => item.xCode === selected.code || item.yCode === selected.code) ?? insights.parameterScatter?.[0]; const maxBin = Math.max(...distribution.map((bin) => bin.count), 1); const hasLimits = selected.lowerLimit !== null && selected.upperLimit !== null; const cp = hasLimits && selected.stddev > 0 ? (selected.upperLimit! - selected.lowerLimit!) / (6 * selected.stddev) : null; const cpk = hasLimits && selected.stddev > 0 ? Math.min(selected.upperLimit! - selected.mean, selected.mean - selected.lowerLimit!) / (3 * selected.stddev) : null; return <div className="analysis-grid parameter-analysis-grid"><article className="analysis-card parameter-profile"><CardTitle eyebrow="SINGLE PARAMETER" title="Approved distribution and limits" /><label className="parameter-select">Parameter<select aria-label="Parameter selector" value={selectedCode || selected.code} onChange={(event) => setSelectedCode(event.target.value)}>{insights.parameters.map((parameter) => <option key={parameter.code} value={parameter.code}>{parameter.code} · {parameter.name}</option>)}</select></label><div className="parameter-summary parameter-summary-rich"><div><span>Mean</span><b>{selected.mean.toFixed(3)}</b></div><div><span>Median</span><b>{descriptive?.median.toFixed(3) ?? "—"}</b></div><div><span>σ / 3σ</span><b>{selected.stddev.toFixed(3)} / {descriptive?.sigma3.toFixed(3) ?? "—"}</b></div><div><span>6σ</span><b>{descriptive?.sigma6.toFixed(3) ?? "—"}</b></div><div><span>Min — max</span><b>{selected.min.toFixed(3)} — {selected.max.toFixed(3)}</b></div><div><span>Outliers</span><b>{descriptive?.outlierCount ?? 0}</b></div></div><div className="parameter-histogram" aria-label={`${selected.code} distribution`}>{distribution.map((bin, index) => <div key={`${bin.lower}-${bin.upper}-${index}`} title={`${bin.lower.toFixed(3)} — ${bin.upper.toFixed(3)}: ${bin.count} samples`}><i style={{ height: `${Math.max(5, bin.count / maxBin * 100)}%` }} /><span>{index === 0 ? bin.lower.toFixed(2) : index === distribution.length - 1 ? bin.upper.toFixed(2) : ""}</span></div>)}</div><div className="parameter-shape"><span>Shape screen</span><b>{descriptive?.shape.replaceAll("_", " ") ?? "Not available"}</b><small>Skewness {descriptive?.skewness.toFixed(2) ?? "—"}; this is a distribution screen, not a formal normality test.</small></div><div className="parameter-spec"><span>LSL {selected.lowerLimit ?? "—"}</span><b>{hasLimits ? "Approved specification window" : "No approved specification window"}</b><span>USL {selected.upperLimit ?? "—"}</span></div></article><article className="analysis-card capability-card"><p className="analysis-eyebrow">CAPABILITY STATUS</p><h2>{hasLimits ? "Specification limits available" : "Specification limits unavailable"}</h2>{hasLimits ? <div className="capability-values"><div><span>Cp</span><b>{cp === null ? "Not estimable" : cp.toFixed(2)}</b></div><div><span>Cpk</span><b>{cpk === null ? "Not estimable" : cpk.toFixed(2)}</b></div></div> : null}<p>{hasLimits ? "Cp and Cpk use the approved release-wide population. They are screening indicators only; a controlled subgrouping policy remains required for formal capability approval." : "Parameter measurements exist, but approved lower and upper limits were not supplied for this cohort."}</p></article><article className="analysis-card parameter-box-card"><CardTitle eyebrow="BOX-PLOT COMPARISON" title="Distribution shift and outlier screen" /><label className="parameter-select">Compare by<select aria-label="Box plot grouping" value={boxDimension} onChange={(event) => setBoxDimension(event.target.value)}><option value="wafer">Wafer</option><option value="lot">Lot</option><option value="tester">Tester</option><option value="probeCard">Probe card</option></select></label><BoxPlotChart rows={boxes} /></article><article className="analysis-card parameter-scatter-card"><CardTitle eyebrow="PARAMETER SCATTER" title="Correlation and multivariable screen" />{scatter ? <ScatterPlot scatter={scatter} /> : <EmptyInline text={insights.parameterSampleReason ?? "At least two approved parameters with aligned die records are required for scatter analysis."} />}</article><article className="analysis-card parameter-table wafer-parameter-compare"><CardTitle eyebrow="WAFER COMPARISON" title="Parameter mean and out-of-spec by wafer" /><div className="review-table-wrap"><table><thead><tr><th>Lot / wafer</th><th>Mean ± σ</th><th>Samples</th><th>Out of spec</th></tr></thead><tbody>{waferComparison.map((wafer) => <tr key={wafer.waferKey}><td><b>{wafer.lotId}</b><small>{wafer.waferId}</small></td><td>{wafer.mean.toFixed(3)} ± {wafer.stddev.toFixed(3)}</td><td>{wafer.sampleCount}</td><td>{wafer.outOfSpecCount}</td></tr>)}</tbody></table></div></article></div>; }

function BoxPlotChart({ rows }: { rows: ParameterBoxPlot[] }) { if (!rows.length) return <EmptyInline text="No approved groups are available for this comparison." />; const lower = Math.min(...rows.map((row) => row.min)); const upper = Math.max(...rows.map((row) => row.max)); const span = upper - lower || 1; const point = (value: number) => `${((value - lower) / span) * 100}%`; return <div className="box-plot-chart" aria-label="Parameter box plot">{rows.slice(0, 12).map((row) => <div key={row.group}><span title={row.group}>{row.group}</span><i className="box-whisker" style={{ left: point(row.min), width: `${((row.max - row.min) / span) * 100}%` }} /><i className="box-body" style={{ left: point(row.q1), width: `${Math.max(1, ((row.q3 - row.q1) / span) * 100)}%` }} /><b className="box-median" style={{ left: point(row.median) }} /><small>{row.outlierCount} outliers · n={row.count}</small></div>)}<p>{lower.toFixed(2)} <span>value range</span> {upper.toFixed(2)}</p></div>; }

function ScatterPlot({ scatter }: { scatter: ParameterScatter }) { const xMin = Math.min(...scatter.points.map((point) => point.x)); const xMax = Math.max(...scatter.points.map((point) => point.x)); const yMin = Math.min(...scatter.points.map((point) => point.y)); const yMax = Math.max(...scatter.points.map((point) => point.y)); const xSpan = xMax - xMin || 1; const ySpan = yMax - yMin || 1; return <><div className="scatter-meta"><span>{scatter.xCode} × {scatter.yCode}</span><b>r {scatter.correlation === null ? "—" : scatter.correlation.toFixed(3)}</b><small>{scatter.sampleCount.toLocaleString()} aligned dies</small></div><svg className="scatter-chart" viewBox="0 0 360 220" role="img" aria-label={`${scatter.xCode} by ${scatter.yCode} scatter plot`}><path d="M42 12V184H344" /><path className="scatter-grid" d="M42 70H344M42 127H344M118 12V184M193 12V184M269 12V184" />{scatter.points.map((point, index) => <circle key={`${point.waferKey}-${index}`} cx={42 + ((point.x - xMin) / xSpan) * 302} cy={184 - ((point.y - yMin) / ySpan) * 172} r="2.2"><title>{`${point.lotId} · ${point.waferId}: ${point.x.toFixed(3)}, ${point.y.toFixed(3)}`}</title></circle>)}<text x="42" y="204">{xMin.toFixed(2)}</text><text x="305" y="204">{xMax.toFixed(2)}</text><text x="6" y="24">{yMax.toFixed(2)}</text><text x="6" y="184">{yMin.toFixed(2)}</text></svg><p className="scatter-note">Correlation is descriptive; it does not establish a process-cause relationship.</p></>; }

function TrendModule({ insights }: { insights: EngineeringInsights | null }) { const trend = insights?.trend ?? []; return <div className="analysis-grid trend-grid"><article className="analysis-card trend-card"><CardTitle eyebrow="LOT & TIME TREND" title="Weighted yield by measured date" />{trend.length ? <div className="trend-bars">{trend.map((point) => <div key={point.period}><i style={{ height: `${Math.max(6, point.yield * 100)}%` }} /><span>{point.period.slice(5)}</span><b>{percent(point.yield)}</b></div>)}</div> : <EmptyInline text="No measured-date values are available for the active cohort." />}</article><article className="analysis-card trend-readout"><p className="analysis-eyebrow">SPC AVAILABILITY</p><h2>{trend.length > 1 ? "Trend evidence available" : "Insufficient time points"}</h2><p>{trend.length > 1 ? "The chart shows release-scoped weighted yield by recorded lot date. Western Electric and EWMA alerts require a configured control baseline and are intentionally not inferred from this small sample." : "Add chronological lot history to enable X-bar/R, EWMA, and excursion rules."}</p></article></div>; }

function EquipmentModule({ insights }: { insights: EngineeringInsights | null }) { return <div className="analysis-grid equipment-grid"><DimensionCard eyebrow="TESTER HEALTH" title="Yield by tester" rows={insights?.yieldDimensions.byTester ?? []} /><DimensionCard eyebrow="PROBE-CARD HEALTH" title="Yield by probe card" rows={insights?.yieldDimensions.byProbeCard ?? []} /><article className="analysis-card equipment-readout"><p className="analysis-eyebrow">INTERPRETATION</p><h2>Hardware comparison is release-scoped</h2><p>Compare weighted yield, tested die, and wafer count by tester or probe card. Site-level variation needs approved site identifiers; it is not estimated from wafer-level summaries.</p></article></div>; }

function RetestModule({ insights }: { insights: EngineeringInsights | null }) { const retest = insights?.retest; return <div className="analysis-grid retest-grid"><article className="analysis-card retest-card"><CardTitle eyebrow="RETEST ANALYSIS" title="First-pass versus repeat-test evidence" /><div className="retest-numbers"><div><span>Sessions</span><b>{retest?.sessionCount ?? 0}</b></div><div><span>Retest sessions</span><b>{retest?.retestSessionCount ?? 0}</b></div><div><span>Max pass index</span><b>{retest?.maxPassIndex ?? 0}</b></div></div><p>{retest?.available ? "Approved repeat-test sessions are present. Use pass index alongside bin and parameter evidence to distinguish marginal dies from hard failures." : "No approved retest sessions are present in this active cohort; first-pass versus retest conclusions are unavailable."}</p></article><article className="analysis-card retest-readout"><p className="analysis-eyebrow">DATA REQUIREMENT</p><h2>Retest needs pass-index history</h2><p>The module remains explicit about data availability. It does not manufacture a retest rate when only a single approved CP session exists.</p></article></div>; }

function ProcessModule({ insights }: { insights: EngineeringInsights | null }) { return <UnavailableAnalysis title="Process and defect correlation is not linked" detail={insights?.availability.processDefectReason ?? "No approved inline process or defect-inspection data is linked to this CP release."} icon={<DatabaseZap size={26} />} />; }

function DimensionCard({ eyebrow, title, rows }: { eyebrow: string; title: string; rows: EngineeringDimension[] }) { return <article className="analysis-card dimension-card"><CardTitle eyebrow={eyebrow} title={title} />{rows.length ? <div className="dimension-list">{rows.map((row) => <div key={row.value}><span>{row.value}</span><i><b style={{ width: `${row.yield * 100}%` }} /></i><strong>{percent(row.yield)}</strong><small>{row.waferCount} wafers · {row.testedDie.toLocaleString()} dies</small></div>)}</div> : <EmptyInline text="No assigned values are available for this release cohort." />}</article>; }

function UnavailableAnalysis({ title, detail, icon }: { title: string; detail: string; icon: React.ReactNode }) { return <section className="analysis-empty availability-empty"><div>{icon}</div><div><p className="analysis-eyebrow">APPROVED DATA AVAILABILITY</p><h2>{title}</h2><p>{detail}</p></div></section>; }
function EmptyInline({ text }: { text: string }) { return <div className="empty-inline">{text}</div>; }

function MapModule({ wafer, waferMap, loading, unavailable, selectedDie, onSelectDie, parameterOptions, parameterCode, onParameterChange }: { wafer?: WaferSummary; waferMap: WaferMap | null; loading: boolean; unavailable: boolean; selectedDie: Die | null; onSelectDie: (die: Die) => void; parameterOptions: EngineeringInsights["parameters"]; parameterCode: string; onParameterChange: (value: string) => void }) {
  const [zoom, setZoom] = useState(1);
  const [viewMode, setViewMode] = useState<"bin" | "parameter">("bin");
  const dies = waferMap?.dies ?? [];
  const geometry = waferMap?.geometry;
  const bounds = geometry?.bounds ?? { xMin: null, xMax: null, yMin: null, yMax: null };
  const xMin = bounds.xMin ?? Math.min(...dies.map((die) => die.x), 0);
  const xMax = bounds.xMax ?? Math.max(...dies.map((die) => die.x), 1);
  const yMin = bounds.yMin ?? Math.min(...dies.map((die) => die.y), 0);
  const yMax = bounds.yMax ?? Math.max(...dies.map((die) => die.y), 1);
  const xSpan = Math.max(1, xMax - xMin + 1);
  const ySpan = Math.max(1, yMax - yMin + 1);
  const gridSpan = Math.max(xSpan, ySpan);
  const cell = Math.min(15, 278 / gridSpan);
  const originX = 180 - (xSpan * cell) / 2;
  const originY = 180 - (ySpan * cell) / 2;
  const parameterValues = dies.map((die) => die.measuredValue).filter((value): value is number => value !== null);
  const parameterMin = Math.min(...parameterValues, 0);
  const parameterMax = Math.max(...parameterValues, 1);
  const hasParameterValues = Boolean(parameterCode && parameterValues.length);
  const fillFor = (die: Die) => {
    if (viewMode === "parameter" && hasParameterValues && die.measuredValue !== null) {
      const ratio = Math.max(0, Math.min(1, (die.measuredValue - parameterMin) / (parameterMax - parameterMin || 1)));
      return `rgb(${Math.round(57 + ratio * 196)},${Math.round(128 + ratio * 56)},${Math.round(230 - ratio * 160)})`;
    }
    return die.pass ? "#35d39e" : die.softBin === 40 ? "#f65671" : die.softBin === 11 ? "#f6b44e" : die.softBin === 15 ? "#9d7cf9" : "#43a3ff";
  };
  return <div className="analysis-grid map-grid-layout"><article className="analysis-card map-card"><CardTitle eyebrow="300 MM DIE GRID" title={`${wafer?.waferId ?? "Selected wafer"} · ${scenarioLabel[wafer?.scenario ?? ""] ?? "Spatial inspection"}`} /><div className="wafer-map-toolbar"><div className="map-legend">{viewMode === "parameter" ? <><span><i className="parameter-low" />Low</span><span><i className="parameter-high" />High</span><span>{waferMap?.parameter?.code ?? "Select parameter"}</span></> : <><span><i className="pass" />Pass</span><span><i className="fail" />Fail / bin</span><span><i className="selected" />Selected die</span></>}<span>Gross die geometry</span></div><div className="map-controls"><label>View<select aria-label="Wafer map view" value={viewMode} onChange={(event) => setViewMode(event.target.value as "bin" | "parameter")}><option value="bin">Bin result</option><option value="parameter">Parameter value</option></select></label>{viewMode === "parameter" ? <label>Parameter<select aria-label="Wafer map parameter" value={parameterCode} onChange={(event) => onParameterChange(event.target.value)}><option value="">Select approved parameter</option>{parameterOptions.map((parameter) => <option key={parameter.code} value={parameter.code}>{parameter.code}</option>)}</select></label> : null}<div className="map-zoom"><button aria-label="Zoom out" onClick={() => setZoom((value) => Math.max(.65, value - .15))}>−</button><span>{Math.round(zoom * 100)}%</span><button aria-label="Zoom in" onClick={() => setZoom((value) => Math.min(1.75, value + .15))}>+</button><button aria-label="Reset wafer map zoom" onClick={() => setZoom(1)}>Reset</button></div></div></div>{loading ? <div className="map-loading"><Loader2 className="animate-spin" /> Loading approved die map…</div> : unavailable || !dies.length ? <div className="map-unavailable"><MapIcon size={30} /><b>Die-level map not available for this export</b><span>{waferMap?.availabilityReason ?? "The selected wafer has no approved die-grid evidence."}</span></div> : <><div className="wafer-geometry-note"><span><b>Ø {geometry?.diameterMm ?? 300} mm</b> · {geometry?.grossDie?.toLocaleString() ?? "—"} gross dies</span><span>{viewMode === "parameter" ? `${parameterValues.length.toLocaleString()} measured dies · ${parameterMin.toFixed(3)} to ${parameterMax.toFixed(3)}` : `${geometry?.coordinateSource === "VEDA_TBL_CP_RAW" ? "Decoded VEDA RAW grid" : "Canonical die coordinates"} · ${geometry?.source ?? "geometry fallback"}`}</span></div>{viewMode === "parameter" && !hasParameterValues ? <div className="map-coverage-warning"><TriangleAlert size={15} /> No approved measurement values are available for the selected parameter on this wafer. The map remains a bin-result view until a supported parameter is selected.</div> : null}<div className="wafer-viewport"><svg className="wafer-svg" viewBox="0 0 360 360" role="img" aria-label="300 mm wafer die grid"><defs><clipPath id="wafer-edge"><circle cx="180" cy="180" r="145" /></clipPath></defs><circle className="wafer-body" cx="180" cy="180" r="145" /><path className="wafer-notch" d="M165 323 L180 340 L195 323" /><g clipPath="url(#wafer-edge)" transform={`translate(180 180) scale(${zoom}) translate(-180 -180)`}>{dies.map((die) => { const x = originX + (die.x - xMin) * cell; const y = 360 - originY - (die.y - yMin + 1) * cell; const selected = selectedDie?.x === die.x && selectedDie?.y === die.y; return <rect key={`${die.x}-${die.y}-${die.softBin}`} data-testid={`die-${die.x}-${die.y}`} x={x} y={y} width={Math.max(.8, cell * .94)} height={Math.max(.8, cell * .94)} rx={Math.min(1.4, cell / 6)} fill={fillFor(die)} stroke={selected ? "#f9fbff" : "rgba(5,17,27,.62)"} strokeWidth={selected ? Math.max(1.4, cell * .22) : Math.max(.25, cell * .06)} className="wafer-die" onClick={() => onSelectDie(die)}><title>{`X ${die.x} · Y ${die.y} · ${viewMode === "parameter" ? `value ${die.measuredValue ?? "—"}` : die.pass ? "Pass" : `SB ${die.softBin}`}`}</title></rect>; })}</g><circle className="wafer-rim" cx="180" cy="180" r="145" /></svg></div>{geometry?.isPartial ? <div className="map-coverage-warning"><TriangleAlert size={15} /> Partial spatial coverage: {dies.length.toLocaleString()} decoded dies of {geometry.grossDie.toLocaleString()} gross dies. Use the grid for observed-pattern review only.</div> : null}</>}<div className="map-axis"><span>Y {yMax}</span><span>Y {yMin}</span><span>X {xMin} → {xMax} · click a die to inspect</span></div></article><article className="analysis-card die-inspector"><p className="analysis-eyebrow">DIE INSPECTOR</p>{selectedDie ? <><h2>X {selectedDie.x} · Y {selectedDie.y}</h2><span className={selectedDie.pass ? "result-pass" : "result-fail"}>{selectedDie.pass ? "Pass" : "Fail"}</span><dl><div><dt>Soft / hard bin</dt><dd>{selectedDie.softBin} / {selectedDie.hardBin}</dd></div><div><dt>{waferMap?.parameter?.code ?? "Measured value"}</dt><dd>{selectedDie.measuredValue ?? "—"}</dd></div><div><dt>Direction</dt><dd>{selectedDie.failDirection ?? "—"}</dd></div><div><dt>Source layer</dt><dd>{selectedDie.source ?? "canonical"}</dd></div><div><dt>Pattern context</dt><dd>{scenarioLabel[wafer?.scenario ?? ""] ?? "—"}</dd></div></dl></> : <div className="inspector-empty"><SlidersHorizontal size={28} /><b>Select any die</b><span>The inspected die will display its bins, measurement, and pass/fail evidence.</span></div>}</article></div>;
}

function SpatialPatternModule({ patterns, reason, selectedWaferKey, onInspect, onCompare }: { patterns: SpatialPattern[]; reason: string | null; selectedWaferKey?: number; onInspect: (waferKey: number) => void; onCompare: (waferKey: number) => void }) { if (!patterns.length) return <section className="analysis-card spatial-pattern-empty"><p className="analysis-eyebrow">SPATIAL PATTERN EVIDENCE</p><h2>Coordinate-derived pattern classification is unavailable</h2><p>{reason ?? "The active cohort has no approved canonical die coordinates. Available VEDA RAW maps remain inspectable individually, but no pattern class is inferred from incomplete or absent coordinates."}</p></section>; return <section className="analysis-card spatial-patterns"><CardTitle eyebrow="MULTI-WAFER SPATIAL ANALYSIS" title="Coordinate-derived pattern queue" /><p>Patterns are deterministic screening labels computed only from approved canonical die coordinates. Inspect each wafer map before assigning a process cause.</p><div className="spatial-pattern-list">{patterns.slice(0, 12).map((item) => <div key={item.waferKey} className={selectedWaferKey === item.waferKey ? "selected" : ""}><div><span className="scenario-pill tone-sky">{item.pattern.replaceAll("_", " ")}</span><b>{item.lotId} · {item.waferId}</b><small>{item.failDie.toLocaleString()} fails / {item.dieCount.toLocaleString()} observed dies · {Math.round(item.confidence * 100)}% confidence</small></div><div className="spatial-pattern-actions"><button onClick={() => onInspect(item.waferKey)}>Inspect map</button><button onClick={() => onCompare(item.waferKey)}>Set reference</button></div></div>)}</div></section>; }

function CompareModule({ wafers, selected, reference, referenceWaferId, onReferenceChange, spatialPatterns }: { wafers: WaferSummary[]; selected?: WaferSummary; reference?: WaferSummary; referenceWaferId: string; onReferenceChange: (value: string) => void; spatialPatterns: SpatialPattern[] }) { const delta = (selected?.yield ?? 0) - (reference?.yield ?? 0); const selectedPattern = spatialPatterns.find((pattern) => pattern.waferKey === selected?.waferKey); const referencePattern = spatialPatterns.find((pattern) => pattern.waferKey === reference?.waferKey); return <div className="analysis-grid compare-grid"><article className="analysis-card compare-card"><CardTitle eyebrow="WAFER COMPARISON" title="Compare active wafer against reference" /><label className="reference-select">Reference wafer<select value={referenceWaferId} onChange={(event) => onReferenceChange(event.target.value)}>{wafers.map((wafer) => <option key={wafer.waferKey} value={String(wafer.waferKey)}>{wafer.lotId} · {wafer.waferId} · {scenarioLabel[wafer.scenario ?? ""] ?? "Unknown"}</option>)}</select></label><div className="comparison-columns"><ComparisonColumn label="Active" wafer={selected} /><div className="delta-block"><GitCompareArrows size={22} /><b className={delta >= 0 ? "positive" : "negative"}>{delta >= 0 ? "+" : ""}{(delta * 100).toFixed(1)} pts</b><span>yield delta</span></div><ComparisonColumn label="Reference" wafer={reference} /></div><div className="comparison-patterns"><span>Spatial pattern</span><b>{selectedPattern?.pattern.replaceAll("_", " ") ?? "No canonical pattern"}</b><GitCompareArrows size={14} /><b>{referencePattern?.pattern.replaceAll("_", " ") ?? "No canonical pattern"}</b></div></article><article className="analysis-card comparison-readout"><p className="analysis-eyebrow">READOUT</p><h2>{delta < -0.05 ? "Material yield separation detected" : "No material yield separation"}</h2><p>{selected && reference ? `${selected.waferId} is ${Math.abs(delta * 100).toFixed(1)} percentage points ${delta < 0 ? "below" : "above"} ${reference.waferId}. Use the map, bins, and observed spatial labels to substantiate the signature difference.` : "Choose wafers to compare."}</p><div><Target size={17} /><span>Comparison is restricted to the active approved data release.</span></div></article></div>; }

function ComparisonColumn({ label, wafer }: { label: string; wafer?: WaferSummary }) { return <div className="comparison-wafer"><span>{label}</span><b>{wafer?.waferId ?? "—"}</b><em>{scenarioLabel[wafer?.scenario ?? ""] ?? "—"}</em><strong>{wafer ? percent(wafer.yield) : "—"}</strong><small>{wafer ? `${wafer.goodDie}/${wafer.testedDie} good dies` : ""}</small></div>; }
function CardTitle({ eyebrow, title, action, onAction }: { eyebrow: string; title: string; action?: string; onAction?: () => void }) { return <div className="analysis-card-title"><div><p className="analysis-eyebrow">{eyebrow}</p><h2>{title}</h2></div>{action ? <button onClick={onAction}>{action}<ChevronRight size={15} /></button> : null}</div>; }
function LoadingConsole() { return <div className="analysis-loading"><Loader2 className="animate-spin" /><strong>Opening approved CP analysis release…</strong><span>Validating the release boundary and loading yield, bin, and wafer-map evidence.</span></div>; }
function ApprovedEmpty({ releaseKey }: { releaseKey: string }) { return <section className="analysis-empty"><DatabaseFallback /><div><p className="analysis-eyebrow">VERIFIED EMPTY ANALYSIS</p><h2>No approved wafer evidence is available</h2><p>Release {releaseKey} passed approval controls, but it currently contains no visible yield, bin, or wafer-map records. Refresh after the next approved materialization.</p></div></section>; }
function DatabaseFallback() { return <Layers3 size={30} />; }
