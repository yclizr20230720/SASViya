import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { buildCohortQuery, cohortFilterCount, readAppliedCohort, saveAppliedCohort, type CohortFilters, type FilterName } from "@/lib/cohort";
import { CheckCircle2, Database, Download, FileSearch, Filter, Loader2, RefreshCw, ShieldCheck, TableProperties } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

type ReleaseCatalog = { releases: Array<{ key: string; status: string; waferCount: number; partNumber: string; provenance: string; label: string }>; scope: string };
type FilterMetadata = { release: { key: string; status: string; snapshotHash: string | null }; fields: Record<FilterName, Array<{ value: string; lotCount: number }>>; semantics: { withinField: string; acrossFields: string; scope: string } };
type SelectionPreview = { release: { key: string; status: string }; pendingFilters: CohortFilters; lotCount: number; waferCount: number };
type QueryRow = { waferKey: number; part: string; part6: string; lotId: string; waferNo: number; waferId: string; testProgram: string; binDefName: string; testEqpid: string; cpProbecard: string; testVendor: string; month: string; week: string; measuredAt: string | null; passIndex: number; grossDie: number; testedDie: number; goodDie: number; yield: number; scenario: string | null; materializationHash: string };
type QueryRows = { release: { key: string; status: string; snapshotHash: string | null }; selection: { filters: CohortFilters; totalRowCount: number; returnedRowCount: number; reviewLimit: number; semantics: { withinField: string; acrossFields: string; scope: string } }; rows: QueryRow[] };

const filters: Array<{ key: FilterName; label: string; help: string }> = [
  { key: "part", label: "PART", help: "Device part number" }, { key: "part6", label: "PART6", help: "Six-character family" },
  { key: "lotId", label: "LOTID", help: "Manufacturing lot" }, { key: "testProgram", label: "TEST_PROGRAM", help: "CP program" },
  { key: "binDefName", label: "BIN_DEF_NAME", help: "Bin definition" }, { key: "testEqpid", label: "TEST_EQPID", help: "Test equipment" },
  { key: "cpProbecard", label: "CPPROBECARD", help: "Probe card" }, { key: "testVendor", label: "TEST_VENDOR", help: "Test house" },
  { key: "month", label: "MONTH", help: "YYYYMM" }, { key: "week", label: "WEEK", help: "YYYYWW" },
];

const percent = (value: number) => `${(value * 100).toFixed(1)}%`;

export default function DataQuery() {
  const initial = useMemo(() => readAppliedCohort(), []);
  const [catalog, setCatalog] = useState<ReleaseCatalog | null>(null);
  const [releaseKey, setReleaseKey] = useState(initial.releaseKey);
  const [metadata, setMetadata] = useState<FilterMetadata | null>(null);
  const [draftFilters, setDraftFilters] = useState<CohortFilters>(initial.filters);
  const [preview, setPreview] = useState<SelectionPreview | null>(null);
  const [results, setResults] = useState<QueryRows | null>(null);
  const [loading, setLoading] = useState(true);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [queryLoading, setQueryLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const query = () => buildCohortQuery(releaseKey, draftFilters);

  useEffect(() => {
    fetch("/api/v1/releases/approved/catalog")
      .then(async (response) => { if (!response.ok) throw new Error(`Release catalog request failed (${response.status}).`); return response.json() as Promise<ReleaseCatalog>; })
      .then((payload) => { setCatalog(payload); setReleaseKey((current) => current || payload.releases[0]?.key || ""); })
      .catch((cause) => setError(cause instanceof Error ? cause.message : "Release catalog request failed."));
  }, []);
  useEffect(() => {
    if (!releaseKey) return;
    setLoading(true); setPreview(null); setResults(null);
    fetch(`/api/v1/releases/approved/analysis/filters?${buildCohortQuery(releaseKey, {})}`)
      .then(async (response) => { if (!response.ok) throw new Error(`Filter metadata request failed (${response.status}).`); return response.json() as Promise<FilterMetadata>; })
      .then(setMetadata)
      .catch((cause) => setError(cause instanceof Error ? cause.message : "Filter metadata request failed."))
      .finally(() => setLoading(false));
  }, [releaseKey]);
  useEffect(() => {
    if (!releaseKey || !metadata) return;
    let active = true;
    const timeout = window.setTimeout(() => {
      setPreviewLoading(true);
      fetch(`/api/v1/releases/approved/analysis/preview?${query()}`)
        .then(async (response) => { if (!response.ok) throw new Error("Selection preview failed."); return response.json() as Promise<SelectionPreview>; })
        .then((payload) => { if (active) setPreview(payload); })
        .catch(() => { if (active) setPreview(null); })
        .finally(() => { if (active) setPreviewLoading(false); });
    }, 180);
    return () => { active = false; window.clearTimeout(timeout); };
  }, [releaseKey, metadata, JSON.stringify(draftFilters)]);

  const executeQuery = async () => {
    setQueryLoading(true); setError(null);
    try {
      const response = await fetch(`/api/v1/releases/approved/analysis/query-rows?${query()}&limit=100`);
      if (!response.ok) throw new Error(`Query execution failed (${response.status}).`);
      const payload = await response.json() as QueryRows;
      setResults(payload);
      saveAppliedCohort({ releaseKey, filters: draftFilters, appliedAt: new Date().toISOString() });
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Query execution failed."); }
    finally { setQueryLoading(false); }
  };
  const exportCsv = () => { window.location.assign(`/api/v1/releases/approved/analysis/query-rows?${query()}&limit=10000&format=csv`); };
  const selectedRelease = catalog?.releases.find((item) => item.key === releaseKey);
  const criteriaCount = cohortFilterCount(draftFilters);

  return <DashboardLayout requireAuth={false}><main className="query-page">
    <header className="query-header"><div className="query-title"><span><FileSearch size={21} /></span><div><p className="analysis-eyebrow">VEDA CP / GOVERNED DATA QUERY</p><h1>Define analysis dataset</h1><p>Choose approved release filters once, inspect the returned wafer-level records, then open any analysis workspace against the same applied cohort.</p></div></div><div className="query-header-actions"><label className="release-picker"><span>APPROVED RELEASE</span><select aria-label="Query source release" value={releaseKey} onChange={(event) => { setReleaseKey(event.target.value); setDraftFilters({}); }}>{catalog?.releases.map((release) => <option key={release.key} value={release.key}>{release.provenance.startsWith("simulated") ? "SIMULATION · " : "IMPORTED · "}{release.key} · {release.waferCount} wafers</option>)}</select></label><Button variant="outline" onClick={() => void executeQuery()} disabled={queryLoading || !releaseKey}>{queryLoading ? <Loader2 size={15} className="animate-spin" /> : <RefreshCw size={15} />} Run current query</Button></div></header>

    {selectedRelease?.provenance.startsWith("simulated") ? <section className="simulation-provenance"><Database size={18} /><div><strong>{selectedRelease.label}</strong><span>Synthetic provenance is retained in the release lineage and query result metadata.</span></div><span>{selectedRelease.waferCount} wafers</span></section> : null}
    <section className="query-governance"><ShieldCheck size={18} /><div><strong>Approved-release query boundary</strong><span>OR within a filter field · AND across fields · no unapproved or cross-release rows can enter the review or export.</span></div><span>{criteriaCount ? `${criteriaCount} draft criteria` : "Full approved release"}</span></section>
    <section className="query-filter-card"><div className="query-section-head"><div><p className="analysis-eyebrow">STEP 1 / DATASET DEFINITION</p><h2>Set governed VEDA selection criteria</h2><span>Filter options are read from the selected approved release only. The preview updates before execution.</span></div><div className="query-preview">{previewLoading ? <><Loader2 size={15} className="animate-spin" /> Calculating cohort</> : preview ? <><b>{preview.lotCount} lots</b><span>{preview.waferCount} wafers match</span></> : "Awaiting query"}</div></div><div className="query-filter-grid">{filters.map((field) => <label key={field.key} className="filter-field"><span><b>{field.label}</b><small>{field.help}</small></span><select aria-label={`Query filter ${field.label}`} multiple value={draftFilters[field.key] ?? []} disabled={loading || !metadata?.fields[field.key].length} onChange={(event) => { const values = Array.from(event.currentTarget.selectedOptions).map((option) => option.value); setDraftFilters((current) => ({ ...current, [field.key]: values })); }}>{metadata?.fields[field.key].map((option) => <option key={option.value} value={option.value}>{option.value} · {option.lotCount} lot{option.lotCount === 1 ? "" : "s"}</option>)}</select></label>)}</div><div className="query-actions"><p><Filter size={15} /> Analysis functions inherit the cohort only after <b>Execute query</b>.</p><div><Button variant="outline" onClick={() => setDraftFilters({})} disabled={!criteriaCount}>Clear criteria</Button><Button onClick={() => void executeQuery()} disabled={queryLoading || !releaseKey}>{queryLoading ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />} Execute query</Button></div></div></section>

    {error ? <section className="analysis-error"><strong>Data query is unavailable.</strong><span>{error}</span></section> : null}
    <section className="query-results-card"><div className="query-section-head"><div><p className="analysis-eyebrow">STEP 2 / ROW REVIEW</p><h2>Approved CP query result</h2><span>{results ? `Showing ${results.selection.returnedRowCount} of ${results.selection.totalRowCount} matching wafer-level records. The review view is capped at 100 rows.` : "Execute the selection to materialize the review dataset."}</span></div><div className="query-result-actions"><Button variant="outline" onClick={exportCsv} disabled={!results || !results.selection.totalRowCount}><Download size={15} /> Export query CSV</Button></div></div>{results ? <><div className="query-result-meta"><span><TableProperties size={15} /> Release <b>{results.release.key}</b></span><span>Snapshot {results.release.snapshotHash?.slice(0, 12) ?? "—"}</span><span>{criteriaCount} applied criteria</span><span>CSV export cap 10,000 rows</span></div><div className="review-table-wrap query-table"><table><thead><tr><th>Part / lot / wafer</th><th>Program / bin</th><th>Tester / probe</th><th>Measured</th><th>Good / tested</th><th>Yield</th><th>Pass</th><th>Evidence</th></tr></thead><tbody>{results.rows.map((row) => <tr key={row.waferKey}><td><b>{row.part}</b><small>{row.lotId} · {row.waferId}</small></td><td><b>{row.testProgram}</b><small>{row.binDefName}</small></td><td><b>{row.testEqpid}</b><small>{row.cpProbecard}</small></td><td>{row.measuredAt ? new Date(row.measuredAt).toLocaleDateString() : "—"}<small>{row.month} · {row.week}</small></td><td>{row.goodDie.toLocaleString()} / {row.testedDie.toLocaleString()}</td><td><b>{percent(row.yield)}</b></td><td>{row.passIndex}</td><td><small>{row.scenario ?? "Source-observed"}</small></td></tr>)}</tbody></table></div></> : <div className="query-empty"><TableProperties size={26} /><div><b>No executed review dataset yet</b><span>Select optional criteria and execute the query to show up to 100 approved wafer records.</span></div></div>}</section>
  </main></DashboardLayout>;
}
