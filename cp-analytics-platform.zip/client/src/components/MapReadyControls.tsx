import { Button } from "@/components/ui/button";
import { Map as MapIcon } from "lucide-react";

export type MapReadyCoverage = {
  coverage: { mapReadyWaferCount: number; scopedWaferCount: number; mapReadyShare: number };
  mapReadyWafers: Array<{ waferKey: number; waferId: string; lotId: string; yield: number; rawRowCount: number; observedDieCount: number; grossDie: number; testedDie: number }>;
};

type SelectedWafer = { waferKey: number; waferId: string } | undefined;

export function MapReadyControls({ coverage, loading, selectedWafer, currentMapUnavailable, onSelect }: { coverage: MapReadyCoverage | null; loading: boolean; selectedWafer: SelectedWafer; currentMapUnavailable: boolean; onSelect: (waferKey: number) => void }) {
  const mapReady = coverage?.mapReadyWafers ?? [];
  const currentMapReady = mapReady.some((wafer) => wafer.waferKey === selectedWafer?.waferKey);
  const suggested = mapReady[0];

  return <section className="map-ready-panel" aria-live="polite">
    <div className="map-ready-summary">
      <MapIcon size={18} />
      <div>
        <p className="analysis-eyebrow">MAP EVIDENCE COVERAGE</p>
        <strong>{loading ? "Checking approved raw-map coverage…" : coverage ? `${coverage.coverage.mapReadyWaferCount} / ${coverage.coverage.scopedWaferCount} wafers with RAW die grids` : "Map coverage could not be loaded"}</strong>
        <span>{currentMapUnavailable ? "The active wafer has no approved RAW die rows. Choose a map-ready wafer below." : currentMapReady ? "The active wafer has approved RAW die-grid evidence." : "Choose a mapped wafer to inspect observed die cells."}</span>
      </div>
    </div>
    {suggested ? <Button className="map-ready-primary" onClick={() => onSelect(suggested.waferKey)} disabled={loading || suggested.waferKey === selectedWafer?.waferKey}><MapIcon size={15} /> Inspect map-ready wafer {suggested.waferId}</Button> : null}
    <div className="map-ready-list">
      {mapReady.map((wafer) => <button key={wafer.waferKey} onClick={() => onSelect(wafer.waferKey)} className={wafer.waferKey === selectedWafer?.waferKey ? "selected" : ""}><b>{wafer.lotId} · {wafer.waferId}</b><span>{wafer.rawRowCount} RAW rows · {wafer.observedDieCount.toLocaleString()} observed dies</span></button>)}
    </div>
  </section>;
}
