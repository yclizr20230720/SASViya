# VEDA CP Analytics Platform

This repository contains the CP Analytics Platform source code for local development. The application combines a React + Vite + TypeScript interface with a Flask + SQLAlchemy API. The development database is MySQL-compatible; PostgreSQL remains the documented target for production cutover.

> The API exposes analysis data only from approved, analytics-ready releases. Imported CP data and explicitly labelled synthetic releases remain distinguishable through release provenance.

## Repository layout

| Path | Purpose |
|---|---|
| `client/` | React analysis console, Data Query page, component styling, and rendered tests. |
| `server/` | Vite/Flask serving integration and browser/API regression tests. |
| `backend/cp_platform/` | Flask application, configuration, repository queries, approved-release routes, and database access. |
| `backend/scripts/` | Import, seed, profile, reconciliation, and export utilities. |
| `backend/tests/` | Flask and reconciliation unit tests. |
| `database/migrations/` | MySQL-compatible logical schema migrations and migration notes. |
| `database/fixtures/` | Deterministic fixture SQL and manifest. |
| `docs/` | Verification, database materialization, and PostgreSQL cutover documentation. |
| `drizzle/` | Existing application-template migration metadata; CP application data uses `database/migrations/` and Flask scripts. |

## Local prerequisites

Install Node.js 22+, pnpm 10+, Python 3.11+, and either PostgreSQL 16+ or MySQL 8+/a MySQL-compatible service. For local development, MySQL-compatible configuration is supported through `CP_DATABASE_TARGET=builtin_mysql` and `DATABASE_URL`. PostgreSQL configuration uses `CP_DATABASE_TARGET=postgresql` and `CP_DATABASE_URL`.

## Quick start

```bash
pnpm install --frozen-lockfile
python3 -m venv .venv
. .venv/bin/activate                 # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r backend/requirements.txt

# Set values from config/local_environment.template in your shell or local secret loader.
export CP_DATABASE_TARGET=builtin_mysql
export DATABASE_URL='mysql://cp_user:change_me@127.0.0.1:3306/cp_analytics'

pnpm build:frontend
pnpm dev
```

The local app is served at `http://127.0.0.1:3000`. The `pnpm dev` command first builds the frontend, then serves the Flask API and compiled static application together.

## Database, releases, and development data

Apply the CP logical migrations in sequence from `database/migrations/`, using the procedure documented in [`database/migrations/README.md`](database/migrations/README.md). Development utilities are invoked with `PYTHONPATH=backend` and an explicit database target.

```bash
# Deterministic development release
CP_DATABASE_TARGET=builtin_mysql PYTHONPATH=backend python3 backend/scripts/seed_development.py

# Full 300 mm simulation release
CP_DATABASE_TARGET=builtin_mysql PYTHONPATH=backend python3 backend/scripts/seed_full_wafer_simulation.py

# CSV-profiled synthetic release
CP_DATABASE_TARGET=builtin_mysql PYTHONPATH=backend python3 backend/scripts/seed_csv_profiled_release.py

# Import supplied multi-table VEDA CP exports
CP_DATABASE_TARGET=builtin_mysql PYTHONPATH=backend python3 backend/scripts/import_real_cp_exports.py --help

# Validate reconciliation gates
CP_DATABASE_TARGET=builtin_mysql PYTHONPATH=backend python3 backend/scripts/verify_reconciliation.py
```

The database export ZIP is delivered separately from this source package. Restore it only into a controlled local development database, then validate its checksums and row counts using its manifest and restoration notes.

## Validation

```bash
pnpm check                 # TypeScript
pnpm test                  # Rendered, API, and browser workflows
pnpm test:backend          # Flask/reconciliation tests
pnpm build                 # Production frontend plus Python compilation
```

## Local handoff exclusions

The source handoff intentionally excludes `node_modules/`, `dist/`, `.git/`, `.manus/`, `.manus-logs/`, local environment files, caches, logs, Python bytecode, and editor metadata. These items are generated locally or may contain machine-specific state. No database passwords, API keys, or hosted-service tokens are included. `config/local_environment.template` contains names and placeholders only.

## PostgreSQL production cutover

Review [`docs/POSTGRESQL_CUTOVER.md`](docs/POSTGRESQL_CUTOVER.md) before connecting a production PostgreSQL target. The repository does not claim that the production cutover has already been performed.
