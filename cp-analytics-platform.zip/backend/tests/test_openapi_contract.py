from __future__ import annotations

import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
OPENAPI_SPEC = PROJECT_ROOT / "docs" / "openapi" / "approved-release-wafer-api.yaml"


class OpenApiContractTests(unittest.TestCase):
    def test_approved_release_openapi_contract_declares_required_response_and_gate_states(self) -> None:
        specification = OPENAPI_SPEC.read_text(encoding="utf-8")
        for required_fragment in (
            "openapi: 3.1.0",
            "/api/v1/releases/approved/wafers:",
            "operationId: listApprovedReleaseWafers",
            "enum: [approved, analytics_ready]",
            "'404':",
            "'503':",
        ):
            self.assertIn(required_fragment, specification)
