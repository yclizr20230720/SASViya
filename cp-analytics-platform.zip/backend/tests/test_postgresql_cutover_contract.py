from __future__ import annotations

import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CUTOVER_DOCUMENT = PROJECT_ROOT / "docs" / "POSTGRESQL_CUTOVER.md"


class PostgreSqlCutoverContractTests(unittest.TestCase):
    def test_cutover_document_declares_secret_tls_readiness_and_reconciliation_gates(self) -> None:
        document = CUTOVER_DOCUMENT.read_text(encoding="utf-8")
        for required_term in ("CP_DATABASE_URL", "TLS", "readiness", "reconciliation"):
            self.assertIn(required_term, document)
