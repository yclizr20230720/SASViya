from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "seed_full_wafer_simulation.py"
SPEC = importlib.util.spec_from_file_location("full_wafer_simulation", SCRIPT)
assert SPEC and SPEC.loader
simulation = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(simulation)


class FullWaferSimulationContractTests(unittest.TestCase):
    class ApprovalConnection:
        def __init__(self) -> None:
            self.statements: list[str] = []

        def execute(self, statement: object, parameters: object) -> None:
            self.statements.append(str(statement))

    def valid_reconciliation_inputs(self) -> tuple[list[dict[str, object]], list[dict[str, object]], list[dict[str, object]]]:
        geometry = [{"waferId": "SIM300MM-01", "xMin": 1, "xMax": 62, "yMin": 1, "yMax": 62, "dieCount": 3096}]
        yields = [{"waferId": "SIM300MM-01", "goodDie": 3000, "testedDie": 3096, "yield": 3000 / 3096}]
        bins = [{"waferId": "SIM300MM-01", "binTotal": 3096, "testedDie": 3096}]
        return geometry, yields, bins

    def test_circular_300mm_grid_has_expected_die_count_and_true_padding(self) -> None:
        cells = [(x, y) for y in range(simulation.GRID) for x in range(simulation.GRID) if simulation.on_wafer(x, y)]

        self.assertEqual(simulation.GRID, 64)
        self.assertEqual(len(cells), 3096)
        self.assertFalse(simulation.on_wafer(0, 0))
        self.assertTrue(simulation.on_wafer(31, 31))

    def test_scenarios_produce_distinct_veda_soft_bin_patterns(self) -> None:
        for scenario, expected_bin in (("edge_ring", 5), ("center_cluster", 10), ("diagonal_scratch", 20)):
            bins = [simulation.die_bin(scenario, x, y) for y in range(simulation.GRID) for x in range(simulation.GRID) if simulation.on_wafer(x, y)]
            self.assertIn(expected_bin, bins)
            self.assertIn(1, bins)

    def test_seed_requires_explicit_release_validation_rules_before_approval(self) -> None:
        content = SCRIPT.read_text(encoding="utf-8")
        for rule in ("GEOMETRY_BOUNDS", "WAFER_YIELD_RECONCILIATION", "WAFER_BIN_RECONCILIATION", "analytics_ready"):
            self.assertIn(rule, content)

    def test_invalid_bin_reconciliation_blocks_simulation_approval(self) -> None:
        geometry, yields, _ = self.valid_reconciliation_inputs()
        invalid_bins = [{"waferId": "SIM300MM-01", "binTotal": 3095, "testedDie": 3096}]

        with self.assertRaisesRegex(RuntimeError, "bin-total"):
            simulation.validate_full_wafer_reconciliation(3096, geometry, yields, invalid_bins, 64, 3096, 1)

    def test_invalid_geometry_reconciliation_blocks_simulation_approval(self) -> None:
        _, yields, bins = self.valid_reconciliation_inputs()
        invalid_geometry = [{"waferId": "SIM300MM-01", "xMin": 1, "xMax": 62, "yMin": 1, "yMax": 62, "dieCount": 3095}]

        with self.assertRaisesRegex(RuntimeError, "geometry"):
            simulation.validate_full_wafer_reconciliation(3096, invalid_geometry, yields, bins, 64, 3096, 1)

    def test_invalid_yield_reconciliation_blocks_simulation_approval(self) -> None:
        geometry, _, bins = self.valid_reconciliation_inputs()
        invalid_yields = [{"waferId": "SIM300MM-01", "goodDie": 3000, "testedDie": 3096, "yield": 0.99}]

        with self.assertRaisesRegex(RuntimeError, "yield"):
            simulation.validate_full_wafer_reconciliation(3096, geometry, invalid_yields, bins, 64, 3096, 1)

    def test_invalid_raw_to_canonical_count_blocks_simulation_approval(self) -> None:
        geometry, yields, bins = self.valid_reconciliation_inputs()

        with self.assertRaisesRegex(RuntimeError, "RAW-to-canonical"):
            simulation.validate_full_wafer_reconciliation(3096, geometry, yields, bins, 63, 3096, 1)

    def test_any_blocking_rule_prevents_the_analytics_ready_update(self) -> None:
        invalid_cases = []
        geometry, yields, bins = self.valid_reconciliation_inputs()
        invalid_cases.append((geometry, yields, [{"waferId": "SIM300MM-01", "binTotal": 1, "testedDie": 3096}], 64, 3096))
        invalid_cases.append(([{"waferId": "SIM300MM-01", "xMin": 1, "xMax": 62, "yMin": 1, "yMax": 62, "dieCount": 1}], yields, bins, 64, 3096))
        invalid_cases.append((geometry, [{"waferId": "SIM300MM-01", "goodDie": 3000, "testedDie": 3096, "yield": 0}], bins, 64, 3096))
        invalid_cases.append((geometry, yields, bins, 1, 3096))

        for invalid_geometry, invalid_yields, invalid_bins, raw_rows, canonical_dies in invalid_cases:
            with self.subTest(raw_rows=raw_rows, canonical_dies=canonical_dies):
                connection = self.ApprovalConnection()
                with self.assertRaises(RuntimeError):
                    simulation.approve_after_full_wafer_validation(
                        connection, "CPSIM-TEST", 1, "manifest", 3096,
                        invalid_geometry, invalid_yields, invalid_bins, raw_rows, canonical_dies, 1,
                    )
                self.assertEqual(connection.statements, [])
