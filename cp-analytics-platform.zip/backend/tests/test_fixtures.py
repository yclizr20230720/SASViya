from __future__ import annotations

import unittest

from cp_platform.fixtures import (
    APPROVED_RELEASE_KEY,
    FIXTURE_SEED,
    approved_fixture_wafers,
    build_fixture_wafers,
    scenario_ids,
)


class FixtureCatalogueTests(unittest.TestCase):
    def test_fixture_catalogue_is_deterministic_and_has_all_required_scenarios(self) -> None:
        self.assertEqual(FIXTURE_SEED, "veda-cp-dev-seed-20260823")
        self.assertEqual(APPROVED_RELEASE_KEY, "CPDEV-20260823-R1")
        self.assertEqual(
            scenario_ids(),
            {
                "baseline_good",
                "edge_ring",
                "center_cluster",
                "scratch",
                "site_anomaly",
                "parameter_shift",
                "retest_fail_flip",
                "bad_input_quarantine",
            },
        )
        self.assertEqual(build_fixture_wafers(), build_fixture_wafers())

    def test_quarantined_fixture_is_not_eligible_for_approved_release_views(self) -> None:
        self.assertEqual(len(build_fixture_wafers()), 10)
        self.assertEqual(len(approved_fixture_wafers()), 9)
        self.assertNotIn("bad_input_quarantine", {wafer.scenario_id for wafer in approved_fixture_wafers()})
