from __future__ import annotations

import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
FOUNDATION_MIGRATION = PROJECT_ROOT / "database" / "migrations" / "0001_cp_development_foundation.sql"
AUTHORIZATION_MIGRATION = PROJECT_ROOT / "database" / "migrations" / "0002_cp_authorization.sql"


class MigrationInventoryTests(unittest.TestCase):
    def test_foundation_migration_declares_every_veda_source_mirror(self) -> None:
        migration = FOUNDATION_MIGRATION.read_text(encoding="utf-8")
        source_tables = [
            "alarm", "batch", "batch_result", "bin_definition", "convert_set", "grossdie", "grossdie_hist",
            "hwbin_header", "hwbin_hist", "initcoor", "init_axis", "init_axis_hist", "lot", "lot_ptn_dtl",
            "lot_ptn_info", "lot_sum", "lot_sum_sync", "ptn_redefine", "raw", "raw_temp",
            "sample_rate_set_ol", "test_prog_old", "wafer", "wafer_bin", "wafer_ptn_dtl",
            "wafer_ptn_info", "wafer_sum", "zone",
        ]

        for table_name in source_tables:
            self.assertIn(f"source_veda_cp_{table_name}", migration)

    def test_migrations_define_all_required_logical_table_families(self) -> None:
        migration_text = FOUNDATION_MIGRATION.read_text(encoding="utf-8") + AUTHORIZATION_MIGRATION.read_text(encoding="utf-8")
        required_tables = [
            "ingest_ingestion_run", "ingest_validation_result", "governance_data_release",
            "governance_data_snapshot", "core_product", "core_lot", "core_wafer", "core_die",
            "core_die_measurement", "analytics_wafer_summary", "analytics_wafer_bin_summary",
            "analytics_analysis_run", "analytics_analysis_result", "authz_role", "authz_permission",
            "authz_role_permission", "authz_product_scope", "authz_user_product_scope",
        ]

        for table_name in required_tables:
            self.assertIn(table_name, migration_text)
