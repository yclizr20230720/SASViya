from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

from cp_platform import create_app  # noqa: E402
from cp_platform.config import Settings  # noqa: E402
from cp_platform.database import normalize_database_url  # noqa: E402


class HealthEndpointTests(unittest.TestCase):
    def test_liveness_is_available_without_database_configuration(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            client = create_app({"TESTING": True}).test_client()
            response = client.get("/api/v1/health/live")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), {"service": "cp-analytics-api", "status": "ok"})

    def test_readiness_requires_a_postgresql_connection_configuration(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            client = create_app({"TESTING": True}).test_client()
            response = client.get("/api/v1/health/ready")

        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.get_json()["checks"]["postgresql"], "missing")

    def test_readiness_reports_configured_postgresql_without_claiming_data_readiness(self) -> None:
        with patch.dict(
            os.environ,
            {"CP_DATABASE_URL": "postgresql+psycopg://cp_app:secret@db.local/cp_analytics"},
            clear=True,
        ), patch("cp_platform.routes.health.get_database_connection_status", return_value=(True, None)):
            client = create_app({"TESTING": True}).test_client()
            response = client.get("/api/v1/health/ready")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["checks"]["postgresql"], "reachable")
        self.assertEqual(response.get_json()["checks"]["approved_release_gate"], "enabled")

    def test_builtin_mysql_target_uses_the_managed_database_url(self) -> None:
        with patch.dict(
            os.environ,
            {
                "CP_DATABASE_TARGET": "builtin_mysql",
                "DATABASE_URL": "mysql://cp_app:secret@mysql.local/cp_analytics",
                "CP_DATABASE_URL": "postgresql+psycopg://ignored:secret@postgres.local/cp_analytics",
            },
            clear=True,
        ):
            settings = Settings.from_environment()

        self.assertEqual(settings.database_target, "builtin_mysql")
        self.assertEqual(settings.database_url, "mysql+pymysql://cp_app:secret@mysql.local/cp_analytics")

    def test_database_driver_description_never_returns_connection_credentials(self) -> None:
        with patch.dict(
            os.environ,
            {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://cp_app:secret@mysql.local/cp"},
            clear=True,
        ):
            client = create_app({"TESTING": True}).test_client()
            response = client.get("/api/v1/health/ready")

        self.assertNotIn("secret", response.get_json()["checks"]["database_driver"])
        self.assertNotIn("secret", response.get_json()["checks"]["database_error_class"] or "")

    def test_managed_mysql_ssl_json_is_passed_as_a_safe_driver_mapping(self) -> None:
        url, connect_args = normalize_database_url(
            'mysql+pymysql://cp_app:secret@mysql.local/cp?ssl={"rejectUnauthorized":true}'
        )

        self.assertNotIn("ssl", url.query)
        self.assertEqual(connect_args, {"ssl": {}})

    def test_approved_release_endpoint_refuses_uninitialized_storage(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            client = create_app({"TESTING": True}).test_client()
            response = client.get("/api/v1/releases/approved/wafers")

        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.get_json()["error"], "approved_release_store_unavailable")

    def test_root_never_reports_frontend_ready_before_the_vite_bundle_exists(self) -> None:
        with tempfile.TemporaryDirectory() as static_dir:
            with patch.dict(os.environ, {"CP_STATIC_DIR": static_dir}, clear=True):
                client = create_app({"TESTING": True}).test_client()
                response = client.get("/")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["status"], "frontend_not_built")
