from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

from cp_platform import create_app  # noqa: E402
from cp_platform.repositories import ReleaseNotFoundError, _classify_spatial_patterns, _descriptive_statistics, _pearson_correlation  # noqa: E402


class AnalysisApiTests(unittest.TestCase):
    def test_descriptive_statistics_and_correlation_are_deterministic(self) -> None:
        statistics = _descriptive_statistics([1.0, 2.0, 3.0, 4.0, 20.0])
        self.assertEqual(statistics["median"], 3.0)
        self.assertGreater(statistics["sigma3"], statistics["stddev"])
        self.assertGreater(statistics["sigma6"], statistics["sigma3"])
        self.assertEqual(statistics["shape"], "right_skewed")
        self.assertAlmostEqual(_pearson_correlation([(1, 2), (2, 4), (3, 6)]) or 0, 1.0)
        self.assertIsNone(_pearson_correlation([(1, 2), (2, 4)]))

    def test_coordinate_pattern_classifier_identifies_a_ring_like_edge_signature(self) -> None:
        rows = []
        for x_coord in range(-4, 5):
            for y_coord in range(-4, 5):
                radius = (x_coord * x_coord + y_coord * y_coord) ** 0.5
                if radius > 4:
                    continue
                rows.append({"wafer_key": 9001, "lot_id": "CPTEST", "wafer_id": "CPTEST-01", "x_coord": x_coord, "y_coord": y_coord, "pass_flag": radius < 3.2})
        result = _classify_spatial_patterns(rows)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["pattern"], "ring_like_edge_loss")
        self.assertGreaterEqual(result[0]["confidence"], 0.8)
        self.assertEqual(result[0]["source"], "canonical_die_coordinates")

    def test_overview_returns_repository_data_only_after_release_gate(self) -> None:
        payload = {"release": {"key": "CPDEV-20260823-R1"}, "summary": {"waferCount": 9}, "yieldByWafer": [], "binDistribution": [], "lotSummaries": []}
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_analysis_overview", return_value=payload):
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/overview?releaseKey=CPDEV-20260823-R1")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), payload)

    def test_overview_forwards_multiple_values_with_or_within_and_and_across_filter_semantics(self) -> None:
        payload = {"release": {"key": "CPREAL-EE48DB6DF97E-R4"}, "summary": {"waferCount": 2}, "selection": {"filters": {"part6": ["TMUW83", "TM1234"], "month": ["202509"]}}}
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_analysis_overview", return_value=payload) as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/overview?releaseKey=CPREAL-EE48DB6DF97E-R4&part6=TMUW83&part6=TM1234&month=202509")
        self.assertEqual(response.status_code, 200)
        repository.assert_called_once_with("mysql+pymysql://test:test@localhost/cp", "CPREAL-EE48DB6DF97E-R4", {"part6": ["TMUW83", "TM1234"], "month": ["202509"]})

    def test_filter_metadata_is_release_gated(self) -> None:
        payload = {"release": {"key": "CPREAL-EE48DB6DF97E-R4", "status": "analytics_ready"}, "fields": {"part": [{"value": "TM1234", "lotCount": 2}]}}
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_filter_metadata", return_value=payload) as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/filters?releaseKey=CPREAL-EE48DB6DF97E-R4")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), payload)
        repository.assert_called_once_with("mysql+pymysql://test:test@localhost/cp", "CPREAL-EE48DB6DF97E-R4")

    def test_preview_forwards_pending_filters_without_bypassing_the_release_gate(self) -> None:
        payload = {"release": {"key": "CPREAL-EE48DB6DF97E-R5", "status": "analytics_ready"}, "pendingFilters": {"part6": ["TMUW83"]}, "lotCount": 3, "waferCount": 19}
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_selection_preview", return_value=payload) as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/preview?releaseKey=CPREAL-EE48DB6DF97E-R5&part6=TMUW83")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), payload)
        repository.assert_called_once_with("mysql+pymysql://test:test@localhost/cp", "CPREAL-EE48DB6DF97E-R5", {"part6": ["TMUW83"]})

    def test_query_review_forwards_governed_filters_and_enforces_the_requested_bound(self) -> None:
        payload = {"release": {"key": "CPREAL-EE48DB6DF97E-R5", "status": "analytics_ready", "snapshotHash": "a" * 64}, "selection": {"filters": {"part6": ["TMUW83"]}, "totalRowCount": 101, "returnedRowCount": 100, "reviewLimit": 100}, "rows": [{"part": "TMUW83A", "lotId": "LOT-1", "waferId": "W-01", "yield": 0.95}]}
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_query_rows", return_value=payload) as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/query-rows?releaseKey=CPREAL-EE48DB6DF97E-R5&part6=TMUW83&limit=100")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), payload)
        repository.assert_called_once_with("mysql+pymysql://test:test@localhost/cp", "CPREAL-EE48DB6DF97E-R5", {"part6": ["TMUW83"]}, 100)

    def test_query_csv_export_returns_download_metadata_only_for_approved_repository_rows(self) -> None:
        payload = {"release": {"key": "CPDEV-QUERY-R1", "status": "analytics_ready", "snapshotHash": "a" * 64}, "selection": {"filters": {}, "totalRowCount": 1, "returnedRowCount": 1, "reviewLimit": 10000}, "rows": [{"part": "TMUW83A", "part6": "TMUW83", "lotId": "LOT-1", "waferNo": 1, "waferId": "W-01", "testProgram": "CP", "binDefName": "BIN", "testEqpid": "ATE", "cpProbecard": "PC", "testVendor": "VENDOR", "month": "202608", "week": "202634", "measuredAt": "2026-08-23T00:00:00", "passIndex": 1, "grossDie": 100, "testedDie": 100, "goodDie": 95, "yield": 0.95, "scenario": "baseline", "materializationHash": "b" * 64}]}
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_query_rows", return_value=payload) as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/query-rows?releaseKey=CPDEV-QUERY-R1&format=csv&limit=10000")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.mimetype, "text/csv")
        self.assertIn("attachment; filename=", response.headers["Content-Disposition"])
        self.assertEqual(response.headers["X-CP-Query-Total-Rows"], "1")
        csv_text = response.get_data(as_text=True)
        self.assertIn("# VEDA_CP_APPROVED_QUERY_EXPORT", csv_text)
        self.assertIn("# release_key,CPDEV-QUERY-R1", csv_text)
        self.assertIn("# scope,approved_release_only", csv_text)
        self.assertIn("# export_row_limit,10000", csv_text)
        self.assertIn("TMUW83A", csv_text)
        repository.assert_called_once_with("mysql+pymysql://test:test@localhost/cp", "CPDEV-QUERY-R1", {}, 10000)

    def test_query_review_rejects_an_unbounded_limit_before_repository_access(self) -> None:
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_query_rows") as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/query-rows?limit=10001")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.get_json()["error"], "invalid_query_limit")
        repository.assert_not_called()

    def test_engineering_insights_are_approved_release_scoped_and_forward_governed_filters(self) -> None:
        payload = {
            "release": {"key": "CPREAL-EE48DB6DF97E-R5", "status": "analytics_ready"},
            "yieldDimensions": {"byTester": [{"value": "T01", "waferCount": 2, "goodDie": 190, "testedDie": 200, "yield": 0.95}], "byProbeCard": [], "byPart": [], "byLot": []},
            "topFailBins": [{"softBin": 40, "hardBin": 0, "dieCount": 10}],
            "parameters": [],
            "retest": {"sessionCount": 2, "retestSessionCount": 0, "maxPassIndex": 1, "available": False},
            "availability": {"parameterStatistics": False, "specificationLimits": False, "processDefectCorrelation": False, "retestAnalysis": False},
        }
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_engineering_insights", return_value=payload) as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/engineering?releaseKey=CPREAL-EE48DB6DF97E-R5&part6=TMUW83&month=202509")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), payload)
        self.assertEqual(response.get_json()["topFailBins"][0]["hardBin"], 0)
        repository.assert_called_once_with("mysql+pymysql://test:test@localhost/cp", "CPREAL-EE48DB6DF97E-R5", {"part6": ["TMUW83"], "month": ["202509"]})

    def test_engineering_insights_reject_an_unapproved_or_unknown_release(self) -> None:
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_engineering_insights", side_effect=ReleaseNotFoundError("not approved")):
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/engineering?releaseKey=CPDEV-20260823-R0")
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.get_json()["error"], "approved_release_not_found")

    def test_lot_mosaic_forwards_the_approved_cohort_and_enforces_bounds(self) -> None:
        payload = {"release": {"key": "CPREAL-EE48DB6DF97E-R5", "status": "analytics_ready"}, "coverage": {"scopedWaferCount": 4, "mapReadyWaferCount": 2}, "pagination": {"offset": 2, "limit": 4, "hasMore": False}, "lots": [], "wafers": []}
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_lot_mosaic", return_value=payload) as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/lot-mosaic?releaseKey=CPREAL-EE48DB6DF97E-R5&part6=TMUW83&mosaicLotId=LOT-01&offset=2&limit=4")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), payload)
        repository.assert_called_once_with("mysql+pymysql://test:test@localhost/cp", "CPREAL-EE48DB6DF97E-R5", {"part6": ["TMUW83"]}, "LOT-01", 2, 4)
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True):
            invalid = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/lot-mosaic?offset=bad&limit=13")
        self.assertEqual(invalid.status_code, 400)
        self.assertEqual(invalid.get_json()["error"], "invalid_mosaic_bounds")

    def test_map_rejects_invalid_wafer_identifier_before_repository_query(self) -> None:
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_wafer_map") as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/wafer-map/bad%20id")
        self.assertEqual(response.status_code, 400)
        repository.assert_not_called()

    def test_map_returns_a_successful_availability_state_when_real_export_has_no_die_records(self) -> None:
        payload = {"releaseKey": "CPREAL-EE48DB6DF97E-R5", "wafer": {"waferId": "A12345.01", "lotId": "A12345.1"}, "mapAvailable": False, "availabilityReason": "No complete die-level raw-map records are available for this approved export wafer.", "dies": []}
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_wafer_map", return_value=payload):
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/wafer-map/A12345.01?releaseKey=CPREAL-EE48DB6DF97E-R5")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), payload)

    def test_map_forwards_a_valid_parameter_code_and_rejects_invalid_values(self) -> None:
        payload = {"releaseKey": "CPDEV-20260823-R1", "wafer": {"waferId": "CPDEV100-01", "lotId": "CPDEV100"}, "parameter": {"code": "CP_PARAM_001", "measuredDieCount": 100}, "mapAvailable": True, "dies": []}
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch("cp_platform.routes.approved_release.get_approved_wafer_map", return_value=payload) as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/wafer-map/CPDEV100-01?releaseKey=CPDEV-20260823-R1&parameterCode=CP_PARAM_001")
        self.assertEqual(response.status_code, 200)
        repository.assert_called_once_with("mysql+pymysql://test:test@localhost/cp", "CPDEV100-01", "CPDEV-20260823-R1", None, "CP_PARAM_001")
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True):
            invalid = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/analysis/wafer-map/CPDEV100-01?parameterCode=bad%20code")
        self.assertEqual(invalid.status_code, 400)
        self.assertEqual(invalid.get_json()["error"], "invalid_parameter_code")
