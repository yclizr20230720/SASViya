from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from scripts.import_real_cp_exports import parse_sections, table_name, yield_fraction


class RealImportContractTests(unittest.TestCase):
    def test_multitable_export_parser_preserves_table_context_and_row_width(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            export = Path(directory) / "real.csv"
            export.write_text(
                "TABLE,VEDA_TBL_CP_LOT_202608.csv\nFAB_NAME,LOTID,TEST_TYPE\nFAB12,LOT-R1,CP1\n"
                "TABLE,VEDA_TBL_CP_WAFER_SUM_202608.csv\nFAB_NAME,LOTID,TEST_TYPE,WAFERNO\nFAB12,LOT-R1,CP1,1\n",
                encoding="utf-8",
            )
            records, sections = parse_sections([export])

        self.assertEqual(sorted(sections), ["veda_tbl_cp_lot", "veda_tbl_cp_wafer_sum"])
        self.assertEqual(len(records), 2)
        self.assertTrue(all(record.valid_width for record in records))
        self.assertEqual(records[1].payload["WAFERNO"], "1")

    def test_yield_normalization_handles_percent_and_fraction_exports(self) -> None:
        self.assertEqual(yield_fraction({"YIELD": "99.6"}), 0.996)
        self.assertEqual(yield_fraction({"YIELD": "0.85"}), 0.85)
        self.assertEqual(table_name("VEDA_TBL_CP_LOT_202608.csv"), "veda_tbl_cp_lot")
