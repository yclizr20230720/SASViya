from __future__ import annotations

import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
RECONCILIATION_SCRIPT = PROJECT_ROOT / "backend" / "scripts" / "verify_reconciliation.py"


class ReconciliationContractTests(unittest.TestCase):
    def test_reconciliation_gate_contains_explicit_source_to_canonical_count_checks(self) -> None:
        script = RECONCILIATION_SCRIPT.read_text(encoding="utf-8")
        for check_name in ("source_header_count", "source_summary_count", "source_raw_to_die_count"):
            self.assertIn(check_name, script)
