from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch


BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

from cp_platform import create_app  # noqa: E402


class ApprovedReleaseEndpointTests(unittest.TestCase):
    def test_endpoint_returns_only_repository_supplied_approved_release_data(self) -> None:
        payload = {
            "release": {"key": "CPDEV-20260823-R1", "status": "analytics_ready", "approvedAt": "2026-08-23T00:00:00", "snapshotHash": "a" * 64},
            "wafers": [{"lotId": "CPDEV100", "waferNo": 1, "yield": 0.95}],
        }
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch(
            "cp_platform.routes.approved_release.list_approved_wafer_summaries", return_value=payload
        ):
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/wafers")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), payload)

    def test_endpoint_rejects_malformed_release_key_before_querying_data(self) -> None:
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch(
            "cp_platform.routes.approved_release.list_approved_wafer_summaries"
        ) as repository:
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/wafers?releaseKey=bad key")

        self.assertEqual(response.status_code, 400)
        repository.assert_not_called()

    def test_endpoint_returns_not_found_for_an_unapproved_or_missing_release(self) -> None:
        with patch.dict(os.environ, {"CP_DATABASE_TARGET": "builtin_mysql", "DATABASE_URL": "mysql://test:test@localhost/cp"}, clear=True), patch(
            "cp_platform.routes.approved_release.list_approved_wafer_summaries", side_effect=__import__("cp_platform.repositories", fromlist=["ReleaseNotFoundError"]).ReleaseNotFoundError()
        ):
            response = create_app({"TESTING": True}).test_client().get("/api/v1/releases/approved/wafers?releaseKey=CPDEV-404")

        self.assertEqual(response.status_code, 404)
