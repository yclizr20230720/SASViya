"""Fail closed unless the deterministic CP release passes every required data gate."""

from __future__ import annotations

from sqlalchemy import text

from cp_platform.config import Settings
from cp_platform.database import get_engine
from cp_platform.fixtures import APPROVED_RELEASE_KEY


def read_scalar(connection, statement: str, params: dict[str, object]) -> int | str:
    return connection.execute(text(statement), params).scalar_one()


def main() -> None:
    settings = Settings.from_environment()
    if settings.database_target != "builtin_mysql" or not settings.database_url:
        raise RuntimeError("Reconciliation requires the MySQL development database.")

    engine = get_engine(settings.database_url)
    with engine.connect() as connection:
        release_id = int(read_scalar(connection, "SELECT data_release_id FROM governance_data_release WHERE release_key=:key", {"key": APPROVED_RELEASE_KEY}))
        release_status = str(read_scalar(connection, "SELECT status FROM governance_data_release WHERE data_release_id=:release", {"release": release_id}))
        approved_wafers = int(read_scalar(connection, "SELECT COUNT(*) FROM analytics_wafer_summary WHERE data_release_id=:release", {"release": release_id}))
        canonical_dies = int(read_scalar(connection, "SELECT COUNT(*) FROM core_die d JOIN core_test_session s ON s.test_session_id=d.test_session_id WHERE s.data_release_id=:release", {"release": release_id}))
        source_wafer_headers = int(read_scalar(connection, "SELECT COUNT(*) FROM source_veda_cp_wafer WHERE fab_name='FAB1' AND lot_id LIKE 'CPDEV%' AND lot_id<>'CPDEV999'", {}))
        source_raw_rows = int(read_scalar(connection, "SELECT COUNT(*) FROM source_veda_cp_raw WHERE fab_name='FAB1' AND lot_id LIKE 'CPDEV%' AND lot_id<>'CPDEV999'", {}))
        source_wafer_summaries = int(read_scalar(connection, "SELECT COUNT(*) FROM source_veda_cp_wafer_sum WHERE fab_name='FAB1' AND lot_id LIKE 'CPDEV%'", {}))
        yield_mismatches = int(read_scalar(connection, "SELECT COUNT(*) FROM analytics_wafer_summary WHERE data_release_id=:release AND ABS(yield_value-good_die/tested_die)>0.000001", {"release": release_id}))
        bin_mismatches = int(read_scalar(connection, "SELECT COUNT(*) FROM (SELECT aws.wafer_summary_id FROM analytics_wafer_summary aws JOIN analytics_wafer_bin_summary abs ON abs.wafer_summary_id=aws.wafer_summary_id WHERE aws.data_release_id=:release GROUP BY aws.wafer_summary_id,aws.tested_die HAVING SUM(abs.bin_count)<>aws.tested_die) mismatches", {"release": release_id}))
        coordinate_mismatches = int(read_scalar(connection, "SELECT COUNT(*) FROM analytics_wafer_summary WHERE data_release_id=:release AND (map_x_min<>0 OR map_x_max<>9 OR map_y_min<>0 OR map_y_max<>9)", {"release": release_id}))
        missing_lineage = int(read_scalar(connection, "SELECT COUNT(*) FROM core_die d JOIN core_test_session s ON s.test_session_id=d.test_session_id WHERE s.data_release_id=:release AND (d.source_raw_row_id IS NULL OR d.coordinate_transform_revision_id IS NULL)", {"release": release_id}))
        quarantine_leak = int(read_scalar(connection, "SELECT COUNT(*) FROM analytics_wafer_summary aws JOIN core_wafer w ON w.wafer_key=aws.wafer_key JOIN core_lot l ON l.lot_key=w.lot_key WHERE aws.data_release_id=:release AND l.lot_id='CPDEV999'", {"release": release_id}))

    violations = {
        "release_state": release_status not in {"approved", "analytics_ready"},
        "approved_wafer_count": approved_wafers != 9,
        "source_header_count": source_wafer_headers != approved_wafers,
        "source_summary_count": source_wafer_summaries != approved_wafers,
        "source_raw_to_die_count": source_raw_rows * 10 != canonical_dies,
        "canonical_die_count": canonical_dies != approved_wafers * 100,
        "yield_reconciliation": yield_mismatches != 0,
        "bin_reconciliation": bin_mismatches != 0,
        "coordinate_bounds": coordinate_mismatches != 0,
        "source_lineage": missing_lineage != 0,
        "quarantine_isolation": quarantine_leak != 0,
    }
    failed = [rule for rule, violated in violations.items() if violated]
    if failed:
        raise RuntimeError(f"CP reconciliation failed: {', '.join(failed)}")

    print(
        "CP reconciliation passed "
        f"(release={APPROVED_RELEASE_KEY}, wafers={approved_wafers}, dies={canonical_dies}, status={release_status})."
    )


if __name__ == "__main__":
    main()
