"""Import multi-table VEDA CP exports into governed source and analysis tables.

The command is idempotent per source manifest. It preserves every accepted record in
the ingestion ledger, quarantines structurally invalid records, and creates an
analytics-ready release only after summary and lineage gates pass.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import sys
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

from sqlalchemy import text

from cp_platform.config import Settings
from cp_platform.database import get_engine


DEFAULT_FILES = [Path("/home/ubuntu/upload") / name for name in ("cp2.csv", "cp3.csv", "cp4.csv", "cp5.csv", "test.csv")]
TABLE_PATTERN = re.compile(r"^(VEDA_TBL_CP_[A-Z_]+)_\d+\.csv$", re.IGNORECASE)
DATE_FORMATS = ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S")


@dataclass(frozen=True)
class SourceRecord:
    table: str
    filename: str
    line_number: int
    payload: dict[str, str]
    raw: list[str]
    valid_width: bool


class MirrorStatementCollector:
    """Collect homogeneous source-mirror INSERT statements for one batched execute per table."""

    def __init__(self) -> None:
        self.statements: dict[str, tuple[Any, list[dict[str, Any]]]] = {}

    def execute(self, statement: Any, parameters: dict[str, Any]) -> None:
        key = str(statement)
        if key not in self.statements:
            self.statements[key] = (statement, [])
        self.statements[key][1].append(parameters)

    def flush(self, connection: Any) -> None:
        for statement, rows in self.statements.values():
            bulk_execute(connection, statement, rows)


def bulk_execute(connection: Any, statement: Any, rows: list[dict[str, Any]]) -> None:
    """Use PyMySQL executemany so one homogeneous INSERT becomes a multi-value statement."""
    if not rows:
        return
    raw_connection = connection.connection.driver_connection
    cursor = raw_connection.cursor()
    try:
        compiled_sql = str(statement.compile(dialect=connection.dialect))
        cursor.executemany(compiled_sql, rows)
    finally:
        cursor.close()


def insert_multi_values(connection: Any, table: str, columns: list[str], rows: list[dict[str, Any]], chunk_size: int = 96) -> None:
    """Insert JSON-heavy source rows in bounded multi-value statements to control managed-DB latency."""
    for offset in range(0, len(rows), chunk_size):
        chunk = rows[offset : offset + chunk_size]
        parameters: dict[str, Any] = {}
        value_groups: list[str] = []
        for row_number, row in enumerate(chunk):
            keys: list[str] = []
            for column in columns:
                parameter_key = f"{column}_{row_number}"
                keys.append(f":{parameter_key}")
                parameters[parameter_key] = row[column]
            value_groups.append(f"({','.join(keys)})")
        statement = text(f"INSERT INTO {table} ({','.join(columns)}) VALUES {','.join(value_groups)}")
        connection.execute(statement, parameters)


def table_name(export_name: str) -> str:
    match = TABLE_PATTERN.match(export_name.strip())
    if not match:
        raise ValueError(f"Unsupported VEDA table marker: {export_name}")
    return match.group(1).lower()


def parse_csv_line(line: str) -> list[str]:
    return next(csv.reader([line]))


def is_marker(row: list[str]) -> bool:
    return len(row) >= 2 and row[0].strip().upper() == "TABLE" and row[1].strip().upper().startswith("VEDA_TBL_CP_")


def looks_like_header(row: list[str]) -> bool:
    cells = [cell.strip() for cell in row if cell.strip()]
    return bool(cells) and sum(cell.replace("_", "").isalnum() and cell.upper() == cell for cell in cells) / len(cells) >= 0.8


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def row_hash(table: str, payload: dict[str, str]) -> str:
    canonical = json.dumps({"table": table, "payload": payload}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return sha256_bytes(canonical.encode("utf-8"))


def value(payload: dict[str, str], *names: str) -> str | None:
    for name in names:
        candidate = payload.get(name)
        if candidate is not None and candidate.strip() not in ("", "N/A", "NULL"):
            return candidate.strip()
    return None


def integer(payload: dict[str, str], *names: str) -> int | None:
    raw = value(payload, *names)
    if raw is None:
        return None
    try:
        return int(float(raw))
    except ValueError:
        return None


def decimal(payload: dict[str, str], *names: str) -> float | None:
    raw = value(payload, *names)
    if raw is None:
        return None
    try:
        return float(raw)
    except ValueError:
        return None


def yield_fraction(payload: dict[str, str]) -> float:
    """Normalize VEDA exports that represent yield as either 0..1 or 0..100."""
    imported = decimal(payload, "YIELD") or 0.0
    return imported / 100.0 if imported > 1 else imported


def parsed_datetime(payload: dict[str, str], *names: str) -> datetime | None:
    raw = value(payload, *names)
    if raw is None:
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(raw, fmt)
        except ValueError:
            pass
    return None


def parse_sections(paths: Iterable[Path]) -> tuple[list[SourceRecord], dict[str, list[dict[str, Any]]]]:
    headers: dict[str, list[str]] = {}
    sections: dict[str, list[dict[str, Any]]] = defaultdict(list)
    records: list[SourceRecord] = []
    active_table: str | None = None
    expecting_header = False

    for path in paths:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            for line_number, raw_line in enumerate(handle, start=1):
                if not raw_line.strip():
                    continue
                row = parse_csv_line(raw_line)
                if is_marker(row):
                    active_table = table_name(row[1])
                    expecting_header = True
                    sections[active_table].append({"filename": path.name, "marker_line": line_number, "export_name": row[1]})
                    continue
                if active_table is None:
                    continue
                if expecting_header:
                    if looks_like_header(row):
                        current = headers.get(active_table)
                        if current is not None and current != row:
                            raise ValueError(f"Conflicting header for {active_table} in {path.name}:{line_number}")
                        headers[active_table] = row
                        expecting_header = False
                        continue
                    expecting_header = False
                header = headers.get(active_table)
                if header is None:
                    records.append(SourceRecord(active_table, path.name, line_number, {}, row, False))
                    continue
                valid_width = len(row) == len(header)
                payload = dict(zip(header, row)) if valid_width else {}
                records.append(SourceRecord(active_table, path.name, line_number, payload, row, valid_width))
    return records, sections


def bin_counts(payload: dict[str, str]) -> dict[str, int]:
    return {str(index): amount for index in range(100) if (amount := integer(payload, f"BIN{index}")) not in (None, 0)}


def manifest(paths: Iterable[Path]) -> tuple[str, dict[str, str]]:
    hashes = {path.name: sha256_bytes(path.read_bytes()) for path in paths}
    return sha256_bytes(json.dumps(hashes, sort_keys=True).encode("utf-8")), hashes


def insert_source_mirror(connection: Any, record: SourceRecord, source_hash: str) -> None:
    p = record.payload
    common = {"payload": json.dumps(p, ensure_ascii=False), "source_hash": source_hash}
    if record.table == "veda_tbl_cp_lot":
        connection.execute(text("""INSERT INTO source_veda_cp_lot (fab_name,lot_id,test_type,part_number,measured_at,test_program,bin_def_name,test_eqp_id,probe_card,source_payload,source_hash)
        VALUES (:fab,:lot,:test_type,:part,:measured,:program,:bin_def,:eqp,:card,:payload,:source_hash)
        ON DUPLICATE KEY UPDATE source_payload=VALUES(source_payload),source_hash=VALUES(source_hash),measured_at=VALUES(measured_at)"""), {
            **common, "fab": value(p, "FAB_NAME") or "UNK", "lot": value(p, "LOTID") or "UNKNOWN", "test_type": value(p, "TEST_TYPE") or "UNKNOWN", "part": value(p, "PART"), "measured": parsed_datetime(p, "MEASURETIME"), "program": value(p, "TEST_PROGRAM"), "bin_def": value(p, "BIN_DEF_NAME"), "eqp": value(p, "TEST_EQPID"), "card": value(p, "CPPROBECARD"),
        })
    elif record.table == "veda_tbl_cp_wafer":
        connection.execute(text("""INSERT INTO source_veda_cp_wafer (fab_name,lot_id,test_type,wafer_no,wafer_id,part_number,measured_at,test_program,bin_def_name,test_eqp_id,probe_card,source_payload,source_hash)
        VALUES (:fab,:lot,:test_type,:wafer_no,:wafer_id,:part,:measured,:program,:bin_def,:eqp,:card,:payload,:source_hash)
        ON DUPLICATE KEY UPDATE wafer_id=VALUES(wafer_id),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"""), {
            **common, "fab": value(p, "FAB_NAME") or "UNK", "lot": value(p, "LOTID") or "UNKNOWN", "test_type": value(p, "TEST_TYPE") or "UNKNOWN", "wafer_no": integer(p, "WAFERNO") or 0, "wafer_id": value(p, "WAFERID"), "part": value(p, "PART"), "measured": parsed_datetime(p, "MEASURETIME"), "program": value(p, "TEST_PROGRAM"), "bin_def": value(p, "BIN_DEF_NAME"), "eqp": value(p, "TEST_EQPID"), "card": value(p, "CPPROBECARD"),
        })
    elif record.table == "veda_tbl_cp_wafer_sum":
        connection.execute(text("""INSERT INTO source_veda_cp_wafer_sum (fab_name,lot_id,test_type,wafer_no,range_index,wafer_id,gross_die,tested_die,good_die,yield_value,map_x_min,map_x_max,map_y_min,map_y_max,bin_counts,source_payload,source_hash)
        VALUES (:fab,:lot,:test_type,:wafer_no,:range_index,:wafer_id,:gross,:tested,:good,:yield_value,:xmin,:xmax,:ymin,:ymax,:bin_counts,:payload,:source_hash)
        ON DUPLICATE KEY UPDATE wafer_id=VALUES(wafer_id),gross_die=VALUES(gross_die),tested_die=VALUES(tested_die),good_die=VALUES(good_die),yield_value=VALUES(yield_value),map_x_min=VALUES(map_x_min),map_x_max=VALUES(map_x_max),map_y_min=VALUES(map_y_min),map_y_max=VALUES(map_y_max),bin_counts=VALUES(bin_counts),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"""), {
            **common, "fab": value(p, "FAB_NAME") or "UNK", "lot": value(p, "LOTID") or "UNKNOWN", "test_type": value(p, "TEST_TYPE") or "UNKNOWN", "wafer_no": integer(p, "WAFERNO") or 0, "range_index": integer(p, "RANGE_INDEX") or 0, "wafer_id": value(p, "WAFERID"), "gross": integer(p, "GROSS_DIE") or 0, "tested": integer(p, "NUM_TESTED_DIE") or 0, "good": integer(p, "NUM_GOOD_DIE", "NUM_FUNCTIONAL_DIE") or 0, "yield_value": yield_fraction(p), "xmin": integer(p, "TL_X_COORD"), "xmax": integer(p, "BR_X_COORD"), "ymin": integer(p, "TL_Y_COORD"), "ymax": integer(p, "BR_Y_COORD"), "bin_counts": json.dumps(bin_counts(p)),
        })
    elif record.table == "veda_tbl_cp_wafer_bin":
        connection.execute(text("""INSERT INTO source_veda_cp_wafer_bin (fab_name,lot_id,test_type,wafer_no,wafer_id,bin_no,bin_type,bin_count,source_payload,source_hash)
        VALUES (:fab,:lot,:test_type,:wafer_no,:wafer_id,:bin_no,:bin_type,:bin_count,:payload,:source_hash)
        ON DUPLICATE KEY UPDATE bin_count=VALUES(bin_count),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"""), {
            **common, "fab": value(p, "FAB_NAME") or "UNK", "lot": value(p, "LOTID") or "UNKNOWN", "test_type": value(p, "TEST_TYPE") or "UNKNOWN", "wafer_no": integer(p, "WAFERNO") or 0, "wafer_id": value(p, "WAFERID"), "bin_no": integer(p, "BIN_NO") or 0, "bin_type": value(p, "BIN_TYPE"), "bin_count": integer(p, "BIN_CNT") or 0,
        })
    elif record.table == "veda_tbl_cp_raw":
        connection.execute(text("""INSERT INTO source_veda_cp_raw (fab_name,lot_id,test_type,wafer_no,wafer_id,measured_at,y_coord,view_flag,bin_string,vi_string,bin_type_string,source_payload,source_hash)
        VALUES (:fab,:lot,:test_type,:wafer_no,:wafer_id,:measured,:y_coord,:view_flag,:bin_string,:vi_string,:bin_type_string,:payload,:source_hash)
        ON DUPLICATE KEY UPDATE source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"""), {
            **common, "fab": value(p, "FAB_NAME") or "UNK", "lot": value(p, "LOTID") or "UNKNOWN", "test_type": value(p, "TEST_TYPE") or "UNKNOWN", "wafer_no": integer(p, "WAFERNO") or 0, "wafer_id": value(p, "WAFERID"), "measured": parsed_datetime(p, "MEASURETIME"), "y_coord": integer(p, "Y_COORD") or 0, "view_flag": integer(p, "VIEW_FLAG"), "bin_string": value(p, "BIN_STR"), "vi_string": value(p, "VI_STR"), "bin_type_string": value(p, "BIN_TYPE_STR"),
        })
    elif record.table == "veda_tbl_cp_lot_sum":
        connection.execute(text("""INSERT INTO source_veda_cp_lot_sum (fab_name,lot_id,test_type,range_index,gross_die,tested_die,good_die,yield_value,bin_counts,source_payload,source_hash)
        VALUES (:fab,:lot,:test_type,:range_index,:gross,:tested,:good,:yield_value,:bin_counts,:payload,:source_hash)
        ON DUPLICATE KEY UPDATE source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"""), {
            **common, "fab": value(p, "FAB_NAME") or "UNK", "lot": value(p, "LOTID") or "UNKNOWN", "test_type": value(p, "TEST_TYPE") or "UNKNOWN", "range_index": integer(p, "RANGE_INDEX") or 0, "gross": integer(p, "GROSS_DIE") or 0, "tested": integer(p, "NUM_TESTED_DIE") or 0, "good": integer(p, "NUM_GOOD_DIE", "NUM_FUNCTIONAL_DIE") or 0, "yield_value": yield_fraction(p), "bin_counts": json.dumps(bin_counts(p)),
        })
    elif record.table == "veda_tbl_cp_zone":
        connection.execute(text("""INSERT INTO source_veda_cp_zone (fab_name,part6,lot_id,test_type,wafer_no,y_coord,zone_3c,zone_4c,zone_8p,zone_9s,zone_5s,zone_5w,zone_9w,source_payload,source_hash)
        VALUES (:fab,:part6,:lot,:test_type,:wafer_no,:y_coord,:z3,:z4,:z8,:z9,:z5s,:z5w,:z9w,:payload,:source_hash)
        ON DUPLICATE KEY UPDATE source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"""), {
            **common, "fab": value(p, "FAB_NAME") or "UNK", "part6": value(p, "PART6") or "UNKNOWN", "lot": value(p, "LOTID") or "UNKNOWN", "test_type": value(p, "TEST_TYPE") or "UNKNOWN", "wafer_no": integer(p, "WAFERNO") or 0, "y_coord": integer(p, "Y_COORD") or 0, "z3": value(p, "STR_3C"), "z4": value(p, "STR_4C"), "z8": value(p, "STR_8P"), "z9": value(p, "STR_9S"), "z5s": value(p, "STR_5S"), "z5w": value(p, "STR_5W"), "z9w": value(p, "STR_9W"),
        })


def persist_release_validation(connection: Any, release_id: int, rule_code: str, severity: str, passed: bool, evidence: dict[str, Any]) -> None:
    connection.execute(text("""INSERT INTO governance_release_validation (data_release_id,rule_code,severity,outcome,result_json)
    VALUES (:release,:rule,:severity,:outcome,:evidence)
    ON DUPLICATE KEY UPDATE severity=VALUES(severity),outcome=VALUES(outcome),result_json=VALUES(result_json),validated_at=NOW(6)"""), {
        "release": release_id,
        "rule": rule_code,
        "severity": severity,
        "outcome": "passed" if passed else "failed",
        "evidence": json.dumps(evidence, ensure_ascii=False),
    })


def reconcile_real_release(connection: Any, run_id: int, release_id: int, quarantined_records: int) -> int:
    expected_summaries = connection.execute(text("""SELECT COUNT(DISTINCT CONCAT_WS('|',ws.fab_name,ws.lot_id,ws.test_type,ws.wafer_no)) FROM source_veda_cp_wafer_sum ws
    JOIN ingest_source_record rs ON rs.source_hash=ws.source_hash AND rs.ingestion_run_id=:run AND rs.validation_status='accepted'
    JOIN source_veda_cp_wafer w ON w.fab_name=ws.fab_name AND w.lot_id=ws.lot_id AND w.test_type=ws.test_type AND w.wafer_no=ws.wafer_no
    JOIN ingest_source_record rw ON rw.source_hash=w.source_hash AND rw.ingestion_run_id=:run AND rw.validation_status='accepted'
    WHERE ws.tested_die>0 AND ws.good_die BETWEEN 0 AND ws.tested_die"""), {"run": run_id}).scalar_one()
    canonical_summaries = connection.execute(text("SELECT COUNT(*) FROM analytics_wafer_summary WHERE data_release_id=:release"), {"release": release_id}).scalar_one()
    persist_release_validation(connection, release_id, "source_canonical_wafer_count", "blocking", expected_summaries == canonical_summaries, {"expected_source_rows": expected_summaries, "canonical_rows": canonical_summaries})

    bad_yields = connection.execute(text("SELECT COUNT(*) FROM analytics_wafer_summary WHERE data_release_id=:release AND (yield_value < 0 OR yield_value > 1 OR good_die > tested_die OR tested_die <= 0)"), {"release": release_id}).scalar_one()
    persist_release_validation(connection, release_id, "yield_and_die_bounds", "blocking", bad_yields == 0, {"invalid_summary_rows": bad_yields})

    source_yield_variance = connection.execute(text("""SELECT COUNT(*) FROM source_veda_cp_wafer_sum ws
    JOIN ingest_source_record r ON r.source_hash=ws.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    WHERE ws.tested_die>0 AND ABS(ws.yield_value - (ws.good_die / ws.tested_die)) > 0.02"""), {"run": run_id}).scalar_one()
    persist_release_validation(connection, release_id, "source_yield_variance", "warning", source_yield_variance == 0, {"rows_using_derived_yield": source_yield_variance})

    overflow_bins = connection.execute(text("""SELECT COUNT(*) FROM (
      SELECT aws.wafer_summary_id FROM analytics_wafer_summary aws JOIN analytics_wafer_bin_summary abs ON abs.wafer_summary_id=aws.wafer_summary_id
      WHERE aws.data_release_id=:release GROUP BY aws.wafer_summary_id,aws.tested_die HAVING SUM(abs.bin_count) > aws.tested_die
    ) invalid_bin_totals"""), {"release": release_id}).scalar_one()
    persist_release_validation(connection, release_id, "bin_total_not_over_tested", "blocking", overflow_bins == 0, {"overflow_wafer_count": overflow_bins})

    invalid_coordinates = connection.execute(text("""SELECT COUNT(*) FROM analytics_wafer_summary
    WHERE data_release_id=:release AND (map_x_min > map_x_max OR map_y_min > map_y_max)"""), {"release": release_id}).scalar_one()
    persist_release_validation(connection, release_id, "coordinate_bounds", "blocking", invalid_coordinates == 0, {"invalid_coordinate_rows": invalid_coordinates})

    source_lot_count = connection.execute(text("""SELECT COUNT(*) FROM source_veda_cp_lot l
    JOIN ingest_source_record r ON r.source_hash=l.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'"""), {"run": run_id}).scalar_one()
    filter_lot_count = connection.execute(text("SELECT COUNT(*) FROM analytics_release_lot_filter WHERE data_release_id=:release"), {"release": release_id}).scalar_one()
    persist_release_validation(connection, release_id, "source_filter_lot_count", "blocking", source_lot_count == filter_lot_count, {"source_lots": source_lot_count, "filter_lots": filter_lot_count})

    blocking_quarantine = connection.execute(text("SELECT COUNT(*) FROM ingest_source_quarantine WHERE ingestion_run_id=:run AND severity='blocking'"), {"run": run_id}).scalar_one()
    persist_release_validation(connection, release_id, "quarantine_accounting", "blocking", blocking_quarantine == 0, {"quarantined_records": quarantined_records, "blocking_records": blocking_quarantine})

    failed = connection.execute(text("SELECT COUNT(*) FROM governance_release_validation WHERE data_release_id=:release AND severity='blocking' AND outcome='failed'"), {"release": release_id}).scalar_one()
    return int(failed)


def materialize_release(connection: Any, run_id: int, manifest_hash: str, release_key: str) -> tuple[int, int]:
    connection.execute(text("""INSERT INTO governance_data_release (release_key,ingestion_run_id,status,source_manifest_hash,approved_by,approved_at)
    VALUES (:key,:run,'pending_validation',:manifest,NULL,NULL) ON DUPLICATE KEY UPDATE status='pending_validation',source_manifest_hash=VALUES(source_manifest_hash)"""), {"key": release_key, "run": run_id, "manifest": manifest_hash})
    release_id = connection.execute(text("SELECT data_release_id FROM governance_data_release WHERE release_key=:key"), {"key": release_key}).scalar_one()

    # A product revision is tied to the real CP LOT's PART6. This prevents accidental collapse of distinct revisions.
    connection.execute(text("""INSERT INTO core_product (fab_name,part_number,product_revision)
    SELECT DISTINCT l.fab_name,COALESCE(NULLIF(l.part_number,''),'UNKNOWN'),COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(l.source_payload,'$.PART6')),''),'BASE')
    FROM source_veda_cp_lot l JOIN ingest_source_record r ON r.source_hash=l.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    ON DUPLICATE KEY UPDATE product_id=product_id"""), {"run": run_id})
    connection.execute(text("""INSERT INTO core_lot (product_id,fab_name,lot_id,test_type,measured_at)
    SELECT p.product_id,l.fab_name,l.lot_id,l.test_type,l.measured_at
    FROM source_veda_cp_lot l JOIN ingest_source_record r ON r.source_hash=l.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    JOIN core_product p ON p.fab_name=l.fab_name AND p.part_number=COALESCE(NULLIF(l.part_number,''),'UNKNOWN')
      AND p.product_revision=COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(l.source_payload,'$.PART6')),''),'BASE')
    ON DUPLICATE KEY UPDATE measured_at=VALUES(measured_at)"""), {"run": run_id})
    connection.execute(text("""INSERT INTO core_wafer (lot_key,wafer_no,wafer_id,source_wafer_row_id)
    SELECT cl.lot_key,w.wafer_no,w.wafer_id,w.source_row_id FROM source_veda_cp_wafer w
    JOIN ingest_source_record r ON r.source_hash=w.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    JOIN core_lot cl ON cl.fab_name=w.fab_name AND cl.lot_id=w.lot_id AND cl.test_type=w.test_type
    ON DUPLICATE KEY UPDATE wafer_id=VALUES(wafer_id),source_wafer_row_id=VALUES(source_wafer_row_id)"""), {"run": run_id})
    # Some exports provide a valid wafer summary without a matching VEDA_TBL_CP_WAFER header row.
    # Preserve those wafers as summary-derived records; no tester/probe metadata is invented.
    connection.execute(text("""INSERT INTO core_wafer (lot_key,wafer_no,wafer_id,source_wafer_row_id)
    SELECT cl.lot_key,ws.wafer_no,ws.wafer_id,NULL FROM source_veda_cp_wafer_sum ws
    JOIN ingest_source_record r ON r.source_hash=ws.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    JOIN core_lot cl ON cl.fab_name=ws.fab_name AND cl.lot_id=ws.lot_id AND cl.test_type=ws.test_type
    ON DUPLICATE KEY UPDATE wafer_id=COALESCE(core_wafer.wafer_id,VALUES(wafer_id))"""), {"run": run_id})
    connection.execute(text("""INSERT INTO core_test_session (data_release_id,wafer_key,test_program,tester_id,probe_card_id,measured_at,pass_index,source_raw_hash)
    SELECT :release,cw.wafer_key,w.test_program,w.test_eqp_id,w.probe_card,w.measured_at,1,w.source_hash FROM source_veda_cp_wafer w
    JOIN ingest_source_record r ON r.source_hash=w.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    JOIN core_lot cl ON cl.fab_name=w.fab_name AND cl.lot_id=w.lot_id AND cl.test_type=w.test_type
    JOIN core_wafer cw ON cw.lot_key=cl.lot_key AND cw.wafer_no=w.wafer_no
    ON DUPLICATE KEY UPDATE tester_id=VALUES(tester_id),probe_card_id=VALUES(probe_card_id),source_raw_hash=VALUES(source_raw_hash)"""), {"run": run_id, "release": release_id})
    connection.execute(text("""INSERT INTO core_test_session (data_release_id,wafer_key,test_program,tester_id,probe_card_id,measured_at,pass_index,source_raw_hash)
    SELECT :release,cw.wafer_key,NULL,NULL,NULL,NULL,1,ws.source_hash FROM source_veda_cp_wafer_sum ws
    JOIN ingest_source_record r ON r.source_hash=ws.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    JOIN core_lot cl ON cl.fab_name=ws.fab_name AND cl.lot_id=ws.lot_id AND cl.test_type=ws.test_type
    JOIN core_wafer cw ON cw.lot_key=cl.lot_key AND cw.wafer_no=ws.wafer_no
    ON DUPLICATE KEY UPDATE source_raw_hash=VALUES(source_raw_hash)"""), {"run": run_id, "release": release_id})
    connection.execute(text("""INSERT INTO core_coordinate_transform_revision (data_release_id,product_id,min_x,min_y,max_x,max_y,orientation_code)
    SELECT :release,p.product_id,0,0,COALESCE(MAX(ws.map_x_max),0),COALESCE(MAX(ws.map_y_max),0),'source_summary' FROM source_veda_cp_wafer_sum ws
    JOIN ingest_source_record r ON r.source_hash=ws.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    JOIN core_lot cl ON cl.fab_name=ws.fab_name AND cl.lot_id=ws.lot_id AND cl.test_type=ws.test_type JOIN core_product p ON p.product_id=cl.product_id
    GROUP BY p.product_id ON DUPLICATE KEY UPDATE max_x=VALUES(max_x),max_y=VALUES(max_y)"""), {"run": run_id, "release": release_id})
    result = connection.execute(text("""INSERT INTO analytics_wafer_summary (data_release_id,wafer_key,test_session_id,gross_die,tested_die,good_die,yield_value,map_x_min,map_x_max,map_y_min,map_y_max,materialization_hash)
    SELECT :release,cw.wafer_key,cts.test_session_id,ws.gross_die,ws.tested_die,ws.good_die,ws.good_die / NULLIF(ws.tested_die,0),
      COALESCE(ws.map_x_min,0),COALESCE(ws.map_x_max,0),COALESCE(ws.map_y_min,0),COALESCE(ws.map_y_max,0),ws.source_hash
    FROM source_veda_cp_wafer_sum ws JOIN ingest_source_record r ON r.source_hash=ws.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    JOIN core_lot cl ON cl.fab_name=ws.fab_name AND cl.lot_id=ws.lot_id AND cl.test_type=ws.test_type JOIN core_wafer cw ON cw.lot_key=cl.lot_key AND cw.wafer_no=ws.wafer_no
    JOIN core_test_session cts ON cts.data_release_id=:release AND cts.wafer_key=cw.wafer_key
    WHERE ws.tested_die>0 AND ws.good_die BETWEEN 0 AND ws.tested_die
    ON DUPLICATE KEY UPDATE gross_die=VALUES(gross_die),tested_die=VALUES(tested_die),good_die=VALUES(good_die),yield_value=VALUES(yield_value),materialization_hash=VALUES(materialization_hash)"""), {"run": run_id, "release": release_id})
    wafer_count = result.rowcount or 0
    connection.execute(text("""INSERT INTO analytics_wafer_bin_summary (wafer_summary_id,soft_bin_no,hard_bin_no,bin_count,bin_rate)
    SELECT aws.wafer_summary_id,wb.bin_no,NULL,wb.bin_count,wb.bin_count/NULLIF(aws.tested_die,0)
    FROM source_veda_cp_wafer_bin wb JOIN ingest_source_record r ON r.source_hash=wb.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    JOIN core_lot cl ON cl.fab_name=wb.fab_name AND cl.lot_id=wb.lot_id AND cl.test_type=wb.test_type JOIN core_wafer cw ON cw.lot_key=cl.lot_key AND cw.wafer_no=wb.wafer_no
    JOIN analytics_wafer_summary aws ON aws.data_release_id=:release AND aws.wafer_key=cw.wafer_key
    WHERE wb.bin_count >= 0 ON DUPLICATE KEY UPDATE bin_count=VALUES(bin_count),bin_rate=VALUES(bin_rate)"""), {"run": run_id, "release": release_id})
    connection.execute(text("""INSERT INTO analytics_release_lot_filter (data_release_id,lot_key,fab_name,part_number,part6,lot_id,test_program,bin_def_name,test_eqp_id,cp_probe_card,test_vendor,month_code,week_code)
    SELECT DISTINCT :release,cl.lot_key,l.fab_name,l.part_number,JSON_UNQUOTE(JSON_EXTRACT(l.source_payload,'$.PART6')),l.lot_id,l.test_program,l.bin_def_name,l.test_eqp_id,l.probe_card,
      JSON_UNQUOTE(JSON_EXTRACT(l.source_payload,'$.TEST_VENDOR')),JSON_UNQUOTE(JSON_EXTRACT(l.source_payload,'$.MONTH')),JSON_UNQUOTE(JSON_EXTRACT(l.source_payload,'$.WEEK'))
    FROM source_veda_cp_lot l JOIN ingest_source_record r ON r.source_hash=l.source_hash AND r.ingestion_run_id=:run AND r.validation_status='accepted'
    JOIN core_lot cl ON cl.fab_name=l.fab_name AND cl.lot_id=l.lot_id AND cl.test_type=l.test_type
    ON DUPLICATE KEY UPDATE test_program=VALUES(test_program),bin_def_name=VALUES(bin_def_name),test_eqp_id=VALUES(test_eqp_id),cp_probe_card=VALUES(cp_probe_card),test_vendor=VALUES(test_vendor),month_code=VALUES(month_code),week_code=VALUES(week_code)"""), {"run": run_id, "release": release_id})
    filter_count = connection.execute(text("SELECT COUNT(*) FROM analytics_release_lot_filter WHERE data_release_id=:release"), {"release": release_id}).scalar_one()
    if wafer_count == 0 or filter_count == 0:
        raise ValueError(f"Materialization gate failed: {wafer_count} wafer summaries and {filter_count} filterable lots")
    snapshot_hash = sha256_bytes(f"{manifest_hash}:{release_key}:real-cp-v1".encode("utf-8"))
    connection.execute(text("INSERT INTO governance_data_snapshot (data_release_id,snapshot_hash,transform_version) VALUES (:release,:snapshot,'real-cp-v1') ON DUPLICATE KEY UPDATE snapshot_hash=VALUES(snapshot_hash)"), {"release": release_id, "snapshot": snapshot_hash})
    return release_id, filter_count


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release-key", default=None)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("files", nargs="*", type=Path, default=DEFAULT_FILES)
    args = parser.parse_args([argument for argument in sys.argv[1:] if argument != "--"])
    paths = args.files
    if any(not path.exists() for path in paths):
        missing = [str(path) for path in paths if not path.exists()]
        raise SystemExit(f"Missing source exports: {', '.join(missing)}")
    records, sections = parse_sections(paths)
    manifest_hash, file_hashes = manifest(paths)
    release_key = args.release_key or f"CPREAL-{manifest_hash[:12].upper()}"
    summary = {"release_key": release_key, "manifest_hash": manifest_hash, "records": len(records), "tables": sorted(sections)}
    if args.dry_run:
        print(json.dumps(summary, indent=2))
        return
    database_url = Settings.from_environment().database_url
    if not database_url:
        raise SystemExit("DATABASE_URL is required")
    engine = get_engine(database_url)
    print(f"[import] parsed {len(records)} logical source rows across {len(sections)} VEDA tables", flush=True)
    with engine.begin() as connection:
        existing = connection.execute(text("SELECT data_release_id FROM governance_data_release WHERE release_key=:key"), {"key": release_key}).scalar_one_or_none()
        if existing:
            print(json.dumps({**summary, "release_id": existing, "status": "already_imported"}, indent=2))
            return
        connection.execute(text("INSERT INTO ingest_ingestion_run (source_system,parser_version,status,source_manifest_hash,initiated_by) VALUES ('user_cp_csv','real-cp-v1','started',:manifest,'project-owner')"), {"manifest": manifest_hash})
        run_id = connection.execute(text("SELECT LAST_INSERT_ID()")).scalar_one()
        file_ids: dict[str, int] = {}
        for path in paths:
            section_json = json.dumps([item for entries in sections.values() for item in entries if item["filename"] == path.name])
            connection.execute(text("INSERT INTO ingest_source_file (ingestion_run_id,original_filename,content_sha256,byte_count,table_sections_json) VALUES (:run,:name,:hash,:bytes,:sections)"), {"run": run_id, "name": path.name, "hash": file_hashes[path.name], "bytes": path.stat().st_size, "sections": section_json})
            file_ids[path.name] = connection.execute(text("SELECT LAST_INSERT_ID()")).scalar_one()
        print("[import] registered immutable source-file manifests", flush=True)
        accepted = quarantined = duplicates = 0
        accepted_records: list[tuple[SourceRecord, str]] = []
        ledger_rows: list[dict[str, object]] = []
        seen_records: set[tuple[str, str]] = set()
        for record in records:
            raw_payload = record.payload or {"raw": record.raw}
            record_digest = row_hash(record.table, raw_payload)
            dedupe_key = (record.table, record_digest)
            if dedupe_key in seen_records:
                duplicates += 1
                continue
            seen_records.add(dedupe_key)
            if not record.valid_width:
                quarantined += 1
                connection.execute(text("INSERT INTO ingest_source_quarantine (ingestion_run_id,source_file_id,source_table_name,source_line_number,rule_code,severity,details,raw_payload) VALUES (:run,:file,:table,:line,'row_width_mismatch','warning',:details,:raw)"), {"run": run_id, "file": file_ids[record.filename], "table": record.table, "line": record.line_number, "details": json.dumps({"observed_columns": len(record.raw)}), "raw": json.dumps(raw_payload)})
                continue
            accepted += 1
            accepted_records.append((record, record_digest))
            ledger_rows.append({"run": run_id, "file": file_ids[record.filename], "table": record.table, "line": record.line_number, "payload": json.dumps(record.payload, ensure_ascii=False), "hash": record_digest, "status": "accepted"})
        insert_multi_values(connection, "ingest_source_record", ["ingestion_run_id", "source_file_id", "source_table_name", "source_line_number", "source_payload", "source_hash", "validation_status"], [
            {"ingestion_run_id": row["run"], "source_file_id": row["file"], "source_table_name": row["table"], "source_line_number": row["line"], "source_payload": row["payload"], "source_hash": row["hash"], "validation_status": row["status"]}
            for row in ledger_rows
        ])
        print(f"[import] recorded {accepted} accepted rows, {quarantined} quarantined rows, and {duplicates} duplicate rows", flush=True)
        mirror_collector = MirrorStatementCollector()
        for record, record_digest in accepted_records:
            insert_source_mirror(mirror_collector, record, record_digest)
        mirror_collector.flush(connection)
        print(f"[import] wrote {len(mirror_collector.statements)} source mirror batches", flush=True)
        connection.execute(text("UPDATE ingest_ingestion_run SET status='validated' WHERE ingestion_run_id=:run"), {"run": run_id})
        print("[import] running canonical materialization and release gates", flush=True)
        release_id, filter_count = materialize_release(connection, run_id, manifest_hash, release_key)
        failed_rules = reconcile_real_release(connection, run_id, release_id, quarantined)
        status = "analytics_ready" if failed_rules == 0 else "rejected"
        if status == "analytics_ready":
            connection.execute(text("UPDATE governance_data_release SET status='analytics_ready',approved_by='real-cp-import-gate',approved_at=NOW(6) WHERE data_release_id=:release"), {"release": release_id})
            connection.execute(text("UPDATE ingest_ingestion_run SET status='published',completed_at=NOW(6) WHERE ingestion_run_id=:run"), {"run": run_id})
        else:
            connection.execute(text("UPDATE governance_data_release SET status='rejected',approved_by=NULL,approved_at=NULL WHERE data_release_id=:release"), {"release": release_id})
            connection.execute(text("UPDATE ingest_ingestion_run SET status='failed',completed_at=NOW(6) WHERE ingestion_run_id=:run"), {"run": run_id})
    print(json.dumps({**summary, "ingestion_run_id": run_id, "release_id": release_id, "accepted_records": accepted, "quarantined_records": quarantined, "duplicate_records": duplicates, "filterable_lots": filter_count, "failed_blocking_rules": failed_rules, "status": status}, indent=2))


if __name__ == "__main__":
    main()
