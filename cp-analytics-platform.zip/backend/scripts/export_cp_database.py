"""Export the CP development database into a portable schema-and-data ZIP package.

The exporter writes MySQL-compatible DDL, table CSV/JSONL snapshots, release provenance,
row-count evidence, and restore notes. It deliberately excludes only non-CP identity data
(`users`) so that CP records can be shared without exposing project-owner account details.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import zipfile
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

from sqlalchemy import text

from cp_platform.config import Settings
from cp_platform.database import get_engine


EXCLUDED_DATA_TABLES = {"users"}


def safe_name(value: str) -> str:
    if not value.replace("_", "").isalnum():
        raise ValueError(f"Unexpected database object name: {value}")
    return value


def json_default(value: object) -> object:
    if isinstance(value, (datetime,)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, bytes):
        return value.hex()
    return str(value)


def checksum(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_readme(output_dir: Path, package_name: str) -> None:
    (output_dir / "README.md").write_text(
        "# CP Analytics Database Export\n\n"
        f"Package: `{package_name}`\n\n"
        "This package is a point-in-time export of the MySQL-compatible CP development database. "
        "It contains MySQL DDL in `schema/schema.sql`, one CSV and one JSONL snapshot for every exported CP table, "
        "row-count and checksum evidence in `manifest.json`, and `releases.csv` for approved/rejected release provenance.\n\n"
        "> Imported and synthetic releases remain separate. Synthetic releases are explicitly labelled in the governance and ingestion tables.\n\n"
        "## Restore guidance\n\n"
        "Create an empty MySQL-compatible schema, apply `schema/schema.sql`, then load the data files in dependency order. "
        "`data/*.jsonl` preserves JSON/text values exactly and is the recommended input for a controlled restoration script; "
        "`data/*.csv` provides spreadsheet-friendly inspection. Validate `table_row_counts.csv` after loading.\n\n"
        "## Deliberately excluded data\n\n"
        "The schema includes every table, but rows from the non-CP `users` table are excluded to avoid exporting project-owner identity data. "
        "All CP source, canonical, analytics, ingestion, governance, and authorization-scope records are exported.\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Export CP development DB schema and materialized CP data.")
    parser.add_argument("--output-root", type=Path, default=Path("/home/ubuntu/exports"))
    parser.add_argument("--package-name", default=None)
    args = parser.parse_args()
    settings = Settings.from_environment()
    if settings.database_target != "builtin_mysql" or not settings.database_url:
        raise RuntimeError("The export requires the configured MySQL-compatible CP development database.")

    generated_at = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    package_name = args.package_name or f"cp_analytics_database_export_{generated_at}"
    output_dir = args.output_root / package_name
    if output_dir.exists():
        shutil.rmtree(output_dir)
    schema_dir = output_dir / "schema"
    data_dir = output_dir / "data"
    schema_dir.mkdir(parents=True)
    data_dir.mkdir()

    engine = get_engine(settings.database_url)
    table_evidence: list[dict[str, object]] = []
    with engine.connect() as connection:
        table_rows = connection.execute(
            text("SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE' ORDER BY table_name")
        ).scalars().all()
        table_names = [safe_name(str(table)) for table in table_rows]
        schema_parts = ["-- CP Analytics Platform database schema export", f"-- Generated UTC: {generated_at}", "SET FOREIGN_KEY_CHECKS=0;", ""]
        for table_name in table_names:
            ddl_result = connection.execute(text(f"SHOW CREATE TABLE `{table_name}`")).mappings().one()
            create_statement = next(str(value) for key, value in ddl_result.items() if key.lower().startswith("create"))
            schema_parts.extend([f"-- TABLE: {table_name}", f"DROP TABLE IF EXISTS `{table_name}`;", create_statement + ";", ""])
        schema_parts.append("SET FOREIGN_KEY_CHECKS=1;")
        (schema_dir / "schema.sql").write_text("\n".join(schema_parts) + "\n", encoding="utf-8")

        for table_name in table_names:
            row_count = int(connection.execute(text(f"SELECT COUNT(*) FROM `{table_name}`")).scalar_one())
            if table_name in EXCLUDED_DATA_TABLES:
                table_evidence.append({"table": table_name, "rows": row_count, "exported": False, "reason": "non_cp_identity_data"})
                continue
            records = [dict(row) for row in connection.execute(text(f"SELECT * FROM `{table_name}`")).mappings().all()]
            columns = list(records[0].keys()) if records else [str(row[0]) for row in connection.execute(text(f"SHOW COLUMNS FROM `{table_name}`")).all()]
            csv_path = data_dir / f"{table_name}.csv"
            with csv_path.open("w", newline="", encoding="utf-8") as csv_file:
                writer = csv.DictWriter(csv_file, fieldnames=columns, extrasaction="ignore")
                writer.writeheader()
                for record in records:
                    writer.writerow({column: json.dumps(record.get(column), default=json_default, ensure_ascii=False) if isinstance(record.get(column), (dict, list)) else json_default(record.get(column)) if record.get(column) is not None else "" for column in columns})
            jsonl_path = data_dir / f"{table_name}.jsonl"
            with jsonl_path.open("w", encoding="utf-8") as jsonl_file:
                for record in records:
                    jsonl_file.write(json.dumps(record, default=json_default, ensure_ascii=False, separators=(",", ":")) + "\n")
            table_evidence.append({"table": table_name, "rows": row_count, "exported": True, "csv": str(csv_path.relative_to(output_dir)), "jsonl": str(jsonl_path.relative_to(output_dir))})

        releases = [dict(row) for row in connection.execute(text("SELECT r.release_key,r.status,r.source_manifest_hash,r.approved_at,ir.source_system,ir.parser_version FROM governance_data_release r JOIN ingest_ingestion_run ir ON ir.ingestion_run_id=r.ingestion_run_id ORDER BY r.data_release_id")).mappings().all()]
    with (output_dir / "releases.csv").open("w", newline="", encoding="utf-8") as release_file:
        fields = ["release_key", "status", "source_manifest_hash", "approved_at", "source_system", "parser_version"]
        writer = csv.DictWriter(release_file, fieldnames=fields)
        writer.writeheader()
        for release in releases:
            writer.writerow({field: json_default(release.get(field)) if release.get(field) is not None else "" for field in fields})
    with (output_dir / "table_row_counts.csv").open("w", newline="", encoding="utf-8") as evidence_file:
        writer = csv.DictWriter(evidence_file, fieldnames=["table", "rows", "exported", "reason", "csv", "jsonl"])
        writer.writeheader()
        writer.writerows(table_evidence)
    write_readme(output_dir, package_name)

    files = sorted(path for path in output_dir.rglob("*") if path.is_file())
    manifest = {
        "package": package_name,
        "generatedAtUtc": generated_at,
        "databaseTarget": "builtin_mysql_compatible",
        "scope": "all CP source, canonical, analytics, ingestion, governance, and authorization-scope table rows; schema for all tables",
        "excludedDataTables": sorted(EXCLUDED_DATA_TABLES),
        "tables": table_evidence,
        "releases": releases,
        "files": [{"path": str(path.relative_to(output_dir)), "bytes": path.stat().st_size, "sha256": checksum(path)} for path in files],
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, default=json_default, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    archive_path = args.output_root / f"{package_name}.zip"
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(path for path in output_dir.rglob("*") if path.is_file()):
            archive.write(path, path.relative_to(output_dir.parent))
    print(json.dumps({"outputDirectory": str(output_dir), "archive": str(archive_path), "tables": len(table_evidence), "releases": len(releases), "archiveBytes": archive_path.stat().st_size}, indent=2))


if __name__ == "__main__":
    main()
