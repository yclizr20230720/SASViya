"""Materialize a richer, explicitly synthetic CP release profiled from supplied VEDA CSV exports.

This script never modifies imported-release records. It reads the supplied CSV sections to
derive observed part, program, tester, probe-card, and bin-definition vocabulary, then
generates deterministic VEDA-compatible source rows and materializes them through the
same source -> canonical -> analytics model used by the application.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from sqlalchemy import text

from cp_platform.config import Settings
from cp_platform.database import get_engine
from import_real_cp_exports import DEFAULT_FILES, bulk_execute, parse_sections, value


RELEASE_KEY = "CPSYNCSV-EE48DB6DF97E-R1"
SEED_VERSION = "csv-profiled-veda-cp-v1"
FAB = "CSVPF"
TEST_TYPE = "CP1"
GRID = 12
RADIUS = 5.3
BIN_ROWS = ((1, 1, 1, "PASS"), (5, 2, 0, "EDGE_RING"), (10, 3, 0, "CENTER_CLUSTER"), (20, 4, 0, "SCRATCH"), (30, 5, 0, "CONTACT"), (40, 6, 0, "PARAMETRIC"))
PARAMETERS = (("CSVPROF_VTH", "Vth profile", "V", 4.0, 6.0), ("CSVPROF_IDDQ", "Iddq profile", "uA", 0.2, 1.6), ("CSVPROF_RON", "Ron profile", "ohm", 2.4, 4.8))
SCENARIOS = ("baseline", "edge_ring", "center_cluster", "scratch", "contact", "parametric_shift", "radial_gradient")


def digest(value_to_hash: object) -> str:
    return hashlib.sha256(str(value_to_hash).encode("utf-8")).hexdigest()


def scalar(connection: Any, statement: str, parameters: dict[str, object]) -> int:
    return int(connection.execute(text(statement), parameters).scalar_one())


def batched_execute(connection: Any, statement: Any, rows: list[dict[str, object]], batch_size: int = 750) -> None:
    """Use native multi-value batches for large deterministic die populations."""
    for offset in range(0, len(rows), batch_size):
        bulk_execute(connection, statement, rows[offset:offset + batch_size])


def insert_value_chunks(connection: Any, prefix: str, values: list[str], suffix: str, chunk_size: int = 700) -> None:
    """Send fixed, internally generated values as bounded multi-row statements."""
    for offset in range(0, len(values), chunk_size):
        connection.execute(text(prefix + ",".join(values[offset:offset + chunk_size]) + suffix))


def on_wafer(x_coord: int, y_coord: int) -> bool:
    center = (GRID - 1) / 2
    return (x_coord - center) ** 2 + (y_coord - center) ** 2 <= RADIUS**2


def die_bin(scenario: str, x_coord: int, y_coord: int, wafer_index: int) -> int:
    center = (GRID - 1) / 2
    radius = math.hypot(x_coord - center, y_coord - center)
    if scenario == "edge_ring" and radius >= 7.8:
        return 5
    if scenario == "center_cluster" and radius <= 3.1:
        return 10
    if scenario == "scratch" and abs(y_coord - x_coord + (wafer_index % 5) - 2) <= 0.55:
        return 20
    if scenario == "contact" and x_coord % 5 == wafer_index % 5 and y_coord % 3 == 0:
        return 30
    if scenario == "parametric_shift" and (x_coord - center) ** 2 + (y_coord - center) ** 2 <= 12:
        return 40
    return 1


def profile_values(records: list[Any], field: str, fallback: list[str]) -> list[str]:
    values = [value(record.payload, field) for record in records if record.valid_width]
    observed = sorted({item.strip() for item in values if item and item.strip()})
    return observed or fallback


def template_vocabulary(records: list[Any]) -> dict[str, list[str]]:
    return {
        "parts": profile_values(records, "PART", ["TMUW83", "TMVB24", "VP6388", "TM1234"]),
        "programs": profile_values(records, "TEST_PROGRAM", ["CSV_PROFILED_CP1"]),
        "binDefs": profile_values(records, "BIN_DEF_NAME", ["CSV_PROFILED_BIN_R1"]),
        "testers": profile_values(records, "TEST_EQPID", ["CSVPROF-ATE-01"]),
        "probeCards": profile_values(records, "CPPROBECARD", ["CSVPROF-PC-01"]),
    }


def parameter_values(scenario: str, x_coord: int, y_coord: int, lot_index: int, wafer_index: int) -> dict[str, tuple[float, str]]:
    center = (GRID - 1) / 2
    radius = math.hypot(x_coord - center, y_coord - center)
    baseline = 4.85 + ((x_coord - center) * 0.028) + ((y_coord - center) * 0.014) + lot_index * 0.045 + wafer_index * 0.018
    if scenario == "parametric_shift" and radius <= 3.5:
        baseline += 1.25
    if scenario == "radial_gradient":
        baseline += radius * 0.085
    iddq = 0.56 + (baseline - 4.85) * 0.42 + radius * 0.012 + (0.18 if scenario == "contact" and x_coord % 5 == wafer_index % 5 else 0)
    ron = 3.05 + (baseline - 4.85) * 0.68 + ((x_coord + y_coord) % 4) * 0.035
    return {
        "CSVPROF_VTH": (round(baseline, 5), "high" if baseline > 6 else "pass"),
        "CSVPROF_IDDQ": (round(iddq, 5), "high" if iddq > 1.6 else "pass"),
        "CSVPROF_RON": (round(ron, 5), "high" if ron > 4.8 else "pass"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="*", type=Path, default=DEFAULT_FILES)
    parser.add_argument("--release-key", default=RELEASE_KEY)
    args = parser.parse_args()
    if any(not source.exists() for source in args.files):
        missing = ", ".join(str(source) for source in args.files if not source.exists())
        raise SystemExit(f"Missing CSV input: {missing}")
    settings = Settings.from_environment()
    if settings.database_target != "builtin_mysql" or not settings.database_url:
        raise RuntimeError("CSV-profiled seed requires the configured MySQL-compatible development database.")

    records, sections = parse_sections(args.files)
    vocabulary = template_vocabulary(records)
    manifest_components = {source.name: digest(source.read_bytes()) for source in args.files}
    manifest_hash = digest(json.dumps({"seed": SEED_VERSION, "sources": manifest_components}, sort_keys=True))
    engine = get_engine(settings.database_url)
    lot_count = min(5, len(vocabulary["parts"]))
    generated: list[dict[str, object]] = []
    for lot_index in range(lot_count):
        part = vocabulary["parts"][lot_index % len(vocabulary["parts"])]
        lot_id = f"CSVPRF-{lot_index + 1:02d}-{part[:6].replace(' ', '')}"
        for wafer_no in range(1, 5):
            wafer_index = lot_index * 4 + wafer_no - 1
            generated.append({
                "lotIndex": lot_index,
                "lotId": lot_id,
                "part": part,
                "part6": part[:6].strip() or "CSVPRF",
                "waferNo": wafer_no,
                "waferId": f"{lot_id}.{wafer_no:02d}",
                "scenario": SCENARIOS[wafer_index % len(SCENARIOS)],
                "program": vocabulary["programs"][wafer_index % len(vocabulary["programs"])],
                "binDef": vocabulary["binDefs"][wafer_index % len(vocabulary["binDefs"])],
                "tester": vocabulary["testers"][wafer_index % len(vocabulary["testers"])],
                "probe": vocabulary["probeCards"][wafer_index % len(vocabulary["probeCards"])],
                "measuredAt": datetime(2025, 2, 12) + timedelta(days=lot_index * 19 + wafer_no * 2, hours=wafer_no),
            })

    cells = [(x_coord, y_coord) for y_coord in range(GRID) for x_coord in range(GRID) if on_wafer(x_coord, y_coord)]
    print(f"Preparing {args.release_key}: {len(generated)} CSV-profiled wafers, {len(cells)} dies per wafer", flush=True)
    with engine.begin() as connection:
        connection.execute(text("INSERT INTO ingest_ingestion_run (source_system,parser_version,status,source_manifest_hash,initiated_by) SELECT 'csv_profiled_synthetic_veda_cp',:parser,'validated',:manifest,'csv-profiled-seed' WHERE NOT EXISTS (SELECT 1 FROM ingest_ingestion_run WHERE source_manifest_hash=:manifest)"), {"parser": SEED_VERSION, "manifest": manifest_hash})
        run_id = scalar(connection, "SELECT ingestion_run_id FROM ingest_ingestion_run WHERE source_manifest_hash=:manifest", {"manifest": manifest_hash})
        connection.execute(text("INSERT INTO governance_data_release (release_key,ingestion_run_id,status,source_manifest_hash,approved_by,approved_at) VALUES (:key,:run,'pending_validation',:manifest,NULL,NULL) ON DUPLICATE KEY UPDATE ingestion_run_id=VALUES(ingestion_run_id),status='pending_validation',approved_by=NULL,approved_at=NULL"), {"key": args.release_key, "run": run_id, "manifest": manifest_hash})
        release_id = scalar(connection, "SELECT data_release_id FROM governance_data_release WHERE release_key=:key", {"key": args.release_key})
        connection.execute(text("INSERT INTO governance_data_snapshot (data_release_id,snapshot_hash,transform_version) VALUES (:release,:snapshot,:version) ON DUPLICATE KEY UPDATE snapshot_hash=VALUES(snapshot_hash),transform_version=VALUES(transform_version)"), {"release": release_id, "snapshot": digest(f"{manifest_hash}-snapshot"), "version": SEED_VERSION})

        connection.execute(text("DELETE abs FROM analytics_wafer_bin_summary abs JOIN analytics_wafer_summary aws ON aws.wafer_summary_id=abs.wafer_summary_id WHERE aws.data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE FROM analytics_wafer_summary WHERE data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE dm FROM core_die_measurement dm JOIN core_die d ON d.die_id=dm.die_id JOIN core_test_session s ON s.test_session_id=d.test_session_id WHERE s.data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE d FROM core_die d JOIN core_test_session s ON s.test_session_id=d.test_session_id WHERE s.data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE FROM core_test_session WHERE data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE FROM analytics_release_lot_filter WHERE data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE FROM core_parameter_version WHERE data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE FROM core_coordinate_transform_revision WHERE data_release_id=:release"), {"release": release_id})

        metadata = {"synthetic": True, "profiledFromManifest": manifest_hash, "sourceFiles": manifest_components, "sourceTables": sorted(sections), "seed": SEED_VERSION}
        parts = sorted({str(row["part"]) for row in generated})
        print("[profiled-seed] writing product, bin, and coordinate source dimensions", flush=True)
        for part in parts:
            bin_def = f"CSVPROF-{part[:6].replace(' ', '')}-BIN-R1"
            payload = json.dumps({**metadata, "part": part, "binDefinition": bin_def})
            connection.execute(text("INSERT INTO source_veda_cp_bin_definition (fab_name,part_number,bin_def_name,bin_number,bin_name,description_text,good_bin_flag,hard_bin_number,hard_bin_name,hard_good_bin_flag,source_payload,source_hash) VALUES (:fab,:part,:bin_def,:soft,:name,:name,:good,:hard,:name,:good,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), [{"fab": FAB, "part": part, "bin_def": bin_def, "soft": soft, "hard": hard, "good": good, "name": name, "payload": payload, "hash": digest(f"{manifest_hash}-bin-{part}-{soft}")} for soft, hard, good, name in BIN_ROWS])
            connection.execute(text("INSERT INTO source_veda_cp_grossdie (product_name,fab_name,gross_die,actual_die,source_payload,source_hash) VALUES (:part,:fab,:gross,:gross,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE gross_die=VALUES(gross_die),actual_die=VALUES(actual_die),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), {"part": part, "fab": FAB, "gross": len(cells), "payload": payload, "hash": digest(f"{manifest_hash}-gross-{part}")})
            connection.execute(text("INSERT INTO source_veda_cp_init_axis (fab_name,customer_id,test_fab_id,product_id,version_no,part_number,lb_axis_x,lb_axis_y,rt_axis_x,rt_axis_y,source_payload,source_hash) VALUES (:fab,'CSVPROF','CP','CSVPROF','1',:part,0,0,:max,:max,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), {"fab": FAB, "part": part, "max": GRID - 1, "payload": payload, "hash": digest(f"{manifest_hash}-axis-{part}")})
            connection.execute(text("INSERT INTO core_product (fab_name,part_number,product_revision) VALUES (:fab,:part,'CSV-PROFILED-R1') ON DUPLICATE KEY UPDATE product_id=LAST_INSERT_ID(product_id)"), {"fab": FAB, "part": part})

        source_lot_rows = []
        source_wafer_rows = []
        source_raw_rows = []
        source_summary_rows = []
        source_bin_rows = []
        per_wafer: list[dict[str, object]] = []
        for wafer_index, row in enumerate(generated):
            part = str(row["part"])
            bin_def = f"CSVPROF-{part[:6].replace(' ', '')}-BIN-R1"
            payload = json.dumps({"synthetic": True, "profiledFromManifest": manifest_hash, "seed": SEED_VERSION, "scenario": row["scenario"], "csvTemplate": {"part": part, "tester": row["tester"], "probeCard": row["probe"]}})
            common = {"fab": FAB, "lot": row["lotId"], "test": TEST_TYPE, "part": part, "measured": row["measuredAt"], "program": row["program"], "bin_def": bin_def, "tester": row["tester"], "probe": row["probe"], "payload": payload, "hash": digest(f"{manifest_hash}-{row['waferId']}")}
            if int(row["waferNo"]) == 1:
                source_lot_rows.append(common)
            source_wafer_rows.append({**common, "wafer_no": row["waferNo"], "wafer_id": row["waferId"]})
            counts = Counter(die_bin(str(row["scenario"]), x_coord, y_coord, wafer_index) for x_coord, y_coord in cells)
            for y_coord in range(GRID):
                tokens = [f"{die_bin(str(row['scenario']), x_coord, y_coord, wafer_index) if on_wafer(x_coord, y_coord) else 0:06d}" for x_coord in range(GRID)]
                source_raw_rows.append({**common, "wafer_no": row["waferNo"], "wafer_id": row["waferId"], "y": y_coord, "bins": "".join(tokens), "hash": digest(f"{manifest_hash}-raw-{row['waferId']}-{y_coord}")})
            good_die = counts[1]
            source_summary_rows.append({**common, "wafer_no": row["waferNo"], "wafer_id": row["waferId"], "good": good_die, "yield": good_die / len(cells), "counts": json.dumps({str(bin_no): count for bin_no, count in counts.items()}), "hash": digest(f"{manifest_hash}-summary-{row['waferId']}")})
            for soft, hard, _, _ in BIN_ROWS:
                if counts[soft]:
                    source_bin_rows.append({**common, "wafer_no": row["waferNo"], "wafer_id": row["waferId"], "soft": soft, "hard": hard, "count": counts[soft], "hash": digest(f"{manifest_hash}-bin-{row['waferId']}-{soft}")})
            per_wafer.append({**row, "binDef": bin_def, "counts": counts, "good": good_die, "yield": good_die / len(cells), "payload": payload})

        print("[profiled-seed] writing VEDA source lots, wafers, raw maps, summaries, and bins", flush=True)
        batched_execute(connection, text("INSERT INTO source_veda_cp_lot (fab_name,lot_id,test_type,part_number,measured_at,test_program,bin_def_name,test_eqp_id,probe_card,source_payload,source_hash) VALUES (:fab,:lot,:test,:part,:measured,:program,:bin_def,:tester,:probe,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE measured_at=VALUES(measured_at),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), source_lot_rows)
        print("[profiled-seed] source lots complete", flush=True)
        batched_execute(connection, text("INSERT INTO source_veda_cp_wafer (fab_name,lot_id,test_type,wafer_no,wafer_id,part_number,measured_at,test_program,bin_def_name,test_eqp_id,probe_card,source_payload,source_hash) VALUES (:fab,:lot,:test,:wafer_no,:wafer_id,:part,:measured,:program,:bin_def,:tester,:probe,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE measured_at=VALUES(measured_at),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), source_wafer_rows)
        print("[profiled-seed] source wafers complete", flush=True)
        batched_execute(connection, text("INSERT INTO source_veda_cp_raw (fab_name,lot_id,test_type,wafer_no,wafer_id,measured_at,y_coord,view_flag,bin_string,vi_string,bin_type_string,source_payload,source_hash) VALUES (:fab,:lot,:test,:wafer_no,:wafer_id,:measured,:y,1,:bins,'','',CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE bin_string=VALUES(bin_string),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), source_raw_rows)
        print("[profiled-seed] source raw-map rows complete", flush=True)
        batched_execute(connection, text("INSERT INTO source_veda_cp_wafer_sum (fab_name,lot_id,test_type,wafer_no,range_index,wafer_id,gross_die,tested_die,good_die,yield_value,map_x_min,map_x_max,map_y_min,map_y_max,bin_counts,source_payload,source_hash) VALUES (:fab,:lot,:test,:wafer_no,:wafer_no,:wafer_id,:gross,:gross,:good,:yield,0,:max,0,:max,CAST(:counts AS JSON),CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE good_die=VALUES(good_die),yield_value=VALUES(yield_value),bin_counts=VALUES(bin_counts),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), [{**row, "gross": len(cells), "max": GRID - 1} for row in source_summary_rows])
        print("[profiled-seed] source wafer summaries complete", flush=True)
        batched_execute(connection, text("INSERT INTO source_veda_cp_wafer_bin (fab_name,lot_id,test_type,wafer_no,wafer_id,bin_no,bin_type,bin_count,source_payload,source_hash) VALUES (:fab,:lot,:test,:wafer_no,:wafer_id,:soft,'S',:count,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE bin_count=VALUES(bin_count),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), source_bin_rows)
        print("[profiled-seed] source wafer bins complete", flush=True)

        print("[profiled-seed] materializing product revisions, parameter versions, lots, and sessions", flush=True)
        product_ids = {str(part): int(product_id) for part, product_id in connection.execute(text("SELECT part_number,product_id FROM core_product WHERE fab_name=:fab AND product_revision='CSV-PROFILED-R1'"), {"fab": FAB}).all()}
        axis_ids = {str(part): int(axis_id) for part, axis_id in connection.execute(text("SELECT part_number,source_row_id FROM source_veda_cp_init_axis WHERE fab_name=:fab AND customer_id='CSVPROF'"), {"fab": FAB}).all()}
        for part in parts:
            bin_def = f"CSVPROF-{part[:6].replace(' ', '')}-BIN-R1"
            connection.execute(text("INSERT INTO core_coordinate_transform_revision (data_release_id,product_id,min_x,min_y,max_x,max_y,orientation_code,source_axis_row_id) VALUES (:release,:product,0,0,:max,:max,'notch_south',:axis) ON DUPLICATE KEY UPDATE coordinate_transform_revision_id=LAST_INSERT_ID(coordinate_transform_revision_id),source_axis_row_id=VALUES(source_axis_row_id)"), {"release": release_id, "product": product_ids[part], "max": GRID - 1, "axis": axis_ids[part]})
            connection.execute(text("INSERT INTO core_bin_definition_revision (data_release_id,fab_name,part_number,bin_def_name,revision_hash) VALUES (:release,:fab,:part,:bin_def,:hash) ON DUPLICATE KEY UPDATE bin_definition_revision_id=LAST_INSERT_ID(bin_definition_revision_id),revision_hash=VALUES(revision_hash)"), {"release": release_id, "fab": FAB, "part": part, "bin_def": bin_def, "hash": digest(f"{manifest_hash}-{part}-binrev")})
            source_bin_ids = {int(soft): int(source_id) for soft, source_id in connection.execute(text("SELECT bin_number,source_row_id FROM source_veda_cp_bin_definition WHERE fab_name=:fab AND part_number=:part AND bin_def_name=:bin_def"), {"fab": FAB, "part": part, "bin_def": bin_def}).all()}
            revision_id = scalar(connection, "SELECT bin_definition_revision_id FROM core_bin_definition_revision WHERE data_release_id=:release AND fab_name=:fab AND part_number=:part AND bin_def_name=:bin_def", {"release": release_id, "fab": FAB, "part": part, "bin_def": bin_def})
            connection.execute(text("INSERT INTO core_bin_definition (bin_definition_revision_id,soft_bin_no,soft_bin_name,hard_bin_no,hard_bin_name,is_good_bin,source_bin_row_id) VALUES (:revision,:soft,:name,:hard,:hard_name,:good,:source) ON DUPLICATE KEY UPDATE soft_bin_name=VALUES(soft_bin_name),is_good_bin=VALUES(is_good_bin),source_bin_row_id=VALUES(source_bin_row_id)"), [{"revision": revision_id, "soft": soft, "name": name, "hard": hard, "hard_name": f"HB{hard}", "good": good, "source": source_bin_ids[soft]} for soft, hard, good, name in BIN_ROWS])

        connection.execute(text("INSERT INTO core_parameter_definition (parameter_code,display_name,unit_name) VALUES (:code,:display,:unit) ON DUPLICATE KEY UPDATE display_name=VALUES(display_name),unit_name=VALUES(unit_name)"), [{"code": code, "display": display, "unit": unit} for code, display, unit, _, _ in PARAMETERS])
        parameter_ids = {str(code): int(parameter_id) for parameter_id, code in connection.execute(text("SELECT parameter_id,parameter_code FROM core_parameter_definition WHERE parameter_code IN ('CSVPROF_VTH','CSVPROF_IDDQ','CSVPROF_RON')")).all()}
        connection.execute(text("INSERT INTO core_parameter_version (parameter_id,data_release_id,test_number,lower_limit,upper_limit,guardband_low,guardband_high) VALUES (:parameter,:release,:number,:lower,:upper,:guard_low,:guard_high) ON DUPLICATE KEY UPDATE lower_limit=VALUES(lower_limit),upper_limit=VALUES(upper_limit),guardband_low=VALUES(guardband_low),guardband_high=VALUES(guardband_high)"), [{"parameter": parameter_ids[code], "release": release_id, "number": number + 1, "lower": lower, "upper": upper, "guard_low": lower + (upper - lower) * .08, "guard_high": upper - (upper - lower) * .08} for number, (code, _, _, lower, upper) in enumerate(PARAMETERS)])
        parameter_versions = {str(code): int(version_id) for code, version_id in connection.execute(text("SELECT pd.parameter_code,pv.parameter_version_id FROM core_parameter_version pv JOIN core_parameter_definition pd ON pd.parameter_id=pv.parameter_id WHERE pv.data_release_id=:release"), {"release": release_id}).all()}

        batched_execute(connection, text("INSERT INTO core_lot (product_id,fab_name,lot_id,test_type,measured_at) VALUES (:product,:fab,:lot,:test,:measured) ON DUPLICATE KEY UPDATE product_id=VALUES(product_id),measured_at=VALUES(measured_at)"), [{"product": product_ids[str(row["part"])], "fab": FAB, "lot": row["lotId"], "test": TEST_TYPE, "measured": row["measuredAt"]} for row in per_wafer])
        source_wafer_ids = {(str(lot), int(wafer_no)): int(source_id) for lot, wafer_no, source_id in connection.execute(text("SELECT lot_id,wafer_no,source_row_id FROM source_veda_cp_wafer WHERE fab_name=:fab AND lot_id LIKE 'CSVPRF-%'"), {"fab": FAB}).all()}
        source_raw_ids = {(str(lot), int(wafer_no), int(y_coord)): int(source_id) for lot, wafer_no, y_coord, source_id in connection.execute(text("SELECT lot_id,wafer_no,y_coord,source_row_id FROM source_veda_cp_raw WHERE fab_name=:fab AND lot_id LIKE 'CSVPRF-%'"), {"fab": FAB}).all()}
        lot_keys = {str(lot): int(lot_key) for lot, lot_key in connection.execute(text("SELECT lot_id,lot_key FROM core_lot WHERE fab_name=:fab AND lot_id LIKE 'CSVPRF-%' AND test_type=:test"), {"fab": FAB, "test": TEST_TYPE}).all()}
        batched_execute(connection, text("INSERT INTO core_wafer (lot_key,wafer_no,wafer_id,source_wafer_row_id) VALUES (:lot_key,:wafer_no,:wafer_id,:source) ON DUPLICATE KEY UPDATE wafer_id=VALUES(wafer_id),source_wafer_row_id=VALUES(source_wafer_row_id)"), [{"lot_key": lot_keys[str(row["lotId"])], "wafer_no": row["waferNo"], "wafer_id": row["waferId"], "source": source_wafer_ids[(str(row["lotId"]), int(row["waferNo"]))]} for row in per_wafer])
        wafer_keys = {(str(lot), int(wafer_no)): int(wafer_key) for lot, wafer_no, wafer_key in connection.execute(text("SELECT l.lot_id,w.wafer_no,w.wafer_key FROM core_wafer w JOIN core_lot l ON l.lot_key=w.lot_key WHERE l.fab_name=:fab AND l.lot_id LIKE 'CSVPRF-%'"), {"fab": FAB}).all()}
        bin_revisions = {str(part): int(revision_id) for part, revision_id in connection.execute(text("SELECT part_number,bin_definition_revision_id FROM core_bin_definition_revision WHERE data_release_id=:release AND fab_name=:fab"), {"release": release_id, "fab": FAB}).all()}
        batched_execute(connection, text("INSERT INTO core_test_session (data_release_id,wafer_key,test_program,bin_definition_revision_id,tester_id,probe_card_id,measured_at,pass_index,source_raw_hash) VALUES (:release,:wafer,:program,:bin_revision,:tester,:probe,:measured,1,:hash) ON DUPLICATE KEY UPDATE test_program=VALUES(test_program),tester_id=VALUES(tester_id),probe_card_id=VALUES(probe_card_id),measured_at=VALUES(measured_at),source_raw_hash=VALUES(source_raw_hash)"), [{"release": release_id, "wafer": wafer_keys[(str(row["lotId"]), int(row["waferNo"]))], "program": row["program"], "bin_revision": bin_revisions[str(row["part"])], "tester": row["tester"], "probe": row["probe"], "measured": row["measuredAt"], "hash": digest(f"{manifest_hash}-session-{row['waferId']}")} for row in per_wafer])
        session_ids = {int(wafer_key): int(session_id) for wafer_key, session_id in connection.execute(text("SELECT wafer_key,test_session_id FROM core_test_session WHERE data_release_id=:release"), {"release": release_id}).all()}
        transforms = {str(part): int(transform_id) for part, transform_id in connection.execute(text("SELECT p.part_number,ctr.coordinate_transform_revision_id FROM core_coordinate_transform_revision ctr JOIN core_product p ON p.product_id=ctr.product_id WHERE ctr.data_release_id=:release"), {"release": release_id}).all()}

        print("[profiled-seed] materializing canonical dies and parameter measurements", flush=True)
        die_rows = []
        expected_bin_counts: dict[int, Counter[int]] = {}
        for wafer_index, row in enumerate(per_wafer):
            session_id = session_ids[wafer_keys[(str(row["lotId"]), int(row["waferNo"]))]]
            expected_bin_counts[session_id] = Counter()
            for x_coord, y_coord in cells:
                soft = die_bin(str(row["scenario"]), x_coord, y_coord, wafer_index)
                hard = next(hard_bin for soft_bin, hard_bin, _, _ in BIN_ROWS if soft_bin == soft)
                expected_bin_counts[session_id][soft] += 1
                die_rows.append({"session": session_id, "x": x_coord, "y": y_coord, "hard": hard, "soft": soft, "passed": int(soft == 1), "source": source_raw_ids[(str(row["lotId"]), int(row["waferNo"]), y_coord)], "transform": transforms[str(row["part"]) ]})
        die_values = [f"({int(row['session'])},{int(row['x'])},{int(row['y'])},{int(row['hard'])},{int(row['soft'])},{int(row['passed'])},0,{int(row['source'])},{int(row['transform'])})" for row in die_rows]
        insert_value_chunks(connection, "INSERT INTO core_die (test_session_id,x_coord,y_coord,hard_bin_no,soft_bin_no,pass_flag,vi_flag,source_raw_row_id,coordinate_transform_revision_id) VALUES ", die_values, " ON DUPLICATE KEY UPDATE hard_bin_no=VALUES(hard_bin_no),soft_bin_no=VALUES(soft_bin_no),pass_flag=VALUES(pass_flag),source_raw_row_id=VALUES(source_raw_row_id),coordinate_transform_revision_id=VALUES(coordinate_transform_revision_id)")
        die_ids = {(int(session_id), int(x_coord), int(y_coord)): int(die_id) for die_id, session_id, x_coord, y_coord in connection.execute(text("SELECT d.die_id,d.test_session_id,d.x_coord,d.y_coord FROM core_die d JOIN core_test_session ts ON ts.test_session_id=d.test_session_id WHERE ts.data_release_id=:release"), {"release": release_id}).all()}
        measurements = []
        for wafer_index, row in enumerate(per_wafer):
            session_id = session_ids[wafer_keys[(str(row["lotId"]), int(row["waferNo"]))]]
            for x_coord, y_coord in cells:
                for code, (measured, direction) in parameter_values(str(row["scenario"]), x_coord, y_coord, int(row["lotIndex"]), wafer_index).items():
                    measurements.append({"die": die_ids[(session_id, x_coord, y_coord)], "version": parameter_versions[code], "measured": measured, "direction": direction, "hash": digest(f"{manifest_hash}-measurement-{session_id}-{x_coord}-{y_coord}-{code}")})
        measurement_values = [f"({int(row['die'])},{int(row['version'])},{float(row['measured'])},'{str(row['direction'])}','{str(row['hash'])}')" for row in measurements]
        insert_value_chunks(connection, "INSERT INTO core_die_measurement (die_id,parameter_version_id,measured_value,fail_direction,source_measurement_hash) VALUES ", measurement_values, " ON DUPLICATE KEY UPDATE measured_value=VALUES(measured_value),fail_direction=VALUES(fail_direction),source_measurement_hash=VALUES(source_measurement_hash)")

        print("[profiled-seed] materializing release summaries, filters, and reconciliation evidence", flush=True)
        summaries = []
        for row in per_wafer:
            wafer_key = wafer_keys[(str(row["lotId"]), int(row["waferNo"]))]
            session_id = session_ids[wafer_key]
            good = expected_bin_counts[session_id][1]
            summaries.append({"release": release_id, "wafer": wafer_key, "session": session_id, "gross": len(cells), "good": good, "yield": good / len(cells), "hash": digest(f"{manifest_hash}-analytics-{row['waferId']}")})
        connection.execute(text("INSERT INTO analytics_wafer_summary (data_release_id,wafer_key,test_session_id,gross_die,tested_die,good_die,yield_value,map_x_min,map_x_max,map_y_min,map_y_max,materialization_hash) VALUES (:release,:wafer,:session,:gross,:gross,:good,:yield,0,:max,0,:max,:hash)"), [{**row, "max": GRID - 1} for row in summaries])
        summary_ids = {(int(wafer_key), int(session_id)): int(summary_id) for wafer_key, session_id, summary_id in connection.execute(text("SELECT wafer_key,test_session_id,wafer_summary_id FROM analytics_wafer_summary WHERE data_release_id=:release"), {"release": release_id}).all()}
        bin_summary_rows = []
        for row in summaries:
            for soft, hard, _, _ in BIN_ROWS:
                count = expected_bin_counts[int(row["session"])][soft]
                if count:
                    bin_summary_rows.append({"summary": summary_ids[(int(row["wafer"]), int(row["session"]))], "soft": soft, "hard": hard, "count": count, "rate": count / len(cells)})
        connection.execute(text("INSERT INTO analytics_wafer_bin_summary (wafer_summary_id,soft_bin_no,hard_bin_no,bin_count,bin_rate) VALUES (:summary,:soft,:hard,:count,:rate) ON DUPLICATE KEY UPDATE bin_count=VALUES(bin_count),bin_rate=VALUES(bin_rate)"), bin_summary_rows)
        connection.execute(text("INSERT INTO analytics_release_lot_filter (data_release_id,lot_key,fab_name,part_number,part6,lot_id,test_program,bin_def_name,test_eqp_id,cp_probe_card,test_vendor,month_code,week_code) VALUES (:release,:lot_key,:fab,:part,:part6,:lot,:program,:bin_def,:tester,:probe,'CSV_PROFILED_SYNTHETIC',DATE_FORMAT(:measured,'%Y%m'),DATE_FORMAT(:measured,'%x%v')) ON DUPLICATE KEY UPDATE test_program=VALUES(test_program),test_eqp_id=VALUES(test_eqp_id),cp_probe_card=VALUES(cp_probe_card),month_code=VALUES(month_code),week_code=VALUES(week_code)"), [{"release": release_id, "lot_key": lot_keys[str(row["lotId"])], "fab": FAB, "part": row["part"], "part6": row["part6"], "lot": row["lotId"], "program": row["program"], "bin_def": row["binDef"], "tester": row["tester"], "probe": row["probe"], "measured": row["measuredAt"]} for row in per_wafer[::4]])

        expected_dies = len(generated) * len(cells)
        observed_dies = scalar(connection, "SELECT COUNT(*) FROM core_die d JOIN core_test_session ts ON ts.test_session_id=d.test_session_id WHERE ts.data_release_id=:release", {"release": release_id})
        observed_measurements = scalar(connection, "SELECT COUNT(*) FROM core_die_measurement dm JOIN core_die d ON d.die_id=dm.die_id JOIN core_test_session ts ON ts.test_session_id=d.test_session_id WHERE ts.data_release_id=:release", {"release": release_id})
        bin_reconciled = scalar(connection, "SELECT COUNT(*) FROM (SELECT aws.wafer_summary_id,aws.tested_die,SUM(abs.bin_count) AS bin_total FROM analytics_wafer_summary aws JOIN analytics_wafer_bin_summary abs ON abs.wafer_summary_id=aws.wafer_summary_id WHERE aws.data_release_id=:release GROUP BY aws.wafer_summary_id,aws.tested_die HAVING bin_total <> aws.tested_die) AS mismatches", {"release": release_id})
        if observed_dies != expected_dies or observed_measurements != expected_dies * len(PARAMETERS) or bin_reconciled != 0:
            raise RuntimeError("CSV-profiled release reconciliation failed; approval blocked.")
        validation = [
            ("CSV_PROFILE_MANIFEST", {"manifest": manifest_hash, "sourceFiles": manifest_components, "sourceTables": sorted(sections)}),
            ("EXPANDED_WAFER_COVERAGE", {"lots": lot_count, "wafers": len(generated), "diesPerWafer": len(cells)}),
            ("RAW_TO_CANONICAL_RECONCILIATION", {"expectedDies": expected_dies, "observedDies": observed_dies, "rawRows": len(generated) * GRID}),
            ("PARAMETER_MEASUREMENT_COVERAGE", {"parameters": [code for code, *_ in PARAMETERS], "observedMeasurements": observed_measurements}),
            ("WAFER_BIN_RECONCILIATION", {"mismatchedWafers": bin_reconciled}),
            ("SYNTHETIC_PROVENANCE", metadata),
        ]
        connection.execute(text("INSERT INTO governance_release_validation (data_release_id,rule_code,severity,outcome,result_json) VALUES (:release,:rule,'blocking','passed',CAST(:result AS JSON)) ON DUPLICATE KEY UPDATE outcome='passed',result_json=VALUES(result_json),validated_at=NOW(6)"), [{"release": release_id, "rule": rule, "result": json.dumps(result)} for rule, result in validation])
        connection.execute(text("UPDATE governance_data_release SET status='analytics_ready',approved_by='csv-profiled-data-steward',approved_at=NOW(6) WHERE data_release_id=:release AND source_manifest_hash=:manifest"), {"release": release_id, "manifest": manifest_hash})
        connection.execute(text("UPDATE ingest_ingestion_run SET status='published',completed_at=NOW(6) WHERE ingestion_run_id=:run"), {"run": run_id})
    print(json.dumps({"releaseKey": args.release_key, "status": "analytics_ready", "sourceManifest": manifest_hash, "lots": lot_count, "wafers": len(generated), "dies": len(generated) * len(cells), "measurements": len(generated) * len(cells) * len(PARAMETERS)}, indent=2))


if __name__ == "__main__":
    main()
