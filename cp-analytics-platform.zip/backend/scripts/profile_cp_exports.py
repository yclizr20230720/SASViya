"""Profile multi-section VEDA CP CSV exports without altering database state."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

from import_real_cp_exports import DEFAULT_FILES, parse_sections, value


DIMENSIONS = ("PART", "PART6", "LOTID", "TEST_PROGRAM", "BIN_DEF_NAME", "TEST_EQPID", "CPPROBECARD", "TEST_VENDOR", "MEASURETIME")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="*", type=Path, default=DEFAULT_FILES)
    args = parser.parse_args()
    records, sections = parse_sections(args.files)
    tables: dict[str, dict[str, object]] = {}
    dimensions: dict[str, Counter[str]] = defaultdict(Counter)
    headers: dict[str, set[str]] = defaultdict(set)
    valid_rows: Counter[str] = Counter()
    invalid_rows: Counter[str] = Counter()
    for record in records:
        headers[record.table].update(record.payload)
        if not record.valid_width:
            invalid_rows[record.table] += 1
            continue
        valid_rows[record.table] += 1
        for dimension in DIMENSIONS:
            candidate = value(record.payload, dimension)
            if candidate:
                dimensions[dimension][candidate] += 1
    for table in sorted({record.table for record in records}):
        tables[table] = {
            "logicalRows": valid_rows[table],
            "invalidWidthRows": invalid_rows[table],
            "columns": sorted(headers[table]),
            "sections": len(sections.get(table, [])),
        }
    print(json.dumps({
        "recordCount": len(records),
        "tables": tables,
        "analysisDimensions": {
            field: {"distinct": len(values), "topValues": [{"value": name, "rows": count} for name, count in values.most_common(12)]}
            for field, values in dimensions.items()
        },
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
