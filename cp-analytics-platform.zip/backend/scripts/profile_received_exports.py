"""Profile and reconstruct table sections embedded across user-supplied CP CSV exports."""

from __future__ import annotations

import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


FILES = [
    Path("/home/ubuntu/upload/cp2.csv"),
    Path("/home/ubuntu/upload/cp3.csv"),
    Path("/home/ubuntu/upload/cp4.csv"),
    Path("/home/ubuntu/upload/cp5.csv"),
    Path("/home/ubuntu/upload/test.csv"),
]
TABLE_PATTERN = re.compile(r"^(VEDA_TBL_CP_[A-Z_]+)_\d+\.csv$", re.IGNORECASE)


def parse_row(line: str) -> list[str]:
    return next(csv.reader([line]))


def is_marker(row: list[str]) -> bool:
    return len(row) >= 2 and row[0].strip().upper() == "TABLE" and row[1].strip().upper().startswith("VEDA_TBL_CP_")


def table_name(filename: str) -> str:
    match = TABLE_PATTERN.match(filename.strip())
    return match.group(1).lower() if match else filename.strip().lower()


def looks_like_header(row: list[str]) -> bool:
    cells = [cell.strip() for cell in row if cell.strip()]
    return bool(cells) and sum(cell.replace("_", "").isalnum() and cell.upper() == cell for cell in cells) / len(cells) >= 0.8


def compact_row(row: list[str]) -> list[str]:
    return [value if len(value) <= 80 else f"{value[:77]}…" for value in row]


def main() -> None:
    records: dict[str, list[list[str]]] = defaultdict(list)
    headers: dict[str, list[str]] = {}
    source_parts: dict[str, list[dict[str, object]]] = defaultdict(list)
    active_table: str | None = None
    expecting_header = False

    for path in FILES:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            for line_number, raw_line in enumerate(handle, start=1):
                if not raw_line.strip():
                    continue
                row = parse_row(raw_line)
                if is_marker(row):
                    active_table = table_name(row[1])
                    expecting_header = True
                    source_parts[active_table].append({"file": path.name, "marker_line": line_number, "export_name": row[1]})
                    continue
                if active_table is None:
                    continue
                if expecting_header:
                    if looks_like_header(row):
                        existing = headers.get(active_table)
                        if existing is None:
                            headers[active_table] = row
                        elif existing != row:
                            raise ValueError(f"Conflicting header for {active_table} at {path.name}:{line_number}")
                        expecting_header = False
                        continue
                    expecting_header = False
                records[active_table].append(row)

    exports = []
    for name in sorted(records | headers | source_parts):
        rows = records[name]
        widths = Counter(len(row) for row in rows)
        expected_width = len(headers[name]) if name in headers else None
        valid_rows = [row for row in rows if expected_width is None or len(row) == expected_width]
        exports.append({
            "table": name,
            "header": headers.get(name),
            "expected_width": expected_width,
            "physical_data_rows": len(rows),
            "valid_width_rows": len(valid_rows),
            "invalid_width_rows": len(rows) - len(valid_rows),
            "width_distribution": dict(sorted(widths.items())),
            "sources": source_parts[name],
            "sample_rows": [compact_row(row) for row in valid_rows[:2]],
        })
    print(json.dumps({"exports": exports}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
