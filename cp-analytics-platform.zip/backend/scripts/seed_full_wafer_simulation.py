"""Materialize deterministic, VEDA-compatible complete 300 mm wafer-map simulations.

The simulated release is strictly separate from imported CP exports. Every source row
contains a ``simulation`` marker and the release is labelled by its dedicated key.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections import Counter

from sqlalchemy import text

from cp_platform.config import Settings
from cp_platform.database import get_engine


SIMULATION_SEED = "veda-cp-full-wafer-300mm-v1"
SIMULATION_RELEASE_KEY = "CPSIM300-20260823-R1"
FAB = "SIM"
PART = "VEDA-CP-SIM300"
REVISION = "R300-V1"
LOT_ID = "SIM300MM.1"
TEST_TYPE = "CP1"
BIN_DEF = "SIM300-BIN-R1"
GRID = 64
RADIUS = 31.5
WAFERS = (
    (1, "SIM300MM-01", "edge_ring"),
    (2, "SIM300MM-02", "center_cluster"),
    (3, "SIM300MM-03", "diagonal_scratch"),
)
BIN_DEFINITIONS = (
    (1, 1, True, "PASS"),
    (5, 2, False, "EDGE_RING"),
    (10, 3, False, "CENTER_CLUSTER"),
    (20, 4, False, "SCRATCH"),
)


def digest(value: object) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def on_wafer(x: int, y: int) -> bool:
    center = (GRID - 1) / 2
    return (x - center) ** 2 + (y - center) ** 2 <= RADIUS**2


def die_bin(scenario: str, x: int, y: int) -> int:
    """Return a deterministic VEDA soft-bin number for an in-wafer die."""
    center = (GRID - 1) / 2
    radial_distance = math.hypot(x - center, y - center)
    if scenario == "edge_ring" and radial_distance >= 27:
        return 5
    if scenario == "center_cluster" and radial_distance <= 7:
        return 10
    if scenario == "diagonal_scratch" and abs(y - x + 4) <= 1:
        return 20
    return 1


def scalar(connection, statement: str, parameters: dict[str, object]) -> int:
    return int(connection.execute(text(statement), parameters).scalar_one())


def insert_chunks(connection, prefix: str, tuples: list[str], suffix: str, chunk_size: int = 900) -> None:
    for offset in range(0, len(tuples), chunk_size):
        connection.execute(text(prefix + ",".join(tuples[offset:offset + chunk_size]) + suffix))


def validate_full_wafer_reconciliation(
    expected_die_count: int,
    per_wafer_geometry: list[dict[str, object]],
    per_wafer_yield: list[dict[str, object]],
    per_wafer_bins: list[dict[str, object]],
    raw_row_count: int,
    canonical_die_count: int,
    wafer_count: int,
) -> None:
    """Block analytics approval unless complete-wafer geometry and summaries reconcile."""
    expected_raw_rows = GRID * wafer_count
    expected_canonical_dies = expected_die_count * wafer_count
    if raw_row_count != expected_raw_rows or canonical_die_count != expected_canonical_dies:
        raise RuntimeError("Full-wafer RAW-to-canonical row-count reconciliation failed.")
    expected_x_min = min(x for x, _, _ in [(x, y, die_bin("edge_ring", x, y)) for y in range(GRID) for x in range(GRID) if on_wafer(x, y)])
    expected_x_max = max(x for x, _, _ in [(x, y, die_bin("edge_ring", x, y)) for y in range(GRID) for x in range(GRID) if on_wafer(x, y)])
    expected_y_min = min(y for _, y, _ in [(x, y, die_bin("edge_ring", x, y)) for y in range(GRID) for x in range(GRID) if on_wafer(x, y)])
    expected_y_max = max(y for _, y, _ in [(x, y, die_bin("edge_ring", x, y)) for y in range(GRID) for x in range(GRID) if on_wafer(x, y)])
    if any(entry["dieCount"] != expected_die_count or entry["xMin"] != expected_x_min or entry["xMax"] != expected_x_max or entry["yMin"] != expected_y_min or entry["yMax"] != expected_y_max for entry in per_wafer_geometry):
        raise RuntimeError("Full-wafer geometry validation failed; the 300 mm simulated grid is incomplete.")
    if any(abs(entry["yield"] - entry["goodDie"] / entry["testedDie"]) > 1e-12 for entry in per_wafer_yield):
        raise RuntimeError("Full-wafer yield reconciliation failed.")
    if any(entry["binTotal"] != entry["testedDie"] for entry in per_wafer_bins):
        raise RuntimeError("Full-wafer bin-total reconciliation failed.")


def approve_after_full_wafer_validation(
    connection: object,
    release_key: str,
    run_id: int,
    manifest_hash: str,
    expected_die_count: int,
    per_wafer_geometry: list[dict[str, object]],
    per_wafer_yield: list[dict[str, object]],
    per_wafer_bins: list[dict[str, object]],
    raw_row_count: int,
    canonical_die_count: int,
    wafer_count: int,
) -> None:
    """Run every blocking rule immediately before the sole analytics-ready status update."""
    validate_full_wafer_reconciliation(
        expected_die_count,
        per_wafer_geometry,
        per_wafer_yield,
        per_wafer_bins,
        raw_row_count,
        canonical_die_count,
        wafer_count,
    )
    connection.execute(
        text(
            "UPDATE governance_data_release SET status='analytics_ready',approved_by='simulation-data-steward',approved_at=NOW(6) "
            "WHERE release_key=:key AND ingestion_run_id=:run AND source_manifest_hash=:manifest"
        ),
        {"key": release_key, "run": run_id, "manifest": manifest_hash},
    )


def main() -> None:
    settings = Settings.from_environment()
    if settings.database_target != "builtin_mysql" or not settings.database_url:
        raise RuntimeError("Full-wafer simulation requires CP_DATABASE_TARGET=builtin_mysql and DATABASE_URL.")

    engine = get_engine(settings.database_url)
    manifest_hash = digest(SIMULATION_SEED)
    source_metadata = {"simulation": True, "simulationSeed": SIMULATION_SEED, "sourceContract": "VEDA_CP"}
    cells_by_wafer: dict[int, list[tuple[int, int, int]]] = {}
    for wafer_no, _, scenario in WAFERS:
        cells_by_wafer[wafer_no] = [(x, y, die_bin(scenario, x, y)) for y in range(GRID) for x in range(GRID) if on_wafer(x, y)]
    expected_die_count = len(cells_by_wafer[1])

    print(f"Preparing {SIMULATION_RELEASE_KEY}: {expected_die_count} dies per 300 mm wafer", flush=True)
    with engine.begin() as connection:
        connection.execute(text("INSERT INTO ingest_ingestion_run (source_system,parser_version,status,source_manifest_hash,initiated_by) SELECT 'synthetic_veda_cp_300mm','full-wafer-v1','validated',:manifest,'simulation-loader' WHERE NOT EXISTS (SELECT 1 FROM ingest_ingestion_run WHERE source_manifest_hash=:manifest)"), {"manifest": manifest_hash})
        run_id = scalar(connection, "SELECT ingestion_run_id FROM ingest_ingestion_run WHERE source_manifest_hash=:manifest", {"manifest": manifest_hash})
        connection.execute(text("INSERT INTO governance_data_release (release_key,ingestion_run_id,status,source_manifest_hash,approved_by,approved_at) VALUES (:key,:run,'pending_validation',:manifest,NULL,NULL) ON DUPLICATE KEY UPDATE status='pending_validation',approved_by=NULL,approved_at=NULL"), {"key": SIMULATION_RELEASE_KEY, "run": run_id, "manifest": manifest_hash})
        release_id = scalar(connection, "SELECT data_release_id FROM governance_data_release WHERE release_key=:key", {"key": SIMULATION_RELEASE_KEY})

        connection.execute(text("DELETE abs FROM analytics_wafer_bin_summary abs JOIN analytics_wafer_summary aws ON aws.wafer_summary_id=abs.wafer_summary_id WHERE aws.data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE FROM analytics_wafer_summary WHERE data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE d FROM core_die d JOIN core_test_session s ON s.test_session_id=d.test_session_id WHERE s.data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE FROM core_test_session WHERE data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE FROM analytics_release_lot_filter WHERE data_release_id=:release"), {"release": release_id})

        bin_payloads = [
            {"soft": soft, "hard": hard, "good": int(good), "name": name, "payload": json.dumps({**source_metadata, "softBin": soft}), "hash": digest(f"{SIMULATION_SEED}-bin-{soft}")}
            for soft, hard, good, name in BIN_DEFINITIONS
        ]
        connection.execute(text("INSERT INTO source_veda_cp_bin_definition (fab_name,part_number,bin_def_name,bin_number,bin_name,description_text,good_bin_flag,hard_bin_number,hard_bin_name,hard_good_bin_flag,source_payload,source_hash) VALUES (:fab,:part,:bin_def,:soft,:name,:name,:good,:hard,:name,:good,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), [{**row, "fab": FAB, "part": PART, "bin_def": BIN_DEF} for row in bin_payloads])
        connection.execute(text("INSERT INTO source_veda_cp_grossdie (product_name,fab_name,gross_die,actual_die,source_payload,source_hash) VALUES (:part,:fab,:gross,:gross,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE gross_die=VALUES(gross_die),actual_die=VALUES(actual_die),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), {"part": PART, "fab": FAB, "gross": expected_die_count, "payload": json.dumps({**source_metadata, "diameterMm": 300, "grid": GRID, "chipPitchMm": 4.6875, "edgeRule": "circle-radius-31.5"}), "hash": digest(f"{SIMULATION_SEED}-grossdie")})
        connection.execute(text("INSERT INTO source_veda_cp_init_axis (fab_name,customer_id,test_fab_id,product_id,version_no,part_number,lb_axis_x,lb_axis_y,rt_axis_x,rt_axis_y,source_payload,source_hash) VALUES (:fab,'SIMC','SIMT','SIM300','1',:part,0,0,:max,:max,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE lb_axis_x=0,lb_axis_y=0,rt_axis_x=VALUES(rt_axis_x),rt_axis_y=VALUES(rt_axis_y),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), {"fab": FAB, "part": PART, "max": GRID - 1, "payload": json.dumps({**source_metadata, "orientation": "notch_south"}), "hash": digest(f"{SIMULATION_SEED}-axis")})
        axis_id = scalar(connection, "SELECT source_row_id FROM source_veda_cp_init_axis WHERE fab_name=:fab AND customer_id='SIMC' AND test_fab_id='SIMT' AND product_id='SIM300' AND version_no='1' AND part_number=:part", {"fab": FAB, "part": PART})

        connection.execute(text("INSERT INTO core_product (fab_name,part_number,product_revision) VALUES (:fab,:part,:revision) ON DUPLICATE KEY UPDATE product_id=LAST_INSERT_ID(product_id)"), {"fab": FAB, "part": PART, "revision": REVISION})
        product_id = scalar(connection, "SELECT product_id FROM core_product WHERE fab_name=:fab AND part_number=:part AND product_revision=:revision", {"fab": FAB, "part": PART, "revision": REVISION})
        connection.execute(text("INSERT INTO core_lot (product_id,fab_name,lot_id,test_type,measured_at) VALUES (:product,:fab,:lot,:test,NOW(6)) ON DUPLICATE KEY UPDATE product_id=VALUES(product_id),measured_at=VALUES(measured_at)"), {"product": product_id, "fab": FAB, "lot": LOT_ID, "test": TEST_TYPE})
        lot_key = scalar(connection, "SELECT lot_key FROM core_lot WHERE fab_name=:fab AND lot_id=:lot AND test_type=:test", {"fab": FAB, "lot": LOT_ID, "test": TEST_TYPE})
        connection.execute(text("INSERT INTO core_coordinate_transform_revision (data_release_id,product_id,min_x,min_y,max_x,max_y,orientation_code,source_axis_row_id) VALUES (:release,:product,0,0,:max,:max,'notch_south',:axis) ON DUPLICATE KEY UPDATE coordinate_transform_revision_id=LAST_INSERT_ID(coordinate_transform_revision_id),max_x=VALUES(max_x),max_y=VALUES(max_y)"), {"release": release_id, "product": product_id, "max": GRID - 1, "axis": axis_id})
        transform_id = scalar(connection, "SELECT coordinate_transform_revision_id FROM core_coordinate_transform_revision WHERE data_release_id=:release AND product_id=:product AND orientation_code='notch_south'", {"release": release_id, "product": product_id})
        connection.execute(text("INSERT INTO core_bin_definition_revision (data_release_id,fab_name,part_number,bin_def_name,revision_hash) VALUES (:release,:fab,:part,:bin_def,:hash) ON DUPLICATE KEY UPDATE bin_definition_revision_id=LAST_INSERT_ID(bin_definition_revision_id),revision_hash=VALUES(revision_hash)"), {"release": release_id, "fab": FAB, "part": PART, "bin_def": BIN_DEF, "hash": digest(f"{SIMULATION_SEED}-bin-revision")})
        bin_revision_id = scalar(connection, "SELECT bin_definition_revision_id FROM core_bin_definition_revision WHERE data_release_id=:release AND fab_name=:fab AND part_number=:part AND bin_def_name=:bin_def", {"release": release_id, "fab": FAB, "part": PART, "bin_def": BIN_DEF})
        source_bin_ids = {int(bin_no): int(source_id) for bin_no, source_id in connection.execute(text("SELECT bin_number,source_row_id FROM source_veda_cp_bin_definition WHERE fab_name=:fab AND part_number=:part AND bin_def_name=:bin_def"), {"fab": FAB, "part": PART, "bin_def": BIN_DEF}).all()}
        connection.execute(text("INSERT INTO core_bin_definition (bin_definition_revision_id,soft_bin_no,soft_bin_name,hard_bin_no,hard_bin_name,is_good_bin,source_bin_row_id) VALUES (:revision,:soft,:name,:hard,:hard_name,:good,:source) ON DUPLICATE KEY UPDATE soft_bin_name=VALUES(soft_bin_name),is_good_bin=VALUES(is_good_bin),source_bin_row_id=VALUES(source_bin_row_id)"), [{"revision": bin_revision_id, "soft": soft, "name": name, "hard": hard, "hard_name": f"HB{hard}", "good": int(good), "source": source_bin_ids[soft]} for soft, hard, good, name in BIN_DEFINITIONS])

        lot_payload = json.dumps({**source_metadata, "geometry": "300mm-complete-grid", "scenarioFamily": "full_wafer"})
        connection.execute(text("INSERT INTO source_veda_cp_lot (fab_name,lot_id,test_type,part_number,measured_at,test_program,bin_def_name,test_eqp_id,probe_card,source_payload,source_hash) VALUES (:fab,:lot,:test,:part,NOW(6),'SIM300-R1',:bin_def,'SIM-EQP-300','SIM-PROBE-300',CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), {"fab": FAB, "lot": LOT_ID, "test": TEST_TYPE, "part": PART, "bin_def": BIN_DEF, "payload": lot_payload, "hash": digest(f"{SIMULATION_SEED}-lot")})

        source_wafer_rows: list[dict[str, object]] = []
        source_raw_rows: list[dict[str, object]] = []
        source_summary_rows: list[dict[str, object]] = []
        source_bin_rows: list[dict[str, object]] = []
        for wafer_no, wafer_id, scenario in WAFERS:
            scenario_payload = json.dumps({**source_metadata, "scenario": scenario, "waferId": wafer_id, "grossDie": expected_die_count})
            source_wafer_rows.append({"wafer_no": wafer_no, "wafer_id": wafer_id, "payload": scenario_payload, "hash": digest(f"{SIMULATION_SEED}-wafer-{wafer_id}")})
            counts = Counter(soft_bin for _, _, soft_bin in cells_by_wafer[wafer_no])
            good_die = counts[1]
            for y in range(GRID):
                tokens = [f"{die_bin(scenario, x, y) if on_wafer(x, y) else 0:06d}" for x in range(GRID)]
                source_raw_rows.append({"wafer_no": wafer_no, "wafer_id": wafer_id, "y": y, "bins": "".join(tokens), "payload": scenario_payload, "hash": digest(f"{SIMULATION_SEED}-raw-{wafer_id}-{y}")})
            source_summary_rows.append({"wafer_no": wafer_no, "wafer_id": wafer_id, "good": good_die, "yield": good_die / expected_die_count, "bins": json.dumps({str(bin_number): count for bin_number, count in counts.items()}), "payload": scenario_payload, "hash": digest(f"{SIMULATION_SEED}-summary-{wafer_id}")})
            for soft_bin, count in counts.items():
                hard_bin = next(hard for soft, hard, _, _ in BIN_DEFINITIONS if soft == soft_bin)
                source_bin_rows.append({"wafer_no": wafer_no, "wafer_id": wafer_id, "soft": soft_bin, "hard": hard_bin, "count": count, "payload": scenario_payload, "hash": digest(f"{SIMULATION_SEED}-wafer-bin-{wafer_id}-{soft_bin}")})

        connection.execute(text("INSERT INTO source_veda_cp_wafer (fab_name,lot_id,test_type,wafer_no,wafer_id,part_number,measured_at,test_program,bin_def_name,test_eqp_id,probe_card,source_payload,source_hash) VALUES (:fab,:lot,:test,:wafer_no,:wafer_id,:part,NOW(6),'SIM300-R1',:bin_def,'SIM-EQP-300','SIM-PROBE-300',CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE wafer_id=VALUES(wafer_id),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), [{**row, "fab": FAB, "lot": LOT_ID, "test": TEST_TYPE, "part": PART, "bin_def": BIN_DEF} for row in source_wafer_rows])
        connection.execute(text("INSERT INTO source_veda_cp_raw (fab_name,lot_id,test_type,wafer_no,wafer_id,measured_at,y_coord,view_flag,bin_string,vi_string,bin_type_string,source_payload,source_hash) VALUES (:fab,:lot,:test,:wafer_no,:wafer_id,NOW(6),:y,1,:bins,'','',CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE bin_string=VALUES(bin_string),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), [{**row, "fab": FAB, "lot": LOT_ID, "test": TEST_TYPE} for row in source_raw_rows])
        connection.execute(text("INSERT INTO source_veda_cp_wafer_sum (fab_name,lot_id,test_type,wafer_no,range_index,wafer_id,gross_die,tested_die,good_die,yield_value,map_x_min,map_x_max,map_y_min,map_y_max,bin_counts,source_payload,source_hash) VALUES (:fab,:lot,:test,:wafer_no,:wafer_no,:wafer_id,:gross,:gross,:good,:yield,0,:max,0,:max,CAST(:bins AS JSON),CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE good_die=VALUES(good_die),yield_value=VALUES(yield_value),bin_counts=VALUES(bin_counts),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), [{**row, "fab": FAB, "lot": LOT_ID, "test": TEST_TYPE, "gross": expected_die_count, "max": GRID - 1} for row in source_summary_rows])
        connection.execute(text("INSERT INTO source_veda_cp_wafer_bin (fab_name,lot_id,test_type,wafer_no,wafer_id,bin_no,bin_type,bin_count,source_payload,source_hash) VALUES (:fab,:lot,:test,:wafer_no,:wafer_id,:soft,'S',:count,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE bin_count=VALUES(bin_count),source_payload=VALUES(source_payload),source_hash=VALUES(source_hash)"), [{**row, "fab": FAB, "lot": LOT_ID, "test": TEST_TYPE} for row in source_bin_rows])

        source_wafer_ids = {int(wafer_no): int(source_id) for wafer_no, source_id in connection.execute(text("SELECT wafer_no,source_row_id FROM source_veda_cp_wafer WHERE fab_name=:fab AND lot_id=:lot AND test_type=:test"), {"fab": FAB, "lot": LOT_ID, "test": TEST_TYPE}).all()}
        source_raw_ids = {(int(wafer_no), int(y)): int(source_id) for wafer_no, y, source_id in connection.execute(text("SELECT wafer_no,y_coord,source_row_id FROM source_veda_cp_raw WHERE fab_name=:fab AND lot_id=:lot AND test_type=:test"), {"fab": FAB, "lot": LOT_ID, "test": TEST_TYPE}).all()}
        connection.execute(text("INSERT INTO core_wafer (lot_key,wafer_no,wafer_id,source_wafer_row_id) VALUES (:lot_key,:wafer_no,:wafer_id,:source) ON DUPLICATE KEY UPDATE wafer_id=VALUES(wafer_id),source_wafer_row_id=VALUES(source_wafer_row_id)"), [{"lot_key": lot_key, "wafer_no": wafer_no, "wafer_id": wafer_id, "source": source_wafer_ids[wafer_no]} for wafer_no, wafer_id, _ in WAFERS])
        wafer_keys = {int(wafer_no): int(wafer_key) for wafer_no, wafer_key in connection.execute(text("SELECT wafer_no,wafer_key FROM core_wafer WHERE lot_key=:lot_key"), {"lot_key": lot_key}).all()}
        connection.execute(text("INSERT INTO core_test_session (data_release_id,wafer_key,test_program,bin_definition_revision_id,tester_id,probe_card_id,measured_at,pass_index,source_raw_hash) VALUES (:release,:wafer,'SIM300-R1',:bin_revision,'SIM-EQP-300','SIM-PROBE-300',NOW(6),1,:hash) ON DUPLICATE KEY UPDATE source_raw_hash=VALUES(source_raw_hash)"), [{"release": release_id, "wafer": wafer_keys[wafer_no], "bin_revision": bin_revision_id, "hash": digest(f"{SIMULATION_SEED}-session-{wafer_id}")} for wafer_no, wafer_id, _ in WAFERS])
        session_ids = {int(wafer_key): int(session_id) for wafer_key, session_id in connection.execute(text("SELECT wafer_key,test_session_id FROM core_test_session WHERE data_release_id=:release"), {"release": release_id}).all()}

        die_values: list[str] = []
        summary_rows: list[dict[str, object]] = []
        for wafer_no, wafer_id, scenario in WAFERS:
            session_id = session_ids[wafer_keys[wafer_no]]
            counts = Counter(soft_bin for _, _, soft_bin in cells_by_wafer[wafer_no])
            for x, y, soft_bin in cells_by_wafer[wafer_no]:
                hard_bin = next(hard for soft, hard, _, _ in BIN_DEFINITIONS if soft == soft_bin)
                passed = 1 if soft_bin == 1 else 0
                die_values.append(f"({session_id},{x},{y},{hard_bin},{soft_bin},{passed},0,{source_raw_ids[(wafer_no, y)]},{transform_id})")
            summary_rows.append({"wafer_no": wafer_no, "wafer_id": wafer_id, "session": session_id, "good": counts[1], "yield": counts[1] / expected_die_count, "counts": counts})
        insert_chunks(connection, "INSERT INTO core_die (test_session_id,x_coord,y_coord,hard_bin_no,soft_bin_no,pass_flag,vi_flag,source_raw_row_id,coordinate_transform_revision_id) VALUES ", die_values, " ON DUPLICATE KEY UPDATE hard_bin_no=VALUES(hard_bin_no),soft_bin_no=VALUES(soft_bin_no),pass_flag=VALUES(pass_flag),source_raw_row_id=VALUES(source_raw_row_id)")
        connection.execute(text("INSERT INTO analytics_wafer_summary (data_release_id,wafer_key,test_session_id,gross_die,tested_die,good_die,yield_value,map_x_min,map_x_max,map_y_min,map_y_max,materialization_hash) VALUES (:release,:wafer,:session,:gross,:gross,:good,:yield,0,:max,0,:max,:hash)"), [{"release": release_id, "wafer": wafer_keys[row["wafer_no"]], "session": row["session"], "gross": expected_die_count, "good": row["good"], "yield": row["yield"], "max": GRID - 1, "hash": digest(f"{SIMULATION_SEED}-materialized-{row['wafer_id']}")} for row in summary_rows])
        summary_ids = {(int(wafer_key), int(session_id)): int(summary_id) for wafer_key, session_id, summary_id in connection.execute(text("SELECT wafer_key,test_session_id,wafer_summary_id FROM analytics_wafer_summary WHERE data_release_id=:release"), {"release": release_id}).all()}
        bin_summary_rows = []
        for row in summary_rows:
            summary_id = summary_ids[(wafer_keys[row["wafer_no"]], row["session"])]
            for soft_bin, count in row["counts"].items():
                hard_bin = next(hard for soft, hard, _, _ in BIN_DEFINITIONS if soft == soft_bin)
                bin_summary_rows.append({"summary": summary_id, "soft": soft_bin, "hard": hard_bin, "count": count, "rate": count / expected_die_count})
        connection.execute(text("INSERT INTO analytics_wafer_bin_summary (wafer_summary_id,soft_bin_no,hard_bin_no,bin_count,bin_rate) VALUES (:summary,:soft,:hard,:count,:rate) ON DUPLICATE KEY UPDATE bin_count=VALUES(bin_count),bin_rate=VALUES(bin_rate)"), bin_summary_rows)
        connection.execute(text("INSERT INTO analytics_release_lot_filter (data_release_id,lot_key,fab_name,part_number,part6,lot_id,test_program,bin_def_name,test_eqp_id,cp_probe_card,test_vendor,month_code,week_code) VALUES (:release,:lot_key,:fab,:part,'SIM300',:lot,'SIM300-R1',:bin_def,'SIM-EQP-300','SIM-PROBE-300','SIMULATION','202608','202635')"), {"release": release_id, "lot_key": lot_key, "fab": FAB, "part": PART, "lot": LOT_ID, "bin_def": BIN_DEF})

        per_wafer_geometry = [
            {"waferId": wafer_id, "xMin": min(x for x, _, _ in cells_by_wafer[wafer_no]), "xMax": max(x for x, _, _ in cells_by_wafer[wafer_no]), "yMin": min(y for _, y, _ in cells_by_wafer[wafer_no]), "yMax": max(y for _, y, _ in cells_by_wafer[wafer_no]), "dieCount": len(cells_by_wafer[wafer_no])}
            for wafer_no, wafer_id, _ in WAFERS
        ]
        per_wafer_yield = [
            {"waferId": row["wafer_id"], "goodDie": row["good"], "testedDie": expected_die_count, "yield": row["yield"]}
            for row in summary_rows
        ]
        per_wafer_bins = [
            {"waferId": row["wafer_id"], "binTotal": sum(row["counts"].values()), "testedDie": expected_die_count}
            for row in summary_rows
        ]
        validation_rows = [
            ("FULL_GRID_DIE_COUNT", {"expectedDiePerWafer": expected_die_count, "observedDiePerWafer": [len(cells_by_wafer[number]) for number, _, _ in WAFERS]}),
            ("RAW_TO_CANONICAL_COUNT", {"rawRows": GRID * len(WAFERS), "canonicalDies": expected_die_count * len(WAFERS)}),
            ("GEOMETRY_BOUNDS", {"diameterMm": 300, "grid": GRID, "waferGeometry": per_wafer_geometry}),
            ("WAFER_YIELD_RECONCILIATION", {"waferYields": per_wafer_yield}),
            ("WAFER_BIN_RECONCILIATION", {"waferBins": per_wafer_bins}),
            ("SIMULATION_LINEAGE", {"simulation": True, "seed": SIMULATION_SEED, "sourceTables": ["VEDA_TBL_CP_GROSSDDIE", "VEDA_TBL_CP_RAW", "VEDA_TBL_CP_WAFER"]}),
        ]
        connection.execute(text("INSERT INTO governance_release_validation (data_release_id,rule_code,severity,outcome,result_json) VALUES (:release,:rule,'blocking','passed',CAST(:result AS JSON)) ON DUPLICATE KEY UPDATE outcome='passed',result_json=VALUES(result_json),validated_at=NOW(6)"), [{"release": release_id, "rule": rule, "result": json.dumps(result)} for rule, result in validation_rows])
        connection.execute(text("INSERT INTO governance_data_snapshot (data_release_id,snapshot_hash,transform_version) SELECT :release,:hash,'simulation-full-wafer-v1' WHERE NOT EXISTS (SELECT 1 FROM governance_data_snapshot WHERE snapshot_hash=:hash)"), {"release": release_id, "hash": digest(f"{SIMULATION_SEED}-snapshot")})
        approve_after_full_wafer_validation(
            connection,
            SIMULATION_RELEASE_KEY,
            run_id,
            manifest_hash,
            expected_die_count,
            per_wafer_geometry,
            per_wafer_yield,
            per_wafer_bins,
            raw_row_count=len(source_raw_rows),
            canonical_die_count=len(die_values),
            wafer_count=len(WAFERS),
        )
        connection.execute(text("INSERT INTO governance_audit_event (data_release_id,actor,action_name,entity_type,entity_key,correlation_id,metadata_json) VALUES (:release,'simulation-data-steward','release.approve','data_release',:key,'30000000-0000-0000-0000-000000000001',CAST(:metadata AS JSON))"), {"release": release_id, "key": SIMULATION_RELEASE_KEY, "metadata": json.dumps({"simulation": True, "waferCount": len(WAFERS), "grossDiePerWafer": expected_die_count})})

    print(f"Approved {SIMULATION_RELEASE_KEY}: {len(WAFERS)} complete synthetic 300 mm wafers × {expected_die_count} die cells.")


if __name__ == "__main__":
    main()
