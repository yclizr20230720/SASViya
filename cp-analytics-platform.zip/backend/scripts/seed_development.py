"""Create a traceable, deterministic VEDA CP development release in batched SQL operations."""

from __future__ import annotations

import hashlib
import json

from sqlalchemy import text

from cp_platform.config import Settings
from cp_platform.database import get_engine
from cp_platform.fixtures import APPROVED_RELEASE_KEY, FIXTURE_SEED, approved_fixture_wafers


def digest(value: object) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def failure_coordinates(scenario: str) -> set[tuple[int, int]]:
    edge = [(x, y) for x in range(10) for y in range(10) if x in {0, 9} or y in {0, 9}]
    if scenario == "baseline_good":
        return {(0, 0), (9, 9), (0, 9), (9, 0), (5, 0)}
    if scenario == "edge_ring":
        return set(edge[:30])
    if scenario == "center_cluster":
        return {(x, y) for x in range(3, 7) for y in range(3, 8)}
    if scenario == "scratch":
        return {(x, x) for x in range(10)} | {(x, min(9, x + 1)) for x in range(10)} | {(x, min(9, x + 2)) for x in range(10)}
    if scenario in {"site_anomaly", "parameter_shift"}:
        return {(x, y) for x in range(10) for y in range(10) if x % 5 == 0}
    if scenario == "retest_fail_flip":
        return {(x, 0) for x in range(10)}
    return set()


def bins_for_scenario(scenario: str) -> tuple[int, int]:
    return {
        "edge_ring": (5, 2), "center_cluster": (10, 3), "scratch": (20, 4),
        "site_anomaly": (30, 5), "parameter_shift": (40, 6), "retest_fail_flip": (50, 7),
    }.get(scenario, (2, 2))


def scalar(connection, statement: str, params: dict[str, object]) -> int:
    return int(connection.execute(text(statement), params).scalar_one())


def main() -> None:
    settings = Settings.from_environment()
    if settings.database_target != "builtin_mysql" or not settings.database_url:
        raise RuntimeError("Development seeding requires CP_DATABASE_TARGET=builtin_mysql and DATABASE_URL.")

    fixtures = approved_fixture_wafers()
    manifest_hash = digest(FIXTURE_SEED)
    engine = get_engine(settings.database_url)

    print("Preparing release metadata", flush=True)
    with engine.begin() as connection:
        connection.execute(text("INSERT INTO ingest_ingestion_run (source_system,parser_version,status,source_manifest_hash,initiated_by) SELECT 'synthetic_veda_cp','fixture-parser-v1','validated',:manifest,'fixture-loader' WHERE NOT EXISTS (SELECT 1 FROM ingest_ingestion_run WHERE source_manifest_hash=:manifest)"), {"manifest": manifest_hash})
        run_id = scalar(connection, "SELECT ingestion_run_id FROM ingest_ingestion_run WHERE source_manifest_hash=:manifest", {"manifest": manifest_hash})
        connection.execute(text("INSERT INTO governance_data_release (release_key,ingestion_run_id,status,source_manifest_hash,approved_by,approved_at) VALUES (:key,:run,'analytics_ready',:manifest,'fixture-data-steward',NOW(6)) ON DUPLICATE KEY UPDATE status='analytics_ready',approved_by='fixture-data-steward',approved_at=NOW(6)"), {"key": APPROVED_RELEASE_KEY, "run": run_id, "manifest": manifest_hash})
        connection.execute(text("INSERT INTO governance_data_release (release_key,ingestion_run_id,status,source_manifest_hash,approved_by,approved_at) VALUES ('CPDEV-20260823-R0',:run,'rejected',:manifest,NULL,NULL) ON DUPLICATE KEY UPDATE status='rejected',approved_by=NULL,approved_at=NULL"), {"run": run_id, "manifest": manifest_hash})
        release_id = scalar(connection, "SELECT data_release_id FROM governance_data_release WHERE release_key=:key", {"key": APPROVED_RELEASE_KEY})
        connection.execute(text("INSERT INTO governance_data_snapshot (data_release_id,snapshot_hash,transform_version) SELECT :release,:hash,'fixture-materializer-v1' WHERE NOT EXISTS (SELECT 1 FROM governance_data_snapshot WHERE snapshot_hash=:hash)"), {"release": release_id, "hash": digest(f"snapshot-{FIXTURE_SEED}")})

        connection.execute(text("DELETE abs FROM analytics_wafer_bin_summary abs JOIN analytics_wafer_summary aws ON aws.wafer_summary_id=abs.wafer_summary_id WHERE aws.data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE FROM analytics_wafer_summary WHERE data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE dm FROM core_die_measurement dm JOIN core_die d ON d.die_id=dm.die_id JOIN core_test_session s ON s.test_session_id=d.test_session_id WHERE s.data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE d FROM core_die d JOIN core_test_session s ON s.test_session_id=d.test_session_id WHERE s.data_release_id=:release"), {"release": release_id})
        connection.execute(text("DELETE FROM core_test_session WHERE data_release_id=:release"), {"release": release_id})

        print("Preparing source mappings and bin revisions", flush=True)
        bin_rows = [(1, 1, 1, "PASS"), (2, 2, 0, "RANDOM"), (5, 2, 0, "EDGE"), (10, 3, 0, "CENTR"), (20, 4, 0, "SCRAT"), (30, 5, 0, "SITE"), (40, 6, 0, "PARAM"), (50, 7, 0, "RETES")]
        connection.execute(text("INSERT INTO source_veda_cp_bin_definition (fab_name,part_number,bin_def_name,bin_number,bin_name,description_text,good_bin_flag,hard_bin_number,hard_bin_name,hard_good_bin_flag,source_payload,source_hash) VALUES ('FAB1','VEDA-CP-DEV','CPDEV-BIN-R1',:soft,:name,:name,:good,:hard,:name,:good,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE source_hash=VALUES(source_hash)"), [{"soft": soft, "hard": hard, "good": good, "name": name, "payload": json.dumps({"fixture_seed": FIXTURE_SEED, "soft_bin": soft}), "hash": digest(f"bin-{soft}")} for soft, hard, good, name in bin_rows])
        connection.execute(text("INSERT INTO source_veda_cp_init_axis (fab_name,customer_id,test_fab_id,product_id,version_no,part_number,lb_axis_x,lb_axis_y,rt_axis_x,rt_axis_y,source_payload,source_hash) VALUES ('FAB1','C001','T001','P001','1','VEDA-CP-DEV',0,0,9,9,CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE source_hash=VALUES(source_hash)"), {"payload": json.dumps({"orientation": "notch_up"}), "hash": digest("axis")})
        axis_id = scalar(connection, "SELECT source_row_id FROM source_veda_cp_init_axis WHERE fab_name='FAB1' AND customer_id='C001' AND test_fab_id='T001' AND product_id='P001' AND version_no='1' AND part_number='VEDA-CP-DEV'", {})
        connection.execute(text("INSERT INTO core_product (fab_name,part_number,product_revision) VALUES ('FAB1','VEDA-CP-DEV','R1') ON DUPLICATE KEY UPDATE product_id=LAST_INSERT_ID(product_id)"))
        product_id = scalar(connection, "SELECT product_id FROM core_product WHERE fab_name='FAB1' AND part_number='VEDA-CP-DEV' AND product_revision='R1'", {})
        connection.execute(text("INSERT INTO core_coordinate_transform_revision (data_release_id,product_id,min_x,min_y,max_x,max_y,orientation_code,source_axis_row_id) VALUES (:release,:product,0,0,9,9,'notch_up',:axis) ON DUPLICATE KEY UPDATE coordinate_transform_revision_id=LAST_INSERT_ID(coordinate_transform_revision_id)"), {"release": release_id, "product": product_id, "axis": axis_id})
        transform_id = scalar(connection, "SELECT coordinate_transform_revision_id FROM core_coordinate_transform_revision WHERE data_release_id=:release AND product_id=:product AND orientation_code='notch_up'", {"release": release_id, "product": product_id})
        connection.execute(text("INSERT INTO core_bin_definition_revision (data_release_id,fab_name,part_number,bin_def_name,revision_hash) VALUES (:release,'FAB1','VEDA-CP-DEV','CPDEV-BIN-R1',:hash) ON DUPLICATE KEY UPDATE bin_definition_revision_id=LAST_INSERT_ID(bin_definition_revision_id)"), {"release": release_id, "hash": digest("CPDEV-BIN-R1")})
        bin_revision_id = scalar(connection, "SELECT bin_definition_revision_id FROM core_bin_definition_revision WHERE data_release_id=:release AND fab_name='FAB1' AND part_number='VEDA-CP-DEV' AND bin_def_name='CPDEV-BIN-R1'", {"release": release_id})
        source_bin_ids = {row[0]: row[1] for row in connection.execute(text("SELECT bin_number,source_row_id FROM source_veda_cp_bin_definition WHERE fab_name='FAB1' AND part_number='VEDA-CP-DEV' AND bin_def_name='CPDEV-BIN-R1'")).all()}
        connection.execute(text("INSERT INTO core_bin_definition (bin_definition_revision_id,soft_bin_no,soft_bin_name,hard_bin_no,hard_bin_name,is_good_bin,source_bin_row_id) VALUES (:revision,:soft,:name,:hard,:hard_name,:good,:source) ON DUPLICATE KEY UPDATE is_good_bin=VALUES(is_good_bin),source_bin_row_id=VALUES(source_bin_row_id)"), [{"revision": bin_revision_id, "soft": soft, "name": name, "hard": hard, "hard_name": f"HB{hard}", "good": good, "source": source_bin_ids[soft]} for soft, hard, good, name in bin_rows])

        parameter_rows = [{"code": f"CP_PARAM_{number:03d}", "display": f"CP Parameter {number:03d}"} for number in range(1, 101)]
        connection.execute(text("INSERT INTO core_parameter_definition (parameter_code,display_name,unit_name) VALUES (:code,:display,'arb') ON DUPLICATE KEY UPDATE display_name=VALUES(display_name)"), parameter_rows)
        parameter_ids = connection.execute(text("SELECT parameter_id,parameter_code FROM core_parameter_definition WHERE parameter_code LIKE 'CP_PARAM_%'")).all()
        connection.execute(text("INSERT INTO core_parameter_version (parameter_id,data_release_id,test_number,lower_limit,upper_limit,guardband_low,guardband_high) VALUES (:parameter,:release,:number,0,10,0.5,9.5) ON DUPLICATE KEY UPDATE upper_limit=VALUES(upper_limit)"), [{"parameter": int(identifier), "release": release_id, "number": int(code.rsplit('_', 1)[1])} for identifier, code in parameter_ids])
        shift_parameter_version_id = scalar(connection, "SELECT pv.parameter_version_id FROM core_parameter_version pv JOIN core_parameter_definition pd ON pd.parameter_id=pv.parameter_id WHERE pv.data_release_id=:release AND pd.parameter_code='CP_PARAM_001'", {"release": release_id})
        correlation_parameter_version_id = scalar(connection, "SELECT pv.parameter_version_id FROM core_parameter_version pv JOIN core_parameter_definition pd ON pd.parameter_id=pv.parameter_id WHERE pv.data_release_id=:release AND pd.parameter_code='CP_PARAM_002'", {"release": release_id})

        print("Writing source lot, wafer, and raw-map evidence", flush=True)
        source_lot_rows: list[dict[str, object]] = []
        source_wafer_rows: list[dict[str, object]] = []
        source_raw_rows: list[dict[str, object]] = []
        for fixture in fixtures:
            payload = json.dumps({"scenario": fixture.scenario_id, "fixture_seed": FIXTURE_SEED})
            base = {"lot": fixture.lot_id, "wafer_no": fixture.wafer_no, "wafer_id": fixture.wafer_id, "payload": payload}
            source_lot_rows.append({**base, "hash": digest(f"lot-{fixture.lot_id}")})
            source_wafer_rows.append({**base, "hash": digest(f"wafer-{fixture.wafer_id}")})
            soft_bin, _ = bins_for_scenario(fixture.scenario_id)
            failures = failure_coordinates(fixture.scenario_id)
            for y in range(10):
                source_raw_rows.append({**base, "y": y, "bins": ",".join(str(soft_bin if (x, y) in failures else 1) for x in range(10)), "hash": digest(f"raw-{fixture.wafer_id}-{y}")})
        connection.execute(text("INSERT INTO source_veda_cp_lot (fab_name,lot_id,test_type,part_number,measured_at,test_program,bin_def_name,test_eqp_id,probe_card,source_payload,source_hash) VALUES ('FAB1',:lot,'CP1','VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-01','PC-01',CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE source_hash=VALUES(source_hash)"), source_lot_rows)
        connection.execute(text("INSERT INTO source_veda_cp_wafer (fab_name,lot_id,test_type,wafer_no,wafer_id,part_number,measured_at,test_program,bin_def_name,test_eqp_id,probe_card,source_payload,source_hash) VALUES ('FAB1',:lot,'CP1',:wafer_no,:wafer_id,'VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-01','PC-01',CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE source_hash=VALUES(source_hash)"), source_wafer_rows)
        connection.execute(text("INSERT INTO source_veda_cp_raw (fab_name,lot_id,test_type,wafer_no,wafer_id,measured_at,y_coord,view_flag,bin_string,vi_string,bin_type_string,source_payload,source_hash) VALUES ('FAB1',:lot,'CP1',:wafer_no,:wafer_id,NOW(6),:y,1,:bins,'','',CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE bin_string=VALUES(bin_string),source_hash=VALUES(source_hash)"), source_raw_rows)

        source_wafer_ids = {(lot, int(wafer_no)): int(source_id) for lot, wafer_no, source_id in connection.execute(text("SELECT lot_id,wafer_no,source_row_id FROM source_veda_cp_wafer WHERE fab_name='FAB1' AND lot_id LIKE 'CPDEV%'")).all()}
        source_raw_ids = {(lot, int(wafer_no), int(y)): int(source_id) for lot, wafer_no, y, source_id in connection.execute(text("SELECT lot_id,wafer_no,y_coord,source_row_id FROM source_veda_cp_raw WHERE fab_name='FAB1' AND lot_id LIKE 'CPDEV%'")).all()}

        canonical_lot_rows = [{"product": product_id, "lot": fixture.lot_id} for fixture in fixtures]
        connection.execute(text("INSERT INTO core_lot (product_id,fab_name,lot_id,test_type,measured_at) VALUES (:product,'FAB1',:lot,'CP1',NOW(6)) ON DUPLICATE KEY UPDATE product_id=VALUES(product_id)"), canonical_lot_rows)
        lot_keys = {lot: int(lot_key) for lot, lot_key in connection.execute(text("SELECT lot_id,lot_key FROM core_lot WHERE fab_name='FAB1' AND lot_id LIKE 'CPDEV%' AND test_type='CP1'")).all()}
        connection.execute(text("INSERT INTO core_wafer (lot_key,wafer_no,wafer_id,source_wafer_row_id) VALUES (:lot_key,:wafer_no,:wafer_id,:source) ON DUPLICATE KEY UPDATE source_wafer_row_id=VALUES(source_wafer_row_id)"), [{"lot_key": lot_keys[fixture.lot_id], "wafer_no": fixture.wafer_no, "wafer_id": fixture.wafer_id, "source": source_wafer_ids[(fixture.lot_id, fixture.wafer_no)]} for fixture in fixtures])
        wafer_keys = {(lot, int(wafer_no)): int(wafer_key) for lot, wafer_no, wafer_key in connection.execute(text("SELECT l.lot_id,w.wafer_no,w.wafer_key FROM core_wafer w JOIN core_lot l ON l.lot_key=w.lot_key WHERE l.fab_name='FAB1' AND l.lot_id LIKE 'CPDEV%'")).all()}
        connection.execute(text("INSERT INTO core_test_session (data_release_id,wafer_key,test_program,bin_definition_revision_id,tester_id,probe_card_id,measured_at,pass_index,source_raw_hash) VALUES (:release,:wafer,'CPDEV-R1',:bin_revision,'TSTR-01','PC-01',NOW(6),1,:hash) ON DUPLICATE KEY UPDATE source_raw_hash=VALUES(source_raw_hash)"), [{"release": release_id, "wafer": wafer_keys[(fixture.lot_id, fixture.wafer_no)], "bin_revision": bin_revision_id, "hash": digest(f"raw-{fixture.wafer_id}")} for fixture in fixtures])
        session_ids = {int(wafer_key): int(session_id) for wafer_key, session_id in connection.execute(text("SELECT wafer_key,test_session_id FROM core_test_session WHERE data_release_id=:release"), {"release": release_id}).all()}

        print("Materializing canonical dies and wafer summaries", flush=True)
        die_rows: list[dict[str, object]] = []
        summary_rows: list[dict[str, object]] = []
        source_summary_rows: list[dict[str, object]] = []
        bin_summary_rows: list[dict[str, object]] = []
        for fixture in fixtures:
            wafer_key = wafer_keys[(fixture.lot_id, fixture.wafer_no)]
            session_id = session_ids[wafer_key]
            soft_bin, hard_bin = bins_for_scenario(fixture.scenario_id)
            failures = failure_coordinates(fixture.scenario_id)
            good_die = 100 - len(failures)
            payload = json.dumps({"scenario": fixture.scenario_id, "fixture_seed": FIXTURE_SEED})
            for y in range(10):
                for x in range(10):
                    failed = (x, y) in failures
                    die_rows.append({"session": session_id, "x": x, "y": y, "hard": hard_bin if failed else 1, "soft": soft_bin if failed else 1, "passed": 0 if failed else 1, "source": source_raw_ids[(fixture.lot_id, fixture.wafer_no, y)], "transform": transform_id})
            source_summary_rows.append({"lot": fixture.lot_id, "wafer_no": fixture.wafer_no, "wafer_id": fixture.wafer_id, "good": good_die, "yield": good_die / 100, "bins": json.dumps({"1": good_die, str(soft_bin): len(failures)}), "payload": payload, "hash": digest(f"source-summary-{fixture.wafer_id}")})
            summary_rows.append({"release": release_id, "wafer": wafer_key, "session": session_id, "good": good_die, "yield": good_die / 100, "hash": digest(f"materialized-{fixture.wafer_id}"), "soft": soft_bin, "hard": hard_bin, "fail_count": len(failures)})
        die_values = ",".join(
            f"({int(row['session'])},{int(row['x'])},{int(row['y'])},{int(row['hard'])},{int(row['soft'])},{int(row['passed'])},0,{int(row['source'])},{int(row['transform'])})"
            for row in die_rows
        )
        connection.execute(
            text(
                "INSERT INTO core_die (test_session_id,x_coord,y_coord,hard_bin_no,soft_bin_no,pass_flag,vi_flag,source_raw_row_id,coordinate_transform_revision_id) VALUES "
                f"{die_values} ON DUPLICATE KEY UPDATE hard_bin_no=VALUES(hard_bin_no),soft_bin_no=VALUES(soft_bin_no),pass_flag=VALUES(pass_flag),source_raw_row_id=VALUES(source_raw_row_id)"
            )
        )
        die_ids = {(int(session_id), int(x_coord), int(y_coord)): int(die_id) for die_id, session_id, x_coord, y_coord in connection.execute(text("SELECT d.die_id,d.test_session_id,d.x_coord,d.y_coord FROM core_die d JOIN core_test_session s ON s.test_session_id=d.test_session_id WHERE s.data_release_id=:release"), {"release": release_id}).all()}
        measurement_values: list[str] = []
        for fixture in fixtures:
            session_id = session_ids[wafer_keys[(fixture.lot_id, fixture.wafer_no)]]
            failures = failure_coordinates(fixture.scenario_id)
            for x in range(10):
                for y in range(10):
                    shifted = fixture.scenario_id == "parameter_shift" and (x, y) in failures
                    measured_value = 10.4 if shifted else 5.0
                    fail_direction = "high" if shifted else "pass"
                    correlated_value = 10.15 if shifted else 4.5 + ((x - y) * 0.025)
                    correlated_direction = "high" if correlated_value > 10 else "pass"
                    die_id = die_ids[(session_id, x, y)]
                    measurement_values.append(
                        f"({die_id},{shift_parameter_version_id},{measured_value},'{fail_direction}','{digest(f'measurement-{die_id}-{shift_parameter_version_id}')}')"
                    )
                    measurement_values.append(
                        f"({die_id},{correlation_parameter_version_id},{correlated_value},'{correlated_direction}','{digest(f'measurement-{die_id}-{correlation_parameter_version_id}')}')"
                    )
        connection.execute(text("INSERT INTO core_die_measurement (die_id,parameter_version_id,measured_value,fail_direction,source_measurement_hash) VALUES " + ",".join(measurement_values) + " ON DUPLICATE KEY UPDATE measured_value=VALUES(measured_value),fail_direction=VALUES(fail_direction)"))
        connection.execute(text("INSERT INTO source_veda_cp_wafer_sum (fab_name,lot_id,test_type,wafer_no,range_index,wafer_id,gross_die,tested_die,good_die,yield_value,map_x_min,map_x_max,map_y_min,map_y_max,bin_counts,source_payload,source_hash) VALUES ('FAB1',:lot,'CP1',:wafer_no,1,:wafer_id,100,100,:good,:yield,0,9,0,9,CAST(:bins AS JSON),CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE good_die=VALUES(good_die),yield_value=VALUES(yield_value),bin_counts=VALUES(bin_counts)"), source_summary_rows)
        connection.execute(text("INSERT INTO analytics_wafer_summary (data_release_id,wafer_key,test_session_id,gross_die,tested_die,good_die,yield_value,map_x_min,map_x_max,map_y_min,map_y_max,materialization_hash) VALUES (:release,:wafer,:session,100,100,:good,:yield,0,9,0,9,:hash)"), summary_rows)
        summary_ids = {(int(wafer_key), int(session_id)): int(summary_id) for wafer_key, session_id, summary_id in connection.execute(text("SELECT wafer_key,test_session_id,wafer_summary_id FROM analytics_wafer_summary WHERE data_release_id=:release"), {"release": release_id}).all()}
        for row in summary_rows:
            summary_id = summary_ids[(int(row["wafer"]), int(row["session"]))]
            bin_summary_rows.extend([{"summary": summary_id, "soft": 1, "hard": 1, "count": 100 - int(row["fail_count"]), "rate": (100 - int(row["fail_count"])) / 100}, {"summary": summary_id, "soft": row["soft"], "hard": row["hard"], "count": row["fail_count"], "rate": int(row["fail_count"]) / 100}])
        connection.execute(text("INSERT INTO analytics_wafer_bin_summary (wafer_summary_id,soft_bin_no,hard_bin_no,bin_count,bin_rate) VALUES (:summary,:soft,:hard,:count,:rate)"), bin_summary_rows)

        connection.execute(text("INSERT INTO source_veda_cp_wafer (fab_name,lot_id,test_type,wafer_no,wafer_id,part_number,measured_at,test_program,bin_def_name,test_eqp_id,probe_card,source_payload,source_hash) VALUES ('FAB1','CPDEV999','CP1',1,'CPDEV999-01','VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-99','PC-99',CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE source_hash=VALUES(source_hash)"), {"payload": json.dumps({"scenario": "bad_input_quarantine"}), "hash": digest("wafer-CPDEV999-01")})
        connection.execute(text("INSERT INTO source_veda_cp_raw (fab_name,lot_id,test_type,wafer_no,wafer_id,measured_at,y_coord,view_flag,bin_string,vi_string,bin_type_string,source_payload,source_hash) VALUES ('FAB1','CPDEV999','CP1',1,'CPDEV999-01',NOW(6),-1,1,'99','','',CAST(:payload AS JSON),:hash) ON DUPLICATE KEY UPDATE source_hash=VALUES(source_hash)"), {"payload": json.dumps({"scenario": "bad_input_quarantine", "coordinate": -1}), "hash": digest("bad-raw")})
        bad_raw_id = scalar(connection, "SELECT source_row_id FROM source_veda_cp_raw WHERE fab_name='FAB1' AND lot_id='CPDEV999' AND test_type='CP1' AND wafer_no=1 AND y_coord=-1", {})
        connection.execute(text("INSERT INTO ingest_validation_result (ingestion_run_id,rule_code,severity,source_table_name,source_row_id,details) SELECT :run,'COORDINATE_OUT_OF_RANGE','blocking','source_veda_cp_raw',:source,CAST(:details AS JSON) WHERE NOT EXISTS (SELECT 1 FROM ingest_validation_result WHERE ingestion_run_id=:run AND rule_code='COORDINATE_OUT_OF_RANGE' AND source_row_id=:source)"), {"run": run_id, "source": bad_raw_id, "details": json.dumps({"scenario": "bad_input_quarantine", "reason": "y=-1 violates approved coordinate bounds"})})
        connection.execute(text("INSERT INTO governance_audit_event (data_release_id,actor,action_name,entity_type,entity_key,correlation_id,metadata_json) VALUES (:release,'fixture-data-steward','release.approve','data_release',:key,'00000000-0000-0000-0000-000000000001',CAST(:metadata AS JSON))"), {"release": release_id, "key": APPROVED_RELEASE_KEY, "metadata": json.dumps({"fixture_seed": FIXTURE_SEED, "approved_wafers": len(fixtures)})})

    print(f"Seeded {APPROVED_RELEASE_KEY} with {len(fixtures)} approved synthetic wafer scenarios.")


if __name__ == "__main__":
    main()
