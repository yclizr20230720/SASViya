# PostgreSQL Database Foundation

This directory contains the CP platform's development migrations, source-to-canonical mapping metadata, fixture manifests, and reconciliation SQL. The managed project template's MySQL-compatible database is the active development target so the source mirror, deterministic fixtures, and release-gated workflows can be implemented immediately.

The development target uses the managed `DATABASE_URL` under `CP_DATABASE_TARGET=builtin_mysql`. Production migration remains PostgreSQL-compatible: setting `CP_DATABASE_TARGET=postgresql` makes the service use the `CP_DATABASE_URL` secret after a reachable PostgreSQL database is provisioned.

The migration order is intentionally strict:

1. Development migration metadata and access controls.
2. All 28 `source_veda_` compatibility tables.
3. `ingest_`, `core_`, `governance_`, `analytics_`, and `authz_` logical table families.
4. Deterministic source fixtures and their approved data release.
5. Source-to-canonical materialization and reconciliation assertions.

No API query may use raw source tables as a fallback. Application endpoints consume canonical or analytics records that are linked to an approved `governance.data_release`.
