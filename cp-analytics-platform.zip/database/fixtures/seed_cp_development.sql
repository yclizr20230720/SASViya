-- Deterministic synthetic CP fixture: veda-cp-dev-seed-20260823
-- The execution path inserts source evidence first, then approved canonical records.

INSERT INTO ingest_ingestion_run (source_system, parser_version, status, source_manifest_hash, initiated_by)
SELECT 'synthetic_veda_cp', 'fixture-parser-v1', 'validated', SHA2('veda-cp-dev-seed-20260823',256), 'fixture-loader'
WHERE NOT EXISTS (SELECT 1 FROM ingest_ingestion_run WHERE source_manifest_hash = SHA2('veda-cp-dev-seed-20260823',256));

INSERT INTO governance_data_release (release_key, ingestion_run_id, status, source_manifest_hash, approved_by, approved_at)
SELECT 'CPDEV-20260823-R1', r.ingestion_run_id, 'analytics_ready', r.source_manifest_hash, 'fixture-data-steward', NOW(6)
FROM ingest_ingestion_run r
WHERE r.source_manifest_hash = SHA2('veda-cp-dev-seed-20260823',256)
  AND NOT EXISTS (SELECT 1 FROM governance_data_release WHERE release_key = 'CPDEV-20260823-R1');

INSERT INTO source_veda_cp_bin_definition (fab_name, part_number, bin_def_name, bin_number, bin_name, description_text, good_bin_flag, hard_bin_number, hard_bin_name, hard_good_bin_flag, source_payload, source_hash)
VALUES
('FAB1','VEDA-CP-DEV','CPDEV-BIN-R1',1,'PASS','Functional pass',1,1,'PASS',1,JSON_OBJECT('scenario','baseline_good'),SHA2('bin-1',256)),
('FAB1','VEDA-CP-DEV','CPDEV-BIN-R1',5,'EDGE','Edge ring loss',0,2,'EDGE',0,JSON_OBJECT('scenario','edge_ring'),SHA2('bin-5',256)),
('FAB1','VEDA-CP-DEV','CPDEV-BIN-R1',10,'CENTR','Center cluster',0,3,'CENTR',0,JSON_OBJECT('scenario','center_cluster'),SHA2('bin-10',256)),
('FAB1','VEDA-CP-DEV','CPDEV-BIN-R1',20,'SCRAT','Scratch pattern',0,4,'SCRAT',0,JSON_OBJECT('scenario','scratch'),SHA2('bin-20',256)),
('FAB1','VEDA-CP-DEV','CPDEV-BIN-R1',30,'SITE','Site signature',0,5,'SITE',0,JSON_OBJECT('scenario','site_anomaly'),SHA2('bin-30',256)),
('FAB1','VEDA-CP-DEV','CPDEV-BIN-R1',40,'PARAM','Parametric shift',0,6,'PARAM',0,JSON_OBJECT('scenario','parameter_shift'),SHA2('bin-40',256)),
('FAB1','VEDA-CP-DEV','CPDEV-BIN-R1',50,'RETES','Retest flip',0,7,'RETES',0,JSON_OBJECT('scenario','retest_fail_flip'),SHA2('bin-50',256))
ON DUPLICATE KEY UPDATE source_hash=VALUES(source_hash);

INSERT INTO source_veda_cp_init_axis (fab_name, customer_id, test_fab_id, product_id, version_no, part_number, lb_axis_x, lb_axis_y, rt_axis_x, rt_axis_y, source_payload, source_hash)
VALUES ('FAB1','C001','T001','P001','1','VEDA-CP-DEV',0,0,9,0,JSON_OBJECT('orientation','notch_up'),SHA2('axis-dev',256))
ON DUPLICATE KEY UPDATE source_hash=VALUES(source_hash);

INSERT INTO source_veda_cp_lot (fab_name, lot_id, test_type, part_number, measured_at, test_program, bin_def_name, test_eqp_id, probe_card, source_payload, source_hash)
VALUES
('FAB1','CPDEV100','CP1','VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-01','PC-01',JSON_OBJECT('scenario','baseline_good'),SHA2('lot-100',256)),
('FAB1','CPDEV200','CP1','VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-01','PC-01',JSON_OBJECT('scenario','edge_ring'),SHA2('lot-200',256)),
('FAB1','CPDEV201','CP1','VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-01','PC-01',JSON_OBJECT('scenario','center_cluster'),SHA2('lot-201',256)),
('FAB1','CPDEV202','CP1','VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-01','PC-01',JSON_OBJECT('scenario','scratch'),SHA2('lot-202',256)),
('FAB1','CPDEV203','CP1','VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-01','PC-02',JSON_OBJECT('scenario','site_anomaly'),SHA2('lot-203',256)),
('FAB1','CPDEV204','CP1','VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-02','PC-03',JSON_OBJECT('scenario','parameter_shift'),SHA2('lot-204',256)),
('FAB1','CPDEV205','CP1','VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-02','PC-03',JSON_OBJECT('scenario','retest_fail_flip'),SHA2('lot-205',256)),
('FAB1','CPDEV999','CP1','VEDA-CP-DEV',NOW(6),'CPDEV-R1','CPDEV-BIN-R1','TSTR-99','PC-99',JSON_OBJECT('scenario','bad_input_quarantine'),SHA2('lot-999',256))
ON DUPLICATE KEY UPDATE source_hash=VALUES(source_hash);
