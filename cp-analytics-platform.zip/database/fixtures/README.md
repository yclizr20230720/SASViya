# Deterministic CP Development Fixtures

The development fixture set is synthetic, non-identifying, and deterministic. Its fixed seed is `veda-cp-dev-seed-20260823`; it is never derived from customer, tester, or production data.

The published fixture release contains three comparable baseline wafers and six analytical excursion wafers. The `bad_input_quarantine` scenario deliberately contains an invalid coordinate and unknown bin mapping. It is retained as traceable source evidence and a blocking validation result, but it is never linked to the approved release.

The corresponding seed materializes VEDA source headers, bin definitions, raw map evidence, canonical products/lots/wafers/test sessions/dies, 100 parameter definitions, deterministic parameter measurements, wafer summaries, bin summaries, release snapshots, and audit rows. The `parameter_shift` scenario produces high-limit failures for `CP_PARAM_001`, while all other fixture die measurements remain in range. Reconciliation must confirm that released yield equals `good_die / tested_die`, bin totals equal tested-die counts, coordinate bounds enclose all canonical dies, and every canonical record references its source and approved release lineage.
