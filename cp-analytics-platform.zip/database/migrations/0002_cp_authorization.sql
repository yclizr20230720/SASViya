-- CP approved-release access control for the MySQL development target.
CREATE TABLE IF NOT EXISTS authz_role (
  role_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  role_code VARCHAR(64) NOT NULL,
  description_text VARCHAR(255) NOT NULL,
  UNIQUE KEY uq_authz_role (role_code)
);

CREATE TABLE IF NOT EXISTS authz_permission (
  permission_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  permission_code VARCHAR(128) NOT NULL,
  description_text VARCHAR(255) NOT NULL,
  UNIQUE KEY uq_authz_permission (permission_code)
);

CREATE TABLE IF NOT EXISTS authz_role_permission (
  role_id BIGINT UNSIGNED NOT NULL,
  permission_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  CONSTRAINT fk_authz_role_permission_role FOREIGN KEY (role_id) REFERENCES authz_role(role_id),
  CONSTRAINT fk_authz_role_permission_permission FOREIGN KEY (permission_id) REFERENCES authz_permission(permission_id)
);

CREATE TABLE IF NOT EXISTS authz_product_scope (
  product_scope_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id BIGINT UNSIGNED NOT NULL,
  scope_code VARCHAR(128) NOT NULL,
  UNIQUE KEY uq_authz_product_scope (product_id, scope_code),
  CONSTRAINT fk_authz_product_scope_product FOREIGN KEY (product_id) REFERENCES core_product(product_id)
);

CREATE TABLE IF NOT EXISTS authz_user_product_scope (
  user_open_id VARCHAR(128) NOT NULL,
  role_id BIGINT UNSIGNED NOT NULL,
  product_scope_id BIGINT UNSIGNED NOT NULL,
  granted_by VARCHAR(128) NOT NULL,
  granted_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (user_open_id, role_id, product_scope_id),
  CONSTRAINT fk_authz_user_scope_role FOREIGN KEY (role_id) REFERENCES authz_role(role_id),
  CONSTRAINT fk_authz_user_scope_product FOREIGN KEY (product_scope_id) REFERENCES authz_product_scope(product_scope_id)
);
