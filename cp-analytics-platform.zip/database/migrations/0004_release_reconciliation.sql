CREATE TABLE IF NOT EXISTS governance_release_validation (
  release_validation_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  data_release_id BIGINT UNSIGNED NOT NULL,
  rule_code VARCHAR(96) NOT NULL,
  severity ENUM('warning','blocking') NOT NULL,
  outcome ENUM('passed','failed') NOT NULL,
  result_json JSON NOT NULL,
  validated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_governance_release_validation (data_release_id, rule_code),
  KEY ix_governance_release_validation_status (data_release_id, severity, outcome),
  CONSTRAINT fk_governance_release_validation_release FOREIGN KEY (data_release_id) REFERENCES governance_data_release(data_release_id)
);
