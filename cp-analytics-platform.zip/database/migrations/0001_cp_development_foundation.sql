-- CP Analytics Platform development foundation
-- Target: MySQL-compatible development database. PostgreSQL migration equivalents
-- retain the same logical table and column contracts with dialect-specific types.

CREATE TABLE IF NOT EXISTS source_veda_cp_alarm (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL,
  record_id BIGINT NOT NULL,
  lot_id VARCHAR(64) NOT NULL,
  hist_date DATETIME(6) NULL,
  part_number VARCHAR(32) NULL,
  baseline_yield DECIMAL(12,6) NULL,
  yield_value DECIMAL(12,6) NULL,
  failure_category VARCHAR(32) NULL,
  source_payload JSON NOT NULL,
  source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_alarm (record_id, lot_id, fab_name),
  KEY ix_source_veda_cp_alarm_part (part_number, hist_date)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_batch (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, lot_id VARCHAR(64) NOT NULL, test_type VARCHAR(32) NOT NULL,
  wafer_no INT NOT NULL, part_number VARCHAR(32) NULL, task_group VARCHAR(50) NULL,
  bin_def_name VARCHAR(80) NULL, source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_batch (fab_name, lot_id, test_type, wafer_no)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_batch_result (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, file_name VARCHAR(200) NOT NULL, gross_die BIGINT NULL,
  bin_version INT NULL, result_code VARCHAR(2) NULL, task_group VARCHAR(50) NULL, log_time DATETIME(6) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_batch_result (fab_name, file_name, task_group, log_time)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_bin_definition (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, part_number VARCHAR(32) NOT NULL, bin_def_name VARCHAR(80) NOT NULL,
  bin_number BIGINT NOT NULL, bin_name VARCHAR(20) NULL, description_text VARCHAR(255) NULL,
  bin_spec VARCHAR(2) NULL, good_bin_flag TINYINT NULL, hard_bin_number BIGINT NULL,
  hard_bin_name VARCHAR(20) NULL, hard_good_bin_flag TINYINT NULL, effective_at DATETIME(6) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_bin_definition (part_number, bin_def_name, bin_number, fab_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_convert_set (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, customer_id INT NOT NULL, test_fab_id INT NOT NULL,
  part_number VARCHAR(32) NOT NULL, version_no INT NOT NULL, convert_type INT NULL,
  bin_def_name VARCHAR(80) NULL, cp_number INT NULL, mirror_flag TINYINT NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_convert_set (part_number, customer_id, test_fab_id, version_no, fab_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_grossdie (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_name VARCHAR(32) NOT NULL, fab_name VARCHAR(5) NULL, gross_die BIGINT NULL, actual_die BIGINT NULL,
  chip_size_x DECIMAL(18,6) NULL, chip_size_y DECIMAL(18,6) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_grossdie (product_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_grossdie_hist (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_name VARCHAR(32) NOT NULL, fab_name VARCHAR(5) NULL, gross_die BIGINT NULL, actual_die BIGINT NULL,
  created_at DATETIME(6) NOT NULL, source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_grossdie_hist (product_name, created_at)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_hwbin_header (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NULL, product_name VARCHAR(32) NOT NULL, bin_def_name VARCHAR(80) NOT NULL,
  version_no VARCHAR(12) NOT NULL, created_by VARCHAR(64) NULL, created_at DATETIME(6) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_hwbin_header (bin_def_name, version_no)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_hwbin_hist (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bin_def_name VARCHAR(80) NOT NULL, bin_number BIGINT NOT NULL, version_no VARCHAR(12) NOT NULL,
  description_text VARCHAR(255) NOT NULL, bin_spec VARCHAR(2) NULL, created_at DATETIME(6) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_hwbin_hist (bin_def_name, bin_number, version_no)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_initcoor (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NULL, customer_id INT NOT NULL, test_fab_id INT NOT NULL, part_number VARCHAR(32) NOT NULL,
  min_x BIGINT NULL, min_y BIGINT NULL, max_x BIGINT NULL, max_y BIGINT NULL, run_flag VARCHAR(10) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_initcoor (customer_id, test_fab_id, part_number)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_init_axis (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, customer_id VARCHAR(12) NOT NULL, test_fab_id VARCHAR(12) NOT NULL,
  product_id VARCHAR(12) NOT NULL, version_no VARCHAR(12) NOT NULL, part_number VARCHAR(32) NOT NULL,
  lot_id VARCHAR(64) NULL, wafer_no VARCHAR(32) NULL, golden_status VARCHAR(2) NULL,
  lb_axis_x BIGINT NULL, lb_axis_y BIGINT NULL, rt_axis_x BIGINT NULL, rt_axis_y BIGINT NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_init_axis (fab_name, customer_id, test_fab_id, product_id, version_no, part_number)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_init_axis_hist (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NULL, customer_id VARCHAR(12) NULL, test_fab_id VARCHAR(12) NULL,
  product_id VARCHAR(12) NULL, version_no VARCHAR(12) NULL, part_number VARCHAR(32) NULL,
  lot_id VARCHAR(64) NULL, wafer_no VARCHAR(32) NULL, lb_axis_x BIGINT NULL, lb_axis_y BIGINT NULL,
  rt_axis_x BIGINT NULL, rt_axis_y BIGINT NULL, recorded_at DATETIME(6) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  KEY ix_source_veda_cp_init_axis_hist_part (part_number, recorded_at)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_lot (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, lot_id VARCHAR(64) NOT NULL, test_type VARCHAR(32) NOT NULL,
  part_number VARCHAR(32) NULL, measured_at DATETIME(6) NULL, test_program VARCHAR(80) NULL,
  bin_def_name VARCHAR(80) NULL, test_eqp_id VARCHAR(50) NULL, probe_card VARCHAR(32) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_lot (lot_id, test_type, fab_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_lot_ptn_dtl (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pattern_key VARCHAR(30) NOT NULL, classify_result VARCHAR(20) NOT NULL, classify_rate DECIMAL(12,6) NOT NULL,
  classify_date DATETIME(6) NOT NULL, source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_lot_ptn_dtl (pattern_key, classify_result)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_lot_ptn_info (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pattern_key VARCHAR(30) NOT NULL, lot_id VARCHAR(64) NOT NULL, test_type VARCHAR(32) NOT NULL,
  part6 VARCHAR(6) NULL, part7 VARCHAR(7) NULL, classify_date DATETIME(6) NOT NULL,
  image_path VARCHAR(255) NULL, model_version VARCHAR(32) NULL, pattern_issue VARCHAR(32) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_lot_ptn_info (pattern_key)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_lot_sum (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, lot_id VARCHAR(64) NOT NULL, test_type VARCHAR(32) NOT NULL,
  range_index INT NOT NULL, measured_at DATETIME(6) NULL, wafer_count INT NULL, gross_die BIGINT NULL,
  tested_die BIGINT NULL, good_die BIGINT NULL, yield_value DECIMAL(12,6) NULL, bin_counts JSON NOT NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_lot_sum (lot_id, test_type, range_index, fab_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_lot_sum_sync (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lot_id VARCHAR(64) NOT NULL, test_type VARCHAR(32) NOT NULL, synced_at DATETIME(6) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_lot_sum_sync (lot_id, test_type)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_ptn_redefine (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, username VARCHAR(64) NOT NULL, image_path VARCHAR(255) NOT NULL,
  redefined_pattern VARCHAR(32) NOT NULL, redefined_at DATETIME(6) NOT NULL, retrain_flag VARCHAR(1) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  KEY ix_source_veda_cp_ptn_redefine (fab_name, redefined_at)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_raw (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, lot_id VARCHAR(64) NOT NULL, test_type VARCHAR(32) NOT NULL,
  wafer_no INT NOT NULL, wafer_id VARCHAR(32) NULL, measured_at DATETIME(6) NULL, y_coord BIGINT NOT NULL,
  view_flag BIGINT NULL, bin_string LONGTEXT NULL, vi_string LONGTEXT NULL, bin_type_string LONGTEXT NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_raw (fab_name, lot_id, test_type, wafer_no, y_coord),
  KEY ix_source_veda_cp_raw_wafer (fab_name, lot_id, test_type, wafer_no)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_raw_temp (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, lot_id VARCHAR(64) NOT NULL, test_type VARCHAR(32) NOT NULL,
  wafer_no INT NOT NULL, wafer_id VARCHAR(32) NULL, measured_at DATETIME(6) NULL, y_coord BIGINT NOT NULL,
  view_flag BIGINT NULL, bin_string LONGTEXT NULL, vi_string LONGTEXT NULL, bin_type_string LONGTEXT NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_raw_temp (lot_id, test_type, wafer_no, y_coord, fab_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_sample_rate_set_ol (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, part6 VARCHAR(6) NOT NULL, full_die_count INT NULL, sample_die_count INT NULL,
  modified_at DATETIME(6) NULL, source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_sample_rate_set_ol (part6, fab_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_test_prog_old (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, part_number VARCHAR(32) NOT NULL, bin_def_name VARCHAR(80) NOT NULL,
  test_program VARCHAR(80) NOT NULL, cp_ft_flag VARCHAR(5) NULL, notch_flag VARCHAR(5) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_test_prog_old (part_number, bin_def_name, test_program, fab_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_wafer (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, lot_id VARCHAR(64) NOT NULL, test_type VARCHAR(32) NOT NULL,
  wafer_no INT NOT NULL, wafer_id VARCHAR(32) NULL, part_number VARCHAR(32) NULL, measured_at DATETIME(6) NULL,
  test_program VARCHAR(80) NULL, bin_def_name VARCHAR(80) NULL, test_eqp_id VARCHAR(50) NULL,
  probe_card VARCHAR(32) NULL, source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_wafer (lot_id, test_type, wafer_no, fab_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_wafer_bin (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, lot_id VARCHAR(64) NOT NULL, test_type VARCHAR(32) NOT NULL,
  wafer_no INT NOT NULL, wafer_id VARCHAR(32) NULL, bin_no BIGINT NOT NULL, bin_type VARCHAR(1) NULL,
  bin_count BIGINT NOT NULL, measured_at DATETIME(6) NULL, gross_die BIGINT NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_wafer_bin (lot_id, test_type, wafer_no, bin_no, fab_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_wafer_ptn_dtl (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pattern_key VARCHAR(30) NOT NULL, classify_result VARCHAR(20) NOT NULL, classify_rate DECIMAL(12,6) NOT NULL,
  classify_date DATETIME(6) NOT NULL, source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_wafer_ptn_dtl (pattern_key, classify_result)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_wafer_ptn_info (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pattern_key VARCHAR(30) NOT NULL, lot_id VARCHAR(64) NOT NULL, wafer_no INT NOT NULL, test_type VARCHAR(32) NOT NULL,
  part6 VARCHAR(6) NULL, part7 VARCHAR(7) NULL, classify_date DATETIME(6) NOT NULL,
  image_path VARCHAR(255) NULL, model_version VARCHAR(32) NULL, pattern_issue VARCHAR(32) NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_wafer_ptn_info (pattern_key)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_wafer_sum (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, lot_id VARCHAR(64) NOT NULL, test_type VARCHAR(32) NOT NULL,
  wafer_no INT NOT NULL, range_index INT NOT NULL, wafer_id VARCHAR(32) NULL, measured_at DATETIME(6) NULL,
  gross_die BIGINT NULL, tested_die BIGINT NULL, good_die BIGINT NULL, yield_value DECIMAL(12,6) NULL,
  map_x_min BIGINT NULL, map_x_max BIGINT NULL, map_y_min BIGINT NULL, map_y_max BIGINT NULL,
  bin_counts JSON NOT NULL, source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_wafer_sum (lot_id, test_type, wafer_no, range_index, fab_name)
);

CREATE TABLE IF NOT EXISTS source_veda_cp_zone (
  source_row_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, part6 VARCHAR(6) NOT NULL, lot_id VARCHAR(64) NOT NULL,
  test_type VARCHAR(32) NOT NULL, wafer_no INT NOT NULL, y_coord BIGINT NOT NULL,
  zone_3c LONGTEXT NULL, zone_4c LONGTEXT NULL, zone_8p LONGTEXT NULL, zone_9s LONGTEXT NULL,
  zone_5s LONGTEXT NULL, zone_5w LONGTEXT NULL, zone_9w LONGTEXT NULL,
  source_payload JSON NOT NULL, source_hash CHAR(64) NOT NULL,
  source_loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_source_veda_cp_zone (part6, y_coord)
);

CREATE TABLE IF NOT EXISTS ingest_ingestion_run (
  ingestion_run_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  source_system VARCHAR(64) NOT NULL, parser_version VARCHAR(64) NOT NULL,
  status ENUM('started','validated','published','failed') NOT NULL,
  started_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), completed_at DATETIME(6) NULL,
  source_manifest_hash CHAR(64) NOT NULL, initiated_by VARCHAR(128) NOT NULL
);

CREATE TABLE IF NOT EXISTS ingest_validation_result (
  validation_result_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ingestion_run_id BIGINT UNSIGNED NOT NULL, rule_code VARCHAR(64) NOT NULL,
  severity ENUM('warning','blocking') NOT NULL, source_table_name VARCHAR(128) NOT NULL,
  source_row_id BIGINT UNSIGNED NULL, details JSON NOT NULL, created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  KEY ix_ingest_validation_result_run (ingestion_run_id, severity),
  CONSTRAINT fk_ingest_validation_run FOREIGN KEY (ingestion_run_id) REFERENCES ingest_ingestion_run(ingestion_run_id)
);

CREATE TABLE IF NOT EXISTS governance_data_release (
  data_release_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  release_key VARCHAR(64) NOT NULL, ingestion_run_id BIGINT UNSIGNED NOT NULL,
  status ENUM('pending_validation','rejected','approved','analytics_ready','superseded') NOT NULL,
  source_manifest_hash CHAR(64) NOT NULL, approved_by VARCHAR(128) NULL, approved_at DATETIME(6) NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_governance_data_release_key (release_key),
  KEY ix_governance_data_release_status (status, created_at),
  CONSTRAINT fk_governance_release_run FOREIGN KEY (ingestion_run_id) REFERENCES ingest_ingestion_run(ingestion_run_id)
);

CREATE TABLE IF NOT EXISTS governance_data_snapshot (
  data_snapshot_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  data_release_id BIGINT UNSIGNED NOT NULL, snapshot_hash CHAR(64) NOT NULL,
  transform_version VARCHAR(64) NOT NULL, created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_governance_data_snapshot_hash (snapshot_hash),
  CONSTRAINT fk_governance_snapshot_release FOREIGN KEY (data_release_id) REFERENCES governance_data_release(data_release_id)
);

CREATE TABLE IF NOT EXISTS core_product (
  product_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fab_name VARCHAR(5) NOT NULL, part_number VARCHAR(32) NOT NULL, product_revision VARCHAR(64) NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_core_product (fab_name, part_number, product_revision)
);

CREATE TABLE IF NOT EXISTS core_lot (
  lot_key BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id BIGINT UNSIGNED NOT NULL, fab_name VARCHAR(5) NOT NULL, lot_id VARCHAR(64) NOT NULL,
  test_type VARCHAR(32) NOT NULL, measured_at DATETIME(6) NULL,
  CONSTRAINT fk_core_lot_product FOREIGN KEY (product_id) REFERENCES core_product(product_id),
  UNIQUE KEY uq_core_lot (fab_name, lot_id, test_type)
);

CREATE TABLE IF NOT EXISTS core_wafer (
  wafer_key BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lot_key BIGINT UNSIGNED NOT NULL, wafer_no INT NOT NULL, wafer_id VARCHAR(32) NULL,
  source_wafer_row_id BIGINT UNSIGNED NULL,
  CONSTRAINT fk_core_wafer_lot FOREIGN KEY (lot_key) REFERENCES core_lot(lot_key),
  CONSTRAINT fk_core_wafer_source FOREIGN KEY (source_wafer_row_id) REFERENCES source_veda_cp_wafer(source_row_id),
  UNIQUE KEY uq_core_wafer (lot_key, wafer_no)
);

CREATE TABLE IF NOT EXISTS core_bin_definition_revision (
  bin_definition_revision_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  data_release_id BIGINT UNSIGNED NOT NULL, fab_name VARCHAR(5) NOT NULL, part_number VARCHAR(32) NOT NULL,
  bin_def_name VARCHAR(80) NOT NULL, revision_hash CHAR(64) NOT NULL,
  CONSTRAINT fk_core_bin_revision_release FOREIGN KEY (data_release_id) REFERENCES governance_data_release(data_release_id),
  UNIQUE KEY uq_core_bin_definition_revision (data_release_id, fab_name, part_number, bin_def_name)
);

CREATE TABLE IF NOT EXISTS core_bin_definition (
  bin_definition_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bin_definition_revision_id BIGINT UNSIGNED NOT NULL, soft_bin_no BIGINT NOT NULL, soft_bin_name VARCHAR(32) NULL,
  hard_bin_no BIGINT NULL, hard_bin_name VARCHAR(32) NULL, is_good_bin BOOLEAN NOT NULL DEFAULT FALSE,
  source_bin_row_id BIGINT UNSIGNED NULL,
  CONSTRAINT fk_core_bin_definition_revision FOREIGN KEY (bin_definition_revision_id) REFERENCES core_bin_definition_revision(bin_definition_revision_id),
  CONSTRAINT fk_core_bin_definition_source FOREIGN KEY (source_bin_row_id) REFERENCES source_veda_cp_bin_definition(source_row_id),
  UNIQUE KEY uq_core_bin_definition (bin_definition_revision_id, soft_bin_no)
);

CREATE TABLE IF NOT EXISTS core_test_session (
  test_session_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  data_release_id BIGINT UNSIGNED NOT NULL, wafer_key BIGINT UNSIGNED NOT NULL,
  test_program VARCHAR(80) NULL, bin_definition_revision_id BIGINT UNSIGNED NULL,
  tester_id VARCHAR(50) NULL, probe_card_id VARCHAR(50) NULL, measured_at DATETIME(6) NULL,
  pass_index INT NOT NULL DEFAULT 1, source_raw_hash CHAR(64) NULL,
  CONSTRAINT fk_core_test_session_release FOREIGN KEY (data_release_id) REFERENCES governance_data_release(data_release_id),
  CONSTRAINT fk_core_test_session_wafer FOREIGN KEY (wafer_key) REFERENCES core_wafer(wafer_key),
  CONSTRAINT fk_core_test_session_bin_revision FOREIGN KEY (bin_definition_revision_id) REFERENCES core_bin_definition_revision(bin_definition_revision_id),
  UNIQUE KEY uq_core_test_session (data_release_id, wafer_key, pass_index)
);

CREATE TABLE IF NOT EXISTS core_coordinate_transform_revision (
  coordinate_transform_revision_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  data_release_id BIGINT UNSIGNED NOT NULL, product_id BIGINT UNSIGNED NOT NULL,
  min_x BIGINT NOT NULL, min_y BIGINT NOT NULL, max_x BIGINT NOT NULL, max_y BIGINT NOT NULL,
  orientation_code VARCHAR(32) NOT NULL, source_axis_row_id BIGINT UNSIGNED NULL,
  CONSTRAINT fk_core_coordinate_release FOREIGN KEY (data_release_id) REFERENCES governance_data_release(data_release_id),
  CONSTRAINT fk_core_coordinate_product FOREIGN KEY (product_id) REFERENCES core_product(product_id),
  UNIQUE KEY uq_core_coordinate_revision (data_release_id, product_id, orientation_code)
);

CREATE TABLE IF NOT EXISTS core_die (
  die_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  test_session_id BIGINT UNSIGNED NOT NULL, x_coord BIGINT NOT NULL, y_coord BIGINT NOT NULL,
  hard_bin_no BIGINT NULL, soft_bin_no BIGINT NULL, pass_flag BOOLEAN NOT NULL, vi_flag BOOLEAN NULL,
  source_raw_row_id BIGINT UNSIGNED NULL, coordinate_transform_revision_id BIGINT UNSIGNED NOT NULL,
  CONSTRAINT fk_core_die_session FOREIGN KEY (test_session_id) REFERENCES core_test_session(test_session_id),
  CONSTRAINT fk_core_die_source FOREIGN KEY (source_raw_row_id) REFERENCES source_veda_cp_raw(source_row_id),
  CONSTRAINT fk_core_die_transform FOREIGN KEY (coordinate_transform_revision_id) REFERENCES core_coordinate_transform_revision(coordinate_transform_revision_id),
  UNIQUE KEY uq_core_die_location (test_session_id, x_coord, y_coord),
  KEY ix_core_die_session_bin (test_session_id, hard_bin_no, soft_bin_no)
);

CREATE TABLE IF NOT EXISTS core_parameter_definition (
  parameter_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  parameter_code VARCHAR(128) NOT NULL, display_name VARCHAR(256) NOT NULL, unit_name VARCHAR(64) NULL,
  UNIQUE KEY uq_core_parameter_definition (parameter_code)
);

CREATE TABLE IF NOT EXISTS core_parameter_version (
  parameter_version_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  parameter_id BIGINT UNSIGNED NOT NULL, data_release_id BIGINT UNSIGNED NOT NULL,
  test_number INT NULL, lower_limit DOUBLE NULL, upper_limit DOUBLE NULL, guardband_low DOUBLE NULL, guardband_high DOUBLE NULL,
  CONSTRAINT fk_core_parameter_version_definition FOREIGN KEY (parameter_id) REFERENCES core_parameter_definition(parameter_id),
  CONSTRAINT fk_core_parameter_version_release FOREIGN KEY (data_release_id) REFERENCES governance_data_release(data_release_id),
  UNIQUE KEY uq_core_parameter_version (parameter_id, data_release_id)
);

CREATE TABLE IF NOT EXISTS core_die_measurement (
  die_measurement_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  die_id BIGINT UNSIGNED NOT NULL, parameter_version_id BIGINT UNSIGNED NOT NULL, measured_value DOUBLE NULL,
  fail_direction ENUM('low','high','invalid','pass') NOT NULL, source_measurement_hash CHAR(64) NOT NULL,
  CONSTRAINT fk_core_die_measurement_die FOREIGN KEY (die_id) REFERENCES core_die(die_id),
  CONSTRAINT fk_core_die_measurement_parameter FOREIGN KEY (parameter_version_id) REFERENCES core_parameter_version(parameter_version_id),
  UNIQUE KEY uq_core_die_measurement (die_id, parameter_version_id)
);

CREATE TABLE IF NOT EXISTS analytics_wafer_summary (
  wafer_summary_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  data_release_id BIGINT UNSIGNED NOT NULL, wafer_key BIGINT UNSIGNED NOT NULL, test_session_id BIGINT UNSIGNED NOT NULL,
  gross_die BIGINT NOT NULL, tested_die BIGINT NOT NULL, good_die BIGINT NOT NULL, yield_value DECIMAL(12,6) NOT NULL,
  map_x_min BIGINT NOT NULL, map_x_max BIGINT NOT NULL, map_y_min BIGINT NOT NULL, map_y_max BIGINT NOT NULL,
  materialization_hash CHAR(64) NOT NULL, created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  CONSTRAINT fk_analytics_wafer_summary_release FOREIGN KEY (data_release_id) REFERENCES governance_data_release(data_release_id),
  CONSTRAINT fk_analytics_wafer_summary_wafer FOREIGN KEY (wafer_key) REFERENCES core_wafer(wafer_key),
  CONSTRAINT fk_analytics_wafer_summary_session FOREIGN KEY (test_session_id) REFERENCES core_test_session(test_session_id),
  UNIQUE KEY uq_analytics_wafer_summary (data_release_id, wafer_key, test_session_id),
  KEY ix_analytics_wafer_summary_release_yield (data_release_id, yield_value)
);

CREATE TABLE IF NOT EXISTS analytics_wafer_bin_summary (
  wafer_bin_summary_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  wafer_summary_id BIGINT UNSIGNED NOT NULL, soft_bin_no BIGINT NULL, hard_bin_no BIGINT NULL,
  bin_count BIGINT NOT NULL, bin_rate DECIMAL(12,8) NOT NULL,
  CONSTRAINT fk_analytics_wafer_bin_summary FOREIGN KEY (wafer_summary_id) REFERENCES analytics_wafer_summary(wafer_summary_id),
  UNIQUE KEY uq_analytics_wafer_bin_summary (wafer_summary_id, soft_bin_no, hard_bin_no)
);

CREATE TABLE IF NOT EXISTS analytics_analysis_run (
  analysis_run_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  data_release_id BIGINT UNSIGNED NOT NULL, data_snapshot_id BIGINT UNSIGNED NULL,
  analysis_type VARCHAR(64) NOT NULL, status ENUM('queued','running','succeeded','failed') NOT NULL,
  input_hash CHAR(64) NOT NULL, configuration_json JSON NOT NULL, created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  CONSTRAINT fk_analytics_analysis_release FOREIGN KEY (data_release_id) REFERENCES governance_data_release(data_release_id),
  CONSTRAINT fk_analytics_analysis_snapshot FOREIGN KEY (data_snapshot_id) REFERENCES governance_data_snapshot(data_snapshot_id),
  UNIQUE KEY uq_analytics_analysis_run (data_release_id, analysis_type, input_hash)
);

CREATE TABLE IF NOT EXISTS analytics_analysis_result (
  analysis_result_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  analysis_run_id BIGINT UNSIGNED NOT NULL, entity_type VARCHAR(64) NOT NULL, entity_key VARCHAR(128) NOT NULL,
  result_json JSON NOT NULL, created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  CONSTRAINT fk_analytics_analysis_result FOREIGN KEY (analysis_run_id) REFERENCES analytics_analysis_run(analysis_run_id),
  KEY ix_analytics_analysis_result_run (analysis_run_id, entity_type)
);

CREATE TABLE IF NOT EXISTS authz_role (
  role_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  role_code VARCHAR(64) NOT NULL,
  description_text VARCHAR(255) NOT NULL,
  UNIQUE KEY uq_authz_role (role_code)
);

CREATE TABLE IF NOT EXISTS authz_permission (
  permission_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  permission_code VARCHAR(128) NOT NULL,
  description_text VARCHAR(255) NOT NULL,
  UNIQUE KEY uq_authz_permission (permission_code)
);

CREATE TABLE IF NOT EXISTS authz_role_permission (
  role_id BIGINT UNSIGNED NOT NULL,
  permission_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS authz_product_scope (
  product_scope_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id BIGINT UNSIGNED NOT NULL,
  scope_code VARCHAR(128) NOT NULL,
  UNIQUE KEY uq_authz_product_scope (product_id, scope_code)
);

CREATE TABLE IF NOT EXISTS authz_user_product_scope (
  user_open_id VARCHAR(128) NOT NULL,
  role_id BIGINT UNSIGNED NOT NULL,
  product_scope_id BIGINT UNSIGNED NOT NULL,
  granted_by VARCHAR(128) NOT NULL,
  granted_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (user_open_id, role_id, product_scope_id)
);
