-- Real CP export ingestion and approved-release selection support.

CREATE TABLE IF NOT EXISTS ingest_source_file (
  source_file_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ingestion_run_id BIGINT UNSIGNED NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  byte_count BIGINT UNSIGNED NOT NULL,
  table_sections_json JSON NOT NULL,
  loaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_ingest_source_file_hash (ingestion_run_id, original_filename, content_sha256),
  CONSTRAINT fk_ingest_source_file_run FOREIGN KEY (ingestion_run_id) REFERENCES ingest_ingestion_run(ingestion_run_id)
);

CREATE TABLE IF NOT EXISTS ingest_source_record (
  source_record_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ingestion_run_id BIGINT UNSIGNED NOT NULL,
  source_file_id BIGINT UNSIGNED NOT NULL,
  source_table_name VARCHAR(128) NOT NULL,
  source_line_number BIGINT UNSIGNED NOT NULL,
  source_payload JSON NOT NULL,
  source_hash CHAR(64) NOT NULL,
  validation_status ENUM('accepted','quarantined') NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  UNIQUE KEY uq_ingest_source_record_hash (ingestion_run_id, source_table_name, source_hash),
  KEY ix_ingest_source_record_table (ingestion_run_id, source_table_name, validation_status),
  CONSTRAINT fk_ingest_source_record_run FOREIGN KEY (ingestion_run_id) REFERENCES ingest_ingestion_run(ingestion_run_id),
  CONSTRAINT fk_ingest_source_record_file FOREIGN KEY (source_file_id) REFERENCES ingest_source_file(source_file_id)
);

CREATE TABLE IF NOT EXISTS ingest_source_quarantine (
  quarantine_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ingestion_run_id BIGINT UNSIGNED NOT NULL,
  source_file_id BIGINT UNSIGNED NOT NULL,
  source_table_name VARCHAR(128) NOT NULL,
  source_line_number BIGINT UNSIGNED NOT NULL,
  rule_code VARCHAR(96) NOT NULL,
  severity ENUM('warning','blocking') NOT NULL,
  details JSON NOT NULL,
  raw_payload JSON NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  KEY ix_ingest_quarantine_run (ingestion_run_id, severity, source_table_name),
  CONSTRAINT fk_ingest_quarantine_run FOREIGN KEY (ingestion_run_id) REFERENCES ingest_ingestion_run(ingestion_run_id),
  CONSTRAINT fk_ingest_quarantine_file FOREIGN KEY (source_file_id) REFERENCES ingest_source_file(source_file_id)
);

CREATE TABLE IF NOT EXISTS analytics_release_lot_filter (
  data_release_id BIGINT UNSIGNED NOT NULL,
  lot_key BIGINT UNSIGNED NOT NULL,
  fab_name VARCHAR(5) NOT NULL,
  part_number VARCHAR(64) NULL,
  part6 VARCHAR(64) NULL,
  lot_id VARCHAR(64) NOT NULL,
  test_program VARCHAR(128) NULL,
  bin_def_name VARCHAR(128) NULL,
  test_eqp_id VARCHAR(128) NULL,
  cp_probe_card VARCHAR(128) NULL,
  test_vendor VARCHAR(128) NULL,
  month_code VARCHAR(16) NULL,
  week_code VARCHAR(16) NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (data_release_id, lot_key),
  KEY ix_release_lot_filter_part (data_release_id, part_number, part6),
  KEY ix_release_lot_filter_lot (data_release_id, lot_id),
  KEY ix_release_lot_filter_program (data_release_id, test_program),
  KEY ix_release_lot_filter_equipment (data_release_id, test_eqp_id, cp_probe_card),
  KEY ix_release_lot_filter_calendar (data_release_id, month_code, week_code),
  CONSTRAINT fk_release_lot_filter_release FOREIGN KEY (data_release_id) REFERENCES governance_data_release(data_release_id),
  CONSTRAINT fk_release_lot_filter_lot FOREIGN KEY (lot_key) REFERENCES core_lot(lot_key)
);

ALTER TABLE source_veda_cp_zone DROP INDEX uq_zone;
ALTER TABLE source_veda_cp_zone ADD UNIQUE KEY uq_source_veda_cp_zone_context (fab_name, part6, lot_id, test_type, wafer_no, y_coord);
