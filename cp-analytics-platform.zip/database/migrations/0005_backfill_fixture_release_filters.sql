-- Preserve the existing deterministic CP fixture as an approved-release test dataset
-- after filter joins become mandatory for all analysis queries.
INSERT INTO analytics_release_lot_filter (
  data_release_id,lot_key,fab_name,part_number,part6,lot_id,
  test_program,bin_def_name,test_eqp_id,cp_probe_card,test_vendor,month_code,week_code
)
SELECT
  aws.data_release_id,l.lot_key,l.fab_name,p.part_number,p.product_revision,l.lot_id,
  MAX(ts.test_program),NULL,MAX(ts.tester_id),MAX(ts.probe_card_id),NULL,NULL,NULL
FROM analytics_wafer_summary aws
JOIN core_wafer w ON w.wafer_key=aws.wafer_key
JOIN core_lot l ON l.lot_key=w.lot_key
JOIN core_product p ON p.product_id=l.product_id
JOIN core_test_session ts ON ts.test_session_id=aws.test_session_id
WHERE aws.data_release_id=(SELECT data_release_id FROM governance_data_release WHERE release_key='CPDEV-20260823-R1')
GROUP BY aws.data_release_id,l.lot_key,l.fab_name,p.part_number,p.product_revision,l.lot_id
ON DUPLICATE KEY UPDATE test_program=VALUES(test_program),test_eqp_id=VALUES(test_eqp_id),cp_probe_card=VALUES(cp_probe_card);
