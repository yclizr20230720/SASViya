# Real CP Export Import Contract

The user-supplied CSV files are multi-table streams rather than one CSV per source table. The importer treats every `TABLE,VEDA_TBL_CP_*` marker as a new section and continues a section across a subsequent file until another marker is encountered. Every accepted record is retained in `ingest_source_record` with its original table name, physical source line, deterministic row hash, file hash, and ingestion-run identifier. Rows that do not conform to a section header are retained in `ingest_source_quarantine`; they do not enter canonical analysis tables.

The release selection layer reads the requested lot criteria from the source `VEDA_TBL_CP_LOT` record and materializes them into `analytics_release_lot_filter`. Filtering is applied only after the release has reached an approved analytics state. The query contract uses **OR within a selected criterion** and **AND across different criteria**, which is appropriate for multi-select investigation filters.

The current real-data release intentionally uses `VEDA_TBL_CP_WAFER_SUM` and `VEDA_TBL_CP_WAFER_BIN` as the analysis facts. Raw wafer rows are preserved and validated as source evidence; a die-level map is exposed only when a selected wafer has a complete and verified raw-grid transform. This avoids misrepresenting incomplete exported rows as a full wafer map.
