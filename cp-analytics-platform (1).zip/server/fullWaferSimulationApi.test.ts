import { describe, expect, it } from "vitest";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";
const simulationRelease = "CPSIM300-20260823-R1";

describe("full-wafer simulation release API", () => {
  it("exposes a provenance-labelled approved simulation release with a complete 3,096-die map", async () => {
    const catalogResponse = await fetch(`${baseUrl}/api/v1/releases/approved/catalog`);
    const catalog = (await catalogResponse.json()) as { releases: Array<{ key: string; provenance: string; waferCount: number }> };
    const simulation = catalog.releases.find((release) => release.key === simulationRelease);

    expect(catalogResponse.status).toBe(200);
    expect(simulation).toMatchObject({ provenance: "simulated_complete_300mm", waferCount: 3 });

    const overviewResponse = await fetch(`${baseUrl}/api/v1/releases/approved/analysis/overview?releaseKey=${simulationRelease}`);
    const overview = (await overviewResponse.json()) as { yieldByWafer: Array<{ waferId: string; waferKey: number }>; summary: { waferCount: number } };
    const wafer = overview.yieldByWafer.find((entry) => entry.waferId === "SIM300MM-01");
    expect(overviewResponse.status).toBe(200);
    expect(overview.summary.waferCount).toBe(3);
    expect(wafer).toBeDefined();

    const mapResponse = await fetch(`${baseUrl}/api/v1/releases/approved/analysis/wafer-map/SIM300MM-01?releaseKey=${simulationRelease}&waferKey=${wafer?.waferKey}`);
    const map = (await mapResponse.json()) as { mapAvailable: boolean; dies: unknown[]; geometry: { grossDie: number; isPartial: boolean; diePitchMm: number; diePitchSource: string; axisSource: string; edgeRule: string; grid: { columns: number; rows: number; grossCellTarget: number }; axis: { xMin: number; xMax: number; yMin: number; yMax: number } } };
    expect(mapResponse.status).toBe(200);
    expect(map.mapAvailable).toBe(true);
    expect(map.geometry).toMatchObject({ grossDie: 3096, isPartial: false, diePitchMm: 4.6875, diePitchSource: "VEDA_TBL_CP_GROSSDIE.source_payload", axisSource: "VEDA_TBL_CP_INIT_AXIS", edgeRule: "circle-radius-31.5", grid: { columns: 64, rows: 64, grossCellTarget: 3096 }, axis: { xMin: 0, xMax: 63, yMin: 0, yMax: 63 } });
    expect(map.dies).toHaveLength(3096);
  }, 20_000);
});
