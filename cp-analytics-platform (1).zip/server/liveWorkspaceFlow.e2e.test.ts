import { chromium } from "@playwright/test";
import { readFile } from "node:fs/promises";
import { expect, describe, it } from "vitest";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";

describe("live CP analysis workspace", () => {
  it("loads approved analysis data and drives yield, bin, wafer-map, and comparison workflows", async () => {
    const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
    try {
      const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
      const obsoleteRuntimeRequests: string[] = [];
      const duplicateReactKeyWarnings: string[] = [];
      page.on("request", (request) => {
        const url = request.url();
        if (url.includes("/api/trpc/") || url.includes("/__manus__/logs")) {
          obsoleteRuntimeRequests.push(url);
        }
      });
      page.on("console", (message) => {
        const text = message.text();
        if (text.includes("same key") || text.includes("Keys should be unique")) {
          duplicateReactKeyWarnings.push(text);
        }
      });
      await page.goto(`${baseUrl}/query`, { waitUntil: "domcontentloaded" });
      await page.getByRole("heading", { name: "Define analysis dataset" }).waitFor();
      await page.getByLabel("Query source release").selectOption("CPREAL-EE48DB6DF97E-R5");
      const part6Select = page.getByLabel("Query filter PART6");
      await part6Select.locator('option[value="TMUW83"]').waitFor({ timeout: 20_000 });
      await part6Select.selectOption("TMUW83");
      await page.getByText("19 wafers match", { exact: true }).waitFor({ timeout: 20_000 });
      await page.getByRole("button", { name: "Execute query" }).click();
      await page.getByText(/Showing 19 of 19 matching wafer-level records/).waitFor({ timeout: 20_000 });
      const downloadPromise = page.waitForEvent("download");
      await page.getByRole("button", { name: "Export query CSV" }).click();
      const download = await downloadPromise;
      expect(download.suggestedFilename()).toContain("cp_query_CPREAL-EE48DB6DF97E-R5");
      const downloadPath = await download.path();
      expect(downloadPath).not.toBeNull();
      const csvText = await readFile(downloadPath!, "utf8");
      expect(csvText).toContain("# VEDA_CP_APPROVED_QUERY_EXPORT");
      expect(csvText).toContain("# release_key,CPREAL-EE48DB6DF97E-R5");
      expect(csvText).toContain("# scope,approved_release_only");
      expect(csvText).toContain("# export_row_limit,10000");
      await page.getByRole("button", { name: "Yield & bin summary" }).click();
      await page.getByRole("heading", { name: "CP analysis console" }).waitFor();
      await page.getByText("APPLIED DATA QUERY", { exact: true }).waitFor();
      expect(await page.getByText("All dashboards use the last executed Data Query", { exact: true }).count()).toBe(0);
      expect(await page.getByText("Guided workflow", { exact: true }).count()).toBe(0);
      expect(await page.getByText(/Review the release signal/).count()).toBe(0);
      await page.getByText(/1 criteria · 3 lots \/ 19 wafers/).waitFor();
      await page.getByRole("button", { name: "Yield & bin summary" }).click();
      await page.getByText("Ranked wafer yield", { exact: false }).waitFor();
      await page.getByText("Release bin distribution", { exact: true }).waitFor();
      await page.getByRole("button", { name: /Open wafer map/ }).click();
      await page.getByText("300 MM DIE GRID", { exact: true }).waitFor();
      await page.getByText("Die-level map not available for this export", { exact: true }).waitFor();
      await page.getByRole("button", { name: "Multi-wafer compare" }).click();
      await page.getByText("WAFER COMPARISON", { exact: true }).waitFor();
      expect(await page.getByText("Comparison is restricted to the active approved data release.").count()).toBe(1);

      await page.reload({ waitUntil: "domcontentloaded" });
      await page.getByRole("heading", { name: "CP analysis console" }).waitFor();
      await page.getByText(/1 criteria · 3 lots \/ 19 wafers/).waitFor({ timeout: 20_000 });
      await page.getByRole("button", { name: "Spatial wafer maps" }).click();
      await page.getByText("1 / 19 wafers with RAW die grids", { exact: true }).waitFor({ timeout: 20_000 });
      await page.getByRole("button", { name: /Inspect map-ready wafer M123456.13/ }).click();
      await page.getByText("M123456.13 · Spatial inspection", { exact: true }).waitFor({ timeout: 20_000 });
      await page.locator("svg.wafer-svg .wafer-die").first().waitFor({ timeout: 20_000 });
      expect(await page.locator("svg.wafer-svg .wafer-die").count()).toBeGreaterThan(100);

      const readiness = await page.request.get(`${baseUrl}/api/v1/health/ready`);
      const rejected = await page.request.get(`${baseUrl}/api/v1/releases/approved/wafers?releaseKey=CPDEV-20260823-R0`);
      const favicon = await page.request.get(`${baseUrl}/favicon.svg`);
      expect(readiness.status()).toBe(200);
      expect(rejected.status()).toBe(404);
      expect(favicon.status()).toBe(200);
      expect(obsoleteRuntimeRequests).toEqual([]);
      expect(duplicateReactKeyWarnings).toEqual([]);

      const mobilePage = await browser.newPage({ viewport: { width: 390, height: 844 } });
      await mobilePage.goto(`${baseUrl}/query`, { waitUntil: "domcontentloaded" });
      await mobilePage.getByRole("heading", { name: "Define analysis dataset" }).waitFor();
      expect(await mobilePage.getByText("Approved-release query boundary", { exact: true }).count()).toBe(1);
      expect(await mobilePage.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
    } finally {
      await browser.close();
    }
  }, 90_000);
});
