import { describe, expect, it } from "vitest";
import { chromium } from "@playwright/test";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";

describe("approved multi-parameter matrix workflows", () => {
  it("renders an N × N value matrix and linked R² correlation scatter from one executed fixture cohort", async () => {
    const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
    try {
      const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
      await page.goto(`${baseUrl}/query`, { waitUntil: "domcontentloaded" });
      await page.getByRole("heading", { name: "Define analysis dataset" }).waitFor();
      await page.getByLabel("Query source release").selectOption("CPDEV-20260823-R1");
      await page.getByRole("button", { name: "Execute query" }).click();
      await page.getByText(/Showing 9 of 9 matching wafer-level records/).waitFor({ timeout: 20_000 });

      await page.getByRole("button", { name: "Parameter N×N matrix" }).click();
      await page.getByRole("heading", { name: "CP analysis console" }).waitFor();
      const fixtureEngineering = page.waitForResponse((response) => response.url().includes("/analysis/engineering?releaseKey=CPDEV-20260823-R1") && response.status() === 200);
      await fixtureEngineering;
      const matrixResponse = page.waitForResponse((response) => response.url().includes("/analysis/parameter-matrix?") && response.status() === 200);
      await page.getByRole("button", { name: "Parameter N×N matrix" }).click();
      await matrixResponse;
      await page.getByText("Parameter values across approved lots or wafers", { exact: true }).waitFor({ timeout: 20_000 });
      expect(await page.getByLabel("Matrix parameter selection").locator('option[value="CP_PARAM_001"]').count()).toBe(1);
      await page.getByText("MEAN VALUE MATRIX", { exact: true }).waitFor();
      expect(await page.getByText(/CPDEV100 · CPDEV100-01/).count()).toBeGreaterThan(0);

      const valueRefresh = page.waitForResponse((response) => response.url().includes("/analysis/parameter-matrix?") && response.status() === 200);
      await page.getByLabel("Matrix parameter selection").selectOption(["CP_PARAM_001", "CP_PARAM_002", "CP_PARAM_003", "CP_PARAM_004", "CP_PARAM_005", "CP_PARAM_006"]);
      await valueRefresh;
      await page.getByRole("img", { name: "Approved multi-parameter value trend" }).waitFor({ timeout: 20_000 });
      expect(await page.locator(".parameter-trend-svg circle").count()).toBeGreaterThan(24);

      const correlationResponse = page.waitForResponse((response) => response.url().includes("/analysis/parameter-matrix?") && response.status() === 200);
      await page.getByRole("button", { name: "Correlation N×N matrix" }).click();
      await correlationResponse;
      await page.getByText("R² / PEARSON R MATRIX", { exact: true }).waitFor({ timeout: 20_000 });
      await page.getByRole("img", { name: "Approved parameter scatterplot matrix" }).waitFor({ timeout: 20_000 });
      expect(await page.locator(".scatterplot-matrix circle").count()).toBeGreaterThan(100);
      await page.getByText(/R² 0\.986/).first().click();
      await page.getByText("CP_PARAM_001 vs CP_PARAM_002", { exact: true }).waitFor();
      expect(await page.locator(".correlation-readout").getByText(/Pearson r/).count()).toBeGreaterThan(0);
    } finally {
      await browser.close();
    }
  }, 60_000);
});
