import { chromium } from "@playwright/test";
import { describe, expect, it } from "vitest";

const baseUrl = process.env.CP_TEST_BASE_URL ?? "http://127.0.0.1:3000";

describe("complete 300 mm wafer simulation", () => {
  it("selects the provenance-labelled simulation release and renders a complete interactive die grid", async () => {
    const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
    try {
      const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
      await page.goto(`${baseUrl}/query`, { waitUntil: "domcontentloaded" });
      await page.getByRole("heading", { name: "Define analysis dataset" }).waitFor();
      const simulationFilters = page.waitForResponse((response) => response.url().includes("analysis/filters?releaseKey=CPSIM300-20260823-R1") && response.status() === 200);
      await page.getByLabel("Query source release").selectOption("CPSIM300-20260823-R1");
      expect(await page.getByLabel("Query source release").inputValue()).toBe("CPSIM300-20260823-R1");
      await simulationFilters;
      await page.getByRole("button", { name: "Execute query" }).click();
      await page.getByText(/Showing 3 of 3 matching wafer-level records/).waitFor({ timeout: 20_000 });
      await page.getByRole("button", { name: "Spatial wafer maps" }).click();
      await page.getByRole("heading", { name: "CP analysis console" }).waitFor();
      await page.getByText(/SIM300MM-01 · (Edge ring|Spatial inspection)/).waitFor({ timeout: 20_000 });

      const dies = page.locator("svg.wafer-svg .wafer-die");
      await dies.first().waitFor({ timeout: 20_000 });
      expect(await dies.count()).toBe(3096);
      await page.getByText(/64 × 64 axis grid/).waitFor({ timeout: 20_000 });
      expect(await page.locator("svg.wafer-svg .wafer-gross-die").count()).toBe(3096);
      await dies.first().click();
      await page.getByRole("heading", { name: /X \d+ · Y \d+/ }).waitFor({ timeout: 20_000 });
    } finally {
      await browser.close();
    }
  }, 60_000);
});
