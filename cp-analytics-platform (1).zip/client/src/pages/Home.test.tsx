import React from "react";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("@/components/DashboardLayout", () => ({
  default: ({ children }: { children: React.ReactNode }) => <div data-testid="workspace-shell">{children}</div>,
}));

import Home from "./Home";

const livePayload = {
  release: { key: "CPDEV-20260823-R1", status: "analytics_ready", approvedAt: "2026-08-23T00:00:00", snapshotHash: "a".repeat(64) },
  summary: { waferCount: 2, testedDie: 200, goodDie: 175, meanYield: 0.875, medianYield: 0.875, minYield: 0.8, belowTargetCount: 1 },
  yieldByWafer: [
    { waferKey: 101, lotId: "CPDEV100", waferNo: 1, waferId: "CPDEV100-01", scenario: "baseline_good", testedDie: 100, goodDie: 95, yield: 0.95 },
    { waferKey: 202, lotId: "CPDEV204", waferNo: 1, waferId: "CPDEV204-01", scenario: "parameter_shift", testedDie: 100, goodDie: 80, yield: 0.8 },
  ],
  binDistribution: [{ softBin: 1, hardBin: 1, dieCount: 175, share: 0.875 }, { softBin: 40, hardBin: 6, dieCount: 25, share: 0.125 }],
  lotSummaries: [],
};

const mapPayload = {
  releaseKey: "CPDEV-20260823-R1",
  wafer: { waferId: "CPDEV100-01", lotId: "CPDEV100" },
  mapAvailable: true,
  availabilityReason: null,
  geometry: { diameterMm: 300, grossDie: 88, testedDie: 1, source: "VEDA_TBL_CP_GROSSDIE", coordinateSource: "canonical_die", bounds: { xMin: 0, xMax: 0, yMin: 0, yMax: 0 }, axis: { xMin: 0, xMax: 9, yMin: 0, yMax: 9 }, grid: { columns: 10, rows: 10, grossCellTarget: 88 }, diePitchMm: 30, edgeRule: "axis-bounded circular gross-die inclusion", coverage: 1 / 88, isPartial: true },
  dies: [{ x: 0, y: 0, softBin: 1, hardBin: 1, pass: true, measuredValue: 5, failDirection: "pass" }],
};
const mapReadyPayload = {
  coverage: { mapReadyWaferCount: 1, scopedWaferCount: 2, mapReadyShare: 0.5 },
  mapReadyWafers: [{ waferKey: 101, waferId: "CPDEV100-01", lotId: "CPDEV100", yield: 0.95, rawRowCount: 3, observedDieCount: 100, grossDie: 100, testedDie: 100 }],
};
const lotMosaicPayload = { coverage: { mapReadyWaferCount: 1, scopedWaferCount: 2, mapReadyShare: 0.5, totalMosaicCandidates: 1, returnedWaferCount: 1 }, pagination: { offset: 0, limit: 12, hasMore: false }, lots: [{ lotId: "CPDEV100", mapReadyWaferCount: 1, avgYield: 0.95, minYield: 0.95 }], wafers: [{ waferKey: 101, lotId: "CPDEV100", waferId: "CPDEV100-01", waferNo: 1, yield: 0.95, testedDie: 100, goodDie: 95, lossDie: 5, scenario: "baseline_good", observedDieCount: 1, previewSampled: false, dominantFailBin: { softBin: 40, hardBin: 6, dieCount: 5 }, geometry: { bounds: { xMin: 0, xMax: 0, yMin: 0, yMax: 0 } }, previewDies: [{ x: 0, y: 0, softBin: 1, hardBin: 1, pass: true }] }] };

const filterPayload = {
  release: { key: "CPDEV-20260823-R1", status: "analytics_ready", snapshotHash: "a".repeat(64) },
  fields: { part: [], part6: [{ value: "TMUW83", lotCount: 3 }], lotId: [], testProgram: [], binDefName: [], testEqpid: [], cpProbecard: [], testVendor: [], month: [], week: [] },
  semantics: { withinField: "OR", acrossFields: "AND", scope: "approved_release_only" },
};
const previewPayload = { release: { key: "CPDEV-20260823-R1", status: "analytics_ready" }, pendingFilters: {}, lotCount: 2, waferCount: 2 };
const releaseCatalogPayload = { releases: [{ key: "CPDEV-20260823-R1", status: "analytics_ready", waferCount: 2, partNumber: "VEDA-CP-DEV", provenance: "imported_or_fixture", label: "Imported / fixture CP analysis release" }], scope: "approved_release_only" };
const engineeringPayload = { release: { key: "CPDEV-20260823-R1", status: "analytics_ready", snapshotHash: "a".repeat(64) }, yieldDimensions: { byTester: [], byProbeCard: [], byPart: [], byLot: [] }, trend: [], topFailBins: [], parameters: [], retest: { sessionCount: 2, retestSessionCount: 0, maxPassIndex: 1, available: false }, spatialPatternEvidence: [], availability: { parameterStatistics: false, specificationLimits: false, processDefectCorrelation: false, processDefectReason: "No process data", retestAnalysis: false } };
const detailedEngineeringPayload = { ...engineeringPayload, yieldDimensions: { byTester: [{ value: "ATE-01", waferCount: 2, goodDie: 175, testedDie: 200, yield: 0.875 }], byProbeCard: [{ value: "PC-10", waferCount: 2, goodDie: 175, testedDie: 200, yield: 0.875 }], byPart: [{ value: "TMUW83A", waferCount: 2, goodDie: 175, testedDie: 200, yield: 0.875 }], byLot: [{ value: "CPDEV100", waferCount: 1, goodDie: 95, testedDie: 100, yield: 0.95 }] }, trend: [{ period: "2026-08-22", waferCount: 1, yield: 0.95, representativeWaferKey: 101 }, { period: "2026-08-23", waferCount: 1, yield: 0.8, representativeWaferKey: 202 }] };
const supportedAnalyticsPayload = { ...detailedEngineeringPayload, parameters: [{ code: "CP_PARAM_001", name: "CP Parameter 001", unit: "arb", sampleCount: 200, mean: 5.1, stddev: 0.5, min: 4.2, max: 10.4, lowerLimit: 0, upperLimit: 10, outOfSpecCount: 4 }, { code: "CP_PARAM_002", name: "CP Parameter 002", unit: "arb", sampleCount: 200, mean: 4.6, stddev: 0.3, min: 4.2, max: 10.15, lowerLimit: 0, upperLimit: 10, outOfSpecCount: 4 }], parameterDistributions: { CP_PARAM_001: [{ lower: 4.2, upper: 4.8, count: 30 }, { lower: 4.9, upper: 5.3, count: 120 }, { lower: 5.4, upper: 10.4, count: 50 }] }, parameterWaferComparison: { CP_PARAM_001: [{ waferKey: 101, lotId: "CPDEV100", waferId: "CPDEV100-01", sampleCount: 100, mean: 5, stddev: 0.2, outOfSpecCount: 0 }, { waferKey: 202, lotId: "CPDEV204", waferId: "CPDEV204-01", sampleCount: 100, mean: 5.2, stddev: 0.6, outOfSpecCount: 4 }] }, parameterDescriptive: { CP_PARAM_001: { count: 200, mean: 5.1, median: 5, stddev: 0.5, sigma3: 1.5, sigma6: 3, min: 4.2, max: 10.4, q1: 4.9, q3: 5.3, iqr: 0.4, outlierCount: 4, skewness: 1.2, shape: "right_skewed" } }, parameterBoxPlots: { CP_PARAM_001: { wafer: [{ group: "CPDEV100 · CPDEV100-01", count: 100, mean: 5, median: 5, stddev: 0.2, sigma3: 0.6, sigma6: 1.2, min: 4.8, max: 5.2, q1: 4.9, q3: 5.1, iqr: 0.2, outlierCount: 0, skewness: 0, shape: "approximately_symmetric" }] } }, parameterScatter: [{ xCode: "CP_PARAM_001", yCode: "CP_PARAM_002", sampleCount: 200, correlation: 0.86, points: [{ x: 5, y: 4.5, waferKey: 101, lotId: "CPDEV100", waferId: "CPDEV100-01", xCoord: 0, yCoord: 0 }] }], spatialPatterns: [{ waferKey: 101, lotId: "CPDEV100", waferId: "CPDEV100-01", pattern: "ring_like_edge_loss", confidence: 0.87, dieCount: 100, failDie: 20, source: "canonical_die_coordinates" }], availability: { ...engineeringPayload.availability, parameterStatistics: true, specificationLimits: true } };
const parameterMatrixPayload = { release: { key: "CPDEV-20260823-R1", status: "analytics_ready", snapshotHash: "a".repeat(64) }, selection: { filters: {}, scope: "approved_release_only", parameters: ["CP_PARAM_001", "CP_PARAM_002"], dimension: "wafer" }, valueMatrix: { dimension: "wafer", rowLimit: 40, rows: [{ key: "101", label: "CPDEV100 · CPDEV100-01", sortTime: "2026-08-22", values: { CP_PARAM_001: { sampleCount: 100, mean: 5, stddev: 0.2, min: 4.8, max: 5.2 }, CP_PARAM_002: { sampleCount: 100, mean: 4.5, stddev: 0.2, min: 4.2, max: 4.8 } } }, { key: "202", label: "CPDEV204 · CPDEV204-01", sortTime: "2026-08-23", values: { CP_PARAM_001: { sampleCount: 100, mean: 5.2, stddev: 0.6, min: 4.2, max: 10.4 }, CP_PARAM_002: { sampleCount: 100, mean: 4.7, stddev: 0.3, min: 4.3, max: 10.15 } } }], coverage: { availableCells: 4, expectedCells: 4 } }, correlationMatrix: { minimumSampleSize: 3, detailedMeasurementLimit: 40000, measurementCount: 400, cells: [{ xCode: "CP_PARAM_001", yCode: "CP_PARAM_001", sampleCount: 200, correlation: 1, rSquared: 1, strength: "strong", available: true, sameParameter: true }, { xCode: "CP_PARAM_001", yCode: "CP_PARAM_002", sampleCount: 200, correlation: 0.86, rSquared: 0.7396, strength: "strong", available: true, sameParameter: false }, { xCode: "CP_PARAM_002", yCode: "CP_PARAM_002", sampleCount: 200, correlation: 1, rSquared: 1, strength: "strong", available: true, sameParameter: true }], scatterSeries: [{ xCode: "CP_PARAM_001", yCode: "CP_PARAM_002", sampleCount: 200, correlation: 0.86, rSquared: 0.7396, strength: "strong", points: [{ x: 5, y: 4.5, waferKey: 101, lotId: "CPDEV100", waferId: "CPDEV100-01", xCoord: 0, yCoord: 0 }] }] }, availabilityReason: null };

const emptyPayload = { ...livePayload, summary: { ...livePayload.summary, waferCount: 0, testedDie: 0, goodDie: 0, meanYield: 0, medianYield: 0, minYield: 0, belowTargetCount: 0 }, yieldByWafer: [], binDistribution: [] };

afterEach(() => {
  cleanup();
  window.localStorage.clear();
  vi.restoreAllMocks();
});

describe("CP analysis console", () => {
  it("renders approved yield analysis, changes active wafer, and opens map evidence", async () => {
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/engineering") ? engineeringPayload : url.includes("analysis/lot-mosaic") ? lotMosaicPayload : url.includes("wafer-map") ? mapPayload : url.includes("analysis/map-ready") ? mapReadyPayload : url.includes("analysis/filters") ? filterPayload : url.includes("analysis/preview") ? previewPayload : livePayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<Home />);

    await screen.findByRole("heading", { name: "CP analysis console" });
    expect((await screen.findAllByText("87.5%")).length).toBeGreaterThan(0);
    expect(screen.getByText("Observed release yield by measured date")).toBeTruthy();

    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "yield" }));
    await screen.findByText("Ranked wafer yield", { exact: false });
    fireEvent.click(screen.getByRole("button", { name: /Parameter shift.*CPDEV204-01/ }));
    await waitFor(() => expect(screen.getAllByText("CPDEV204-01").length).toBeGreaterThan(0));

    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "map" }));
    await screen.findByText("300 MM DIE GRID", { exact: true });
    expect(await screen.findByText("1 / 2 wafers with RAW die grids")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /Inspect map-ready wafer CPDEV100-01/ }));
    await waitFor(() => expect(screen.getByRole("button", { name: /Inspect map-ready wafer CPDEV100-01/ }).hasAttribute("disabled")).toBe(true));
    expect(screen.getByText(/click an observed die to inspect/i)).toBeTruthy();
    expect(screen.getByText(/10 × 10 axis grid/)).toBeTruthy();
    expect(screen.getByTestId("gross-die-0-0")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Zoom in" }));
    expect(screen.getByText("115%")).toBeTruthy();
    fireEvent.click(screen.getByTestId("die-0-0"));
    expect(screen.getByRole("heading", { name: "X 0 · Y 0" })).toBeTruthy();
  });

  it("renders linked product engineering signals and drills a ranked loss contributor into spatial inspection", async () => {
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/engineering") ? detailedEngineeringPayload : url.includes("wafer-map") ? mapPayload : url.includes("analysis/map-ready") ? mapReadyPayload : livePayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<Home />);

    expect(await screen.findByText("Applied-cohort engineering signal")).toBeTruthy();
    expect(screen.getByText("Observed release yield by measured date")).toBeTruthy();
    expect(screen.getByText("Wafers with the largest observed die loss")).toBeTruthy();
    expect(await screen.findByText("Approved map-ready wafer previews")).toBeTruthy();
    fireEvent.click(screen.getAllByRole("button", { name: /CPDEV204-01/ })[0]);
    expect(await screen.findByText("300 MM DIE GRID", { exact: true })).toBeTruthy();
  });

  it("drills an approved representative wafer from a product trend point into spatial inspection", async () => {
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/engineering") ? detailedEngineeringPayload : url.includes("wafer-map") ? mapPayload : url.includes("analysis/map-ready") ? mapReadyPayload : livePayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<Home />);

    await screen.findByText("Applied-cohort engineering signal");
    fireEvent.click(await screen.findByRole("button", { name: /2026-08-23.*inspect representative/ }));
    expect(await screen.findByText("300 MM DIE GRID", { exact: true })).toBeTruthy();
    expect((screen.getByLabelText("Inspect wafer") as HTMLSelectElement).value).toBe("202");
  });

  it("renders the active-cohort lot table and bounded multi-wafer bin-map mosaic", async () => {
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/engineering") ? detailedEngineeringPayload : url.includes("analysis/lot-mosaic") ? lotMosaicPayload : url.includes("wafer-map") ? mapPayload : url.includes("analysis/map-ready") ? mapReadyPayload : livePayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<Home />);
    await screen.findByText("CP analysis console");
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "compare" }));
    expect(await screen.findByText("Approved bin-map mosaic and wafer loss review")).toBeTruthy();
    expect(screen.getAllByText("CPDEV100-01", { exact: true }).length).toBeGreaterThan(1);
    expect(await screen.findByRole("button", { name: "Inspect mosaic wafer CPDEV100-01" })).toBeTruthy();
  });

  it("presents a verified empty state instead of empty analysis panels", async () => {
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/engineering") ? engineeringPayload : url.includes("analysis/filters") ? filterPayload : url.includes("analysis/preview") ? { ...previewPayload, lotCount: 0, waferCount: 0 } : emptyPayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<Home />);

    await screen.findByText("No approved wafer evidence is available");
    expect(screen.getByText(/Release CPDEV-20260823-R1 passed approval controls/)).toBeTruthy();
  });

  it("keeps compact applied-query controls without rendering repeated cohort or provenance banners", async () => {
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/engineering") ? engineeringPayload : livePayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<Home />);

    expect(await screen.findByText("APPLIED DATA QUERY")).toBeTruthy();
    expect(screen.queryByText("Define the approved CP population")).toBeNull();
    expect(screen.getByRole("button", { name: "Edit data query" })).toBeTruthy();
    expect(screen.queryByText("All dashboards use the last executed Data Query")).toBeNull();
    expect(screen.queryByLabelText("Simulated data provenance")).toBeNull();
    expect(screen.queryByText("Guided workflow")).toBeNull();
    expect(screen.queryByText(/Review the release signal/)).toBeNull();
  });

  it("uses stable wafer keys when the same wafer identifier appears in different lots", async () => {
    const duplicateIdentifierPayload = {
      ...livePayload,
      yieldByWafer: [
        { waferKey: 3001, lotId: "LOT-ALPHA", waferNo: 1, waferId: "M123456.01", scenario: "baseline_good", testedDie: 100, goodDie: 95, yield: 0.95 },
        { waferKey: 3002, lotId: "LOT-BETA", waferNo: 1, waferId: "M123456.01", scenario: "parameter_shift", testedDie: 100, goodDie: 80, yield: 0.8 },
      ],
    };
    const fetchMock = vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/engineering") ? engineeringPayload : url.includes("wafer-map") ? mapPayload : url.includes("analysis/filters") ? filterPayload : url.includes("analysis/preview") ? previewPayload : duplicateIdentifierPayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    });
    const consoleError = vi.spyOn(console, "error").mockImplementation(() => undefined);
    vi.stubGlobal("fetch", fetchMock);
    render(<Home />);

    const inspector = await screen.findByLabelText("Inspect wafer");
    expect(screen.getByRole("option", { name: /LOT-ALPHA · M123456.01/ })).toBeTruthy();
    expect(screen.getByRole("option", { name: /LOT-BETA · M123456.01/ })).toBeTruthy();
    fireEvent.change(inspector, { target: { value: "3002" } });
    await waitFor(() => expect(fetchMock.mock.calls.some(([input]) => String(input).includes("wafer-map/M123456.01") && String(input).includes("waferKey=3002"))).toBe(true));
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "compare" }));
    const reference = await screen.findByLabelText("Reference wafer") as HTMLSelectElement;
    expect(reference.value).toBe("3001");
    expect(screen.getByRole("option", { name: /LOT-ALPHA · M123456.01 · Baseline/ })).toBeTruthy();
    expect(screen.getByRole("option", { name: /LOT-BETA · M123456.01 · Parameter shift/ })).toBeTruthy();
    expect(consoleError.mock.calls.some(([message]) => String(message).includes("same key") || String(message).includes("Keys should be unique"))).toBe(false);
  });

  it("renders every engineering module requested from sidebar navigation with honest data availability", async () => {
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/engineering") ? detailedEngineeringPayload : url.includes("wafer-map") ? mapPayload : url.includes("analysis/map-ready") ? mapReadyPayload : url.includes("analysis/filters") ? filterPayload : url.includes("analysis/preview") ? previewPayload : livePayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<Home />);
    await screen.findByRole("heading", { name: "CP analysis console" });

    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "yield" }));
    expect(await screen.findByText("Yield by product")).toBeTruthy();
    expect((await screen.findAllByText("TMUW83A")).length).toBeGreaterThan(0);
    expect((await screen.findAllByText("CPDEV100")).length).toBeGreaterThan(0);
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "rows" }));
    expect(await screen.findByText("Screen approved wafer records")).toBeTruthy();
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "parameters" }));
    expect(await screen.findByText("Parameter distributions are not available for this cohort")).toBeTruthy();
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "trends" }));
    expect(await screen.findByText("Weighted yield by measured date")).toBeTruthy();
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "equipment" }));
    expect(await screen.findByText("Yield by tester")).toBeTruthy();
    expect(screen.getByText("ATE-01")).toBeTruthy();
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "retest" }));
    expect(await screen.findByText("First-pass versus repeat-test evidence")).toBeTruthy();
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "process" }));
    expect(await screen.findByText("Process and defect correlation is not linked")).toBeTruthy();
  });
  it("renders approved parameter capability details and coordinate-derived multi-wafer spatial controls when supported", async () => {
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/engineering") ? supportedAnalyticsPayload : url.includes("wafer-map") ? mapPayload : url.includes("analysis/map-ready") ? mapReadyPayload : url.includes("analysis/filters") ? filterPayload : url.includes("analysis/preview") ? previewPayload : livePayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<Home />);
    await screen.findByRole("heading", { name: "CP analysis console" });
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "parameters" }));
    expect(await screen.findByText("Approved distribution and limits")).toBeTruthy();
    expect(screen.getByText("Cp")).toBeTruthy();
    expect(screen.getByText("Cpk")).toBeTruthy();
    expect(screen.getByText("Median")).toBeTruthy();
    expect(screen.getByText("Distribution shift and outlier screen")).toBeTruthy();
    expect(screen.getByText("Correlation and multivariable screen")).toBeTruthy();
    expect(screen.getByText("Parameter mean and out-of-spec by wafer")).toBeTruthy();
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "map" }));
    expect(await screen.findByText("Coordinate-derived pattern queue")).toBeTruthy();
    fireEvent.change(screen.getByLabelText("Wafer map view"), { target: { value: "parameter" } });
    fireEvent.change(screen.getByLabelText("Wafer map parameter"), { target: { value: "CP_PARAM_002" } });
    await waitFor(() => expect(screen.getByText("CP_PARAM_002")).toBeTruthy());
    expect(screen.getByText("ring like edge loss")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Set reference" }));
    expect(await screen.findByText("WAFER COMPARISON")).toBeTruthy();
  });
  it("renders approved N × N parameter values, R² correlation cells, and linked aligned-die scatter evidence", async () => {
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/parameter-matrix") ? parameterMatrixPayload : url.includes("analysis/engineering") ? supportedAnalyticsPayload : url.includes("wafer-map") ? mapPayload : url.includes("analysis/map-ready") ? mapReadyPayload : url.includes("analysis/filters") ? filterPayload : url.includes("analysis/preview") ? previewPayload : livePayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<Home />);
    await screen.findByRole("heading", { name: "CP analysis console" });
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "parameterMatrix" }));
    expect(await screen.findByText("Parameter values across approved lots or wafers")).toBeTruthy();
    expect(screen.getByLabelText("Matrix parameter selection")).toBeTruthy();
    expect(await screen.findByText("CPDEV100 · CPDEV100-01")).toBeTruthy();
    expect(screen.getAllByText("CP_PARAM_001").length).toBeGreaterThan(0);
    expect(screen.getByText("Available cells")).toBeTruthy();
    expect(await screen.findByRole("img", { name: "Approved multi-parameter value trend" })).toBeTruthy();
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "correlationMatrix" }));
    expect(await screen.findByText("Aligned-die Pearson correlation and R²")).toBeTruthy();
    expect(screen.getByText("R² / PEARSON R MATRIX")).toBeTruthy();
    expect(await screen.findByRole("img", { name: "Approved parameter scatterplot matrix" })).toBeTruthy();
    const correlationCell = (await screen.findAllByText("R² 0.740"))[0].closest("button");
    expect(correlationCell).toBeTruthy();
    fireEvent.click(correlationCell!);
    expect(await screen.findByText("CP_PARAM_001 vs CP_PARAM_002")).toBeTruthy();
    expect(screen.getByText("Pearson r")).toBeTruthy();
  });
  it("falls back to verified bin colors when a selected parameter has no approved wafer measurements", async () => {
    const parameterlessMap = { ...mapPayload, parameter: { code: "CP_PARAM_001", name: "CP Parameter 001", unit: "arb", lowerLimit: 0, upperLimit: 10, measuredDieCount: 0 }, dies: [{ x: 0, y: 0, softBin: 40, hardBin: 6, pass: false, measuredValue: null, failDirection: null }] };
    vi.stubGlobal("fetch", vi.fn((input: string | URL | Request) => {
      const url = String(input);
      const payload = url.includes("/catalog") ? releaseCatalogPayload : url.includes("analysis/engineering") ? supportedAnalyticsPayload : url.includes("wafer-map") ? parameterlessMap : url.includes("analysis/map-ready") ? mapReadyPayload : url.includes("analysis/filters") ? filterPayload : url.includes("analysis/preview") ? previewPayload : livePayload;
      return Promise.resolve(new Response(JSON.stringify(payload), { status: 200 }));
    }));
    render(<Home />);
    await screen.findByRole("heading", { name: "CP analysis console" });
    window.dispatchEvent(new CustomEvent("cp-analysis-navigate", { detail: "map" }));
    await screen.findByText("300 MM DIE GRID", { exact: true });
    fireEvent.change(screen.getByLabelText("Wafer map view"), { target: { value: "parameter" } });
    fireEvent.change(screen.getByLabelText("Wafer map parameter"), { target: { value: "CP_PARAM_001" } });
    expect(await screen.findByText(/No approved measurement values are available/)).toBeTruthy();
    expect(screen.getByTestId("die-0-0").getAttribute("fill")).toBe("#f65671");
  });
});
