"""
Advanced Bossung Curve Analysis
================================
Additional analysis tools for lithography process window evaluation.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from bossung_plotter import BossungPlotter
from scipy.optimize import curve_fit


class AdvancedBossungAnalysis:
    """
    Advanced analysis tools for Bossung curves.
    """
    
    def __init__(self, plotter):
        """
        Initialize with a BossungPlotter instance.
        
        Parameters:
        -----------
        plotter : BossungPlotter
            Initialized BossungPlotter object
        """
        self.plotter = plotter
        self.data = plotter.data
    
    def fit_bossung_model(self, dose):
        """
        Fit a parabolic model to a single Bossung curve.
        
        Model: CD = a * defocus^2 + b * defocus + c
        
        Parameters:
        -----------
        dose : float
            Exposure dose to analyze
        
        Returns:
        --------
        dict : Fitted parameters and metrics
        """
        dose_data = self.data[self.data['Dose'] == dose].sort_values('Defocus')
        
        if len(dose_data) < 3:
            return None
        
        defocus = dose_data['Defocus'].values
        cd = dose_data['CD'].values
        
        # Parabolic model
        def parabola(x, a, b, c):
            return a * x**2 + b * x + c
        
        try:
            params, covariance = curve_fit(parabola, defocus, cd)
            a, b, c = params
            
            # Calculate R-squared
            cd_pred = parabola(defocus, a, b, c)
            ss_res = np.sum((cd - cd_pred)**2)
            ss_tot = np.sum((cd - np.mean(cd))**2)
            r_squared = 1 - (ss_res / ss_tot)
            
            # Find best focus (minimum of parabola)
            best_focus = -b / (2 * a) if a != 0 else 0
            cd_at_best_focus = parabola(best_focus, a, b, c)
            
            return {
                'dose': dose,
                'a': a,
                'b': b,
                'c': c,
                'r_squared': r_squared,
                'best_focus': best_focus,
                'cd_at_best_focus': cd_at_best_focus,
                'curvature': a  # Higher curvature = steeper Bossung curve
            }
        except:
            return None
    
    def analyze_all_doses(self):
        """
        Fit Bossung models to all dose conditions.
        
        Returns:
        --------
        pd.DataFrame : Fitted parameters for all doses
        """
        doses = sorted(self.data['Dose'].unique())
        results = []
        
        for dose in doses:
            fit_result = self.fit_bossung_model(dose)
            if fit_result:
                results.append(fit_result)
        
        return pd.DataFrame(results)
    
    def plot_dose_sensitivity(self, figsize=(12, 8)):
        """
        Plot CD sensitivity to dose at different defocus values.
        
        Parameters:
        -----------
        figsize : tuple
            Figure size
        """
        fig, ax = plt.subplots(figsize=figsize)
        
        # Select key defocus values
        defocus_values = sorted(self.data['Defocus'].unique())
        # Pick every 4th value for clarity
        selected_defocus = defocus_values[::4]
        
        colors = plt.cm.coolwarm(np.linspace(0, 1, len(selected_defocus)))
        
        for idx, defocus in enumerate(selected_defocus):
            defocus_data = self.data[self.data['Defocus'] == defocus].sort_values('Dose')
            ax.plot(defocus_data['Dose'], defocus_data['CD'],
                   marker='o', markersize=6, linewidth=2,
                   color=colors[idx], label=f'{defocus:.2f} μm',
                   alpha=0.8)
        
        if self.plotter.target_cd:
            ax.axhline(y=self.plotter.target_cd, color='red', 
                      linestyle='--', linewidth=2, label='Target CD')
        
        ax.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=13, fontweight='bold')
        ax.set_ylabel('Critical Dimension (nm)', fontsize=13, fontweight='bold')
        ax.set_title('Dose Sensitivity at Different Defocus Values', 
                    fontsize=15, fontweight='bold')
        ax.legend(title='Defocus', fontsize=9, ncol=2)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig, ax
    
    def plot_best_focus_vs_dose(self, figsize=(10, 6)):
        """
        Plot best focus position as a function of dose.
        
        Parameters:
        -----------
        figsize : tuple
            Figure size
        """
        fit_results = self.analyze_all_doses()
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)
        
        # Best focus vs dose
        ax1.plot(fit_results['dose'], fit_results['best_focus'],
                marker='o', markersize=8, linewidth=2, color='steelblue')
        ax1.axhline(y=0, color='red', linestyle='--', linewidth=1.5, alpha=0.5)
        ax1.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Best Focus (μm)', fontsize=12, fontweight='bold')
        ax1.set_title('Best Focus vs Dose', fontsize=13, fontweight='bold')
        ax1.grid(True, alpha=0.3)
        
        # CD at best focus vs dose
        ax2.plot(fit_results['dose'], fit_results['cd_at_best_focus'],
                marker='s', markersize=8, linewidth=2, color='darkgreen')
        if self.plotter.target_cd:
            ax2.axhline(y=self.plotter.target_cd, color='red', 
                       linestyle='--', linewidth=1.5, label='Target CD')
            ax2.legend()
        ax2.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=12, fontweight='bold')
        ax2.set_ylabel('CD at Best Focus (nm)', fontsize=12, fontweight='bold')
        ax2.set_title('CD at Best Focus vs Dose', fontsize=13, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig, fit_results
    
    def plot_curvature_analysis(self, figsize=(10, 6)):
        """
        Analyze and plot Bossung curve curvature vs dose.
        
        Higher curvature indicates steeper CD change with defocus.
        
        Parameters:
        -----------
        figsize : tuple
            Figure size
        """
        fit_results = self.analyze_all_doses()
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)
        
        # Curvature vs dose
        ax1.plot(fit_results['dose'], fit_results['curvature'],
                marker='D', markersize=8, linewidth=2, color='purple')
        ax1.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Curvature (a coefficient)', fontsize=12, fontweight='bold')
        ax1.set_title('Bossung Curve Curvature vs Dose', fontsize=13, fontweight='bold')
        ax1.grid(True, alpha=0.3)
        
        # R-squared (goodness of fit)
        ax2.plot(fit_results['dose'], fit_results['r_squared'],
                marker='o', markersize=8, linewidth=2, color='orange')
        ax2.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=12, fontweight='bold')
        ax2.set_ylabel('R² (Goodness of Fit)', fontsize=12, fontweight='bold')
        ax2.set_title('Model Fit Quality', fontsize=13, fontweight='bold')
        ax2.set_ylim([0.9, 1.0])
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig, fit_results
    
    def generate_process_capability_report(self):
        """
        Generate a comprehensive process capability report.
        
        Returns:
        --------
        dict : Process capability metrics
        """
        if not self.plotter.target_cd or not self.plotter.cd_tolerance:
            raise ValueError("Target CD and tolerance must be set")
        
        # Basic metrics
        pw_metrics = self.plotter.calculate_process_window_metrics()
        
        # Fit analysis
        fit_results = self.analyze_all_doses()
        
        # Find dose that gives target CD at best focus
        fit_results['cd_error'] = abs(fit_results['cd_at_best_focus'] - self.plotter.target_cd)
        optimal_row = fit_results.loc[fit_results['cd_error'].idxmin()]
        
        # CD statistics
        cd_mean = self.data['CD'].mean()
        cd_std = self.data['CD'].std()
        cd_range = self.data['CD'].max() - self.data['CD'].min()
        
        # Process capability indices (simplified)
        spec_range = 2 * self.plotter.cd_tolerance
        cp = spec_range / (6 * cd_std) if cd_std > 0 else 0
        
        report = {
            'Process Window': {
                'DOF (μm)': pw_metrics['DOF'],
                'EL (mJ/cm²)': pw_metrics['EL'],
                'Optimal Dose (mJ/cm²)': pw_metrics['optimal_dose'],
                'Optimal Focus (μm)': pw_metrics['optimal_focus'],
                'Yield (%)': pw_metrics['in_spec_points'] / pw_metrics['total_points'] * 100
            },
            'CD Statistics': {
                'Mean CD (nm)': cd_mean,
                'Std Dev (nm)': cd_std,
                'Range (nm)': cd_range,
                'Target CD (nm)': self.plotter.target_cd,
                'Tolerance (nm)': self.plotter.cd_tolerance
            },
            'Best Dose for Target CD': {
                'Dose (mJ/cm²)': optimal_row['dose'],
                'Best Focus (μm)': optimal_row['best_focus'],
                'CD at Best Focus (nm)': optimal_row['cd_at_best_focus'],
                'Error from Target (nm)': optimal_row['cd_error']
            },
            'Process Capability': {
                'Cp Index': cp,
                'Interpretation': 'Excellent' if cp > 1.67 else 'Good' if cp > 1.33 else 'Adequate' if cp > 1.0 else 'Poor'
            }
        }
        
        return report
    
    def print_report(self):
        """
        Print a formatted process capability report.
        """
        report = self.generate_process_capability_report()
        
        print("\n" + "="*70)
        print("LITHOGRAPHY PROCESS CAPABILITY REPORT")
        print("="*70)
        
        for section, metrics in report.items():
            print(f"\n{section}:")
            print("-" * 70)
            for key, value in metrics.items():
                if isinstance(value, float):
                    print(f"  {key:.<50} {value:.3f}")
                else:
                    print(f"  {key:.<50} {value}")
        
        print("\n" + "="*70)


def main():
    """
    Demonstration of advanced analysis capabilities.
    """
    print("\n" + "="*70)
    print("Advanced Bossung Curve Analysis")
    print("="*70)
    
    # Load data
    plotter = BossungPlotter(data_file='lithography_data.csv')
    plotter.set_target_specs(target_cd=45.0, tolerance_percent=10)
    
    # Create advanced analyzer
    analyzer = AdvancedBossungAnalysis(plotter)
    
    # Generate comprehensive report
    analyzer.print_report()
    
    # Generate advanced plots
    print("\nGenerating advanced analysis plots...")
    
    fig1, ax1 = analyzer.plot_dose_sensitivity()
    fig1.savefig('advanced_dose_sensitivity.png', dpi=300, bbox_inches='tight')
    print("  Saved: advanced_dose_sensitivity.png")
    
    fig2, fit_results = analyzer.plot_best_focus_vs_dose()
    fig2.savefig('advanced_best_focus.png', dpi=300, bbox_inches='tight')
    print("  Saved: advanced_best_focus.png")
    
    fig3, _ = analyzer.plot_curvature_analysis()
    fig3.savefig('advanced_curvature.png', dpi=300, bbox_inches='tight')
    print("  Saved: advanced_curvature.png")
    
    # Save fit results
    fit_results.to_csv('bossung_fit_parameters.csv', index=False)
    print("  Saved: bossung_fit_parameters.csv")
    
    print("\n" + "="*70)
    print("Advanced analysis complete!")
    print("="*70)
    
    plt.show()


if __name__ == "__main__":
    main()
