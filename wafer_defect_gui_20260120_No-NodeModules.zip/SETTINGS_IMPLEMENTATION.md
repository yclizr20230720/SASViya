# Settings & Preferences Implementation

## Overview
Comprehensive user settings and preferences system for the Wafer Defect Analysis GUI.

## Features Implemented

### 1. Appearance Settings
- **Theme Mode**: Light, Dark, Auto (System)
- **Color Scheme**: Blue (Default), Green, Purple, Orange
- **Density**: Compact, Comfortable, Spacious
- **Localization**: 
  - Language: English, Chinese, Japanese, Korean
  - Date Format: MM/DD/YYYY, DD/MM/YYYY, YYYY-MM-DD
  - Time Format: 12-hour (AM/PM), 24-hour
- **Display Options**:
  - Show tooltips
  - Enable animations
  - High contrast mode

### 2. Notifications Settings
- **Notification Channels**:
  - Email Notifications
  - In-App Notifications
  - Push Notifications
  - SMS Notifications
- **Notification Types**:
  - High defect rate alerts
  - Pattern detection alerts
  - Model update notifications
  - Daily summary reports
  - System maintenance alerts
- **Alert Thresholds**:
  - Defect Rate Threshold (%)
  - Confidence Score Threshold (%)

### 3. Data Display Settings
- **Table & Grid Settings**:
  - Default Page Size: 10, 25, 50, 100 rows
  - Show row numbers
  - Enable column sorting
  - Enable column filtering
- **Wafer Map Display**:
  - Default Color Scheme: Heatmap, Grayscale, Viridis, Plasma
  - Show die coordinates
  - Show defect markers
  - Enable zoom controls
- **Chart Settings**:
  - Show data labels
  - Enable chart animations
  - Show legend

### 4. Analysis Settings
- **Model Configuration**:
  - Default Model: CNN v1, CNN v2, ResNet-50, EfficientNet
  - Confidence Threshold: 0-100% (slider)
  - Enable automatic model updates
  - Use ensemble predictions
- **Pattern Detection**:
  - Enable pattern classification
  - Detect edge patterns
  - Detect center patterns
  - Detect scratch patterns
- **Processing Options**:
  - Batch Processing Size: 16, 32, 64, 128 wafers
  - Enable parallel processing
  - Use GPU acceleration

### 5. Security Settings
- **Authentication**:
  - Require two-factor authentication
  - Remember login for 30 days
  - Session Timeout: 15 min, 30 min, 1 hour, 4 hours
  - Change Password button
- **Data Privacy**:
  - Encrypt data at rest
  - Encrypt data in transit
  - Enable audit logging
  - Data Retention: 30-365 days (slider)
- **API Keys Management**:
  - List of API keys with creation date and last used
  - Refresh and Delete actions
  - Generate New API Key button

### 6. Integration Settings
- **Data Upload Settings**:
  - Maximum Upload Size: 10-500 MB (slider)
  - Allowed File Types: CSV, XLSX, JSON, XML, TXT (multi-select)
  - Auto-process uploaded files
  - Validate file format before upload
- **Auto-Refresh Settings**:
  - Dashboard Refresh Interval: 10s - 5m (slider)
  - Enable auto-refresh toggle
- **External Integrations**:
  - MES System Integration (Connected)
  - ERP System Integration (Connected)
  - Email Server (SMTP) (Configured)
  - Cloud Storage (S3) (Not configured)
  - Add New Integration button

## UI Components Used
- Material-UI Tabs for navigation
- Cards for section grouping
- Switches for boolean settings
- Sliders for numeric ranges
- Select dropdowns for options
- Text fields for input
- Lists for API keys and integrations
- Icons for visual clarity

## State Management
- Redux integration via `useAppDispatch` and `useAppSelector`
- Local state for settings that don't need global state
- Save success notification with auto-dismiss

## User Experience
- Tabbed interface for easy navigation
- Clear section headers and dividers
- Helpful descriptions and labels
- Visual feedback on save
- Consistent spacing and layout
- Responsive grid layout

## Files Modified
- `wafer-defect-gui/src/pages/Settings.tsx` - Complete rewrite with comprehensive settings

## Next Steps
1. Connect settings to backend API for persistence
2. Implement actual save functionality
3. Add validation for input fields
4. Add reset to defaults option
5. Add export/import settings functionality
