import { createSlice, type PayloadAction } from '@reduxjs/toolkit';

export interface PredictionResult {
  id: string;
  waferId: string;
  patternClass: string;
  patternConfidence: number;
  rootCauseClass: string;
  rootCauseConfidence: number;
  processingTimeMs: number;
  timestamp: string;
  explanation?: {
    heatmapUrl?: string;
    shapValues?: Record<string, number>;
    narrative?: string;
  };
}

interface PredictionState {
  predictions: Record<string, PredictionResult>;
  loading: boolean;
  error: string | null;
}

const initialState: PredictionState = {
  predictions: {},
  loading: false,
  error: null,
};

const predictionSlice = createSlice({
  name: 'prediction',
  initialState,
  reducers: {
    addPrediction: (state, action: PayloadAction<PredictionResult>) => {
      state.predictions[action.payload.waferId] = action.payload;
    },
    updatePrediction: (state, action: PayloadAction<{ waferId: string; updates: Partial<PredictionResult> }>) => {
      if (state.predictions[action.payload.waferId]) {
        state.predictions[action.payload.waferId] = {
          ...state.predictions[action.payload.waferId],
          ...action.payload.updates,
        };
      }
    },
    removePrediction: (state, action: PayloadAction<string>) => {
      delete state.predictions[action.payload];
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload;
    },
    clearPredictions: (state) => {
      state.predictions = {};
    },
  },
});

export const {
  addPrediction,
  updatePrediction,
  removePrediction,
  setLoading,
  setError,
  clearPredictions,
} = predictionSlice.actions;

export default predictionSlice.reducer;
