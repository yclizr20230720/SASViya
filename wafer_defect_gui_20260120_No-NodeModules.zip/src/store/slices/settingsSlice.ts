import { createSlice, type PayloadAction } from '@reduxjs/toolkit';

interface SettingsState {
  theme: 'light' | 'dark';
  language: string;
  notifications: {
    email: boolean;
    inApp: boolean;
    push: boolean;
  };
  dashboard: {
    layout: string;
    widgets: string[];
  };
}

const initialState: SettingsState = {
  theme: 'light',
  language: 'en',
  notifications: {
    email: true,
    inApp: true,
    push: false,
  },
  dashboard: {
    layout: 'default',
    widgets: ['kpi', 'recent-activity', 'system-health'],
  },
};

const settingsSlice = createSlice({
  name: 'settings',
  initialState,
  reducers: {
    setTheme: (state, action: PayloadAction<'light' | 'dark'>) => {
      state.theme = action.payload;
    },
    setLanguage: (state, action: PayloadAction<string>) => {
      state.language = action.payload;
    },
    updateNotifications: (state, action: PayloadAction<Partial<SettingsState['notifications']>>) => {
      state.notifications = { ...state.notifications, ...action.payload };
    },
    updateDashboard: (state, action: PayloadAction<Partial<SettingsState['dashboard']>>) => {
      state.dashboard = { ...state.dashboard, ...action.payload };
    },
    resetSettings: () => initialState,
  },
});

export const {
  setTheme,
  setLanguage,
  updateNotifications,
  updateDashboard,
  resetSettings,
} = settingsSlice.actions;

export default settingsSlice.reducer;
