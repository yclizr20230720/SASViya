// Knowledge-based recommendation engine for metrics

export interface Recommendation {
  priority: 'critical' | 'high' | 'medium' | 'low';
  category: 'immediate' | 'preventive' | 'optimization';
  title: string;
  description: string;
  actions: {
    step: number;
    action: string;
    owner: string;
    estimatedTime: string;
  }[];
  relatedMetrics: string[];
  expectedImpact: string;
  references?: string[];
}

interface MetricContext {
  metricId: string;
  currentValue: number;
  previousValue: number;
  target?: number;
  min?: number;
  max?: number;
}

// Knowledge base for metric-specific recommendations
const metricKnowledgeBase: Record<string, (context: MetricContext) => Recommendation[]> = {
  equipmentUptime: (context) => {
    const recommendations: Recommendation[] = [];
    
    if (context.currentValue < 90) {
      recommendations.push({
        priority: 'critical',
        category: 'immediate',
        title: 'Critical Equipment Uptime Issue Detected',
        description: `Equipment uptime has dropped to ${context.currentValue.toFixed(1)}%, significantly below the industry standard of 95%. This indicates frequent equipment failures or extended downtime periods that are severely impacting production capacity.`,
        actions: [
          {
            step: 1,
            action: 'Conduct immediate equipment health assessment across all critical tools',
            owner: 'Equipment Engineering Team',
            estimatedTime: '2-4 hours',
          },
          {
            step: 2,
            action: 'Review maintenance logs for the past 30 days to identify failure patterns',
            owner: 'Maintenance Team',
            estimatedTime: '1-2 hours',
          },
          {
            step: 3,
            action: 'Implement emergency preventive maintenance on high-risk equipment',
            owner: 'Maintenance Team',
            estimatedTime: '1-2 days',
          },
          {
            step: 4,
            action: 'Schedule vendor support for equipment showing recurring issues',
            owner: 'Equipment Engineering Team',
            estimatedTime: '3-5 days',
          },
          {
            step: 5,
            action: 'Establish daily uptime monitoring dashboard with real-time alerts',
            owner: 'Process Engineering Team',
            estimatedTime: '1 day',
          },
        ],
        relatedMetrics: ['meanTimeBetweenFailures', 'meanTimeToRepair', 'overallEquipmentEffectiveness'],
        expectedImpact: 'Restoring uptime to >95% could increase production capacity by 5-7% and reduce emergency maintenance costs by 30-40%.',
        references: [
          'SEMI E10 Standard - Equipment Reliability',
          'TPM (Total Productive Maintenance) Best Practices',
        ],
      });
    }
    
    return recommendations;
  },

  overallEquipmentEffectiveness: (context) => {
    const recommendations: Recommendation[] = [];
    
    if (context.currentValue < 65) {
      recommendations.push({
        priority: 'critical',
        category: 'immediate',
        title: 'OEE Below Acceptable Threshold - Comprehensive Improvement Required',
        description: `Overall Equipment Effectiveness at ${context.currentValue.toFixed(1)}% indicates significant losses in availability, performance, or quality. World-class manufacturing targets >85% OEE.`,
        actions: [
          {
            step: 1,
            action: 'Perform OEE breakdown analysis: Availability × Performance × Quality',
            owner: 'Industrial Engineering Team',
            estimatedTime: '4-6 hours',
          },
          {
            step: 2,
            action: 'Identify the primary loss category (availability, performance, or quality)',
            owner: 'Process Engineering Team',
            estimatedTime: '2-3 hours',
          },
          {
            step: 3,
            action: 'Conduct Pareto analysis on equipment downtime causes',
            owner: 'Manufacturing Team',
            estimatedTime: '1 day',
          },
          {
            step: 4,
            action: 'Implement quick wins: reduce changeover time, optimize cycle times',
            owner: 'Production Team',
            estimatedTime: '1-2 weeks',
          },
          {
            step: 5,
            action: 'Launch OEE improvement project with cross-functional team',
            owner: 'Operations Manager',
            estimatedTime: '3-6 months',
          },
        ],
        relatedMetrics: ['equipmentUptime', 'yieldRate', 'cycleTime'],
        expectedImpact: 'Improving OEE from 62% to 75% could increase effective capacity by 21% without capital investment.',
        references: [
          'SEMI E79 - OEE Metrics Standard',
          'Lean Manufacturing - OEE Improvement Methodology',
        ],
      });
    }
    
    return recommendations;
  },

  meanTimeBetweenFailures: (context) => {
    const recommendations: Recommendation[] = [];
    
    if (context.currentValue < 500) {
      recommendations.push({
        priority: 'high',
        category: 'preventive',
        title: 'Equipment Reliability Crisis - MTBF Below Critical Threshold',
        description: `MTBF of ${context.currentValue.toFixed(0)} hours indicates poor equipment reliability. Target is >1000 hours. Frequent failures are disrupting production and increasing costs.`,
        actions: [
          {
            step: 1,
            action: 'Analyze failure modes using FMEA (Failure Mode and Effects Analysis)',
            owner: 'Reliability Engineering Team',
            estimatedTime: '1 week',
          },
          {
            step: 2,
            action: 'Review and update preventive maintenance schedules based on failure data',
            owner: 'Maintenance Team',
            estimatedTime: '3-5 days',
          },
          {
            step: 3,
            action: 'Implement predictive maintenance using sensor data and AI analytics',
            owner: 'Equipment Engineering Team',
            estimatedTime: '2-3 months',
          },
          {
            step: 4,
            action: 'Replace or refurbish equipment with chronic reliability issues',
            owner: 'Capital Planning Team',
            estimatedTime: '3-6 months',
          },
          {
            step: 5,
            action: 'Train maintenance staff on advanced troubleshooting techniques',
            owner: 'Training Department',
            estimatedTime: '2 weeks',
          },
        ],
        relatedMetrics: ['equipmentUptime', 'meanTimeToRepair', 'maintenanceCost'],
        expectedImpact: 'Doubling MTBF from 450 to 900 hours could reduce unplanned downtime by 50% and maintenance costs by 35%.',
        references: [
          'SEMI E10 - Equipment Reliability, Availability, and Maintainability',
          'RCM (Reliability-Centered Maintenance) Guidelines',
        ],
      });
    }
    
    return recommendations;
  },

  yieldRate: (context) => {
    const recommendations: Recommendation[] = [];
    
    if (context.currentValue < 90) {
      recommendations.push({
        priority: 'critical',
        category: 'immediate',
        title: 'Yield Rate Below Target - Immediate Quality Investigation Required',
        description: `Yield at ${context.currentValue.toFixed(1)}% is below the 95% target, indicating significant quality issues affecting profitability.`,
        actions: [
          {
            step: 1,
            action: 'Initiate yield loss analysis using Pareto charts by defect type',
            owner: 'Quality Engineering Team',
            estimatedTime: '1-2 days',
          },
          {
            step: 2,
            action: 'Conduct root cause analysis on top 3 yield detractors',
            owner: 'Process Engineering Team',
            estimatedTime: '3-5 days',
          },
          {
            step: 3,
            action: 'Review and tighten process control limits on critical parameters',
            owner: 'Manufacturing Team',
            estimatedTime: '1 week',
          },
          {
            step: 4,
            action: 'Implement enhanced inline inspection and SPC monitoring',
            owner: 'Quality Team',
            estimatedTime: '2 weeks',
          },
          {
            step: 5,
            action: 'Launch yield improvement task force with daily reviews',
            owner: 'Operations Manager',
            estimatedTime: 'Ongoing',
          },
        ],
        relatedMetrics: ['defectDensity', 'defectRate', 'firstPassYield'],
        expectedImpact: 'Improving yield from 94% to 96% could increase revenue by $2-3M annually for a typical fab.',
        references: [
          'SEMI E133 - Yield Management Metrics',
          'Six Sigma DMAIC Methodology for Yield Improvement',
        ],
      });
    }
    
    return recommendations;
  },

  defectDensity: (context) => {
    const recommendations: Recommendation[] = [];
    
    if (context.currentValue > 0.5) {
      recommendations.push({
        priority: 'high',
        category: 'immediate',
        title: 'Elevated Defect Density - Process Control Investigation Needed',
        description: `Defect density of ${context.currentValue.toFixed(3)} defects/cm² exceeds the 0.5 target, suggesting process drift or contamination issues.`,
        actions: [
          {
            step: 1,
            action: 'Perform cleanroom particle count audit and contamination assessment',
            owner: 'Facilities Team',
            estimatedTime: '1 day',
          },
          {
            step: 2,
            action: 'Review chemical and gas purity levels for all critical processes',
            owner: 'Process Engineering Team',
            estimatedTime: '2-3 days',
          },
          {
            step: 3,
            action: 'Analyze defect spatial patterns using AI pattern recognition',
            owner: 'Data Science Team',
            estimatedTime: '1 week',
          },
          {
            step: 4,
            action: 'Implement enhanced wafer cleaning protocols',
            owner: 'Manufacturing Team',
            estimatedTime: '3-5 days',
          },
          {
            step: 5,
            action: 'Establish defect density trending with automated alerts',
            owner: 'Quality Engineering Team',
            estimatedTime: '1 week',
          },
        ],
        relatedMetrics: ['yieldRate', 'defectRate', 'patternDensity'],
        expectedImpact: 'Reducing defect density to <0.3 defects/cm² could improve yield by 2-3 percentage points.',
        references: [
          'SEMI M33 - Defect Density Measurement',
          'Cleanroom Contamination Control Best Practices',
        ],
      });
    }
    
    return recommendations;
  },
};

// Generate recommendations based on current metrics
export function generateRecommendations(
  metricContexts: MetricContext[]
): Recommendation[] {
  const allRecommendations: Recommendation[] = [];
  
  for (const context of metricContexts) {
    const generator = metricKnowledgeBase[context.metricId];
    if (generator) {
      const recommendations = generator(context);
      allRecommendations.push(...recommendations);
    }
  }
  
  // Sort by priority
  const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
  allRecommendations.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
  
  return allRecommendations;
}

// Generate summary insights
export function generateSummaryInsights(
  metricContexts: MetricContext[]
): {
  overallHealth: 'excellent' | 'good' | 'fair' | 'poor';
  keyFindings: string[];
  topPriorities: string[];
} {
  const recommendations = generateRecommendations(metricContexts);
  const criticalCount = recommendations.filter((r) => r.priority === 'critical').length;
  const highCount = recommendations.filter((r) => r.priority === 'high').length;
  
  let overallHealth: 'excellent' | 'good' | 'fair' | 'poor';
  if (criticalCount === 0 && highCount === 0) {
    overallHealth = 'excellent';
  } else if (criticalCount === 0 && highCount <= 2) {
    overallHealth = 'good';
  } else if (criticalCount <= 1) {
    overallHealth = 'fair';
  } else {
    overallHealth = 'poor';
  }
  
  const keyFindings: string[] = [];
  const topPriorities: string[] = [];
  
  if (criticalCount > 0) {
    keyFindings.push(`${criticalCount} critical issue${criticalCount > 1 ? 's' : ''} requiring immediate attention`);
    topPriorities.push(...recommendations.filter((r) => r.priority === 'critical').map((r) => r.title));
  }
  
  if (highCount > 0) {
    keyFindings.push(`${highCount} high-priority improvement opportunit${highCount > 1 ? 'ies' : 'y'} identified`);
  }
  
  const metricsImproving = metricContexts.filter((m) => m.currentValue > m.previousValue).length;
  const metricsDeclining = metricContexts.filter((m) => m.currentValue < m.previousValue).length;
  
  if (metricsImproving > metricsDeclining) {
    keyFindings.push(`Positive trend: ${metricsImproving} metrics improving vs ${metricsDeclining} declining`);
  } else if (metricsDeclining > metricsImproving) {
    keyFindings.push(`Concerning trend: ${metricsDeclining} metrics declining vs ${metricsImproving} improving`);
  }
  
  return {
    overallHealth,
    keyFindings,
    topPriorities: topPriorities.slice(0, 3),
  };
}
