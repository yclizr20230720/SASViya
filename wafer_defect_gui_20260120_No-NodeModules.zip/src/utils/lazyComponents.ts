import { lazy } from 'react';

/**
 * Lazy load heavy chart and visualization components
 * These components are loaded on-demand to reduce initial bundle size
 */

// Chart components
export const LazyPatternDistributionCharts = lazy(
  () => import('../components/PatternDistributionCharts')
);

export const LazyTemporalTrendAnalysis = lazy(
  () => import('../components/TemporalTrendAnalysis')
);

export const LazyYieldAnalysisCharts = lazy(
  () => import('../components/YieldAnalysisCharts')
);

export const LazyEquipmentCorrelationAnalysis = lazy(
  () => import('../components/EquipmentCorrelationAnalysis')
);

export const LazyProcessStepAnalysis = lazy(
  () => import('../components/ProcessStepAnalysis')
);

// Visualization components
export const LazySHAPVisualization = lazy(
  () => import('../components/SHAPVisualization')
);

export const LazyAttentionMapVisualization = lazy(
  () => import('../components/AttentionMapVisualization')
);

export const LazyWaferMapComparison = lazy(
  () => import('../components/WaferMapComparison')
);

// Report components
export const LazyReportViewer = lazy(
  () => import('../components/ReportViewer')
);

export const LazyReportBuilder = lazy(
  () => import('../components/ReportBuilder')
);

// Data table component
export const LazyAdvancedDataTable = lazy(
  () => import('../components/AdvancedDataTable')
);
