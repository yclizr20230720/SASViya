import { useMemo, useState } from 'react';
import {
  MaterialReactTable,
  useMaterialReactTable,
  type MRT_ColumnDef,
  type MRT_RowSelectionState,
  type MRT_ColumnFiltersState,
  type MRT_SortingState,
  type MRT_VisibilityState,
} from 'material-react-table';
import {
  Box,
  Button,
  IconButton,
  Tooltip,
  Menu,
  MenuItem,
  ListItemIcon,
  Typography,
  Chip,
} from '@mui/material';
import {
  Visibility as ViewIcon,
  GetApp as DownloadIcon,
  Delete as DeleteIcon,
  Compare as CompareIcon,
  MoreVert as MoreVertIcon,
  FileDownload as FileDownloadIcon,
} from '@mui/icons-material';

export interface WaferData {
  id: string;
  waferId: string;
  lotId: string;
  pattern: string;
  confidence: number;
  rootCause: string;
  equipment: string;
  processStep: string;
  date: string;
  defectCount: number;
  yieldImpact: number;
}

export interface AdvancedDataTableProps {
  data: WaferData[];
  onViewDetails?: (row: WaferData) => void;
  onDelete?: (rows: WaferData[]) => void;
  onCompare?: (rows: WaferData[]) => void;
  onExport?: (rows: WaferData[], format: 'csv' | 'excel' | 'pdf') => void;
}

const AdvancedDataTable: React.FC<AdvancedDataTableProps> = ({
  data,
  onViewDetails,
  onDelete,
  onCompare,
  onExport,
}) => {
  const [rowSelection, setRowSelection] = useState<MRT_RowSelectionState>({});
  const [columnFilters, setColumnFilters] = useState<MRT_ColumnFiltersState>([]);
  const [sorting, setSorting] = useState<MRT_SortingState>([]);
  const [columnVisibility, setColumnVisibility] = useState<MRT_VisibilityState>({});
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedRow, setSelectedRow] = useState<WaferData | null>(null);

  // Define columns
  const columns = useMemo<MRT_ColumnDef<WaferData>[]>(
    () => [
      {
        accessorKey: 'waferId',
        header: 'Wafer ID',
        size: 150,
        enableColumnFilter: true,
        filterVariant: 'text',
      },
      {
        accessorKey: 'lotId',
        header: 'Lot ID',
        size: 150,
        enableColumnFilter: true,
        filterVariant: 'text',
      },
      {
        accessorKey: 'pattern',
        header: 'Pattern',
        size: 140,
        enableColumnFilter: true,
        filterVariant: 'select',
        filterSelectOptions: ['Center', 'Edge-Ring', 'Edge-Loc', 'Loc', 'Random', 'None'],
        Cell: ({ cell }) => (
          <Chip
            label={cell.getValue<string>()}
            size="small"
            color="primary"
            variant="outlined"
          />
        ),
      },
      {
        accessorKey: 'confidence',
        header: 'Confidence',
        size: 180,
        enableColumnFilter: true,
        filterVariant: 'range',
        Cell: ({ cell }) => {
          const value = cell.getValue<number>();
          return (
            <Chip
              label={`${value.toFixed(1)}%`}
              size="small"
              color={value > 90 ? 'success' : value > 70 ? 'warning' : 'error'}
            />
          );
        },
      },
      {
        accessorKey: 'rootCause',
        header: 'Root Cause',
        size: 180,
        enableColumnFilter: true,
        filterVariant: 'text',
      },
      {
        accessorKey: 'equipment',
        header: 'Equipment',
        size: 180,
        enableColumnFilter: true,
        filterVariant: 'select',
        filterSelectOptions: ['EQP-001', 'EQP-002', 'EQP-003', 'EQP-004'],
      },
      {
        accessorKey: 'processStep',
        header: 'Process Step',
        size: 180,
        enableColumnFilter: true,
        filterVariant: 'select',
        filterSelectOptions: ['Lithography', 'Etching', 'Deposition', 'CMP', 'Ion Implantation'],
      },
      {
        accessorKey: 'date',
        header: 'Date',
        size: 130,
        enableColumnFilter: true,
        filterVariant: 'text',
        Cell: ({ cell }) => new Date(cell.getValue<string>()).toLocaleDateString(),
      },
      {
        accessorKey: 'defectCount',
        header: 'Defects',
        size: 160,
        enableColumnFilter: true,
        filterVariant: 'range',
      },
      {
        accessorKey: 'yieldImpact',
        header: 'Yield Impact',
        size: 180,
        enableColumnFilter: true,
        filterVariant: 'range',
        Cell: ({ cell }) => `${cell.getValue<number>().toFixed(2)}%`,
      },
    ],
    []
  );

  // Handle row action menu
  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, row: WaferData) => {
    setAnchorEl(event.currentTarget);
    setSelectedRow(row);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedRow(null);
  };

  // Handle view details
  const handleViewDetails = () => {
    if (selectedRow && onViewDetails) {
      onViewDetails(selectedRow);
    }
    handleMenuClose();
  };

  // Handle delete
  const handleDelete = () => {
    if (selectedRow && onDelete) {
      onDelete([selectedRow]);
    }
    handleMenuClose();
  };

  // Handle bulk delete
  const handleBulkDelete = () => {
    const selectedRows = data.filter((row) => rowSelection[row.id]);
    if (onDelete && selectedRows.length > 0) {
      onDelete(selectedRows);
      setRowSelection({});
    }
  };

  // Handle compare
  const handleCompare = () => {
    const selectedRows = data.filter((row) => rowSelection[row.id]);
    if (onCompare && selectedRows.length >= 2) {
      onCompare(selectedRows);
    }
  };

  // Handle export
  const handleExport = (format: 'csv' | 'excel' | 'pdf') => {
    const selectedRows = Object.keys(rowSelection).length > 0
      ? data.filter((row) => rowSelection[row.id])
      : data;
    
    if (onExport) {
      onExport(selectedRows, format);
    }
  };

  // Get selected row count
  const selectedCount = Object.keys(rowSelection).length;

  // Create table instance
  const table = useMaterialReactTable({
    columns,
    data,
    enableRowSelection: true,
    enableColumnOrdering: true,
    enableColumnResizing: true,
    enableStickyHeader: true,
    enableStickyFooter: true,
    enablePagination: true,
    enableSorting: true,
    enableColumnFilters: true,
    enableGlobalFilter: true,
    enableDensityToggle: true,
    enableFullScreenToggle: true,
    enableHiding: true,
    initialState: {
      density: 'compact',
      pagination: { pageSize: 20, pageIndex: 0 },
    },
    state: {
      rowSelection,
      columnFilters,
      sorting,
      columnVisibility,
    },
    onRowSelectionChange: setRowSelection,
    onColumnFiltersChange: setColumnFilters,
    onSortingChange: setSorting,
    onColumnVisibilityChange: setColumnVisibility,
    muiTableContainerProps: {
      sx: { 
        maxHeight: '70vh',
        overflow: 'auto',
      },
    },
    muiTableProps: {
      sx: {
        tableLayout: 'auto',
        minWidth: '100%',
      },
    },
    muiTableHeadCellProps: {
      sx: {
        backgroundColor: 'primary.main',
        color: 'white !important',
        fontWeight: 'bold',
        fontSize: '0.75rem',
        padding: '8px 12px',
        whiteSpace: 'normal',
        overflow: 'visible',
        lineHeight: 1.3,
        maxHeight: '48px',
        '& .Mui-TableHeadCell-Content': {
          justifyContent: 'space-between',
          fontWeight: 'bold',
          color: 'white !important',
          whiteSpace: 'normal',
          wordWrap: 'break-word',
        },
        '& .Mui-TableHeadCell-Content-Labels': {
          color: 'white !important',
          whiteSpace: 'normal',
        },
        '& .MuiTableSortLabel-root': {
          color: 'white !important',
          whiteSpace: 'normal',
          '&:hover': {
            color: 'white !important',
          },
          '&.Mui-active': {
            color: 'white !important',
          },
        },
        '& .MuiTableSortLabel-icon': {
          color: 'white !important',
          opacity: 1,
        },
        '& .MuiSvgIcon-root': {
          color: 'white !important',
        },
      },
    },
    muiTableBodyCellProps: {
      sx: {
        fontSize: '0.813rem',
      },
    },
    renderTopToolbarCustomActions: () => (
      <Box display="flex" gap={1}>
        {selectedCount > 0 && (
          <>
            <Typography variant="body2" sx={{ alignSelf: 'center', mr: 1 }}>
              {selectedCount} selected
            </Typography>
            <Button
              variant="outlined"
              size="small"
              startIcon={<CompareIcon />}
              onClick={handleCompare}
              disabled={selectedCount < 2}
            >
              Compare
            </Button>
            <Button
              variant="outlined"
              size="small"
              color="error"
              startIcon={<DeleteIcon />}
              onClick={handleBulkDelete}
            >
              Delete
            </Button>
          </>
        )}
        <Button
          variant="outlined"
          size="small"
          startIcon={<FileDownloadIcon />}
          onClick={() => handleExport('csv')}
        >
          Export CSV
        </Button>
        <Button
          variant="outlined"
          size="small"
          startIcon={<FileDownloadIcon />}
          onClick={() => handleExport('excel')}
        >
          Export Excel
        </Button>
      </Box>
    ),
    renderRowActions: ({ row }) => (
      <Box display="flex" gap={0.5}>
        <Tooltip title="View Details">
          <IconButton
            size="small"
            onClick={() => onViewDetails?.(row.original)}
          >
            <ViewIcon fontSize="small" />
          </IconButton>
        </Tooltip>
        <Tooltip title="More Actions">
          <IconButton
            size="small"
            onClick={(e) => handleMenuOpen(e, row.original)}
          >
            <MoreVertIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Box>
    ),
  });

  return (
    <>
      <MaterialReactTable table={table} />

      {/* Row Action Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={handleViewDetails}>
          <ListItemIcon>
            <ViewIcon fontSize="small" />
          </ListItemIcon>
          View Details
        </MenuItem>
        <MenuItem onClick={() => {
          if (selectedRow) {
            handleExport('csv');
          }
          handleMenuClose();
        }}>
          <ListItemIcon>
            <DownloadIcon fontSize="small" />
          </ListItemIcon>
          Download
        </MenuItem>
        <MenuItem onClick={handleDelete}>
          <ListItemIcon>
            <DeleteIcon fontSize="small" />
          </ListItemIcon>
          Delete
        </MenuItem>
      </Menu>
    </>
  );
};

export default AdvancedDataTable;
