import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Button,
  Rating,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Alert,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Divider,
} from '@mui/material';
import {
  AttachFile,
  Delete,
  Send,
  CheckCircle,
} from '@mui/icons-material';
import { patternTypes, rootCauses } from '../mock/mockData';

interface FeedbackFormData {
  rating: number;
  correctPatternClass: string;
  correctRootCause: string;
  comments: string;
  attachments: File[];
}

interface FeedbackSubmissionFormProps {
  waferId: string;
  predictedPattern: string;
  predictedRootCause: string;
  onSubmit?: (feedback: FeedbackFormData) => void;
}

export default function FeedbackSubmissionForm({
  waferId,
  predictedPattern,
  predictedRootCause,
  onSubmit,
}: FeedbackSubmissionFormProps) {
  const [rating, setRating] = useState<number>(4);
  const [correctPatternClass, setCorrectPatternClass] = useState<string>(predictedPattern);
  const [correctRootCause, setCorrectRootCause] = useState<string>(predictedRootCause);
  const [comments, setComments] = useState<string>('');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [submitted, setSubmitted] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const newFiles = Array.from(event.target.files);
      setAttachments([...attachments, ...newFiles]);
    }
  };

  const handleRemoveAttachment = (index: number) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    const feedbackData: FeedbackFormData = {
      rating,
      correctPatternClass,
      correctRootCause,
      comments,
      attachments,
    };

    if (onSubmit) {
      onSubmit(feedbackData);
    }

    // Simulate submission
    console.log('Feedback submitted:', feedbackData);
    setSubmitted(true);

    // Reset form after 3 seconds
    setTimeout(() => {
      setSubmitted(false);
      setRating(4);
      setCorrectPatternClass(predictedPattern);
      setCorrectRootCause(predictedRootCause);
      setComments('');
      setAttachments([]);
    }, 3000);
  };

  const isPatternCorrected = correctPatternClass !== predictedPattern;
  const isRootCauseCorrected = correctRootCause !== predictedRootCause;

  if (submitted) {
    return (
      <Card>
        <CardContent>
          <Box sx={{ textAlign: 'center', py: 4 }}>
            <CheckCircle color="success" sx={{ fontSize: 64, mb: 2 }} />
            <Typography variant="h5" gutterBottom sx={{ fontWeight: 600 }}>
              Feedback Submitted Successfully
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Thank you for helping improve our model accuracy!
            </Typography>
          </Box>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent>
        <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
          Provide Feedback for Wafer {waferId}
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Your feedback helps improve model accuracy and performance
        </Typography>

        {/* Rating */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" gutterBottom>
            Overall Prediction Quality
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Rating
              value={rating}
              onChange={(_, newValue) => setRating(newValue || 0)}
              size="large"
            />
            <Typography variant="body2" color="text.secondary">
              {rating === 5 && 'Excellent'}
              {rating === 4 && 'Good'}
              {rating === 3 && 'Fair'}
              {rating === 2 && 'Poor'}
              {rating === 1 && 'Very Poor'}
            </Typography>
          </Box>
        </Box>

        <Divider sx={{ my: 3 }} />

        {/* Pattern Class Correction */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" gutterBottom>
            Correct Pattern Classification
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', mb: 1 }}>
            <Typography variant="body2" color="text.secondary">
              Predicted:
            </Typography>
            <Chip label={predictedPattern} size="small" />
          </Box>
          <FormControl fullWidth>
            <InputLabel>Correct Pattern Class</InputLabel>
            <Select
              value={correctPatternClass}
              onChange={(e) => setCorrectPatternClass(e.target.value)}
              label="Correct Pattern Class"
            >
              {patternTypes.map((pattern) => (
                <MenuItem key={pattern} value={pattern}>
                  {pattern}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          {isPatternCorrected && (
            <Alert severity="info" sx={{ mt: 1 }}>
              Pattern correction noted - this will help retrain the model
            </Alert>
          )}
        </Box>

        {/* Root Cause Correction */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" gutterBottom>
            Correct Root Cause
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', mb: 1 }}>
            <Typography variant="body2" color="text.secondary">
              Predicted:
            </Typography>
            <Chip label={predictedRootCause} size="small" />
          </Box>
          <FormControl fullWidth>
            <InputLabel>Correct Root Cause</InputLabel>
            <Select
              value={correctRootCause}
              onChange={(e) => setCorrectRootCause(e.target.value)}
              label="Correct Root Cause"
            >
              {rootCauses.map((cause) => (
                <MenuItem key={cause} value={cause}>
                  {cause}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          {isRootCauseCorrected && (
            <Alert severity="info" sx={{ mt: 1 }}>
              Root cause correction noted - this will help retrain the model
            </Alert>
          )}
        </Box>

        <Divider sx={{ my: 3 }} />

        {/* Comments */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" gutterBottom>
            Additional Comments
          </Typography>
          <TextField
            fullWidth
            multiline
            rows={4}
            placeholder="Provide additional context, observations, or suggestions..."
            value={comments}
            onChange={(e) => setComments(e.target.value)}
            variant="outlined"
          />
        </Box>

        {/* Attachments */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" gutterBottom>
            Attachments (Optional)
          </Typography>
          <Button
            variant="outlined"
            component="label"
            startIcon={<AttachFile />}
            sx={{ mb: 2 }}
          >
            Add Files
            <input
              type="file"
              hidden
              multiple
              accept="image/*,.pdf,.doc,.docx"
              onChange={handleFileUpload}
            />
          </Button>

          {attachments.length > 0 && (
            <List dense>
              {attachments.map((file, index) => (
                <ListItem key={index}>
                  <ListItemText
                    primary={file.name}
                    secondary={`${(file.size / 1024).toFixed(1)} KB`}
                  />
                  <ListItemSecondaryAction>
                    <IconButton
                      edge="end"
                      size="small"
                      onClick={() => handleRemoveAttachment(index)}
                    >
                      <Delete />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          )}
        </Box>

        {/* Submit Button */}
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
          <Button
            variant="contained"
            size="large"
            startIcon={<Send />}
            onClick={handleSubmit}
            disabled={!rating}
          >
            Submit Feedback
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
}
