import {
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Grid,
  Card,
  CardContent,
  Typography,
  Chip,
} from '@mui/material';
import {
  BarChart as ChartIcon,
  TableChart as TableIcon,
  Image as ImageIcon,
  TextFields as TextIcon,
  Assessment as MetricIcon,
} from '@mui/icons-material';
import type { ReportTemplate, ReportWidgetType } from '../types/report';

export interface ReportTemplatePreviewProps {
  template: ReportTemplate | null;
  open: boolean;
  onClose: () => void;
  onUse?: () => void;
}

const getWidgetIcon = (type: ReportWidgetType) => {
  switch (type) {
    case 'chart':
      return <ChartIcon />;
    case 'table':
      return <TableIcon />;
    case 'wafer-map':
      return <ImageIcon />;
    case 'metric':
      return <MetricIcon />;
    case 'text':
      return <TextIcon />;
    case 'image':
      return <ImageIcon />;
    default:
      return <ChartIcon />;
  }
};

const getWidgetColor = (type: ReportWidgetType) => {
  switch (type) {
    case 'chart':
      return 'primary.light';
    case 'table':
      return 'secondary.light';
    case 'wafer-map':
      return 'success.light';
    case 'metric':
      return 'warning.light';
    case 'text':
      return 'info.light';
    case 'image':
      return 'error.light';
    default:
      return 'grey.300';
  }
};

const ReportTemplatePreview: React.FC<ReportTemplatePreviewProps> = ({
  template,
  open,
  onClose,
  onUse,
}) => {
  if (!template) return null;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="h6">{template.name}</Typography>
          <Chip
            label={template.type.replace('-', ' ')}
            size="small"
            color="primary"
            sx={{ textTransform: 'capitalize' }}
          />
        </Box>
        <Typography variant="body2" color="text.secondary" mt={1}>
          {template.description}
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Box bgcolor="grey.100" p={2} borderRadius={1}>
          <Grid container spacing={1}>
            {template.widgets.map((widget) => (
              <Grid
                size={{ xs: widget.position.width }}
                key={widget.id}
              >
                <Card
                  sx={{
                    minHeight: widget.position.height * 40,
                    bgcolor: getWidgetColor(widget.type),
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}
                >
                  <CardContent sx={{ textAlign: 'center' }}>
                    <Box mb={1}>{getWidgetIcon(widget.type)}</Box>
                    <Typography variant="body2" fontWeight={600}>
                      {widget.title}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {widget.type}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          {template.widgets.length === 0 && (
            <Box textAlign="center" py={4}>
              <Typography variant="body2" color="text.secondary">
                No widgets configured
              </Typography>
            </Box>
          )}
        </Box>

        <Box mt={3}>
          <Typography variant="subtitle2" gutterBottom>
            Template Details
          </Typography>
          <Typography variant="body2" color="text.secondary">
            • {template.widgets.length} widgets configured
          </Typography>
          <Typography variant="body2" color="text.secondary">
            • Layout: {template.layout}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            • Last updated: {new Date(template.updatedAt).toLocaleString()}
          </Typography>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        {onUse && (
          <Button onClick={onUse} variant="contained">
            Use This Template
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default ReportTemplatePreview;
