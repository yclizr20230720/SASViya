import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Card,
  CardContent,
  Typography,
  Box,
  IconButton,
  Chip,
  Slider,
  CardActionArea,
  Grid,
} from '@mui/material';

import {
  ChevronLeft,
  ChevronRight,
  Visibility,
} from '@mui/icons-material';

interface SimilarCase {
  id: string;
  waferId: string;
  lotId: string;
  patternType: string;
  similarityScore: number;
  timestamp: string;
  thumbnail?: string;
}

interface SimilarCasesCarouselProps {
  cases: SimilarCase[];
  minSimilarity?: number;
}

export default function SimilarCasesCarousel({
  cases,
  minSimilarity = 0.7,
}: SimilarCasesCarouselProps) {
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [similarityThreshold, setSimilarityThreshold] = useState(minSimilarity);

  const filteredCases = cases.filter((c) => c.similarityScore >= similarityThreshold);
  const itemsPerPage = 3;
  const maxIndex = Math.max(0, Math.ceil(filteredCases.length / itemsPerPage) - 1);

  const handlePrevious = () => {
    setCurrentIndex((prev) => Math.max(0, prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => Math.min(maxIndex, prev + 1));
  };

  const handleViewCase = (waferId: string) => {
    navigate(`/analysis/${waferId}`);
  };

  const visibleCases = filteredCases.slice(
    currentIndex * itemsPerPage,
    (currentIndex + 1) * itemsPerPage
  );

  const getSimilarityColor = (score: number) => {
    if (score >= 0.9) return 'success';
    if (score >= 0.7) return 'warning';
    return 'default';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Similar Historical Cases
          </Typography>
          <Chip
            label={`${filteredCases.length} cases found`}
            size="small"
            color="primary"
          />
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Historical wafer maps with similar defect patterns
        </Typography>

        {/* Similarity Threshold Slider */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="body2" gutterBottom>
            Similarity Threshold: {(similarityThreshold * 100).toFixed(0)}%
          </Typography>
          <Slider
            value={similarityThreshold}
            onChange={(_, value) => {
              setSimilarityThreshold(value as number);
              setCurrentIndex(0);
            }}
            min={0.5}
            max={1}
            step={0.05}
            marks={[
              { value: 0.5, label: '50%' },
              { value: 0.7, label: '70%' },
              { value: 0.9, label: '90%' },
            ]}
          />
        </Box>

        {/* Carousel */}
        {filteredCases.length > 0 ? (
          <>
            <Box sx={{ position: 'relative' }}>
              <Grid container spacing={2}>
                {visibleCases.map((case_) => (
                  <Grid size={{ xs: 12, sm: 6, md: 4 }} key={case_.id}>
                    <Card
                      variant="outlined"
                      sx={{
                        height: '100%',
                        transition: 'transform 0.2s, box-shadow 0.2s',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: 4,
                        },
                      }}
                    >
                      <CardActionArea onClick={() => handleViewCase(case_.waferId)}>
                        <CardContent>
                          {/* Thumbnail placeholder */}
                          <Box
                            sx={{
                              height: 120,
                              bgcolor: 'action.hover',
                              borderRadius: 1,
                              mb: 2,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          >
                            <Visibility sx={{ fontSize: 48, color: 'text.secondary' }} />
                          </Box>

                          <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                            {case_.waferId}
                          </Typography>

                          <Typography variant="caption" color="text.secondary" display="block">
                            Lot: {case_.lotId}
                          </Typography>

                          <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1 }}>
                            {formatDate(case_.timestamp)}
                          </Typography>

                          <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mb: 1 }}>
                            <Chip
                              label={case_.patternType}
                              size="small"
                              sx={{ fontSize: '0.7rem' }}
                            />
                            <Chip
                              label={`${(case_.similarityScore * 100).toFixed(0)}% match`}
                              size="small"
                              color={getSimilarityColor(case_.similarityScore) as any}
                              sx={{ fontSize: '0.7rem' }}
                            />
                          </Box>
                        </CardContent>
                      </CardActionArea>
                    </Card>
                  </Grid>
                ))}
              </Grid>

              {/* Navigation Buttons */}
              {maxIndex > 0 && (
                <Box
                  sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    gap: 2,
                    mt: 2,
                  }}
                >
                  <IconButton
                    onClick={handlePrevious}
                    disabled={currentIndex === 0}
                    size="small"
                  >
                    <ChevronLeft />
                  </IconButton>
                  <Typography variant="body2" sx={{ alignSelf: 'center' }}>
                    {currentIndex + 1} / {maxIndex + 1}
                  </Typography>
                  <IconButton
                    onClick={handleNext}
                    disabled={currentIndex === maxIndex}
                    size="small"
                  >
                    <ChevronRight />
                  </IconButton>
                </Box>
              )}
            </Box>
          </>
        ) : (
          <Box sx={{ textAlign: 'center', py: 4 }}>
            <Typography variant="body2" color="text.secondary">
              No similar cases found with the current threshold
            </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );
}
