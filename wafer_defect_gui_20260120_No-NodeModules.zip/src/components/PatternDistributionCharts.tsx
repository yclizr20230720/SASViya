import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  FormControlLabel,
  Switch,
} from '@mui/material';
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { DonutLarge, BarChart as BarChartIcon, ShowChart } from '@mui/icons-material';

interface PatternDistributionChartsProps {
  data?: {
    distribution: { pattern: string; count: number; percentage: number }[];
    trends: { date: string; [key: string]: number | string }[];
  };
}

type ChartType = 'pie' | 'bar' | 'area';

const COLORS = ['#0066CC', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658'];

export default function PatternDistributionCharts({
  data,
}: PatternDistributionChartsProps) {
  const [chartType, setChartType] = useState<ChartType>('pie');
  const [showLegendFilter, setShowLegendFilter] = useState(true);
  const [hiddenPatterns, setHiddenPatterns] = useState<Set<string>>(new Set());

  // Transform API data to chart format
  const pieData = data?.distribution.map((item, index) => ({
    name: item.pattern,
    value: item.count,
    color: COLORS[index % COLORS.length],
  })) || [];

  const trendData = data?.trends || [];
  const frequencyData = data?.trends || [];

  if (!data || pieData.length === 0) {
    return (
      <Card>
        <CardContent>
          <Typography variant="body2" color="text.secondary">
            No pattern distribution data available
          </Typography>
        </CardContent>
      </Card>
    );
  }

  const handleLegendClick = (entry: any) => {
    if (!showLegendFilter) return;
    
    const newHidden = new Set(hiddenPatterns);
    if (newHidden.has(entry.value || entry.dataKey)) {
      newHidden.delete(entry.value || entry.dataKey);
    } else {
      newHidden.add(entry.value || entry.dataKey);
    }
    setHiddenPatterns(newHidden);
  };

  const filteredPieData = pieData.filter((item) => !hiddenPatterns.has(item.name));

  const renderPieChart = () => (
    <ResponsiveContainer width="100%" height={400}>
      <PieChart>
        <Pie
          data={filteredPieData}
          cx="50%"
          cy="50%"
          labelLine
          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
          outerRadius={120}
          fill="#8884d8"
          dataKey="value"
        >
          {filteredPieData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip />
        <Legend
          onClick={handleLegendClick}
          wrapperStyle={{ cursor: showLegendFilter ? 'pointer' : 'default' }}
        />
      </PieChart>
    </ResponsiveContainer>
  );

  const renderBarChart = () => {
    const patternKeys = frequencyData.length > 0 ? Object.keys(frequencyData[0]).filter((key) => key !== 'date') : [];
    const visibleKeys = patternKeys.filter((key) => !hiddenPatterns.has(key));

    return (
      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={frequencyData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          <Legend
            onClick={handleLegendClick}
            wrapperStyle={{ cursor: showLegendFilter ? 'pointer' : 'default' }}
          />
          {visibleKeys.map((key, index) => (
            <Bar
              key={key}
              dataKey={key}
              fill={COLORS[index % COLORS.length]}
              stackId="a"
            />
          ))}
        </BarChart>
      </ResponsiveContainer>
    );
  };

  const renderAreaChart = () => {
    const patternKeys = trendData.length > 0 ? Object.keys(trendData[0]).filter((key) => key !== 'date') : [];
    const visibleKeys = patternKeys.filter((key) => !hiddenPatterns.has(key));

    return (
      <ResponsiveContainer width="100%" height={400}>
        <AreaChart data={trendData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          <Legend
            onClick={handleLegendClick}
            wrapperStyle={{ cursor: showLegendFilter ? 'pointer' : 'default' }}
          />
          {visibleKeys.map((key, index) => (
            <Area
              key={key}
              type="monotone"
              dataKey={key}
              stackId="1"
              stroke={COLORS[index % COLORS.length]}
              fill={COLORS[index % COLORS.length]}
            />
          ))}
        </AreaChart>
      </ResponsiveContainer>
    );
  };

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <DonutLarge color="primary" />
          <Typography variant="h6" sx={{ fontWeight: 600, flex: 1 }}>
            Defect Pattern Distribution
          </Typography>
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Analysis of defect pattern occurrences across wafers
        </Typography>

        {/* Chart Type Selector */}
        <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <ToggleButtonGroup
            value={chartType}
            exclusive
            onChange={(_, value) => value && setChartType(value)}
            size="small"
          >
            <ToggleButton value="pie">
              <DonutLarge sx={{ mr: 1 }} fontSize="small" />
              Pie Chart
            </ToggleButton>
            <ToggleButton value="bar">
              <BarChartIcon sx={{ mr: 1 }} fontSize="small" />
              Bar Chart
            </ToggleButton>
            <ToggleButton value="area">
              <ShowChart sx={{ mr: 1 }} fontSize="small" />
              Trend Chart
            </ToggleButton>
          </ToggleButtonGroup>

          <FormControlLabel
            control={
              <Switch
                checked={showLegendFilter}
                onChange={(e) => {
                  setShowLegendFilter(e.target.checked);
                  if (!e.target.checked) {
                    setHiddenPatterns(new Set());
                  }
                }}
                size="small"
              />
            }
            label={<Typography variant="caption">Interactive Legend</Typography>}
          />
        </Box>

        {/* Render Selected Chart */}
        {chartType === 'pie' && renderPieChart()}
        {chartType === 'bar' && renderBarChart()}
        {chartType === 'area' && renderAreaChart()}

        {/* Summary Statistics */}
        <Box sx={{ mt: 3, p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
          <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
            Distribution Summary
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 2 }}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Most Common
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {pieData[0]?.name || 'N/A'}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Total Patterns
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {pieData.reduce((sum, item) => sum + item.value, 0)}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Pattern Types
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {pieData.length}
              </Typography>
            </Box>
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
}

// No longer need mock data generator
