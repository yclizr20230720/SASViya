import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import SavedViewsManager from '../SavedViewsManager';

describe('SavedViewsManager', () => {
  const mockOnClose = vi.fn();
  const mockOnLoadView = vi.fn();
  const mockOnSaveView = vi.fn();
  const mockOnDeleteView = vi.fn();
  const mockOnUpdateView = vi.fn();

  const mockSavedViews = [
    {
      id: 'view1',
      name: 'High Confidence Wafers',
      description: 'Wafers with confidence > 90%',
      filters: { confidenceRange: [90, 100] },
      isShared: true,
      createdAt: '2024-01-15T10:00:00Z',
      updatedAt: '2024-01-15T10:00:00Z',
      createdBy: 'user1',
    },
    {
      id: 'view2',
      name: 'Recent Uploads',
      filters: { dateRange: { start: '2024-01-01', end: '2024-01-31' } },
      isShared: false,
      createdAt: '2024-01-16T10:00:00Z',
      updatedAt: '2024-01-16T10:00:00Z',
      createdBy: 'user1',
    },
  ];

  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
  });

  it('renders when open', () => {
    render(
      <SavedViewsManager
        open={true}
        onClose={mockOnClose}
        onLoadView={mockOnLoadView}
        onSaveView={mockOnSaveView}
        onDeleteView={mockOnDeleteView}
        onUpdateView={mockOnUpdateView}
        savedViews={[]}
        currentUserId="user1"
      />
    );

    expect(screen.getByText('Saved Views & Bookmarks')).toBeInTheDocument();
  });

  it('shows empty state when no views', () => {
    render(
      <SavedViewsManager
        open={true}
        onClose={mockOnClose}
        onLoadView={mockOnLoadView}
        onSaveView={mockOnSaveView}
        onDeleteView={mockOnDeleteView}
        onUpdateView={mockOnUpdateView}
        savedViews={[]}
        currentUserId="user1"
      />
    );

    expect(screen.getByText('No Saved Views')).toBeInTheDocument();
  });

  it('displays saved views', () => {
    render(
      <SavedViewsManager
        open={true}
        onClose={mockOnClose}
        onLoadView={mockOnLoadView}
        onSaveView={mockOnSaveView}
        onDeleteView={mockOnDeleteView}
        onUpdateView={mockOnUpdateView}
        savedViews={mockSavedViews}
        currentUserId="user1"
      />
    );

    expect(screen.getByText('High Confidence Wafers')).toBeInTheDocument();
    expect(screen.getByText('Recent Uploads')).toBeInTheDocument();
  });

  it('shows shared badge for shared views', () => {
    render(
      <SavedViewsManager
        open={true}
        onClose={mockOnClose}
        onLoadView={mockOnLoadView}
        onSaveView={mockOnSaveView}
        onDeleteView={mockOnDeleteView}
        onUpdateView={mockOnUpdateView}
        savedViews={mockSavedViews}
        currentUserId="user1"
      />
    );

    expect(screen.getByText('Shared')).toBeInTheDocument();
  });

  it('opens create dialog when save button is clicked', () => {
    render(
      <SavedViewsManager
        open={true}
        onClose={mockOnClose}
        onLoadView={mockOnLoadView}
        onSaveView={mockOnSaveView}
        onDeleteView={mockOnDeleteView}
        onUpdateView={mockOnUpdateView}
        savedViews={[]}
        currentUserId="user1"
      />
    );

    const saveButton = screen.getByRole('button', { name: /Save Current View/i });
    fireEvent.click(saveButton);

    expect(screen.getByText('Save Current View')).toBeInTheDocument();
    expect(screen.getByLabelText('View Name')).toBeInTheDocument();
  });

  it('calls onLoadView when view is loaded', () => {
    render(
      <SavedViewsManager
        open={true}
        onClose={mockOnClose}
        onLoadView={mockOnLoadView}
        onSaveView={mockOnSaveView}
        onDeleteView={mockOnDeleteView}
        onUpdateView={mockOnUpdateView}
        savedViews={mockSavedViews}
        currentUserId="user1"
      />
    );

    const loadButtons = screen.getAllByTestId('VisibilityIcon');
    fireEvent.click(loadButtons[0].parentElement!);

    expect(mockOnLoadView).toHaveBeenCalledWith(mockSavedViews[0]);
    expect(mockOnClose).toHaveBeenCalled();
  });

  it('calls onClose when close button is clicked', () => {
    render(
      <SavedViewsManager
        open={true}
        onClose={mockOnClose}
        onLoadView={mockOnLoadView}
        onSaveView={mockOnSaveView}
        onDeleteView={mockOnDeleteView}
        onUpdateView={mockOnUpdateView}
        savedViews={[]}
        currentUserId="user1"
      />
    );

    const closeButton = screen.getByRole('button', { name: /Close/i });
    fireEvent.click(closeButton);

    expect(mockOnClose).toHaveBeenCalled();
  });

  it('saves view name to localStorage', () => {
    render(
      <SavedViewsManager
        open={true}
        onClose={mockOnClose}
        onLoadView={mockOnLoadView}
        onSaveView={mockOnSaveView}
        onDeleteView={mockOnDeleteView}
        onUpdateView={mockOnUpdateView}
        savedViews={[]}
        currentUserId="user1"
      />
    );

    // Open create dialog
    const saveButton = screen.getByRole('button', { name: /Save Current View/i });
    fireEvent.click(saveButton);

    // Fill in form
    const nameInput = screen.getByLabelText('View Name');
    fireEvent.change(nameInput, { target: { value: 'Test View' } });

    // Save
    const saveViewButton = screen.getAllByRole('button', { name: /Save/i })[1];
    fireEvent.click(saveViewButton);

    expect(mockOnSaveView).toHaveBeenCalled();
  });
});
