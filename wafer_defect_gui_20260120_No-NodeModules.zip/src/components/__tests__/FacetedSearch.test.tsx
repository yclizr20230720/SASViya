import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import FacetedSearch from '../FacetedSearch';

describe('FacetedSearch', () => {
  const mockFacets = [
    {
      id: 'pattern',
      name: 'Pattern Type',
      options: [
        { value: 'center', label: 'Center', count: 25 },
        { value: 'edge', label: 'Edge-Ring', count: 15 },
        { value: 'random', label: 'Random', count: 10 },
      ],
    },
    {
      id: 'equipment',
      name: 'Equipment',
      options: [
        { value: 'eqp1', label: 'EQP-001', count: 30 },
        { value: 'eqp2', label: 'EQP-002', count: 20 },
      ],
    },
  ];

  const mockOnFacetChange = vi.fn();
  const mockOnClearAll = vi.fn();

  it('renders facets', () => {
    render(
      <FacetedSearch
        facets={mockFacets}
        selectedFacets={{}}
        onFacetChange={mockOnFacetChange}
      />
    );

    expect(screen.getByText('Pattern Type')).toBeInTheDocument();
    expect(screen.getByText('Equipment')).toBeInTheDocument();
  });

  it('shows facet options with counts', () => {
    render(
      <FacetedSearch
        facets={mockFacets}
        selectedFacets={{}}
        onFacetChange={mockOnFacetChange}
      />
    );

    expect(screen.getByText('Center')).toBeInTheDocument();
    expect(screen.getByText('(25)')).toBeInTheDocument();
    expect(screen.getByText('Edge-Ring')).toBeInTheDocument();
    expect(screen.getByText('(15)')).toBeInTheDocument();
  });

  it('calls onFacetChange when option is selected', () => {
    render(
      <FacetedSearch
        facets={mockFacets}
        selectedFacets={{}}
        onFacetChange={mockOnFacetChange}
      />
    );

    const centerCheckbox = screen.getByRole('checkbox', { name: /Center/i });
    fireEvent.click(centerCheckbox);

    expect(mockOnFacetChange).toHaveBeenCalledWith('pattern', ['center']);
  });

  it('shows selected facets as chips', () => {
    render(
      <FacetedSearch
        facets={mockFacets}
        selectedFacets={{ pattern: ['center'], equipment: ['eqp1'] }}
        onFacetChange={mockOnFacetChange}
      />
    );

    expect(screen.getByText('Active Filters')).toBeInTheDocument();
    expect(screen.getByText('Pattern Type: Center')).toBeInTheDocument();
    expect(screen.getByText('Equipment: EQP-001')).toBeInTheDocument();
  });

  it('shows total selected count', () => {
    render(
      <FacetedSearch
        facets={mockFacets}
        selectedFacets={{ pattern: ['center', 'edge'], equipment: ['eqp1'] }}
        onFacetChange={mockOnFacetChange}
      />
    );

    expect(screen.getByText('3')).toBeInTheDocument(); // Badge with count
  });

  it('calls onClearAll when clear all is clicked', () => {
    render(
      <FacetedSearch
        facets={mockFacets}
        selectedFacets={{ pattern: ['center'] }}
        onFacetChange={mockOnFacetChange}
        onClearAll={mockOnClearAll}
      />
    );

    const clearAllButton = screen.getByText('Clear All');
    fireEvent.click(clearAllButton);

    expect(mockOnClearAll).toHaveBeenCalled();
  });

  it('removes facet when chip delete is clicked', () => {
    render(
      <FacetedSearch
        facets={mockFacets}
        selectedFacets={{ pattern: ['center'] }}
        onFacetChange={mockOnFacetChange}
      />
    );

    const chip = screen.getByText('Pattern Type: Center');
    const deleteButton = chip.parentElement?.querySelector('[data-testid="CancelIcon"]');
    
    if (deleteButton) {
      fireEvent.click(deleteButton);
      expect(mockOnFacetChange).toHaveBeenCalledWith('pattern', []);
    }
  });

  it('toggles facet expansion', () => {
    render(
      <FacetedSearch
        facets={mockFacets}
        selectedFacets={{}}
        onFacetChange={mockOnFacetChange}
      />
    );

    const patternHeader = screen.getByText('Pattern Type');
    
    // Initially expanded, so options should be visible
    expect(screen.getByText('Center')).toBeVisible();
    
    // Click to collapse
    fireEvent.click(patternHeader);
    
    // Options should still be in DOM but may be hidden by Collapse
    expect(screen.getByText('Center')).toBeInTheDocument();
  });
});
