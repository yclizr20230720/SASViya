import { useState, useEffect } from 'react';
import {
  Autocomplete,
  TextField,
  InputAdornment,
  Paper,
  Box,
  Typography,
  Chip,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
} from '@mui/material';
import {
  Search as SearchIcon,
  History as HistoryIcon,
  Memory as WaferIcon,
  Category as PatternIcon,
  CalendarToday as DateIcon,
  Clear as ClearIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

export interface SearchResult {
  id: string;
  type: 'wafer' | 'lot' | 'pattern' | 'date' | 'equipment';
  title: string;
  subtitle?: string;
  path: string;
  metadata?: Record<string, string>;
}

export interface GlobalSearchProps {
  onSearch?: (query: string) => void;
  onResultSelect?: (result: SearchResult) => void;
}

const GlobalSearch: React.FC<GlobalSearchProps> = ({ onSearch, onResultSelect }) => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [open, setOpen] = useState(false);

  // Load search history from localStorage
  useEffect(() => {
    const history = localStorage.getItem('searchHistory');
    if (history) {
      setSearchHistory(JSON.parse(history));
    }
  }, []);

  // Save search to history
  const saveToHistory = (query: string) => {
    if (!query.trim()) return;
    
    const newHistory = [query, ...searchHistory.filter(h => h !== query)].slice(0, 10);
    setSearchHistory(newHistory);
    localStorage.setItem('searchHistory', JSON.stringify(newHistory));
  };

  // Clear search history
  const clearHistory = () => {
    setSearchHistory([]);
    localStorage.removeItem('searchHistory');
  };

  // Mock search function - replace with actual API call
  const performSearch = async (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 300));

    // Mock search results
    const mockResults: SearchResult[] = [
      {
        id: '1',
        type: 'wafer',
        title: `Wafer ${query}`,
        subtitle: 'Lot: LOT-2024-001',
        path: `/analysis/wafer-${query}`,
        metadata: { pattern: 'Center', confidence: '95%' },
      },
      {
        id: '2',
        type: 'lot',
        title: `LOT-${query}`,
        subtitle: '25 wafers',
        path: `/history?lot=LOT-${query}`,
        metadata: { date: '2024-01-15' },
      },
      {
        id: '3',
        type: 'pattern',
        title: 'Center Pattern',
        subtitle: `Found in ${query} wafers`,
        path: `/analytics?pattern=center`,
        metadata: { frequency: '15%' },
      },
    ];

    setSearchResults(mockResults.filter(r => 
      r.title.toLowerCase().includes(query.toLowerCase()) ||
      r.subtitle?.toLowerCase().includes(query.toLowerCase())
    ));
    setIsLoading(false);
  };

  // Handle search input change
  const handleInputChange = (_: any, value: string) => {
    setSearchQuery(value);
    performSearch(value);
    onSearch?.(value);
  };

  // Handle result selection
  const handleResultSelect = (_: any, value: SearchResult | string | null) => {
    if (!value) return;

    if (typeof value === 'string') {
      // User pressed Enter with custom text
      saveToHistory(value);
      performSearch(value);
    } else {
      // User selected a result
      saveToHistory(value.title);
      onResultSelect?.(value);
      navigate(value.path);
      setOpen(false);
    }
  };

  // Get icon for result type
  const getResultIcon = (type: SearchResult['type']) => {
    switch (type) {
      case 'wafer':
        return <WaferIcon />;
      case 'pattern':
        return <PatternIcon />;
      case 'date':
        return <DateIcon />;
      default:
        return <SearchIcon />;
    }
  };

  // Render search option
  const renderOption = (props: any, option: SearchResult | string) => {
    if (typeof option === 'string') {
      return (
        <ListItem {...props}>
          <ListItemIcon>
            <HistoryIcon />
          </ListItemIcon>
          <ListItemText primary={option} secondary="From history" />
        </ListItem>
      );
    }

    return (
      <ListItem {...props}>
        <ListItemIcon>
          {getResultIcon(option.type)}
        </ListItemIcon>
        <ListItemText
          primary={
            <Box display="flex" alignItems="center" gap={1}>
              <Typography variant="body1">{option.title}</Typography>
              <Chip label={option.type} size="small" />
            </Box>
          }
          secondary={
            <Box>
              {option.subtitle && (
                <Typography variant="body2" color="text.secondary">
                  {option.subtitle}
                </Typography>
              )}
              {option.metadata && (
                <Box display="flex" gap={1} mt={0.5}>
                  {Object.entries(option.metadata).map(([key, value]) => (
                    <Chip key={key} label={`${key}: ${value}`} size="small" variant="outlined" />
                  ))}
                </Box>
              )}
            </Box>
          }
        />
      </ListItem>
    );
  };

  return (
    <Autocomplete
      freeSolo
      open={open}
      onOpen={() => setOpen(true)}
      onClose={() => setOpen(false)}
      options={searchQuery ? searchResults : searchHistory}
      getOptionLabel={(option) => typeof option === 'string' ? option : option.title}
      loading={isLoading}
      inputValue={searchQuery}
      onInputChange={handleInputChange}
      onChange={handleResultSelect}
      filterOptions={(x) => x} // Disable built-in filtering
      renderInput={(params) => (
        <TextField
          {...params}
          placeholder="Search wafers, lots, patterns..."
          variant="outlined"
          size="small"
          InputProps={{
            ...params.InputProps,
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
            endAdornment: (
              <>
                {searchQuery && (
                  <InputAdornment position="end">
                    <ClearIcon
                      sx={{ cursor: 'pointer', fontSize: 20 }}
                      onClick={() => {
                        setSearchQuery('');
                        setSearchResults([]);
                      }}
                    />
                  </InputAdornment>
                )}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
        />
      )}
      renderOption={renderOption}
      PaperComponent={(props) => (
        <Paper {...props}>
          {props.children}
          {searchHistory.length > 0 && !searchQuery && (
            <>
              <Divider />
              <Box p={1} display="flex" justifyContent="space-between" alignItems="center">
                <Typography variant="caption" color="text.secondary">
                  Recent Searches
                </Typography>
                <Typography
                  variant="caption"
                  color="primary"
                  sx={{ cursor: 'pointer' }}
                  onClick={clearHistory}
                >
                  Clear History
                </Typography>
              </Box>
            </>
          )}
        </Paper>
      )}
      sx={{ minWidth: 300, maxWidth: 600 }}
    />
  );
};

export default GlobalSearch;
