import { useState, useEffect } from 'react';
import {
  Box,
  TextField,
  Autocomplete,
  Typography,
  Button,
  Checkbox,
  FormControlLabel,
} from '@mui/material';
import { ContentCopy } from '@mui/icons-material';

interface MetadataFormProps {
  value: {
    lotId: string;
    processStep: string;
    equipmentId: string;
  };
  onChange: (metadata: { lotId: string; processStep: string; equipmentId: string }) => void;
  fileCount: number;
}

export default function MetadataForm({ value, onChange, fileCount }: MetadataFormProps) {
  const [applyToAll, setApplyToAll] = useState(true);

  // Load previously used values from localStorage
  const [recentLotIds, setRecentLotIds] = useState<string[]>([]);
  const [recentProcessSteps, setRecentProcessSteps] = useState<string[]>([]);
  const [recentEquipmentIds, setRecentEquipmentIds] = useState<string[]>([]);

  useEffect(() => {
    const loadedLotIds = JSON.parse(localStorage.getItem('recentLotIds') || '[]');
    const loadedProcessSteps = JSON.parse(localStorage.getItem('recentProcessSteps') || '[]');
    const loadedEquipmentIds = JSON.parse(localStorage.getItem('recentEquipmentIds') || '[]');

    setRecentLotIds(loadedLotIds);
    setRecentProcessSteps(loadedProcessSteps);
    setRecentEquipmentIds(loadedEquipmentIds);
  }, []);

  const saveToRecent = (key: string, value: string, setter: (val: string[]) => void) => {
    if (!value) return;

    const storageKey = `recent${key}`;
    const recent = JSON.parse(localStorage.getItem(storageKey) || '[]');
    const updated = [value, ...recent.filter((v: string) => v !== value)].slice(0, 10);

    localStorage.setItem(storageKey, JSON.stringify(updated));
    setter(updated);
  };

  const handleLotIdChange = (newValue: string) => {
    onChange({ ...value, lotId: newValue });
    saveToRecent('LotIds', newValue, setRecentLotIds);
  };

  const handleProcessStepChange = (newValue: string) => {
    onChange({ ...value, processStep: newValue });
    saveToRecent('ProcessSteps', newValue, setRecentProcessSteps);
  };

  const handleEquipmentIdChange = (newValue: string) => {
    onChange({ ...value, equipmentId: newValue });
    saveToRecent('EquipmentIds', newValue, setRecentEquipmentIds);
  };

  const handleCopyFromPrevious = () => {
    if (recentLotIds.length > 0) {
      onChange({
        lotId: recentLotIds[0],
        processStep: recentProcessSteps[0] || '',
        equipmentId: recentEquipmentIds[0] || '',
      });
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h6" sx={{ fontWeight: 600 }}>
          Wafer Metadata
        </Typography>
        {recentLotIds.length > 0 && (
          <Button
            size="small"
            startIcon={<ContentCopy />}
            onClick={handleCopyFromPrevious}
          >
            Copy Last
          </Button>
        )}
      </Box>

      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        {applyToAll && fileCount > 1
          ? `Metadata will be applied to all ${fileCount} files`
          : 'Optional information for processing'}
      </Typography>

      <Autocomplete
        freeSolo
        options={recentLotIds}
        value={value.lotId}
        onInputChange={(_, newValue) => handleLotIdChange(newValue)}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Lot ID"
            placeholder="e.g., LOT-2026-A001"
            sx={{ mb: 2 }}
          />
        )}
      />

      <Autocomplete
        freeSolo
        options={recentProcessSteps}
        value={value.processStep}
        onInputChange={(_, newValue) => handleProcessStepChange(newValue)}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Process Step"
            placeholder="e.g., Lithography"
            sx={{ mb: 2 }}
          />
        )}
      />

      <Autocomplete
        freeSolo
        options={recentEquipmentIds}
        value={value.equipmentId}
        onInputChange={(_, newValue) => handleEquipmentIdChange(newValue)}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Equipment ID"
            placeholder="e.g., LITHO-001"
            sx={{ mb: 2 }}
          />
        )}
      />

      {fileCount > 1 && (
        <FormControlLabel
          control={
            <Checkbox
              checked={applyToAll}
              onChange={(e) => setApplyToAll(e.target.checked)}
            />
          }
          label="Apply metadata to all files"
        />
      )}
    </Box>
  );
}
