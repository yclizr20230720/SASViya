import { useState, useEffect } from 'react';
import {
  Box,
  Drawer,
  Typography,
  IconButton,
  Button,
  Divider,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Chip,
  Stack,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  RadioGroup,
  FormControlLabel,
  Radio,
  Slider,
  Autocomplete,
} from '@mui/material';
import {
  Close as CloseIcon,
  ExpandMore as ExpandMoreIcon,
  FilterList as FilterIcon,
  Save as SaveIcon,
  Delete as DeleteIcon,
} from '@mui/icons-material';

export interface FilterCriteria {
  dateRange?: {
    start: string | null;
    end: string | null;
  };
  patternTypes?: string[];
  confidenceRange?: [number, number];
  equipment?: string[];
  processSteps?: string[];
  lots?: string[];
  waferIds?: string[];
  logicOperator?: 'AND' | 'OR';
}

export interface FilterPreset {
  id: string;
  name: string;
  criteria: FilterCriteria;
}

export interface AdvancedFilterPanelProps {
  open: boolean;
  onClose: () => void;
  onApplyFilters: (criteria: FilterCriteria) => void;
  onSavePreset?: (preset: FilterPreset) => void;
  onLoadPreset?: (preset: FilterPreset) => void;
  savedPresets?: FilterPreset[];
}

const patternTypeOptions = [
  'Center',
  'Edge-Ring',
  'Edge-Loc',
  'Loc',
  'Near-full',
  'Scratch',
  'Random',
  'None',
];

const equipmentOptions = [
  'EQP-001',
  'EQP-002',
  'EQP-003',
  'EQP-004',
  'EQP-005',
];

const processStepOptions = [
  'Lithography',
  'Etching',
  'Deposition',
  'Ion Implantation',
  'CMP',
  'Cleaning',
];

const AdvancedFilterPanel: React.FC<AdvancedFilterPanelProps> = ({
  open,
  onClose,
  onApplyFilters,
  onSavePreset,
  onLoadPreset,
  savedPresets = [],
}) => {
  const [filters, setFilters] = useState<FilterCriteria>({
    dateRange: { start: null, end: null },
    patternTypes: [],
    confidenceRange: [0, 100],
    equipment: [],
    processSteps: [],
    lots: [],
    waferIds: [],
    logicOperator: 'AND',
  });

  const [presetName, setPresetName] = useState('');
  const [showSavePreset, setShowSavePreset] = useState(false);

  // Load filters from localStorage on mount
  useEffect(() => {
    const savedFilters = localStorage.getItem('currentFilters');
    if (savedFilters) {
      const parsed = JSON.parse(savedFilters);
      setFilters(parsed);
    }
  }, []);

  // Save filters to localStorage
  const saveFiltersToStorage = (newFilters: FilterCriteria) => {
    localStorage.setItem('currentFilters', JSON.stringify(newFilters));
  };

  // Handle filter changes
  const handleFilterChange = (key: keyof FilterCriteria, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    saveFiltersToStorage(newFilters);
  };

  // Apply filters
  const handleApplyFilters = () => {
    onApplyFilters(filters);
    onClose();
  };

  // Reset filters
  const handleResetFilters = () => {
    const resetFilters: FilterCriteria = {
      dateRange: { start: null, end: null },
      patternTypes: [],
      confidenceRange: [0, 100],
      equipment: [],
      processSteps: [],
      lots: [],
      waferIds: [],
      logicOperator: 'AND',
    };
    setFilters(resetFilters);
    saveFiltersToStorage(resetFilters);
  };

  // Save preset
  const handleSavePreset = () => {
    if (!presetName.trim()) return;

    const preset: FilterPreset = {
      id: `preset-${Date.now()}`,
      name: presetName,
      criteria: filters,
    };

    onSavePreset?.(preset);
    setPresetName('');
    setShowSavePreset(false);

    // Save to localStorage
    const presets = JSON.parse(localStorage.getItem('filterPresets') || '[]');
    presets.push(preset);
    localStorage.setItem('filterPresets', JSON.stringify(presets));
  };

  // Load preset
  const handleLoadPreset = (preset: FilterPreset) => {
    setFilters(preset.criteria);
    saveFiltersToStorage(preset.criteria);
    onLoadPreset?.(preset);
  };

  // Delete preset
  const handleDeletePreset = (presetId: string) => {
    const presets = JSON.parse(localStorage.getItem('filterPresets') || '[]');
    const updated = presets.filter((p: FilterPreset) => p.id !== presetId);
    localStorage.setItem('filterPresets', JSON.stringify(updated));
  };

  // Get active filter count
  const getActiveFilterCount = () => {
    let count = 0;
    if (filters.dateRange?.start || filters.dateRange?.end) count++;
    if (filters.patternTypes && filters.patternTypes.length > 0) count++;
    if (filters.confidenceRange && (filters.confidenceRange[0] > 0 || filters.confidenceRange[1] < 100)) count++;
    if (filters.equipment && filters.equipment.length > 0) count++;
    if (filters.processSteps && filters.processSteps.length > 0) count++;
    if (filters.lots && filters.lots.length > 0) count++;
    if (filters.waferIds && filters.waferIds.length > 0) count++;
    return count;
  };

  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      sx={{
        '& .MuiDrawer-paper': {
          width: { xs: '100%', sm: 400 },
          p: 2,
        },
      }}
    >
      <Box>
        {/* Header */}
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <Box display="flex" alignItems="center" gap={1}>
            <FilterIcon />
            <Typography variant="h6">Advanced Filters</Typography>
            {getActiveFilterCount() > 0 && (
              <Chip label={`${getActiveFilterCount()} active`} size="small" color="primary" />
            )}
          </Box>
          <IconButton onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </Box>

        <Divider sx={{ mb: 2 }} />

        {/* Filter Logic Operator */}
        <Box mb={2}>
          <Typography variant="subtitle2" gutterBottom>
            Filter Logic
          </Typography>
          <RadioGroup
            row
            value={filters.logicOperator}
            onChange={(e) => handleFilterChange('logicOperator', e.target.value)}
          >
            <FormControlLabel value="AND" control={<Radio />} label="Match All (AND)" />
            <FormControlLabel value="OR" control={<Radio />} label="Match Any (OR)" />
          </RadioGroup>
        </Box>

        <Divider sx={{ mb: 2 }} />

        {/* Saved Presets */}
        {savedPresets.length > 0 && (
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography>Saved Presets</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Stack spacing={1}>
                {savedPresets.map((preset) => (
                  <Box key={preset.id} display="flex" justifyContent="space-between" alignItems="center">
                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => handleLoadPreset(preset)}
                      sx={{ flex: 1, mr: 1 }}
                    >
                      {preset.name}
                    </Button>
                    <IconButton size="small" onClick={() => handleDeletePreset(preset.id)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Box>
                ))}
              </Stack>
            </AccordionDetails>
          </Accordion>
        )}

        {/* Date Range Filter */}
        <Accordion defaultExpanded>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>Date Range</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Stack spacing={2}>
              <TextField
                label="Start Date"
                type="date"
                value={filters.dateRange?.start || ''}
                onChange={(e) =>
                  handleFilterChange('dateRange', { ...filters.dateRange, start: e.target.value })
                }
                size="small"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
              <TextField
                label="End Date"
                type="date"
                value={filters.dateRange?.end || ''}
                onChange={(e) =>
                  handleFilterChange('dateRange', { ...filters.dateRange, end: e.target.value })
                }
                size="small"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Stack>
          </AccordionDetails>
        </Accordion>

        {/* Pattern Type Filter */}
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>Pattern Types</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Autocomplete
              multiple
              options={patternTypeOptions}
              value={filters.patternTypes || []}
              onChange={(_, value) => handleFilterChange('patternTypes', value)}
              renderInput={(params) => (
                <TextField {...params} label="Select Patterns" size="small" />
              )}
              renderTags={(value, getTagProps) =>
                value.map((option, index) => (
                  <Chip label={option} size="small" {...getTagProps({ index })} />
                ))
              }
            />
          </AccordionDetails>
        </Accordion>

        {/* Confidence Range Filter */}
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>Confidence Range</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Box px={1}>
              <Typography variant="body2" gutterBottom>
                {filters.confidenceRange?.[0]}% - {filters.confidenceRange?.[1]}%
              </Typography>
              <Slider
                value={filters.confidenceRange || [0, 100]}
                onChange={(_, value) => handleFilterChange('confidenceRange', value)}
                valueLabelDisplay="auto"
                min={0}
                max={100}
              />
            </Box>
          </AccordionDetails>
        </Accordion>

        {/* Equipment Filter */}
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>Equipment</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Autocomplete
              multiple
              options={equipmentOptions}
              value={filters.equipment || []}
              onChange={(_, value) => handleFilterChange('equipment', value)}
              renderInput={(params) => (
                <TextField {...params} label="Select Equipment" size="small" />
              )}
              renderTags={(value, getTagProps) =>
                value.map((option, index) => (
                  <Chip label={option} size="small" {...getTagProps({ index })} />
                ))
              }
            />
          </AccordionDetails>
        </Accordion>

        {/* Process Step Filter */}
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>Process Steps</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Autocomplete
              multiple
              options={processStepOptions}
              value={filters.processSteps || []}
              onChange={(_, value) => handleFilterChange('processSteps', value)}
              renderInput={(params) => (
                <TextField {...params} label="Select Process Steps" size="small" />
              )}
              renderTags={(value, getTagProps) =>
                value.map((option, index) => (
                  <Chip label={option} size="small" {...getTagProps({ index })} />
                ))
              }
            />
          </AccordionDetails>
        </Accordion>

        {/* Lot Filter */}
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>Lot IDs</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <TextField
              fullWidth
              size="small"
              label="Enter Lot IDs (comma-separated)"
              value={filters.lots?.join(', ') || ''}
              onChange={(e) =>
                handleFilterChange(
                  'lots',
                  e.target.value.split(',').map((s) => s.trim()).filter(Boolean)
                )
              }
            />
          </AccordionDetails>
        </Accordion>

        {/* Wafer ID Filter */}
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography>Wafer IDs</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <TextField
              fullWidth
              size="small"
              label="Enter Wafer IDs (comma-separated)"
              value={filters.waferIds?.join(', ') || ''}
              onChange={(e) =>
                handleFilterChange(
                  'waferIds',
                  e.target.value.split(',').map((s) => s.trim()).filter(Boolean)
                )
              }
            />
          </AccordionDetails>
        </Accordion>

        {/* Save Preset Section */}
        {showSavePreset && (
          <Box mt={2} p={2} bgcolor="background.paper" borderRadius={1}>
            <TextField
              fullWidth
              size="small"
              label="Preset Name"
              value={presetName}
              onChange={(e) => setPresetName(e.target.value)}
              sx={{ mb: 1 }}
            />
            <Stack direction="row" spacing={1}>
              <Button
                variant="contained"
                size="small"
                startIcon={<SaveIcon />}
                onClick={handleSavePreset}
                disabled={!presetName.trim()}
              >
                Save
              </Button>
              <Button
                variant="outlined"
                size="small"
                onClick={() => {
                  setShowSavePreset(false);
                  setPresetName('');
                }}
              >
                Cancel
              </Button>
            </Stack>
          </Box>
        )}

        {/* Action Buttons */}
        <Box mt={3}>
          <Stack spacing={1}>
            <Button
              variant="contained"
              fullWidth
              onClick={handleApplyFilters}
              disabled={getActiveFilterCount() === 0}
            >
              Apply Filters ({getActiveFilterCount()})
            </Button>
            <Button
              variant="outlined"
              fullWidth
              startIcon={<SaveIcon />}
              onClick={() => setShowSavePreset(true)}
              disabled={getActiveFilterCount() === 0}
            >
              Save as Preset
            </Button>
            <Button variant="text" fullWidth onClick={handleResetFilters}>
              Reset All Filters
            </Button>
          </Stack>
        </Box>
      </Box>
    </Drawer>
  );
};

export default AdvancedFilterPanel;
