import { useEffect, useRef, useState } from 'react';
import { Box, IconButton, Tooltip, Slider, Typography, Popover, Paper } from '@mui/material';
import { ZoomIn, ZoomOut, RestartAlt } from '@mui/icons-material';

interface WaferMapCanvasProps {
  heatmap: number[][];
  size?: number;
  showHeatmap?: boolean;
  heatmapOpacity?: number;
  onDieClick?: (row: number, col: number) => void;
}

interface DieInfo {
  row: number;
  col: number;
  x: number;
  y: number;
  defectValue: number;
}

export default function WaferMapCanvas({
  heatmap,
  size = 500,
  showHeatmap = true,
  heatmapOpacity = 0.7,
  onDieClick,
}: WaferMapCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [opacity, setOpacity] = useState(heatmapOpacity);
  const [selectedDie, setSelectedDie] = useState<DieInfo | null>(null);
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [touchStartDistance, setTouchStartDistance] = useState<number | null>(null);

  useEffect(() => {
    drawWaferMap();
  }, [heatmap, zoom, pan, showHeatmap, opacity, selectedDie]);

  const drawWaferMap = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const gridSize = heatmap.length;
    const cellSize = (size / gridSize) * zoom;
    const centerX = size / 2 + pan.x;
    const centerY = size / 2 + pan.y;
    const radius = (size / 2 - 10) * zoom;

    // Clear canvas
    ctx.clearRect(0, 0, size, size);

    // Draw wafer circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
    ctx.fillStyle = '#f5f5f5';
    ctx.fill();
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw notch
    ctx.beginPath();
    ctx.arc(centerX, centerY - radius, 10 * zoom, 0, Math.PI);
    ctx.fillStyle = '#333';
    ctx.fill();

    // Draw die grid
    const startX = centerX - (gridSize * cellSize) / 2;
    const startY = centerY - (gridSize * cellSize) / 2;

    for (let i = 0; i < gridSize; i++) {
      for (let j = 0; j < gridSize; j++) {
        const x = startX + j * cellSize;
        const y = startY + i * cellSize;

        // Check if die is within wafer circle
        const dieX = x + cellSize / 2;
        const dieY = y + cellSize / 2;
        const distFromCenter = Math.sqrt(
          Math.pow(dieX - centerX, 2) + Math.pow(dieY - centerY, 2)
        );

        if (distFromCenter <= radius - cellSize / 2) {
          // Draw die
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(x, y, cellSize - 1, cellSize - 1);
          ctx.strokeStyle = '#ddd';
          ctx.strokeRect(x, y, cellSize - 1, cellSize - 1);

          // Highlight selected die
          if (selectedDie && selectedDie.row === i && selectedDie.col === j) {
            ctx.strokeStyle = '#0066CC';
            ctx.lineWidth = 3;
            ctx.strokeRect(x, y, cellSize - 1, cellSize - 1);
            ctx.lineWidth = 1;
          }

          // Draw heatmap overlay
          if (showHeatmap && heatmap[i][j] > 0) {
            const intensity = heatmap[i][j];
            const hue = (1 - intensity) * 240; // Blue to red
            ctx.fillStyle = `hsla(${hue}, 100%, 50%, ${opacity})`;
            ctx.fillRect(x, y, cellSize - 1, cellSize - 1);
          }
        }
      }
    }
  };

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 0.2, 3));
  };

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 0.2, 0.5));
  };

  const handleReset = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const gridSize = heatmap.length;
    const cellSize = (size / gridSize) * zoom;
    const centerX = size / 2 + pan.x;
    const centerY = size / 2 + pan.y;
    const startX = centerX - (gridSize * cellSize) / 2;
    const startY = centerY - (gridSize * cellSize) / 2;

    // Find clicked die
    for (let i = 0; i < gridSize; i++) {
      for (let j = 0; j < gridSize; j++) {
        const x = startX + j * cellSize;
        const y = startY + i * cellSize;

        if (
          clickX >= x &&
          clickX <= x + cellSize &&
          clickY >= y &&
          clickY <= y + cellSize
        ) {
          const dieInfo: DieInfo = {
            row: i,
            col: j,
            x: e.clientX,
            y: e.clientY,
            defectValue: heatmap[i][j],
          };
          setSelectedDie(dieInfo);
          setAnchorEl(canvas);
          if (onDieClick) {
            onDieClick(i, j);
          }
          return;
        }
      }
    }
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
    setSelectedDie(null);
  };

  // Touch gesture support
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const distance = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      setTouchStartDistance(distance);
    } else if (e.touches.length === 1) {
      setIsDragging(true);
      setDragStart({
        x: e.touches[0].clientX - pan.x,
        y: e.touches[0].clientY - pan.y,
      });
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && touchStartDistance) {
      const distance = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const scale = distance / touchStartDistance;
      setZoom((prev) => Math.max(0.5, Math.min(3, prev * scale)));
      setTouchStartDistance(distance);
    } else if (e.touches.length === 1 && isDragging) {
      setPan({
        x: e.touches[0].clientX - dragStart.x,
        y: e.touches[0].clientY - dragStart.y,
      });
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    setTouchStartDistance(null);
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', gap: 1, mb: 2, alignItems: 'center' }}>
        <Tooltip title="Zoom In">
          <IconButton onClick={handleZoomIn} size="small">
            <ZoomIn />
          </IconButton>
        </Tooltip>
        <Tooltip title="Zoom Out">
          <IconButton onClick={handleZoomOut} size="small">
            <ZoomOut />
          </IconButton>
        </Tooltip>
        <Tooltip title="Reset View">
          <IconButton onClick={handleReset} size="small">
            <RestartAlt />
          </IconButton>
        </Tooltip>
        <Box sx={{ flex: 1, ml: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
          <Typography variant="body2">Heatmap Opacity:</Typography>
          <Slider
            value={opacity}
            onChange={(_, value) => setOpacity(value as number)}
            min={0}
            max={1}
            step={0.1}
            sx={{ width: 150 }}
            size="small"
          />
        </Box>
      </Box>
      <Box
        sx={{
          border: 1,
          borderColor: 'divider',
          borderRadius: 1,
          overflow: 'hidden',
          cursor: isDragging ? 'grabbing' : 'grab',
        }}
      >
        <canvas
          ref={canvasRef}
          width={size}
          height={size}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onClick={handleCanvasClick}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        />
      </Box>

      {/* Die Info Popover */}
      <Popover
        open={Boolean(anchorEl) && selectedDie !== null}
        anchorEl={anchorEl}
        onClose={handlePopoverClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
      >
        {selectedDie && (
          <Paper sx={{ p: 2, minWidth: 200 }}>
            <Typography variant="subtitle2" gutterBottom>
              Die Information
            </Typography>
            <Typography variant="body2">
              <strong>Position:</strong> ({selectedDie.row}, {selectedDie.col})
            </Typography>
            <Typography variant="body2">
              <strong>Defect Value:</strong> {selectedDie.defectValue.toFixed(3)}
            </Typography>
            <Typography variant="body2">
              <strong>Status:</strong>{' '}
              {selectedDie.defectValue > 0.5 ? 'High Defect' : 'Normal'}
            </Typography>
          </Paper>
        )}
      </Popover>
    </Box>
  );
}
