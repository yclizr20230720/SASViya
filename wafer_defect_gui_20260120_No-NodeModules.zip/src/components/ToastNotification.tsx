import { Snackbar, Alert, AlertTitle, IconButton, Slide, SlideProps } from '@mui/material';
import { Close as CloseIcon } from '@mui/icons-material';

export interface Toast {
  id: string;
  type: 'error' | 'warning' | 'info' | 'success';
  title?: string;
  message: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

interface ToastNotificationProps {
  toast: Toast | null;
  onClose: () => void;
}

function SlideTransition(props: SlideProps) {
  return <Slide {...props} direction="down" />;
}

const ToastNotification: React.FC<ToastNotificationProps> = ({ toast, onClose }) => {
  if (!toast) return null;

  return (
    <Snackbar
      open={!!toast}
      autoHideDuration={toast.duration || 6000}
      onClose={onClose}
      anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      TransitionComponent={SlideTransition}
      sx={{ mt: 8 }}
    >
      <Alert
        severity={toast.type}
        variant="filled"
        onClose={onClose}
        action={
          <>
            {toast.action && (
              <IconButton
                size="small"
                color="inherit"
                onClick={() => {
                  toast.action?.onClick();
                  onClose();
                }}
                sx={{ mr: 1 }}
              >
                {toast.action.label}
              </IconButton>
            )}
            <IconButton size="small" color="inherit" onClick={onClose}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </>
        }
        sx={{ minWidth: 300, maxWidth: 500 }}
      >
        {toast.title && <AlertTitle>{toast.title}</AlertTitle>}
        {toast.message}
      </Alert>
    </Snackbar>
  );
};

export default ToastNotification;
