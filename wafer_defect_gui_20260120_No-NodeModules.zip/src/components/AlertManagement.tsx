import { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  IconButton,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  Divider,
  Alert as MuiAlert,
} from '@mui/material';
import {
  Error as ErrorIcon,
  Warning as WarningIcon,
  CheckCircle as ResolvedIcon,
  Visibility as ViewIcon,
  Check as AcknowledgeIcon,
  Close as CloseIcon,
  FilterList as FilterIcon,
} from '@mui/icons-material';

export interface Alert {
  id: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  type: 'defect_rate' | 'confidence' | 'equipment' | 'pattern' | 'system';
  title: string;
  description: string;
  timestamp: string;
  status: 'active' | 'acknowledged' | 'resolved';
  acknowledgedBy?: string;
  acknowledgedAt?: string;
  resolvedBy?: string;
  resolvedAt?: string;
  resolution?: string;
  affectedItems?: string[];
}

interface AlertManagementProps {
  alerts: Alert[];
  onAcknowledge: (id: string) => void;
  onResolve: (id: string, resolution: string) => void;
}

const AlertManagement: React.FC<AlertManagementProps> = ({
  alerts,
  onAcknowledge,
  onResolve,
}) => {
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [resolutionText, setResolutionText] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'acknowledged' | 'resolved'>('all');
  const [filterSeverity, setFilterSeverity] = useState<'all' | 'critical' | 'high' | 'medium' | 'low'>('all');

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'error';
      case 'high':
        return 'warning';
      case 'medium':
        return 'info';
      default:
        return 'default';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'error';
      case 'acknowledged':
        return 'warning';
      case 'resolved':
        return 'success';
      default:
        return 'default';
    }
  };

  const getIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
      case 'high':
        return <ErrorIcon color="error" />;
      case 'medium':
        return <WarningIcon color="warning" />;
      default:
        return <WarningIcon color="info" />;
    }
  };

  const filteredAlerts = alerts.filter((alert) => {
    if (filterStatus !== 'all' && alert.status !== filterStatus) return false;
    if (filterSeverity !== 'all' && alert.severity !== filterSeverity) return false;
    return true;
  });

  const activeCount = alerts.filter((a) => a.status === 'active').length;
  const acknowledgedCount = alerts.filter((a) => a.status === 'acknowledged').length;
  const criticalCount = alerts.filter((a) => a.severity === 'critical' && a.status === 'active').length;

  const handleResolve = () => {
    if (selectedAlert && resolutionText.trim()) {
      onResolve(selectedAlert.id, resolutionText);
      setSelectedAlert(null);
      setResolutionText('');
    }
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h5" fontWeight={600}>
          Alert Management
        </Typography>
        <Box display="flex" gap={1}>
          <Chip
            label={`${criticalCount} Critical`}
            color="error"
            size="small"
            variant={criticalCount > 0 ? 'filled' : 'outlined'}
          />
          <Chip
            label={`${activeCount} Active`}
            color="warning"
            size="small"
            variant={activeCount > 0 ? 'filled' : 'outlined'}
          />
          <Chip
            label={`${acknowledgedCount} Acknowledged`}
            color="info"
            size="small"
          />
        </Box>
      </Box>

      {/* Summary Cards */}
      <Grid container spacing={2} mb={3}>
        <Grid size={{ xs: 12, md: 3 }}>
          <Card sx={{ bgcolor: 'error.light', color: 'error.contrastText' }}>
            <CardContent>
              <Typography variant="h4" fontWeight={600}>
                {criticalCount}
              </Typography>
              <Typography variant="body2">Critical Alerts</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, md: 3 }}>
          <Card sx={{ bgcolor: 'warning.light', color: 'warning.contrastText' }}>
            <CardContent>
              <Typography variant="h4" fontWeight={600}>
                {activeCount}
              </Typography>
              <Typography variant="body2">Active Alerts</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, md: 3 }}>
          <Card sx={{ bgcolor: 'info.light', color: 'info.contrastText' }}>
            <CardContent>
              <Typography variant="h4" fontWeight={600}>
                {acknowledgedCount}
              </Typography>
              <Typography variant="body2">Acknowledged</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, md: 3 }}>
          <Card sx={{ bgcolor: 'success.light', color: 'success.contrastText' }}>
            <CardContent>
              <Typography variant="h4" fontWeight={600}>
                {alerts.filter((a) => a.status === 'resolved').length}
              </Typography>
              <Typography variant="body2">Resolved</Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Filters */}
      <Card sx={{ mb: 2 }}>
        <CardContent>
          <Box display="flex" alignItems="center" gap={2}>
            <FilterIcon color="action" />
            <Typography variant="subtitle2" fontWeight={600}>
              Filters:
            </Typography>
            <Box display="flex" gap={1} flexWrap="wrap">
              <Chip
                label="All Status"
                onClick={() => setFilterStatus('all')}
                color={filterStatus === 'all' ? 'primary' : 'default'}
                size="small"
              />
              <Chip
                label="Active"
                onClick={() => setFilterStatus('active')}
                color={filterStatus === 'active' ? 'primary' : 'default'}
                size="small"
              />
              <Chip
                label="Acknowledged"
                onClick={() => setFilterStatus('acknowledged')}
                color={filterStatus === 'acknowledged' ? 'primary' : 'default'}
                size="small"
              />
              <Chip
                label="Resolved"
                onClick={() => setFilterStatus('resolved')}
                color={filterStatus === 'resolved' ? 'primary' : 'default'}
                size="small"
              />
            </Box>
            <Divider orientation="vertical" flexItem />
            <Box display="flex" gap={1} flexWrap="wrap">
              <Chip
                label="All Severity"
                onClick={() => setFilterSeverity('all')}
                color={filterSeverity === 'all' ? 'primary' : 'default'}
                size="small"
              />
              <Chip
                label="Critical"
                onClick={() => setFilterSeverity('critical')}
                color={filterSeverity === 'critical' ? 'primary' : 'default'}
                size="small"
              />
              <Chip
                label="High"
                onClick={() => setFilterSeverity('high')}
                color={filterSeverity === 'high' ? 'primary' : 'default'}
                size="small"
              />
              <Chip
                label="Medium"
                onClick={() => setFilterSeverity('medium')}
                color={filterSeverity === 'medium' ? 'primary' : 'default'}
                size="small"
              />
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* Alert List */}
      <Card>
        <List>
          {filteredAlerts.length === 0 ? (
            <Box sx={{ p: 4, textAlign: 'center' }}>
              <ResolvedIcon sx={{ fontSize: 48, color: 'success.main', mb: 1 }} />
              <Typography variant="body1" color="text.secondary">
                No alerts match the current filters
              </Typography>
            </Box>
          ) : (
            filteredAlerts.map((alert, index) => (
              <Box key={alert.id}>
                {index > 0 && <Divider />}
                <ListItem
                  sx={{
                    py: 2,
                    '&:hover': {
                      bgcolor: 'action.hover',
                    },
                  }}
                >
                  <ListItemIcon>{getIcon(alert.severity)}</ListItemIcon>
                  <ListItemText
                    primary={
                      <Box display="flex" alignItems="center" gap={1} mb={0.5}>
                        <Typography variant="subtitle1" fontWeight={600}>
                          {alert.title}
                        </Typography>
                        <Chip
                          label={alert.severity.toUpperCase()}
                          color={getSeverityColor(alert.severity) as any}
                          size="small"
                        />
                        <Chip
                          label={alert.status.toUpperCase()}
                          color={getStatusColor(alert.status) as any}
                          size="small"
                          variant="outlined"
                        />
                        <Chip label={alert.type.replace('_', ' ')} size="small" variant="outlined" />
                      </Box>
                    }
                    secondary={
                      <Box>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                          {alert.description}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {new Date(alert.timestamp).toLocaleString()}
                        </Typography>
                        {alert.affectedItems && alert.affectedItems.length > 0 && (
                          <Box mt={1}>
                            <Typography variant="caption" color="text.secondary">
                              Affected: {alert.affectedItems.join(', ')}
                            </Typography>
                          </Box>
                        )}
                      </Box>
                    }
                  />
                  <Box display="flex" gap={1}>
                    <IconButton
                      size="small"
                      onClick={() => setSelectedAlert(alert)}
                      title="View details"
                    >
                      <ViewIcon fontSize="small" />
                    </IconButton>
                    {alert.status === 'active' && (
                      <Button
                        size="small"
                        startIcon={<AcknowledgeIcon />}
                        onClick={() => onAcknowledge(alert.id)}
                        variant="outlined"
                      >
                        Acknowledge
                      </Button>
                    )}
                    {alert.status === 'acknowledged' && (
                      <Button
                        size="small"
                        startIcon={<ResolvedIcon />}
                        onClick={() => setSelectedAlert(alert)}
                        variant="contained"
                        color="success"
                      >
                        Resolve
                      </Button>
                    )}
                  </Box>
                </ListItem>
              </Box>
            ))
          )}
        </List>
      </Card>

      {/* Alert Detail Dialog */}
      <Dialog
        open={!!selectedAlert}
        onClose={() => setSelectedAlert(null)}
        maxWidth="md"
        fullWidth
      >
        {selectedAlert && (
          <>
            <DialogTitle>
              <Box display="flex" justifyContent="space-between" alignItems="center">
                <Box display="flex" alignItems="center" gap={1}>
                  {getIcon(selectedAlert.severity)}
                  <Typography variant="h6">{selectedAlert.title}</Typography>
                </Box>
                <IconButton onClick={() => setSelectedAlert(null)}>
                  <CloseIcon />
                </IconButton>
              </Box>
            </DialogTitle>
            <DialogContent>
              <Box mb={2}>
                <Box display="flex" gap={1} mb={2}>
                  <Chip
                    label={selectedAlert.severity.toUpperCase()}
                    color={getSeverityColor(selectedAlert.severity) as any}
                    size="small"
                  />
                  <Chip
                    label={selectedAlert.status.toUpperCase()}
                    color={getStatusColor(selectedAlert.status) as any}
                    size="small"
                  />
                  <Chip label={selectedAlert.type.replace('_', ' ')} size="small" variant="outlined" />
                </Box>

                <Typography variant="body1" paragraph>
                  {selectedAlert.description}
                </Typography>

                <Typography variant="caption" color="text.secondary" display="block" mb={2}>
                  Triggered: {new Date(selectedAlert.timestamp).toLocaleString()}
                </Typography>

                {selectedAlert.affectedItems && selectedAlert.affectedItems.length > 0 && (
                  <MuiAlert severity="info" sx={{ mb: 2 }}>
                    <Typography variant="body2" fontWeight={600} gutterBottom>
                      Affected Items:
                    </Typography>
                    <Typography variant="body2">
                      {selectedAlert.affectedItems.join(', ')}
                    </Typography>
                  </MuiAlert>
                )}

                {selectedAlert.status === 'acknowledged' && (
                  <MuiAlert severity="warning" sx={{ mb: 2 }}>
                    <Typography variant="body2">
                      Acknowledged by {selectedAlert.acknowledgedBy} at{' '}
                      {selectedAlert.acknowledgedAt && new Date(selectedAlert.acknowledgedAt).toLocaleString()}
                    </Typography>
                  </MuiAlert>
                )}

                {selectedAlert.status === 'resolved' && (
                  <MuiAlert severity="success" sx={{ mb: 2 }}>
                    <Typography variant="body2" fontWeight={600} gutterBottom>
                      Resolved by {selectedAlert.resolvedBy}
                    </Typography>
                    <Typography variant="body2">
                      {selectedAlert.resolvedAt && new Date(selectedAlert.resolvedAt).toLocaleString()}
                    </Typography>
                    {selectedAlert.resolution && (
                      <Typography variant="body2" sx={{ mt: 1 }}>
                        Resolution: {selectedAlert.resolution}
                      </Typography>
                    )}
                  </MuiAlert>
                )}

                {selectedAlert.status === 'acknowledged' && (
                  <TextField
                    fullWidth
                    multiline
                    rows={4}
                    label="Resolution Notes"
                    placeholder="Describe how this alert was resolved..."
                    value={resolutionText}
                    onChange={(e) => setResolutionText(e.target.value)}
                    sx={{ mt: 2 }}
                  />
                )}
              </Box>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setSelectedAlert(null)}>Close</Button>
              {selectedAlert.status === 'active' && (
                <Button
                  variant="outlined"
                  startIcon={<AcknowledgeIcon />}
                  onClick={() => {
                    onAcknowledge(selectedAlert.id);
                    setSelectedAlert(null);
                  }}
                >
                  Acknowledge
                </Button>
              )}
              {selectedAlert.status === 'acknowledged' && (
                <Button
                  variant="contained"
                  color="success"
                  startIcon={<ResolvedIcon />}
                  onClick={handleResolve}
                  disabled={!resolutionText.trim()}
                >
                  Resolve Alert
                </Button>
              )}
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
};

export default AlertManagement;
