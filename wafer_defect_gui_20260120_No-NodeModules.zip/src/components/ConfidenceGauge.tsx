import { Box, Typography } from '@mui/material';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

interface ConfidenceGaugeProps {
  value: number; // 0-1
  label: string;
  size?: number;
}

export default function ConfidenceGauge({ value, label, size = 200 }: ConfidenceGaugeProps) {
  const percentage = value * 100;
  
  const getColor = () => {
    if (percentage >= 90) return '#388E3C'; // High - Green
    if (percentage >= 70) return '#F57C00'; // Medium - Orange
    return '#D32F2F'; // Low - Red
  };

  const getLabel = () => {
    if (percentage >= 90) return 'High Confidence';
    if (percentage >= 70) return 'Medium Confidence';
    return 'Low Confidence';
  };

  const data = [
    { name: 'Confidence', value: percentage },
    { name: 'Remaining', value: 100 - percentage },
  ];

  const COLORS = [getColor(), '#E0E0E0'];

  return (
    <Box sx={{ textAlign: 'center' }}>
      <ResponsiveContainer width={size} height={size}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            startAngle={180}
            endAngle={0}
            innerRadius="70%"
            outerRadius="90%"
            dataKey="value"
            stroke="none"
          >
            {data.map((_entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index]} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <Box sx={{ mt: -8 }}>
        <Typography variant="h3" sx={{ fontWeight: 600, color: getColor() }}>
          {percentage.toFixed(1)}%
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {label}
        </Typography>
        <Typography variant="caption" sx={{ color: getColor(), fontWeight: 600 }}>
          {getLabel()}
        </Typography>
      </Box>
    </Box>
  );
}
