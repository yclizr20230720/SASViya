/**
 * Synthetic Generation Component
 * 
 * Allows users to generate synthetic wafer maps using trained GAN models
 */
import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Grid,
  LinearProgress,
  Alert,
  Chip,
  Paper,
  Divider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Slider
} from '@mui/material';
import { AutoAwesome, Refresh } from '@mui/icons-material';
import { ganService } from '../../services/ganService';

interface GANModel {
  name: string;
  path: string;
  size_mb: number;
  created_at: string;
}

const PATTERN_CLASSES = [
  'Center',
  'Donut',
  'Edge-Loc',
  'Edge-Ring',
  'Loc',
  'Near-full',
  'Random',
  'Scratch',
  'none'
];

const SyntheticGeneration: React.FC = () => {
  // Configuration
  const [numSamples, setNumSamples] = useState(100);
  const [selectedPattern, setSelectedPattern] = useState<string>('');
  const [defectDensity, setDefectDensity] = useState<number>(0.5);
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [outputDir, setOutputDir] = useState('data/synthetic');

  // State
  const [models, setModels] = useState<GANModel[]>([]);
  const [generating, setGenerating] = useState(false);
  const [jobId, setJobId] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [generatedFiles, setGeneratedFiles] = useState<string[]>([]);

  // Load available models
  useEffect(() => {
    loadModels();
  }, []);

  const loadModels = async () => {
    try {
      const response = await ganService.listModels();
      setModels(response.models);
      
      // Auto-select the most recent model
      if (response.models.length > 0) {
        setSelectedModel(response.models[0].path);
      }
    } catch (err) {
      console.error('Failed to load GAN models:', err);
    }
  };

  // Start generation
  const handleGenerate = async () => {
    try {
      setError(null);
      setGenerating(true);
      setProgress(0);
      setGeneratedFiles([]);

      const config: any = {
        num_samples: numSamples,
        checkpoint: selectedModel,
        output_dir: outputDir
      };

      if (selectedPattern) {
        config.pattern = selectedPattern;
      }

      if (selectedPattern) {
        config.defect_density = defectDensity;
      }

      const response = await ganService.generateSynthetic(config);
      setJobId(response.job_id);

      // Start polling for progress
      pollProgress(response.job_id);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start generation');
      setGenerating(false);
    }
  };

  // Poll generation progress
  const pollProgress = async (jobId: string) => {
    const interval = setInterval(async () => {
      try {
        const response = await ganService.getStatus(jobId);
        const job = response.job;

        setProgress(job.progress);

        if (job.status === 'completed') {
          clearInterval(interval);
          setGenerating(false);
          setProgress(100);
          setGeneratedFiles(job.generated_files || []);
        } else if (job.status === 'failed') {
          clearInterval(interval);
          setGenerating(false);
          setError(job.error || 'Generation failed');
        }
      } catch (err) {
        console.error('Failed to fetch generation status:', err);
      }
    }, 2000);

    return () => clearInterval(interval);
  };

  return (
    <Box>
      <Typography variant="h5" fontWeight={600} gutterBottom>
        Synthetic Data Generation
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Generate synthetic wafer maps using trained GAN models
      </Typography>

      <Grid container spacing={3}>
        {/* Configuration Panel */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">
                  Generation Configuration
                </Typography>
                <Button
                  size="small"
                  startIcon={<Refresh />}
                  onClick={loadModels}
                  disabled={generating}
                >
                  Refresh Models
                </Button>
              </Box>
              <Divider sx={{ mb: 2 }} />

              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <FormControl fullWidth disabled={generating || models.length === 0}>
                    <InputLabel>GAN Model</InputLabel>
                    <Select
                      value={selectedModel}
                      label="GAN Model"
                      onChange={(e) => setSelectedModel(e.target.value)}
                    >
                      {models.map((model) => (
                        <MenuItem key={model.path} value={model.path}>
                          {model.name} ({model.size_mb.toFixed(1)} MB)
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  {models.length === 0 && (
                    <Alert severity="warning" sx={{ mt: 1 }}>
                      No GAN models found. Please train a GAN model first.
                    </Alert>
                  )}
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Number of Samples"
                    type="number"
                    value={numSamples}
                    onChange={(e) => setNumSamples(parseInt(e.target.value))}
                    disabled={generating}
                    helperText="Number of synthetic wafer maps to generate"
                  />
                </Grid>

                <Grid item xs={12}>
                  <FormControl fullWidth disabled={generating}>
                    <InputLabel>Pattern Type (Optional)</InputLabel>
                    <Select
                      value={selectedPattern}
                      label="Pattern Type (Optional)"
                      onChange={(e) => setSelectedPattern(e.target.value)}
                    >
                      <MenuItem value="">
                        <em>All Patterns (Balanced)</em>
                      </MenuItem>
                      {PATTERN_CLASSES.map((pattern) => (
                        <MenuItem key={pattern} value={pattern}>
                          {pattern}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>

                {selectedPattern && (
                  <Grid item xs={12}>
                    <Typography variant="body2" gutterBottom>
                      Defect Density: {defectDensity.toFixed(2)}
                    </Typography>
                    <Slider
                      value={defectDensity}
                      onChange={(_, value) => setDefectDensity(value as number)}
                      min={0}
                      max={1}
                      step={0.05}
                      marks={[
                        { value: 0, label: 'Low' },
                        { value: 0.5, label: 'Medium' },
                        { value: 1, label: 'High' }
                      ]}
                      disabled={generating}
                    />
                  </Grid>
                )}

                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Output Directory"
                    value={outputDir}
                    onChange={(e) => setOutputDir(e.target.value)}
                    disabled={generating}
                  />
                </Grid>

                <Grid item xs={12}>
                  <Button
                    fullWidth
                    variant="contained"
                    size="large"
                    startIcon={<AutoAwesome />}
                    onClick={handleGenerate}
                    disabled={generating || !selectedModel}
                    color="secondary"
                  >
                    {generating ? 'Generating...' : 'Generate Synthetic Data'}
                  </Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* Progress Panel */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Generation Progress
              </Typography>
              <Divider sx={{ mb: 2 }} />

              {!generating && !jobId && (
                <Alert severity="info">
                  Select a GAN model and configure generation parameters to begin
                </Alert>
              )}

              {error && (
                <Alert severity="error" sx={{ mb: 2 }}>
                  {error}
                </Alert>
              )}

              {generating && (
                <Box>
                  <Box sx={{ mb: 3 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                      <Typography variant="body2" color="text.secondary">
                        Generating {numSamples} samples...
                      </Typography>
                      <Typography variant="body2" fontWeight={600}>
                        {progress.toFixed(0)}%
                      </Typography>
                    </Box>
                    <LinearProgress
                      variant="determinate"
                      value={progress}
                      sx={{ height: 8, borderRadius: 4 }}
                      color="secondary"
                    />
                  </Box>

                  <Alert severity="info">
                    Generation typically takes 1-2 minutes per 100 samples
                  </Alert>
                </Box>
              )}

              {!generating && jobId && progress === 100 && (
                <Box>
                  <Alert severity="success" sx={{ mb: 2 }}>
                    Successfully generated {generatedFiles.length} synthetic wafer maps!
                  </Alert>

                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Generation Summary
                    </Typography>
                    <Grid container spacing={1}>
                      <Grid item xs={6}>
                        <Typography variant="caption" color="text.secondary">
                          Samples Generated
                        </Typography>
                        <Typography variant="h6">
                          {generatedFiles.length}
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" color="text.secondary">
                          Output Directory
                        </Typography>
                        <Typography variant="body2" sx={{ wordBreak: 'break-all' }}>
                          {outputDir}
                        </Typography>
                      </Grid>
                    </Grid>
                  </Paper>
                </Box>
              )}
            </CardContent>
          </Card>

          {/* Available Models */}
          {models.length > 0 && (
            <Card sx={{ mt: 2 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Available GAN Models
                </Typography>
                <Divider sx={{ mb: 2 }} />

                {models.map((model) => (
                  <Paper
                    key={model.path}
                    variant="outlined"
                    sx={{
                      p: 2,
                      mb: 1,
                      bgcolor: selectedModel === model.path ? 'action.selected' : 'transparent'
                    }}
                  >
                    <Typography variant="body2" fontWeight={600}>
                      {model.name}
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                      <Chip label={`${model.size_mb.toFixed(1)} MB`} size="small" />
                      <Chip
                        label={new Date(model.created_at).toLocaleDateString()}
                        size="small"
                        variant="outlined"
                      />
                    </Box>
                  </Paper>
                ))}
              </CardContent>
            </Card>
          )}
        </Grid>

        {/* Prerequisites Alert */}
        <Grid item xs={12}>
          <Alert severity="info">
            <Typography variant="subtitle2" gutterBottom>
              📋 Prerequisites for Synthetic Generation
            </Typography>
            <Typography variant="body2">
              Before generating synthetic data, ensure you have:
            </Typography>
            <Box component="ul" sx={{ mt: 1, mb: 0, pl: 2 }}>
              <Typography component="li" variant="body2">
                ✅ Completed GAN training (trained model checkpoint available)
              </Typography>
              <Typography component="li" variant="body2">
                ✅ At least one GAN model in the models list below
              </Typography>
              <Typography component="li" variant="body2">
                💡 Recommended: 30% synthetic + 70% real data for best results
              </Typography>
            </Box>
          </Alert>
        </Grid>

        {/* Information Panel */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                About Synthetic Generation
              </Typography>
              <Divider sx={{ mb: 2 }} />
              
              <Typography variant="body2" paragraph>
                Generate synthetic wafer maps to augment your training dataset. Synthetic data helps
                balance class distributions and improve model performance on rare defect patterns.
              </Typography>

              <Typography variant="subtitle2" gutterBottom>
                Generation Options:
              </Typography>
              <Box component="ul" sx={{ mt: 1, pl: 2 }}>
                <Typography component="li" variant="body2">
                  <strong>All Patterns:</strong> Generates balanced samples across all pattern types
                </Typography>
                <Typography component="li" variant="body2">
                  <strong>Specific Pattern:</strong> Generates samples for a single pattern type
                </Typography>
                <Typography component="li" variant="body2">
                  <strong>Defect Density:</strong> Controls the severity of defects (0.0 = minimal, 1.0 = severe)
                </Typography>
              </Box>

              <Typography variant="subtitle2" gutterBottom sx={{ mt: 2 }}>
                Recommended Usage:
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 1 }}>
                <Chip label="30% synthetic, 70% real data" size="small" color="primary" />
                <Chip label="Balance rare patterns" size="small" />
                <Chip label="Validate quality before training" size="small" />
              </Box>

              <Typography variant="subtitle2" gutterBottom sx={{ mt: 2 }}>
                Quality Targets:
              </Typography>
              <Box component="ul" sx={{ mt: 1, pl: 2 }}>
                <Typography component="li" variant="body2">
                  <strong>FID Score:</strong> {'<'} 50 (lower is better)
                </Typography>
                <Typography component="li" variant="body2">
                  <strong>Classifier Confidence:</strong> {'>'} 0.7 (higher is better)
                </Typography>
                <Typography component="li" variant="body2">
                  <strong>Visual Quality:</strong> Realistic patterns matching real wafer maps
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default SyntheticGeneration;
