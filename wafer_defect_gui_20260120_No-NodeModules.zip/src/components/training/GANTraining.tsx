/**
 * GAN Training Component
 * 
 * Allows users to train GAN models for synthetic data generation
 */
import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Grid,
  LinearProgress,
  Alert,
  Chip,
  Paper,
  Divider,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import { PlayArrow, Stop } from '@mui/icons-material';
import { ganService } from '../../services/ganService';

interface GANMetrics {
  d_loss: number;
  g_loss: number;
  gp: number;
  w_dist: number;
}

const GANTraining: React.FC = () => {
  // Training configuration
  const [epochs, setEpochs] = useState(100);
  const [batchSize, setBatchSize] = useState(32);
  const [nCritic, setNCritic] = useState(5);
  const [lambdaGp, setLambdaGp] = useState(10.0);
  const [learningRate, setLearningRate] = useState(0.0001);
  const [dataSplit, setDataSplit] = useState('all');

  // Training state
  const [training, setTraining] = useState(false);
  const [jobId, setJobId] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [currentEpoch, setCurrentEpoch] = useState(0);
  const [metrics, setMetrics] = useState<GANMetrics | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [estimatedTime, setEstimatedTime] = useState<number | null>(null);

  // Start training
  const handleStartTraining = async () => {
    try {
      setError(null);
      setTraining(true);
      setProgress(0);
      setCurrentEpoch(0);
      setMetrics(null);

      const response = await ganService.startTraining({
        epochs,
        batch_size: batchSize,
        n_critic: nCritic,
        lambda_gp: lambdaGp,
        learning_rate: learningRate,
        data_split: dataSplit
      });

      setJobId(response.job_id);
      setEstimatedTime(response.estimated_duration_minutes);

      // Start polling for progress
      pollProgress(response.job_id);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start training');
      setTraining(false);
    }
  };

  // Poll training progress
  const pollProgress = async (jobId: string) => {
    const interval = setInterval(async () => {
      try {
        const response = await ganService.getStatus(jobId);
        const job = response.job;

        setProgress(job.progress);
        setCurrentEpoch(job.current_epoch || 0);
        
        if (job.metrics) {
          setMetrics(job.metrics);
        }

        if (job.status === 'completed') {
          clearInterval(interval);
          setTraining(false);
          setProgress(100);
        } else if (job.status === 'failed') {
          clearInterval(interval);
          setTraining(false);
          setError(job.error || 'Training failed');
        }
      } catch (err) {
        console.error('Failed to fetch training status:', err);
      }
    }, 3000);

    return () => clearInterval(interval);
  };

  return (
    <Box>
      <Typography variant="h5" fontWeight={600} gutterBottom>
        GAN Training
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Train a Generative Adversarial Network to generate synthetic wafer maps for data augmentation
      </Typography>

      <Grid container spacing={3}>
        {/* Configuration Panel */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Training Configuration
              </Typography>
              <Divider sx={{ mb: 2 }} />

              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Epochs"
                    type="number"
                    value={epochs}
                    onChange={(e) => setEpochs(parseInt(e.target.value))}
                    disabled={training}
                    helperText="Number of training epochs (recommended: 100-200)"
                  />
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label="Batch Size"
                    type="number"
                    value={batchSize}
                    onChange={(e) => setBatchSize(parseInt(e.target.value))}
                    disabled={training}
                  />
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label="Critic Iterations"
                    type="number"
                    value={nCritic}
                    onChange={(e) => setNCritic(parseInt(e.target.value))}
                    disabled={training}
                  />
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label="Gradient Penalty (λ)"
                    type="number"
                    value={lambdaGp}
                    onChange={(e) => setLambdaGp(parseFloat(e.target.value))}
                    disabled={training}
                  />
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label="Learning Rate"
                    type="number"
                    value={learningRate}
                    onChange={(e) => setLearningRate(parseFloat(e.target.value))}
                    disabled={training}
                    inputProps={{ step: 0.00001 }}
                  />
                </Grid>

                <Grid item xs={12}>
                  <FormControl fullWidth disabled={training}>
                    <InputLabel>Data Split</InputLabel>
                    <Select
                      value={dataSplit}
                      label="Data Split"
                      onChange={(e) => setDataSplit(e.target.value)}
                    >
                      <MenuItem value="all">All Data (Train + Val)</MenuItem>
                      <MenuItem value="train">Training Data Only</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={12}>
                  <Button
                    fullWidth
                    variant="contained"
                    size="large"
                    startIcon={training ? <Stop /> : <PlayArrow />}
                    onClick={handleStartTraining}
                    disabled={training}
                    color={training ? 'error' : 'primary'}
                  >
                    {training ? 'Training...' : 'Start GAN Training'}
                  </Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* Progress Panel */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Training Progress
              </Typography>
              <Divider sx={{ mb: 2 }} />

              {!training && !jobId && (
                <Alert severity="info">
                  Configure training parameters and click "Start GAN Training" to begin
                </Alert>
              )}

              {error && (
                <Alert severity="error" sx={{ mb: 2 }}>
                  {error}
                </Alert>
              )}

              {training && (
                <Box>
                  {/* Progress Bar */}
                  <Box sx={{ mb: 3 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                      <Typography variant="body2" color="text.secondary">
                        Epoch {currentEpoch} / {epochs}
                      </Typography>
                      <Typography variant="body2" fontWeight={600}>
                        {progress.toFixed(0)}%
                      </Typography>
                    </Box>
                    <LinearProgress
                      variant="determinate"
                      value={progress}
                      sx={{ height: 8, borderRadius: 4 }}
                    />
                  </Box>

                  {/* Estimated Time */}
                  {estimatedTime && (
                    <Alert severity="info" sx={{ mb: 2 }}>
                      Estimated time: ~{estimatedTime} minutes
                    </Alert>
                  )}

                  {/* Current Metrics */}
                  {metrics && (
                    <Box>
                      <Typography variant="subtitle2" gutterBottom>
                        Current Metrics
                      </Typography>
                      <Grid container spacing={2}>
                        <Grid item xs={6}>
                          <Paper variant="outlined" sx={{ p: 2 }}>
                            <Typography variant="caption" color="text.secondary">
                              Discriminator Loss
                            </Typography>
                            <Typography variant="h6">
                              {metrics.d_loss.toFixed(4)}
                            </Typography>
                          </Paper>
                        </Grid>
                        <Grid item xs={6}>
                          <Paper variant="outlined" sx={{ p: 2 }}>
                            <Typography variant="caption" color="text.secondary">
                              Generator Loss
                            </Typography>
                            <Typography variant="h6">
                              {metrics.g_loss.toFixed(4)}
                            </Typography>
                          </Paper>
                        </Grid>
                        <Grid item xs={6}>
                          <Paper variant="outlined" sx={{ p: 2 }}>
                            <Typography variant="caption" color="text.secondary">
                              Gradient Penalty
                            </Typography>
                            <Typography variant="h6">
                              {metrics.gp.toFixed(4)}
                            </Typography>
                          </Paper>
                        </Grid>
                        <Grid item xs={6}>
                          <Paper variant="outlined" sx={{ p: 2 }}>
                            <Typography variant="caption" color="text.secondary">
                              Wasserstein Distance
                            </Typography>
                            <Typography variant="h6">
                              {metrics.w_dist.toFixed(4)}
                            </Typography>
                          </Paper>
                        </Grid>
                      </Grid>
                    </Box>
                  )}
                </Box>
              )}

              {!training && jobId && progress === 100 && (
                <Alert severity="success">
                  GAN training completed successfully! You can now generate synthetic data.
                </Alert>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Data Requirements Alert */}
        <Grid item xs={12}>
          <Alert severity="warning" sx={{ mb: 0 }}>
            <Typography variant="subtitle2" gutterBottom>
              ⚠️ Data Requirements for GAN Training
            </Typography>
            <Typography variant="body2" paragraph>
              GAN training requires a substantial dataset of real wafer images to learn realistic patterns.
            </Typography>
            <Box component="ul" sx={{ mt: 1, mb: 1, pl: 2 }}>
              <Typography component="li" variant="body2">
                <strong>Minimum:</strong> 500-1000 wafer map images (224×224 RGB)
              </Typography>
              <Typography component="li" variant="body2">
                <strong>Optimal:</strong> 2000+ images with balanced class distribution
              </Typography>
              <Typography component="li" variant="body2">
                <strong>Per Class:</strong> 50-100 images for each of the 10 pattern types
              </Typography>
              <Typography component="li" variant="body2">
                <strong>Current Status:</strong> Check your uploaded wafer count before training
              </Typography>
            </Box>
            <Typography variant="body2">
              💡 Upload more wafer images via the <strong>Upload</strong> page before starting GAN training.
            </Typography>
          </Alert>
        </Grid>

        {/* Information Panel */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                About GAN Training
              </Typography>
              <Divider sx={{ mb: 2 }} />
              
              <Typography variant="body2" paragraph>
                The Generative Adversarial Network (GAN) learns to generate realistic synthetic wafer maps
                that can be used to augment your training dataset. This helps improve model performance,
                especially for rare defect patterns.
              </Typography>

              <Typography variant="subtitle2" gutterBottom>
                Key Features:
              </Typography>
              <Box component="ul" sx={{ mt: 1, pl: 2 }}>
                <Typography component="li" variant="body2">
                  Conditional WGAN-GP architecture for stable training
                </Typography>
                <Typography component="li" variant="body2">
                  Generates 224×224 RGB wafer maps conditioned on pattern type
                </Typography>
                <Typography component="li" variant="body2">
                  Supports all 10 defect pattern classes
                </Typography>
                <Typography component="li" variant="body2">
                  Controllable defect density for realistic variations
                </Typography>
              </Box>

              <Typography variant="subtitle2" gutterBottom sx={{ mt: 2 }}>
                Required Data Format:
              </Typography>
              <Box component="ul" sx={{ mt: 1, pl: 2 }}>
                <Typography component="li" variant="body2">
                  <strong>Images:</strong> PNG/JPEG format, 224×224 pixels, RGB color
                </Typography>
                <Typography component="li" variant="body2">
                  <strong>Labels:</strong> Pattern class (Center, Donut, Edge-Loc, Edge-Ring, Loc, Near-full, Random, Scratch, none, Mixed)
                </Typography>
                <Typography component="li" variant="body2">
                  <strong>Metadata:</strong> Defect density, lot ID, wafer ID
                </Typography>
                <Typography component="li" variant="body2">
                  <strong>Location:</strong> data/processed/splits/train_metadata.json
                </Typography>
              </Box>

              <Typography variant="subtitle2" gutterBottom sx={{ mt: 2 }}>
                Recommended Settings:
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 1 }}>
                <Chip label="Epochs: 100-200" size="small" />
                <Chip label="Batch Size: 32" size="small" />
                <Chip label="Critic: 5" size="small" />
                <Chip label="λ GP: 10.0" size="small" />
                <Chip label="LR: 0.0001" size="small" />
              </Box>

              <Typography variant="subtitle2" gutterBottom sx={{ mt: 2 }}>
                Training Time Estimates:
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 1 }}>
                <Chip label="100 epochs: 2-3 hours (GPU)" size="small" variant="outlined" />
                <Chip label="200 epochs: 4-6 hours (GPU)" size="small" variant="outlined" />
                <Chip label="CPU: 10-20x slower" size="small" variant="outlined" color="warning" />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default GANTraining;
