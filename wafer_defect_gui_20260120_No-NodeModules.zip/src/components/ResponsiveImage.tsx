import { useState } from 'react';
import { Box, Skeleton } from '@mui/material';

interface ImageSource {
  src: string;
  width: number;
}

interface ResponsiveImageProps {
  sources: ImageSource[];
  alt: string;
  width?: string | number;
  height?: string | number;
  fallbackSrc: string;
  onLoad?: () => void;
  onError?: () => void;
  style?: React.CSSProperties;
}

/**
 * Responsive image component with srcset for different screen sizes
 * Automatically selects the best image size based on viewport
 */
export default function ResponsiveImage({
  sources,
  alt,
  width = '100%',
  height = 'auto',
  fallbackSrc,
  onLoad,
  onError,
  style,
}: ResponsiveImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  const handleLoad = () => {
    setIsLoaded(true);
    onLoad?.();
  };

  const handleError = () => {
    setHasError(true);
    onError?.();
  };

  // Generate srcset string
  const srcSet = sources
    .map((source) => `${source.src} ${source.width}w`)
    .join(', ');

  // Generate sizes string (can be customized based on layout)
  const sizes = '(max-width: 600px) 100vw, (max-width: 960px) 50vw, 33vw';

  return (
    <Box
      sx={{
        width,
        height,
        position: 'relative',
        overflow: 'hidden',
        ...style,
      }}
    >
      {!isLoaded && !hasError && (
        <Skeleton
          variant="rectangular"
          width={width}
          height={height}
          animation="wave"
        />
      )}
      <img
        srcSet={srcSet}
        sizes={sizes}
        src={fallbackSrc}
        alt={alt}
        onLoad={handleLoad}
        onError={handleError}
        loading="lazy"
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          display: isLoaded || hasError ? 'block' : 'none',
        }}
      />
    </Box>
  );
}
