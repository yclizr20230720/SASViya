/**
 * GAN Service
 * 
 * Service for interacting with GAN API endpoints
 * Handles GAN training, synthetic data generation, and quality validation
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api/v1';

export interface GANTrainingConfig {
  epochs: number;
  batch_size: number;
  n_critic: number;
  lambda_gp: number;
  learning_rate: number;
  data_split: string;
  checkpoint_dir: string;
}

export interface GANGenerationConfig {
  num_samples: number;
  pattern?: string;
  defect_density?: number;
  checkpoint: string;
  output_dir: string;
}

export interface GANValidationConfig {
  real_dir: string;
  synthetic_dir: string;
  model_checkpoint: string;
}

export interface GANJob {
  id: string;
  type: 'gan_training' | 'gan_generation' | 'gan_validation';
  status: 'queued' | 'training' | 'generating' | 'validating' | 'completed' | 'failed';
  created_at: string;
  completed_at?: string;
  config: GANTrainingConfig | GANGenerationConfig | GANValidationConfig;
  progress: number;
  current_epoch?: number;
  metrics?: GANMetrics;
  error?: string;
  generated_files?: string[];
}

export interface GANMetrics {
  d_loss: number;
  g_loss: number;
  gp: number;
  w_dist: number;
  fid_score?: number;
  avg_confidence?: number;
}

export interface GANModel {
  name: string;
  path: string;
  size_mb: number;
  created_at: string;
}

export interface GANTrainingResponse {
  status: string;
  message: string;
  job_id: string;
  estimated_duration_minutes: number;
}

export interface GANStatusResponse {
  status: string;
  job: GANJob;
}

export interface GANModelsResponse {
  status: string;
  models: GANModel[];
}

export interface GANJobsResponse {
  status: string;
  jobs: GANJob[];
  total: number;
}

class GANService {
  /**
   * Start GAN training
   */
  async startTraining(config: Partial<GANTrainingConfig>): Promise<GANTrainingResponse> {
    const defaultConfig: GANTrainingConfig = {
      epochs: 100,
      batch_size: 32,
      n_critic: 5,
      lambda_gp: 10.0,
      learning_rate: 0.0001,
      data_split: 'all',
      checkpoint_dir: 'checkpoints/gan',
      ...config
    };

    const response = await fetch(`${API_BASE_URL}/gan/train`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(defaultConfig)
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to start GAN training');
    }

    return response.json();
  }

  /**
   * Get GAN training/generation status
   */
  async getStatus(jobId: string): Promise<GANStatusResponse> {
    const response = await fetch(`${API_BASE_URL}/gan/status/${jobId}`);

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to get GAN status');
    }

    return response.json();
  }

  /**
   * Generate synthetic wafer maps
   */
  async generateSynthetic(config: Partial<GANGenerationConfig>): Promise<GANTrainingResponse> {
    const defaultConfig: GANGenerationConfig = {
      num_samples: 100,
      checkpoint: 'checkpoints/gan/gan_final.pth',
      output_dir: 'data/synthetic',
      ...config
    };

    const response = await fetch(`${API_BASE_URL}/gan/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(defaultConfig)
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to start synthetic generation');
    }

    return response.json();
  }

  /**
   * List available GAN models
   */
  async listModels(): Promise<GANModelsResponse> {
    const response = await fetch(`${API_BASE_URL}/gan/models`);

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to list GAN models');
    }

    return response.json();
  }

  /**
   * List GAN jobs
   */
  async listJobs(
    type?: 'gan_training' | 'gan_generation' | 'gan_validation',
    status?: string,
    limit: number = 50
  ): Promise<GANJobsResponse> {
    const params = new URLSearchParams({ limit: limit.toString() });
    if (type) params.append('type', type);
    if (status) params.append('status', status);

    const response = await fetch(`${API_BASE_URL}/gan/jobs?${params}`);

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to list GAN jobs');
    }

    return response.json();
  }

  /**
   * Validate synthetic quality
   */
  async validateQuality(config: Partial<GANValidationConfig>): Promise<GANTrainingResponse> {
    const defaultConfig: GANValidationConfig = {
      real_dir: 'data/wafer_images',
      synthetic_dir: 'data/synthetic',
      model_checkpoint: 'checkpoints/best_model.pth',
      ...config
    };

    const response = await fetch(`${API_BASE_URL}/gan/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(defaultConfig)
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to start quality validation');
    }

    return response.json();
  }

  /**
   * Poll job status until completion
   */
  async pollJobStatus(
    jobId: string,
    onProgress?: (job: GANJob) => void,
    interval: number = 3000
  ): Promise<GANJob> {
    return new Promise((resolve, reject) => {
      const poll = async () => {
        try {
          const response = await this.getStatus(jobId);
          const job = response.job;

          if (onProgress) {
            onProgress(job);
          }

          if (job.status === 'completed') {
            resolve(job);
          } else if (job.status === 'failed') {
            reject(new Error(job.error || 'Job failed'));
          } else {
            setTimeout(poll, interval);
          }
        } catch (error) {
          reject(error);
        }
      };

      poll();
    });
  }
}

export const ganService = new GANService();
