import { Box, Typography, Grid, Tabs, Tab, CircularProgress, Alert } from '@mui/material';
import { useState, useEffect } from 'react';
import PatternDistributionCharts from '../components/PatternDistributionCharts';
import TemporalTrendAnalysis from '../components/TemporalTrendAnalysis';
import YieldAnalysisCharts from '../components/YieldAnalysisCharts';
import EquipmentCorrelationAnalysis from '../components/EquipmentCorrelationAnalysis';
import ProcessStepAnalysis from '../components/ProcessStepAnalysis';
import { analyticsService } from '../services/analyticsService';

export default function Analytics() {
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [patternData, setPatternData] = useState<any>(null);
  const [temporalData, setTemporalData] = useState<any>(null);
  const [yieldData, setYieldData] = useState<any>(null);
  const [equipmentData, setEquipmentData] = useState<any>(null);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const [patterns, temporal, yields, equipment] = await Promise.all([
          analyticsService.getPatternAnalytics(30),
          analyticsService.getTemporalAnalytics(30, 'day'),
          analyticsService.getYieldAnalytics(30),
          analyticsService.getEquipmentAnalytics(30),
        ]);
        
        // Transform pattern data to match component expectations
        setPatternData({
          distribution: patterns.pattern_distribution,
          trends: patterns.pattern_over_time,
        });
        
        // Transform temporal data to match component expectations
        setTemporalData({
          time_series: temporal.defect_trends.map(item => ({
            date: item.date,
            defect_rate: item.defect_rate_percentage,
            moving_average: item.defect_rate_percentage, // Use same value for now
          })),
          anomalies: temporal.anomalies,
          statistics: {
            avg_defect_rate: temporal.statistics.mean_defect_rate,
            max_defect_rate: Math.max(...temporal.defect_trends.map(d => d.defect_rate_percentage)),
            min_defect_rate: Math.min(...temporal.defect_trends.map(d => d.defect_rate_percentage)),
            trend_direction: 'stable',
            trend_percentage: 0,
          },
        });
        
        // Transform yield data to match component expectations
        setYieldData({
          yield_trends: yields.yield_trends.map(item => ({
            date: item.date,
            yield: item.yield_percentage,
            target: 95, // Default target
          })),
          yield_vs_defects: yields.yield_by_lot.map(item => ({
            defect_density: ((item.defective_wafers / item.total_wafers) * 100),
            yield: item.yield_percentage,
            lot_id: item.lot_id,
          })),
          statistics: {
            current_yield: yields.yield_trends[yields.yield_trends.length - 1]?.yield_percentage || 0,
            avg_yield: yields.overall_statistics.overall_yield_percentage,
            target_yield: 95,
            yield_gap: yields.overall_statistics.overall_yield_percentage - 95,
          },
        });
        
        // Transform equipment data to match component expectations
        setEquipmentData({
          equipment_patterns: equipment.equipment_performance.map(item => ({
            equipment_id: item.equipment_id,
            patterns: item.pattern_distribution,
            total_defects: item.total_wafers * item.avg_defect_count,
            defect_rate: item.defect_rate_percentage / 100,
          })),
          correlations: equipment.equipment_correlation.map(item => ({
            equipment1: item.equipment_1,
            equipment2: item.equipment_2,
            similarity: item.similarity_score,
          })),
          performance: equipment.equipment_performance.map(item => ({
            equipment_id: item.equipment_id,
            uptime: 0.95, // Default uptime
            defect_rate: item.defect_rate_percentage / 100,
          })),
        });
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load analytics data');
        console.error('Analytics fetch error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchAnalytics();
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '400px' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 3, fontWeight: 600 }}>
        Reports & Trends
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
        Comprehensive analytics and insights for wafer defect patterns, yield trends, and equipment performance
      </Typography>

      {/* Tab Navigation */}
      <Tabs
        value={activeTab}
        onChange={(_, newValue) => setActiveTab(newValue)}
        sx={{ mb: 3, borderBottom: 1, borderColor: 'divider' }}
      >
        <Tab label="Overview" />
        <Tab label="Equipment & Process" />
      </Tabs>

      {/* Overview Tab */}
      {activeTab === 0 && (
        <Grid container spacing={3}>
          <Grid size={{ xs: 12 }}>
            <PatternDistributionCharts data={patternData} />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <TemporalTrendAnalysis data={temporalData} />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <YieldAnalysisCharts data={yieldData} />
          </Grid>
        </Grid>
      )}

      {/* Equipment & Process Tab */}
      {activeTab === 1 && (
        <Grid container spacing={3}>
          <Grid size={{ xs: 12 }}>
            <EquipmentCorrelationAnalysis data={equipmentData} />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <ProcessStepAnalysis />
          </Grid>
        </Grid>
      )}
    </Box>
  );
}
