import { useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Tabs,
  Tab,
  Alert,
} from '@mui/material';
import FeedbackSubmissionForm from '../components/FeedbackSubmissionForm';
import FeedbackHistoryTracking from '../components/FeedbackHistoryTracking';
import WaferMapAnnotation from '../components/WaferMapAnnotation';
// import CollaborativeReviewSystem from '../components/CollaborativeReviewSystem';
import { mockWafers, mockPredictions } from '../mock/mockData';

export default function Feedback() {
  const { waferId } = useParams();
  const [activeTab, setActiveTab] = useState(0);

  // Use first wafer if no ID provided
  const wafer = waferId
    ? mockWafers.find((w) => w.waferId === waferId) || mockWafers[0]
    : mockWafers[0];

  const prediction = mockPredictions[wafer.id];

  if (!prediction) {
    return (
      <Alert severity="info">
        No prediction data available for this wafer.
      </Alert>
    );
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 3, fontWeight: 600 }}>
        Feedback & Collaboration
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
        Submit feedback, annotate wafer maps, and collaborate with your team on wafer analysis.
      </Typography>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Tabs
            value={activeTab}
            onChange={(_, newValue) => setActiveTab(newValue)}
            sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}
          >
            <Tab label="Submit Feedback" />
            <Tab label="Annotate Wafer Map" />
            {/* <Tab label="Collaboration" /> */}
            <Tab label="Feedback History" />
          </Tabs>

          {/* Submit Feedback Tab */}
          {activeTab === 0 && (
            <Grid container spacing={3}>
              <Grid size={{ xs: 12, lg: 8 }}>
                <FeedbackSubmissionForm
                  waferId={wafer.waferId}
                  predictedPattern={prediction.patternClass}
                  predictedRootCause={prediction.rootCauseClass}
                />
              </Grid>
              <Grid size={{ xs: 12, lg: 4 }}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Current Prediction
                    </Typography>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Pattern: <strong>{prediction.patternClass}</strong>
                    </Typography>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Confidence: <strong>{(prediction.patternConfidence * 100).toFixed(1)}%</strong>
                    </Typography>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Root Cause: <strong>{prediction.rootCauseClass}</strong>
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Confidence: <strong>{(prediction.rootCauseConfidence * 100).toFixed(1)}%</strong>
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          )}

          {/* Annotate Wafer Map Tab */}
          {activeTab === 1 && (
            <Box>
              <Typography variant="h6" gutterBottom>
                Annotate Wafer Map: {wafer.waferId}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Use the annotation tools to mark regions of interest, add notes, and highlight defect patterns.
              </Typography>
              <WaferMapAnnotation
                annotations={[]}
                onAnnotationsChange={(annotations) => {
                  console.log('Annotations changed:', annotations);
                }}
                canvasSize={600}
              />
            </Box>
          )}

          {/* Collaboration Tab - Temporarily Disabled */}
          {/* {activeTab === 2 && (
            <Box>
              <Typography variant="h6" gutterBottom>
                Collaborative Review: {wafer.waferId}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Collaborate with your team in real-time. Add comments, assign reviews, and discuss findings.
              </Typography>
              <CollaborativeReviewSystem
                waferId={wafer.waferId}
                currentUserId="current-user"
                currentUserName="Current User"
                onCommentAdded={(comment) => {
                  console.log('Comment added:', comment);
                }}
                onAssignmentCreated={(assignment) => {
                  console.log('Assignment created:', assignment);
                }}
              />
            </Box>
          )} */}

          {/* Feedback History Tab */}
          {activeTab === 2 && (
            <Box>
              <Typography variant="h6" gutterBottom>
                Feedback History
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                View all feedback submissions and track their status and impact on model performance.
              </Typography>
              <FeedbackHistoryTracking />
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
