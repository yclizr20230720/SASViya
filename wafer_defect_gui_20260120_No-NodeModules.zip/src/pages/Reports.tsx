import { useState } from 'react';
import {
  Box,
  Typography,
  Tabs,
  Tab,
  Paper,
} from '@mui/material';
import ReportTemplateLibrary from '../components/ReportTemplateLibrary';
import ReportBuilder from '../components/ReportBuilder';
import ReportScheduler from '../components/ReportScheduler';
import ReportExport from '../components/ReportExport';
import ReportViewer from '../components/ReportViewer';
import type { ReportTemplate, ReportSchedule, GeneratedReport } from '../types/report';
import { exportToPDF, exportToPowerPoint, generateShareableLink } from '../utils/reportExportService';

interface ExportOptions {
  includeCharts?: boolean;
  includeData?: boolean;
  format?: 'pdf' | 'pptx';
}

// Helper functions to generate wafer map heatmaps
function generateEdgeDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      const distFromCenter = Math.sqrt(
        Math.pow(i - size / 2, 2) + Math.pow(j - size / 2, 2)
      );
      const maxDist = size / 2;
      if (distFromCenter > maxDist * 0.8) {
        heatmap[i][j] = Math.random() * 0.8 + 0.2;
      } else {
        heatmap[i][j] = Math.random() * 0.1;
      }
    }
  }
  return heatmap;
}

function generateCenterDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      const distFromCenter = Math.sqrt(
        Math.pow(i - size / 2, 2) + Math.pow(j - size / 2, 2)
      );
      const maxDist = size / 2;
      if (distFromCenter < maxDist * 0.3) {
        heatmap[i][j] = Math.random() * 0.7 + 0.3;
      } else {
        heatmap[i][j] = Math.random() * 0.15;
      }
    }
  }
  return heatmap;
}

function generateEdgeLocDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  // Create localized edge defect (right side)
  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      const distFromCenter = Math.sqrt(
        Math.pow(i - size / 2, 2) + Math.pow(j - size / 2, 2)
      );
      const maxDist = size / 2;
      const angle = Math.atan2(i - size / 2, j - size / 2);
      
      if (distFromCenter > maxDist * 0.7 && angle > -Math.PI / 4 && angle < Math.PI / 4) {
        heatmap[i][j] = Math.random() * 0.8 + 0.2;
      } else {
        heatmap[i][j] = Math.random() * 0.1;
      }
    }
  }
  return heatmap;
}

function generateScratchDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  // Create diagonal scratch
  for (let i = 0; i < size; i++) {
    const j = Math.floor((i * size) / size);
    for (let offset = -2; offset <= 2; offset++) {
      if (j + offset >= 0 && j + offset < size) {
        heatmap[i][j + offset] = Math.random() * 0.6 + 0.4;
      }
    }
  }
  return heatmap;
}

function generateRandomDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      heatmap[i][j] = Math.random() * 0.3;
    }
  }
  return heatmap;
}

function generateRingDefectHeatmap(): number[][] {
  const size = 30;
  const heatmap: number[][] = Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      const distFromCenter = Math.sqrt(
        Math.pow(i - size / 2, 2) + Math.pow(j - size / 2, 2)
      );
      const maxDist = size / 2;
      const ringDist = Math.abs(distFromCenter - maxDist * 0.6);
      if (ringDist < maxDist * 0.15) {
        heatmap[i][j] = Math.random() * 0.7 + 0.3;
      } else {
        heatmap[i][j] = Math.random() * 0.1;
      }
    }
  }
  return heatmap;
}

export default function Reports() {
  const [activeTab, setActiveTab] = useState(0);
  const [editingTemplate, setEditingTemplate] = useState<ReportTemplate | null>(null);
  const [viewingReport, setViewingReport] = useState<GeneratedReport | null>(null);

  // Mock data - replace with actual API calls
  const [templates, setTemplates] = useState<ReportTemplate[]>([
    {
      id: 'template-1',
      name: 'Daily Summary Report',
      description: 'Overview of daily wafer processing and defect patterns',
      type: 'daily-summary',
      widgets: [
        {
          id: 'widget-1',
          type: 'metric',
          title: 'Total Wafers Processed',
          config: { metric: 'totalWafers', showTrend: true },
          position: { x: 0, y: 0, width: 3, height: 2 },
        },
        {
          id: 'widget-2',
          type: 'metric',
          title: 'Average Confidence',
          config: { metric: 'avgConfidence', showTrend: true },
          position: { x: 3, y: 0, width: 3, height: 2 },
        },
        {
          id: 'widget-3',
          type: 'metric',
          title: 'Defect Detection Rate',
          config: { metric: 'defectRate', showTrend: true },
          position: { x: 6, y: 0, width: 3, height: 2 },
        },
        {
          id: 'widget-4',
          type: 'metric',
          title: 'Processing Time',
          config: { metric: 'processingTime', showTrend: true },
          position: { x: 9, y: 0, width: 3, height: 2 },
        },
        {
          id: 'widget-5',
          type: 'chart',
          title: 'Pattern Distribution',
          config: { chartType: 'pie', dataSource: 'patternDistribution' },
          position: { x: 0, y: 2, width: 6, height: 4 },
        },
        {
          id: 'widget-6',
          type: 'chart',
          title: 'Hourly Processing Volume',
          config: { chartType: 'line', dataSource: 'hourlyVolume' },
          position: { x: 6, y: 2, width: 6, height: 4 },
        },
        {
          id: 'widget-7',
          type: 'table',
          title: 'Top 10 Defect Wafers',
          config: { dataSource: 'topDefects', columns: ['waferId', 'pattern', 'confidence', 'defectCount'] },
          position: { x: 0, y: 6, width: 12, height: 4 },
        },
      ],
      layout: 'grid',
      createdAt: '2024-01-15T10:00:00Z',
      updatedAt: '2024-01-15T10:00:00Z',
      createdBy: 'admin',
      isDefault: true,
    },
    {
      id: 'template-2',
      name: 'Pattern Analysis Report',
      description: 'Detailed analysis of defect patterns and trends',
      type: 'pattern-analysis',
      widgets: [
        {
          id: 'widget-1',
          type: 'text',
          title: 'Executive Summary',
          config: { content: 'Pattern analysis summary for the selected period' },
          position: { x: 0, y: 0, width: 12, height: 2 },
        },
        {
          id: 'widget-2',
          type: 'wafer-map',
          title: 'Representative Wafer Map',
          config: { waferId: 'sample', showDefects: true },
          position: { x: 0, y: 2, width: 6, height: 6 },
        },
        {
          id: 'widget-3',
          type: 'chart',
          title: 'Pattern Trend Over Time',
          config: { chartType: 'line', dataSource: 'patternTrend' },
          position: { x: 6, y: 2, width: 6, height: 6 },
        },
        {
          id: 'widget-4',
          type: 'chart',
          title: 'Pattern Classification Breakdown',
          config: { chartType: 'bar', dataSource: 'patternClassification' },
          position: { x: 0, y: 8, width: 6, height: 4 },
        },
        {
          id: 'widget-5',
          type: 'chart',
          title: 'Root Cause Distribution',
          config: { chartType: 'pie', dataSource: 'rootCauseDistribution' },
          position: { x: 6, y: 8, width: 6, height: 4 },
        },
        {
          id: 'widget-6',
          type: 'table',
          title: 'Pattern Details',
          config: { dataSource: 'patternDetails', columns: ['pattern', 'count', 'avgConfidence', 'rootCause'] },
          position: { x: 0, y: 12, width: 12, height: 4 },
        },
      ],
      layout: 'grid',
      createdAt: '2024-01-16T10:00:00Z',
      updatedAt: '2024-01-16T10:00:00Z',
      createdBy: 'admin',
      isDefault: true,
    },
    {
      id: 'template-3',
      name: 'Yield Report',
      description: 'Yield metrics and equipment performance analysis',
      type: 'yield-report',
      widgets: [
        {
          id: 'widget-1',
          type: 'metric',
          title: 'Overall Yield',
          config: { metric: 'overallYield', showTrend: true },
          position: { x: 0, y: 0, width: 4, height: 2 },
        },
        {
          id: 'widget-2',
          type: 'metric',
          title: 'Yield Target',
          config: { metric: 'yieldTarget', showProgress: true },
          position: { x: 4, y: 0, width: 4, height: 2 },
        },
        {
          id: 'widget-3',
          type: 'metric',
          title: 'Defect Impact',
          config: { metric: 'defectImpact', showTrend: true },
          position: { x: 8, y: 0, width: 4, height: 2 },
        },
        {
          id: 'widget-4',
          type: 'chart',
          title: 'Yield Trend',
          config: { chartType: 'line', dataSource: 'yieldTrend' },
          position: { x: 0, y: 2, width: 12, height: 4 },
        },
        {
          id: 'widget-5',
          type: 'chart',
          title: 'Equipment Performance',
          config: { chartType: 'bar', dataSource: 'equipmentPerformance' },
          position: { x: 0, y: 6, width: 6, height: 4 },
        },
        {
          id: 'widget-6',
          type: 'chart',
          title: 'Process Step Analysis',
          config: { chartType: 'funnel', dataSource: 'processStepYield' },
          position: { x: 6, y: 6, width: 6, height: 4 },
        },
        {
          id: 'widget-7',
          type: 'table',
          title: 'Equipment Yield Summary',
          config: { dataSource: 'equipmentYield', columns: ['equipment', 'yield', 'defectRate', 'uptime'] },
          position: { x: 0, y: 10, width: 12, height: 4 },
        },
      ],
      layout: 'grid',
      createdAt: '2024-01-17T10:00:00Z',
      updatedAt: '2024-01-17T10:00:00Z',
      createdBy: 'admin',
      isDefault: true,
    },
  ]);

  const [schedules, setSchedules] = useState<ReportSchedule[]>([
    {
      id: 'schedule-1',
      templateId: 'template-1',
      frequency: 'daily',
      time: '09:00',
      recipients: ['manager@example.com', 'team@example.com'],
      enabled: true,
      lastRun: '2024-01-17T09:00:00Z',
      nextRun: '2024-01-18T09:00:00Z',
    },
  ]);

  const [generatedReports, setGeneratedReports] = useState<GeneratedReport[]>([
    // Daily Summary Reports
    {
      id: 'report-1',
      templateId: 'template-1',
      name: 'Daily Summary - January 17, 2024',
      generatedAt: '2024-01-17T09:00:00Z',
      generatedBy: 'system',
      data: {
        totalWafers: 245,
        avgConfidence: 87.3,
        defectRate: 12.4,
        processingTime: '2.3s',
        patterns: { Center: 45, 'Edge-Ring': 32, 'Edge-Loc': 28, Random: 18, None: 122 },
      },
      format: 'pdf',
      url: '/reports/daily-summary-2024-01-17.pdf',
    },
    {
      id: 'report-2',
      templateId: 'template-1',
      name: 'Daily Summary - January 16, 2024',
      generatedAt: '2024-01-16T09:00:00Z',
      generatedBy: 'system',
      data: {
        totalWafers: 238,
        avgConfidence: 85.7,
        defectRate: 13.1,
        processingTime: '2.4s',
        patterns: { Center: 42, 'Edge-Ring': 35, 'Edge-Loc': 25, Random: 21, None: 115 },
      },
      format: 'pdf',
      url: '/reports/daily-summary-2024-01-16.pdf',
    },
    {
      id: 'report-3',
      templateId: 'template-1',
      name: 'Daily Summary - January 15, 2024',
      generatedAt: '2024-01-15T09:00:00Z',
      generatedBy: 'system',
      data: {
        totalWafers: 252,
        avgConfidence: 88.9,
        defectRate: 11.2,
        processingTime: '2.2s',
        patterns: { Center: 48, 'Edge-Ring': 30, 'Edge-Loc': 26, Random: 15, None: 133 },
      },
      format: 'pdf',
      url: '/reports/daily-summary-2024-01-15.pdf',
    },
    // Pattern Analysis Reports
    {
      id: 'report-4',
      templateId: 'template-2',
      name: 'Pattern Analysis - Week 3, 2024',
      generatedAt: '2024-01-17T14:30:00Z',
      generatedBy: 'john.doe',
      data: {
        period: 'Week 3, 2024',
        totalPatterns: 156,
        dominantPattern: 'Center',
        avgConfidence: 86.5,
        rootCauses: {
          'Equipment Drift': 35,
          'Process Variation': 28,
          'Particle Contamination': 22,
          'Temperature Fluctuation': 15,
        },
        waferMaps: [
          {
            pattern: 'Center',
            confidence: 94,
            heatmap: generateCenterDefectHeatmap(),
          },
          {
            pattern: 'Edge-Ring',
            confidence: 89,
            heatmap: generateEdgeDefectHeatmap(),
          },
          {
            pattern: 'Edge-Loc',
            confidence: 91,
            heatmap: generateEdgeLocDefectHeatmap(),
          },
          {
            pattern: 'Random',
            confidence: 78,
            heatmap: generateRandomDefectHeatmap(),
          },
        ],
      },
      format: 'pptx',
      url: '/reports/pattern-analysis-week3-2024.pptx',
    },
    {
      id: 'report-5',
      templateId: 'template-2',
      name: 'Pattern Analysis - Week 2, 2024',
      generatedAt: '2024-01-10T14:30:00Z',
      generatedBy: 'jane.smith',
      data: {
        period: 'Week 2, 2024',
        totalPatterns: 142,
        dominantPattern: 'Edge-Ring',
        avgConfidence: 84.2,
        rootCauses: {
          'Equipment Drift': 32,
          'Process Variation': 30,
          'Particle Contamination': 25,
          'Temperature Fluctuation': 13,
        },
        waferMaps: [
          {
            pattern: 'Edge-Ring',
            confidence: 92,
            heatmap: generateEdgeDefectHeatmap(),
          },
          {
            pattern: 'Center',
            confidence: 88,
            heatmap: generateCenterDefectHeatmap(),
          },
          {
            pattern: 'Scratch',
            confidence: 85,
            heatmap: generateScratchDefectHeatmap(),
          },
          {
            pattern: 'Ring',
            confidence: 81,
            heatmap: generateRingDefectHeatmap(),
          },
        ],
      },
      format: 'pptx',
      url: '/reports/pattern-analysis-week2-2024.pptx',
    },
    {
      id: 'report-6',
      templateId: 'template-2',
      name: 'Pattern Analysis - December 2023',
      generatedAt: '2024-01-02T10:00:00Z',
      generatedBy: 'mike.johnson',
      data: {
        period: 'December 2023',
        totalPatterns: 628,
        dominantPattern: 'Center',
        avgConfidence: 87.8,
        rootCauses: {
          'Equipment Drift': 145,
          'Process Variation': 128,
          'Particle Contamination': 98,
          'Temperature Fluctuation': 67,
        },
        waferMaps: [
          {
            pattern: 'Center',
            confidence: 95,
            heatmap: generateCenterDefectHeatmap(),
          },
          {
            pattern: 'Edge-Ring',
            confidence: 90,
            heatmap: generateEdgeDefectHeatmap(),
          },
          {
            pattern: 'Ring',
            confidence: 87,
            heatmap: generateRingDefectHeatmap(),
          },
          {
            pattern: 'Scratch',
            confidence: 83,
            heatmap: generateScratchDefectHeatmap(),
          },
          {
            pattern: 'Edge-Loc',
            confidence: 86,
            heatmap: generateEdgeLocDefectHeatmap(),
          },
          {
            pattern: 'Random',
            confidence: 75,
            heatmap: generateRandomDefectHeatmap(),
          },
        ],
      },
      format: 'pdf',
      url: '/reports/pattern-analysis-dec-2023.pdf',
    },
    // Yield Reports
    {
      id: 'report-7',
      templateId: 'template-3',
      name: 'Yield Report - Q1 2024',
      generatedAt: '2024-01-17T16:00:00Z',
      generatedBy: 'sarah.williams',
      data: {
        period: 'Q1 2024',
        overallYield: 92.5,
        yieldTarget: 95.0,
        defectImpact: -2.5,
        equipmentPerformance: {
          'EQP-001': 94.2,
          'EQP-002': 91.8,
          'EQP-003': 93.1,
          'EQP-004': 90.9,
        },
      },
      format: 'pptx',
      url: '/reports/yield-report-q1-2024.pptx',
    },
    {
      id: 'report-8',
      templateId: 'template-3',
      name: 'Yield Report - December 2023',
      generatedAt: '2024-01-05T16:00:00Z',
      generatedBy: 'sarah.williams',
      data: {
        period: 'December 2023',
        overallYield: 91.8,
        yieldTarget: 95.0,
        defectImpact: -3.2,
        equipmentPerformance: {
          'EQP-001': 93.5,
          'EQP-002': 90.2,
          'EQP-003': 92.8,
          'EQP-004': 90.7,
        },
      },
      format: 'pdf',
      url: '/reports/yield-report-dec-2023.pdf',
    },
    {
      id: 'report-9',
      templateId: 'template-3',
      name: 'Yield Report - November 2023',
      generatedAt: '2023-12-05T16:00:00Z',
      generatedBy: 'sarah.williams',
      data: {
        period: 'November 2023',
        overallYield: 93.2,
        yieldTarget: 95.0,
        defectImpact: -1.8,
        equipmentPerformance: {
          'EQP-001': 94.8,
          'EQP-002': 92.5,
          'EQP-003': 93.6,
          'EQP-004': 91.9,
        },
      },
      format: 'pdf',
      url: '/reports/yield-report-nov-2023.pdf',
    },
  ]);

  // Template handlers
  const handleCreateTemplate = (template: Omit<ReportTemplate, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newTemplate: ReportTemplate = {
      ...template,
      id: `template-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setTemplates([...templates, newTemplate]);
  };

  const handleEditTemplate = (templateId: string) => {
    const template = templates.find((t) => t.id === templateId);
    if (template) {
      setEditingTemplate(template);
    }
  };

  const handleDeleteTemplate = (templateId: string) => {
    setTemplates(templates.filter((t) => t.id !== templateId));
  };

  const handleDuplicateTemplate = (templateId: string) => {
    const template = templates.find((t) => t.id === templateId);
    if (template) {
      const duplicated: ReportTemplate = {
        ...template,
        id: `template-${Date.now()}`,
        name: `${template.name} (Copy)`,
        isDefault: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setTemplates([...templates, duplicated]);
    }
  };

  const handleUseTemplate = (templateId: string) => {
    console.log('Use template:', templateId);
    // Implement report generation
  };

  const handleSaveTemplate = (template: ReportTemplate) => {
    setTemplates(templates.map((t) => (t.id === template.id ? template : t)));
    setEditingTemplate(null);
  };

  // Schedule handlers
  const handleCreateSchedule = (schedule: Omit<ReportSchedule, 'id' | 'lastRun' | 'nextRun'>) => {
    const newSchedule: ReportSchedule = {
      ...schedule,
      id: `schedule-${Date.now()}`,
      nextRun: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    };
    setSchedules([...schedules, newSchedule]);
  };

  const handleUpdateSchedule = (scheduleId: string, updates: Partial<ReportSchedule>) => {
    setSchedules(schedules.map((s) => (s.id === scheduleId ? { ...s, ...updates } : s)));
  };

  const handleDeleteSchedule = (scheduleId: string) => {
    setSchedules(schedules.filter((s) => s.id !== scheduleId));
  };

  // Export handlers
  const handleExportPdf = async (reportId: string, options: ExportOptions) => {
    const report = generatedReports.find((r) => r.id === reportId);
    const template = templates.find((t) => t.id === report?.templateId);
    
    if (!report || !template) {
      console.error('Report or template not found');
      return;
    }
    
    const result = await exportToPDF(report, template, options);
    if (result.success) {
      console.log('PDF exported successfully:', result.url);
    } else {
      console.error('PDF export failed:', result.error);
    }
  };

  const handleExportPptx = async (reportId: string, options: ExportOptions) => {
    const report = generatedReports.find((r) => r.id === reportId);
    const template = templates.find((t) => t.id === report?.templateId);
    
    if (!report || !template) {
      console.error('Report or template not found');
      return;
    }
    
    const result = await exportToPowerPoint(report, template, options);
    if (result.success) {
      console.log('PowerPoint exported successfully:', result.url);
    } else {
      console.error('PowerPoint export failed:', result.error);
    }
  };

  const handleGenerateLink = async (reportId: string): Promise<string> => {
    return await generateShareableLink(reportId);
  };

  const handleDeleteReport = (reportId: string) => {
    setGeneratedReports(generatedReports.filter((r) => r.id !== reportId));
  };

  const handleViewReport = (reportId: string) => {
    const report = generatedReports.find((r) => r.id === reportId);
    if (report) {
      setViewingReport(report);
    }
  };

  const handleExportViewedReportPdf = async () => {
    if (!viewingReport) return;

    try {
      const jsPDF = (await import('jspdf')).default;
      const html2canvas = (await import('html2canvas')).default;

      // Show loading message
      const loadingMsg = document.createElement('div');
      loadingMsg.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(0,0,0,0.8);color:white;padding:20px;border-radius:8px;z-index:10000;';
      loadingMsg.textContent = 'Generating PDF... Please wait';
      document.body.appendChild(loadingMsg);

      // Get the content element
      const contentElement = document.querySelector('[role="dialog"] .MuiDialogContent-root') as HTMLElement;
      if (!contentElement) {
        document.body.removeChild(loadingMsg);
        alert('Could not find report content');
        return;
      }

      // Store original styles
      const originalStyles = {
        maxHeight: contentElement.style.maxHeight,
        overflow: contentElement.style.overflow,
        height: contentElement.style.height,
        position: contentElement.style.position,
      };

      // Apply styles for full capture
      contentElement.style.maxHeight = 'none';
      contentElement.style.overflow = 'visible';
      contentElement.style.height = 'auto';
      contentElement.style.position = 'relative';

      // Wait for layout
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Capture the canvas
      const canvas = await html2canvas(contentElement, {
        scale: 2,
        useCORS: true,
        allowTaint: false,
        backgroundColor: '#ffffff',
        logging: false,
        imageTimeout: 0,
        removeContainer: true,
      });

      // Restore original styles
      Object.assign(contentElement.style, originalStyles);

      // Create PDF
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const canvasWidth = canvas.width;
      const canvasHeight = canvas.height;
      const ratio = canvasWidth / canvasHeight;
      const width = pdfWidth;
      const height = width / ratio;

      let position = 0;

      // Add pages
      while (position < canvasHeight) {
        const pageCanvas = document.createElement('canvas');
        pageCanvas.width = canvasWidth;
        pageCanvas.height = Math.min(canvasHeight - position, canvasWidth / ratio);

        const ctx = pageCanvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
          ctx.drawImage(canvas, 0, -position);

          const pageData = pageCanvas.toDataURL('image/jpeg', 0.95);
          
          if (position > 0) {
            pdf.addPage();
          }
          
          pdf.addImage(pageData, 'JPEG', 0, 0, width, Math.min(height, pdfHeight));
        }

        position += pageCanvas.height;
      }

      // Save PDF
      pdf.save(`${viewingReport.name.replace(/\s+/g, '_')}.pdf`);
      
      document.body.removeChild(loadingMsg);
      alert('✅ PDF exported successfully!');
    } catch (error) {
      console.error('PDF export error:', error);
      alert('❌ PDF export failed: ' + (error as Error).message);
    }
  };

  const handleExportViewedReportPptx = async () => {
    if (!viewingReport) return;

    try {
      const PptxGenJS = (await import('pptxgenjs')).default;
      const html2canvas = (await import('html2canvas')).default;

      // Show loading message
      const loadingMsg = document.createElement('div');
      loadingMsg.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(0,0,0,0.8);color:white;padding:20px;border-radius:8px;z-index:10000;';
      loadingMsg.textContent = 'Generating PowerPoint... Please wait';
      document.body.appendChild(loadingMsg);

      // Get the content element
      const contentElement = document.querySelector('[role="dialog"] .MuiDialogContent-root') as HTMLElement;
      if (!contentElement) {
        document.body.removeChild(loadingMsg);
        alert('Could not find report content');
        return;
      }

      // Store original styles
      const originalStyles = {
        maxHeight: contentElement.style.maxHeight,
        overflow: contentElement.style.overflow,
        height: contentElement.style.height,
        position: contentElement.style.position,
      };

      // Apply styles for full capture
      contentElement.style.maxHeight = 'none';
      contentElement.style.overflow = 'visible';
      contentElement.style.height = 'auto';
      contentElement.style.position = 'relative';

      // Wait for layout
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Capture the canvas
      const canvas = await html2canvas(contentElement, {
        scale: 2,
        useCORS: true,
        allowTaint: false,
        backgroundColor: '#ffffff',
        logging: false,
        imageTimeout: 0,
        removeContainer: true,
      });

      // Restore original styles
      Object.assign(contentElement.style, originalStyles);

      // Create PowerPoint
      const pptx = new PptxGenJS();

      // Add title slide
      const titleSlide = pptx.addSlide();
      titleSlide.addText(viewingReport.name, {
        x: 0.5,
        y: 2,
        w: 9,
        h: 1,
        fontSize: 32,
        bold: true,
        color: '1976d2',
        align: 'center',
      });
      titleSlide.addText(`Generated: ${new Date(viewingReport.generatedAt).toLocaleString()}`, {
        x: 0.5,
        y: 3.5,
        w: 9,
        h: 0.5,
        fontSize: 14,
        color: '666666',
        align: 'center',
      });

      // Calculate slides needed
      const slideHeight = 7.5; // inches
      const slideWidth = 10; // inches
      const aspectRatio = canvas.height / canvas.width;
      const contentHeight = slideWidth * aspectRatio;
      const numSlides = Math.ceil(contentHeight / slideHeight);

      // Create slides
      for (let i = 0; i < numSlides; i++) {
        const slide = pptx.addSlide();
        
        // Calculate slice
        const sliceHeight = canvas.height / numSlides;
        const sliceCanvas = document.createElement('canvas');
        sliceCanvas.width = canvas.width;
        sliceCanvas.height = sliceHeight;
        
        const ctx = sliceCanvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, sliceCanvas.width, sliceCanvas.height);
          ctx.drawImage(canvas, 0, -i * sliceHeight);
          
          const sliceData = sliceCanvas.toDataURL('image/jpeg', 0.95);
          
          slide.addImage({
            data: sliceData,
            x: 0,
            y: 0,
            w: slideWidth,
            h: slideHeight,
          });
          
          // Add slide number
          slide.addText(`${i + 2} / ${numSlides + 1}`, {
            x: 9,
            y: 7.2,
            w: 0.8,
            h: 0.3,
            fontSize: 10,
            color: '999999',
          });
        }
      }

      // Save PowerPoint
      await pptx.writeFile({ fileName: `${viewingReport.name.replace(/\s+/g, '_')}.pptx` });
      
      document.body.removeChild(loadingMsg);
      alert('✅ PowerPoint exported successfully!');
    } catch (error) {
      console.error('PowerPoint export error:', error);
      alert('❌ PowerPoint export failed: ' + (error as Error).message);
    }
  };

  if (editingTemplate) {
    return (
      <ReportBuilder
        template={editingTemplate}
        onSave={handleSaveTemplate}
        onCancel={() => setEditingTemplate(null)}
      />
    );
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 3, fontWeight: 600 }}>
        Reports
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
        Create, schedule, and manage reports for wafer defect analysis
      </Typography>

      <Paper sx={{ mb: 3 }}>
        <Tabs value={activeTab} onChange={(_, value) => setActiveTab(value)}>
          <Tab label="Templates" />
          <Tab label="Schedules" />
          <Tab label="Generated Reports" />
        </Tabs>
      </Paper>

      <Box>
        {activeTab === 0 && (
          <ReportTemplateLibrary
            templates={templates}
            onCreateTemplate={handleCreateTemplate}
            onEditTemplate={handleEditTemplate}
            onDeleteTemplate={handleDeleteTemplate}
            onDuplicateTemplate={handleDuplicateTemplate}
            onUseTemplate={handleUseTemplate}
          />
        )}

        {activeTab === 1 && (
          <ReportScheduler
            schedules={schedules}
            templates={templates}
            onCreateSchedule={handleCreateSchedule}
            onUpdateSchedule={handleUpdateSchedule}
            onDeleteSchedule={handleDeleteSchedule}
          />
        )}

        {activeTab === 2 && (
          <ReportExport
            reports={generatedReports}
            onExportPdf={handleExportPdf}
            onExportPptx={handleExportPptx}
            onGenerateLink={handleGenerateLink}
            onDeleteReport={handleDeleteReport}
            onViewReport={handleViewReport}
          />
        )}
      </Box>

      {/* Report Viewer Dialog */}
      <ReportViewer
        report={viewingReport}
        template={viewingReport ? templates.find((t) => t.id === viewingReport.templateId) || null : null}
        open={!!viewingReport}
        onClose={() => setViewingReport(null)}
        onExportPdf={handleExportViewedReportPdf}
        onExportPptx={handleExportViewedReportPptx}
      />
    </Box>
  );
}
