/**
 * Enhanced Training Dashboard with Guided Workflows and Contextual Help
 * Professional UI with clear information architecture and user guidance
 */

import { useState } from 'react';
import {
  Box,
  Grid,
  Typography,
  Paper,
  Button,
  Chip,
  Card,
  CardContent,
  CardActions,
  Stepper,
  Step,
  StepLabel,
  Alert,
  AlertTitle,
  Collapse,
  IconButton,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  LinearProgress,
  useTheme,
} from '@mui/material';
import {
  TrendingUp,
  Warning,
  Inventory,
  MonitorHeart,
  Analytics,
  RocketLaunch,
  CheckCircle,
  Info as InfoIcon,
  Close as CloseIcon,
  Help as HelpIcon,
  PlayArrow as PlayIcon,
  CloudUpload as UploadIcon,
  Psychology as AnalyzeIcon,
  AutoAwesome as GenerateIcon,
  Assessment as MetricsIcon,
  Storage as LibraryIcon,
  Settings as SettingsIcon,
  LightbulbOutlined as TipIcon,
  School as LearnIcon,
  ArrowForward as ArrowIcon,
  CheckCircleOutline as CheckIcon,
} from '@mui/icons-material';
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  ZAxis,
} from 'recharts';
import KPICard from '../../components/KPICard';
import type { ActivityItem } from '../../types/training';

// Workflow steps
const workflowSteps = [
  'Ingest Training Data',
  'Analyze Patterns',
  'Generate Synthetic Data',
  'Train Model',
  'Validate & Deploy',
];

// Mock data
const scatterData = Array.from({ length: 20 }).map((_, i) => ({
  x: Math.random() * 5 + 0.1,
  y: 98 - (Math.random() * 10 * i) / 20,
  size: Math.random() * 100,
  lot: `LOT-${i + 100}`,
}));

const mockActivity: ActivityItem[] = [
  {
    id: '1',
    type: 'Analysis',
    message: 'Pattern detected: Scratch (Confidence 99%)',
    timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
    user: 'AI Engine',
    severity: 'error',
  },
  {
    id: '2',
    type: 'Upload',
    message: 'Batch LOT-2024-X4 ingested (12 wafers)',
    timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    user: 'm.chen',
    severity: 'success',
  },
  {
    id: '3',
    type: 'Training',
    message: 'Model WV-v4.2 weights updated',
    timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
    user: 'System',
    severity: 'info',
  },
];

const nodeInfrastructure = [
  { label: 'Inference Cluster', status: 'Healthy', load: 14 },
  { label: 'GAN Generator v2', status: 'Standby', load: 0 },
  { label: 'Database Mesh', status: 'Optimal', load: 42 },
  { label: 'API Gateway', status: 'Healthy', load: 8 },
];

const formatRelativeTime = (timestamp: string): string => {
  const now = Date.now();
  const time = new Date(timestamp).getTime();
  const diff = now - time;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
};

export default function TrainingDashboard() {
  const theme = useTheme();
  const [showQuickStart, setShowQuickStart] = useState(true);
  const [helpDialogOpen, setHelpDialogOpen] = useState(false);
  const [activeStep] = useState(0);

  return (
    <Box>
      {/* Header with Help */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
        <Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
            <Typography variant="h4" sx={{ fontWeight: 600 }}>
              Model Training Hub
            </Typography>
            <Tooltip title="View comprehensive training guide">
              <IconButton size="small" onClick={() => setHelpDialogOpen(true)} color="primary">
                <HelpIcon />
              </IconButton>
            </Tooltip>
          </Box>
          <Typography variant="body2" color="text.secondary">
            End-to-end AI model training workflow for wafer defect pattern recognition
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button variant="outlined" startIcon={<Analytics />} size="small">
            Live Analytics
          </Button>
          <Button variant="contained" startIcon={<RocketLaunch />} size="small">
            Quick Actions
          </Button>
        </Box>
      </Box>

      {/* Quick Start Guide - Collapsible */}
      <Collapse in={showQuickStart}>
        <Alert
          severity="info"
          icon={<LearnIcon />}
          action={
            <IconButton size="small" onClick={() => setShowQuickStart(false)}>
              <CloseIcon fontSize="small" />
            </IconButton>
          }
          sx={{ mb: 3 }}
        >
          <AlertTitle sx={{ fontWeight: 600 }}>Welcome to Model Training</AlertTitle>
          <Typography variant="body2" sx={{ mb: 1 }}>
            Follow the guided workflow below to train and deploy your AI models. Each step includes helpful tips and best practices.
          </Typography>
          <Button size="small" startIcon={<PlayIcon />} onClick={() => setHelpDialogOpen(true)} sx={{ mt: 1 }}>
            View Complete Guide
          </Button>
        </Alert>
      </Collapse>

      {/* Workflow Progress Stepper */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
          <CheckCircle color="success" />
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Training Workflow Progress
          </Typography>
          <Chip label="Step 1 of 5" size="small" color="primary" sx={{ ml: 'auto' }} />
        </Box>
        <Stepper activeStep={activeStep} alternativeLabel>
          {workflowSteps.map((label) => (
            <Step key={label}>
              <StepLabel
                StepIconProps={{
                  sx: {
                    '&.Mui-completed': { color: 'success.main' },
                    '&.Mui-active': { color: 'primary.main' },
                  },
                }}
              >
                {label}
              </StepLabel>
            </Step>
          ))}
        </Stepper>
      </Paper>

      {/* KPI Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Overall Yield"
            value="93.4"
            suffix="%"
            trend={1.2}
            trendLabel="from shift avg"
            icon={<TrendingUp color="success" />}
            color="success"
            sparklineData={[90, 91, 92, 91, 93, 94, 93.4]}
            subtitle="Percentage of non-defective dies"
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Total Scans"
            value={1442}
            trend={8.5}
            trendLabel="last 24 hours"
            icon={<Inventory color="primary" />}
            color="primary"
            sparklineData={[1200, 1250, 1300, 1350, 1400, 1420, 1442]}
            subtitle="Wafers inspected in current shift"
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="Anomalies"
            value={18}
            trend={-12.5}
            trendLabel="critical patterns"
            icon={<Warning color="error" />}
            color="error"
            sparklineData={[25, 23, 20, 22, 19, 20, 18]}
            subtitle="Systematic defect patterns detected"
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <KPICard
            title="AI Health"
            value="Nominal"
            subtitle="Confidence: 98.2%"
            icon={<MonitorHeart color="info" />}
            color="primary"
            showProgress
            progressValue={98.2}
          />
        </Grid>
      </Grid>

      {/* Action Cards - Guided Workflow */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 4 }}>
          <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flexGrow: 1 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <UploadIcon color="primary" sx={{ fontSize: 32 }} />
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Ingest Wafers
                </Typography>
                <Tooltip title="Upload wafer map files (CSV, XML, KLARF) to build your training dataset">
                  <InfoIcon fontSize="small" color="action" sx={{ ml: 'auto' }} />
                </Tooltip>
              </Box>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Upload wafer inspection data to build your training dataset. Supports CSV, XML, BIN, and KLARF formats.
              </Typography>
              <Alert severity="info" icon={<TipIcon />} sx={{ mb: 2 }}>
                <Typography variant="caption">
                  <strong>Tip:</strong> Ensure metadata (Lot ID, Equipment ID) is complete for better traceability.
                </Typography>
              </Alert>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                <Chip label="CSV" size="small" variant="outlined" />
                <Chip label="XML" size="small" variant="outlined" />
                <Chip label="KLARF" size="small" variant="outlined" />
              </Box>
            </CardContent>
            <CardActions>
              <Button fullWidth variant="contained" startIcon={<UploadIcon />} href="/training/ingest">
                Start Ingestion
              </Button>
            </CardActions>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flexGrow: 1 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <AnalyzeIcon color="success" sx={{ fontSize: 32 }} />
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Pattern Analysis
                </Typography>
                <Tooltip title="Analyze wafer patterns using AI to identify defect types and root causes">
                  <InfoIcon fontSize="small" color="action" sx={{ ml: 'auto' }} />
                </Tooltip>
              </Box>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Use AI-powered analysis to detect defect patterns, visualize heatmaps, and identify root causes.
              </Typography>
              <Alert severity="success" icon={<TipIcon />} sx={{ mb: 2 }}>
                <Typography variant="caption">
                  <strong>Best Practice:</strong> Annotate ambiguous patterns manually to improve model accuracy.
                </Typography>
              </Alert>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                <Chip label="AI-Powered" size="small" color="success" />
                <Chip label="Heatmap" size="small" variant="outlined" />
              </Box>
            </CardContent>
            <CardActions>
              <Button fullWidth variant="contained" startIcon={<AnalyzeIcon />} href="/training/pattern-analysis">
                Analyze Patterns
              </Button>
            </CardActions>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flexGrow: 1 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <GenerateIcon color="warning" sx={{ fontSize: 32 }} />
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  GAN Generator
                </Typography>
                <Tooltip title="Generate synthetic wafer data to augment your training dataset for rare defect patterns">
                  <InfoIcon fontSize="small" color="action" sx={{ ml: 'auto' }} />
                </Tooltip>
              </Box>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Generate synthetic wafer data using StyleGAN-v2 to augment rare defect patterns in your dataset.
              </Typography>
              <Alert severity="warning" icon={<TipIcon />} sx={{ mb: 2 }}>
                <Typography variant="caption">
                  <strong>Warning:</strong> Keep synthetic data below 35% of total dataset to avoid overfitting.
                </Typography>
              </Alert>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                <Chip label="StyleGAN-v2" size="small" color="warning" />
                <Chip label="Augmentation" size="small" variant="outlined" />
              </Box>
            </CardContent>
            <CardActions>
              <Button fullWidth variant="contained" startIcon={<GenerateIcon />} href="/training/gan-generator">
                Generate Data
              </Button>
            </CardActions>
          </Card>
        </Grid>
      </Grid>

      {/* Secondary Action Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <MetricsIcon color="info" sx={{ fontSize: 28 }} />
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Model Metrics & Registry
                </Typography>
                <Tooltip title="View model performance, compare versions, and manage deployments">
                  <InfoIcon fontSize="small" color="action" sx={{ ml: 'auto' }} />
                </Tooltip>
              </Box>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Track model performance, compare versions, view confusion matrices, and manage deployments across environments.
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
                <Chip label="4 Versions" size="small" icon={<CheckIcon />} />
                <Chip label="v4.2 Active" size="small" color="success" />
              </Box>
            </CardContent>
            <CardActions>
              <Button startIcon={<MetricsIcon />} href="/training/model-metrics">
                View Metrics
              </Button>
              <Button startIcon={<ArrowIcon />}>Compare Models</Button>
            </CardActions>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <LibraryIcon color="primary" sx={{ fontSize: 28 }} />
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Wafer Library
                </Typography>
                <Tooltip title="Browse and manage historical wafer inspection records">
                  <InfoIcon fontSize="small" color="action" sx={{ ml: 'auto' }} />
                </Tooltip>
              </Box>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Browse, search, and filter historical wafer inspection records. Export data for analysis or reporting.
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
                <Chip label="14,224 Wafers" size="small" />
                <Chip label="Searchable" size="small" variant="outlined" />
              </Box>
            </CardContent>
            <CardActions>
              <Button startIcon={<LibraryIcon />} href="/training/wafer-library">
                Browse Library
              </Button>
              <Button startIcon={<ArrowIcon />}>Export CSV</Button>
            </CardActions>
          </Card>
        </Grid>
      </Grid>

      {/* Charts and System Health */}
      <Grid container spacing={3}>
        {/* Correlation Analysis */}
        <Grid size={{ xs: 12, lg: 8 }}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Analytics color="success" />
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Yield vs Defect Density Correlation
                </Typography>
                <Tooltip title="Scatter plot showing the relationship between defect density and yield percentage">
                  <InfoIcon fontSize="small" color="action" />
                </Tooltip>
              </Box>
              <Chip label="Real-time Data" size="small" color="success" />
            </Box>
            <Box sx={{ height: 320 }}>
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 20, right: 20, bottom: 40, left: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={theme.palette.divider} />
                  <XAxis
                    type="number"
                    dataKey="x"
                    name="Density"
                    unit="%"
                    tick={{ fontSize: 12, fill: theme.palette.text.secondary }}
                    label={{
                      value: 'Defect Density (%)',
                      position: 'insideBottom',
                      offset: -20,
                      style: { fontSize: 12, fill: theme.palette.text.secondary },
                    }}
                  />
                  <YAxis
                    type="number"
                    dataKey="y"
                    name="Yield"
                    unit="%"
                    domain={[80, 100]}
                    tick={{ fontSize: 12, fill: theme.palette.text.secondary }}
                    label={{
                      value: 'Yield (%)',
                      angle: -90,
                      position: 'insideLeft',
                      style: { fontSize: 12, fill: theme.palette.text.secondary },
                    }}
                  />
                  <ZAxis type="number" dataKey="size" range={[50, 400]} />
                  <RechartsTooltip
                    cursor={{ strokeDasharray: '3 3' }}
                    contentStyle={{
                      borderRadius: 8,
                      border: `1px solid ${theme.palette.divider}`,
                      backgroundColor: theme.palette.background.paper,
                    }}
                  />
                  <Scatter name="Lots" data={scatterData} fill={theme.palette.success.main} opacity={0.6} />
                </ScatterChart>
              </ResponsiveContainer>
            </Box>
          </Paper>
        </Grid>

        {/* System Health */}
        <Grid size={{ xs: 12, lg: 4 }}>
          <Paper sx={{ p: 3, height: '100%', bgcolor: 'grey.900', color: 'white' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
              <CheckCircle sx={{ color: 'success.light' }} />
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                System Health
              </Typography>
              <Tooltip title="Real-time infrastructure monitoring">
                <InfoIcon fontSize="small" sx={{ color: 'grey.400' }} />
              </Tooltip>
            </Box>

            {nodeInfrastructure.map((node) => (
              <Box key={node.label} sx={{ mb: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="caption" sx={{ color: 'grey.400', fontWeight: 600 }}>
                    {node.label}
                  </Typography>
                  <Typography variant="caption" sx={{ color: 'success.light', fontWeight: 600 }}>
                    {node.status}
                  </Typography>
                </Box>
                <LinearProgress
                  variant="determinate"
                  value={node.load}
                  sx={{
                    height: 6,
                    borderRadius: 3,
                    bgcolor: 'grey.800',
                    '& .MuiLinearProgress-bar': {
                      bgcolor: 'success.main',
                      borderRadius: 3,
                    },
                  }}
                />
              </Box>
            ))}

            <Divider sx={{ my: 3, borderColor: 'grey.800' }} />

            <Typography variant="caption" sx={{ color: 'grey.500', fontWeight: 600, textTransform: 'uppercase', mb: 2, display: 'block' }}>
              Recent Activity
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {mockActivity.map((item) => (
                <Box key={item.id} sx={{ display: 'flex', gap: 1.5 }}>
                  <Box
                    sx={{
                      width: 6,
                      height: 6,
                      borderRadius: '50%',
                      bgcolor: item.severity === 'error' ? 'error.main' : item.severity === 'success' ? 'success.main' : 'info.main',
                      mt: 0.5,
                      flexShrink: 0,
                    }}
                  />
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="caption" sx={{ color: 'grey.300', lineHeight: 1.4 }}>
                      {item.message}
                    </Typography>
                    <Typography variant="caption" sx={{ color: 'grey.600', display: 'block', fontFamily: 'monospace', fontSize: '0.65rem' }}>
                      {formatRelativeTime(item.timestamp)}
                    </Typography>
                  </Box>
                </Box>
              ))}
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Comprehensive Help Dialog */}
      <Dialog open={helpDialogOpen} onClose={() => setHelpDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <LearnIcon color="primary" />
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              Model Training Guide
            </Typography>
          </Box>
        </DialogTitle>
        <DialogContent dividers>
          <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2 }}>
            Complete Training Workflow
          </Typography>

          <List>
            <ListItem>
              <ListItemIcon>
                <UploadIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary="1. Ingest Training Data"
                secondary="Upload wafer inspection files (CSV, XML, KLARF). Ensure metadata is complete for traceability. Recommended: 10,000+ samples for robust training."
              />
            </ListItem>
            <Divider variant="inset" component="li" />

            <ListItem>
              <ListItemIcon>
                <AnalyzeIcon color="success" />
              </ListItemIcon>
              <ListItemText
                primary="2. Analyze Patterns"
                secondary="Use AI to detect defect patterns and visualize heatmaps. Manually annotate ambiguous cases to improve accuracy. Review similar historical cases."
              />
            </ListItem>
            <Divider variant="inset" component="li" />

            <ListItem>
              <ListItemIcon>
                <GenerateIcon color="warning" />
              </ListItemIcon>
              <ListItemText
                primary="3. Generate Synthetic Data (Optional)"
                secondary="Use GAN to create synthetic samples for rare defect patterns. Keep synthetic data below 35% of total dataset. Validate plausibility before use."
              />
            </ListItem>
            <Divider variant="inset" component="li" />

            <ListItem>
              <ListItemIcon>
                <MetricsIcon color="info" />
              </ListItemIcon>
              <ListItemText
                primary="4. Train & Validate Model"
                secondary="Configure hyperparameters, train model, and monitor learning curves. Compare with previous versions. Validate on hold-out test set."
              />
            </ListItem>
            <Divider variant="inset" component="li" />

            <ListItem>
              <ListItemIcon>
                <SettingsIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary="5. Deploy to Production"
                secondary="Deploy validated model to staging first, then production. Monitor serving metrics (latency, throughput). Set up drift detection alerts."
              />
            </ListItem>
          </List>

          <Alert severity="info" sx={{ mt: 3 }}>
            <AlertTitle>Best Practices</AlertTitle>
            <Typography variant="body2" component="div">
              <ul style={{ margin: 0, paddingLeft: 20 }}>
                <li>Maintain balanced dataset across all defect pattern types</li>
                <li>Use data augmentation for rare patterns (rotation, flip, noise)</li>
                <li>Monitor model performance continuously after deployment</li>
                <li>Retrain periodically with new data to prevent drift</li>
                <li>Document all training experiments and hyperparameters</li>
              </ul>
            </Typography>
          </Alert>

          <Alert severity="warning" sx={{ mt: 2 }}>
            <AlertTitle>Common Pitfalls to Avoid</AlertTitle>
            <Typography variant="body2" component="div">
              <ul style={{ margin: 0, paddingLeft: 20 }}>
                <li>Overfitting: Use validation set and early stopping</li>
                <li>Data leakage: Ensure proper train/val/test split</li>
                <li>Class imbalance: Use weighted loss or oversampling</li>
                <li>Insufficient data: Minimum 1000 samples per class recommended</li>
              </ul>
            </Typography>
          </Alert>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setHelpDialogOpen(false)}>Close</Button>
          <Button variant="contained" startIcon={<PlayIcon />} onClick={() => setHelpDialogOpen(false)}>
            Start Training
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
