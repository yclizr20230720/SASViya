/**
 * Training Job Queue Management Page
 * Display and manage all training jobs with status, priority, and metadata
 */

import React, { useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Typography,
  Paper,
  Button,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  LinearProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Card,
  CardContent,
  Tooltip,
  Alert
} from '@mui/material';
import {
  PlayArrow,
  Stop,
  Delete,
  Refresh,
  PriorityHigh,
  Schedule,
  CheckCircle,
  Error,
  Cancel,
  Info,
  FilterList
} from '@mui/icons-material';

interface TrainingJob {
  id: string;
  job_id: string;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'stopped' | 'cancelled';
  priority: 'high' | 'normal' | 'low';
  config: {
    model_architecture: string;
    epochs: number;
    batch_size: number;
    learning_rate: number;
    dataset_filter?: any;
  };
  current_epoch: number;
  total_epochs: number;
  metrics: {
    loss: number;
    accuracy: number;
    val_loss: number;
    val_accuracy: number;
  };
  queued_at?: string;
  start_time?: string;
  end_time?: string;
  estimated_duration_minutes: number;
  created_at?: string;
}

interface QueueStatistics {
  total_jobs: number;
  by_status: {
    queued: number;
    running: number;
    completed: number;
    failed: number;
    stopped: number;
    cancelled: number;
  };
  by_priority: {
    high: number;
    normal: number;
    low: number;
  };
  average_duration_minutes: number;
  success_rate: number;
}

const TrainingJobQueue: React.FC = () => {
  const [jobs, setJobs] = useState<TrainingJob[]>([]);
  const [statistics, setStatistics] = useState<QueueStatistics | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedJob, setSelectedJob] = useState<TrainingJob | null>(null);
  const [expandedJobId, setExpandedJobId] = useState<string | null>(null);
  const [jobMetrics, setJobMetrics] = useState<Record<string, any>>({});
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [refreshInterval, setRefreshInterval] = useState<NodeJS.Timeout | null>(null);

  // Fetch training queue
  const fetchTrainingQueue = async () => {
    try {
      setLoading(true);
      const url = filterStatus === 'all' 
        ? 'http://localhost:5000/api/v1/training/queue'
        : `http://localhost:5000/api/v1/training/queue?status=${filterStatus}`;
      
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setJobs(data.jobs || []);
        if (data.statistics) {
          setStatistics(data.statistics);
        }
      }
    } catch (error) {
      console.error('Failed to fetch training queue:', error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch queue statistics
  const fetchStatistics = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/v1/training/queue/statistics');
      if (response.ok) {
        const data = await response.json();
        setStatistics(data.statistics);
      }
    } catch (error) {
      console.error('Failed to fetch statistics:', error);
    }
  };

  // Auto-refresh every 5 seconds
  useEffect(() => {
    fetchTrainingQueue();
    fetchStatistics();
    
    const interval = setInterval(() => {
      fetchTrainingQueue();
      fetchStatistics();
    }, 5000);
    
    setRefreshInterval(interval);
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [filterStatus]);

  // Cancel job
  const handleCancelJob = async (jobId: string) => {
    try {
      const response = await fetch(`http://localhost:5000/api/v1/training/queue/${jobId}/cancel`, {
        method: 'POST'
      });
      if (response.ok) {
        alert('Job cancelled successfully');
        fetchTrainingQueue();
      }
    } catch (error) {
      console.error('Failed to cancel job:', error);
      alert('Failed to cancel job');
    }
  };

  // Requeue job
  const handleRequeueJob = async (jobId: string) => {
    try {
      const response = await fetch(`http://localhost:5000/api/v1/training/queue/${jobId}/requeue`, {
        method: 'POST'
      });
      if (response.ok) {
        alert('Job requeued successfully');
        fetchTrainingQueue();
      }
    } catch (error) {
      console.error('Failed to requeue job:', error);
      alert('Failed to requeue job');
    }
  };

  // Delete job
  const handleDeleteJob = async (jobId: string) => {
    if (!confirm('Are you sure you want to delete this job?')) return;
    
    try {
      const response = await fetch(`http://localhost:5000/api/v1/training/queue/${jobId}`, {
        method: 'DELETE'
      });
      if (response.ok) {
        alert('Job deleted successfully');
        fetchTrainingQueue();
      }
    } catch (error) {
      console.error('Failed to delete job:', error);
      alert('Failed to delete job');
    }
  };

  // Update priority
  const handleUpdatePriority = async (jobId: string, priority: string) => {
    try {
      const response = await fetch(`http://localhost:5000/api/v1/training/queue/${jobId}/priority`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priority })
      });
      if (response.ok) {
        alert('Priority updated successfully');
        fetchTrainingQueue();
      }
    } catch (error) {
      console.error('Failed to update priority:', error);
      alert('Failed to update priority');
    }
  };

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'queued': return 'info';
      case 'running': return 'primary';
      case 'completed': return 'success';
      case 'failed': return 'error';
      case 'stopped': return 'warning';
      case 'cancelled': return 'default';
      default: return 'default';
    }
  };

  // Get priority color
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'error';
      case 'normal': return 'primary';
      case 'low': return 'default';
      default: return 'default';
    }
  };

  // Format date
  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString();
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h4" fontWeight={600} gutterBottom>
            Training Job Queue
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Monitor and manage all training jobs
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<Refresh />}
          onClick={() => {
            fetchTrainingQueue();
            fetchStatistics();
          }}
        >
          Refresh
        </Button>
      </Box>

      {/* Statistics Cards */}
      {statistics && (
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent>
                <Typography color="text.secondary" gutterBottom>
                  Total Jobs
                </Typography>
                <Typography variant="h3" fontWeight={600}>
                  {statistics.total_jobs}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent>
                <Typography color="text.secondary" gutterBottom>
                  Running
                </Typography>
                <Typography variant="h3" fontWeight={600} color="primary.main">
                  {statistics.by_status.running}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent>
                <Typography color="text.secondary" gutterBottom>
                  Success Rate
                </Typography>
                <Typography variant="h3" fontWeight={600} color="success.main">
                  {statistics.success_rate}%
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent>
                <Typography color="text.secondary" gutterBottom>
                  Avg Duration
                </Typography>
                <Typography variant="h3" fontWeight={600}>
                  {statistics.average_duration_minutes.toFixed(0)}m
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Filter */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
          <FilterList />
          <FormControl size="small" sx={{ minWidth: 200 }}>
            <InputLabel>Filter by Status</InputLabel>
            <Select
              value={filterStatus}
              label="Filter by Status"
              onChange={(e) => setFilterStatus(e.target.value)}
            >
              <MenuItem value="all">All</MenuItem>
              <MenuItem value="queued">Queued</MenuItem>
              <MenuItem value="running">Running</MenuItem>
              <MenuItem value="completed">Completed</MenuItem>
              <MenuItem value="failed">Failed</MenuItem>
              <MenuItem value="stopped">Stopped</MenuItem>
              <MenuItem value="cancelled">Cancelled</MenuItem>
            </Select>
          </FormControl>
          <Typography variant="body2" color="text.secondary">
            Showing {jobs.length} job(s)
          </Typography>
        </Box>
      </Paper>

      {/* Jobs Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Job ID</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Priority</TableCell>
              <TableCell>Model</TableCell>
              <TableCell>Progress</TableCell>
              <TableCell>Queued At</TableCell>
              <TableCell>Duration</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && jobs.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  <LinearProgress />
                </TableCell>
              </TableRow>
            ) : jobs.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  <Typography color="text.secondary">No training jobs found</Typography>
                </TableCell>
              </TableRow>
            ) : (
              jobs.map((job) => (
                <TableRow key={job.job_id} hover>
                  <TableCell>
                    <Tooltip title={job.job_id}>
                      <Typography variant="body2" sx={{ fontFamily: 'monospace' }}>
                        {job.job_id.substring(0, 8)}...
                      </Typography>
                    </Tooltip>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={job.status}
                      color={getStatusColor(job.status) as any}
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={job.priority}
                      color={getPriorityColor(job.priority) as any}
                      size="small"
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">
                      {job.config.model_architecture}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {job.total_epochs} epochs
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Box sx={{ width: 100 }}>
                      <LinearProgress
                        variant="determinate"
                        value={(job.current_epoch / job.total_epochs) * 100}
                      />
                      <Typography variant="caption" color="text.secondary">
                        {job.current_epoch}/{job.total_epochs}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">
                      {formatDate(job.queued_at || job.created_at)}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">
                      ~{job.estimated_duration_minutes}m
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', gap: 0.5 }}>
                      <Tooltip title="View Details">
                        <IconButton
                          size="small"
                          onClick={() => {
                            setSelectedJob(job);
                            setDetailsOpen(true);
                          }}
                        >
                          <Info />
                        </IconButton>
                      </Tooltip>
                      {job.status === 'queued' || job.status === 'running' ? (
                        <Tooltip title="Cancel">
                          <IconButton
                            size="small"
                            color="warning"
                            onClick={() => handleCancelJob(job.job_id)}
                          >
                            <Cancel />
                          </IconButton>
                        </Tooltip>
                      ) : null}
                      {job.status === 'failed' || job.status === 'stopped' || job.status === 'cancelled' ? (
                        <Tooltip title="Requeue">
                          <IconButton
                            size="small"
                            color="primary"
                            onClick={() => handleRequeueJob(job.job_id)}
                          >
                            <Refresh />
                          </IconButton>
                        </Tooltip>
                      ) : null}
                      {job.status !== 'running' ? (
                        <Tooltip title="Delete">
                          <IconButton
                            size="small"
                            color="error"
                            onClick={() => handleDeleteJob(job.job_id)}
                          >
                            <Delete />
                          </IconButton>
                        </Tooltip>
                      ) : null}
                    </Box>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Job Details Dialog */}
      <Dialog
        open={detailsOpen}
        onClose={() => setDetailsOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Training Job Details</DialogTitle>
        <DialogContent>
          {selectedJob && (
            <Box sx={{ pt: 2 }}>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Job ID
                  </Typography>
                  <Typography variant="body1" sx={{ fontFamily: 'monospace' }}>
                    {selectedJob.job_id}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Status
                  </Typography>
                  <Chip
                    label={selectedJob.status}
                    color={getStatusColor(selectedJob.status) as any}
                    size="small"
                  />
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Priority
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                    <Chip
                      label={selectedJob.priority}
                      color={getPriorityColor(selectedJob.priority) as any}
                      size="small"
                    />
                    <Select
                      size="small"
                      value={selectedJob.priority}
                      onChange={(e) => handleUpdatePriority(selectedJob.job_id, e.target.value)}
                    >
                      <MenuItem value="high">High</MenuItem>
                      <MenuItem value="normal">Normal</MenuItem>
                      <MenuItem value="low">Low</MenuItem>
                    </Select>
                  </Box>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                    Configuration
                  </Typography>
                  <Paper sx={{ p: 2, bgcolor: 'grey.50' }}>
                    <pre style={{ margin: 0, fontSize: '0.875rem' }}>
                      {JSON.stringify(selectedJob.config, null, 2)}
                    </pre>
                  </Paper>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                    Metrics
                  </Typography>
                  <Paper sx={{ p: 2, bgcolor: 'grey.50' }}>
                    <pre style={{ margin: 0, fontSize: '0.875rem' }}>
                      {JSON.stringify(selectedJob.metrics, null, 2)}
                    </pre>
                  </Paper>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Queued At
                  </Typography>
                  <Typography variant="body2">
                    {formatDate(selectedJob.queued_at)}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Started At
                  </Typography>
                  <Typography variant="body2">
                    {formatDate(selectedJob.start_time)}
                  </Typography>
                </Grid>
              </Grid>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDetailsOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TrainingJobQueue;
