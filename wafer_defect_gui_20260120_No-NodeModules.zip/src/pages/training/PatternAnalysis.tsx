import { useState } from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Button,
  Slider,
  Chip,
  Alert,
  CircularProgress,
  Card,
  CardContent,
  LinearProgress,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Psychology as BrainIcon,
  Edit as EditIcon,
  Search as SearchIcon,
  Flag as FlagIcon,
  Terminal as TerminalIcon,
  GridView as GridViewIcon,
  Send as SendIcon,
  Info as InfoIcon,
} from '@mui/icons-material';
import { TrainingWaferCanvas } from '../../components/training';
import { generateWafer } from '../../services/waferGenerator';
import { analyzeWaferPattern } from '../../services/geminiService';
import type { WaferData, Die, AnalysisResult, Annotation } from '../../types/training';

// Similar case mini-card component
interface SimilarCaseProps {
  wafer: WaferData;
  match: string;
}

const SimilarCase = ({ wafer, match }: SimilarCaseProps) => (
  <Card
    sx={{
      cursor: 'pointer',
      transition: 'all 0.2s',
      '&:hover': {
        transform: 'translateY(-4px)',
        boxShadow: 4,
      },
    }}
  >
    <CardContent sx={{ textAlign: 'center', p: 2 }}>
      <Box sx={{ mb: 1 }}>
        <TrainingWaferCanvas wafer={wafer} size={100} showControls={false} />
      </Box>
      <Chip
        label={`${match} Match`}
        color="success"
        size="small"
        sx={{ mb: 0.5, fontWeight: 600, fontSize: '0.65rem' }}
      />
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', fontFamily: 'monospace' }}>
        ID: {wafer.id}
      </Typography>
    </CardContent>
  </Card>
);

export default function PatternAnalysis() {
  const [wafer, setWafer] = useState<WaferData>(generateWafer('W-INIT-001', 'Scratch', 0.1));
  const [hoveredDie, setHoveredDie] = useState<Die | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [heatmapIntensity, setHeatmapIntensity] = useState(0.4);
  const [isAnnotating, setIsAnnotating] = useState(false);

  // Generate similar wafers for the carousel
  const similarWafers = [
    generateWafer('W-HIST-01', 'Scratch', 0.08, 40),
    generateWafer('W-HIST-02', 'Scratch', 0.12, 40),
  ];

  const handleGenerate = () => {
    const patterns = ['Edge', 'Center', 'Scratch', 'Ring', 'Cluster'] as const;
    const randomPattern = patterns[Math.floor(Math.random() * patterns.length)];
    const newWafer = generateWafer(`W-${Math.random().toString(36).substr(2, 5)}`, randomPattern, 0.08);
    setWafer(newWafer);
    setResult(null);
    setHeatmapIntensity(0.4);
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      const analysis = await analyzeWaferPattern(wafer);
      setResult({
        ...analysis,
        heatmapIntensity: 0.6,
        featureImportance: analysis.featureImportance || [
          { feature: 'Radial Density', score: 0.82 },
          { feature: 'Angular Covariance', score: 0.45 },
          { feature: 'Cluster Eccentricity', score: 0.12 },
        ],
      });
    } catch (e) {
      console.error(e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleDieClick = (die: Die) => {
    if (!isAnnotating) return;
    const newAnnotation: Annotation = {
      id: Math.random().toString(36).substr(2, 5),
      x: die.x,
      y: die.y,
      label: `Review [${die.x},${die.y}]`,
      type: die.status === 'Defect' ? 'Critical' : 'Note',
    };
    setWafer((prev) => ({
      ...prev,
      annotations: [...(prev.annotations || []), newAnnotation],
    }));
  };

  return (
    <Box>
      <Typography variant="h4" sx={{ mb: 3, fontWeight: 600 }}>
        Pattern Analysis
      </Typography>

      <Grid container spacing={3}>
        {/* Left Column - Wafer Canvas and Controls */}
        <Grid size={{ xs: 12, xl: 7 }}>
          <Paper sx={{ p: 3, mb: 3 }}>
            {/* Header */}
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Box>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Interactive Inspection View
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'monospace' }}>
                  300mm Silicon | Lot: {wafer.lotId}
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Button
                  variant={isAnnotating ? 'contained' : 'outlined'}
                  color={isAnnotating ? 'warning' : 'primary'}
                  startIcon={<EditIcon />}
                  onClick={() => setIsAnnotating(!isAnnotating)}
                  size="small"
                >
                  {isAnnotating ? 'Finish Tagging' : 'Annotate Map'}
                </Button>
                <Tooltip title="Generate new wafer">
                  <IconButton onClick={handleGenerate} size="small">
                    <RefreshIcon />
                  </IconButton>
                </Tooltip>
                <Button
                  variant="contained"
                  startIcon={isAnalyzing ? <CircularProgress size={16} color="inherit" /> : <BrainIcon />}
                  onClick={handleAnalyze}
                  disabled={isAnalyzing}
                  size="small"
                >
                  Analyze Pattern
                </Button>
              </Box>
            </Box>

            {/* Wafer Canvas */}
            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <TrainingWaferCanvas
                wafer={wafer}
                size={500}
                onDieHover={setHoveredDie}
                onDieClick={handleDieClick}
                showHeatmap={!!result}
                heatmapIntensity={heatmapIntensity}
                showControls={false}
              />

              {/* Heatmap Intensity Control */}
              {result && (
                <Paper sx={{ mt: 3, p: 2, width: '100%', maxWidth: 500, bgcolor: 'background.default' }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <InfoIcon fontSize="small" color="action" />
                      <Typography variant="caption" sx={{ fontWeight: 600, textTransform: 'uppercase' }}>
                        Grad-CAM Sensitivity
                      </Typography>
                    </Box>
                    <Chip label={`${Math.round(heatmapIntensity * 100)}%`} size="small" color="success" />
                  </Box>
                  <Slider
                    value={heatmapIntensity}
                    onChange={(_, value) => setHeatmapIntensity(value as number)}
                    min={0}
                    max={1}
                    step={0.05}
                    valueLabelDisplay="auto"
                    valueLabelFormat={(value) => `${Math.round(value * 100)}%`}
                  />
                </Paper>
              )}

              {/* Die Hover Tooltip */}
              {hoveredDie && (
                <Paper
                  sx={{
                    position: 'absolute',
                    top: 16,
                    right: 16,
                    p: 2,
                    bgcolor: 'grey.900',
                    color: 'white',
                    minWidth: 180,
                    pointerEvents: 'none',
                  }}
                  elevation={8}
                >
                  <Typography variant="caption" sx={{ display: 'block', mb: 1, opacity: 0.7, textTransform: 'uppercase' }}>
                    Die Telemetry
                  </Typography>
                  <Typography variant="body2" sx={{ fontFamily: 'monospace', mb: 1 }}>
                    POS: [{hoveredDie.x}, {hoveredDie.y}]
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Box
                      sx={{
                        width: 12,
                        height: 12,
                        borderRadius: '50%',
                        bgcolor: hoveredDie.status === 'Defect' ? 'error.main' : 'success.main',
                        animation: hoveredDie.status === 'Defect' ? 'pulse 2s infinite' : 'none',
                      }}
                    />
                    <Typography variant="body1" sx={{ fontWeight: 600 }}>
                      {hoveredDie.status}
                    </Typography>
                  </Box>
                </Paper>
              )}
            </Box>
          </Paper>

          {/* Neural Pipeline Log */}
          <Paper sx={{ p: 2, bgcolor: 'grey.900', color: 'white' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
              <TerminalIcon fontSize="small" sx={{ color: 'success.main' }} />
              <Typography variant="caption" sx={{ fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1 }}>
                Neural Pipeline Log
              </Typography>
            </Box>
            <Box sx={{ fontFamily: 'monospace', fontSize: '0.75rem', '& > *': { mb: 0.5 } }}>
              <Typography variant="caption" sx={{ color: 'grey.500', display: 'block' }}>
                [{new Date().toLocaleTimeString()}] Pipeline: VisionTransformer-WV ready.
              </Typography>
              {wafer.annotations?.map((ann) => (
                <Typography key={ann.id} variant="caption" sx={{ color: 'warning.main', display: 'block' }}>
                  [{new Date().toLocaleTimeString()}] User Tag added: {ann.label}
                </Typography>
              ))}
              {result && (
                <Typography variant="caption" sx={{ color: 'success.main', display: 'block' }}>
                  [{new Date().toLocaleTimeString()}] Class: {result.pattern} | Confidence:{' '}
                  {(result.confidence * 100).toFixed(1)}%
                </Typography>
              )}
            </Box>
          </Paper>
        </Grid>

        {/* Right Column - Analysis Results */}
        <Grid size={{ xs: 12, xl: 5 }}>
          {!result && !isAnalyzing ? (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              {/* Awaiting Analysis State */}
              <Paper
                sx={{
                  p: 6,
                  textAlign: 'center',
                  border: 2,
                  borderStyle: 'dashed',
                  borderColor: 'divider',
                  minHeight: 400,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Box
                  sx={{
                    p: 4,
                    bgcolor: 'background.default',
                    borderRadius: '50%',
                    mb: 3,
                  }}
                >
                  <SearchIcon sx={{ fontSize: 64, color: 'text.disabled' }} />
                </Box>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>
                  Awaiting Neural Inference
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 300 }}>
                  Trigger the recognition engine to perform deep-spatial analysis.
                </Typography>
              </Paper>

              {/* Onboarding Tip */}
              <Alert severity="warning" icon={<FlagIcon />}>
                <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 0.5, textTransform: 'uppercase' }}>
                  Onboarding Tip
                </Typography>
                <Typography variant="body2">
                  You can manually tag questionable dies by enabling 'Annotate Map' and clicking on the grid.
                </Typography>
              </Alert>
            </Box>
          ) : isAnalyzing ? (
            /* Analyzing State */
            <Paper
              sx={{
                p: 6,
                textAlign: 'center',
                minHeight: 400,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Box sx={{ position: 'relative', mb: 4 }}>
                <CircularProgress size={120} thickness={2} />
                <Box
                  sx={{
                    position: 'absolute',
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)',
                  }}
                >
                  <BrainIcon sx={{ fontSize: 40, color: 'success.main' }} />
                </Box>
              </Box>
              <Box sx={{ width: '100%', maxWidth: 300 }}>
                <Box sx={{ height: 24, bgcolor: 'action.hover', borderRadius: 1, mb: 2, animation: 'pulse 1.5s infinite' }} />
                <Box sx={{ height: 16, bgcolor: 'action.selected', borderRadius: 1, animation: 'pulse 1.5s infinite 0.3s' }} />
              </Box>
            </Paper>
          ) : (
            /* Results State */
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              {/* Inference Result Card */}
              <Paper sx={{ p: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', mb: 3 }}>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    Inference Result
                  </Typography>
                  <Box>
                    <Typography variant="caption" sx={{ display: 'block', fontWeight: 600, color: 'success.main', textTransform: 'uppercase', mb: 0.5 }}>
                      Confidence
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <LinearProgress
                        variant="determinate"
                        value={result!.confidence * 100}
                        sx={{ width: 80, height: 8, borderRadius: 1 }}
                        color="success"
                      />
                      <Typography variant="caption" sx={{ fontWeight: 600 }}>
                        {(result!.confidence * 100).toFixed(0)}%
                      </Typography>
                    </Box>
                  </Box>
                </Box>

                <Box sx={{ mb: 3 }}>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1, textTransform: 'uppercase', fontWeight: 600 }}>
                    Predicted Class
                  </Typography>
                  <Typography variant="h3" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 2 }}>
                    {result!.pattern}
                    <Chip label="AI" color="success" size="small" />
                  </Typography>
                </Box>

                {/* Root Cause */}
                <Paper sx={{ p: 2, bgcolor: 'background.default', mb: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                    <FlagIcon fontSize="small" color="error" />
                    <Typography variant="caption" sx={{ fontWeight: 600, textTransform: 'uppercase', color: 'error.main' }}>
                      Root Cause Attribution
                    </Typography>
                  </Box>
                  <Typography variant="body2" sx={{ fontWeight: 500 }}>
                    {result!.rootCause}
                  </Typography>
                </Paper>

                {/* Feature Importance */}
                <Paper sx={{ p: 2, border: 1, borderColor: 'divider' }}>
                  <Typography variant="caption" sx={{ display: 'block', mb: 2, textTransform: 'uppercase', fontWeight: 600, color: 'text.secondary' }}>
                    SHAP Feature Importance
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    {result!.featureImportance?.map((fi, i) => (
                      <Box key={i}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="caption" sx={{ fontWeight: 600 }}>
                            {fi.feature}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            +{fi.score.toFixed(2)}
                          </Typography>
                        </Box>
                        <LinearProgress
                          variant="determinate"
                          value={fi.score * 100}
                          sx={{ height: 6, borderRadius: 1 }}
                          color="success"
                        />
                      </Box>
                    ))}
                  </Box>
                </Paper>
              </Paper>

              {/* Similar Historical Cases */}
              <Paper sx={{ p: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                  <GridViewIcon fontSize="small" color="action" />
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    Similar Historical Cases
                  </Typography>
                </Box>
                <Grid container spacing={2}>
                  {similarWafers.map((w, i) => (
                    <Grid key={i} size={{ xs: 6 }}>
                      <SimilarCase wafer={w} match={i === 0 ? '98.4%' : '92.1%'} />
                    </Grid>
                  ))}
                </Grid>
              </Paper>

              {/* Engineer Review Queue */}
              <Paper sx={{ p: 3, bgcolor: 'grey.900', color: 'white' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                  <SendIcon fontSize="small" sx={{ color: 'success.main' }} />
                  <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                    Engineer Review Queue
                  </Typography>
                </Box>
                <Typography variant="body2" sx={{ mb: 2, opacity: 0.7 }}>
                  Submit this wafer for peer-review if the classification is ambiguous.
                </Typography>
                <Button
                  variant="contained"
                  color="success"
                  fullWidth
                  sx={{ py: 1.5, fontWeight: 600 }}
                >
                  Escalate to Quality Lead
                </Button>
              </Paper>
            </Box>
          )}
        </Grid>
      </Grid>
    </Box>
  );
}
