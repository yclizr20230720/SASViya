/**
 * Enhanced Upload Page for Wafer Inference
 * Upload wafer information files (JSON/CSV/XLSX) and wafer map images (JPG/PNG/GIF)
 * for model inference and justification
 */

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  LinearProgress,
  Chip,
  Alert,
  AlertTitle,
  Grid,
  Paper,
  Divider,
  Tab,
  Tabs,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material';
import {
  CloudUpload,
  Delete,
  CheckCircle,
  Error as ErrorIcon,
  InsertDriveFile,
  Image as ImageIcon,
  Download,
  Info as InfoIcon,
  Description,
  TableChart,
} from '@mui/icons-material';
import { useAppDispatch } from '../store/hooks';
import { addWafer } from '../store/slices/waferSlice';
import { mockWaferData, downloadSampleCSV, downloadSampleJSON, type DefectBinData } from '../mock/waferInferenceData';

interface UploadFile {
  file: File;
  id: string;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
  error?: string;
  type: 'data' | 'image';
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

export default function Upload() {
  const [dataFiles, setDataFiles] = useState<UploadFile[]>([]);
  const [imageFiles, setImageFiles] = useState<UploadFile[]>([]);
  const [tabValue, setTabValue] = useState(0);
  const [showMockData, setShowMockData] = useState(false);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  // Dropzone for data files (JSON, CSV, XLSX)
  const { getRootProps: getDataRootProps, getInputProps: getDataInputProps, isDragActive: isDataDragActive } = useDropzone({
    accept: {
      'application/json': ['.json'],
      'text/csv': ['.csv'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
    },
    onDrop: (acceptedFiles) => {
      const newFiles = acceptedFiles.map((file) => ({
        file,
        id: Math.random().toString(36).substr(2, 9),
        progress: 0,
        status: 'pending' as const,
        type: 'data' as const,
      }));
      setDataFiles((prev) => [...prev, ...newFiles]);
    },
  });

  // Dropzone for image files (JPG, PNG, GIF)
  const { getRootProps: getImageRootProps, getInputProps: getImageInputProps, isDragActive: isImageDragActive } = useDropzone({
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif'],
    },
    multiple: true,
    onDrop: (acceptedFiles) => {
      const newFiles = acceptedFiles.map((file) => ({
        file,
        id: Math.random().toString(36).substr(2, 9),
        progress: 0,
        status: 'pending' as const,
        type: 'image' as const,
      }));
      setImageFiles((prev) => [...prev, ...newFiles]);
    },
  });

  const handleRemoveFile = (id: string, type: 'data' | 'image') => {
    if (type === 'data') {
      setDataFiles((prev) => prev.filter((f) => f.id !== id));
    } else {
      setImageFiles((prev) => prev.filter((f) => f.id !== id));
    }
  };

  const simulateUpload = (fileId: string, type: 'data' | 'image') => {
    const interval = setInterval(() => {
      const setFiles = type === 'data' ? setDataFiles : setImageFiles;
      setFiles((prev) =>
        prev.map((f) => {
          if (f.id === fileId) {
            const newProgress = Math.min(f.progress + 10, 100);
            return {
              ...f,
              progress: newProgress,
              status: newProgress === 100 ? 'completed' : 'uploading',
            };
          }
          return f;
        })
      );
    }, 200);

    setTimeout(() => {
      clearInterval(interval);
    }, 2000);
  };

  const handleUpload = () => {
    if (dataFiles.length === 0 && imageFiles.length === 0) return;

    // Upload data files
    dataFiles.forEach((file) => {
      if (file.status === 'pending') {
        simulateUpload(file.id, 'data');
      }
    });

    // Upload image files
    imageFiles.forEach((file) => {
      if (file.status === 'pending') {
        simulateUpload(file.id, 'image');
      }
    });

    // Simulate adding to store after upload
    setTimeout(() => {
      const waferId = mockWaferData[0].waferID;
      dispatch(
        addWafer({
          id: Math.random().toString(36).substr(2, 9),
          waferId,
          lotId: mockWaferData[0].lotID,
          processStep: 'Inference',
          equipmentId: mockWaferData[0].toolID,
          timestamp: new Date().toISOString(),
          status: 'processing',
        })
      );
    }, 2500);
  };

  const handleViewResults = () => {
    navigate('/history');
  };

  const allCompleted = 
    dataFiles.length > 0 && 
    imageFiles.length > 0 &&
    dataFiles.every((f) => f.status === 'completed') &&
    imageFiles.every((f) => f.status === 'completed');

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom sx={{ fontWeight: 600 }}>
          Upload Wafer Maps for Inference
        </Typography>
        <Typography variant="body1" color="text.secondary" gutterBottom>
          Upload wafer information files and wafer map images for model inference and justification
        </Typography>
        <Box sx={{ mt: 2, display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
          <Chip 
            label="📊 Data Files: JSON, CSV, XLSX" 
            color="primary" 
            variant="outlined"
            size="small"
          />
          <Chip 
            label="🖼️ Image Files: JPG, PNG, GIF" 
            color="success" 
            variant="outlined"
            size="small"
          />
          <Chip 
            label="🔍 Model Inference Ready" 
            color="info" 
            variant="outlined"
            size="small"
          />
        </Box>
      </Box>

      {/* Important Information Alert */}
      <Alert 
        severity="info" 
        sx={{ mb: 3, borderRadius: 2 }}
        icon={<InfoIcon />}
      >
        <AlertTitle sx={{ fontWeight: 600 }}>📋 Upload Requirements</AlertTitle>
        <Box component="ul" sx={{ m: 0, pl: 2, '& li': { mb: 0.5 } }}>
          <li>
            <Typography variant="body2">
              <strong>Wafer Information File</strong>: Upload JSON, CSV, or XLSX file containing WaferID, ToolID, ScanTime, and Defect Bin Locations (X, Y coordinates)
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>Wafer Map Images</strong>: Upload corresponding wafer map images in JPG, JPEG, PNG, or GIF format
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>File Matching</strong>: Ensure wafer IDs in data files match the image filenames for proper correlation
            </Typography>
          </li>
          <li>
            <Typography variant="body2">
              <strong>Inference Purpose</strong>: Uploaded data will be processed through the trained model for defect pattern recognition and justification
            </Typography>
          </li>
        </Box>
      </Alert>

      <Grid container spacing={3}>
        {/* Left Column - Upload Zones */}
        <Grid size={{ xs: 12, lg: 8 }}>
          {/* Data File Upload */}
          <Paper sx={{ mb: 3, borderRadius: 3, overflow: 'hidden' }}>
            <Box sx={{ p: 2, bgcolor: 'primary.lighter', borderBottom: 1, borderColor: 'divider' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <TableChart sx={{ color: 'primary.main' }} />
                <Typography variant="h6" fontWeight={600}>
                  1. Upload Wafer Information File
                </Typography>
              </Box>
              <Typography variant="caption" color="text.secondary">
                JSON, CSV, or XLSX file with WaferID, ToolID, ScanTime, Defect Bin X/Y coordinates
              </Typography>
            </Box>
            <CardContent>
              <Box
                {...getDataRootProps()}
                sx={{
                  border: '2px dashed',
                  borderColor: isDataDragActive ? 'primary.main' : 'grey.300',
                  borderRadius: 2,
                  p: 4,
                  textAlign: 'center',
                  cursor: 'pointer',
                  bgcolor: isDataDragActive ? 'action.hover' : 'background.paper',
                  transition: 'all 0.3s',
                  '&:hover': {
                    borderColor: 'primary.main',
                    bgcolor: 'action.hover',
                  },
                }}
              >
                <input {...getDataInputProps()} />
                <InsertDriveFile sx={{ fontSize: 48, color: 'primary.main', mb: 2 }} />
                <Typography variant="h6" gutterBottom>
                  {isDataDragActive
                    ? 'Drop data file here...'
                    : 'Drag & drop wafer data file'}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  or click to browse
                </Typography>
                <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center', flexWrap: 'wrap' }}>
                  <Chip label="JSON" size="small" color="primary" variant="outlined" />
                  <Chip label="CSV" size="small" color="primary" variant="outlined" />
                  <Chip label="XLSX" size="small" color="primary" variant="outlined" />
                </Box>
              </Box>

              {/* Data File List */}
              {dataFiles.length > 0 && (
                <Box sx={{ mt: 3 }}>
                  <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                    Data Files ({dataFiles.length})
                  </Typography>
                  <List>
                    {dataFiles.map((uploadFile) => (
                      <ListItem
                        key={uploadFile.id}
                        sx={{
                          border: 1,
                          borderColor: 'divider',
                          borderRadius: 1,
                          mb: 1,
                        }}
                      >
                        <Box sx={{ flex: 1 }}>
                          <ListItemText
                            primary={uploadFile.file.name}
                            secondary={`${(uploadFile.file.size / 1024).toFixed(2)} KB`}
                          />
                          {uploadFile.status === 'uploading' && (
                            <LinearProgress
                              variant="determinate"
                              value={uploadFile.progress}
                              sx={{ mt: 1 }}
                            />
                          )}
                          {uploadFile.status === 'completed' && (
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 1 }}>
                              <CheckCircle color="success" fontSize="small" />
                              <Typography variant="caption" color="success.main">
                                Upload completed
                              </Typography>
                            </Box>
                          )}
                        </Box>
                        <ListItemSecondaryAction>
                          {uploadFile.status === 'pending' && (
                            <IconButton
                              edge="end"
                              onClick={() => handleRemoveFile(uploadFile.id, 'data')}
                            >
                              <Delete />
                            </IconButton>
                          )}
                        </ListItemSecondaryAction>
                      </ListItem>
                    ))}
                  </List>
                </Box>
              )}
            </CardContent>
          </Paper>

          {/* Image File Upload */}
          <Paper sx={{ borderRadius: 3, overflow: 'hidden' }}>
            <Box sx={{ p: 2, bgcolor: 'success.lighter', borderBottom: 1, borderColor: 'divider' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <ImageIcon sx={{ color: 'success.main' }} />
                <Typography variant="h6" fontWeight={600}>
                  2. Upload Wafer Map Images
                </Typography>
              </Box>
              <Typography variant="caption" color="text.secondary">
                JPG, JPEG, PNG, or GIF images of wafer defect maps
              </Typography>
            </Box>
            <CardContent>
              <Box
                {...getImageRootProps()}
                sx={{
                  border: '2px dashed',
                  borderColor: isImageDragActive ? 'success.main' : 'grey.300',
                  borderRadius: 2,
                  p: 4,
                  textAlign: 'center',
                  cursor: 'pointer',
                  bgcolor: isImageDragActive ? 'action.hover' : 'background.paper',
                  transition: 'all 0.3s',
                  '&:hover': {
                    borderColor: 'success.main',
                    bgcolor: 'action.hover',
                  },
                }}
              >
                <input {...getImageInputProps()} />
                <ImageIcon sx={{ fontSize: 48, color: 'success.main', mb: 2 }} />
                <Typography variant="h6" gutterBottom>
                  {isImageDragActive
                    ? 'Drop image files here...'
                    : 'Drag & drop wafer map images'}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  or click to browse • Multiple files supported
                </Typography>
                <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center', flexWrap: 'wrap' }}>
                  <Chip label="JPG" size="small" color="success" variant="outlined" />
                  <Chip label="JPEG" size="small" color="success" variant="outlined" />
                  <Chip label="PNG" size="small" color="success" variant="outlined" />
                  <Chip label="GIF" size="small" color="success" variant="outlined" />
                </Box>
              </Box>

              {/* Image File List */}
              {imageFiles.length > 0 && (
                <Box sx={{ mt: 3 }}>
                  <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                    Image Files ({imageFiles.length})
                  </Typography>
                  <List>
                    {imageFiles.map((uploadFile) => (
                      <ListItem
                        key={uploadFile.id}
                        sx={{
                          border: 1,
                          borderColor: 'divider',
                          borderRadius: 1,
                          mb: 1,
                        }}
                      >
                        <Box sx={{ flex: 1 }}>
                          <ListItemText
                            primary={uploadFile.file.name}
                            secondary={`${(uploadFile.file.size / 1024).toFixed(2)} KB`}
                          />
                          {uploadFile.status === 'uploading' && (
                            <LinearProgress
                              variant="determinate"
                              value={uploadFile.progress}
                              sx={{ mt: 1 }}
                            />
                          )}
                          {uploadFile.status === 'completed' && (
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 1 }}>
                              <CheckCircle color="success" fontSize="small" />
                              <Typography variant="caption" color="success.main">
                                Upload completed
                              </Typography>
                            </Box>
                          )}
                        </Box>
                        <ListItemSecondaryAction>
                          {uploadFile.status === 'pending' && (
                            <IconButton
                              edge="end"
                              onClick={() => handleRemoveFile(uploadFile.id, 'image')}
                            >
                              <Delete />
                            </IconButton>
                          )}
                        </ListItemSecondaryAction>
                      </ListItem>
                    ))}
                  </List>
                </Box>
              )}
            </CardContent>
          </Paper>

          {/* Upload Button */}
          <Box sx={{ mt: 3, display: 'flex', gap: 2 }}>
            <Button
              fullWidth
              variant="contained"
              size="large"
              onClick={handleUpload}
              disabled={(dataFiles.length === 0 && imageFiles.length === 0) || allCompleted}
              startIcon={<CloudUpload />}
              sx={{ py: 1.5, fontWeight: 600 }}
            >
              {allCompleted ? 'Upload Complete - Ready for Inference' : 'Start Upload & Inference'}
            </Button>

            {allCompleted && (
              <Button
                variant="outlined"
                size="large"
                onClick={handleViewResults}
                sx={{ py: 1.5, fontWeight: 600, minWidth: 200 }}
              >
                View Results
              </Button>
            )}
          </Box>
        </Grid>

        {/* Right Column - Info and Samples */}
        <Grid size={{ xs: 12, lg: 4 }}>
          {/* Sample Data */}
          <Paper sx={{ borderRadius: 3, overflow: 'hidden', mb: 3 }}>
            <Box sx={{ p: 2, bgcolor: 'warning.lighter', borderBottom: 1, borderColor: 'divider' }}>
              <Typography variant="h6" fontWeight={600}>
                📥 Download Sample Data
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Industry-standard wafer defect bin map format
              </Typography>
            </Box>
            <CardContent>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Download sample files to understand the required data format
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Button
                  variant="outlined"
                  startIcon={<Download />}
                  onClick={downloadSampleJSON}
                  size="small"
                >
                  Download Sample JSON
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<Download />}
                  onClick={downloadSampleCSV}
                  size="small"
                >
                  Download Sample CSV
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<Description />}
                  onClick={() => setShowMockData(!showMockData)}
                  size="small"
                >
                  {showMockData ? 'Hide' : 'View'} Data Format
                </Button>
              </Box>

              {showMockData && (
                <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.100', borderRadius: 1, maxHeight: 300, overflow: 'auto' }}>
                  <Typography variant="caption" sx={{ fontFamily: 'monospace', whiteSpace: 'pre-wrap', fontSize: '0.7rem' }}>
                    {JSON.stringify(mockWaferData[0], null, 2)}
                  </Typography>
                </Box>
              )}
            </CardContent>
          </Paper>

          {/* Required Fields */}
          <Paper sx={{ borderRadius: 3, overflow: 'hidden', mb: 3 }}>
            <Box sx={{ p: 2, bgcolor: 'info.lighter', borderBottom: 1, borderColor: 'divider' }}>
              <Typography variant="h6" fontWeight={600}>
                📋 Required Data Fields
              </Typography>
            </Box>
            <CardContent>
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 600 }}>Field</TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>Format</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableRow>
                      <TableCell>WaferID</TableCell>
                      <TableCell>
                        <Typography variant="caption" sx={{ fontFamily: 'monospace' }}>
                          F12-2401A-W01-S01
                        </Typography>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>LotID</TableCell>
                      <TableCell>
                        <Typography variant="caption" sx={{ fontFamily: 'monospace' }}>
                          LOT-2401-A001
                        </Typography>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>ToolID</TableCell>
                      <TableCell>
                        <Typography variant="caption" sx={{ fontFamily: 'monospace' }}>
                          LITHO-ASML-04
                        </Typography>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>ScanTime</TableCell>
                      <TableCell>
                        <Typography variant="caption" sx={{ fontFamily: 'monospace' }}>
                          ISO 8601 format
                        </Typography>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>LocationX</TableCell>
                      <TableCell>
                        <Typography variant="caption">
                          Integer (die column)
                        </Typography>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>LocationY</TableCell>
                      <TableCell>
                        <Typography variant="caption">
                          Integer (die row)
                        </Typography>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Paper>

          {/* Supported Formats */}
          <Paper sx={{ borderRadius: 3, overflow: 'hidden' }}>
            <Box sx={{ p: 2, bgcolor: 'grey.100', borderBottom: 1, borderColor: 'divider' }}>
              <Typography variant="h6" fontWeight={600}>
                ℹ️ File Format Details
              </Typography>
            </Box>
            <CardContent>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Box>
                  <Typography variant="subtitle2" fontWeight={600} color="primary.main" gutterBottom>
                    Data Files
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                    • JSON: Structured wafer defect data
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                    • CSV: Comma-separated values
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                    • XLSX: Excel spreadsheet format
                  </Typography>
                </Box>
                
                <Divider />
                
                <Box>
                  <Typography variant="subtitle2" fontWeight={600} color="success.main" gutterBottom>
                    Image Files
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                    • JPG/JPEG: Standard image format
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                    • PNG: High quality images
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                    • GIF: Animated or static images
                  </Typography>
                </Box>

                <Divider />

                <Alert severity="success" sx={{ mt: 1 }}>
                  <Typography variant="caption">
                    <strong>Max File Size:</strong> 50MB per file
                    <br />
                    <strong>Multiple Files:</strong> Supported
                    <br />
                    <strong>Processing:</strong> Automatic inference
                  </Typography>
                </Alert>
              </Box>
            </CardContent>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
