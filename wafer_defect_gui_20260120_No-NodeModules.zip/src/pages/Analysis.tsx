import { useParams } from 'react-router-dom';
import {
  Box,
  Card,
  CardContent,
  Typography,
  LinearProgress,
  Divider,
  List,
  ListItem,
  ListItemText,
  Alert,
  Grid,
  Tabs,
  Tab,
} from '@mui/material';

import {
  CheckCircle,
  Warning,
  Speed,
} from '@mui/icons-material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { useState } from 'react';
import WaferMapCanvas from '../components/WaferMapCanvas';
import AttentionMapVisualization from '../components/AttentionMapVisualization';
import SHAPVisualization from '../components/SHAPVisualization';
import ExplanationNarrative from '../components/ExplanationNarrative';
import ConfidenceFactorsBreakdown from '../components/ConfidenceFactorsBreakdown';
import { mockWafers, mockPredictions } from '../mock/mockData';

export default function Analysis() {
  const { waferId } = useParams();
  const [explainabilityTab, setExplainabilityTab] = useState(0);
  
  // Use first wafer if no ID provided
  const wafer = waferId
    ? mockWafers.find((w) => w.waferId === waferId) || mockWafers[0]
    : mockWafers[0];
  
  const prediction = mockPredictions[wafer.id];

  if (!prediction) {
    return (
      <Alert severity="info">
        No prediction data available for this wafer.
      </Alert>
    );
  }

  // Pattern probabilities (mock data)
  const patternProbabilities = [
    { pattern: 'Edge Defect', probability: prediction.patternClass === 'Edge Defect' ? 96 : 2 },
    { pattern: 'Center Defect', probability: prediction.patternClass === 'Center Defect' ? 93 : 3 },
    { pattern: 'Scratch', probability: prediction.patternClass === 'Scratch Pattern' ? 98 : 1 },
    { pattern: 'Ring', probability: prediction.patternClass === 'Ring Pattern' ? 91 : 2 },
    { pattern: 'Random', probability: prediction.patternClass === 'Random Defects' ? 87 : 5 },
  ];

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'success';
    if (confidence >= 0.7) return 'warning';
    return 'error';
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 3, fontWeight: 600 }}>
        Wafer Details: {wafer.waferId}
      </Typography>

      <Grid container spacing={3}>
        {/* Wafer Map Visualization */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Wafer Map with Defect Heatmap
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Interactive visualization with Grad-CAM overlay showing model attention
              </Typography>
              <WaferMapCanvas heatmap={prediction.defectHeatmap} size={500} />
              <Box sx={{ mt: 2, display: 'flex', gap: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box
                    sx={{
                      width: 20,
                      height: 20,
                      background: 'linear-gradient(to right, hsl(240, 100%, 50%), hsl(0, 100%, 50%))',
                      borderRadius: 0.5,
                    }}
                  />
                  <Typography variant="caption">Low → High Defect Probability</Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Prediction Results */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Pattern Classification
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                <CheckCircle color="success" sx={{ fontSize: 40 }} />
                <Box>
                  <Typography variant="h5" sx={{ fontWeight: 600 }}>
                    {prediction.patternClass}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Detected Pattern Type
                  </Typography>
                </Box>
              </Box>
              <Box sx={{ mb: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2">Confidence Score</Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {(prediction.patternConfidence * 100).toFixed(1)}%
                  </Typography>
                </Box>
                <LinearProgress
                  variant="determinate"
                  value={prediction.patternConfidence * 100}
                  color={getConfidenceColor(prediction.patternConfidence)}
                  sx={{ height: 8, borderRadius: 4 }}
                />
              </Box>
              <Divider sx={{ my: 2 }} />
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Root Cause Analysis
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                <Warning color="warning" sx={{ fontSize: 40 }} />
                <Box>
                  <Typography variant="h5" sx={{ fontWeight: 600 }}>
                    {prediction.rootCauseClass}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Probable Root Cause
                  </Typography>
                </Box>
              </Box>
              <Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body2">Confidence Score</Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {(prediction.rootCauseConfidence * 100).toFixed(1)}%
                  </Typography>
                </Box>
                <LinearProgress
                  variant="determinate"
                  value={prediction.rootCauseConfidence * 100}
                  color={getConfidenceColor(prediction.rootCauseConfidence)}
                  sx={{ height: 8, borderRadius: 4 }}
                />
              </Box>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Processing Metrics
              </Typography>
              <List dense>
                <ListItem>
                  <ListItemText
                    primary="Processing Time"
                    secondary={`${prediction.processingTimeMs}ms`}
                  />
                  <Speed color="primary" />
                </ListItem>
                <ListItem>
                  <ListItemText
                    primary="Defect Count"
                    secondary={`${wafer.defectCount} defects`}
                  />
                </ListItem>
                <ListItem>
                  <ListItemText
                    primary="Defect Density"
                    secondary={`${(wafer.defectDensity * 100).toFixed(2)}%`}
                  />
                </ListItem>
                <ListItem>
                  <ListItemText
                    primary="Process Step"
                    secondary={wafer.processStep}
                  />
                </ListItem>
                <ListItem>
                  <ListItemText
                    primary="Equipment"
                    secondary={wafer.equipmentId}
                  />
                </ListItem>
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Pattern Probabilities */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Pattern Classification Breakdown
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Probability distribution across all pattern classes
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={patternProbabilities} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" domain={[0, 100]} />
                  <YAxis dataKey="pattern" type="category" width={120} />
                  <Tooltip />
                  <Bar dataKey="probability" fill="#0066CC" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Confidence Factors */}
        <Grid size={{ xs: 12, lg: 6 }}>
          {prediction.confidenceFactors && (
            <ConfidenceFactorsBreakdown
              overallConfidence={prediction.patternConfidence}
              factors={prediction.confidenceFactors}
            />
          )}
        </Grid>

        {/* Explainability Visualizations */}
        <Grid size={{ xs: 12 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Explainability & Model Insights
              </Typography>
              <Tabs
                value={explainabilityTab}
                onChange={(_, newValue) => setExplainabilityTab(newValue)}
                sx={{ mb: 2 }}
              >
                <Tab label="SHAP Values" />
                <Tab label="Attention Maps" />
                <Tab label="AI Explanation" />
              </Tabs>

              {explainabilityTab === 0 && (
                <SHAPVisualization
                  shapValues={prediction.shapValues}
                  baseValue={0.5}
                  predictionValue={prediction.patternConfidence}
                />
              )}

              {explainabilityTab === 1 && prediction.attentionLayers && (
                <AttentionMapVisualization
                  attentionLayers={prediction.attentionLayers}
                  size={500}
                />
              )}

              {explainabilityTab === 2 && (
                <ExplanationNarrative
                  patternClass={prediction.patternClass}
                  patternConfidence={prediction.patternConfidence}
                  rootCauseClass={prediction.rootCauseClass}
                  rootCauseConfidence={prediction.rootCauseConfidence}
                  shapValues={prediction.shapValues}
                  defectCount={wafer.defectCount}
                  defectDensity={wafer.defectDensity}
                  processStep={wafer.processStep}
                  equipmentId={wafer.equipmentId}
                />
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
