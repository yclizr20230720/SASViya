# Frontend Deployment Guide

## Overview

This directory contains deployment scripts and configuration for the VSMC AI Wafer Map frontend application on Windows Server 2022 with IIS.

## Prerequisites

- Windows Server 2022
- IIS (Internet Information Services) installed
- Node.js 18+ and npm installed
- Administrator privileges

## Deployment Steps

### Option 1: Automated Deployment (Recommended)

Run from the root directory:

```cmd
deploy-all.bat
```

This will deploy both backend and frontend automatically.

### Option 2: Manual Frontend Deployment

1. **Build the Application**

```cmd
cd wafer-defect-gui\deploy
build.bat
```

This creates an optimized production build in the `dist` folder.

2. **Install on IIS**

```cmd
install_iis.bat
```

This configures IIS to serve the frontend application.

## Configuration

### Environment Variables

Edit `.env.production` to configure the API endpoint:

```env
VITE_API_BASE_URL=http://localhost:5000/api/v1
```

### IIS Configuration

The `web.config` file is automatically copied to the `dist` folder during build. It configures:

- URL rewriting for SPA routing
- MIME types for static assets
- Compression
- Security headers
- Caching policies

### Site Settings

Default configuration in `install_iis.bat`:

- **Site Name**: VSMCAIWaferMap
- **Application Pool**: VSMCAIWaferMapPool
- **Port**: 80
- **Physical Path**: `wafer-defect-gui\dist`

To change these, edit the variables at the top of `install_iis.bat`.

## Verification

After deployment, verify the installation:

1. **Check IIS Site**

Open IIS Manager and verify the site is running.

2. **Access the Application**

Navigate to: `http://localhost` or `http://your-server-ip`

3. **Check API Connection**

The frontend should connect to the backend API at `http://localhost:5000/api/v1`

## Troubleshooting

### Build Fails

- Ensure Node.js and npm are installed
- Run `npm install` manually to check for dependency issues
- Check for TypeScript errors: `npm run type-check`

### IIS Site Not Starting

- Verify IIS is installed: `%windir%\system32\inetsrv\appcmd.exe list site`
- Check Application Pool status in IIS Manager
- Verify the `dist` folder exists and contains files

### 404 Errors on Routes

- Ensure `web.config` is present in the `dist` folder
- Verify URL Rewrite module is installed in IIS
- Check IIS logs: `C:\inetpub\logs\LogFiles`

### API Connection Fails

- Verify backend service is running: `sc query VSMCWaferDefectAPI`
- Check backend health: `curl http://localhost:5000/api/v1/health`
- Verify `.env.production` has correct API URL

## Management

### Update the Application

1. Pull latest code
2. Run `build.bat` to rebuild
3. IIS will automatically serve the new files

### Stop the Site

```cmd
%windir%\system32\inetsrv\appcmd.exe stop site "VSMCAIWaferMap"
```

### Start the Site

```cmd
%windir%\system32\inetsrv\appcmd.exe start site "VSMCAIWaferMap"
```

### Uninstall

```cmd
%windir%\system32\inetsrv\appcmd.exe delete site "VSMCAIWaferMap"
%windir%\system32\inetsrv\appcmd.exe delete apppool "VSMCAIWaferMapPool"
```

## Production Optimization

The build process automatically:

- Minifies JavaScript and CSS
- Optimizes images
- Generates source maps
- Enables tree-shaking
- Chunks code for optimal loading

## Security

The `web.config` includes security headers:

- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: SAMEORIGIN`
- `X-XSS-Protection: 1; mode=block`

For HTTPS deployment, configure SSL certificate in IIS Manager.

## Support

For issues or questions, refer to:

- Backend deployment: `wafer-defect-ap\deploy\README.md`
- Complete system guide: `DEPLOYMENT_GUIDE.md`
