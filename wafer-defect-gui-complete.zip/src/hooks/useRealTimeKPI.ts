import { useState, useEffect } from 'react';

interface KPIData {
  totalWafersProcessed: number;
  averageAccuracy: number;
  averageProcessingTime: number;
  defectDetectionRate: number;
  todayProcessed: number;
  weeklyTrend: number;
  monthlyYield: number;
}

interface SparklineData {
  wafers: number[];
  accuracy: number[];
  processingTime: number[];
  detectionRate: number[];
}

export const useRealTimeKPI = (updateInterval = 5000) => {
  const [kpiData, setKpiData] = useState<KPIData>({
    totalWafersProcessed: 1247,
    averageAccuracy: 94.2,
    averageProcessingTime: 3.2,
    defectDetectionRate: 98.7,
    todayProcessed: 45,
    weeklyTrend: 12.5,
    monthlyYield: 96.3,
  });

  const [sparklineData, setSparklineData] = useState<SparklineData>({
    wafers: [1200, 1210, 1225, 1230, 1240, 1245, 1247],
    accuracy: [93.5, 93.8, 94.0, 94.1, 94.0, 94.2, 94.2],
    processingTime: [3.5, 3.4, 3.3, 3.2, 3.3, 3.2, 3.2],
    detectionRate: [98.2, 98.4, 98.5, 98.6, 98.7, 98.7, 98.7],
  });

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate real-time updates with small random changes
      setKpiData((prev) => ({
        ...prev,
        totalWafersProcessed: prev.totalWafersProcessed + Math.floor(Math.random() * 3),
        averageAccuracy: Math.min(100, prev.averageAccuracy + (Math.random() - 0.5) * 0.2),
        averageProcessingTime: Math.max(
          2.5,
          prev.averageProcessingTime + (Math.random() - 0.5) * 0.1
        ),
        defectDetectionRate: Math.min(
          100,
          prev.defectDetectionRate + (Math.random() - 0.5) * 0.1
        ),
        todayProcessed: prev.todayProcessed + (Math.random() > 0.7 ? 1 : 0),
      }));

      // Update sparkline data
      setSparklineData((prev) => ({
        wafers: [...prev.wafers.slice(1), kpiData.totalWafersProcessed],
        accuracy: [...prev.accuracy.slice(1), kpiData.averageAccuracy],
        processingTime: [...prev.processingTime.slice(1), kpiData.averageProcessingTime],
        detectionRate: [...prev.detectionRate.slice(1), kpiData.defectDetectionRate],
      }));
    }, updateInterval);

    return () => clearInterval(interval);
  }, [updateInterval, kpiData]);

  return { kpiData, sparklineData };
};
