import { describe, it, expect, beforeEach } from 'vitest';
import apiClient from '../api';

describe('API Client', () => {
  beforeEach(() => {
    // Clear any stored tokens
    localStorage.clear();
  });

  it('should have correct base URL', () => {
    expect(apiClient.defaults.baseURL).toBeDefined();
  });

  it('should have default timeout', () => {
    expect(apiClient.defaults.timeout).toBe(30000);
  });

  it('should have JSON content type header', () => {
    expect(apiClient.defaults.headers['Content-Type']).toBe('application/json');
  });

  it('should have request interceptor configured', () => {
    expect(apiClient.interceptors.request.handlers).toHaveLength(1);
  });

  it('should have response interceptor configured', () => {
    expect(apiClient.interceptors.response.handlers).toHaveLength(1);
  });
});
