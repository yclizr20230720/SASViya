import { describe, it, expect } from 'vitest';
import waferReducer, {
  addWafer,
  updateWafer,
  removeWafer,
  selectWafer,
  setUploadProgress,
  type WaferMap,
} from '../slices/waferSlice';

describe('waferSlice', () => {
  const initialState = {
    wafers: [],
    selectedWaferId: null,
    uploadProgress: {},
    loading: false,
    error: null,
  };

  const mockWafer: WaferMap = {
    id: '1',
    waferId: 'W001',
    lotId: 'L001',
    processStep: 'Lithography',
    equipmentId: 'EQ001',
    timestamp: '2026-01-17T10:00:00Z',
    status: 'uploading',
  };

  it('should handle initial state', () => {
    expect(waferReducer(undefined, { type: 'unknown' })).toEqual(initialState);
  });

  it('should handle addWafer', () => {
    const actual = waferReducer(initialState, addWafer(mockWafer));
    expect(actual.wafers).toHaveLength(1);
    expect(actual.wafers[0]).toEqual(mockWafer);
  });

  it('should handle updateWafer', () => {
    const stateWithWafer = {
      ...initialState,
      wafers: [mockWafer],
    };
    const actual = waferReducer(
      stateWithWafer,
      updateWafer({ id: '1', updates: { status: 'completed' } })
    );
    expect(actual.wafers[0].status).toBe('completed');
  });

  it('should handle removeWafer', () => {
    const stateWithWafer = {
      ...initialState,
      wafers: [mockWafer],
    };
    const actual = waferReducer(stateWithWafer, removeWafer('1'));
    expect(actual.wafers).toHaveLength(0);
  });

  it('should handle selectWafer', () => {
    const actual = waferReducer(initialState, selectWafer('1'));
    expect(actual.selectedWaferId).toBe('1');
  });

  it('should handle setUploadProgress', () => {
    const actual = waferReducer(initialState, setUploadProgress({ id: '1', progress: 50 }));
    expect(actual.uploadProgress['1']).toBe(50);
  });
});
