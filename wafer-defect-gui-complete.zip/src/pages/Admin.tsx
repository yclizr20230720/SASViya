import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Button,
  LinearProgress,
  Grid,
} from '@mui/material';

import {
  Memory,
  Storage,
  Speed,
  CloudQueue,
  TrendingUp,
} from '@mui/icons-material';
import {
  AreaChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

export default function Admin() {
  // Mock system metrics
  const systemMetrics = {
    cpuUsage: 45,
    memoryUsage: 62,
    gpuUsage: 78,
    storageUsage: 54,
    activeUsers: 12,
    requestsPerMinute: 145,
  };

  // Mock model versions
  const modelVersions = [
    {
      version: 'v2.3',
      status: 'production',
      accuracy: 94.2,
      deployedAt: '2026-01-15',
      requests: 12450,
    },
    {
      version: 'v2.2',
      status: 'staging',
      accuracy: 93.8,
      deployedAt: '2026-01-10',
      requests: 3200,
    },
    {
      version: 'v2.1',
      status: 'archived',
      accuracy: 92.5,
      deployedAt: '2026-01-05',
      requests: 0,
    },
  ];

  // Mock performance data
  const performanceData = [
    { time: '00:00', requests: 120, latency: 3.2 },
    { time: '04:00', requests: 85, latency: 2.8 },
    { time: '08:00', requests: 210, latency: 3.5 },
    { time: '12:00', requests: 245, latency: 3.8 },
    { time: '16:00', requests: 198, latency: 3.4 },
    { time: '20:00', requests: 156, latency: 3.1 },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'production':
        return 'success';
      case 'staging':
        return 'info';
      case 'archived':
        return 'default';
      default:
        return 'default';
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ mb: 3, fontWeight: 600 }}>
        System Administration
      </Typography>

      {/* System Metrics */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography color="text.secondary" variant="body2">
                  CPU Usage
                </Typography>
                <Memory color="primary" fontSize="small" />
              </Box>
              <Typography variant="h4" sx={{ mb: 1, fontWeight: 600 }}>
                {systemMetrics.cpuUsage}%
              </Typography>
              <LinearProgress
                variant="determinate"
                value={systemMetrics.cpuUsage}
                sx={{ height: 6, borderRadius: 3 }}
              />
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography color="text.secondary" variant="body2">
                  Memory Usage
                </Typography>
                <Storage color="warning" fontSize="small" />
              </Box>
              <Typography variant="h4" sx={{ mb: 1, fontWeight: 600 }}>
                {systemMetrics.memoryUsage}%
              </Typography>
              <LinearProgress
                variant="determinate"
                value={systemMetrics.memoryUsage}
                color="warning"
                sx={{ height: 6, borderRadius: 3 }}
              />
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography color="text.secondary" variant="body2">
                  GPU Usage
                </Typography>
                <Speed color="error" fontSize="small" />
              </Box>
              <Typography variant="h4" sx={{ mb: 1, fontWeight: 600 }}>
                {systemMetrics.gpuUsage}%
              </Typography>
              <LinearProgress
                variant="determinate"
                value={systemMetrics.gpuUsage}
                color="error"
                sx={{ height: 6, borderRadius: 3 }}
              />
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography color="text.secondary" variant="body2">
                  Requests/Min
                </Typography>
                <TrendingUp color="success" fontSize="small" />
              </Box>
              <Typography variant="h4" sx={{ mb: 1, fontWeight: 600 }}>
                {systemMetrics.requestsPerMinute}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {systemMetrics.activeUsers} active users
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        {/* Performance Chart */}
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                System Performance (24h)
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Area
                    yAxisId="left"
                    type="monotone"
                    dataKey="requests"
                    stroke="#0066CC"
                    fill="#0066CC"
                    fillOpacity={0.6}
                    name="Requests"
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="latency"
                    stroke="#F57C00"
                    strokeWidth={2}
                    name="Latency (s)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Quick Actions */}
        <Grid size={{ xs: 12, lg: 4 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                Quick Actions
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
                <Button variant="contained" fullWidth startIcon={<CloudQueue />}>
                  Deploy New Model
                </Button>
                <Button variant="outlined" fullWidth>
                  Run System Diagnostics
                </Button>
                <Button variant="outlined" fullWidth>
                  View Audit Logs
                </Button>
                <Button variant="outlined" fullWidth>
                  Backup Database
                </Button>
                <Button variant="outlined" fullWidth color="error">
                  Emergency Stop
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Model Versions */}
        <Grid size={{ xs: 12 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Model Versions
                </Typography>
                <Button variant="contained" size="small">
                  Deploy New Version
                </Button>
              </Box>
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Version</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Accuracy</TableCell>
                      <TableCell>Deployed At</TableCell>
                      <TableCell>Total Requests</TableCell>
                      <TableCell align="right">Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {modelVersions.map((model) => (
                      <TableRow key={model.version}>
                        <TableCell>
                          <Typography variant="body2" fontWeight={600}>
                            {model.version}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={model.status}
                            size="small"
                            color={getStatusColor(model.status)}
                          />
                        </TableCell>
                        <TableCell>{model.accuracy}%</TableCell>
                        <TableCell>{model.deployedAt}</TableCell>
                        <TableCell>{model.requests.toLocaleString()}</TableCell>
                        <TableCell align="right">
                          {model.status !== 'production' && (
                            <Button size="small" variant="outlined">
                              Promote
                            </Button>
                          )}
                          {model.status === 'production' && (
                            <Chip label="Active" size="small" color="success" />
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
