/**
 * Training-related constants for WaferVision AI integration
 * Color schemes, glossary terms, and root cause mappings
 */

import type { DefectPattern } from '../types/training';

/**
 * Color mapping for defect patterns
 * Aligned with MUI theme for consistency
 */
export const PATTERN_COLORS: Record<DefectPattern, string> = {
  Edge: '#EF5350',      // MUI error.light - Red for edge defects
  Center: '#42A5F5',    // MUI info.light - Blue for center defects
  Scratch: '#FFA726',   // MUI warning.light - Orange for scratches
  Ring: '#AB47BC',      // Purple for ring patterns
  Cluster: '#EC407A',   // Pink for clusters
  Random: '#78909C',    // Blue Grey for random patterns
  Unknown: '#BDBDBD',   // Grey for unknown patterns
  None: '#66BB6A'       // MUI success.light - Green for no defects
};

/**
 * Semiconductor industry glossary for contextual help
 * Provides definitions for technical terms used in the application
 */
export const INDUSTRY_GLOSSARY = [
  { 
    term: 'FID', 
    definition: 'Fréchet Inception Distance: A metric used to assess the quality of images created by a generative model (GAN). Lower FID scores indicate better quality synthetic data.' 
  },
  { 
    term: 'mAP', 
    definition: 'Mean Average Precision: A popular metric in computer vision for measuring the accuracy of object detectors. Ranges from 0 to 1, with higher values indicating better performance.' 
  },
  { 
    term: 'KLARF', 
    definition: 'KLA Results File: A standard file format for semiconductor inspection results. Contains defect coordinates, classifications, and metadata.' 
  },
  { 
    term: 'CMP', 
    definition: 'Chemical Mechanical Polishing: A process of smoothing surfaces with the combination of chemical and mechanical forces. Critical for achieving planar wafer surfaces.' 
  },
  { 
    term: 'Grad-CAM', 
    definition: 'Gradient-weighted Class Activation Mapping: A technique for producing visual explanations for decisions from a large class of CNNs. Highlights important regions in the input.' 
  },
  { 
    term: 'CVD', 
    definition: 'Chemical Vapor Deposition: A process used to deposit thin films on wafers. Gas precursors react on the wafer surface to form solid material.' 
  },
  { 
    term: 'EBR', 
    definition: 'Edge Bead Removal: Process to remove excess photoresist from wafer edges to prevent contamination and improve handling.' 
  },
  { 
    term: 'Die', 
    definition: 'Individual integrated circuit on a wafer. A wafer typically contains hundreds to thousands of dies arranged in a grid pattern.' 
  },
  { 
    term: 'Bin Code', 
    definition: 'Classification code assigned to dies based on test results. Bin 0 typically indicates passing dies, while other bins indicate various failure modes.' 
  },
  { 
    term: 'Yield', 
    definition: 'Percentage of good dies on a wafer. Higher yield indicates better manufacturing process control and lower defect rates.' 
  }
];

/**
 * Root cause mapping for defect patterns
 * Maps each pattern type to likely root causes in the fabrication process
 */
export const ROOT_CAUSE_MAP: Record<DefectPattern, string[]> = {
  Edge: [
    'Edge Exclusion Calibration',
    'CMP Non-uniformity',
    'EBR Fluid Dynamics',
    'Edge Ring Misalignment',
    'Wafer Chuck Edge Contact'
  ],
  Center: [
    'CVD Nozzle Obstruction',
    'Thermal Gradient',
    'Spin Coater Velocity',
    'Gas Flow Stagnation',
    'Heating Element Non-uniformity'
  ],
  Scratch: [
    'Wafer Handling Robotic Error',
    'Polishing Pad Contamination',
    'Chuck Contact',
    'Transport Rail Particle',
    'End Effector Malfunction'
  ],
  Ring: [
    'Radial Temperature Drift',
    'Photoresist Viscosity Issue',
    'Gas Flow Turbulence',
    'Spin Coating Acceleration',
    'Radial Etch Rate Variation'
  ],
  Cluster: [
    'Micro-contamination Particle',
    'Focus/Exposure Variation',
    'Etch Localized Hotspot',
    'Reticle Defect',
    'Localized Contamination Event'
  ],
  Random: [
    'Ambient Particle Level',
    'Baseline Yield Variation',
    'Cleanroom Environment',
    'Normal Process Variation'
  ],
  Unknown: [
    'Investigate Process Shift',
    'New Material Interaction',
    'Equipment Drift',
    'Uncharacterized Failure Mode'
  ],
  None: [
    'Process Within Control Limits',
    'Optimal Process Conditions',
    'No Action Required'
  ]
};

/**
 * Default GAN configuration for synthetic wafer generation
 */
export const DEFAULT_GAN_CONFIG = {
  defectDensity: 0.05,
  noiseLevel: 0.1,
  symmetry: false,
  gridSize: 40
};

/**
 * Model architecture options for training
 */
export const MODEL_ARCHITECTURES = [
  { value: 'cnn-v1', label: 'CNN v1 (Baseline)', description: 'Simple convolutional neural network' },
  { value: 'cnn-v2', label: 'CNN v2 (Enhanced)', description: 'Improved CNN with batch normalization' },
  { value: 'resnet-50', label: 'ResNet-50', description: 'Deep residual network with 50 layers' },
  { value: 'efficientnet', label: 'EfficientNet', description: 'Efficient scaling of CNNs' },
  { value: 'vision-transformer', label: 'Vision Transformer', description: 'Transformer-based architecture' }
];

/**
 * Training hyperparameter defaults
 */
export const DEFAULT_TRAINING_CONFIG = {
  batchSize: 32,
  epochs: 100,
  learningRate: 0.001,
  validationSplit: 0.2,
  earlyStoppingPatience: 10,
  optimizer: 'adam',
  lossFunction: 'categorical_crossentropy'
};

/**
 * Wafer grid size options
 */
export const GRID_SIZE_OPTIONS = [
  { value: 20, label: '20x20 (Small)' },
  { value: 30, label: '30x30 (Medium)' },
  { value: 40, label: '40x40 (Standard)' },
  { value: 50, label: '50x50 (Large)' },
  { value: 60, label: '60x60 (Extra Large)' }
];

/**
 * Wafer diameter options (in mm)
 */
export const WAFER_DIAMETER_OPTIONS = [
  { value: 200, label: '200mm (8 inch)' },
  { value: 300, label: '300mm (12 inch)' },
  { value: 450, label: '450mm (18 inch)' }
];
