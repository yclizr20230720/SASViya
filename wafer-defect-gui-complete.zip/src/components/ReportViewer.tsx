import { useRef, useEffect } from 'react';
import {
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Grid,
  Card,
  CardContent,
  Divider,
  Chip,
  IconButton,
  Paper,
} from '@mui/material';
import {
  Close as CloseIcon,
  PictureAsPdf as PdfIcon,
  Slideshow as PptxIcon,
} from '@mui/icons-material';
import type { GeneratedReport, ReportTemplate } from '../types/report';
import { Bar, Line, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

export interface ReportViewerProps {
  report: GeneratedReport | null;
  template: ReportTemplate | null;
  open: boolean;
  onClose: () => void;
  onExportPdf?: () => void;
  onExportPptx?: () => void;
}

const ReportViewer: React.FC<ReportViewerProps> = ({
  report,
  template,
  open,
  onClose,
  onExportPdf,
  onExportPptx,
}) => {
  if (!report || !template) return null;

  // Helper function to draw wafer map on canvas
  const drawWaferMap = (canvas: HTMLCanvasElement, heatmap: number[][], size: number = 200) => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const gridSize = heatmap.length;
    const cellSize = size / gridSize;
    const centerX = size / 2;
    const centerY = size / 2;
    const radius = size / 2 - 5;

    // Clear canvas
    ctx.clearRect(0, 0, size, size);

    // Draw wafer circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
    ctx.fillStyle = '#f5f5f5';
    ctx.fill();
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 1;
    ctx.stroke();

    // Draw notch
    ctx.beginPath();
    ctx.arc(centerX, centerY - radius, 5, 0, Math.PI);
    ctx.fillStyle = '#333';
    ctx.fill();

    // Draw die grid
    const startX = centerX - (gridSize * cellSize) / 2;
    const startY = centerY - (gridSize * cellSize) / 2;

    for (let i = 0; i < gridSize; i++) {
      for (let j = 0; j < gridSize; j++) {
        const x = startX + j * cellSize;
        const y = startY + i * cellSize;

        // Check if die is within wafer circle
        const dieX = x + cellSize / 2;
        const dieY = y + cellSize / 2;
        const distFromCenter = Math.sqrt(
          Math.pow(dieX - centerX, 2) + Math.pow(dieY - centerY, 2)
        );

        if (distFromCenter <= radius - cellSize / 2) {
          // Draw die
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(x, y, cellSize - 0.5, cellSize - 0.5);

          // Draw heatmap overlay
          if (heatmap[i][j] > 0) {
            const intensity = heatmap[i][j];
            const hue = (1 - intensity) * 240; // Blue to red
            ctx.fillStyle = `hsla(${hue}, 100%, 50%, 0.7)`;
            ctx.fillRect(x, y, cellSize - 0.5, cellSize - 0.5);
          }
        }
      }
    }
  };

  // Component to render a single wafer map
  const WaferMapDisplay: React.FC<{ heatmap: number[][]; size?: number; label?: string }> = ({ 
    heatmap, 
    size = 200,
    label 
  }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
      if (canvasRef.current) {
        drawWaferMap(canvasRef.current, heatmap, size);
      }
    }, [heatmap, size]);

    return (
      <Box textAlign="center">
        <canvas ref={canvasRef} width={size} height={size} style={{ border: '1px solid #ddd', borderRadius: '4px' }} />
        {label && (
          <Typography variant="caption" display="block" mt={1}>
            {label}
          </Typography>
        )}
      </Box>
    );
  };

  const renderDailySummaryReport = () => {
    const data = report.data as any;
    
    return (
      <Box>
        {/* KPI Metrics */}
        <Grid container spacing={2} mb={3}>
          <Grid size={{ xs: 3 }}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">Total Wafers</Typography>
                <Typography variant="h4" color="primary">{data.totalWafers}</Typography>
                <Typography variant="caption" color="success.main">+5.2% vs yesterday</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid size={{ xs: 3 }}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">Avg Confidence</Typography>
                <Typography variant="h4" color="primary">{data.avgConfidence}%</Typography>
                <Typography variant="caption" color="success.main">+2.1% vs yesterday</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid size={{ xs: 3 }}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">Defect Rate</Typography>
                <Typography variant="h4" color="error">{data.defectRate}%</Typography>
                <Typography variant="caption" color="error.main">+0.8% vs yesterday</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid size={{ xs: 3 }}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">Processing Time</Typography>
                <Typography variant="h4" color="primary">{data.processingTime}</Typography>
                <Typography variant="caption" color="success.main">-0.1s vs yesterday</Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Charts */}
        <Grid container spacing={2}>
          <Grid size={{ xs: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>Pattern Distribution</Typography>
              <Pie
                data={{
                  labels: Object.keys(data.patterns || {}),
                  datasets: [{
                    data: Object.values(data.patterns || {}),
                    backgroundColor: ['#1976d2', '#dc004e', '#ff9800', '#4caf50', '#9c27b0'],
                  }],
                }}
                options={{ maintainAspectRatio: true, aspectRatio: 2 }}
              />
            </Paper>
          </Grid>
          <Grid size={{ xs: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>Hourly Processing Volume</Typography>
              <Line
                data={{
                  labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'],
                  datasets: [{
                    label: 'Wafers Processed',
                    data: [12, 19, 25, 32, 28, 15],
                    borderColor: '#1976d2',
                    backgroundColor: 'rgba(25, 118, 210, 0.1)',
                  }],
                }}
                options={{ maintainAspectRatio: true, aspectRatio: 2 }}
              />
            </Paper>
          </Grid>
        </Grid>
      </Box>
    );
  };

  const renderPatternAnalysisReport = () => {
    const data = report.data as any;
    
    return (
      <Box>
        {/* Executive Summary */}
        <Paper sx={{ p: 2, mb: 3 }}>
          <Typography variant="h6" gutterBottom>Executive Summary</Typography>
          <Typography variant="body2" sx={{ mb: 2 }}>
            Analysis period: {data.period}. Total of {data.totalPatterns} defect patterns detected with {data.dominantPattern} being the most prevalent pattern type. Average confidence score of {data.avgConfidence}% indicates high model reliability.
          </Typography>
        </Paper>

        {/* Wafer Maps Section */}
        {data.waferMaps && (
          <Paper sx={{ p: 2, mb: 3 }}>
            <Typography variant="h6" gutterBottom>Representative Wafer Maps</Typography>
            <Grid container spacing={2} justifyContent="center">
              {data.waferMaps.map((waferMap: any, index: number) => (
                <Grid key={index} size={{ xs: 6, sm: 4, md: 3 }}>
                  <WaferMapDisplay 
                    heatmap={waferMap.heatmap} 
                    size={180}
                    label={`${waferMap.pattern} - ${waferMap.confidence}%`}
                  />
                </Grid>
              ))}
            </Grid>
          </Paper>
        )}

        {/* Charts */}
        <Grid container spacing={2}>
          <Grid size={{ xs: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>Pattern Classification</Typography>
              <Bar
                data={{
                  labels: ['Center', 'Edge-Ring', 'Edge-Loc', 'Random', 'None'],
                  datasets: [{
                    label: 'Count',
                    data: [45, 32, 28, 18, 33],
                    backgroundColor: '#1976d2',
                  }],
                }}
                options={{ maintainAspectRatio: true, aspectRatio: 2 }}
              />
            </Paper>
          </Grid>
          <Grid size={{ xs: 6 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>Root Cause Distribution</Typography>
              <Pie
                data={{
                  labels: Object.keys(data.rootCauses || {}),
                  datasets: [{
                    data: Object.values(data.rootCauses || {}),
                    backgroundColor: ['#1976d2', '#dc004e', '#ff9800', '#4caf50'],
                  }],
                }}
                options={{ maintainAspectRatio: true, aspectRatio: 2 }}
              />
            </Paper>
          </Grid>
        </Grid>
      </Box>
    );
  };

  const renderYieldReport = () => {
    const data = report.data as any;
    
    return (
      <Box>
        {/* Yield Metrics */}
        <Grid container spacing={2} mb={3}>
          <Grid size={{ xs: 4 }}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">Overall Yield</Typography>
                <Typography variant="h4" color="primary">{data.overallYield}%</Typography>
                <Typography variant="caption" color="success.main">+0.7% vs last period</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid size={{ xs: 4 }}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">Yield Target</Typography>
                <Typography variant="h4" color="primary">{data.yieldTarget}%</Typography>
                <Typography variant="caption" color="text.secondary">Industry standard</Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid size={{ xs: 4 }}>
            <Card>
              <CardContent>
                <Typography variant="caption" color="text.secondary">Defect Impact</Typography>
                <Typography variant="h4" color="error">{data.defectImpact}%</Typography>
                <Typography variant="caption" color="error.main">Gap to target</Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Charts */}
        <Grid container spacing={2}>
          <Grid size={{ xs: 12 }}>
            <Paper sx={{ p: 2, mb: 2 }}>
              <Typography variant="h6" gutterBottom>Yield Trend</Typography>
              <Line
                data={{
                  labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                  datasets: [{
                    label: 'Yield %',
                    data: [91.2, 92.5, 91.8, 92.5],
                    borderColor: '#1976d2',
                    backgroundColor: 'rgba(25, 118, 210, 0.1)',
                  }, {
                    label: 'Target',
                    data: [95, 95, 95, 95],
                    borderColor: '#4caf50',
                    borderDash: [5, 5],
                  }],
                }}
                options={{ maintainAspectRatio: true, aspectRatio: 3 }}
              />
            </Paper>
          </Grid>
          <Grid size={{ xs: 12 }}>
            <Paper sx={{ p: 2 }}>
              <Typography variant="h6" gutterBottom>Equipment Performance</Typography>
              <Bar
                data={{
                  labels: Object.keys(data.equipmentPerformance || {}),
                  datasets: [{
                    label: 'Yield %',
                    data: Object.values(data.equipmentPerformance || {}),
                    backgroundColor: '#1976d2',
                  }],
                }}
                options={{ maintainAspectRatio: true, aspectRatio: 3 }}
              />
            </Paper>
          </Grid>
        </Grid>
      </Box>
    );
  };

  const renderReportContent = () => {
    if (template.type === 'daily-summary') {
      return renderDailySummaryReport();
    } else if (template.type === 'pattern-analysis') {
      return renderPatternAnalysisReport();
    } else if (template.type === 'yield-report') {
      return renderYieldReport();
    }
    return <Typography>Report content not available</Typography>;
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Box>
            <Typography variant="h6">{report.name}</Typography>
            <Box display="flex" gap={1} mt={1}>
              <Chip label={template.type.replace('-', ' ')} size="small" color="primary" sx={{ textTransform: 'capitalize' }} />
              <Chip label={new Date(report.generatedAt).toLocaleString()} size="small" variant="outlined" />
              <Chip label={`By: ${report.generatedBy}`} size="small" variant="outlined" />
            </Box>
          </Box>
          <IconButton onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </Box>
      </DialogTitle>
      <Divider />
      <DialogContent sx={{ minHeight: 500 }}>
        {renderReportContent()}
      </DialogContent>
      <Divider />
      <DialogActions>
        {onExportPdf && (
          <Button startIcon={<PdfIcon />} onClick={onExportPdf} variant="contained" color="primary">
            Export PDF
          </Button>
        )}
        {onExportPptx && (
          <Button startIcon={<PptxIcon />} onClick={onExportPptx} variant="contained" color="secondary">
            Export PowerPoint
          </Button>
        )}
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default ReportViewer;
