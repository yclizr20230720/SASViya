import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import GlobalSearch from '../GlobalSearch';

// Mock useNavigate
const mockNavigate = vi.fn();
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom');
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

describe('GlobalSearch', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
  });

  it('renders search input', () => {
    render(
      <BrowserRouter>
        <GlobalSearch />
      </BrowserRouter>
    );

    const searchInput = screen.getByPlaceholderText(/search wafers, lots, patterns/i);
    expect(searchInput).toBeInTheDocument();
  });

  it('shows search results when typing', async () => {
    render(
      <BrowserRouter>
        <GlobalSearch />
      </BrowserRouter>
    );

    const searchInput = screen.getByPlaceholderText(/search wafers, lots, patterns/i);
    fireEvent.change(searchInput, { target: { value: 'test' } });

    await waitFor(() => {
      expect(screen.getByText(/Wafer test/i)).toBeInTheDocument();
    });
  });

  it('saves search to history', async () => {
    const onSearch = vi.fn();
    render(
      <BrowserRouter>
        <GlobalSearch onSearch={onSearch} />
      </BrowserRouter>
    );

    const searchInput = screen.getByPlaceholderText(/search wafers, lots, patterns/i);
    fireEvent.change(searchInput, { target: { value: 'test query' } });

    await waitFor(() => {
      expect(onSearch).toHaveBeenCalledWith('test query');
    });
  });

  it('clears search when clear icon is clicked', async () => {
    render(
      <BrowserRouter>
        <GlobalSearch />
      </BrowserRouter>
    );

    const searchInput = screen.getByPlaceholderText(/search wafers, lots, patterns/i);
    fireEvent.change(searchInput, { target: { value: 'test' } });

    await waitFor(() => {
      const clearIcon = screen.getByTestId('ClearIcon');
      expect(clearIcon).toBeInTheDocument();
    });
  });

  it('navigates to result path when result is selected', async () => {
    const onResultSelect = vi.fn();
    render(
      <BrowserRouter>
        <GlobalSearch onResultSelect={onResultSelect} />
      </BrowserRouter>
    );

    const searchInput = screen.getByPlaceholderText(/search wafers, lots, patterns/i);
    fireEvent.change(searchInput, { target: { value: 'test' } });

    await waitFor(() => {
      const result = screen.getByText(/Wafer test/i);
      fireEvent.click(result);
    });

    await waitFor(() => {
      expect(onResultSelect).toHaveBeenCalled();
      expect(mockNavigate).toHaveBeenCalled();
    });
  });

  it('loads search history from localStorage', () => {
    const mockHistory = ['previous search 1', 'previous search 2'];
    localStorage.setItem('searchHistory', JSON.stringify(mockHistory));

    render(
      <BrowserRouter>
        <GlobalSearch />
      </BrowserRouter>
    );

    const searchInput = screen.getByPlaceholderText(/search wafers, lots, patterns/i);
    fireEvent.focus(searchInput);

    // History should be loaded
    expect(localStorage.getItem('searchHistory')).toBeTruthy();
  });
});
