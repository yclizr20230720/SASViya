/**
 * Training Components
 * Export all training-related components for easy importing
 */

export { default as TrainingWaferCanvas } from './TrainingWaferCanvas';
